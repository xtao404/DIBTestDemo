﻿
using System.Collections.ObjectModel;
using System.ComponentModel;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System;
using RockwellAutomation.UI.CommonControls;
using System.Windows.Input;
using RockwellAutomation.Client.Services.Query.Common;
namespace RockwellAutomation.UI.ViewModels
{
    public class DIBListViewModel : DIBViewModel
    {
        #region private members

        private DIBListViewItem _selectedItem;
        private ObservableCollection<DIBListViewItem> _items = new ObservableCollection<DIBListViewItem>();

        #endregion

        #region Constructor

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">DataItemBrowser View Model</param>
        public DIBListViewModel(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
            _dibViewModel.ListViewOCChanged += new PropertyChangedEventHandler(DataItemBrowserViewModel_ListViewOCChanged);
        }

        #endregion Constructor

        #region Properties

        override public bool isActive()
        {
            return _dibViewModel.DataView.IsListView();
        }

        /// <summary>
        /// ItemsSource property that is bound to the DIBListView
        /// </summary>
        public ObservableCollection<DIBListViewItem> Items
        {
            get { return _items; }

        }

        /// <summary>
        /// Selected DataItemBase item property
        /// </summary>
        public DIBListViewItem SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                if (_selectedItem != value)
                {
                    _selectedItem = value;
                    NotifyPropertyChanged("SelectedItem");
                }
            }
        }

        #endregion

        #region Events

        /// <summary>
        /// Handler for changes to the dataitems in the Device View
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">Device View Property Changed Event</param>        
        protected virtual void DataItemBrowserViewModel_ListViewOCChanged(object sender, PropertyChangedEventArgs e)
        {
            SelectedItemPropertyChangedEventArgs DSOCArgs = e as SelectedItemPropertyChangedEventArgs;

            if (DSOCArgs == null) return;

            SelectedItem = null;
            Items.Clear();

            DIBListViewItem NewSelection = null;

            // Create a DIBListViewItem object for each dataitem
            foreach (DataItemBase di in _dibViewModel.DataItems)
            {
                DIBListViewItem data = CreateDIBViewDataItemFrom(di);

                // Mark this item as the item to select if it's name matched or if we haven't marked
                // a selection yet (i.e. first item selected by default)
                if (DSOCArgs.SelectedItem == di.ToString() || NewSelection == null)
                {
                    NewSelection = data;
                }

                Items.Add(data);
            }

            //Mark and set the selected item
            if (NewSelection != null)
                NewSelection.IsSelected = true;
            SelectedItem = NewSelection;
        }

        #endregion

        #region Commands

        /// <summary>
        /// Creates the path which specifies the Controller to drill into and then navigates into it.
        /// </summary>
        public override SimpleCommand CreateDrillInCommand()
        {
            return new SimpleCommand()
            {
                ExecuteDelegate = x =>
                {
                    DIBListViewItem node = x as DIBListViewItem;
                    if (node == null) return;
                    if (node.DataItem == null) return;

                    if ((_dibViewModel.Path.Forward != null) &&
                        (node.Name == _dibViewModel.Path.Forward.DisplayName))
                        _dibViewModel.Path.SetActive(_dibViewModel.Path.Forward);
                    else
                    {
                        IPathElement newPE = PathElementFactory.Instance().CreatePathElement(node.DataItem);
                        _dibViewModel.Path.Add(newPE);

                    }
                    //handle highlighted item processing
                    this.Path.HighlightedElement = Path.ActiveElement;
                    _dibViewModel.Navigate(node.DataItem);
                }
            };
        }
        
        #endregion
        
        #region Private

        protected virtual DIBListViewItem CreateDIBViewDataItemFrom(DataItemBase di)
        {
            UpdatePropertiesOnDataItemBaseIfNeeded(di);
            DIBListViewItem data = new DIBListViewItem(di);
            data.IsSelected = false;
            return data;
        }

        private static void UpdatePropertiesOnDataItemBaseIfNeeded(DataItemBase item)
        {
            //if DataItemBase does not already have a UUID on it, set it now
            //We force all instances of DataItemBase to have a UUID as its ID. The client itself can use its won ID but needs to have different property key
            if (String.IsNullOrWhiteSpace(item.CommonID))
                item.CommonID = ResourceBase.generateRandomUUIDString();

            item.IsStructured = DIBViewItemBase.BooleanValueFrom(item.GUISupportsDrillIn, item.IsStructured);
        }

        #endregion

        #region Startup - Shutdown

        /// <summary>
        /// Remove event handlers
        /// </summary>
        override public void Cleanup()
        {
            base.Cleanup();
            _dibViewModel.ListViewOCChanged -= new PropertyChangedEventHandler(DataItemBrowserViewModel_ListViewOCChanged);
        }

        #endregion

    }
}
