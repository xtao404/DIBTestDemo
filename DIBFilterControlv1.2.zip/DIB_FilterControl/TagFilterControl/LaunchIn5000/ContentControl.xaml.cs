﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TagFilterControl.Common.Controls;
using TagFilterControl.Controls;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Utility;

namespace TagFilterControl
{
    /// <summary>
    /// Interaction logic for ContentControl.xaml
    /// </summary>
    public partial class ContentControl : UserControl
    {
        private Config config = Config.GetInstance();
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();
        public ContentControl()
        {
            InitializeComponent();
            this.ContentControlVM = new ContentControlViewModel();
            this.DataContext = this.ContentControlVM;
        }

        public ContentControlViewModel ContentControlVM { get; set; }

        private void Popup_Closed(object sender, EventArgs e)
        {
            filterDIBIn.DIBClientManager = null;
            config.IsCheckedTags.Clear();
            config.ACMCustomPropertiesTagOwnersFilter.Clear();
        }
    }
}
