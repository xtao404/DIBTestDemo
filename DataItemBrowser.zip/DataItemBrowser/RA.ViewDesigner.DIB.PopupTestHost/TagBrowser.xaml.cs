using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;

namespace PopUpTestHost
{
    /// <summary>
    /// Interaction logic for TagBrowser.xaml
    /// </summary>
    public partial class TagBrowser : Window
    {
        #region priavte data
        private TagBrowserPresenter _presenter;  //added for integration testing
        private bool _Closing;

        #endregion private data

        #region Event handling
        /// <summary>
        /// SelectedItemProperty dependency property
        /// </summary>
        public static DependencyProperty SelectedItemProperty = DependencyProperty.Register("SelectedItem",
                                typeof(string), typeof(TagBrowser), new PropertyMetadata(null));
        public string SelectedItem
        {
            get { return (string)GetValue(TagBrowser.SelectedItemProperty); }
            set { SetValue(TagBrowser.SelectedItemProperty, value); }
        }
        /// <summary>
        /// Event routing triggered when the user clicks on a hyperlink
        /// </summary>
        public static readonly RoutedEvent ItemSelectedEvent =
            EventManager.RegisterRoutedEvent("ItemSelected", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(TagBrowser));

        /// <summary>
        /// Provide CLR accessors for the DrillInClick event
        /// </summary>
        public event RoutedEventHandler ItemSelectedEventHandler
        {
            add { AddHandler(ItemSelectedEvent, value); }
            remove { RemoveHandler(ItemSelectedEvent, value); }
        }

        /// <summary>
        /// Raises the ItemSelected event
        /// </summary>
        private void RaiseItemSelectedEvent()
        {
            RoutedEventArgs args = new RoutedEventArgs(TagBrowser.ItemSelectedEvent);
            RaiseEvent(args);
        }

        private void OnItemSelected(object sender, RoutedEventArgs e)
        {
            RaiseItemSelectedEvent();
        }
        #endregion

        #region Constructor
        /// <summary>
        /// constructor
        /// </summary>
        public TagBrowser()
        {
            InitializeComponent();
            _presenter = new TagBrowserPresenter();
            this.DataContext = _presenter;

        }
        #endregion Constructor

        #region Window's Events
        /// <summary>
        /// window loaded event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ////listen for the ItemSelected event from the DataItemBrowser
            this.DataItemBrowserControl.ItemSelected += new RoutedEventHandler(DataItemBrowserControl_ItemSelected);
            this.DataItemBrowserControl.BrowserType = this.BrowserType;

            //make sure the window fits on the screen
            Rect currentRect = new Rect(this.Left, this.Top, this.Width, this.Height);
            Rect screenRect = new Rect(System.Windows.SystemParameters.VirtualScreenLeft, System.Windows.SystemParameters.VirtualScreenTop, System.Windows.SystemParameters.VirtualScreenWidth, System.Windows.SystemParameters.VirtualScreenHeight);
            Rect newRect = TagBrowserPresenter.ResizeRectToFitInScreen(currentRect, screenRect);
            //did the width or height change then update the window location and size
            if (newRect.Width != currentRect.Width || newRect.Height != currentRect.Height)
            {
                this.Top = newRect.Top;
                this.Left = newRect.Left;
                this.Width = newRect.Width;
                this.Height = newRect.Height;
            }

        }
        /// <summary>
        /// Window deactivated event - allows us to close this modeless window
        /// </summary>
        /// <param name="sender">this window</param>
        /// <param name="e"></param>
        private void Window_Deactivated(object sender, EventArgs e)
        {
            //keep this modeless window from closing when we open the filter builder dialog
            if (DataItemBrowserControl.ChildWindowOpen)
                return;
            //if we already closing do not do it again (this only happens when we select an item)
            if (_Closing)
            {
                return;
            }

            //save the window properties
            PopupTestHost.Properties.Settings.Default.Save();
            //close the window on deactivate
            this.Close();
        }
        #endregion Window's Events

        #region Item Selected Events

        /// <summary>
        /// Item selected event from the dataitembrowser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void DataItemBrowserControl_ItemSelected(object sender, RoutedEventArgs e)
        {
            //Raise event so owner of this window can get the selected item
            this.RaiseItemSelectedEvent();
            //set the closing flag so it will not attempt to close in deactivate window also
            _Closing = true;

            //save the window properties
           PopupTestHost.Properties.Settings.Default.Save();

            this.Close();
        }
        #endregion Item Selected Events
        #region BrowserType property

        /// <summary>
        /// BrowserType dependency property - specifies either which type of data item browser should be launched
        /// </summary>
        public readonly static DependencyProperty BrowserTypeProperty = DependencyProperty.Register("BrowserType", typeof(string), typeof(TagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// BrowserType property
        /// </summary>
        public string BrowserType
        {
            get
            {
                return ((string)(base.GetValue(TagBrowser.BrowserTypeProperty)));
            }
            set
            {
                base.SetValue(TagBrowser.BrowserTypeProperty, value);
            }
        }

        #endregion BrowserType Property
    }
}
