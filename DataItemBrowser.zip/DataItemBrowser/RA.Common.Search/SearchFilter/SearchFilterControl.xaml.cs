/*************************************************************************************
                                                                     
   ViewE SearchFilterControl 
   Copyright � 2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using RockwellAutomation.UI.CommonControls.ViewModels;
using System.Windows.Media;
using System.Windows.Threading;
using System.Windows.Documents;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Controls.Primitives;
using RockwellAutomation.UI.CommonControls.Behavior;

namespace RockwellAutomation.UI.CommonControls
{
    /// <summary>
    /// Interaction logic for SearchFilterControl.xaml
    /// </summary>
    public partial class SearchFilterControl : Grid
    {
        /// <summary>
        /// Event routing for filter text changed
        /// </summary>
        public static readonly RoutedEvent FilterTextChangedEvent =
            EventManager.RegisterRoutedEvent("FilterTextChanged", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(SearchFilterControl));
        /// <summary>
        /// CLR Accessor for FilterTextChangedEvent
        /// </summary>
        public event RoutedEventHandler FilterTextChangedEventHandler
        {
            add { AddHandler(FilterTextChangedEvent, value); }
            remove { RemoveHandler(FilterTextChangedEvent, value); }
        }
      
        /// <summary>
        /// Obtains the text of the search filter control's text box
        /// </summary>
		public String Text
        {
            get
            {
                return SearchFilterTextBox.Text;
            }
        }

		//Timer to run the search after user pauses (timer will reset in textBoxChanged handler)
		private DispatcherTimer _searchEventDelayTimer = new DispatcherTimer();

        //Tracks if we are calling focus in the filter builder button click handler so we know to
        // bypass the auto open context menu logic temporarily
        private bool _SettingFocusFromFilterButtonClick = false;

        //Used for workaround for implementing specific behaviour when tabbing between items in this control. 
        //Specifically, this is used during keyboard selection (using ENTER) of a combo box item to prevent the textbox from receiving the key ENTER event
        public bool IgnoreNextTextBoxKeyEvent { get; set; }

        //Used to indicate whether or not to open the context menus(for FilterButton and MRU) whenever focus is received in the FilterButton and MRU button 
        public bool ShouldAutoOpenContextMenusOnFocus { get; set; }

        //Used to indicate whether MRU list is scrolling horizontally
        public bool IsMRUListScrollingHorizontally { get { return _mruListScrollViewer != null; } }

        //Used to save the MRU list scroll viewer if it is currently active
        private ScrollViewer _mruListScrollViewer = null;

        #region "Init"

        /// <summary>
        /// Constructor
        /// </summary>
        public SearchFilterControl()
        {
            // Set the locale for our resources based on the global local;
            System.Globalization.CultureInfo currentLocale = System.Globalization.CultureInfo.CurrentUICulture;
            // If the current locale is not our default locale, we want to lookup localized strings when we are displayed.
            // For performance reasons, if the current locale is our default locale we dont want any extra lookups performed
            if (SearchFilterControl.IsDefaultLocale(currentLocale))
                RockwellAutomation.UI.CommonControls.Properties.Resources.Culture = null;
            else
                RockwellAutomation.UI.CommonControls.Properties.Resources.Culture = currentLocale;
            InitializeComponent();
            this.ShouldAutoOpenContextMenusOnFocus = false;
            this.IgnoreNextTextBoxKeyEvent = false;           
        }        

        /// <summary>
        /// Helper method to determine if the passed locale is our default locale.
        /// Our localized strings default values are set to either "en" or "en-US"
        /// </summary>
        /// <param name="aLocale"></param>
        /// <returns></returns>
        public static bool IsDefaultLocale(System.Globalization.CultureInfo aLocale)
        {
            return aLocale.Name == "en" || aLocale.Name == "en-US";
        }

        /// <summary>
        /// Handler for loaded event of this class
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchFilterControl_Loaded(object sender, RoutedEventArgs e)
        {            
            _searchEventDelayTimer.Tick += new EventHandler(_searchEventDelayTimer_Tick);
            viewModel = this.DataContext as SearchFilterControlViewModel;

            if (viewModel != null)
                viewModel.PropertyChanged += new PropertyChangedEventHandler(SearchFilterControlVM_SearchFilterTextPropertyChanged);

            UpdateSearchTextBoxAutomationProperties();

            if (this.viewModel == null)
            {
                _searchEventDelayTimer.Interval = SearchFilterControlViewModel.DefaultAutoSearchTimerDelay;
                return;
            }
            _searchEventDelayTimer.Interval = this.viewModel.AutoSearchTimerDelay;
        }

        private void SearchFilterControl_Unloaded(object sender, RoutedEventArgs e)
        {
            _searchEventDelayTimer.Tick -= _searchEventDelayTimer_Tick;
        }

        private SearchFilterControlViewModel _viewModel = null;

        /// <summary>
        /// the view model for this control
        /// </summary>
        public SearchFilterControlViewModel viewModel
        {
            get { return _viewModel; }
            //used by unit test
            internal set
            {
                _viewModel = value;
            }
        }
        #endregion

        #region "Commands"

        /// <summary>
        /// Clear Search command, this is in the view so we can give focus to the control when we are done
        /// </summary>
        private SimpleCommand _clearSearchCommand = null;
        public ICommand ClearSearchCommand
        {
            get
            {
                if (_clearSearchCommand == null)
                {
                    _clearSearchCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {
                            //ClearSearch on the view model will clear the text and error indicator
                            StopTimerAndResetSearch();
                            this.SearchFilterTextBox.Focus();                            
                            //if we are clearing/cancelling before any search has been submitted just clear the text(above) and return don't execute the filter
                            if (this.viewModel.IsClientOnlyCancelRequest())
                                return;
                            ExecuteFilter();
                        }
                    };
                }
                return _clearSearchCommand;
            }
        }

        /// <summary>
        /// Filter Builder  command, this is in the view so we can give focus to the control when we are done
        /// command is associated with filter button context menu items
        /// </summary>
        private SimpleCommand _filterBuilderCommand = null;        
        public ICommand FilterBuilderCommand
        {
            get
            {
                if (_filterBuilderCommand == null)
                {
                    _filterBuilderCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {
                            //get the filter type name
                            FilterType filterType = x as FilterType;

                            // just display the filter type string
                            this.SearchFilterTextBox.Text += " " + filterType.Operator;
 
                            this.SearchFilterTextBox.Focus();
                        }

                    };

                }
                return _filterBuilderCommand;
            }
        }

        #endregion

        #region "API"

        /// <summary>
        /// Give focus to this control
        /// </summary>
        public void ProcessKeyboardRequestFocus()
        {
            Keyboard.Focus(SearchFilterTextBox);
        }

        /// <summary>
        /// Wether or not this control has any open context menus.
        /// </summary>
        /// <returns>True if we have a context menu open, otherwise false</returns>
        public bool IsAnyContextMenuOpen()
        {
            if (FilterBuilderBtn.ContextMenu.IsOpen) return true;
            if (SearchMruPopup.IsOpen) return true;
            return false;
        }

        /// <summary>
        /// Wether or not this control has keyboard focus
        /// </summary>
        /// <returns>True if this control has keyboard focus, otherwise false</returns>
        public bool IsTextBoxFocused()
        {
            return IsKeyboardFocusWithin;
        }

        /// <summary>
        /// This handler updates the SearchFilterTextBox.Text which will then update the SearchFilterRichTextBox.SearchFilterText
        /// See SearchFilterSearchTextBox.cs for more details.
        /// This is needed to clear the textbox text correctly which in some cases doesn't work when only setting the viewmodel.SearchFilterText
        /// </summary>
        /// <param name="sender">where the event came from</param>
        /// <param name="eArgs">the arguments passed in the event</param>
        private void SearchFilterControlVM_SearchFilterTextPropertyChanged(object sender, PropertyChangedEventArgs eArgs)
        {
            string propertyName = eArgs.PropertyName;
            if (propertyName.Equals("SearchFilterText"))
            {
                //If the search filter text changes in the view model, look to see if it differs from the actual
                // text of the search filter text box.  The intention is that this be data bound via XAML, and
                // it is, but the rich text edit seems to obtain explicit values sometimes along the way thus
                // overriding any data bound value, and thus we make sure it is set explicitly here
                if (SearchFilterTextBox.Text != viewModel.SearchFilterText)
                {
                    SearchFilterTextBox.Text = viewModel.SearchFilterText;
                }
            }
            // Parse search statement if this is event came from our view model initialization code
            else if (propertyName.Equals("ParseSearchTextOnInitialize"))
            {
                ParseSearchTextAndUpdateGUIOnError(false);
            }
        }

        /// <summary>
        /// Stop timer and clear search text. Usefull to stop getting the timer events when not needed
        /// </summary>
        public void StopTimerAndResetSearch()
        {
            _searchEventDelayTimer.Stop();
            //ClearSearch on the view model will clear the text and error indicator
            this.viewModel.ClearSearch();
            this.SearchFilterTextBox.Text = string.Empty;
        }
        #endregion

        #region "SearchFilter Textbox"

        /// <summary>
        /// to catch the return key to parse the search/filter string
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void filterSearchTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (this.IgnoreNextTextBoxKeyEvent)
            {
                this.IgnoreNextTextBoxKeyEvent = false;
                return;
            }

            if (e.Key == Key.Enter)
            {
                ExecuteFilter();
            }
            else if (e.Key == Key.Delete || e.Key == Key.Back)
            {
                //Delete and backspace don't trigger KeyDown events (WPF framework thing),
                // so make sure we restart the timer in this case too (we need to start it
                // as well here because the key up event will come in after the text changed)
                _searchEventDelayTimer.Stop();
                _searchEventDelayTimer.Start();
            }
        }

        private void StartAutoSearchTimer()
        {
            if (_searchEventDelayTimer.IsEnabled) return;
            // The text has changed. Start the timer that will execute an "auto search" once timer finishes.
            // This functionality is referred to as "Auto Search" since it will auto run the search after x seconds when 
            // the user has focus in the textbox and has changed text
            _searchEventDelayTimer.Start();
        }

        /// <summary>
        /// Reset the auto search timer when a key down comes in
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void filterSearchTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            //This handles a case where the user is holding down a key repetitively
            _searchEventDelayTimer.Stop();
        }

		/// <summary>
		/// Handler for when the preset time interval has elapsed for our timer which
		/// denotes we should auto-run a search
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void _searchEventDelayTimer_Tick(object sender, EventArgs e)
		{
            //Stop the timer. Even if we ignore the tick below, we want to wait for another key up event to initiate
            // the timer again. This way moving focus back to the search control won't "spontaneously" start a search
            _searchEventDelayTimer.Stop();

			//Ignore the current timer tick if any of the popups are open
            if (MruListView.IsFocused || FilterBuilderBtn_ContextMenu.IsOpen)
				return;

			//Only run the search if the text has changed or if there is currently an error in the search text
			// In the error case, this will make sure that if the text was changed back to the same thing it started
			// as, the error parsing will reapply (since the error triangle will go away as soon as the text changes)
			if (viewModel != null)
            {
                if (this.Text.Trim() != viewModel.SearchFilterText.Trim() || viewModel.HasError)
                {
                    // As soon as this filter is executed, any already open context menus in the DIB (especially bread crumb menus)
                    // could potentially contain links are not invalid anymore (because we executed the filter). To guard against that possibility we set keyboard focus to 
                    // our search filter text box to close any already open context menus. 
                    ProcessKeyboardRequestFocus();
					ExecuteFilter(true);
				}
			}
		}
        
        /// <summary>
        /// Raises the FilterTextChanged event
        /// </summary>
        private void RaiseFilterTextChangedEvent()
        {
            RoutedEventArgs args = new RoutedEventArgs(FilterTextChangedEvent);
            RaiseEvent(args);
        }
        #endregion

        #region MRU

        /// <summary>
        /// Handle click of the SearchMruBtn
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchMruBtn_Click(object sender, RoutedEventArgs e)
        {
            // The SearchMru Popup is being opened via a normal button. 
            // It is sometimes desirable to use a toggleButton instead 
            // of a button and to do everything in XAML.  
            // However, when the DIB is hosted inside a
            // Popup the SearchMru becomes a popup inside a popup and does 
            // not handle the interaction between the ToggleButton IsChecked
            // and the SearchMruPopup IsOpen properties.
            OpenSearchMruPopup();
        }

        /// <summary>
        /// Make the SearchMruPopup visible
        /// </summary>
        private void OpenSearchMruPopup()
        {            
            if (!SearchMruPopup.IsOpen)
            {             
                SearchMruPopup.IsOpen = true;
            }
        }

        /// <summary>
        /// Close the SearchMruPopup
        /// </summary>
        private void CloseSearchMruPopup()
        {            
            SearchMruPopup.IsOpen = false;
        }        

        /// <summary>
        /// Handle event SearchMruPopup Loaded
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchMruPopup_Loaded(object sender, RoutedEventArgs e)
        {
            Popup popup = sender as Popup;
            if (popup != null)
            {
                // Attach a behavior that will help close the popup when
                // an input event is generated outside of the popup. This
                // behavior must be attached after the popup has been loaded
                PopupBehaviorCloseOnOutsideInput.AttachToPopup(popup);
            }
        }

        /// <summary>
        /// When the search mru popup is opening
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchMruPopup_Opened(object sender, EventArgs e)
        {
			viewModel.EnsureMruUpdated();
            Keyboard.Focus(MruListView);
            MruListView.SelectedIndex = -1;
        }

        /// <summary>
        /// Figure out if ListView has scrollbar visible. This is used to determine whether left or right arrow keyboard input
        /// should scroll horizontally (if the horizontal scrollbar is visible) or should act like TAB and move to next control
        /// more details at http://windowsclient.net/blogs/anshulee/archive/2008/03/26/wpf-figure-out-dynamically-if-the-listview-scrollviewer-is-showing.aspx
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MruListView_LayoutUpdated(object sender, EventArgs e)
        {
            if (!MruListView.IsVisible) return;
            Decorator border = VisualTreeHelper.GetChild(MruListView, 0) as Decorator;//Border is the first child of a Listview
            ScrollViewer scroll = border.Child as ScrollViewer;

            _mruListScrollViewer = (scroll.ScrollableWidth > 0) ? scroll : null;
        }

        /// <summary>
        /// When a key is pressed in the search MRU listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchMruListView_PreviewKeyDown(object sender, KeyEventArgs e)
        {            
            ListView listView = sender as ListView;
            if (listView == null)
            {
                return;
            }

            //Process moving to the next or previous control
            //If the user clicked left or right buttons we want them to act just like TAB and Shift TAB
            if (((Keyboard.Modifiers == ModifierKeys.Shift) && (e.Key == Key.Tab)) 
                || e.Key == Key.Tab
                || e.Key == Key.Right
                || e.Key == Key.Left)
            {
                //if we are scrolling then left and right arrows should not cause menu to close but should scroll 
                if (this.IsMRUListScrollingHorizontally && (e.Key == Key.Right || e.Key == Key.Left))
                {
                    //if we are pressing left/right against the edge of the scroll bar, don't allow this to select
                    // an item in the list view (which happens on the first invocation of a scrollable MRU list
                    // irrespective of trying to set the KeyboardNavigation.DirectionalNavigation to not do this)
                    if((e.Key == Key.Left  && this._mruListScrollViewer.HorizontalOffset==0) ||
                       (e.Key == Key.Right && this._mruListScrollViewer.HorizontalOffset==this._mruListScrollViewer.ScrollableWidth))
                        e.Handled = true;

                    return;
                }
                
                CloseSearchMruPopup();

                TraversalRequest request = null;
                if ((Keyboard.Modifiers == ModifierKeys.Shift) && (e.Key == Key.Tab) || (e.Key == Key.Left)) 
                    request = new TraversalRequest(FocusNavigationDirection.Previous);
                else
                    request = new TraversalRequest(FocusNavigationDirection.Next);
                // Change keyboard focus.
                SearchMruBtn.MoveFocus(request);
                e.Handled = true;
                return;
            }
            //Clicking ENTER with nothing selected should act like ESC key
            //Clicking ENTER with something selected will process the selection
            if (e.Key == Key.Enter)
            {
                if (listView.SelectedValue != null)
                {
                    // Prevent ExecuteFilter from being called again in filterSearchTextBox_KeyUp
                    IgnoreNextTextBoxKeyEvent = true;

                    SearchFilterTextBox.Text = listView.SelectedValue as string;
                    listView.SelectedItem = null;
                    CloseSearchMruPopup();
					ExecuteFilter();
                    this.SearchFilterTextBox.Focus();
                }
                else
                {
                    CloseSearchMruPopup();
                    this.giveKeyboardFocusWithoutContextPopup(SearchMruBtn);
                }

                e.Handled = true;
                return;                
            }
            //ESCAPE or ALT or CTRL will close the menu but leave focus on the button
            if (e.Key == Key.Escape || (Keyboard.Modifiers == ModifierKeys.Alt) || (Keyboard.Modifiers == ModifierKeys.Control))
            {
                CloseSearchMruPopup();
                this.giveKeyboardFocusWithoutContextPopup(SearchMruBtn);
                e.Handled = true;
            }
        }
        
		/// <summary>
		/// Calls the ViewModel execute filter command as well as raises the filter text change event
		/// </summary>
		/// <param name="fromTimer">Will be true if this execute call came from the auto search timer</param>
		private void ExecuteFilter(bool fromTimer = false)
		{
            ParseSearchTextAndUpdateGUIOnError(fromTimer);

			//Special case: don't send a filter text changed if the text change caused an error
			// This is a usability consideration because there is a case where the error is just happening
			// because the user is delaying a second between key presses and the search results would clear
			// if we continue to raise the filter text change
			if (viewModel.HasError && fromTimer)
				return;

			RaiseFilterTextChangedEvent();
		}

        /// <summary>
        /// Calls the ViewModel execute filter command and updates GUI elements if there was a parser error
        /// </summary>
        /// <param name="fromTimer">Will be true if this execute call came from the auto search timer</param>
        private void ParseSearchTextAndUpdateGUIOnError(bool fromTimer)
        {
            _searchEventDelayTimer.Stop();

            if (viewModel != null)
            {
                viewModel.AutoSearched = fromTimer;

                string searchText = this.Text;
                viewModel.ExecuteFilterCommand.Execute(searchText);

                //Instruct the search filter text box to underline any syntax error
                DrawingBrush wavyBrush = this.FindResource("WavyBrush") as DrawingBrush;
                Tuple<int, int> errorPositions = SearchFilterTextBox.UnderlineError(wavyBrush);
                StretchErrorBrushGeometry(searchText, errorPositions, wavyBrush);

                UpdateSearchTextBoxAutomationProperties(errorPositions.Item1, errorPositions.Item2);
            }
        }

        /// <summary>
        /// Extends the geometry of the error brush if necessary based on the passed error positions
        /// </summary>
        /// <param name="searchText">Text in the search control</param>
        /// <param name="errorPositions">Tuple containing the error information form the last filter execution</param>
        /// <param name="wavyBrush">Brush to control the geometry of</param>
        private void StretchErrorBrushGeometry(string searchText, Tuple<int, int> errorPositions, DrawingBrush wavyBrush)
        {
            if (errorPositions.Item1 != -1)
            {
                const double brushWidth = 30.5; //Found in the XAML geometry

                SearchFilterErrorTextBlock.Text = searchText.Substring(errorPositions.Item1, errorPositions.Item2);
                SearchFilterErrorTextBlock.Measure(new Size(1000, 100)); //Choose size bigger than text should ever be so desired size isn't limited
                double errorTextWidth = SearchFilterErrorTextBlock.DesiredSize.Width;

                //Determine if we need to stretch the brush
                bool stretchBrush = errorTextWidth > brushWidth;
                if (stretchBrush)
                {
                    //Create a longer path based on the error text width computed above
                    string GeometryString = "M";
                    double nextX = 0;
                    double[] yPositions = { 1.5, 0.5, 1.5, 2.5 };
                    string prefix = String.Empty;
                    for (int i = 0; nextX <= errorTextWidth + 1; i++)
                    {
                        double yPos = yPositions[i % 4];

                        GeometryString += string.Format("{0}{1},{2}", prefix, nextX.ToString(), yPos.ToString());

                        nextX += 1;
                        prefix = "L";
                    }

                    (wavyBrush.Drawing as GeometryDrawing).Geometry = Geometry.Parse(GeometryString);
                }
            }
        }

        /// <summary>
        /// Helper to set the automation properties of the search filter text box
        /// </summary>
        /// <param name="errorStart">Error start index if the search filter text has a syntax error</param>
        /// <param name="errorLength">Error length if the search filter text has a syntax error</param>
        private void UpdateSearchTextBoxAutomationProperties(int errorStart = -1, int errorLength = -1)
        {
            //Set the text and error position info in the ItemStatusProperty (so UI Automation/TAF can access it)
            string searchTextInfoString = string.Format("{0},{1}", errorStart, errorLength);
            this.SearchFilterTextBox.SetValue(System.Windows.Automation.AutomationProperties.ItemStatusProperty, searchTextInfoString);
        }

        /// <summary>
        /// When a click is made within the search MRU listview
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchMruListView_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            ListView listView = sender as ListView;
            if (listView == null)
            {
                return;
            }

            if (listView.SelectedValue == null)
            {
                return;
            }

            if (this._mruListScrollViewer != null)
            {
                // If the MRU is scrolling and the mouse is in the scroll viewer we do not want to execute a selection of the MRU
                // We want to execute the search only if the mouse is over an item in the MRU 
                ItemsPresenter itemsPresenter = this._mruListScrollViewer.Content as ItemsPresenter;
                if (itemsPresenter != null && !itemsPresenter.IsAncestorOf(Mouse.DirectlyOver as DependencyObject)) return;
            }

            // Execute a selection of an MRU item
            SearchFilterTextBox.Text = listView.SelectedValue as string;
            listView.SelectedItem = null;

            CloseSearchMruPopup();
            ExecuteFilter();

            e.Handled = true;
        }

        /// <summary>
        /// MRU button has been tabbed to
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchMruBtn_GotKeyboardFocus(object sender, RoutedEventArgs e)
        {
            if (!ShouldAutoOpenContextMenusOnFocus)
            {
                return;
            }

            OpenSearchMruPopup();
            e.Handled = true;
        }

        #endregion MRU

        #region "SearchFilterButton"

        /// <summary>
        /// When FilterBuilderBtn is either tabbed to or clicked upon do the following common code.
        /// </summary>
        private void FilterBuilderBtn_Common_Functionality()
        {
            if (FilterBuilderBtn.ContextMenu.IsOpen) return;
            // Set the placement target
            FilterBuilderBtn.ContextMenu.PlacementTarget = FilterBuilderBtn;

            // make sure the font is inherited from the control and not the frameworks menu item style
            FilterBuilderBtn.ContextMenu.FontFamily = FilterBuilderBtn.FontFamily;
            FilterBuilderBtn.ContextMenu.FontSize = FilterBuilderBtn.FontSize;

            //open the contextmenu
            FilterBuilderBtn.ContextMenu.IsOpen = true;
        }

        /// <summary>
        /// Raises the Help Event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CommandBinding_HelpExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            RaiseEvent(e);         
        }

        /// <summary>
        /// When button gets focus via keyboard navigation (left or right tab) show the drop down list. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FilterBuilderBtn_GotFocus(object sender, RoutedEventArgs e)
        {
            if (_SettingFocusFromFilterButtonClick ||
                !ShouldAutoOpenContextMenusOnFocus)
            {
                return;
            }

            FilterBuilderBtn_Common_Functionality();
            e.Handled = true;
        }

        /// <summary>
        /// When user clicks on the FilterBuildBtn
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FilterBuilderBtn_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            _SettingFocusFromFilterButtonClick = true;
            Keyboard.Focus(sender as IInputElement);
            _SettingFocusFromFilterButtonClick = false;

            FilterBuilderBtn_Common_Functionality();
            e.Handled = true;
        }

        /// <summary>
        /// If user hits ENTER or SPACE while FilterBuildBtn has focus, we want it to behave the same as when left clicking on FilterBuildBtn
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FilterBuilderBtn_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter || e.Key == Key.Space)
            { 
                FilterBuilderBtn_Common_Functionality();
                e.Handled = true;
            }
        }


        /// <summary>
        /// Typically Shift-Tab and Tab would navigate through the list of elements.  
        /// Tab functionality desired: close context menu and set the focus on next/previous item in list of crumbs.
        /// Esc key should just close the context menu.
        /// Enter key selects an item and closes the context menu.
        /// All other keys should be handled as usual.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FilterBuilderBtn_ContextMenu_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            ContextMenu cm = sender as ContextMenu;
            if (cm == null) return;
            Button button = cm.PlacementTarget as Button;
            if (button == null) return;

            //If the user clicked left or right buttons we want them to act just like TAB and Shift TAB
            //Process moving to the next or previous control
            if (((Keyboard.Modifiers == ModifierKeys.Shift) && (e.Key == Key.Tab) || 
                (e.Key == Key.Tab) || 
                (e.Key == Key.Right) || 
                (e.Key == Key.Left)))
            {
                // Close the window
                button.ContextMenu.IsOpen = false;
                this.giveKeyboardFocusWithoutContextPopup(button);
                TraversalRequest request = null;
                if ((Keyboard.Modifiers == ModifierKeys.Shift) && (e.Key == Key.Tab) || (e.Key == Key.Left))  // Shift-Tab
                    request = new TraversalRequest(FocusNavigationDirection.Previous);
                else
                {
                    request = new TraversalRequest(FocusNavigationDirection.Next);                   
                } 
                // Change keyboard focus.
                button.MoveFocus(request);
                e.Handled = true;
                return;
            }
            //Clicking ENTER with nothing selected should act like ESC key
            //Clicking ENTER with something selected will process the selection
            if (e.Key == Key.Enter)
            {
                if (button.ContextMenu.Items.CurrentItem == null) return;

                // Item selected by ENTER key. Since e.handled will is set to false we dont want the 
                // textbox to receive the next keyboard event so we set IgnoreNextTextBoxKeyEvent to true.
                this.IgnoreNextTextBoxKeyEvent = true;
                button.ContextMenu.IsOpen = false;
                e.Handled = false;
                return;
            }
            //We want the context menu to close whenever CTRL or ALT or ESC is pressed
            if ((Keyboard.Modifiers == ModifierKeys.Control) || (Keyboard.Modifiers == ModifierKeys.Alt) || (e.Key == Key.Escape))
            {
                // Close the window
                button.ContextMenu.IsOpen = false;
                e.Handled = true;
            }
        }
   

        #endregion

        #region Private


        /// <summary>
        /// Give keyboard focus to a control and make sure we dont autopop up conext menu regardless of whether shouldAutoOpenContextMenusOnFocus is set 
        /// </summary>
        /// <param name="aControl">The control to receive focus</param>
        private void giveKeyboardFocusWithoutContextPopup(Control aControl)
        {
            Boolean origContextBehavior = this.ShouldAutoOpenContextMenusOnFocus;
            this.ShouldAutoOpenContextMenusOnFocus = false;
            Keyboard.Focus(aControl);
            this.ShouldAutoOpenContextMenusOnFocus = origContextBehavior;
        }
		
        #endregion

		/// <summary>
		/// Handler for the text box losing focus
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void SearchFilterTextBox_LostFocus(object sender, RoutedEventArgs e)
		{
            //Make sure the MRU list is updated as there may be a pending auto search to add
			viewModel.EnsureMruUpdated();

		}

		/// <summary>
		/// Handler for the filter type menu opening (to make sure the MRU list is updated)
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void FilterBuilderBtn_ContextMenu_Opened(object sender, RoutedEventArgs e)
		{
			viewModel.EnsureMruUpdated();
		}

        /// <summary>
        /// Handler for the control isEnabled property change
        /// We use this hook to turn off the timer so that we 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SearchFilterControl_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (!this.IsEnabled)
            {
                _searchEventDelayTimer.Stop();
                this.SearchFilterTextBox.Text = string.Empty;
            }
        }

        /// <summary>
        /// Override key down on the clear search button to prevent enter from bubbling up to the main search
        /// control key handler (which would incorrectly issue a secondary/empty search)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ClearSearchBtn_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                ClearSearchCommand.Execute(null);
                e.Handled = true;
            }
        }

        /// <summary>
        /// Handler for the text box text changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void filterSearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!this.IsEnabled) return;
            if (this._searchEventDelayTimer.IsEnabled) return;
            if (!this.SearchFilterTextBox.IsKeyboardFocusWithin) return; //If the text box doesn't have focus, we dont want auto search
            if (this.IgnoreNextTextBoxKeyEvent) return;
            if (viewModel == null) return;
            // If the tex has not changed from what is in our view model, we dont want auto search
            if (this.Text == viewModel.SearchFilterText) return;

            // The text has changed. Start the timer that will execute an "auto search" once timer finishes.
            // This functionality is referred to as "Auto Search" since it will auto run the search after x seconds when 
            // the user has focus in the textbox and has changed text
            this.StartAutoSearchTimer();
        }
    }
}
