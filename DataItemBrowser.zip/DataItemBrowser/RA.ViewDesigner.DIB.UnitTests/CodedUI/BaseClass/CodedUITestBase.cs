using System;
using System.Collections.Generic;
using System.Windows.Input;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapClasses;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
using System.Diagnostics;
using System.Windows;
using System.Reflection;
using System.IO;
using System.Windows.Automation;
using System.Threading;
using System.Text;


namespace DataItemBrowserUT
{
    /// <summary>
    /// Excecutes Tests which require the popup test host to run the DIBWindow
    /// </summary>
    [CodedUITest]
    public abstract class CodedUITestBase
    {
        private static Process _popupTestHostProcess = null;
        private static bool _HasOpenedPackage = false;
        private static int _TotalTestCount = 0;
        private static int _NumTestsRun = 0;
        protected string _serializationFilePath = null;
        private static Dictionary<string, string> _TestClasses = new Dictionary<string, string>();
        protected string _projectName;
        private static string _popupTestHostProject = String.Empty;

        private static Process _qspMockProcess = null;
        private static string qspMockConfigFileName = "00000000-0000-dddd-0000-00000000ffff.xml";
        private static string qspMockWindowTitleName = "QSPMock";

        public CodedUITestBase()
        {
            //If we haven't already obtained the test methods from this class, do so now
            // we need to check via a static dictionary because test view can cause the
            // test constructors to be called multiple times
            string thisClassName = this.GetType().Name;
            if (!_TestClasses.ContainsKey(thisClassName))
            {
                _TestClasses[thisClassName] = String.Empty;

                //Determine how many tests are in this test class
                MethodInfo[] TestMethods = this.GetType().GetMethods();
                foreach (MethodInfo curInfo in TestMethods)
                {
                    if (curInfo.IsDefined(typeof(TestMethodAttribute), true))
                    {
                        if (!curInfo.IsDefined(typeof(IgnoreAttribute), true))
                        {
                            Console.WriteLine("Adding test method to base UI test count: " + curInfo.ReflectedType.Name + "." + curInfo.Name);
                            _TotalTestCount += 1;
                        }
                    }
                }
            }

            //determine the path for the serialization file
            PrivateType dataGridViewPrivate = new PrivateType(typeof(RockwellAutomation.UI.Views.DIBGridView));
            _serializationFilePath = (string)dataGridViewPrivate.GetStaticFieldOrProperty("_GridRowDataFilePath");
            // Make sure path exists if it is not already created
            String _serializationFileDirectory = _serializationFilePath.Remove(_serializationFilePath.IndexOf((string)dataGridViewPrivate.GetStaticFieldOrProperty("_GridRowDataFileName")));
            if (!System.IO.Directory.Exists(_serializationFileDirectory))
            {
                System.IO.Directory.CreateDirectory(_serializationFileDirectory);
            }
        }

        //Helper to take any VPD/L5X files embedded in the unit test assembly and extract them to the unit test working directory
        private static void ExtractEmbeddedProjectFiles()
        {
            Assembly curAssembly = Assembly.GetExecutingAssembly();
            foreach(string resPath in curAssembly.GetManifestResourceNames())
            {
                if (resPath.EndsWith(".VPD") || resPath.EndsWith(".L5X"))
                {
                    Stream curStream = curAssembly.GetManifestResourceStream(resPath);

                    FileStream outputFile = new FileStream(resPath, FileMode.Create);
                    curStream.CopyTo(outputFile);

                    outputFile.Close();
                    curStream.Close();
                }
            }
        }

        #region "QSP Mock"

        private bool IsUsingQSPMock()
        {
            return this._projectName == CodedUITestBase.qspMockConfigFileName;
        }

        private static string QspMockWorkingDirectory()
        {
            return Environment.GetEnvironmentVariable("USERPROFILE") + "/Documents/Studio 5000/Projects/";
        }

        private static void EnsureQSPMockWorkingDirectoryExists()
        {
            bool IsExists = System.IO.Directory.Exists(CodedUITestBase.QspMockWorkingDirectory());
            if (!IsExists) System.IO.Directory.CreateDirectory(CodedUITestBase.QspMockWorkingDirectory());
        }

        //Helper to create the mock data sources file - returns the name of the created XML file
        private string CreateMockDataSourcesXmlFile(params Tuple<string, string, string>[] mockDataSources)
        {
            string CurrentDir = Directory.GetCurrentDirectory();
            StringBuilder MockXmlContentBuilder = new StringBuilder();
            MockXmlContentBuilder.AppendLine("<?xml version=\"1.0\" ?>");
            MockXmlContentBuilder.AppendLine("<!--");
            MockXmlContentBuilder.AppendLine("    Copyright 2013 Rockwell Automation Technologies, Inc.");
            MockXmlContentBuilder.AppendLine("");
            MockXmlContentBuilder.AppendLine("    Device Resource instance file for the Mock Query Session service.");
            MockXmlContentBuilder.AppendLine("    This file specifies the Devices contained within the project (database).");
            MockXmlContentBuilder.AppendLine("    The project (database) UUID is shown in the name of this file.");
            MockXmlContentBuilder.AppendLine("--> ");
            MockXmlContentBuilder.AppendLine("<Resources>");
            foreach (Tuple<string, string, string> curDataSource in mockDataSources)
            {
                bool isHmi = curDataSource.Item3 == "hmi";
                string NodeName = isHmi ? "HMI" : "Controller";
                MockXmlContentBuilder.Append("   <");
                MockXmlContentBuilder.Append(NodeName);
                MockXmlContentBuilder.Append(" uuid=\"0,1\" ");
                MockXmlContentBuilder.Append(" name=\"");
                MockXmlContentBuilder.Append(curDataSource.Item1);
                MockXmlContentBuilder.Append("\" ");
                MockXmlContentBuilder.Append("path=\"");
                if (isHmi)
                    MockXmlContentBuilder.Append(curDataSource.Item2);
                else
                    MockXmlContentBuilder.Append(Path.Combine(CurrentDir, "DataItemBrowserUT.CodedUI.Projects." + Path.GetFileNameWithoutExtension(curDataSource.Item2)));
                MockXmlContentBuilder.AppendLine("\" />");
            }

            MockXmlContentBuilder.AppendLine("</Resources>");
            CodedUITestBase.EnsureQSPMockWorkingDirectoryExists();
            File.WriteAllText(CodedUITestBase.QspMockWorkingDirectory() + CodedUITestBase.qspMockConfigFileName, MockXmlContentBuilder.ToString());
            return CodedUITestBase.qspMockConfigFileName;
        }

        private void startQSPMockIfNeeded()
        {
            if (this.IsQSPMockRunning()) return;

            // The QSP Mock is started by running ..ct_dib\out\lib\ct-mock-query-services.bat
            // Here we start QSPMock and give the window title a specific name in order to be able to identify it later on

            string currentDir = Directory.GetCurrentDirectory();
            if (currentDir.IndexOf("src") > 0) currentDir = currentDir.Remove(currentDir.IndexOf("src"));
            if (currentDir.IndexOf("test") > 0) currentDir = currentDir.Remove(currentDir.IndexOf("test"));
            currentDir = currentDir + @"out\lib";

            ProcessStartInfo processStartInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                WorkingDirectory = currentDir,
                Arguments = "/C title " + CodedUITestBase.qspMockWindowTitleName + " & ct-mock-query-services.bat"
            };

            _qspMockProcess = new Process { StartInfo = processStartInfo };
            _qspMockProcess.Start();

            //----------------------------------------------------------------------------------------------------
            // Use the following in order to start the command prompt without the console GUI, and execute commands.
            // This is a cleaner approach since the user will not see the console window but can cause issues if we dont properly clean up between tests
            //ProcessStartInfo processStartInfo = new ProcessStartInfo
            //{
            //    FileName = "cmd.exe",
            //    WorkingDirectory = "C:\\CodeViewSnapshots\\adpantea.C1.20348\\ct_dib\\out\\lib",
            //RedirectStandardInput = true,
            //RedirectStandardOutput = true,
            //UseShellExecute = false,
            //CreateNoWindow = false,
            //};

            //Process _qspMockProcess = new Process { StartInfo = processStartInfo };
            //_qspMockProcess.Start();
            //_qspMockProcess.StandardInput.WriteLine(@"dir>cd ..\..\..\..\..\..\..\out\lib");
            //_qspMockProcess.StandardInput.WriteLine(@"dir>ct-mock-query-services.bat");
        }
               
        private bool IsQSPMockRunning()
        {
            // test to make sure not one else is running the Mock manually
            Process[] allOpenCommandPrompts = Process.GetProcessesByName("cmd");
            foreach (Process currentProcess in allOpenCommandPrompts)
            {
                if (currentProcess.MainWindowTitle.Contains("ct_mock-query-services.bat")) return true;
                if (currentProcess.MainWindowTitle.Contains(CodedUITestBase.qspMockWindowTitleName)) return true;
            }

            return (_qspMockProcess != null);
        }

        private void CloseQSPMockIfRunning()
        {
            if (!IsQSPMockRunning()) return;
            _qspMockProcess.CloseMainWindow();
            _qspMockProcess = null;
        }


        #endregion

        //Helper to open a popup test host (or in certain cases, close and restart to a different project)
        private void StartPopupTestHost(string projectName)
        {
            //If we're already open to the specified project, just send keys to ensure all fields in the popup are cleaned
            if (_HasOpenedPackage && _popupTestHostProject == projectName)
            {
                //Load values from the default file which will: 1) collapse the data context section and 2) clear selected item data
                PTC_HitControlPlus("L");
                //Clear values from the data context section
                PTC_HitControlPlus("K");
                return;
            }

            _HasOpenedPackage = false;

            //Check that no popup test host is currently running
            Process[] popupTestHosts = Process.GetProcessesByName("RA.DTC.DataItemBrowser.PopupTestHost");
            string currentDir = Directory.GetCurrentDirectory();

            //If there's an open popup test host, see if it's from a previous test in this same test context
            if (popupTestHosts.Length == 1)
            {
                Process openTestHostProcess = popupTestHosts[0];
                string openTestHostPath = Path.GetDirectoryName(openTestHostProcess.MainModule.FileName);
                if (openTestHostPath == currentDir)
                {
                    //Close the open test host since we'll simply re-open a new one below to be "fresh" for the next test
                    _HasOpenedPackage = true;
                    openTestHostProcess.CloseMainWindow();
                }
            }

            //If we've not closed an open test host above (thus leaving the package open), assert to require previously open test host be closed
            if (_HasOpenedPackage == false && popupTestHosts.Length != 0)
            {
                if (System.Diagnostics.Debugger.IsAttached)
                {
                    string sVar = popupTestHosts.Length == 1 ? "" : " windows";
                    MessageBox.Show("All open popup test host windows must be closed before running coded UI tests.\n\nClose the existing popup test host" + sVar + " and then click OK to prevent coded UI test error.", "All open popup test host windows must be closed...", MessageBoxButton.OK, MessageBoxImage.Warning);
                    Thread.Sleep(500);
                    popupTestHosts = Process.GetProcessesByName("RA.DTC.DataItemBrowser.PopupTestHost");
                }

                Assert.IsTrue(popupTestHosts.Length == 0, "All open popup test host windows must be closed before running these tests.");
            }

            //Get the paths for the files we can use to ensure the popup loads set to the project we're interested in
            PrivateType PopupPrivate = new PrivateType("RA.DTC.DataItemBrowser.PopupTestHost", "RockwellAutomation.DesignTimeClient.PopUpTestHost.Window1");
            string DefaultDevicesFile = Path.Combine(currentDir, (string)PopupPrivate.GetStaticFieldOrProperty("_WELL_KNOWN_DEFAULT_CONTROLLERS_FILE"));
            string DefaultPackageFile = Path.Combine(currentDir, (string)PopupPrivate.GetStaticFieldOrProperty("_WELL_KNOWN_DEFAULT_PACKAGEPATH_FILE"));
            string SkipPackagerParam  = Path.Combine(currentDir, (string)PopupPrivate.GetStaticFieldOrProperty("_SKIP_PACKAGER_ERROR_COMMANDLINE_PARAM"));

            if (this.IsUsingQSPMock())
            {
                //Start the QSP Mock and monitor
                this.startQSPMockIfNeeded();

                //We are using the QSP Mock and want the QSP mock config file to be put out to "%USERPROFILE%/Documents/Studio 5000/Projects/
                //This will make the unit test version of the popup test host use the users profile projects directory for .XML files
                CodedUITestBase.EnsureQSPMockWorkingDirectoryExists();
                File.WriteAllText(DefaultPackageFile, CodedUITestBase.QspMockWorkingDirectory());
            }
            else
            {
                //This will make the unit test version of the popup test host use the current directory for VPD files
                File.WriteAllText(DefaultPackageFile, currentDir);
            }

            //This will make the unit test version of the popup test host select the project name we are interested in, as well as
            // set up empty defaults for the selected item fields, as well as a collapsed mode for the data context expander, as well
            // as using the Tag browser radio button as default.  These defaults will be read whenever a test class context is
            // changing so these settings will ensure a clean start for each test.
            List<string> DefaultLines = new List<string>();
            DefaultLines.Add("@ViewProject," + projectName);
            DefaultLines.Add("@ShowDataContext,0");
            DefaultLines.Add("@BrowserType,Tag");
            DefaultLines.Add("@SelectedItem,txReadTag,");
            DefaultLines.Add("@SelectedItem,txWriteTag,");
            DefaultLines.Add("@SelectedItem,txDataType1,");
            DefaultLines.Add("@SelectedItem,txDataType2,");
            File.WriteAllLines(DefaultDevicesFile, DefaultLines);

            _popupTestHostProject = projectName;

            //Start the popup test host
            _popupTestHostProcess = Process.Start("RA.DTC.DataItemBrowser.PopupTestHost.exe", SkipPackagerParam);
            _popupTestHostProcess.WaitForInputIdle();
        }

        /// <summary>
        /// Specify the project (VPD) to use for this unit test run
        /// If mock data sources are passed via alternate overload, it will override any value passed here
        /// </summary>
        /// <param name="VpdFileName"></param>
        protected void SetProjectFile(string VpdFileName)
        {
            _projectName = VpdFileName;
        }

        /// <summary>
        /// Specify mock data sources (which will generate an mock "XML" project file) to use for the unit test run
        /// </summary>
        /// <param name="mockDataSources">Tuple of zero or more mock data sources (DataSourceName,DataSourcePath,DataSourceType)
        /// where DataSourcePath is the file name of a L5X file in the unit test project,
        ///       DataSourceType is either "Controller" or "EOI"</param>
        protected void SetProjectFile(params Tuple<string, string, string>[] mockDataSources)
        {
            _projectName = CreateMockDataSourcesXmlFile(mockDataSources);
        }

        #region Special Test Methods (Before/After Each/All Tests)

        #region Before first test runs class init
        /// <summary>
        /// Should be called from derived classes to obtain standard UI test functionality from their respective class initialize methods
        /// </summary>
        /// <param name="testContext">Unit text context (as provided to the derived class by the framework in its class initialize method)</param>
        [ClassInitialize]
        public static void BaseClassInitialize(TestContext testContext)
        {
            //Extract VPD/L5X files stored in the assembly
            ExtractEmbeddedProjectFiles();
        }

        /// <summary>
        /// Create the serialization file which enabled grid serialization
        /// This method deletes the file if it exists already and then creates a new one.
        /// When the tests are all running together, the file could be getting deleted in another tests
        /// Cleanup method, so we try a few times to 
        /// </summary>
        public void SetupGridSerialization()
        {           
            //Create the grid serialization file to enable grid serialization            
            if (CleanUpGridSerialization())
                File.Create(_serializationFilePath);
            else
                Assert.Fail("Could not clean up GridSerialization file");

        }

        #endregion Before first test runs class init

        #region After all tests finish running class cleanup
        [ClassCleanup]
        public static void BaseClassCleanup()
        {
            //Warn/fail if we still have a open package in the popup test host.
            //If we are debugging, this is just an informational since we can only automatically close the project if we detected
            // that all tests in the unit test class were run
            if (_HasOpenedPackage)
            {
                if (System.Diagnostics.Debugger.IsAttached)
                {
                    MessageBox.Show("Not all of the tests in the current test class were run, so the open project could not be closed automatically.\n\nThe Popup Test Host Window was left open so the project could be closed manually.", "Popup Test Host Window left open...", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    Assert.Fail("Popup Test Host Window unexpectly left open as project was not closed automatically");
                }
            }
        }

        /// <summary>
        /// Delete the serialization file which will disable GridSerialization
        /// 
        /// </summary>
        public bool CleanUpGridSerialization()
        {           
            const int MAX_ATTEMPTS = 5;
            int tries = 0;
            bool deleted = false;

            //Remove the grid serialization file, this should prevent any grid serialization            
            while (!deleted && (tries < MAX_ATTEMPTS))
            {
                try
                {
                    if (File.Exists(_serializationFilePath))
                    {
                        File.Delete(_serializationFilePath);
                    }
                    //set true if file doesn't exist or was deleted 
                    deleted = true;
                }
                catch (System.IO.IOException e)
                {
                    Thread.Sleep(1000);
                    Console.WriteLine(e.Message);
                    if (e.InnerException != null)
                        Console.WriteLine(e.InnerException.Message);
                }
                tries++;
            }

            return deleted;
        }

        #endregion After all tests finish running class cleanup

        #region Before running each test
        [TestInitialize()]
        public void BaseTestInitialize()
        {
            //Make sure we obtained the path to the grid serialization file
            Assert.IsNotNull(_serializationFilePath, "Could not obtain path to grid serialization file from DataGridView class");

            //Ensure a popup test host is open pointing to the correct project
            StartPopupTestHost(_projectName);

            //Make sure the package is open
            Thread.Sleep(2000);

            // We only need to click the project open button if we are NOT using the QSP Mock
            if (!this.IsUsingQSPMock())
            {
                if (!_HasOpenedPackage || !this.BaseUIMap.DIB_PackageCloseButton_Exists())
                {
                    this.BaseUIMap.PTH_ClickOpenPackageButton();
                    _HasOpenedPackage = true;
                }
            }
        }
        #endregion

        #region After each test has run
        [TestCleanup()]
        public void BaseTestCleanup()
        {
            //Test finish running so add to the number of tests run
            _NumTestsRun += 1;

            //If we've run all the tests in this class
            if (_NumTestsRun == _TotalTestCount)
            {
                if (_HasOpenedPackage)
                {
                    // We dont need to close an open package if the QSP Mock is running
                    if (!this.IsQSPMockRunning()) this.BaseUIMap.PTH_ClickClosePackageButton();
                    _HasOpenedPackage = false;

                    //Close the window as long as we've closed the open package
                    if(_popupTestHostProcess!=null)
                        _popupTestHostProcess.CloseMainWindow();
                    
                    //Close the QSPMock
                    this.CloseQSPMockIfRunning();
                }
            }
        }

        /// <summary>
        /// some unit tests need to close the popup to start the next test
        /// e.g. DataContext tests, so that the datacontext fields will be 
        /// reset
        /// </summary>
        public void ClosePopup()
        {
            if (_HasOpenedPackage && this.BaseUIMap.DIB_PackageCloseButton_Exists())
                this.BaseUIMap.PTH_ClickClosePackageButton();

            //the package is closed
            _HasOpenedPackage = false;  
            //The open package should be closed, Close the window 
            if (_popupTestHostProcess != null)
                _popupTestHostProcess.CloseMainWindow();

            //Close the QSPMock
            this.CloseQSPMockIfRunning();
        }

        #endregion After each test has run

        #endregion Special Test Methods (Before/After Each/All Tests)

        /// <summary>
        /// Will hit the ESC key in the DIB
        /// </summary>
        protected void DIB_HitESC()
        {
            // Type '{Escape}'
            Keyboard.SendKeys(this.BaseUIMap.UIDataItemBrowserHostWWindow, "{Escape}", ModifierKeys.None);
        }

        /// <summary>
        /// Will hit the Ctrl+key in the DIB (where key is passed via the key param)
        /// </summary>
        protected void DIB_HitControlPlus(string key)
        {
            Keyboard.SendKeys(this.BaseUIMap.UIDataItemBrowserHostWWindow, key, ModifierKeys.Control);
        }

        /// <summary>
        /// Will hit the Ctrl+key in the Popup Test Host (where key is passed via the key param)
        /// </summary>
        protected void PTC_HitControlPlus(string key)
        {
            Keyboard.SendKeys(this.BaseUIMap.UICommonTagPopupTestHoWindow, key, ModifierKeys.Control);
        }

        /// <summary>
        /// Will wait for the load spinner to stop spinning
        /// </summary>
        protected void DIB_WaitForSpinnerStop()
        {
            AutomationElement.AutomationElementInformation CurrentAutomationVals;

            //Wait up to 1 second for the spinner to start (since this might have gotten called a few milliseconds before the spinner could even show itself)
            int WaitToStartMs = 0;
            bool SpinnerStarted = false;
            while (!SpinnerStarted && WaitToStartMs < 1000) //Wait 1 second for the spinner to appear
            {
                CurrentAutomationVals = ((this.BaseUIMap.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataSourcesLoadingSpCustom.NativeElement as AutomationElement).Current);
                SpinnerStarted = (CurrentAutomationVals.BoundingRectangle.IsEmpty == false);

                WaitToStartMs += 100;
                Thread.Sleep(100);
            }

            //If we detected above the spinner started, wait for the spinner to stop
            if (SpinnerStarted)
            {
                bool SpinnerStopped = false;
                while (!SpinnerStopped)
                {
                    CurrentAutomationVals = ((this.BaseUIMap.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataSourcesLoadingSpCustom.NativeElement as AutomationElement).Current);
                    SpinnerStopped = CurrentAutomationVals.BoundingRectangle.IsEmpty;

                    Thread.Sleep(500);
                }
            }
        }

        /// <summary>
        /// DataGridView content validation method for verifying the number of rows only
        /// </summary>
        /// <param name="validRows"></param>
        protected void DIB_Assert_DataGridView_Contents(int validRows)
        {
            //Make sure we got the expected serialization results
            string[] fileLines = File.ReadAllLines(_serializationFilePath);
            int gridViewRows = fileLines.Length - 1; //subtract the file header            

            Assert.IsTrue(validRows == gridViewRows, "The number of rows in the DataGridView is invalid. Expecting " + validRows + " but has " + gridViewRows);
        }

        /// <summary>
        /// DataGridView Content Validation method
        /// Validates:
        ///     - The number of rows matches validRows
        ///     - Validates that each row contains the corresponding validContent for the column specified in columnName. The List should 
        ///         contain a validContent entry for each row it expects to validate. The assertion validates that the DataGridView
        ///         value in that column for that row contains the validContent if exactMatch is set to false. If exactMatch is set to 
        ///         true then the value in that column for that row must match exactly.
        /// </summary>
        /// <param name="validRows">The number of rows that should be in the DataGridView</param>
        /// <param name="columnName">The name of the column that matches the header column string in the serialization file</param>
        /// <param name="validContent">The string that should be in the corresponding row,column of the DataGridView</param>
        /// <param name="exactMatch">Whether or not the assert should be for an exact match or just verify that the DataGrid row,column contains the valid content</param>
        protected void DIB_Assert_DataGridView_Contents(int validRows, string columnName, string validContent, bool exactMatch)
        {
            //Make sure we got the expected serialization results
            string[] fileLines = File.ReadAllLines(_serializationFilePath);
            int gridViewRows = fileLines.Length - 1; //subtract the file header            
           
            Assert.IsTrue(validRows == gridViewRows, "The number of rows in the DataGridView is invalid. Expecting " + validRows + " but has " + gridViewRows);
           
            //Get the index of the column that we want to validate
            string[] header = fileLines[0].Split(',');
            int headerIndex = -1;
            int idx = 0;
            foreach (var s in header)
            {
                string str = s.TrimStart('%');
                if (str.Equals(columnName))
                {
                    headerIndex = idx;
                    break;
                }
                idx++;
            }
                        
            for (int i = 1; i < fileLines.Length; i++)
            {                               
                string[] values = fileLines[i].Split(new string[]{"\","},StringSplitOptions.None);     
                if (exactMatch)
                    Assert.IsTrue(values[headerIndex].TrimStart('\"').Equals(validContent), "Valid Content not in the DataGrid");                
                else
                    Assert.IsTrue(values[headerIndex].ToLower().Contains(validContent.ToLower()),"Valid Content not in the DataGrid");                
            }
                
        }

        /// <summary>
        /// DataGridView Content Validation method when the default search for name and description is used, meaning no filter type was used
        /// Validates:
        ///     - The number of rows matches validRows
        ///     - Validates that each row contains the corresponding validContent for either the name column OR the description column. The assertion validates that the DataGridView
        ///         value in that column for that row contains the validContent if exactMatch is set to false. If exactMatch is set to 
        ///         true then the value in that column for that row must match exactly.
        /// </summary>
        /// <param name="validRows">The number of rows that should be in the DataGridView</param>
        /// <param name="validContent">The string that should match either the name row,column value OR the description row,column value</param>
        /// <param name="exactMatch">Whether or not the assert should be for an exact match or just verify that the DataGrid row,column contains the valid content</param>
        protected void DIB_Assert_DataGridview_NameORDescription_Contents(int validRows,string validContent,bool exactMatch)
        {
            //Make sure we got the expected serialization results
            string[] fileLines = File.ReadAllLines(_serializationFilePath);
            int gridViewRows = fileLines.Length - 1; //subtract the file header            

            Assert.IsTrue(validRows == gridViewRows, "The number of rows in the DataGridView is invalid");

            const int nameHeaderIdx = 0;
            const int descriptionHeaderIdx = 3;
            for (int i = 1; i < fileLines.Length; i++)
            {
                string[] values = fileLines[i].Split(new string[] { "\"," }, StringSplitOptions.None);
                if (exactMatch)
                {   //if it's not in the name column then check the description column
                    if(!values[nameHeaderIdx].TrimStart('\"').Equals(validContent))
                        Assert.IsTrue(values[descriptionHeaderIdx].TrimStart('\"').Equals(validContent), "Valid Content not in the DataGrid");
                }
                else
                {   //if it's not in the name column then check the description column
                    if (!values[nameHeaderIdx].ToLower().Contains(validContent.ToLower()))
                        Assert.IsTrue(values[descriptionHeaderIdx].ToLower().Contains(validContent.ToLower()), "Valid Content not in the DataGrid");
                }
            }
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;

        public UIMap BaseUIMap
        {
            get
            {
                if ((this.map == null))
                {
                    this.map = new UIMap();
                }

                return this.map;
            }
        }

        private UIMap map;
        
    }
}
