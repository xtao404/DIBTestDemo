﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.Object;

namespace TagFilterControl.Controls.PreFilterManager.FilterInsatnce
{
    public class TagFilter : BaseFilter
    {
        public override bool Apply(TagObjects tag)
        {
            this.Reason = String.Empty;
            AndOrValue preCond = AndOrValue.And;
            bool tResult = true, tResultOne = true;
            foreach (FilterUnitField fFilterOne in this.FieldFilters)
            {
                object fieldValue = GetAttributeValueFilterInformation(tag, fFilterOne);
                tResultOne = (fieldValue == null ? true : fFilterOne.Apply(fieldValue, tag));
                tResult = (preCond == AndOrValue.And) ? tResult && tResultOne : tResult || tResultOne;
                preCond = fFilterOne.Policy;
            }
            this.Reason = tResult ? String.Empty : "8b367d49_3686_46dd_ab8a_b75940586749";
            return tResult;
        }
    }

    public class FilterResult
    {
        public bool IsFiltered { get; set; }
        public string Reason { get; set; }
    }
}
