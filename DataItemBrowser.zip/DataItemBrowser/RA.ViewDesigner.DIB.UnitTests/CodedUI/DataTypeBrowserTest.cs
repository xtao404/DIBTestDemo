﻿
using System.IO;
using DataItemBrowserUT.CodedUI.UIMaps;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapClasses;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapDataTypeBrowserClasses;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapKeyBoardNavClasses;
using System;


namespace DataItemBrowserUT.CodedUI
{
    /// <summary>
    /// Summary description for 
    /// </summary>
    [CodedUITest]
    public class DataTypeBrowserTest : CodedUITestBase
    {
		/// <summary>
		/// Constructor
		/// </summary>
        public DataTypeBrowserTest()
        {
			//USE ONE OF THE CALLS TO SetProjectFile

			//Use this to call the Mock to avoid requiring the ROA stack to be running for the tests to run. This must be used to 
            //run the tests as part of the build process
            //SetProjectFile(new Tuple<string, string, string>("Controller1", "StructuresArraysBits_filter_V21", "Controller"));

			//Use this if you just want to have the tests run by development but do not want to have it run as part of the 
			//build process. All the methods must have [TestCategory("ExcludeOnAutoBuild")] so they are not run as part of the build.
            SetProjectFile("DataItemBrowserUT.CodedUI.Projects.Project12.VPD");
        }

        /// <summary>
        /// Drill into the User-Defined datatypes and verify the number of tags
        /// </summary>
        [TestMethod]
		[TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void DTB_DrillInto_UserDefinedDataTypesTest()
        {
            //ACT
           this.UIMapDataTypeBrowser.DTB_DrillInto_UserDefined();
            DIB_WaitForSpinnerStop();
            //ASSERT
            DIB_Assert_DataGridView_Contents(50);
        }

        /// <summary>
        /// Search for User-Defined DataTypes
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void DTB_Search_Test()
        {
            //ACT
            this.UIMapDataTypeBrowser.DTB_DrillInto_UserDefined();
            this.UIMapDataTypeBrowser.DTB_Search_array();
            //ASSERT
            DIB_Assert_DataGridView_Contents(15);
        }

        /// <summary>
        /// Verify KeyboardNav functions correctly in the DTB
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void DTB_KeyBoardNav_Test()
        {
            //ARRANGE ACT
            this.UIMapDataTypeBrowser.DTB_DrillInto_UserDefined();
            this.UIMapDataTypeBrowser.DTB_Search_array();
            this.UIMapDataTypeBrowser.DTB_KeyboardNav();
            //ASSERT
            DIB_Assert_DataGridView_Contents(50);
        }

        /// <summary>
        /// Verify breadcrumb navigation
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void DTB_BreadcrumbNav_Test()
        {           
            //ARRANGE ACT
            this.UIMapDataTypeBrowser.DTB_KeyboardNav_BreadCrumbContextMenu();
            this.UIMapDataTypeBrowser.DTB_BreadCrumbContext_SelectModuleDefined();
            //ASSERT
            this.UIMapKeyBoardNav.DIB_Assert_BreadCrumb_Button_Enabled("Module-Defined");
        }

        /// <summary>
        /// Verify connectString
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void DTB_ConnectString_Test()
        {
            //ARRANGE, ACT
            //close the DTB so the testinit code doesn't have to change
            UIMap.DTB_PressESC();
            this.UIMap.PTH_ClickDataTypeBrowserButton();
            //Type in the connect string and launch the DTB
            this.UIMapDataTypeBrowser.DTB_ConnectString_AddText("::controller1.AOI_1");
            this.UIMap.PTH_ClickReadTagElipsisButtonForDTB();
            DIB_WaitForSpinnerStop();

            //ASSERT
            this.UIMapDataTypeBrowser.DTB_Assert_AOI_1_Enabled();
            this.UIMapKeyBoardNav.DIB_Assert_BreadCrumb_Button_Enabled("User-Defined");

            //try special case
            //if the datatype specified in the connect string is a UDT, but the user did not prepend the controller
            // then prepend the location 
            UIMap.ClickHomeCrumbButton();
            //drill into pre-defined            
            this.UIMapDataTypeBrowser.DTB_Predefined_NavTo_Tag_Enter();            

            //type in only datatype in connectstring
            this.UIMapDataTypeBrowser.DTB_ConnectString_AddText("Level01");
            this.UIMap.PTH_ClickReadTagElipsisButtonForDTB();
            DIB_WaitForSpinnerStop();

            //ASSERT
            this.UIMapDataTypeBrowser.DTB_Assert_Level01_Enabled();
            this.UIMapKeyBoardNav.DIB_Assert_BreadCrumb_Button_Enabled("User-Defined");

        }


        #region Additional test attributes

        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            CodedUITestBase.BaseClassInitialize(testContext);
        }

        [ClassCleanup]
        public static void MyClassCleanup()
        {
            CodedUITestBase.BaseClassCleanup();
        }

        //Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void MyTestInitialize()
        {
            SetupGridSerialization();

            //Open DTB            
            this.UIMap.PTH_ClickDataTypeBrowserButton();
            //kludge to ensure that DIB opens to the datasources view and not the last hightlighted item
            this.UIMap.PTH_EnterDotInDataType1EditBox();            
            this.UIMap.PTH_ClickReadTagElipsisButtonForDTB();
            
        }

        //Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {
            CleanUpGridSerialization();

            //close DIB
            UIMap.ClickHomeCrumbButton();            
            DIB_WaitForSpinnerStop();
            UIMap.DTB_PressESC();
        }

        #endregion     

		///<summary>
		/// This is the UIMap of the CodedUITestBase
		/// Any recorded functionality that is generic enough to be used by any 
		/// coded UI test should be put in this class, to customize any of these recordings
		/// read the information at the top of this file
		///</summary>
        public UIMap UIMap
        {
            get
            {
                if ((this.map == null))
                {
                    this.map = new UIMap();
                }

                return this.map;
            }
        }

		///<summary>
		/// This is the UIMap of DataTypeBrowserTest
		/// Any recorded functionality that is specific for your 
		/// class should be put in this map file, to customize any of these recordings
		/// read the information at the top of this file
		///</summary>
        public UIMapDataTypeBrowser UIMapDataTypeBrowser
        {
            get
            {
                if ((this.DataTypeBrowserMap == null))
                {
                    this.DataTypeBrowserMap = new UIMapDataTypeBrowser();
                }
                return this.DataTypeBrowserMap;
            }
        }
        ///<summary>
        /// This is the UIMap of DataTypeBrowserTest
        /// Any recorded functionality that is specific for your 
        /// class should be put in this map file, to customize any of these recordings
        /// read the information at the top of this file
        ///</summary>
        public UIMapKeyBoardNav UIMapKeyBoardNav
        {
            get
            {
                if ((this.keyBoardNavMap == null))
                {
                    this.keyBoardNavMap = new UIMapKeyBoardNav();
                }
                return this.keyBoardNavMap;
            }
        }
        private UIMap map;
        private UIMapDataTypeBrowser DataTypeBrowserMap;
        private UIMapKeyBoardNav keyBoardNavMap;
    }
}