/*************************************************************************************
                                                                     
   ViewE SearchFilterDefinition 
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System;
using System.Globalization;
using System.Linq;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using System.Text;

namespace RockwellAutomation.UI.CommonControls
{
    /// <summary>
    /// search/filter defintion
    /// The definition 
    /// </summary>
    public class SearchFilterDefinition
    {
        #region private/protected members       
        /// <summary>
        /// filter types allowed
        /// </summary>
        private static ObservableCollection<FilterType> _filterTypes = null;
        /// <summary>
        /// search and filter statements collection property
        /// </summary>
        private Collection<ISearchStatement> _searchFilterStatements = new Collection<ISearchStatement>();
        /// <summary>
        /// filter configuration used by CDS
        /// </summary>
        private SearchFilterConfig.CreateBuilder _filterConfig = null;
        /// <summary>
        /// filter search state for the entire parser
        /// </summary>
        private FilterSearchStateEnum _filterSearchState = FilterSearchStateEnum.AlwaysSucceed;
        internal FilterSearchStateEnum FilterSearchState
        {
            get { return _filterSearchState; }
            set { _filterSearchState = value; }
        }

        #endregion private/protected member

        #region public members
        // The following Identifier and Column names are ViewE specific 
        // and are used to map between displayed column names and identifiers
        // used to reference data in storage
        public static readonly string NameIdentifier = "DisplayName";
        public static readonly string DataTypeIdentifier = "Definition.DisplayName";
        public static readonly string DescriptionIdentifier = "Description";
        public static readonly string AlternateDescriptionIdentifier = "Definition.Description";
        public static readonly string PathIdentifier = "AbsoluteName";

        public static readonly string ColumnNameString = "Name";
        public static readonly string ColumnDatatypeString = "Data Type";
        public static readonly string ColumnDescriptionString = "Description";
        public static readonly string ColumnPathString = "Path";
        public static readonly string ColumnLocationString = "Location";

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        public static ObservableCollection<FilterType> FilterTypes
        {
            get { return _filterTypes; }
            internal set { _filterTypes = value; }
        }
        public enum StatementLogic
        {
            AND = 0,
            OR = 1,
            NONE = 2
        }
        /// <summary>
        /// enumeration of the filter/search state 
        /// </summary>
        public enum FilterSearchStateEnum
        {
            UseFilter = 0,    //process filter on each DataItemBase object passed into the Parse method
            AlwaysFail = 1,   //return false for each DataItemBase object passed into the Parse method
            AlwaysSucceed = 2 //return true for each DataItemBase object passed into the Parse method
        }
        #endregion public member

        #region public properties
        private ParserToken _errorToken = null;
        /// <summary>
        /// the token with a parse error
        /// </summary>
        public ParserToken ErrorToken
        {
            get { return _errorToken; }
            set { _errorToken = value; }
        }
        #endregion public properties

        #region constructor
        /// <summary>
        /// default builder constructor
        /// </summary>
        public SearchFilterDefinition(ObservableCollection<FilterType> filterTypes)
        {
            _filterConfig = new SearchFilterConfig.CreateBuilder();
            //since filter types are static we do not want to clear the filter types for default construction
            //this can occur when the we launch with a filter, a filter definition is created by the datacontext
            //and then the SearchFilterParser creates a default search definiton with no filter types.  If the 
            //filter statement calls IsMatch the filtertypes are null.
            if (filterTypes != null)
                _filterTypes = filterTypes;
            _searchFilterStatements.Clear();
            //default 
            FilterSearchState = FilterSearchStateEnum.AlwaysSucceed;
            ErrorToken = null;
			HasNonEmptySearchValue = false;
        }
        #endregion constructor

        #region public methods

        /// <summary>
        /// This is being called by our logging framework
        /// </summary>
        public override String ToString()
        {
            Boolean hasInitializedStatements = (_searchFilterStatements.Count() > 0 ? true : false);
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine("Statements: [Count: " +
                                  (hasInitializedStatements ? "0" : _searchFilterStatements.Count().ToString(CultureInfo.CurrentCulture)) + "]");
            if (hasInitializedStatements)
            {
                strBuilder.AppendLine("\t\t(");
                foreach (ISearchStatement tItem in _searchFilterStatements)
                {
                    strBuilder.Append(tItem.ToString());
                }
                strBuilder.Append("\t\t)");
            }
            return strBuilder.ToString();
        }


        /// <summary>
        /// add a filter, this is used to construct filter statements without parsing text
        /// </summary>
        /// <param name="filterName">filter name</param>
        /// <param name="value">filter value</param>
        /// <param name="isExactMatch">is the value an exact match</param>
        /// <param name="logic">logical operator with the next statemen</param>
        public bool AddFilter(string filterName, string value, bool isExactMatch, StatementLogic logic)
        {
            if (ValidateLaunchFilterName(filterName))
            {
                Add(new FilterStatement(filterName, value, isExactMatch, logic));
                HasNonEmptySearchValue = true;
                this._filterSearchState = FilterSearchStateEnum.UseFilter;
                return true;
            }
            return false;
        }

        /// <summary>
        /// make sure this filtername is valid for launching
        /// </summary>
        /// <param name="filterName"></param>
        /// <returns></returns>
        private static bool ValidateLaunchFilterName(string filterName)
        {
            
            foreach (FilterType ft in FilterTypes)
            {
                if (ft.IsLaunchFilter)
                {
                    if (String.Compare(ft.Operator, filterName, true) == 0 || String.Compare(ft.Shortcut, filterName, true) == 0)
                        return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Returns whether or not the definition contains the passed filter type
        /// </summary>
        /// <param name="filterType">Type of filter to look for in the definition</param>
        /// <returns>True if the passed filter type is found, otherwise false</returns>
        public bool Contains(FilterType filterType)
        {
            foreach (ISearchStatement curStatement in _searchFilterStatements)
            {
                FilterStatement curFilter = curStatement as FilterStatement;
                if (curFilter != null)
                {
                    if (curFilter.FilterType.Value == filterType.Operator ||
                       curFilter.FilterType.Value == filterType.Shortcut)
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        ///<summary>
        /// add a search statement, which is used to create the query object to send to the DibQuery
        /// </summary>
        /// <param name="statement"></param>
        public void Add(ISearchStatement statement)
        {
            _searchFilterStatements.Add(statement);
            StatementLogic logic = StatementLogic.NONE;
            if (statement.OperatorToken != null)
                logic = (StatementLogic)Enum.Parse(typeof(StatementLogic), statement.OperatorToken.Value);

            FilterStatement filterStatement = statement as FilterStatement;
            if (filterStatement != null)
            {
                SearchFilterItem.CreateBuilder searchFilterItemParent = new SearchFilterItem.CreateBuilder();
                searchFilterItemParent.SetLogicOperator(logic);
                
                foreach (ParserToken filterValue in filterStatement.FilterValues)
                {
                    if (filterValue.ParseGroup == SearchFilterParser.WhiteSpaceGroup)
                        continue;

                    //update the logic value to apply to the following value parse groups
                    if (filterValue.ParseGroup == SearchFilterParser.BaseOperatorGroup)
                    {
                        logic = filterValue.Value.Equals(SearchFilterParser.OrOperator)
                                    ? StatementLogic.OR
                                    : StatementLogic.AND;
                        continue;
                    }
                    AddFilterItem(filterStatement.FilterType.Value, filterValue.Value, filterValue.ExactMatch, logic, searchFilterItemParent);
                }
                SearchFilterItem searchFilterItemParentBuilt = searchFilterItemParent.Build();
                //If there was only one item added, we dont need it to be nested.
                if (searchFilterItemParentBuilt.GetNestedItems.Count == 1) _filterConfig.AddItem(searchFilterItemParentBuilt.GetNestedItems[0]);
                //If there were multiple items added, keep them nested
                if (searchFilterItemParentBuilt.GetNestedItems.Count > 1) _filterConfig.AddItem(searchFilterItemParentBuilt);
            }
            else
            {
                SearchStatement searchStatement = statement as SearchStatement;
                if (searchStatement != null)
                    AddSearchItem(searchStatement.SearchValue.Value, searchStatement.SearchValue.ExactMatch, logic);
            }
        }

        /// <summary>
        /// get the FilterConfig used for the query request condition in the CDS
        /// </summary>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate")]
        public SearchFilterConfig GetFilterConfig()
        {
                return _filterConfig.Build();           
        }

  

        /// <summary>
        /// The string representing this query
        /// </summary>
        /// <returns></returns>        
        public string SearchString
        {
            get
            {
                string search = string.Empty;
                foreach (ISearchStatement statement in _searchFilterStatements)
                {
                    search += statement.GetSearchString() + " ";
                }
                // Remove the last space added at the end of the last statement
                if (_searchFilterStatements.Count() > 0) search = search.Remove(search.Count() - 1);
                return search;    
            }
            

        }
        /// <summary>
        /// Clear search, clears all statements and resets the search state 
        /// </summary>
        public void ClearSearch()
        {
            _searchFilterStatements.Clear();
            FilterSearchState = FilterSearchStateEnum.AlwaysSucceed;
            HasNonEmptySearchValue = false;
        }
        /// <summary>
        /// Returns true if some search/filter is currently applied
        /// </summary>
        public bool IsActive
        {
            get
            {
                //active means that we are not using an filter and that there is no error associated with it
                return FilterSearchState == FilterSearchStateEnum.UseFilter && !HasError;
            }
        }
        /// <summary>
        /// Returns true if there was a parse error
        /// </summary>
        public bool HasError
        {
            get
            {                
                return ErrorToken != null;
            }
        }
		/// <summary>
		/// Returns true if these results contain any non-empty search/filter values
		/// </summary>
		public bool HasNonEmptySearchValue { get; set; }
        /// <summary>
        /// report error state
        /// </summary>
        /// <param name="alwaysSucceed">all searchs will always succeed (i.e. no filter)</param>
        /// <param name="errorToken">token with an error</param>
        public void ReportErrorState(bool alwaysSucceed, ParserToken errorToken)
        {
            //remove all the search/filter statements because they are not necessary since we will
            //check FilterSearchState in the Apply method and return status
            _searchFilterStatements.Clear();
            _filterConfig = new SearchFilterConfig.CreateBuilder();
			HasNonEmptySearchValue = false;

            //set the error info member
            ErrorToken = errorToken;
            FilterSearchState = alwaysSucceed ? FilterSearchStateEnum.AlwaysSucceed : FilterSearchStateEnum.AlwaysFail;

        }
         /// <summary>
        /// apply the filter to a dataitem 
        /// </summary>        
        /// <param name="item">data item base object</param>
        /// <param name="getFieldValue">delegate</param>
        /// <returns>true if matches filter, false otherwise</returns>
        public bool ApplyViewFilter(Object item, GetFieldValue getFieldValue)
        {
            //short curcuit for always succeed and always fail
            if (FilterSearchState == FilterSearchStateEnum.AlwaysSucceed)
                return true;
            if (FilterSearchState == FilterSearchStateEnum.AlwaysFail)
                return false;

            bool result = false;
            bool isFirst = true;

             //evaluate each statement
            foreach (ISearchStatement curStatement in _searchFilterStatements)
            {
                string sOperator = curStatement.OperatorToken == null ? String.Empty : curStatement.OperatorToken.Value;
                //see if each statement applies to this dataitem
                if (isFirst)
                {
                    result = curStatement.IsMatch(item, getFieldValue);
                    isFirst = false;
                }
                else
                {
                    //is it an OR operator
                    if (sOperator.Equals(SearchFilterParser.OrOperator))
                        result |= curStatement.IsMatch(item, getFieldValue);
                    //is it an AND operator
                    else if (sOperator.Equals(SearchFilterParser.AndOperator))
                        result &= curStatement.IsMatch(item, getFieldValue);
                }
            }
             return result;
        }
        /// <summary>
        /// Helper to get the filter type for the passed filter name
        /// </summary>
        /// <param name="filterName">either the shortcut or full filter name</param>
        /// <returns></returns>
        public static FilterType GetFilterType(string filterName)
        {
            foreach (FilterType ft in _filterTypes)
            {
                if (String.Compare(ft.Operator, filterName, true) == 0 || String.Compare(ft.Shortcut, filterName, true) == 0)
                {
                    return ft;
                }
            }

            return null;
        }
        #endregion public methods

        #region private methods

        /// <summary>
        /// add a search condition
        /// </summary>
        /// <param name="value"></param>
        /// <param name="isExactMatch"></param>
        /// <param name="statementLogic"></param>
        /// <returns></returns>
        private void AddSearchItem(string value, bool isExactMatch, StatementLogic statementLogic)
        {
            // If we have one or more _filterTypes that are searchable, then we need to create nested SearchFilter items (SearchFilterItems that themselves contain SearchFilterItems) 
            // so that our final _filterConfig correctly specifies the order of precedence.
            // Ex. If filter type Name and Description are both searchable and we are adding a search item for the user entered string "aaa bbb", then 
            //      we want to create a filter config that looks like (n:aaa OR d:aaa) AND (n:bbb OR d:bbb). We achieve the parenthesis (order of operations) using nested SearchFilterItems.
            //      So, for the above example we would have one SearchFilterItem representing (n:aaa OR d:aaa) that would itself contain a SearchFilterItem for n:aaa and another for d:aaa.
            //      Also, we would have one SearchFilterItem representing (n:bbb OR d:bbb) that would itself contain a SearchFilterItem for n:bbb and another for d:bbb.
            SearchFilterItem.CreateBuilder searchFilterBuilder = null;
            bool existsSearchableTypes = (_filterTypes.Count(n => n.Searchable) > 0);
            if (existsSearchableTypes) searchFilterBuilder = new SearchFilterItem.CreateBuilder().SetLogicOperator(statementLogic);

            foreach (FilterType ft in _filterTypes)
            {
                if (ft.Searchable)
                {
                    AddBaseItem(ft.DisplayName, value, isExactMatchFor(ft.Name, isExactMatch), statementLogic, searchFilterBuilder);
                    statementLogic = StatementLogic.OR;
                }
            }
            // If we have nested SearchFilterItems add the nested structure to the current Filter Config
            if (searchFilterBuilder != null) _filterConfig.AddItem(searchFilterBuilder.Build());
        }

        /// <summary>
        /// add a filter condition
        /// </summary>
        /// <param name="filterName"></param>
        /// <param name="value"></param>
        /// <param name="isExactMatch"></param>
        /// <param name="statementLogic"></param>
        /// <returns></returns>
        private void AddFilterItem(string filterName, string value, bool isExactMatch, StatementLogic statementLogic, SearchFilterItem.CreateBuilder searchFilterItemBuilder = null)
        {
            FilterType ft = GetFilterType(filterName);
            AddBaseItem(ft.DisplayName, value, isExactMatchFor(ft.Name, isExactMatch), statementLogic, searchFilterItemBuilder);
        }

        /// <summary>
        /// Return the value of isExactMatch to use for the provided filter type
        /// </summary>
        /// <param name="filterType"></param>
        /// <param name="isExactMatch"></param>
        /// <returns></returns>
        private static bool isExactMatchFor(string filterType, bool isExactMatch)
        {
            //there is never an exact match search on description, so disble it
            return filterType != DescriptionIdentifier && isExactMatch;
        }


        /// <summary>
        /// Add a new search SearchFilterItem to our existing SearchFilterConfig or as a sub child of the passed in SearchFilterItem 
        /// </summary>
        /// <param name="columnName">The column identifier that we are searching for</param> 
        /// <param name="value">The string text to search for</param>
        /// <param name="isExactMatch"></param>
        /// <param name="statementLogic">the enum specifying AND, OR, etc</param>
        /// <param name="searchFilterItemBuilder">An optional paramater specifying a SearchFilterItem.CreateBuilder. If this is not null, add the newly created SearchFilterItem to it.
        /// If it null, we add the newly created SearchFilterItem to our existing filterConfig</param>
        private void AddBaseItem(string columnName, string value, bool isExactMatch, StatementLogic statementLogic, SearchFilterItem.CreateBuilder searchFilterItemBuilder = null)
        {
            char[] charsToTrim = { '\"' };
            string valueNoQuotes = value.Trim(charsToTrim);

            //Get the identifier to use for the query condition item
            string identifier = convertNameToIdentifier(columnName);

            // If we are searching for Description, we want to add an "alternate identifier" here. 
            // If the "identifier" resolves to an empty string, resolve the value using "alternate identifier". 
            // Per B-24397, the DIB business rule we want to observe here is that if we are searching on Description and the tag does not have an user explicit description set on it, 
            // use the data type description (pass through description)
            string alternateIdentifier = String.Empty;
            if (identifier.Equals(SearchFilterDefinition.DescriptionIdentifier))
            {
                alternateIdentifier = SearchFilterDefinition.AlternateDescriptionIdentifier;
            }

            // Special case for data types if search text is for exact match, or contains an array qualifier, or a number.
            // In this case we need to set the identifier to the column name and set isIdentifierColumnConfigKey
            // since the display of data types is custom to DIB (specified in ColumnsInfo.xml). 
            // Using isIdentifierColumnConfigKey is a performance slowdown in DIBQuery but is necessary because 
            // there is currently no field or value in OSGI or ResourceMessages (data returned from OSGI) that 
            // formats the data Type string as we specify in ColumnsInfo.xml.
            bool isIdentifierColumnConfigKey = shouldHaveIdentifierAsColumnConfigKeyFor(identifier, value, isExactMatch);
            if (isIdentifierColumnConfigKey)
            {
                identifier = columnName;
                isIdentifierColumnConfigKey = true;
            }
            
            HasNonEmptySearchValue = true;

            SearchFilterItem newSearchFilterItem = new SearchFilterItem.CreateBuilder()
                .SetIdentifier(identifier)
                .SetAlternateIdentifier(alternateIdentifier)
                .SetIsExactMatch(isExactMatch)
                .SetLogicOperator(statementLogic)
                .SetValue(valueNoQuotes)
                .SetIsIdentifierColumnConfigKey(isIdentifierColumnConfigKey)
                .Build();
            if (searchFilterItemBuilder == null)
                { _filterConfig.AddItem(newSearchFilterItem); }
            else
                { searchFilterItemBuilder.AddItem(newSearchFilterItem); }          
        }

        /// <summary>
        /// Determine whether a filter item should set isIdentifierColumnConfigKey to true 
        /// </summary>
        /// <param name="identifier"></param>
        /// <param name="value"></param>
        /// <param name="isExactMatch"></param>
        /// <returns></returns>
        private static bool shouldHaveIdentifierAsColumnConfigKeyFor(string identifier, string value, bool isExactMatch)
        {
            // If its not a seacrch for data type, we want isIdentifierColumnConfigKey=false
            if (identifier != SearchFilterDefinition.DataTypeIdentifier) return false;
            // If its a search by exact match set isIdentifierColumnConfigKey=true
            if (isExactMatch) return true;
            // If there exists a [, ], or comma (,) character in the value representing the user is planning on matching against 
            //array characters, set isIdentifierColumnConfigKey=true
            if (value.IndexOfAny(new char[] { '[', ']', ',' }) >= 0) return true;
            // DFCT341330 If any character is a number in the value, then we cannot determine if the user wants to search the number in the tag name or the tag array
            // dimensions. To be on the safe side here, we set sIdentifierColumnConfigKey=true
            if (value.Any(itemX=>Char.IsNumber(itemX))) return true;
            return false;
        }

        /// <summary>
        /// Convert column name to the database identifier
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns></returns>
        private static string convertNameToIdentifier(string columnName)
        {
            // The following mapping from column name to identifier is ViewE specific
            // The ColumnsInfo tag and FieldConfigItem records provide some of this 
            // mapping functionality in a more generic way but this functionality has
            // not been fully implemented
            if (string.Compare(columnName, SearchFilterDefinition.ColumnNameString) == 0)
                return NameIdentifier;
            else if (string.Compare(columnName, SearchFilterDefinition.ColumnDatatypeString) == 0)
                return DataTypeIdentifier;
            else if (string.Compare(columnName, SearchFilterDefinition.ColumnDescriptionString) == 0)
                return DescriptionIdentifier;
            else if (string.Compare(columnName, SearchFilterDefinition.ColumnPathString) == 0)
                return PathIdentifier;
            else if (string.Compare(columnName, SearchFilterDefinition.ColumnLocationString) == 0)
                return PathIdentifier;

            return columnName;
        }

        #endregion private methods
    }
}
