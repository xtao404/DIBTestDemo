﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.DIBClientManagers.DataGridViewSimple;
using TagFilterControl.UserControls;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace TagFilterControl.Controls
{
    public class FilterDIBInstance
    {
        private static FilterDIBInstance instance = new FilterDIBInstance();
        public FilterDIBInstance() { }
        public static FilterDIBInstance GetInstance()
        {
            if (instance == null)
            {
                instance = new FilterDIBInstance();
            }
            return instance;
        }

        public DIBClientManager DIBClientManager { get; set; }
        public FilterDIB _FilterDIB { get; private set; }

        public void InitializeDIBClientManager(FilterDIB filterDIB)
        {
            this._FilterDIB = filterDIB;
            filterDIB.dib.BrowserType = "tag";
            this.DIBClientManager = new DataGridViewDemo();
            this.DIBClientManager.InitializeDIBControlOnStartup(filterDIB.dib, new System.Text.StringBuilder());
            this.DIBClientManager.InitialLaunchString = "";

            filterDIB.dib.Initialize(
                this.DIBClientManager,
                "");
        }
    }
}
