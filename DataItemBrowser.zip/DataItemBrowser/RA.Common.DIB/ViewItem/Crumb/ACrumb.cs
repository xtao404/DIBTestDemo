using System.ComponentModel;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace RockwellAutomation.UI.Models
{
    /// <summary> 
    /// abstract class for a crumb, this class contains the properties that all crumbs have.
    /// </summary>
    public abstract class ACrumb:INotifyPropertyChanged
    {
        /// <summary>
        /// Does this crumb support drop arrow navigation, must be implemented in concrete classes
        /// </summary>
        public abstract bool SupportsDropArrow
        {
            get;
        }

        /// <summary>
        /// Is this the last crumb in the list?
        /// </summary>
        private bool _isLast = false;
        public bool IsLast
        {
            get { return _isLast; }
            set
            {
                if (_isLast == value)
                    return;

                _isLast = value;
                NotifyPropertyChanged("IsLast");
            }
        }

		

        #region INotifyPropertyChanged Members
        /// <summary>
        /// implements that INotifyPropertyChagned inteface method NotifyPropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
    /// <summary>
    /// crumb that has path element backing it, derived from ACrumb
    /// </summary>
    public abstract class ACrumbWithPathElement : ACrumb
    {
        /// <summary>
        /// reference to its associated path elment
        /// </summary>
        private IPathElement _pathElement = null;
        public IPathElement PathElement
        {
            get { return _pathElement; }
        }

        /// <summary>
        /// Display name property
        /// </summary>
        public string DisplayName
        {
            get { return _pathElement == null? "Home": _pathElement.DisplayName; }    
        }

        /// <summary>
        /// Is this crumb active property
        /// </summary>
        public bool IsActive
        {
            get { return  _pathElement == null? true: _pathElement.IsActive; }
        }

     

        /// <summary>
        /// is this path element a data source (i.e. Controller, Program)
        /// </summary>
        public bool IsContainer
        {
            get { return  _pathElement == null? true:_pathElement.IsContainer; }
        }


        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="pe">reference to its path element</param>
        protected ACrumbWithPathElement(IPathElement pe) 
        {
            _pathElement = pe;

            if (pe != null)
            {
                //listen for any property changes in the path element
                pe.PropertyChanged += new PropertyChangedEventHandler(pe_PropertyChanged);
            }
            // The pathElement may already have controllers attached to it, which requires us to notify UI
            DataItemPathElement dataItemPathElement = pe as DataItemPathElement;
            if ((dataItemPathElement != null) && (dataItemPathElement.IsRootType) &&( dataItemPathElement.PathList.Count > 0 ))
            {
                DisplayIcon = true;
            }
        }

        /// <summary>
        /// notifies any listeners of property changed events
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void pe_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //notify any crumb listeners of path element property changes
            if (e.PropertyName == "IsActive" ||
                e.PropertyName == "HasChildren" ||
                e.PropertyName == "DisplayName")
            {
                NotifyPropertyChanged(e.PropertyName);
            }
            else if (e.PropertyName == "PathListChanged")
            {
                DisplayIcon = true;
            }
        }
        /// <summary>
        /// Does this crumb show an icon for a data type with associated controllers
        /// </summary>
        private bool _displayIcon = false;
        public bool DisplayIcon
        {
            set
            {
                _displayIcon = value;
                NotifyPropertyChanged("DisplayIcon");
            }

            get { return _displayIcon; }
        }

        /// <summary>
        /// Does this crumb support drop arrow navigation, must be implemented in concrete classes
        /// </summary>
        public override bool SupportsDropArrow
        {
            get{return false;}
        }
        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {
            if (_pathElement != null)
                _pathElement.PropertyChanged -= new PropertyChangedEventHandler(pe_PropertyChanged);
        }
    }
}
