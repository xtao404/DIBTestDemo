﻿/* ****************************************************************************
*
*  Copyright 2011 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/
using System;
using System.Windows;
using System.Diagnostics;

namespace AvalonUnitTesting
{
    /// <summary>
    /// Helper class that creates the instances of the objects
    /// </summary>
    internal static class AvalonActivatorHelper
    {
        /// <summary>
        /// wrapps a control in a window so that it can be unit tested
        /// </summary>
        private class ControlWrapper : Window
        {
            /// <summary>
            /// constructor to wrap a control inside a window
            /// </summary>
            /// <param name="controlToWrap">The control to wrap in the window</param>
            public ControlWrapper(object controlToWrap)
            {
                Content = controlToWrap;
            }

            /// <summary>
            /// constructor to wrap a control inside a window
            /// </summary>
            /// <param name="controlToWrap">The control to wrap in the window</param>
            public ControlWrapper(Func<object> controlCreator)
            {
                _controlCreator = controlCreator;
            }

            private Func<object> _controlCreator = null;

            protected override void OnActivated(EventArgs e)
            {
                base.OnActivated(e);
                if (null != _controlCreator)
                {
                    try
                    {
                        Content = _controlCreator();
                    }
                    catch (Exception ex)
                    {
                        // Why DataBindingSource? Because it's the only one the current unit test framework listens to.
                        // Same reasoning for the Warning TraceEventType.
                        PresentationTraceSources.DataBindingSource.TraceEvent(TraceEventType.Warning, 0, ex.ToString());
                    }
                }
            }
        }

        /// <summary>
        /// Creates the instance of the Type that is passed
        /// </summary>
        /// <param name="type">The type to cretae instance of</param>
        /// <param name="parameters">The constructor parameters if any</param>
        /// <returns>An object of the specified type. if the object is not a window it will be wrapped in a window</returns>
        /// <exception cref="ArgumentNullException">The type parameter is passed as null</exception>
        internal static Window CreateInstance(Type type, params object[] parameters)
        {
            if (type == null)
                throw new ArgumentNullException("type", "Type was passed as null");

            object instance;
            if (parameters != null && parameters.Length != 0)
                instance = Activator.CreateInstance(type, parameters);
            else
                instance = Activator.CreateInstance(type);

            return VerifyObjectType(instance);
        }

        /// <summary>
        /// Checks if the object is of type window
        /// If not it creates a wrapper window
        /// </summary>
        /// <param name="instance">The instance of the object to check</param>
        /// <returns>Returns a window instance</returns>
        public static Window VerifyObjectType(object instance)
        {
            Window returnValue = instance as Window;
            //return the value if it is alread a window
            if (returnValue != null)
                return returnValue;

            //wrap the control in a window and return it
            ControlWrapper wrapper = new ControlWrapper(instance);
            return wrapper;
        }

        /// <summary>
        /// Checks if the object is of type window
        /// If not it creates a wrapper window
        /// </summary>
        /// <param name="instance">The instance of the object to check</param>
        /// <returns>Returns a window instance</returns>
        public static Func<Window> VerifyObjectType(Func<object> instance)
        {
            //wrap the control in a window and return it
            return delegate() { return new ControlWrapper(instance); };
        }
    }
}
