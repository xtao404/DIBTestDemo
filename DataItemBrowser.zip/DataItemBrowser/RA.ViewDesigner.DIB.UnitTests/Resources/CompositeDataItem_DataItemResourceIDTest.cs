﻿using RockwellAutomation.UI.Resources;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for CompositeDataItem_DataItemResourceIDTest and is intended
    ///to contain all CompositeDataItem_DataItemResourceIDTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CompositeDataItem_DataItemResourceIDTest
    {

        private static UUID dbID;
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            //55ef7db7-260b-4962-9e42-2d72ec96fc21.h2.db
            dbID = PathElementUtility.getTest_DBID_COMMON_ID();
        }
        
        //Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            dbID = null;
        }
        
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for DataItemResourceID Constructor
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void CompositeDataItem_DataItemResourceIDConstructorTest()
        {           
            //Controller1
            UUID resourceID = PathElementUtility.getTest_CONTROLLER_COMMON_ID();
            UUID resourceTypeId = TypeIdentifiers.getResourceType_Controller();
            string dataType = string.Empty; 
            string bit = string.Empty;
            CompositeDataItem.DataItemResourceID target = new CompositeDataItem.DataItemResourceID(resourceID, resourceTypeId, dataType, bit, dbID);
            ValidateConstructor(resourceID, resourceTypeId, dataType, bit, target);

            //HMIDevice
            UUID HMIDevice_resourceID = PathElementUtility.getTest_HMIDEVICE_COMMON_ID();
            UUID HMIDevice_resourceTypeId = TypeIdentifiers.ResourceType_HMIDevice;
            CompositeDataItem.DataItemResourceID targetHMIDevice = new CompositeDataItem.DataItemResourceID(HMIDevice_resourceID, HMIDevice_resourceTypeId, dataType, bit, dbID);
            ValidateConstructor(HMIDevice_resourceID, HMIDevice_resourceTypeId, dataType, bit, targetHMIDevice);

            //"BOOL_UDT_Array1"
            UUID resourceIDMember = PathElementUtility.getTest_TAG_COMMON_ID();
            UUID resourceTypeIdMember = TypeIdentifiers.ResourceType_Tag;
            string dimensionsMember = "[1]";
            string bitMember = string.Empty;
            CompositeDataItem.DataItemResourceID targetMember = new CompositeDataItem.DataItemResourceID(resourceIDMember, resourceTypeIdMember, dimensionsMember, bitMember, dbID);
            ValidateConstructor(resourceIDMember, resourceTypeIdMember, dimensionsMember, bitMember, targetMember);

            //"  8"			
            UUID resourceIDBit = PathElementUtility.getTest_DATATYPE_MEMBER_COMMON_ID();
            UUID resourceTypeIdBit = null;
            string dimensionsBit = string.Empty;
            string bitBit = " 8";
            CompositeDataItem.DataItemResourceID targetBit = new CompositeDataItem.DataItemResourceID(resourceIDBit, resourceTypeIdBit, dimensionsBit, bitBit, dbID);
            ValidateConstructor(resourceIDBit, resourceTypeIdBit, dimensionsBit, bitBit, targetBit);
            
        }

        private static void ValidateConstructor(UUID resourceID, UUID resourceTypeId, string dimensions, string bit, CompositeDataItem.DataItemResourceID target)
        {
            Assert.IsNotNull(target);              
            Assert.AreEqual(resourceID, target.ResourceID, "ValidateConstructor - ResourceID didn't match");
            Assert.AreEqual(resourceTypeId, target.ResourceTypeID, "ValidateConstructor - ResourceTypeID didn't match");
            Assert.AreEqual(dimensions, target.Dimensions, "ValidateConstructor - Dimensions didn't match");
            Assert.AreEqual(bit, target.Bit, "ValidateConstructor - Bit didn't match");
        }

        /// <summary>
        ///A test for UidToGuidString
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void UidToGuidStringTest()
        {
            //Controller1
            UUID resourceID = PathElementUtility.getTest_CONTROLLER_COMMON_ID();
            UUID resourceTypeId = TypeIdentifiers.getResourceType_Controller();
            string dimensions = string.Empty;
            string bit = string.Empty;
            CompositeDataItem.DataItemResourceID target = new CompositeDataItem.DataItemResourceID(resourceID, resourceTypeId, dimensions, bit, dbID);
            UUID id = PathElementUtility.getTest_CONTROLLER_COMMON_ID();
            string expected = target.ResourceIDString;
            string actual = ResourceBase.UidToGuidString(id);
            Assert.AreEqual(expected, actual);            
        }

        /// <summary>
        ///A test for Bit
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void BitTest()
        {
            //"  8"			
            UUID resourceIDBit = PathElementUtility.getTest_DATATYPE_MEMBER_COMMON_ID();
            UUID resourceTypeIdBit = null;
            string dimensionsBit = string.Empty;
            string bitBit = " 8";
            CompositeDataItem.DataItemResourceID target = new CompositeDataItem.DataItemResourceID(resourceIDBit, resourceTypeIdBit, dimensionsBit, bitBit, dbID); 
            string expected = " 8";
            string actual = target.Bit;
            Assert.AreEqual(expected, actual);
            
        }

        /// <summary>
        ///A test for Dimensions
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DimensionsTest()
        {
            //"BOOL_UDT_Array1"
            UUID resourceIDMember = PathElementUtility.getTest_TAG_COMMON_ID();
            UUID resourceTypeIdMember = TypeIdentifiers.ResourceType_Tag;
            string dataTypeMember = "[1]";
            string bitMember = string.Empty;
            CompositeDataItem.DataItemResourceID target = new CompositeDataItem.DataItemResourceID(resourceIDMember, resourceTypeIdMember, dataTypeMember, bitMember, dbID);
            string expected = "[1]"; 
            string actual = target.Dimensions;
            Assert.AreEqual(expected, actual);
            
        }

        /// <summary>
        ///A test for ResourceID
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ResourceIDTest()
        {
            //Controller1
            UUID resourceID = PathElementUtility.getTest_CONTROLLER_COMMON_ID();
            UUID resourceTypeId = TypeIdentifiers.getResourceType_Controller();
            string dimensions = string.Empty;
            string bit = string.Empty;

            CompositeDataItem.DataItemResourceID target = new CompositeDataItem.DataItemResourceID(resourceID, resourceTypeId, dimensions, bit, dbID);
            UUID expected = PathElementUtility.getTest_CONTROLLER_COMMON_ID();
            UUID actual = target.ResourceID;
            Assert.AreEqual(expected, actual);
            
        }

        /// <summary>
        ///A test for ResourceIDString
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ResourceIDStringTest()
        {
            //Controller1
            UUID resourceID = PathElementUtility.getTest_CONTROLLER_COMMON_ID();
            UUID resourceTypeId = TypeIdentifiers.getResourceType_Controller();
            string dimensions = string.Empty;
            string bit = string.Empty;

            CompositeDataItem.DataItemResourceID target = new CompositeDataItem.DataItemResourceID(resourceID, resourceTypeId, dimensions, bit, dbID);
            string expected = ResourceBase.UidToGuidString(resourceID);
            string actual = target.ResourceIDString;
            Assert.AreEqual(expected, actual);            
        }

        /// <summary>
        ///A test for ResourceTypeID
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ResourceTypeIDTest()
        {
            //"BOOL_UDT_Array1[0]"
            UUID resourceID = PathElementUtility.getTest_TAG_COMMON_ID();
            UUID resourceTypeId = TypeIdentifiers.ResourceType_Tag;
            string dimensions = string.Empty;
            string bit = string.Empty;
            CompositeDataItem.DataItemResourceID target = new CompositeDataItem.DataItemResourceID(resourceID, resourceTypeId, dimensions, bit, dbID); // TODO: Initialize to an appropriate value
            UUID expected = resourceTypeId;
            UUID actual = target.ResourceTypeID;
            Assert.AreEqual(expected, actual);
        }
    }
}
