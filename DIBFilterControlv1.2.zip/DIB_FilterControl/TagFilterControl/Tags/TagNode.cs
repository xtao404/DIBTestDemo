﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Common;
using TagFilterControl.Controls;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.DIBClientManagers.DataGridViewSimple;
using TagFilterControl.Utility;

namespace TagFilterControl.Tags
{
    public class TagNode : BaseNode
    {
        private Config config = Config.GetInstance();
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();

        private bool isRefresh = false;
        public bool IsRefresh
        {

            get { return isRefresh; }
            set { isRefresh = value; }
        }

        private bool expand = false;
        public bool Expand
        {

            get { return expand; }
            set { expand = value; }
        }

        private string parentName;
        public string ParentName
        {
            get { return this.parentName; }
            set
            {
                this.parentName = value;
            }
        }

        private string guid;
        public string Guid
        {
            get { return this.guid; }
            set
            {
                this.guid = value;
            }
        }

        private string name;
        public string Name
        {
            get { return this.name; }
            set
            {
                this.name = value;
                this.RaisePropertyChangedEvent(() => this.Name);
            }
        }

        private CustomCommand drillinCommand;
        public CustomCommand DrillinCommand
        {
            get
            {
                return this.drillinCommand ?? (this.drillinCommand = new CustomCommand(() =>
                {
                    if (filterDIBIn.DIBClientManager != null)
                    {
                        filterDIBIn._FilterDIB.dib.Dispatcher.BeginInvoke(new Action(() =>
                        {
                            (filterDIBIn.DIBClientManager as DataGridViewDemo).GridVM.ExecuteDrillInCommand((filterDIBIn.DIBClientManager as DataGridViewDemo).ParentDataItemBase);
                        }));
                    }
                }));
            }
        }

        private bool isChecked;
        public bool IsChecked
        {
            get { return this.isChecked; }
            set
            {
                this.isChecked = value;
                OnIsCheckedChanged(this);
                this.RaisePropertyChangedEvent(() => this.IsChecked);
            }
        }

        private bool hasChild = false;
        public bool HasChild
        {
            get { return hasChild; }
            set { hasChild = value; }
        }

        private void OnIsCheckedChanged(TagNode currentNode)
        {
            #region FilterSet
            if (currentNode.IsChecked && !config.DefaultTopNodes.Contains(currentNode.Name))
            {
                if (!string.IsNullOrEmpty(currentNode.Guid) && (xmlHelper.TagOwners.Keys.Contains(currentNode.Guid) || xmlHelper.Libs.Find(lib => lib.Guid.Equals(currentNode.Guid)) != null))
                {
                    config.ACMCustomPropertiesTagOwnersFilter[currentNode.Guid] = currentNode;
                }
                else
                {
                    config.IsCheckedTags[currentNode.Name] = currentNode;
                }
            }
            else
            {
                if (!string.IsNullOrEmpty(currentNode.Guid) && config.ACMCustomPropertiesTagOwnersFilter.Keys.Contains(currentNode.Guid))
                {
                    config.ACMCustomPropertiesTagOwnersFilter.Remove(currentNode.Guid);
                }
                else if (config.IsCheckedTags.Keys.Contains(currentNode.Name))
                {
                    config.IsCheckedTags.Remove(currentNode.Name);
                }
            } 
            #endregion

            #region TreeNodeState
            bool flag = false;
            bool _flag = false;

            if (currentNode.ParentNode != null)
            {
                foreach (var item in currentNode.ParentNode.Children)
                {
                    if (item.IsChecked)
                    {
                        flag = true;
                    }
                    else
                    {
                        _flag = true;
                    }
                }

                if (!flag)
                {
                    if (currentNode.ParentNode.IsChecked)
                    {
                        currentNode.ParentNode.IsChecked = false;
                    }
                }
                else if (!_flag)
                {
                    if (!currentNode.ParentNode.IsChecked)
                    {
                        currentNode.ParentNode.IsChecked = true;
                    }
                }
            }

            foreach (var item in currentNode.Children)
            {
                item.IsChecked = currentNode.IsChecked;
            } 
            #endregion
        }

        private bool isLoaded;
        public bool IsLoaded
        {
            get { return this.isLoaded; }
            set
            {
                this.isLoaded = value;
                this.RaisePropertyChangedEvent(() => this.IsLoaded);
            }
        }

        private bool isExpanded;
        public bool IsExpanded
        {
            get { return this.isExpanded; }
            set
            {
                this.isExpanded = value;
                this.RaisePropertyChangedEvent(() => this.IsExpanded);
            }
        }

        private bool isSelected;
        public bool IsSelected
        {
            get { return this.isSelected; }
            set
            {
                this.isSelected = value;
                this.RaisePropertyChangedEvent(() => this.IsSelected);
            }
        }

        public Types Type { get; set; }

        private ObservableCollection<TagNode> children = new ObservableCollection<TagNode>();
        public ObservableCollection<TagNode> Children
        {
            get { return children; }
            set
            {
                children = value;
                this.RaisePropertyChangedEvent(() => this.Children);
            }
        }

        public TagNode ParentNode { get; set; }
    }

    public enum Types
    {
        None,
        CoreType,
        LibraryType,
        Category,
        Libraries,
        CatalogNumber,
        Interface,
        DataMembers,
        InterfaceSelf,
        DataMemberSelf,
        CatalogNumberSelf,
        Name,
        KEYID
    }
}
