/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System;
using System.Collections.Generic;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.Resources
{
    /// <summary>
    /// represents a data item as a composite of the data items up to and including the data item of interest
    /// data item meaning any device, program, tag or property
    /// e.g.  a path of data items for bit 10  of a member of a tag member of a controller
    ///     ::controller1.tag01.member[2,3,3].member[4].10
    ///     is represented as a CompositeDataItem which is a List of DataItemResourceID objects
    ///     Each DataItemResourceID contains resourceID(or refTargetID), dimensions and bits
    ///     See DataItemResourceID
    /// </summary>
    public class CompositeDataItem
    {
        public static UUID ProjectContextUUID = null;

        private List<DataItemResourceID> _dataItemByResourceID = new List<DataItemResourceID>();
        readonly DIBViewItemBase.VisualPerspectiveEnum _browserType = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;

        /// <summary>
        /// Constructor 
        /// </summary>
        /// <param name="list">IPathElement list representing the path to the item</param>
        /// <param name="browserType">enum specifying the browser type</param>
        /// The IPathElements that make up the representation of the path
        public CompositeDataItem(List<IPathElement> list, DIBViewItemBase.VisualPerspectiveEnum browserType)
        {
            this._browserType = browserType;
            CreateDataItemResourceIDList(list);
        }

        /// <summary>
        /// Create the List of DataItemResourceID objects given the list of IPathElements
        /// </summary>
        /// <param name="list">The IPathElements that make up the path to a data item</param> 
        private void CreateDataItemResourceIDList(List<IPathElement> list)
        {            
            if (list.Count > 0)
            {
                string lastBit = string.Empty;
                UUID lastResourceID = null;
                string lastDimensions = string.Empty;
                UUID lastDbID = null;

                foreach (IPathElement element in list)
                {
 	                string dims = string.Empty;
                    string bit = string.Empty;
                    string name = string.Empty;
                    UUID resourceID = null;
                    UUID resourceTypeId = null;
                    UUID dbID = null;

                    if (element.DataItem != null)
                    {
                        name = element.DataItem.CommonName.Trim();
                        resourceTypeId = element.DataItem.GetResourceTypeAsUUID();
                    }

                    switch (_browserType)
                    {
                        case DIBViewItemBase.VisualPerspectiveEnum.TagBrowser:
                            {                                  
                                //do home path element processing since it can contain multiple dataitems
                                HomePathElement homePathElement = element as HomePathElement;
                                if (homePathElement != null && homePathElement.DataItem != null)
                                {
                                    foreach (DataItemBase dataItem in homePathElement.DataItemList)
                                    {
                                        UUID resTypeId = dataItem.GetResourceTypeAsUUID();

                                        //don't add the folders to the list
                                        if (ResourceBase.IsEqual(resTypeId, TypeIdentifiers.ResourceType_TagsAndProperties)) continue;
                                        if (ResourceBase.IsEqual(resTypeId, TypeIdentifiers.ResourceType_Programs)) continue;
                                        if (ResourceBase.IsEqual(resTypeId, TypeIdentifiers.ResourceType_DataLogs)) continue;

                                        resourceID = ResourceBase.GuidStringToId(dataItem.CommonID);

                                        //default set dbID to the project context
                                        dbID = dataItem.CommonRefTargetDBId != null ? ResourceBase.GuidStringToId(dataItem.CommonRefTargetDBId) : CompositeDataItem.ProjectContextUUID;

                                        DataItemResourceID pathDataItemResourceId = new DataItemResourceID(resourceID, resTypeId, string.Empty, string.Empty, dbID);
                                        lastResourceID = resourceID;
                                        //add to the list
                                        _dataItemByResourceID.Add(pathDataItemResourceId);
                                    }
                                }

                                //the home path element can be null
                                else  if (element.DataItem != null)
                                {
                                    //don't add the folders to the list
                                    if (ResourceBase.IsEqual(resourceTypeId, TypeIdentifiers.ResourceType_TagsAndProperties)) continue;
                                    if (ResourceBase.IsEqual(resourceTypeId, TypeIdentifiers.ResourceType_Programs)) continue;
                                    if (ResourceBase.IsEqual(resourceTypeId, TypeIdentifiers.ResourceType_DataLogs)) continue;

                                    string UUIDStr = element.DataItem.CommonID;
                                    
                                    //set the resourceID
                                    resourceID = ResourceBase.GuidStringToId(element.DataItem.CommonID);
                                    
                                    // If the name has an array index in it, this PathElement contains the index into the array
                                    int iArray = name.IndexOf(DIResource.DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER);
                                    // If it is an array remove all but array components.
                                    if (iArray >= 0)
                                    {
                                        dims = name.Substring(iArray, name.Length - iArray);
                                        //use the resourceID of the previous DataItemBase
                                        resourceID = lastResourceID;
                                        //remove last entry in the list to avoid unnecessary resourceIDs in the list
                                        _dataItemByResourceID.RemoveAt(_dataItemByResourceID.Count - 1);
                                    }
                                    else if (UUIDStr == null && MetaDataHelper.isMetaData(element.DataItem))
                                    {
                                        // MetaData reference
                                        bit = element.DataItem.CommonName;

                                        if (UUIDStr == null && lastResourceID != null)
                                        {
                                            //add the resourceID for the bit reference
                                            resourceID = lastResourceID;
                                        }

                                        dims = String.IsNullOrEmpty(dims) ? lastDimensions : dims;    
                                        //If the parent of this Metadata reference was not a bit
                                        if (String.IsNullOrEmpty(lastBit))
                                        {    
                                            //remove last entry in the list to avoid unnecessary and duplicate resourceIDs in the list
                                            _dataItemByResourceID.RemoveAt(_dataItemByResourceID.Count - 1);
                                        }
                                        else
                                        {   
                                            // Dont remove the last entry (since it was a bit) and set resourceID and dims empty since we dont want metadata items to show these
                                            resourceID = null;
                                            dims = String.Empty;
                                        }
                                    }
                                    else if (UUIDStr == null || !element.DataItem.IsStructured && !element.IsContainer && ResourceBase.GuidStringToId(UUIDStr).Equals(lastResourceID))
                                    {
                                        // Bit reference
                                        bit = element.DataItem.CommonName;

                                        if (UUIDStr == null && lastResourceID != null)
                                        {
                                            //add the resourceID for the bit reference
                                            resourceID = lastResourceID;                                           
                                        }

                                        dims = (String.IsNullOrEmpty(dims)) ? lastDimensions : dims;     
                                        //remove last entry in the list to avoid unnecessary and duplicate resourceIDs in the list
                                        _dataItemByResourceID.RemoveAt(_dataItemByResourceID.Count - 1);
                                    }
                                   
                                    //if the DBId is not set in the property bag then use the previous data item's DBId, happens for bit
                                    //if it is still null then set it to the project context
                                    dbID = (ResourceBase.GuidStringToId(element.DataItem.CommonDBId) ?? lastDbID) ??
                                           CompositeDataItem.ProjectContextUUID;

                                    // Clear out the DBID if this is a metadata reference and our parent was a bit as we dont want metadata display
                                    // to contain any extra info in the display string
                                    if (MetaDataHelper.isMetaData(element.DataItem) && !String.IsNullOrEmpty(lastBit))
                                        dbID = null;

                                    //create the DataItemResourceID and add to the list
                                    DataItemResourceID dataItemResourceId = new DataItemResourceID(resourceID, resourceTypeId, dims, bit, dbID);
                                    lastResourceID = resourceID;
                                    lastDimensions = dims;
                                    lastDbID = dbID;
                                    lastBit = bit;
                                    //add to the list
                                    _dataItemByResourceID.Add(dataItemResourceId);

                                }
                            }
                            break;
                        case DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser:
                            //do not process the home path element for the data type browser
                            if (element is HomePathElement)
                                continue;
                            if ((DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE).Equals(name) || (DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE).Equals(name) 
                                || (DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE).Equals(name))
                            {
                                continue;
                            }                           
                            else
                            {
                                if (element.DataItem != null && element.DataItem.CommonRefTargetDBId != null)                                    
                                {
                                    dbID = ResourceBase.GuidStringToId(element.DataItem.CommonRefTargetDBId);
                                }
                                else
                                {
                                    dbID = CompositeDataItem.ProjectContextUUID;
                                }
                                DataItemResourceID dataItemResourceId = new DataItemResourceID(element.ResourceId, resourceTypeId, dims, bit, dbID);

                                //add to the list
                                _dataItemByResourceID.Add(dataItemResourceId);
                            }
                            break;
                        
                    }
                }
            }
            else 
            {
                _dataItemByResourceID.Clear();
            }

        }


        public ReadOnlyCollection<DataItemResourceID> CollectionOfData
        {
            get
            {
                return new ReadOnlyCollection<DataItemResourceID>(_dataItemByResourceID);
            }
        }

        /// <summary>
        /// converts a CompositeDataItem into a full path as a string using the GPB definition
        /// which includes ResourceIDs, array dimmensions, bit specifier    
        ///  e.g.  a path of data items for bit 10  of a member of a tag member of a controller
        ///     ::controller1.tag01.member[2,3,3].member[4].CINT.10
        ///     would be returned as a string with the corresponding UUIDs
        ///     ::UUID(controller1).UUID(tag01).UUID(member)[2,3,3].UUID(member)[4].UUID(CINT).10
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            if (_dataItemByResourceID.Count ==0 || _dataItemByResourceID[0] == null) return string.Empty;
            string returnPath = String.Empty;
            string dbIDStr = string.Empty;
            
            if (_dataItemByResourceID[0].DbID != null)
            {
                dbIDStr = DIResource.DI_COMMON_RESOURCETYPE_DB_BEGIN_DELIMITER + ResourceBase.UidToGuidString(_dataItemByResourceID[0].DbID) + DIResource.DI_COMMON_RESOURCETYPE_DB_END_DELIMITER;
            }

            if (_browserType.Equals(DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser))
            {
                string delimiter = ResourceBase.IsEqual(_dataItemByResourceID[0].ResourceTypeID, TypeIdentifiers.getResourceType_Controller()) ||
                                   ResourceBase.IsEqual(_dataItemByResourceID[0].ResourceTypeID, TypeIdentifiers.ResourceType_HMIDevice) ? DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER : string.Empty;

                returnPath = dbIDStr + delimiter + _dataItemByResourceID[0].ResourceIDString;

                //TODO: currently no datatype DataItemResourceID objects will have more than one entry, this section supports multiple entries                
                //if the controller path needs to be added to the user-defined datatypes this will change
                if (_dataItemByResourceID.Count > 1)
                {
                    for (int index = 1; index < _dataItemByResourceID.Count; index++)
                    {
                        dbIDStr = ResourceBase.UidToGuidString(_dataItemByResourceID[index].DbID);
                        string name = String.Empty;
                        if (!String.IsNullOrEmpty(dbIDStr))
                        {
                            name += DIResource.DI_COMMON_RESOURCETYPE_DB_BEGIN_DELIMITER + dbIDStr + DIResource.DI_COMMON_RESOURCETYPE_DB_END_DELIMITER;
                        }
                        
                        name += _dataItemByResourceID[index].ResourceIDString;
                        
                        if (_dataItemByResourceID[index].Dimensions.Length != 0)
                        {
                            name += _dataItemByResourceID[index].Dimensions;
                        }
                        if (_dataItemByResourceID[index].Bit.Length != 0)
                        {
                            name += DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER + _dataItemByResourceID[index].Bit.Trim();
                        }

                        if (!String.IsNullOrEmpty(returnPath))
                            returnPath += DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER + name;
                        else
                            returnPath = name;
                    }
                }
            }
            else // Tag Browser
            {
                if (_dataItemByResourceID.Count > 0)
                {
                    // First Path Element must be the controller, supports the existing workflow for the tag browser.
                    returnPath = dbIDStr + DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + _dataItemByResourceID[0].ResourceIDString;
                    
                    // Process Remaining Elements
                    if (_dataItemByResourceID.Count > 1)
                    {
                        for (int index = 1; index < _dataItemByResourceID.Count; index++)
                        {
                            // if it is a program follow with program delimeter
                            if (ResourceBase.IsEqual(_dataItemByResourceID[index].ResourceTypeID, TypeIdentifiers.ResourceType_Program))
                            {
                                // add program delimiter before the program name.
                                returnPath += DIResource.DI_COMMON_RESOURCETYPE_PATH_DELIMITER + dbIDStr + _dataItemByResourceID[index].ResourceIDString;
                            }
                            // if it is a datalog follow with datalog delimeter
                            else if (ResourceBase.IsEqual(_dataItemByResourceID[index].ResourceTypeID, TypeIdentifiers.ResourceType_DataLog))
                            {
                                // add datalog delimiter before the datalog's name.
                                returnPath += DIResource.DI_COMMON_RESOURCETYPE_SYSTEM_DEFINED_PATH_DELIMITER + dbIDStr + _dataItemByResourceID[index].ResourceIDString;
                            }
                            else //use dataitem delimeter
                            {                                
                                dbIDStr = ResourceBase.UidToGuidString(_dataItemByResourceID[index].DbID);
                                string name = String.Empty;                                    
                                if (!String.IsNullOrEmpty(dbIDStr))
                                {
                                    name += DIResource.DI_COMMON_RESOURCETYPE_DB_BEGIN_DELIMITER + dbIDStr + DIResource.DI_COMMON_RESOURCETYPE_DB_END_DELIMITER;
                                }

                                name += _dataItemByResourceID[index].ResourceIDString;
                                                                
                                if (_dataItemByResourceID[index].Dimensions.Length != 0)
                                {
                                    name += _dataItemByResourceID[index].Dimensions;
                                }
                                if (_dataItemByResourceID[index].Bit.Length != 0)
                                {
                                    name += DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER + _dataItemByResourceID[index].Bit.Trim();
                                }

                                if (String.IsNullOrEmpty(returnPath))
                                    returnPath = name;   
                                else
                                {
                                    // append the current name to the return path without adding more than one delimiter
                                    if (name[0].Equals(char.Parse(DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER)))
                                        returnPath += name;
                                    else
                                        returnPath += DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER + name;
                                }
                            }
                        } //end loop through _dataItemByResourceID
                    }//end processing remaining elements
                }
            }//end else
           
            return returnPath;
        }

        /// <summary>
        /// DataItem represented by ResourceID
        /// contains UUID, array dimensions, bit
        /// </summary>
        public class DataItemResourceID
        {

            /// <summary>
            /// constructor 
            /// </summary>
            /// <param name="resourceID"></param>
            /// <param name="resourceTypeId">Used for toString in determining delimeters to display</param>
            /// <param name="dimensions"></param>
            /// <param name="bit"></param>
            /// <param name="dbID">The DBID where the resourceID can be found</param>
            public DataItemResourceID(UUID resourceID, UUID resourceTypeId, string dimensions, 
                string bit, UUID dbID)
            {
                this.ResourceID = resourceID;
                this.ResourceIDString = ResourceBase.UidToGuidString(resourceID);                
                this.ResourceTypeID = resourceTypeId;
                this.Dimensions = dimensions;
                this.Bit = bit;
                this.DbID = dbID;
            }

            public UUID ResourceID { get; internal set; }

            /// <summary>
            /// This is the guid represented as a string
            /// i.e. 91f4fd46-12f3-4d05-891c-d8e2b3a47744
            /// </summary>
            public string ResourceIDString { get; internal set; }

            /// <summary>
            /// the guid representing the resourceType 
            /// </summary>
            public UUID ResourceTypeID { get; internal set; }

            /// <summary>
            /// Format includes the array delimeters i.e. [2,1,1]
            /// </summary>
            public string Dimensions { get; internal set; }

            /// <summary>
            /// Format is the fieldValue of DIBConstants.Common.Name from the propertyBag
            /// this is the number as a string sometimes with a leading space, looks like  8
            /// </summary>
            public string Bit { get; internal set; }

            /// <summary>
            /// The database id for this dataitem
            /// </summary>
            public UUID DbID { get; internal set; }

        }//end nested class DataItemResourceID

    }//end class

    
}
