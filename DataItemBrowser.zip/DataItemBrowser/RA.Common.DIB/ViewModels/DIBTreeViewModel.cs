﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RockwellAutomation.UI.CommonControls;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.Models;
using System.Windows;
using System.ComponentModel;
using System.Windows.Input;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Logging;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query;

namespace RockwellAutomation.UI.ViewModels
{
    public class DIBTreeViewModel : DIBViewModel
    {
        #region variables/properties

        private DataItemBase _itemToHighLightAfterSettingSources = null;

        private SimpleCommand _highLightNextTreeNodeCommand = null;
        private SimpleCommand _highLightPreviousTreeNodeCommand = null;

        private IObservableCollection<IVisualBase> _dataSources;
        protected IObservableCollection<IVisualBase> DataSources
        {
            get { return _dataSources; }
        }
        protected String _dataSourceToSelect = String.Empty;

        override public bool isActive()
        {
            return _dibViewModel.DataView.IsTreeView();
        }

        /// <summary>
        /// icon width property bound to the DIBTreeView
        /// controls the width of the deviceImage 
        /// </summary>
        private Visibility _controllerIconVisibility = Visibility.Collapsed;
        public Visibility ControllerIconVisibility
        {
            get { return _controllerIconVisibility; }
            set
            {
                _controllerIconVisibility = value;
            }
        }

        /// <summary>
        ///  Get the item selected in the view
        ///  This is currently used by ViewModel Actors
        /// </summary>
        /// <returns>the selected item</returns>
        public IVisualBase SelectedItem
        {
            get { return FindSelectedItemIn(this.DataSourcesItems); }
        }


        /// <summary>
        /// find the selected item in the items collection
        /// </summary>
        /// <param name="items">items collection (visual base items)</param>
        /// <returns>the selected item</returns>
        private IVisualBase FindSelectedItemIn(IObservableCollection<IVisualBase> items)
        {
            //iterate through all the items and exit the loop if the selected item is found
            foreach (IVisualBase vb in items)
            {
                if (vb.IsSelected)
                    return vb;
                else
                {
                    IVisualBase foundItem = FindSelectedItemIn(vb.Children);
                    if (foundItem != null)
                        return foundItem;
                }
            }
            return null;
        }


        /// <summary>
        /// Collection bound to from the XAML tree control
        /// </summary>
        public IObservableCollection<IVisualBase> DataSourcesItems
        {
            get
            {
                if (DataSources == null) SetSources(null);
                return DataSources;
            }
        }
        #endregion

        #region Constructor

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">DataItemBrowser View Model</param>
        public DIBTreeViewModel(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
            _dataSources = new TSObservableCollection<IVisualBase>();
            _dibViewModel.TreeViewOCChanged += new PropertyChangedEventHandler(DataItemBrowserViewModel_TreeViewOCChanged);
        }

        #endregion Constructor

        #region DIBTreeViewItem related

        /// <summary>
        /// Create a leaf for the Data Sources View
        /// </summary>
        /// <param name="di">DataItemBase of the DIBTreeViewItem</param>
        /// <param name="visualType">VisualType of the DIBTreeViewItem</param>
        /// <param name="parent">parent of the newly created DIBTreeViewItem</param>
        /// <param name="dataSourceToSelect">The name of the datasource to set highlighted.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        protected DIBTreeViewItem CreateChildNodeVisualBase(DataItemBase di, string name, VisualType visualType, DIBTreeViewItem parent, DIBClientManager dibClientManager = null)
        {
            DIBTreeViewItem treeItem = new DIBTreeViewItem(di, name, visualType, parent, dibClientManager);
            UpdateVisualType(visualType, treeItem);
            if ((this._dataSourceToSelect != null) && (treeItem.VisualName == this._dataSourceToSelect))
                treeItem.IsSelected = true;          
            if (treeItem.IsSelected) SetHighLightedItem(treeItem);                    
            parent.Children.Add(treeItem);
            return treeItem;
        }

        private void SetHighLightedItem(DIBTreeViewItem treeItem)
        {
            _itemToHighLightAfterSettingSources = treeItem.DataItem;
            this._dibViewModel.Path.HighlightedElement = PathElementFactory.Instance().CreatePathElement(_itemToHighLightAfterSettingSources);
        }

        /// <summary>
        /// Set the Visual Type for those VisualBases that are data types
        /// </summary>
        /// <param name="item">DIBTreeViewItem to update</param>
        virtual protected void UpdateVisualType(VisualType visualType, DIBTreeViewItem item)
        {
            item.VisualType = VisualType.vtGenericType;
        }

        #endregion

        #region Commands
        
        /// <summary>
        /// Highlight the next item in the tree
        /// </summary>
        public ICommand HighLightNextTreeNodeCommand
        {
            get
            {
                if (_highLightNextTreeNodeCommand == null)
                {
                    _highLightNextTreeNodeCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {
                            DIBTreeViewItem node = x as DIBTreeViewItem;
                            if (node == null) return;

                            DIBTreeViewItem parent = node.Parent as DIBTreeViewItem;                               
                            if (parent == null) // If parent is null, then this is a root Node
                            {
                                this.HighLightNextRootNode(node); 
                                return;
                            }

                            Int32 selectedIndex = parent.Children.IndexOf(node);
                            if (selectedIndex >= (parent.Children.Count - 1))
                            { 
                                // If we already have the last child selected 
                                // then select the next sibling of the parent
                                this.HighLightNextTreeNodeCommand.Execute(parent);
                                return;
                            }
                            parent.Children[selectedIndex + 1].IsSelected = true;
                        }
                    };
                }
                return _highLightNextTreeNodeCommand;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="node"></param>
        /// <returns>Whether we highlighted a node or not</returns>
        private void HighLightNextRootNode(DIBTreeViewItem rootNode)
        {
            // If this node is selected, expanded, and last child is not selected, select the first child
            if (rootNode.IsSelected &&
                rootNode.IsExpanded && 
                rootNode.Children.Count > 0 &&
                !rootNode.Children.Last().IsSelected)
            {
                rootNode.Children.First().IsSelected = true;
                return;
            }

            // Select the next sibling
            int index = this.DataSources.IndexOf(rootNode);
            if (this.DataSources.Count > index + 1)
                this.DataSources[index + 1].IsSelected = true;
            return;
        }

        /// <summary>
        /// Highlight the previous item in the tree
        /// </summary>
        public ICommand HighLightPreviousTreeNodeCommand
        {
            get
            {
                if (_highLightPreviousTreeNodeCommand == null)
                {
                    _highLightPreviousTreeNodeCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {
                            IVisualBase node = x as IVisualBase;
                            if (node == null) return;

                            IVisualBase parent = node.Parent;
                            if (parent == null) // We are a root node
                            {
                                int index = this.DataSources.IndexOf(node);
                                if (index > 0)
                                    DIBTreeViewModel.HighLightPreviousRootNode(this.DataSources[index - 1]);
                                return;
                            }

                            if (parent.Children.Count < 1) return;
                            Int32 selectedIndex = parent.Children.IndexOf(node);
                            if (selectedIndex == 0)
                            {
                                // If we already have the first item selected and user wants to 
                                // select previous, then select the parent
                                parent.IsSelected = true;
                                return;
                            }
                            if (selectedIndex == -1) return;
                            parent.Children[selectedIndex - 1].IsSelected = true;
                        }
                    };
                }
                return _highLightPreviousTreeNodeCommand;
            }
        }

        /// <summary>
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        static private void HighLightPreviousRootNode(IVisualBase rootNode)
        {
            // If this node is selected, expanded, and last child is not selected, select the first child
            if (
                rootNode.IsExpanded &&
                rootNode.Children.Count > 0)
            {
                rootNode.Children.Last().IsSelected = true;
                return;
            }

            rootNode.IsSelected = true;
        }

        #endregion

        #region EventHandlers

        /// <summary>
        /// Handler for DataSources' OC changing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        virtual protected void DataItemBrowserViewModel_TreeViewOCChanged(object sender, PropertyChangedEventArgs e)
        {
            SelectedItemPropertyChangedEventArgs DSOCArgs = e as SelectedItemPropertyChangedEventArgs;
            if (DSOCArgs != null) SetSources(DSOCArgs.SelectedItem);
        }

        /// <summary>
        /// process the changes to the user set highlighted item
        /// </summary>
        /// <param name="highlightedDataItem">the new highlighted data item </param>
        public void ProcessUserSetHighlightedItem(DataItemBase highlightedDataItem)
        {
            //do this in a temp list so we do not get notifications when a path element is added
            List<IPathElement> tempList = Path.SelectedPath;
            
            Path.HighlightedElement = PathElementFactory.Instance().CreatePathElement(highlightedDataItem);
            //don't add a null path element
            if (highlightedDataItem != null)
                tempList.Add(Path.HighlightedElement);

            //set the value of the path to be the parent path of the actual highlighted element, the highlighted element will be passed through the
            //UserChangedHighlightedItem below
            UserSetHighlightedPath = tempList;


            // Set LastUserHighlightedItem if it has been changed
            string highlightedItem = CurrentPathStringFor(tempList);
            if (LastUserHighlightedItem != highlightedItem)
            {
                LastUserHighlightedItem = highlightedItem;

                UserChangedHighlightedItem(Path.HighlightedElement==null? null : Path.HighlightedElement.DataItem);
            }
        }

        /// <summary>
        /// Creates the DIBTreeViewItem tree containing items
        /// </summary>
        /// <param name="dataSourceToSelect">The name of the datasource to set highlighted.</param>
        virtual protected void SetSources(string dataSourceToSelect)
        {
            //make sure you clean up any previous items
            DisposeItems();
            this._dataSourceToSelect = dataSourceToSelect;

            this._itemToHighLightAfterSettingSources = null;

            // Create parent nodes (items without parentID set).
            // For each parent node, we need to find the children and create them as well
            foreach (DataItemBase nonLeafNode in _dibViewModel.DataItems)
            {
                UpdatePropertiesOnDataItemBaseIfNeeded(nonLeafNode);
                if (String.IsNullOrEmpty(nonLeafNode.GUITreeViewParentID))
                {
                    DIBTreeViewItem newParentNode = new DIBTreeViewItem(nonLeafNode, nonLeafNode.ToString(), VisualType.vtGenericType, null);
                    if (newParentNode.IsSelected) SetHighLightedItem(newParentNode);   
                    CreateChildrenFor(newParentNode);
                    //Notice we only add parent nodes to Data Sources. Children are referenced from parent node
                    DataSources.Add(newParentNode);
                }
            }

            // If none of the items we created so far are selected, by default we want to select the first node
            if (this._itemToHighLightAfterSettingSources == null && DataSources.Count > 0)
            {
                DIBTreeViewItem itemToSelect = DataSources.First() as DIBTreeViewItem;
                itemToSelect.IsSelected = true;
                this.SetHighLightedItem(itemToSelect);
            }

            this._itemToHighLightAfterSettingSources = null;
            this._dataSourceToSelect = String.Empty;
        }

        virtual protected void CreateChildrenFor(DIBTreeViewItem vbParent)
        {
            // Find children of diParent in our DataItems list and add them 
            foreach (DataItemBase diChild in _dibViewModel.DataItems)
            {
                if (diChild.GUITreeViewParentID == vbParent.DataItem.GUITreeViewID)
                { 
                    DIBTreeViewItem newItem = CreateChildNodeVisualBase(diChild, diChild.ToString(), VisualType.vtDataTypes, vbParent);
                    // Rrecursivelly call this function to add all sub children
                    this.CreateChildrenFor(newItem);
                }
            }
        }

        private static void UpdatePropertiesOnDataItemBaseIfNeeded(DataItemBase item)
        {
            //if DataItemBase does not already have a UUID on it, set it now
            //We force all instances of DataItemBase to have a UUID as its ID. The client itself can use its won ID but needs to have different property key
            if (String.IsNullOrWhiteSpace(item.CommonID))
                item.CommonID = ResourceBase.generateRandomUUIDString();

            item.IsStructured = DIBViewItemBase.BooleanValueFrom(item.GUISupportsDrillIn, item.IsStructured);
        }

        /// <summary>
        /// Set sources on the Data Type Browser and retry if we encounter known .Net framework recursive error
        // This issue surfaces only when calling the DTB from TAF using Automation
        // Microsoft was commented that this issue will be addressed in a future .net release
        /// http://social.msdn.microsoft.com/Forums/en/windowsaccessibilityandautomation/thread/6c4465e2-207c-4277-a67f-e0f55eff0110
        /// </summary>
        /// <param name="dataTypesNode"></param>
        /// <param name="currentRetry">The number of times we have alreayd tried to </param>
        protected void RetrySetSources(DIBTreeViewItem dataTypesNode, int currentRetry)
        {
            //Dont retry after 25 attempts
            if (currentRetry > 25) return;
            try
            {
                if (DataSources.Count() > 0) DisposeItems();
                DataSources.Add(dataTypesNode);
            }
            catch (System.InvalidOperationException exception)
            {
                LogWrapper.LogException("Encountered Error setting DataSources in Data Type Browser. Pass: " + currentRetry, exception);
                if (!ContainsAutomationRecursionError(exception)) return;
                RetrySetSources(dataTypesNode, currentRetry + 1);
            }
        }


 
        #endregion

        #region Startup - Shutdown

        /// <summary>
        /// dispose of all visual base items
        /// </summary>
        override protected void DisposeItems()
        {
            //dispose of all the visual base items
            foreach (DIBTreeViewItem item in this.DataSources)
            {
                item.Dispose();
                foreach (DIBTreeViewItem childItem in item.Children)
                    childItem.Dispose();
            }
            DataSources.Clear();
        }

        /// <summary>
        /// Remove event handlers
        /// </summary>
        override public void Cleanup()
        {
            base.Cleanup();
            _dibViewModel.TreeViewOCChanged -= new PropertyChangedEventHandler(DataItemBrowserViewModel_TreeViewOCChanged);
        }

        #endregion

    }
}
