﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Tags;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using TagFilterControl.Controls.PreFilterManager.Common;
using TagFilterControl.Controls.PreFilterManager.FilterInsatnce;
using System.Windows;
using TagFilterControl.LaunchIn5000.PreFilterControl;
using System.Collections.ObjectModel;

namespace TagFilterControl.DIBClientManagers
{
    public class Config
    {
        private static Config instance = new Config();
        private Config() { }
        public static Config GetInstance()
        {
            if (instance == null)
            {
                instance = new Config();
            }
            return instance;
        }

        public List<string> DefaultTopNodes = new List<string>() { "User-Defined", "Strings", "Add-On-Defined", 
            "PreDefined", "Module-Defined", "Usage", "ACM", "Catalog Number", "Interface", "DataMembers"};

        public FilterManager FilterManager { get; set; }

        private bool validFlag = true;
        public bool ValidFlag
        {
            get { return validFlag; }
            set { validFlag = value; }
        }

        public string Usage { get; set; }

        public Action<string> ConditionContentAction { get; set; }

        public Action SaveCommandAction { get; set; }

        public Action ConvertDIBManagerPageAction { get; set; }

        private bool isFirstToFilterDIBControl = false;
        public bool IsFirstToFilterDIBControl
        {
            get { return isFirstToFilterDIBControl; }
            set { isFirstToFilterDIBControl = value; }
        }

        private bool isRefreshed = false;
        public bool IsRefreshed
        {
            get { return isRefreshed; }
            set { isRefreshed = value; }
        }

        private PreFilterDIBItem currentSelectItem;
        public PreFilterDIBItem CurrentSelectItem
        {
            get { return this.currentSelectItem; }
            set
            {
                this.currentSelectItem = value;
            }
        }

        private ObservableCollection<PreFilterDIBItem> filterItems = new ObservableCollection<PreFilterDIBItem>();
        public ObservableCollection<PreFilterDIBItem> FilterItems
        {
            get
            {
                return this.filterItems;
            }
            set
            {
                this.filterItems = value;
            }
        }

        public List<FilterUnitField> fieldFilters = new List<FilterUnitField>();
        public List<FilterUnitField> FieldFilters
        {
            get { return fieldFilters; }
            set { fieldFilters = value; }
        }

        private FilterProfile selectFilterProfile;
        public FilterProfile SelectFilterProfile
        {
            get { return selectFilterProfile; }
            set { this.selectFilterProfile = value; }
        }

        private List<FilterProfile> filterItem = new List<FilterProfile>();
        public List<FilterProfile> FilterItem
        {
            get { return filterItem; }
            set { filterItem = value; }
        }

        private Dictionary<string, TagNode> isCheckedTags = new Dictionary<string, TagNode>();
        public Dictionary<string, TagNode> IsCheckedTags
        {
            get { return isCheckedTags; }
            set { isCheckedTags = value; }
        }

        private Dictionary<string, TagNode> acmCustomPropertiesTagOwnersFilter = new Dictionary<string, TagNode>();
        public Dictionary<string, TagNode> ACMCustomPropertiesTagOwnersFilter
        {
            get { return acmCustomPropertiesTagOwnersFilter; }
            set { acmCustomPropertiesTagOwnersFilter = value; }
        }
    }
}
