/*************************************************************************************
                                                                     
   ViewE FilterType class                                                                     
   Copyright � 2009-2016 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RockwellAutomation.UI.CommonControls
{
    /// <summary>
    /// filter type class (i.e. name, datatype etc)
    /// this will accept filter type name and generate a filter type operator
    /// these filter types will be passed to the search filter parser to identify allowable filter types
    /// </summary>
    public class FilterType
    {
        /// <summary>
        /// constructor
        /// </summary>
        public FilterType(string name, bool searchable)
            : this(name, searchable, false)
        {
        }

        /// <summary>
        /// viewe constructor
        /// </summary>
        public FilterType(string name, bool searchable, bool launchFilter)
            : this(name, name, name.ToLower(), searchable, launchFilter)
        {
            IsGenericDIB = false;
        }

        /// <summary>
        /// generic dib constructor
        /// </summary>
        public FilterType(string name, string displayName, bool searchable, bool launchFilter)
            : this(name, displayName, displayName, searchable, launchFilter)
        {
            IsGenericDIB = true;
        }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="name">filter name</param>
        /// <param name="displayName">GUI display string</param>
        /// <param name="operatorName">text displayed in the search filter edit box (will have spaces removed and colon added</param>
        /// <param name="searchable">filter type is searchable</param>
        /// <param name="launchFilter">filter type is valid when launching the DIB</param>
        private FilterType(string name, string displayName, string operatorName, bool searchable, bool launchFilter)
        {
            Name = name;
            DisplayName = displayName;
            //remove spaces in DisplayName and append delimiter
            // this is done because if the spaces were left in the search string, the search edit box could be confusing to the user
            // as it is unclear if the word is part of the search filter text or is it a filter on its own.
            Operator = operatorName.Replace(" ", string.Empty) + SearchFilterParser.FilterOperatorDelimiter;
            Searchable = searchable;
            IsLaunchFilter = launchFilter;

            //B-12775: Add a shortcut operator that is calculate based on 
            //the first letter(s) of the displayed text
            //name: = n:  datatype: = dt:  description: = d:
            string[] words = displayName.Split(' ');
            string firstLetters = string.Empty;
            foreach (string word in words)
            {
                firstLetters += word[0];
            }
            Shortcut = firstLetters.ToLower() + SearchFilterParser.FilterOperatorDelimiter;
        }

        /// <summary>
        /// type name property (same as the filter type passed into the constructor)
        /// </summary>
        private string _name = string.Empty;
        public string Name
        {
            get { return _name; }
            internal set { _name = value; }
        }
        /// <summary>
        /// type token property (used by the parser to identify a filter type operators)
        /// </summary>
        private string _operator = string.Empty;
        public string Operator
        {
            get { return _operator; }
            internal set { _operator = value; }
        }
        /// <summary>
        /// type shortcut property (used by the parser to identify a short hand version of filter type operators)
        /// </summary>
        private string _shortcut = string.Empty;
        //B-12775: Add a property to store the Shortcut value
        public string Shortcut
        {
            get { return _shortcut; }
            internal set { _shortcut = value; }
        }
        /// <summary>
        /// display name property (bound to the filter builder button the menu item)
        /// </summary>
        private string _displayName = String.Empty;
        public string DisplayName
        {
            get { return _displayName; }
            internal set { _displayName = value; }
        }

        /// <summary>
        /// whether or not the filter type is searchable
        /// </summary>
        public bool Searchable { get; set; }
        /// <summary>
        /// whether or not the filter type is valid when launching the DIB
        /// </summary>
        public bool IsLaunchFilter { get; set; }
        /// <summary>
        /// whether or not the filter is being used by the ViewE or generic DIB
        /// </summary>
        public bool IsGenericDIB { get; set; }
    }
}
