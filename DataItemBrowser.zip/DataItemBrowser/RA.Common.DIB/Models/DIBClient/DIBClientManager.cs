﻿using System;
using System.Collections.Generic;
using System.Text;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Views;
using System.Collections.ObjectModel;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query;


namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    abstract public class DIBClientManager
    {
        #region variables/properties

        private string _initialLaunchString;
        /// <summary>
        /// Launch string that was used to open the DIB
        /// </summary>
        public string InitialLaunchString
        {
            get { return _initialLaunchString; }
            set { _initialLaunchString = value; }
        }

        #endregion

        #region Startup/Shutdown

        /// <summary>
        /// Perform any initialization work needed when the DIB control is being launched
        /// </summary>
        /// <param name="dataItemBrowserControl"></param>
        /// <param name="logger"></param>
        virtual public void InitializeDIBControlOnStartup(DataItemBrowser dataItemBrowserControl, StringBuilder logger)
        {
            //Set or update any variables on Browser Control is needed right before launching DIB Window
            logger.AppendLine("DIB Client Manager Type: " + this.GetType().ToString());
        }

        /// <summary>
        /// MRU (Most Recently Used) list history is the list of previous searches that have been performed on the DIB.
        /// When the DIB is relaunched without being cleared (That is call Close() instead of Shutdown()) the MRU list 
        /// is persisted by defualt between DIB invocations if this method returns a false value.
        /// </summary>
        virtual public bool ShouldClearMRUListHistoryOnStartup()
        {
            return true;
        }

        /// <summary>
        /// How we specify the meta data that represents what columns to show in the grid. 
        /// This is an IO Stream so clients don't have to specify contents as a file but could just have a string to represent this
        /// </summary>
        /// <returns>A stream or null</returns>
        virtual public System.IO.Stream GetGridColumnMetaData()
        {
            return null;
        }

        /// <summary>
        /// This instance of the DIB window is closing. 
        /// Cached data or connections can be kept in anticipation of DIB opening again.
        /// </summary>
        virtual public void Close()
        {
            InitialLaunchString = null;
        }

        /// <summary>
        /// This instance of the DIB window is closing and we do not anticipate it opening again. 
        /// Subclasses should call this base method when overriding. This is a good time to clear any cached data or connections as well
        /// </summary>
        virtual public void Shutdown()
        {
            this.Close();
            DataItemBrowserViewModel.ClearLastHighlightedItemWithoutNotify();
            DataItemBrowserViewModel.ClearSearchMRUListHistories();
            DIBGridViewAutomationManager.HasInitializedStaticData = false;
        }

        /// <summary>
        /// This is code that runs during the creation of a GUI item that will be used to display data in any of the views
        /// </summary>
        /// <param name="dataItem"></param>
        /// <param name="type"></param>
        /// <param name="visualBase"></param>
        virtual public void InitializeGUIViewItem(DataItemBase dataItem, VisualType type, DIBTreeViewItem visualBase)
        {
            if (dataItem == null) return;
            visualBase.InitializeWithDefaultValues();
        }

        /// <summary>
        /// This feature is not currently available or supported.
        /// DIBQuery is a generic framework that can be used to query data from any data source.
        /// </summary>
        /// <param name="cds"></param>
        /// <param name="initializeErrorString"></param>
        /// <param name="IsReinit"></param>
        /// <returns></returns>
        virtual public bool InitializeDIBQueryConnection(IClientDataServices cds, ref String initializeErrorString, bool IsReinit)
        {
            return true;
        }

        #endregion

        #region Search
        
        /// <summary>
        /// Create default values used for search filter control
        /// </summary>
        /// <returns></returns>
        virtual public ObservableCollection<CommonControls.FilterType> GetFilterTypes()
        {
            ObservableCollection<CommonControls.FilterType> filterTypes = new ObservableCollection<CommonControls.FilterType>();
            filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.Name, true, false));
            filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.Description, true, false));
            return filterTypes;
        }

        /// <summary>
        /// Default value for search is to do nothing. Let subclasses implement this
        /// </summary>
        /// <param name="queryConditionConfig"></param>
        /// <param name="dibQueryCache"></param>
        virtual public void SearchFor(Client.Services.Query.QueryConditionConfig queryConditionConfig, DIBQueryCache dibQueryCache)
        {
            return;
        }

        /// <summary>
        /// Represents whether or not searching is performed with a back end query or by filtering the data that is already visible and displayed
        /// </summary>
        /// <returns>Wether we should perform searches with queries or filtering the items that are visible and displayed</returns>
        /// <param name="path">The current Path object holding a reference to an ordered list of DataItemBase instances representing navigation choices the user has made so far.
        /// The reason this is used as a patamater is that the current location might be used to help determine if seatching at this location should be done by query or not</param>
        virtual public bool ShouldSearchViaQuery(RockwellAutomation.UI.Models.Path path)
        {
            return false;
        }

        /// <summary>
        /// Represents the time span the search filter control should wait after each text change event before automatically
        /// searching for the input text
        /// </summary>
        public TimeSpan CustomAutoSearchTimerDelay { get; set; }

        #endregion

        #region View Creation

        /// <summary>
        /// Clients get opportunity to create their own view model classes (as subclasses of our view model classes) 
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        virtual public DIBListViewModel createDIBListViewModel(DataItemBrowserViewModel dibVM)
        {
            return new DIBListViewModel(dibVM);
        }

        /// <summary>
        /// Clients get opportunity to create their own view model classes (as subclasses of our view model classes) 
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        virtual public DIBTreeViewModel createDIBTreeViewModel(DataItemBrowserViewModel dibVM)
        {
            return new DIBTreeViewModel(dibVM);
        }

        /// <summary>
        /// Clients get opportunity to create their own view model classes (as subclasses of our view model classes) 
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        virtual public DIBGridViewModel createDIBGridViewModel(DataItemBrowserViewModel dibVM)
        {
            return new DIBGridViewModel(dibVM);
        }

        /// <summary>
        /// Clients get opportunity to create their own view model classes (as subclasses of our view model classes) 
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        virtual public DIBWebViewModel createDIBWebViewModel(DataItemBrowserViewModel dibVM)
        {
            return new DIBWebViewModel(dibVM);
        }

        #endregion

        #region Path Functionality

        /// <summary>
        /// Overidable method to convert a Path (a List of DataItemBase instances) to a string. 
        /// Clients who override this method will display their own results strings when an item is selected in the DIB
        /// </summary>
        /// <param name="fullPath"></param>
        /// <param name="nameToSelect"></param>
        /// <param name="browserPerspective"></param>
        /// <returns></returns>
        virtual public string PathToString(List<IPathElement> fullPath, string nameToSelect, DIBViewItemBase.VisualPerspectiveEnum browserPerspective)
        {
            // Let subclasses overide this custom logic for string representation of 
            // Path (Collection of ordered DataItembase instances representing Path user has navigated to)
            // This implementation will make path look something like: \\FirstItem\SecondItem\Thirditem
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("\\");
            foreach (IPathElement pathElement in fullPath)
            {
                if (pathElement!= null && pathElement.DataItem != null)
                    stringBuilder.Append("\\" + pathElement.DataItem.ToString());
            }
            return stringBuilder.ToString();
        }

        #endregion

        #region Query Functionality

        /// <summary>
        /// Ask if this Client Manager is ready to receive drill-in or search requests. 
        /// If not, this client manager will receive reinitialize events and then drill in or search requests
        /// </summary>
        /// <returns>Wether or not this instance of ClientManager is ready to receive drill in or search requests</returns>
        virtual public bool IsReadyForNavigationRequests()
        {
            return true;
        }

        /// <summary>
        /// Used by hooks into system to know whether or not view is being used. 
        //  This method will be deleted once we move all viewe functionality to DIBClientManagerForViewe as we will not need to ask this question but 
        //  forward requests to DIBClientManagerForViewe
        /// </summary>
        /// <returns>Wether or not w are using Generic DIB</returns>
        virtual public bool IsGenericDIBBrowser()
        {
            return true;
        }

        /// <summary>
        /// <para>Each item in the returned list will call the host's <c>DrillInFor</c> method to perform the drill-in, 
        /// populate the breadcrumb trail and select the last entry.</para>
        /// </summary>
        /// <param name="path">string to be broken into path parts</param>
        /// <returns>list of parts</returns>
        virtual public List<DataItemBase> GetDataItemsFromPath(string path)
        {
            return null;
        }
		
        /// <summary>
        /// Users of the DIB can override this method and are given the opportunity to populate the breadcrumbs.
        /// </summary>
        /// <param name="breadcrumbPath">The breadcrumb element list to add additional elements.</param>
        virtual public void PopulatePathWithInitialItemsBeforeHomeLaunch(RockwellAutomation.UI.Models.Path breadcrumbPath, RockwellAutomation.UI.DIBQuery.DIBQueryCache cache)
        {

        }

        public enum DIBCachingMode
        {
            DefaultCachingMode = 0,
            CachingAlwaysEnabled,
            CachingAlwaysDisabled
        }

        /// <summary>
        /// Override to set the caching mode.
        /// <remarks>
        /// Users of the generic DIB may want to disable the automatic caching for the breadcrumbs which is useful for users that
        /// populate the breadcrumbs and the breadcrumb cache using PopulatePathWithInitialItemsBeforeHomeLaunch override.  If the caching is not set
        /// to CachingAlwaysDisabled, the initial load will automatically (re)cache the root entry so any custom cache values previously loaded will be 
        /// overwritten.
        /// </remarks>
        /// </summary>
        /// <returns></returns>
        virtual public DIBCachingMode BreadcrumbCachingMode()
        {
            return DIBCachingMode.DefaultCachingMode;
        }

        /// <summary>
        /// By default this method is called on views first, and if overridden there, called here on DIBClientManager
        /// When this method is called, clients are expected to add instances of DataItemBase to the provided queryCache
        /// </summary>
        /// <param name="dataItemToDrillInto">The DataItemBase we are drilling into</param>
        /// <param name="queryCache">The instance of dib cache to add items to</param>
        abstract public void DrillInFor(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache);

        /// <summary>
        /// Retrieve a unique string from the provided DataItemBase that represents a cache key we use
        /// to store breadcrumb history. The returned string is used to allow breadcrumbs to show alternate values for 
        /// previous levels of drill ins. 
        /// </summary>
        /// <param name="dataItem"></param>
        /// <returns></returns>
        virtual public string GetBreadCrumbCacheKeyFor(DataItemBase dataItem)
        {
            if (dataItem == null) return string.Empty;
            return dataItem.CommonName;
        }

        /// <summary>
        /// This method informs the DIB what column(s) to use for the current view.
        /// Clients should override this method and determine what column view to use based on the provided DataItemBase instance.
        /// </summary>
        /// <param name="dataItem">The DataItemBase to use to determine what column config we should display</param>
        /// <returns>Return a string representing a key in the column config XML.
        /// The key is located in the column XML at <ColumnsInfo><View Context="KeyNAME"></returns>
        virtual public string GetResourceTypeString(DataItemBase dataItem)
        {
            return DIResource.DI_COMMON_RESOURCETYPE_NONE;
        }

        /// <summary>
        /// Return the DataViewType for the resource type string.
        /// Note that the paramater 'resourceType' is the same string that was returned from 'DIBClientManager.GetResourceTypeString(DataItemBase dataItem)'
        /// </summary>
        /// <param name="resourceType">The resource type</param>
        /// <returns>A sublclass of DIBDataView that represents the current view we are viewing</returns>
        virtual public IDIBDataViewType GetDataViewTypeFor(string resourceType)
        {
            return new DIBDataViewTypeTreeView();
        }

        /// <summary>
        /// Before a drill in is performed we create an instance of an IDIBQueryCommand. 
        /// Most clients should not override this method as it bypasses normal query behaviour.
        /// </summary>
        /// <param name="queryBuilder"></param>
        /// <param name="isDIBSearching"></param>
        /// <returns></returns>
        virtual public IDIBQueryCommand createQueryCommandFor(QueryRequest.CreateBuilder queryBuilder, bool isDIBSearching = false)
        {
            return DIBQueryCommand.CreateFor(queryBuilder, isDIBSearching);
        }

        #endregion

        #region Gui Behavior

        /// <summary>
        /// Wether or not browser selection also closes browser window. 
        /// This is true by default. Allow clients to override. 
        /// Setting this to false will allow clients to select more than one item at a time using the DIB
        /// </summary>
        /// <returns>Wether or not to close the DIB window when an item is selected</returns>
        virtual public bool ShouldCloseOnSelect()
        {
            return true;
        }

        #endregion

        #region "Error Handling"

        /// <summary>
        /// If needed look at the exception and any inner exceptions to determine if we care about this error and wether we want to do anything about it
        /// </summary>      
        /// <param name="exception">The error string used in the GUI for the passed exception</param>
        virtual public string ProcessExceptionErrorResponse(Exception exception, IClientDataServices cds)
        {
            return exception.ToString();
        }

        #endregion

    }
}
