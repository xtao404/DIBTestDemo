﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using TagFilterControl.Common;
using TagFilterControl.Common.Controls;
using TagFilterControl.Controls.PreFilterManager.Common;
using TagFilterControl.Controls.PreFilterManager.FilterInsatnce;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Service;
using TagFilterControl.UserControls;

namespace TagFilterControl.Controls
{
    public class PreFilterDIBManagerViewModel : BaseViewModel
    {
        private Config config = Config.GetInstance();
        public PreFilterDIBManagerViewModel()
        {
            ServiceInvoker<ITagService>
               .Invoke(s => s.QueryFilterItems())
               .Callback(result =>
               {
                   this.FilterItems = new ObservableCollection<PreFilterDIBItem>((from item in result.QueryList select new PreFilterDIBItem(item)));
                   this.RegisterItemCheckEvent();
               })
               .Finally(() => { })
               .Execute();
        }


        private bool isCheckedAll;
        public bool IsCheckedAll
        {
            get { return this.isCheckedAll; }
            set
            {
                this.isCheckedAll = value;
                foreach (var item in this.FilterItems)
                {
                    item.IsChecked = value;
                }
                this.RaisePropertyChangedEvent(() => this.IsCheckedAll);
            }
        }

        protected void RaiseIsCheckedAll(bool uncheck)
        {
            if (uncheck)
            {
                this.isCheckedAll = false;
            }
            else
            {
                this.isCheckedAll = this.FilterItems.All(i => i.IsChecked);
            }
            this.RaisePropertyChangedEvent(() => IsCheckedAll);
        }
        protected void RegisterItemCheckEvent()
        {
            foreach (var item in this.FilterItems)
            {
                item.IsCheckedChanged += (@checked) =>
                {
                    this.EditCommand.RaiseCanExecuteChanged();
                    this.DeleteCommand.RaiseCanExecuteChanged();
                    this.RaiseIsCheckedAll(!@checked);
                };
            }
        }

        private ObservableCollection<PreFilterDIBItem> filterItems = new ObservableCollection<PreFilterDIBItem>();
        public ObservableCollection<PreFilterDIBItem> FilterItems
        {
            get { return this.filterItems; }
            set
            {
                this.filterItems = value;
                this.RaisePropertyChangedEvent(() => this.FilterItems);
            }
        }

        private PreFilterDIBItem currentSelectItem;
        public PreFilterDIBItem CurrentSelectItem
        {
            get { return this.currentSelectItem; }
            set
            {
                this.currentSelectItem = value;
                this.RaisePropertyChangedEvent(() => this.CurrentSelectItem);
            }
        }

        public IEnumerable<PreFilterDIBItem> SelectedItems
        {
            get
            {
                return this.FilterItems.Where(i => i.IsChecked);
            }
        }

        private bool canEditExecute;
        public bool CanEditExecute
        {
            get { return canEditExecute; }
            set
            {
                this.canEditExecute = value;
                this.RaisePropertyChangedEvent(() => this.CanEditExecute);
            }
        }

        private bool canDeleteExecute;
        public bool CanDeleteExecute
        {
            get { return canDeleteExecute; }
            set
            {
                this.canDeleteExecute = value;
                this.RaisePropertyChangedEvent(() => this.CanDeleteExecute);
            }
        }

        public ICommand CreateCommand
        {
            get
            {
                return new CustomCommand(
                    () =>
                    {
                        PopupController.Open<PreConfigFilterDIB>(default(FilterProfile));
                    });
            }
        }

        private CustomCommand editCommand;
        public CustomCommand EditCommand
        {
            get
            {
                return this.editCommand ?? (this.editCommand = new CustomCommand(
                    () =>
                    {
                        PreFilterDIBItem selectItem = this.CurrentSelectItem;
                        if (selectItem == null)
                        {
                            selectItem = this.FilterItems.FirstOrDefault();
                        }
                        PopupController.Open<PreConfigFilterDIB>(selectItem.Profile);
                    }));
            }
        }

        private CustomCommand deleteCommand;
        public CustomCommand DeleteCommand
        {
            get
            {
                return this.deleteCommand ?? (this.deleteCommand = new CustomCommand(() =>
                {
                    PreFilterDIBItem selectItem = this.CurrentSelectItem;
                    if (selectItem == null)
                    {
                        selectItem = this.FilterItems.FirstOrDefault();
                    }

                    this.FilterItems.Remove(selectItem);
                }));
            }
        }

        public CustomCommand SelectCommand
        {
            get
            {
                return new CustomCommand(() =>
                {
                    config.IsFirstToFilterDIBControl = true;
                    FilterAction();
                    if(config.SelectFilterProfile!=null)
                    config.ConditionContentAction(config.SelectFilterProfile.Content);
                    PopupController.Close();
                });
            }
        }

        private void FilterAction()
        {
            PreFilterDIBItem selectItem = this.CurrentSelectItem;
            if (selectItem == null)
            {
                selectItem = this.FilterItems.FirstOrDefault();
            }

            if (selectItem != null)
            {
                var profile = new FilterProfile()
                {
                    ID = selectItem.Profile.ID,
                    Name = selectItem.Profile.Name,
                    Content = selectItem.Profile.Content,
                    FilterContent = selectItem.Profile.FilterContent
                };

                config.SelectFilterProfile = profile;
            }
        }

        public CustomCommand CancelCommand
        {
            get
            {
                return new CustomCommand(() =>
                {
                    PopupController.Close();
                });
            }
        }
    }

    public class PreFilterDIBItem : BaseViewModel
    {
        public PreFilterDIBItem() { }

        private FilterProfile profile;
        public PreFilterDIBItem(FilterProfile profile)
        {
            this.profile = profile;
        }

        public FilterProfile Profile { get { return this.profile; } }

        public string ProfileId
        {
            get { return this.profile.ID; }
        }


        private string filterName;
        public string FilterName
        {
            get { return this.profile.Name; }
            set
            {
                filterName = value;
                this.RaisePropertyChangedEvent(() => this.FilterName);
            }
        }

        private string contentDetail;
        public string ContentDetail
        {
            get { return this.profile.Content; }
            set
            {
                contentDetail = value;
                this.RaisePropertyChangedEvent(() => this.ContentDetail);
            }
        }

        private bool isChecked;
        public bool IsChecked
        {
            get
            {
                return this.isChecked;
            }
            set
            {
                this.isChecked = value;
                this.IsCheckedChanged.Execute(value);
                this.RaisePropertyChangedEvent(() => this.IsChecked);
            }
        }

        private CustomCommand<bool> checkCommand;
        public CustomCommand<bool> CheckCommand
        {
            get
            {
                return this.checkCommand ?? (this.checkCommand = new CustomCommand<bool>(isChecked =>
                {
                    IsChecked = isChecked;
                }));
            }
        }

        public event Action<bool> IsCheckedChanged;
    }

}
