﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TagFilterControl.Controls.PreFilter
{
    /// <summary>
    /// Interaction logic for ConfigFilterDIB.xaml
    /// </summary>
    public partial class ConfigFilterDIB : UserControl
    {
        public ConfigFilterDIB()
        {
            InitializeComponent();
        }

        private void LayoutRoot_Loaded_1(object sender, RoutedEventArgs e)
        {

        }

        private void CategoryComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void CategoryHyperLink_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void ConditionComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void DeleteButton_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void FilterDataGrid_Loaded_1(object sender, RoutedEventArgs e)
        {

        }

        private void Save_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Cancel_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void RuleComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void AndOrValueComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }

        private void RuleComboBox_Loaded_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
