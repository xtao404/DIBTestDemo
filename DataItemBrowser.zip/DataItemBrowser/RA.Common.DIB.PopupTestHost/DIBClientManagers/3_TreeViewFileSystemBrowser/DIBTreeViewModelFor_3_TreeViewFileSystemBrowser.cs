
#region references

using System.Windows.Input;
using System.ComponentModel;
using System;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.Models;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.Common;


#endregion

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// View model supporting the <c>DIBTreeView</c>
    /// </summary>
    public class DIBTreeViewModelFor_3_TreeViewFileSystemBrowser : DIBTreeViewModel
    {
        #region "Constructor"

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">DataItemBrowser View Model</param>
        public DIBTreeViewModelFor_3_TreeViewFileSystemBrowser(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
        }

        #endregion

        #region Event Handlers

        /// <summary>
        /// mouse double click selection method
        /// </summary>
        /// <param name="selectedNameDIB"></param>
        override public void DoubleClickSelection(DataItemBase selectedNameDIB)
        {
            if (selectedNameDIB.CommonDataType == "File")
                System.Diagnostics.Process.Start(selectedNameDIB.CommonLocation);

            base.DoubleClickSelection(selectedNameDIB);
        }


        #endregion Event Handlers

    }
}
