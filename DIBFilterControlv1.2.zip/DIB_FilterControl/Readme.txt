Launch TagFilterControl from Studio 5000
1. The ACD file which you want launch in Studio 5000 must be in TagFilterControl debug path
2. You need to change the ACMplugin.xml file
   (C:\Program Files (x86)\Rockwell Software\Studio 5000\Plug-ins\V28\CustomProperties)
   Change the "Location" node like the following:
   <Location>C:\Users\N0479229\Documents\Visual Studio 2012\Projects\DIB_FilterControl\TagFilterControl\bin\Debug\TagFilterControl.dll</Location>