/*************************************************************************************
                                                                     
   ViewE DataItemBrowser.xaml Class                                                                     
   Copyright � 2009-2016 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using RockwellAutomation.UI.CommonControls.ViewModels;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.Resources;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Models;
using System;
using System.Windows.Input;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query.AbstractItem;


#endregion

namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Interaction logic for DataItemBrowser.xaml
    /// </summary>
    public partial class DataItemBrowser : UserControl
    {
        #region private members

        private DataItemBrowserViewModel _dataItemBrowserViewModel = null;

        private DataItemBrowserContext _dibContext = null;
        #endregion

        #region constructor

        public DataItemBrowser()
        {
            InitializeComponent();           
        }

        #endregion constructor

        public bool EnableSizeToContentWidth
        {
            get { return (bool)GetValue(EnableSizeToContentWidthProperty); }
            set { SetValue(EnableSizeToContentWidthProperty, value); }
        }

        /// <summary>
        /// True if this control is being asked to calculate it's width based
        /// on the current content
        /// </summary>
        public static readonly DependencyProperty EnableSizeToContentWidthProperty =
            DependencyProperty.Register("EnableSizeToContentWidth", typeof(bool), typeof(DataItemBrowser), new PropertyMetadata(false));       

        #region event handlers

        /// <summary>        
        /// dataitembrowswer view model double click select event
        /// </summary>
        /// <param name="sender">the sender of the event</param>
        /// <param name="e">the event arguments</param>
        void dataItemBrowserViewModel_DoubleClickSelect(object sender, PropertyChangedEventArgs e)
        {
            this.SelectedItem = _dataItemBrowserViewModel.SelectedItemPath;
            this.SelectedDataItemBase = _dataItemBrowserViewModel.SelectedDataItemBase;

            LogWrapper.DibInterfaceLog.Info("Double clicked on " + SelectedItem); 

            this.SelectedItemResourceID = _dataItemBrowserViewModel.SelectedCompositeDataItem;

            // Raise HighLightedItem first, as RaiseItemSelectedEvent closes the browser
            dataItemBrowserViewModel_SelectedItemPathChanged(sender, e);

            //raise the itemselected event 
            this.RaiseItemSelectedEvent();
        }

        /// <summary>        
        /// dataitembrowswer view model user changed the highlighted item event
        /// </summary>
        /// <param name="sender">the sender of the event</param>
        /// <param name="e">the event arguments</param>
        void dataItemBrowserViewModel_UserSetHighlightedItem(object sender, PropertyChangedEventArgs e)
        {
            // UserSetHighlightedItemResourceID
            this.UserSetHighlightedItemResourceID = _dataItemBrowserViewModel.UserSetHighlightedItemResourceID;

            //raise the itemselected event 
            this.UserSetHighlightedItem = _dataItemBrowserViewModel.UserSetHighlightedItemPath;

            LogWrapper.DibInterfaceLog.Debug("User High Lighted Item changed to " + UserSetHighlightedItem);

            RaiseEvent(new RoutedEventArgs(UserSetHighlightedItemChangedEvent));
        }

        void dataItemBrowserViewModel_UserSetHighlightedResourceID(object sender, PropertyChangedEventArgs e)
        {
            UserSetHighlightedItemResourceID = _dataItemBrowserViewModel.UserSetHighlightedItemResourceID;
            RaiseEvent(new RoutedEventArgs(UserSetHighlightedItemChangedEvent));
        }

        /// <summary>
        /// dataItemBrowser viewmodel selected item path has changed event
        /// </summary>
        /// <param name="sender">the sender of the event</param> 
        /// <param name="e">the event arguments</param>
        void dataItemBrowserViewModel_SelectedItemPathChanged(object sender, PropertyChangedEventArgs e)
        {
            this.HighlightedItem = _dataItemBrowserViewModel.SelectedItemPath;

            //raise the itemselectionchanged event 
            this.RaiseHighlightedItemChangedEvent();
        }

        /// <summary>
        /// browser window has loaded
        /// </summary>
        /// <param name="sender">the sender of the event</param>
        /// <param name="e">the event arguments</param>
        private void browserWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // If we have not already set the Xceed license key, do it here.
            // Note: Since we support both running the DIB in the context of the
            //       DIBWindow or as a user control, it makes a difference where
            //       the license key gets set. In the case of the DIBWindow the
            //       key is set in DIBWindow constructor, if however we are 
            //       running as a user control, then this will be the place 
            //       where we set the key.
            if (string.IsNullOrEmpty(XceedDeploymentLicense.ActiveLicenseKey))
                XceedDeploymentLicense.SetLicense();

            if (_dataItemBrowserViewModel != null)
            {
                // set the search filter controls data context to the view model stored in the DIB VM
                this.SearchFilter.DataContext = _dataItemBrowserViewModel.SearchFilterControlVM;
                this.SearchFilter.FilterTextChangedEventHandler += new RoutedEventHandler(SearchFilter_FilterTextChangedEventHandler);
                // Allow the search filter to auto open context menus whenever focus is received
                this.SearchFilter.ShouldAutoOpenContextMenusOnFocus = true;

                this.DataContext = _dataItemBrowserViewModel;

                _dataItemBrowserViewModel.Initialize(_dibContext, SelectedItem);
            }
            else
            {
                LogWrapper.DibGeneralLog.Warn("DataItemBrowser window loaded but dataItemBrowserViewModel not initialized");  
            }
        }

        public void Initialize(DIBClientManager dibClientManager, string selectedItem)
        {
            this.Initialize(dibClientManager, new DataItemBrowserContext.CreateBuilder(dibClientManager).Build(), selectedItem); 
        }

        /// <summary>
        /// Initialize
        /// Given a datacontext (optional) and a selecteditem (optional), drive
        /// the DIB toward its first navigation.
        /// </summary>
        /// <param name="dibContext">data item browser context</param>
        /// <param name="selectedItem">string containing item to select</param>
        public void Initialize(DIBClientManager dibClientManager, DataItemBrowserContext dibContext, string selectedItem)
        {
            //setup the data so that initialize of the dib view model can be called in the control
            //loaded event.   Do not try to call initialized before the control has loaded, the drillin
            //method expects all the views to be initialized and it will throw many exceptions.
            SelectedItem = selectedItem;
            _dibContext = dibContext;

            // create and initialize the DataItemBrowser view model
            _dataItemBrowserViewModel = new DataItemBrowserViewModel(dibClientManager, BrowserType);
            _dataItemBrowserViewModel.CurrentScreenName = CurrentScreenName;

            // show data in view
            ShowDataView = true;

            // create the breadcrumb view model
            this.breadCrumbs.DataContext = new BreadCrumbViewModel(_dataItemBrowserViewModel);

            // create the DataSources view model
            this.DataSourceView.DataContext = dibClientManager.createDIBTreeViewModel(_dataItemBrowserViewModel);

            // create DIBListView view model
            this.Device_ListView.DataContext = dibClientManager.createDIBListViewModel(_dataItemBrowserViewModel);

            // create datagrid view model
            this.DataItemDG.DataContext = dibClientManager.createDIBGridViewModel(_dataItemBrowserViewModel);

            // create Web View model
            //this.DIBWebView.DataContext = dibClientManager.createDIBWebViewModel(_dataItemBrowserViewModel);

            // register for various notificiations of the dib vm
            this._dataItemBrowserViewModel.SelectedItemPathChanged             += new PropertyChangedEventHandler(dataItemBrowserViewModel_SelectedItemPathChanged);
            this._dataItemBrowserViewModel.DoubleClickSelect                   += new PropertyChangedEventHandler(dataItemBrowserViewModel_DoubleClickSelect);
            this._dataItemBrowserViewModel.UserSetHighlightedItemPathChanged   += new PropertyChangedEventHandler(dataItemBrowserViewModel_UserSetHighlightedItem);
            this._dataItemBrowserViewModel.UserSetHighlightedResourceIDChanged += new PropertyChangedEventHandler(dataItemBrowserViewModel_UserSetHighlightedResourceID);
            this._dataItemBrowserViewModel.NavigateStateChanged                += new PropertyChangedEventHandler(_dataItemBrowserViewModel_NavigateStateChanged); //to show and hide the load spinner
            this._dataItemBrowserViewModel.DataViewChanged                     += new EventHandler(_dataItemBrowserViewModel_DataViewChanged);
        }

        /// <summary>        
        /// Event Handler for the SearchFilter text changed event.
        /// </summary>
        /// <param name="sender">the sender of the event</param>
        /// <param name="e">the event arguments</param>
        void SearchFilter_FilterTextChangedEventHandler(object sender, RoutedEventArgs e)
        {
            // If this method was called and search is not enabled, its possible that we got here because auto search 
            // was executed immedietely after we switched from a search enabled data view to a non search enabled data view. In that 
            // case, do nothing here.
            if (!this._dataItemBrowserViewModel.IsSearchEnabled)
            {
                return;
            }

            this.DataSourcesLoadingSpinner.Start();
            _dataItemBrowserViewModel.ProcessFilter();

            //  If we are performing a client side search or cancel, the ProcessFilter above will be synchronous.  We can 
            //  re-enable the breadcrumbs and stop the load spinner from here.  Otherwise, if a query based search or cancel is active, 
            //  we don't want to stop the spinner until the navigate is complete (_dataItemBrowserViewModel_NavigateStateChanged)  We
            // also check if a DIB COmmand is processing as we shouldn't stop the load spinner if a client side search is executed 
            // while a navigation request is still processing (i.e. data items are still being loaded).
            if (_dataItemBrowserViewModel.IsClientSideSearch())
            {
                this.DataSourcesLoadingSpinner.Stop();
            }

            if (!_dataItemBrowserViewModel.SearchFilterControlVM.AutoSearched)
                SendFocusToActiveDataView();
        }


        /// <summary>
        /// process the navigate state changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">navigate state changed event argument</param>
        void _dataItemBrowserViewModel_NavigateStateChanged(object sender, PropertyChangedEventArgs e)
        {
            NavigateStateChangedEventArgs navStateArg = e as NavigateStateChangedEventArgs;

            //beginning a navigate show the spinner
            if (navStateArg != null && navStateArg.Begin)
            {
                this.DataSourcesLoadingSpinner.Start();
            }
            else
            {
                //Ending a navigate should hide the spinner. 
                this.DataSourcesLoadingSpinner.Stop();

                if (this._dataItemBrowserViewModel.ProblemText.Length == 0)
                {
                    ShowDataView = true;
                }
                else
                {
                    ShowDataView = false;
                    //If the problem overlay is showing, make sure the help link is focused
                    this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, (Action)(() => Keyboard.Focus(ProblemOverlay_HelpLink as IInputElement)));
                }
            }
        }

        /// <summary>
        /// Handler for the data view changing so we can take opportunity to focus the active data view
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void _dataItemBrowserViewModel_DataViewChanged(object sender, EventArgs e)
        {
            //If the view change was not from a search (which sends focus to the data view elsewhere), set the focus to the data view
            // as long as no context menus are open
            if (!this._dataItemBrowserViewModel.IsLastNavigateFromUserSearch && !this.SearchFilter.IsAnyContextMenuOpen() && !breadCrumbs.IsContextMenuOpen)
            {
                SendFocusToActiveDataView();
            }
        }

        #endregion event handlers

        #region "Keyboard Events/Navigation"

        /// <summary>
        /// This method gives keyboard focus to the SearchFilter
        /// </summary>
        public void ProcessKeyboardRequestFocusToSearch()
        {
            if (SearchFilter.IsEnabled == false) return;
            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.SystemIdle, (Action)(() =>
            {
                SearchFilter.ProcessKeyboardRequestFocus();
            }));
        }

        /// <summary>
        /// This method gives keyboard focus to the DataGrid or DataSourceView
        /// </summary>
        public void ProcessKeyboardRequestFocusToGrid()
        {
            // Run this in the dispather when all other dispather events are processed
            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.SystemIdle, (Action)(() =>
            {
                if (this.IsDataGridViewActive())
                {
                    //The data grid has a quirk that if we set it to focused when it already has focus,
                    // it may not show the FocusVisualStyle (the "dotted outline") - it seems to only
                    // display when focus is coming from an element outside the grid, so to workaround
                    // this, we will quickly set focus to the breadcrumbs before focusing the grid.
                    if (this.DataItemDG.IsKeyboardFocusWithin)
                    {
                        this.breadCrumbs.ProcessKeyboardRequestFocus();
                    }

                    this.DataItemDG.ProcessKeyboardRequestFocus();
                }
                else if (this.IsDeviceViewActive())
                {
                    this.Device_ListView.ProcessKeyboardRequestFocus();
                }
                else
                {
                    this.DataSourceView.ProcessKeyboardRequestFocus();
                }
            }));
        }

        /// <summary>
        /// This method passes a DrillOut keyboard request to the DataGrid or DataSourceView, if the 
        /// DataItemBrowser is not currently processing a request.
        /// </summary>
        public void ProcessKeyboardRequestDrillOut()
        {
            // Run this in the dispather when all other dispather events are processed
            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.SystemIdle, (Action)(() =>
            {
                LogWrapper.DibGeneralLog.Debug("Entered DataItemBrowser>>ProcessKeyboardRequestDrillOut");
                if (this.IsDataGridViewActive())
                {
                    this.DataItemDG.ProcessKeyboardRequestDrillOut();
                }
                else if (this.IsDeviceViewActive())
                {
                    this.Device_ListView.ProcessKeyboardRequestDrillOut();
                }
                //else if (this.IsWebViewActive())
                //{
                //    this.DIBWebView.ProcessKeyboardRequestDrillOut();
                //}
                else
                {
                    this.DataSourceView.ProcessKeyboardRequestDrillOut();
                }
                LogWrapper.DibGeneralLog.Debug("Leaving DataItemBrowser>>ProcessKeyboardRequestDrillOut");
            }));
        }

        /// <summary>
        /// This method passes a DrillIn keyboard request to the DataSourceView, DataGrid or DIBListView, if the 
        /// DataItemBrowser is not currently processing a request.
        /// </summary>
        public void ProcessKeyboardRequestDrillIn()
        {
            // Run this in the dispather when all other dispather events are processed
            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.SystemIdle, (Action)(() =>
            {
                if (this.IsDataTypeBrowser())
                {
                    //If we are in the Data Type browser, we can only drill in if we are in the data sources view (for now)
                    if (!this.IsDataGridViewActive()) this.DataSourceView.ProcessKeyboardRequestDrillIn();
                    return;
                }
                if (this.IsDataGridViewActive())
                {
                    this.DataItemDG.ProcessKeyboardRequestDrillIn();
                }
                else if (this.IsDeviceViewActive())
                {
                    this.Device_ListView.ProcessKeyboardRequestDrillIn();
                }
                //else if (this.IsWebViewActive())
                //{
                //    this.DIBWebView.ProcessKeyboardRequestDrillIn();
                //}
                else
                {
                    //We are drilling in from DataSource View. Give focus to the Device View as that will be visible next
                    this.Device_ListView.ProcessKeyboardRequestFocus();
                    this.DataSourceView.ProcessKeyboardRequestDrillIn();
                }
            }));
        }

        /// <summary>
        /// This method attempts to select and give keyboard focus to the item above the currently selected item
        /// </summary>
        public void ProcessKeyboardRequestSelectPrevious()
        {
            // Run this in the dispather when all other dispather events are processed
            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.SystemIdle, (Action)(() =>
            {
                if (this.IsDataGridViewActive())
                {
                    this.DataItemDG.ProcessKeyboardRequestSelectPrevious();
                }
                else if (this.IsDeviceViewActive())
                {
                    this.Device_ListView.ProcessKeyboardRequestSelectPrevious();
                }
                else
                {
                    this.DataSourceView.ProcessKeyboardRequestSelectPrevious();
                }
            }));
        }

        /// <summary>
        /// This method attempts to select and give keyboard focus to the item below the currently selected item
        /// </summary>
        public void ProcessKeyboardRequestSelectNext()
        {
            // Run this in the dispather when all other dispather events are processed
            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.SystemIdle, (Action)(() =>
            {
                if (this.IsDataGridViewActive())
                {
                    this.DataItemDG.ProcessKeyboardRequestSelectNext();
                }
                else if (this.IsDeviceViewActive())
                {
                    this.Device_ListView.ProcessKeyboardRequestSelectNext();
                }
                else
                {
                    this.DataSourceView.ProcessKeyboardRequestSelectNext();
                }
            }));
        }

        /// <summary>
        /// This method gives keyboard focus to the active data view (DataSource, Device, or DataGrid View)
        /// </summary>
        public void SendFocusToActiveDataView()
        {
            if (this.DataSourceView.DataSourcesTreeView.Visibility == Visibility.Visible)
            {
                this.DataSourceView.ProcessKeyboardRequestFocus();
            }
            else if (this.IsDeviceViewActive())
            {
                this.Device_ListView.ProcessKeyboardRequestFocus();
            }
            else
            {
                this.DataItemDG.ProcessKeyboardRequestFocus();
            }
        }
        #endregion

        #region CurrentScreenName property

        /// <summary>
        /// current screen name. 
        /// </summary>
        public string CurrentScreenName { get; set; }

        #endregion CurrentScreenName property

        #region BrowserType Property

        // DataType or Tag Browser?
        public string BrowserType { get; set; }

        /// <summary>
        /// Is this a Tag or Data Type browser?
        /// </summary>
        /// <returns>True if Tag browser</returns>
        public bool IsTagBrowser()
        {
            return (BrowserType == DIResource.DI_COMMON_RESOURCETYPE_TAG);
        }

        public bool IsDataTypeBrowser()
        {
            return (BrowserType == DIResource.DI_COMMON_RESOURCETYPE_DATATYPE);
        }

        #endregion BrowserType Property

        #region Selected item properties and events

        #region "SelectedDataItemBase Dependency Property"

        ///<summary>
        /// SelectedDataItemBase dependency property
        ///</summary>
        public static DependencyProperty SelectedDataItemBaseProperty = DependencyProperty.Register(
            "SelectedDataItemBase",
            typeof(DataItemBase), 
            typeof(DataItemBrowser), 
            new PropertyMetadata(null,null));

        public DataItemBase SelectedDataItemBase
        {
            get { return (DataItemBase)GetValue(DataItemBrowser.SelectedDataItemBaseProperty); }
            set { SetValue(DataItemBrowser.SelectedDataItemBaseProperty, value); }
        }

        #endregion

        #region "SelectedItemProperty Dependency Property"

        ///<summary>
        /// SelectedItemProperty dependency property
        ///</summary>
        public static DependencyProperty SelectedItemProperty = DependencyProperty.Register("SelectedItem",
                               typeof(string), typeof(DataItemBrowser), new PropertyMetadata(null,
                               new PropertyChangedCallback(SelectedItemValueChanged)));

        public string SelectedItem
        {
            get { return (string)GetValue(DataItemBrowser.SelectedItemProperty); }
            set { SetValue(DataItemBrowser.SelectedItemProperty, value); }
        }

        /// <summary>
        /// callback when the SelectedItem property value has changed
        /// </summary>
        /// <param name="d">DataItemBrowser</param>
        /// <param name="e">the associated event arguments</param>
        private static void SelectedItemValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            DataItemBrowser dib = d as DataItemBrowser;
            if (dib != null) dib.NavigateToSelectedItem();
        }


        ///<summary>
        /// SelectedItemResourceIDProperty dependency property
        ///</summary>
        public static DependencyProperty SelectedItemResourceIDProperty = DependencyProperty.Register("SelectedItemResourceID",
                                typeof(CompositeDataItem), typeof(DataItemBrowser), new PropertyMetadata(null,
                                new PropertyChangedCallback(SelectedItemResourceIDValueChanged)));
        public CompositeDataItem SelectedItemResourceID
        {
            get { return (CompositeDataItem)GetValue(DataItemBrowser.SelectedItemResourceIDProperty); }
            set { SetValue(DataItemBrowser.SelectedItemResourceIDProperty, value); }
        }

        /// <summary>
        /// callback when the SelectedItemResourceID property value has changed
        /// </summary>
        /// <param name="d">DataItemBrowser</param>
        /// <param name="e">the associated event arguments</param>
        private static void SelectedItemResourceIDValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            // This should navigate to the dataitem specified in the CompositeDataItem
        }
        #endregion

        #region "ChildWindowOpenProperty Dependency Property"
        ///<summary>
        /// ChildWindowOpen dependency property
        /// This property informs the owning window that the DataItemBrowser control has opened a child window.
        /// This property is used to keep the modeless DataItemBrowser window from closing when it creates child window.
        ///</summary>
        public static DependencyProperty ChildWindowOpenProperty = DependencyProperty.Register("ChildWindowOpen",
                                typeof(bool), typeof(DataItemBrowser), new PropertyMetadata(null));
        public bool ChildWindowOpen
        {
            get { return (bool)GetValue(DataItemBrowser.ChildWindowOpenProperty); }
            set { SetValue(DataItemBrowser.ChildWindowOpenProperty, value); }
        }
        #endregion

        #region "ShowDataViewProperty Dependency Property"
        /// <summary>
        /// ShowDataView dependency property
        /// This property is used to control the visibility of both the DIBTreeView and DIBGridView
        /// It is turned on while the window is loading if we have been given an initial SelectedItem
        /// In this scenario we won't know which view to show until the SelectedItem is validated against
        ///  the view model so this property is set to true to avoid showing the wrong view for a split second
        /// </summary>
        public static readonly DependencyProperty ShowDataViewProperty =
            DependencyProperty.Register("ShowDataView", typeof(bool), typeof(DataItemBrowser), new UIPropertyMetadata(true));
        public bool ShowDataView
        {
            get { return (bool)GetValue(ShowDataViewProperty); }
            set { SetValue(ShowDataViewProperty, value); }
        }
        #endregion

        #region "HighlightedItemProperty Dependency Property"
        /// <summary>
        /// HighlightedItemProperty dependency property
        /// </summary>
        public static DependencyProperty HighlightedItemProperty = DependencyProperty.Register("HighlightedItem",
                                typeof(string), typeof(DataItemBrowser), new PropertyMetadata(null));
        public string HighlightedItem
        {
            get { return (string)GetValue(DataItemBrowser.HighlightedItemProperty); }
            set { SetValue(DataItemBrowser.HighlightedItemProperty, value); }
        }
        #endregion

        #region "ItemSelectedEvent RoutedEvent"
        ///<summary>
        /// UserSetHighlightedItemProperty dependency property
        ///</summary>
        public static DependencyProperty UserSetHighlightedItemProperty = DependencyProperty.Register("UserSetHighlightedItem",
                                typeof(string), typeof(DataItemBrowser), new PropertyMetadata(null));
        public string UserSetHighlightedItem
        {
            get { return (string)GetValue(DataItemBrowser.UserSetHighlightedItemProperty); }
            set { SetValue(DataItemBrowser.UserSetHighlightedItemProperty, value); }
        }

        /// <summary>
        /// UserSetHighlightedItemResourceIDProperty dependency property
        /// </summary>
        public static DependencyProperty UserSetHighlightedItemResourceIDProperty = DependencyProperty.Register("UserSetHighlightedItemResourceID",
                                typeof(CompositeDataItem), typeof(DataItemBrowser), new PropertyMetadata(null));
        public CompositeDataItem UserSetHighlightedItemResourceID
        {
            get { return (CompositeDataItem)GetValue(DataItemBrowser.UserSetHighlightedItemResourceIDProperty); }
            set { SetValue(DataItemBrowser.UserSetHighlightedItemResourceIDProperty, value); }
        }

        /// <summary>
        /// Event routing triggered when the user double-clicks (selects) an item
        /// </summary>
        public static readonly RoutedEvent ItemSelectedEvent =
            EventManager.RegisterRoutedEvent("ItemSelected", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(DataItemBrowser));

        /// <summary>
        /// Provide CLR accessors for the ItemSelected event
        /// </summary>
        public event RoutedEventHandler ItemSelected
        {
            add { AddHandler(ItemSelectedEvent, value); }
            remove { RemoveHandler(ItemSelectedEvent, value); }
        }

        /// <summary>
        /// Raises the ItemSelected event
        /// </summary>
        private void RaiseItemSelectedEvent()
        {
            RaiseEvent(new RoutedEventArgs(ItemSelectedEvent));
        }
        
        #endregion

        #region "HighlightedItemChangedEvent RoutedEvent"
        /// <summary>
        /// Event routing triggered when the user single-clicks (selects) an item
        /// </summary>
        public static readonly RoutedEvent HighlightedItemChangedEvent =
            EventManager.RegisterRoutedEvent("HighlightedItemChanged", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(DataItemBrowser));

        /// <summary>
        /// Provide CLR accessors for the ItemSelectionChanged event
        /// </summary>
        public event RoutedEventHandler HighlightedItemChanged
        {
            add { AddHandler(HighlightedItemChangedEvent, value); }
            remove { RemoveHandler(HighlightedItemChangedEvent, value); }
        }

        /// <summary>
        /// Raises the HighlightedItemChanged event
        /// </summary>
        private void RaiseHighlightedItemChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(HighlightedItemChangedEvent));
        }
        #endregion

        /// <summary>
        /// Event routing triggered when the user single-clicks (selects) an item
        /// </summary>
        public static readonly RoutedEvent UserSetHighlightedItemChangedEvent =
            EventManager.RegisterRoutedEvent("UserSetHighlightedItemChanged", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(DataItemBrowser));

        /// <summary>
        /// Provide CLR accessors for the UserSetHighlightedItemChanged event
        /// </summary>
        public event RoutedEventHandler UserSetHighlightedItemChanged
        {
            add { AddHandler(UserSetHighlightedItemChangedEvent, value); }
            remove { RemoveHandler(UserSetHighlightedItemChangedEvent, value); }
        }


        #endregion

        #region public interface

        /// <summary>
        /// Is the DIBGridView Visible?
        /// </summary>
        /// <returns></returns>
        public bool IsDataGridViewActive()
        {
            DIBGridViewModel dgVM = this.DataItemDG.DataContext as DIBGridViewModel;
            if (dgVM == null) return false;
            return dgVM.Visible == Visibility.Visible;
        }

        /// <summary>
        /// Is the DIBListView Visible?
        /// </summary>
        /// <returns></returns>
        public bool IsDeviceViewActive()
        {
            DIBListViewModel deviceVM = this.Device_ListView.DataContext as DIBListViewModel;
            if (deviceVM == null) return false;
            return deviceVM.Visible == Visibility.Visible;
        }
                
        /// <summary>
        /// Whether or not the Web View is Active
        /// </summary>
        /// <returns></returns>
        public bool IsWebViewActive()
        {
            return this._dataItemBrowserViewModel.IsWebView();
        }

        /// <summary>
        /// Determines if the data grid has keyboard focus but no selected item
        /// </summary>
        /// <returns>True if the data grid has focus but doesn't yet have a selected item</returns>
        public bool IsDataGridFocusedWithNoSelection()
        {
            DependencyObject dp = Keyboard.FocusedElement as DependencyObject;
            if (dp == null) return false;
            bool DataGridFocused = this.DataItemDG.IsAncestorOf(dp);
            bool DataGridHasNoSelection = this.DataItemDG.SelectedItem == null;
            return DataGridFocused && DataGridHasNoSelection;
        }

        
        /// <summary>
        /// Determines if any context menu of the DIB is currently open
        /// </summary>
        /// <returns>True if a menu is open</returns>
        public bool IsAnyContextMenuOpen()
        {
            if (this.SearchFilter.IsAnyContextMenuOpen()) return true;
            return breadCrumbs.IsContextMenuOpen;
        }

        /// <summary>
        /// Determines if any context menu of the search filter control is currently open
        /// </summary>
        /// <returns>True if a menu is open</returns>
        public bool IsSearchControlContextMenuOpen()
        {
            return this.SearchFilter.IsAnyContextMenuOpen();
        }

        /// <summary>
        /// Navigates to the value in the SelectedItem property
        /// </summary>
        public void NavigateToSelectedItem()
        {
            // Clear out the HighlightedItem - Navigate will set this when it
            // causes dataItemBrowserViewModel_SelectedItemPathChanged to be called.
            HighlightedItem = String.Empty;
            this.RaiseHighlightedItemChangedEvent();

            if (_dataItemBrowserViewModel != null)
            {
                // future functionality
                // If the _dataItemBrowserViewModel exists and the client changes the SelectedItem then
                // navigate to the new path
                // Something similar to _dataItemBrowserViewModel.Navigate(this.SelectedItem);
            }

            // if _dataItemBrowserViewModel == null then SelectedItem will be passed to the DataItemBrowserViewModel when
            // it is initialized.  See browserWindow_Loaded
        }

        /// <summary>
        /// Allow the DIB to refresh the current view and all asociated data.
        /// </summary>
        public void RefreshCurrentView()
        {
            this._dataItemBrowserViewModel.RefreshCurrentView();
        }

        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {
            // Remove this class' event handlers before removing children's event handlers
            _dataItemBrowserViewModel.SelectedItemPathChanged -= new PropertyChangedEventHandler(dataItemBrowserViewModel_SelectedItemPathChanged);
            _dataItemBrowserViewModel.DoubleClickSelect -= new PropertyChangedEventHandler(dataItemBrowserViewModel_DoubleClickSelect);
            _dataItemBrowserViewModel.UserSetHighlightedItemPathChanged -= new PropertyChangedEventHandler(dataItemBrowserViewModel_UserSetHighlightedItem);
            _dataItemBrowserViewModel.UserSetHighlightedResourceIDChanged -= new PropertyChangedEventHandler(dataItemBrowserViewModel_UserSetHighlightedResourceID);
            _dataItemBrowserViewModel.NavigateStateChanged -= new PropertyChangedEventHandler(_dataItemBrowserViewModel_NavigateStateChanged);
            _dataItemBrowserViewModel.DataViewChanged -= new EventHandler(_dataItemBrowserViewModel_DataViewChanged);
            _dataItemBrowserViewModel.CleanupEventSubscriptions();

            this.SearchFilter.FilterTextChangedEventHandler -= new RoutedEventHandler(SearchFilter_FilterTextChangedEventHandler);

            // Clean up the views and associated view models
            this.DataItemDG.CleanupEventSubscriptions();
            this.DataSourceView.CleanupEventSubscriptions();
            this.Device_ListView.CleanupEventSubscriptions();
            //this.DIBWebView.CleanupEventSubscriptions();
            this.breadCrumbs.CleanupEventSubscriptions();

            _dataItemBrowserViewModel.Close();
        }

        /// <summary>
        /// Clears the current MRU list history of the search filter control
        /// </summary>
        public void ClearSearchMRUListHistory()
        {
            _dataItemBrowserViewModel.ClearSearchMRUListHistory();
        }

        #endregion

    }
}

