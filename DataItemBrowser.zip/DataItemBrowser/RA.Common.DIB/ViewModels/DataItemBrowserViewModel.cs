/*************************************************************************************
 	  	                                                                     
   ViewE DataItemBrowser                                                                    
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
	                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                    
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

#region references

using System;
using System.Windows;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows.Input;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.CommonControls.SearchFilter.ViewModels;
using RockwellAutomation.UI.CommonControls.ViewModels;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.Resources;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.WindowsControl.DIBClient;

#endregion

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// Shim view model supporting the <c>DataItemBrowser</c>
    /// </summary>
    public class DataItemBrowserViewModel : DependencyObject, IDataItemBrowserViewModel, INotifyPropertyChanged
    {
        #region Private Members
        private DIBClientManager _dibClientManager = null;
        private Path _path = new Path();
        private ISearchFilterControlViewModel _searchFilterControlViewModel = null;
        private string _selectedItemPath = string.Empty;
        private DataItemBase _selectedDataItemBase = null;
        private SimpleCommand _selectedItemCommand = null;
        private SimpleCommand _userSetHighlightedItemCommand = null;
        private SimpleCommand _itemSelectionChangedCommand = null;
        private string _userSetHighlightedItemPath = string.Empty;
        private ConnectStringProcessor _connectStringProcessor = null;
        private string _launchWithSearchSelectedItemPath = string.Empty;

        //CompositeDataItem objects
        private CompositeDataItem _selectedCompositeDataItem = null;
        private CompositeDataItem _userSetHighlightedItemResourceID = null;

        #endregion Private Members

        #region events

        /// <summary>
        /// Event routing triggered when DataView changes
        /// </summary>
        public event EventHandler DataViewChanged;

        /// <summary>
        /// notify that navigation state has changed
        /// </summary>
        public void NotifyDataViewChanged()
        {
            if (DataViewChanged != null)
                DataViewChanged(this, new EventArgs());
        }

        #endregion

        #region Public Members

        public static readonly string BrowserType_Tag = DIResource.DI_COMMON_RESOURCETYPE_TAG.ToLower(); //"tag";
        public static readonly string BrowserType_DataType = DIResource.DI_COMMON_RESOURCETYPE_DATATYPE.ToLower(); //"datatype";
        public static readonly string BrowserType_AOGs = DIResource.DI_COMMON_RESOURCETYPE_AOGS.ToLower();

        public string BrowserType { get; set; }
        public string CurrentScreenName { get; set; }

        /// <summary>
        /// gets the <see cref="RockwellAutomation.UI.Models.Path"/> object
        /// </summary>
        public Path Path
        {
            get { return _path; }
          
        }

        public bool IsAOGPropertyBrowser()
        {
            return BrowserPerspective == DIBViewItemBase.VisualPerspectiveEnum.AOGPropertiesBrowser;
        }

        public bool IsTagBrowser()
        {
            return BrowserPerspective == DIBViewItemBase.VisualPerspectiveEnum.TagBrowser || IsAOGPropertyBrowser();
        }

        /// <summary>
        /// converts a string representing a browser perspective into a real
        /// <see cref="ViewModel.DIBTreeViewItem.VisualPerspectiveEnum"/> value
        /// </summary>
        /// <returns>VisualPerspectiveEnum value</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1820:TestForEmptyStringsUsingStringLength",Justification = "used in case")]
        public DIBViewItemBase.VisualPerspectiveEnum BrowserPerspective
        {
            get
            {
                DIBViewItemBase.VisualPerspectiveEnum _perspective = new DIBViewItemBase.VisualPerspectiveEnum();
                string browserType = BrowserType.ToLower().Trim();
                if (browserType == String.Empty || browserType == BrowserType_Tag)
                    _perspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
                else if (browserType == BrowserType_AOGs)
                    _perspective = DIBViewItemBase.VisualPerspectiveEnum.AOGPropertiesBrowser;
                else if(browserType==BrowserType_DataType)
                    _perspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
                else
                    throw new InvalidOperationException(String.Empty);

                return _perspective;
            }
        }

        /// <summary>
        /// Selected Item path that is used by the DataItemBrowserView to return the selected item path
        /// </summary>
        public string SelectedItemPath
        {
            get { return _selectedItemPath; }
            internal set
            {
                if (value == _selectedItemPath)
                    return;

                _selectedItemPath = value;

                // Persist the last path so future invocations of the DIB without a context can return to this highlighted item
                PersistLastHighlightedItem(_selectedItemPath);

                NotifySelectedItemPathChanged();
            }
        }

        /// <summary>
        /// Selected DataItemBase
        /// </summary>
        public DataItemBase SelectedDataItemBase
        {
            get { return _selectedDataItemBase; }
            internal set
            {
                if (value == _selectedDataItemBase) return;
                _selectedDataItemBase = value;
            }
        }

        /// <summary>
        /// Clears out the persisted last highlighted item info and notifies dependents
        /// </summary>
        public void ClearLastHighlightedItemInfo()
        {
            DataItemBrowserViewModel.ClearLastHighlightedItemWithoutNotify();
            NotifySelectedItemPathChanged();
        }

        /// <summary>
        /// Clears out the persisted last highlighted item info in the event a client wants to forget the memory of
        /// what was previously navigated to for followup navigation
        /// </summary>
        public static void ClearLastHighlightedItemWithoutNotify()
        {
            LogWrapper.DibInterfaceLog.Debug("Tag Browser's and Data Type Browser's LastHighLightedItem cleared");
            DIBPersistedVariables.TagBrowser_LastHighLightedItem = string.Empty;
            DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem = string.Empty;
        }

        /// <summary>
        /// Helper to persist the passed path to the last highlighted item variable
        /// </summary>
        /// <param name="pathToPersist"></param>
        private void PersistLastHighlightedItem(string pathToPersist)
        {
            if (IsTagBrowser())
            {
                LogWrapper.DibInterfaceLog.Debug("Tag Browser's selected item and LastHighLightedItem changed to " + pathToPersist);
                DIBPersistedVariables.TagBrowser_LastHighLightedItem = pathToPersist;
            }
            else
            {
                LogWrapper.DibInterfaceLog.Debug("Data Type Browser's selected item and LastHighLightedItem changed to " + pathToPersist);
                DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem = pathToPersist;
            }
        }

        /// <summary>
        /// Clears out the current search filter control MRU list history (if wanting to clear histories
        /// for all Tag/Data Type browsers, use the static ClearSearchMRUListHistories instead)
        /// </summary>
        public void ClearSearchMRUListHistory()
        {
            SearchFilterControlVM.ClearMruList();
        }

        /// <summary>
        /// Clears out the search filter control MRU list history (statically for all Tag/Data type browsers)
        /// </summary>
        public static void ClearSearchMRUListHistories()
        {
            SearchFilterControlViewModel.ClearMruListContext(BrowserType_Tag);
            SearchFilterControlViewModel.ClearMruListContext(BrowserType_DataType);
        }

        /// <summary>
        /// CompositeDataItem for the SelectedCompositeDataItem
        /// </summary>
        public CompositeDataItem SelectedCompositeDataItem
        {
            get { return _selectedCompositeDataItem; }
            internal set { _selectedCompositeDataItem = (CompositeDataItem) value; }
        }

        /// <summary>
        /// User-set highlighted item path that is used by the DataItemBrowserView to return the
        /// user-highlighted item
        /// </summary>
        public string UserSetHighlightedItemPath
        {
            get { return _userSetHighlightedItemPath; }
            internal set
            {
                if (value == _userSetHighlightedItemPath)
                    return;

                _userSetHighlightedItemPath = value;
                NotifyUserSetHighlightedItemPathChanged();
            }
        }

        /// <summary>
        /// CompositeDataItem for the UserSetHighlightedItemResourceID
        /// </summary>
        public CompositeDataItem UserSetHighlightedItemResourceID
        {
            get { return _userSetHighlightedItemResourceID; }
            internal set
            {
                _userSetHighlightedItemResourceID = (CompositeDataItem) value;
                NotifyUserSetHighlightedResourceIDChanged();
            }
        }        

        /// <summary>
        /// Gets/Sets the value to display for the View Header
        /// </summary>
        private string _viewHeader = String.Empty;

        public string ViewHeader
        {
            get { return _viewHeader; }
            set
            {
                if (value != _viewHeader)
                {
                    _viewHeader = value;
                    NotifyPropertyChanged("ViewHeader");
                }
            }
        }

        /// <summary>
        /// The last item explicitly highlighted by the user (i.e. via mouse click or keyboard)
        /// </summary>
        public string LastUserHighlightedItem { get; set; }

        /// <summary>
        /// Gets the search filter control view model such that a view can set
        /// it's data context properly
        /// </summary>
        public ISearchFilterControlViewModel SearchFilterControlVM
        {
            get
            {                
                return _searchFilterControlViewModel;                
            }
           
        }

        /// <summary>
        /// Gets the list of columns that are currently being used
        /// </summary>
        public List<ColumnConfigMapItem> Columns
        {
            get 
            {
                if (_clientDataServices == null) return null;
                return _clientDataServices.Columns; 
            }
        }

        /// <summary>
        /// This method performs a  single update to the Column Configuration based on the provided parameters.
        /// </summary>
        /// <param name="columnAttribute">The attribute to be update (Width, visibility, etc)</param>
        /// <param name="columnName">the column name used to generate an key to the correct location</param>
        /// <param name="columnValue">The column Value to set</param>
        public void UpdateColumnConfig(ColumnAttribute columnAttribute, string columnName, object columnValue)
        {
            _clientDataServices.UpdateColumnConfig(columnAttribute, columnName, columnValue);
        }

        /// <summary>
        /// Persist the user config to disk.
        /// </summary>
        public void SaveColumnConfig()
        {
            _clientDataServices.SaveColumnConfig();
        }

        //Represents the tags and properties data item for the current data items
        public DataItemBase TagsAndPropsItem
        {
            get { return DIResource.DIB_TagsAndProps; }
        }

        //Tracks whether a search is currently applied (either view filtering or via query services)
        public bool IsSearchActive { get; set; }


        //Tracks whether we are currently searching via a special query call (will be false
        // if we are searching only by using the view filtering provided by data grid collection view)
        public bool IsQueryBasedSearchActive { get; set; }

        /// <summary>
        /// Whether or not we are currently performing a client side only search or search filter clear. (no server side queries)
        /// </summary>
        /// <returns>True if the request does NOT require server side processing</returns> 
        public bool IsClientSideSearch()
        {
            if (_clientDataServices.IsExecutingQueryCommand()) return false;
            if (IsQueryBasedSearchActive) return false;

            return true;
        }

        /// <summary>
        /// Represents which view the GUI should display given the current context
        /// </summary>
        public IDIBDataViewType DataView
        {
            get 
            {
                return this._clientDataServices != null ? _clientDataServices.DataView : new DIBDataViewTypeUnknown();
            }
        }

        /// <summary>
        /// True if the last navigation of data item display was from a user initiated search
        /// (false if it came from a navigate or data context originated search)
        /// </summary>
        public bool IsLastNavigateFromUserSearch { get; set; }

        #endregion Public Members

       
        #region Public Methods

        /// <summary>
        /// Compares the container Path Items against the passed in current path items to determine if the container path elements match.
        /// Currently only used for the ViewModel TAF plugin
        /// </summary>        
        /// <param name="currentPath"></param>
        public bool IsNavigateOnCurrentPath(Path currentPath)
        {
            if ((currentPath.Items.Count == 0) || (Path.SelectedPath.Count == 0))
                return false;

            //  Check Controller name
            if (!(currentPath.Items[0].DisplayName.Equals(Path.SelectedPath[0].DisplayName, StringComparison.CurrentCultureIgnoreCase)))
                return false;

            // Check for Programs
            bool currPathHasProgram = false;
            bool newPathHasProgram = false;
            if (currentPath.Items.Count > 1)
                currPathHasProgram = currentPath.Items[1].IsContainer;
            if (Path.SelectedPath.Count > 1)
                newPathHasProgram = Path.SelectedPath[1].IsContainer;

            // Path is not the same if only one has a program item.
            if (currPathHasProgram != newPathHasProgram)
                return false;

            // If both do not have programs, then the controllers matched and the path is the same.
            if ((!currPathHasProgram) && (!newPathHasProgram))
                return true;

            // Check whether program name is the same.
            if (!(currentPath.Items[1].DisplayName.Equals(Path.SelectedPath[1].DisplayName, StringComparison.CurrentCultureIgnoreCase)))
                return false;

            // Controller names and Program names match
            return true;
        }


        /// <summary>
        /// Fills in the Path member of this view model from the path of the passed data item
        /// </summary>
        /// <param name="dataItem">Data Item to construct the path for</param>
        /// <param name="callback">Callback to use if this method needs to perform a call to navigate</param>
        /// <returns>True if the call to this method will result in the provided callback being used</returns>
        public bool PopulatePathFromDataItemPath(DataItemBase dataItem, DataLoadComplete callback)
        {
            if (_dibClientManager.IsGenericDIBBrowser())
            {
                return false;
            }

            bool isUsingCallback = false;

            //If we are needing the path populated from the data sources view, the HMIDevice view, or the controller view
            if (Path.ActiveElement is HomePathElement || Path.ActiveElement is ControllerPathElement || Path.ActiveElement is HMIDevicePathElement)
            {
                if ( Path.ActiveElement is ControllerPathElement || Path.ActiveElement is HMIDevicePathElement )
                {
                    Path.SetActive(Path.Back);
                    Path.RemoveInactiveElements();
                }

                string itemPath = dataItem.CommonLocation;
                bool isProgram = itemPath.Contains("\\");
                List<String> pathItems = (itemPath.Split(new char[] { '.', '\\' })).ToList();
                pathItems.Add(dataItem.CommonName);
                string deviceName = pathItems[0].TrimStart(new char[] { ':' });

                // Add device path
                DataItemBase parentItem = this.GetDeviceItemByName(deviceName);
                this.Path.Add(PathElementFactory.Instance().CreatePathElement(parentItem));

                if (isProgram)
                {
                    this.Path.Add(PathElementFactory.Instance().CreatePathElement(DIResource.DIB_Programs));
                    parentItem = DIResource.DIB_Programs;
                }

                //The last item in pathItems will be the name of the tag so to check if this
                // tag is nested in a container (i.e. program, phase, etc) we check to see
                // if the path count is greater than 2, however the container name will be
                // in index 1
                if (pathItems.Count() > 2)
                {
                    //Add program/phase/etc path element
                    string containerName = pathItems[1];

                    //Set that we will be using the callback provided, and call navigate
                    // to allow us to get the data item base for the container
                    isUsingCallback = callback != null ? true : false;
                    this.NavigateNoGui(parentItem, (error) =>
                    {
                        if (String.IsNullOrEmpty(error))
                        {
                            DataItemBase containerItem = this.GetDataItemByName(containerName);
                            if (containerItem == null)
                            {
                                LogWrapper.DibGeneralLog.Warn(containerName + " was not found in folder " + parentItem.ToString(), new Exception(String.Empty));
                            }
                            else
                                // Add the containterItem
                                this.Path.Add(PathElementFactory.Instance().CreatePathElement(containerItem));
                            }
                        else
                        {
                            LogWrapper.LogException("Drilling in during search returned an error from DibQuery", new Exception(error));
                        }

                        //Finish by calling the callback provided by the caller of this method
                        if (callback != null)
                            callback(error);
                    });
                }
                //If we don't have a container name, this is a device scoped item
                else
                {
                    //Add tags and properties path element
                    this.Path.Add(PathElementFactory.Instance().CreatePathElement(DIResource.DIB_TagsAndProps));
                }
            }

            return isUsingCallback;
        }

        /// <summary>
        /// Returns the data item matching the passed device name
        /// </summary>
        /// <param name="deviceName">Name of device to find</param>
        /// <returns>Data item matching passed name or null if not found</returns>
        public DataItemBase GetDeviceItemByName(string deviceName)
        {
            return _clientDataServices.GetDeviceItemByName(deviceName);
        }

        /// <summary>
        /// Returns the data item matching the passed name
        /// </summary>
        /// <param name="deviceName">Name of data item to find</param>
        public DataItemBase GetDataItemByName(string itemName)
        {
            return _clientDataServices.GetDataItemByName(itemName);
        }


        /// <summary>
        /// Find the dataitem for the datatype associated with location
        /// </summary>
        /// <param name="datatype">Name of the datatype</param>
        /// <param name="location">Device containing the name</param>
        /// <returns></returns>
        public DataItemBase GetDataTypeItemByLocation(string datatype, string location)
        {
            return _clientDataServices.GetDataTypeItemByLocation(datatype, location);
        }

        #endregion Public Methods

        #region Events
       

        /// <summary>
        /// Event routing triggered when a selected item path changes 
        /// </summary>
        public event PropertyChangedEventHandler SelectedItemPathChanged;

        /// <summary>
        /// Event routing triggered when we left mouse double click selection
        /// </summary>
        public event PropertyChangedEventHandler DoubleClickSelect;

        /// <summary>
        /// Event routing triggered when the user changes the highlighted item via mouse or keyboard
        /// </summary>
        public event PropertyChangedEventHandler UserSetHighlightedItemPathChanged;

        /// <summary>
        /// Event routing triggered when the UserSetHighlightedResourceID is set after
        /// the user changes the highlighted item via mouse or keyboard
        /// </summary>
        public event PropertyChangedEventHandler UserSetHighlightedResourceIDChanged;

        /// <summary>
        /// Event routing triggered when are navigating
        /// </summary>
        public event PropertyChangedEventHandler NavigateStateChanged;

        /// <summary>
        /// Event routing triggered when we update the data sources observable collection
        /// </summary>
        public event PropertyChangedEventHandler TreeViewOCChanged;

        /// <summary>
        /// Event routing triggered when we update the device view's observable collection
        /// </summary>
        public event PropertyChangedEventHandler ListViewOCChanged;

        /// <summary>
        /// Event routing triggered when we update the web view's observable collection
        /// </summary>
        public event PropertyChangedEventHandler WebViewOCChanged;

        /// <summary>
        /// Event routing triggered when we update the data grid observable collection
        /// </summary>
        public event PropertyChangedEventHandler DataGridOCChanged;

        /// <summary>
        /// Event routing triggered when navigate complete function is called
        /// </summary>
        public event PropertyChangedEventHandler NavigateComplete;

        /// <summary>
        /// Event routing triggered when we update the data grid columns
        /// </summary>
        public event PropertyChangedEventHandler DataGridColsChanged;

        /// <summary>
        /// select item after launching with search
        /// </summary>
        public event PropertyChangedEventHandler SelectItemAfterLaunchWithSearch;

        #endregion Events

        #region Event Handlers

      
        /// <summary>
        /// notify that selected item path has changed
        /// </summary>
        protected void NotifySelectedItemPathChanged()
        {
            if (SelectedItemPathChanged != null)
                SelectedItemPathChanged(this, new PropertyChangedEventArgs("SelectedItemPath"));
        }

        /// <summary>
        /// notify that double click selection has occured
        /// </summary>
        protected void NotifyDoubleClickSelect()
        {
            LogWrapper.DibGeneralLog.Debug("Received DataItemBrowserViewModel.NotifyDoubleClickSelect for: " + SelectedCompositeDataItem);  
            if (DoubleClickSelect != null)
                DoubleClickSelect(this, new PropertyChangedEventArgs(String.Empty));
        }

        /// <summary>
        /// notify that the user's changed the highlighted item
        /// </summary>
        protected void NotifyUserSetHighlightedItemPathChanged()
        {
            if (UserSetHighlightedItemPathChanged != null)
                UserSetHighlightedItemPathChanged(this, new PropertyChangedEventArgs("UserSetHighlightedItemPath"));
        }

        protected void NotifyUserSetHighlightedResourceIDChanged()
        {
            if (UserSetHighlightedResourceIDChanged != null)
                UserSetHighlightedResourceIDChanged(this, new PropertyChangedEventArgs("UserSetHighlightedResourceID"));
        }

        /// <summary>
        /// notify that navigation state has changed
        /// </summary>
        protected void NotifyNavigateStateChanged(bool begin)
        {
             if (NavigateStateChanged != null)
                 NavigateStateChanged(this, new NavigateStateChangedEventArgs(String.Empty, begin));
        }

        /// <summary>
        /// notify to select an item after launching with a search
        /// </summary>
        protected void NotifySelectItemAfterLaunchWithSearch(string selectedItemPath)
        {
            LogWrapper.DibGeneralLog.Debug("Received DataItemBrowserViewModel.NotifySelectItemAfterLaunchWithSearch: " + selectedItemPath);  
            if (SelectItemAfterLaunchWithSearch != null)
            {
                SelectItemAfterLaunchWithSearch(this,
                                                new SelectItemAfterLaunchWithSearchEventArgs(
                                                    "SelectItemAfterLaunchWithSearch", selectedItemPath));
            }           
        }

        /// <summary>
        /// notify that navigation has completed
        /// This allows users above the DIBViewModel to know when Navigate is complete.  
        //  Added only to support TAF DrillIn Actor
        /// </summary>
        protected void NotifyNavigateComplete()
        {
            LogWrapper.DibGeneralLog.Info("Received DataItemBrowserViewModel.NavigateComplete");  
            if (NavigateComplete != null)
            {
                List<IPathElement> fullPath = this.Path.Items.Count > 0 ? this.Path.Items.ToList<IPathElement>() : null;
                // Change ActiveElement (which is null) to SavedHighlightedElement (the last element, or highlighted item)
                string nameToSelect = this.Path.SavedHighlightedElement != null
                                          ? this.Path.SavedHighlightedElement.DisplayName
                                          : String.Empty;
                NavigateComplete(this, new NavigatePropertyChangedEventArgs("NavigateComplete", fullPath, nameToSelect));
            }
        }

        /// <summary>
        /// DataServices load complete callback
        /// 
        /// Note: This callback is called once the data services has obtained a load complete
        ///       event from the underlying query services.
        /// </summary>
        /// <param name="error">If non-empty, reflects an error obtained by the query services</param>
        private void DataServicesLoadComplete(string error)
        {
            DataItemBase itemToSelect = null;
            string itemToSelectName = null;

            bool hasError = !string.IsNullOrEmpty(error);
            if (!hasError)
            {
                // Determine the Item To Highlight (select) in the resulting grid.                
                if (_path != null)
                {                    
                    // If there is a forward Path Element, that is the ItemToSelect.
                    if (_path.Forward != null)
                        itemToSelect = _path.Forward.DataItem;
                    else
                    {
                        // If the Active Element is the last element, use the SavedHighlightedItem, which may or may not be set.
                        if (_path.SavedHighlightedElement != null)
                        {
                            itemToSelect = _path.SavedHighlightedElement.DataItem;
                        }
                        else if (!string.IsNullOrEmpty(_launchWithSearchSelectedItemPath))
                        {
                            //get the dataitem for launch selectedItem
                            itemToSelect = GetDataItemByPath(_launchWithSearchSelectedItemPath);
                        }
                                                    
                    }
                }
                //Refresh the column config / selected item / etc.
                if (IsTreeView())
                {
                    if (itemToSelect != null)
                        itemToSelectName = itemToSelect.CommonName;
                    NotifyTreeViewOCChanged(itemToSelectName);
                }
                else if (IsListView())
                {
                    if (itemToSelect != null)
                        itemToSelectName = itemToSelect.CommonName;
                    NotifyListViewOCChanged(itemToSelectName);
                }
                else if (IsWebView())
                {
                    if (itemToSelect != null)
                        itemToSelectName = itemToSelect.CommonName;
                    NotifyWebViewOCChanged(itemToSelectName);
                }
                else
                {
                    if (!string.IsNullOrEmpty(_launchWithSearchSelectedItemPath))
                    {
                        //get the dataitem for launch selectedItem
                        itemToSelect = GetDataItemByPath(_launchWithSearchSelectedItemPath);
                    }
                    NotifyDataGridOCChanged(itemToSelect);
                }

                //update search state after load is complete
                UpdateIsSearchEnabled();
            }

            //Hide the load spinner
            NotifyNavigateStateChanged(false);

            //since it this is only used during launch, make sure it is cleared 
            _launchWithSearchSelectedItemPath = string.Empty;

            // call NotifyNavigationComplete after navigation was actually finished (fix for TAF hang issue)
            if (!hasError)
            {
                //Let external clients know navigate has completed
                NotifyNavigateComplete();
            }
        }

        /// <summary>
        /// Setter for client data services to set the problem variables
        /// </summary>
        /// <param name="text">Text for the problem</param>
        /// <param name="helpid">Help topic id for the problem</param>
        private void SetProblemVars(string text, string helpid = "", bool disableSearch = false, bool disableCrumbs = false)
        {
            //No need to do any work if this is being called to clear the problem text, but there is currently no problem text
            if (string.IsNullOrEmpty(text) && string.IsNullOrEmpty(ProblemText))
                return;

            ProblemText = text;
            ProblemHelpId = helpid;

            //Disable search if the problem info instructs us to
            if (disableSearch)
                IsSearchEnabled = false;
            else
                UpdateIsSearchEnabled();
            
            //Disable crumbs if the problem info instructs us to.  We can enable
            // the crumbs explicitly here since the problem info is the only entity
            // that disables the crumbs
            IsCrumbNavigationEnabled = !disableCrumbs;
        }
        
        /// <summary>
        /// gets the data item for the path supplied
        /// </summary>
        /// <param name="dataItemPath"></param>
        /// <returns>the DataItemBase that matches this path, otherwise null</returns>
        private DataItemBase GetDataItemByPath(string dataItemPath)
        {
            //nothing to select then just return
            if (string.IsNullOrEmpty(dataItemPath))
                return null;

            string name = dataItemPath;
            string location = null;
            //break the full path into name and path
            string[] pathItems = dataItemPath.Split(DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER[0]);
            if (pathItems.Length > 1)
            {
                //since we are searching we only need to get to the top level tag
                //and remove array delimiters from its name
                string[] names = pathItems[1].Split(DIResource.DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER);

                //Is this a view based search and the active element is home
                if (!IsQueryBasedSearchActive && Path.ActiveElement is HomePathElement)
                {
                    //get top level tag name without array delimiters
                    name = names[0];
                }
                else
                {
                    //get location and top level tag name without array delimiters
                    location = pathItems[0];
                    name = names[0];
                }
            }
            return _clientDataServices.GetDataItemByName(name, location);
        }

        /// <summary>
        /// path property changed event handler
        /// </summary>
        /// <param name="sender">the originator of the event</param>
        /// <param name="e">the property changed event arguments</param>
        private void Path_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //did the last highlighted element property change
            if (e.PropertyName == "HighlightedElement")
            {
                //execute Item selection changed command 
                ItemSelectionChangedCommand.Execute(Path.HighlightedElement);
            }           
        }

        /// <summary>
        /// event handler for the active path changes
        /// </summary>
        /// <param name="sender">the originator of the event</param>
        /// <param name="e">the property changed event arguments</param>
        private void Path_ActivePathChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            ItemSelectionChangedCommand.Execute(Path.HighlightedElement);			
        }
 
        /// <summary>
		/// Updates the IsSearchEnabled property based on the resourceType of the currently ActiveElement
		/// as well as the browser type
        /// </summary>
        private void UpdateIsSearchEnabled()
        {
            bool searchEnabled = true;
			if (IsTagBrowser())
			{
				if (Path.ActiveElement != null && DIResource.IsResourceTypeNonSearchableInVieweGUI(Path.ActiveElement.DataItem))
                    searchEnabled = false;
			}
			else //Data type browser
			{
                if (Path.ActiveElement == null || Path.ActiveElement is HomePathElement) //can't do a deep search for data types
					searchEnabled = false;
			}
            IsSearchEnabled = searchEnabled;
        }
     

        /// <summary>
        /// notify that the data sources observable collection has changed
        /// </summary>
        /// <param name="selectedName"></param>
        protected void NotifyTreeViewOCChanged(string selectedName)
        {
            if (TreeViewOCChanged != null)
                TreeViewOCChanged(this, new SelectedItemPropertyChangedEventArgs(String.Empty, selectedName));
        }

        /// <summary>
        /// event handler for a DataGrid ObservableCollection changes 
        /// </summary>
        /// <param name="itemToSelect"></param>
        protected void NotifyDataGridOCChanged(DataItemBase itemToSelect)
        {
            if (DataGridOCChanged != null)
                DataGridOCChanged(this, new DGOCPropertyChangedEventArgs(String.Empty, itemToSelect));
        }

        /// <summary>
        /// event handler for DIBListView ObservableCollection changes 
        /// </summary>
        /// <param name="itemToSelect"></param>
        protected void NotifyListViewOCChanged(string selectedName)
        {
            if (ListViewOCChanged != null)
                ListViewOCChanged(this, new SelectedItemPropertyChangedEventArgs(String.Empty, selectedName));
        }

        /// <summary>
        /// event handler for WebView ObservableCollection changes 
        /// </summary>
        /// <param name="itemToSelect"></param>
        protected void NotifyWebViewOCChanged(string selectedName)
        {
            if (WebViewOCChanged != null)
                WebViewOCChanged(this, new SelectedItemPropertyChangedEventArgs(String.Empty, selectedName));
        }

        /// <summary>
        /// event handler for a DataGrid column changes 
        /// </summary>
        protected void NotifyDataGridColsChanged()
        {
            if (DataGridColsChanged != null)
                DataGridColsChanged(this, new PropertyChangedEventArgs(String.Empty));
        }

        #endregion Event Handlers

        #region Searching and Filtering

        /// <summary>
        /// Event routing triggered when we want to add or remove the search bread crumb
        /// </summary>
        public event PropertyChangedEventHandler SearchBreadCrumbChanged;

        protected void NotifySearchBreadCrumbChanged(bool add)
        {
            if (SearchBreadCrumbChanged != null)
            {
                SearchBreadCrumbChanged(this, new SearchBreadCrumbPropertyChangedEventArgs(String.Empty, add));
            }
        }

        /// <summary>
        /// is the search capability enabled (i.e. are the controls enabled)
        /// </summary>
        private bool _isSearchEnabled = false;

        public bool IsSearchEnabled
        {
            get { return _isSearchEnabled; }
            set
            {
                if (value != _isSearchEnabled)
                {
                    _isSearchEnabled = value;
                    NotifyPropertyChanged("IsSearchEnabled");
                }
            }
        }

        /// <summary>
        /// Is navigation via the breadcrumbs currently enabled
        /// </summary>
        private bool _isCrumbNavigationEnabled = true;

        public bool IsCrumbNavigationEnabled
        {
            get { return _isCrumbNavigationEnabled; }
            set
            {
                if (value != _isCrumbNavigationEnabled)
                {
                    _isCrumbNavigationEnabled = value;
                    NotifyPropertyChanged("IsCrumbNavigationEnabled");
                }
            }
        }

        private string _problemText = String.Empty;
        /// <summary>
        /// Gets/sets the text to show in a problem overlay if an issue occurs during navigation/operation
        /// The overlay itself will show/hide itself based on if this text is empty/populated
        /// </summary>
        public string ProblemText
        {
            get { return _problemText; }
            set
            {
                if (value != _problemText)
                {
                    _problemText = value;
                    NotifyPropertyChanged("ProblemText");
                }
            }
        }

        private string _problemHelpId = String.Empty;
        /// <summary>
        /// Gets/sets the help topic id for the help link in the problem overlay
        /// </summary>
        public string ProblemHelpId
        {
            get { return _problemHelpId; }
            set
            {
                if (value != _problemHelpId)
                {
                    _problemHelpId = value;
                    NotifyPropertyChanged("ProblemHelpId");
                }
            }
        }

        /// <summary>
        /// Determines based on the current context (this.Path.ActiveElement) whether or not
        /// the DibQuery should be used for searching (i.e. true for tag browser data sources, controller,
        /// and HMI devices views, and false for everything else)
        /// </summary>
        /// <returns>true if search should be done via a call to the query service provider (DibQuery)</returns>
        private bool ShouldSearchViaQuery()
        {
            return _dibClientManager.ShouldSearchViaQuery(this.Path);
        }


        /// <summary>
        /// Procsss a filter / updated the grid/breadcrumbs accordingly
        /// </summary>
        /// <param name="userInvoked">True if this filtering call originated directly from the user typing a search</param>
        public void ProcessFilter(bool userInvoked = true)
        {
            //determine if search text is empty (actual empty string or no filter values)
            bool searchTextEmpty = string.IsNullOrWhiteSpace(SearchFilterControlVM.SearchFilterText) ||
                                   !SearchFilterControlVM.HasNonEmptySearchValue;

            bool wasSearchActive = IsSearchActive;

            //success
            if (!_searchFilterControlViewModel.HasError)
            {
                IsSearchActive = !searchTextEmpty;

                if(userInvoked)
                    IsLastNavigateFromUserSearch = true;

                Path.SavedHighlightedElement = null;

                //have the CDS decide if we should generate a query for this search (conveyed back
                // to us here by the return value of the search call).  
                DataItemBase dataItem = this.Path.ActiveElement != null ? this.Path.ActiveElement.DataItem : null;
                //If the search text was just cleared and we were looking at query based search results, or we are
                //currently in the controller view or datasources view go back to the data sources view or controller view                                
                if (searchTextEmpty && (IsQueryBasedSearchActive 
                                        || IsResourceTypeEqual(dataItem, DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER)
                                        || IsResourceTypeEqual(dataItem, DIResource.DI_COMMON_RESOURCETYPE_NONE)))
                {
                    Navigate(this.Path.ActiveElement != null ? this.Path.ActiveElement.DataItem : (DataItemBase) null, true, true);
                }
                else 
                {                    
                    //If we're doing query based searching and we're not currently canceling an active query 
                    if (ShouldSearchViaQuery())
                    {
                        //False could mean that the data services are busy so only set IsQueryBasedSearchActive if true
                        // (meaning a search query was run) 
                        bool isSearchExecuted = _clientDataServices.Search(dataItem,this._searchFilterControlViewModel.GetFilterConfig());
                        if (!searchTextEmpty && isSearchExecuted)
                        {
                            NotifyDataGridColsChanged();
                            IsQueryBasedSearchActive = true;

                            LogWrapper.DibGeneralLog.Info("Query based search active: " + SearchFilterControlVM.SearchFilterText);
                        }
                        if (!isSearchExecuted)
                        {
                            CleanupFailedSearch(wasSearchActive, searchTextEmpty);
                            LogWrapper.DibGeneralLog.Info("Query based search not executed: " + SearchFilterControlVM.SearchFilterText);
                        }
                    }
                        //View based filtering (only if the text is non-empty or a search was previously active)
                    else if (!searchTextEmpty || wasSearchActive)
                    {
                        //If we have a problem, we need to re-navigate to the context we are drilled in to so that tags are displayed
                        if (!String.IsNullOrEmpty(ProblemText))
                        {
                            Navigate(this.Path.ActiveElement != null ? this.Path.ActiveElement.DataItem : (DataItemBase)null, false, true);
                        }
                        else
                        {
                            NotifyDataGridColsChanged();
                            NotifyDataGridOCChanged(null);
                            //Hide the load spinner and set focus to the Grid
                            if (!_clientDataServices.IsExecutingQueryCommand())
                                NotifyNavigateStateChanged(false);
                        }
                    }
                }

                //Update search crumb
                bool addSearchCrumb = !searchTextEmpty;
                NotifySearchBreadCrumbChanged(addSearchCrumb);
            }
            else //fail
            {
                //Hide the load spinner
                NotifyNavigateStateChanged(false);
                CleanupFailedSearch(wasSearchActive, searchTextEmpty);
            }
        }

        private bool IsResourceTypeEqual(DataItemBase dataItem,  string resourceTypeToCompare)
        {
            string resourceType = DIResource.GetResourceTypeString(dataItem, IsTagBrowser());
            return resourceType.Equals(resourceTypeToCompare, StringComparison.InvariantCulture);                        
        }

        private void CleanupFailedSearch(bool wasSearchActive, bool searchTextEmpty)
        {
            //Go back to the data sources or controller view if we were looking at search results
            // and a new invalid search was entered
            if (IsQueryBasedSearchActive)
            {
                Path.SavedHighlightedElement = null; //clear since we're transitioning views
                Navigate(this.Path.ActiveElement.DataItem, false, false);
            }
            else
            {
                IsSearchActive = false;

                //Remove the search crumb if it existed
                NotifySearchBreadCrumbChanged(false);

                //Only re-filter the view if we have a non-empty search or if the search was previously active
                if (!searchTextEmpty || wasSearchActive)
                {
                    //ensure data grid column update
                    if (Path.ActiveElement.DataItem != null)
                        NotifyDataGridColsChanged();

                    //notify that the datagrid observable collection has updated so the view can update
                    NotifyDataGridOCChanged(null);
                }
            }
        }


        /// <summary>
        /// apply view level filtering on this data item
        /// </summary>
        /// <param name="dataItem">dataitem</param>
        /// <param name="getFieldValue">value </param>
        /// <returns></returns>
        public bool ApplyViewFilter(DataItemBase dataItem, GetFieldValue getFieldValue)
        {
            //Return from the search/filter VM.  Exposed here for test
            return _searchFilterControlViewModel.ApplyViewFilter(dataItem, getFieldValue);
        }

        #endregion Searching and Filtering

        #region IDataItemBrowserViewModel Members

        #region Initialize

        public IObservableCollection<DataItemBase> DataItems
        {
            get { return _dataItems; }
        }

        private TSObservableCollection<DataItemBase> _dataItems = new TSObservableCollection<DataItemBase>();
        private IClientDataServices _clientDataServices = null;

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="browserType">Type of Browser (Tag or DataType)</param>
        public DataItemBrowserViewModel(DIBClientManager dibClientManager, string browserType)
        {
            // set the visual perspective for the DIB
            BrowserType = browserType;
           
            if (dibClientManager == null)
            {
                throw new ArgumentNullException("DIBClientManager not specified");
            }
            _dibClientManager = dibClientManager;

            //Create the search filter control view model early so it will be available when the control loads
            ObservableCollection<FilterType> filterTypes = _dibClientManager.GetFilterTypes();
            _searchFilterControlViewModel = new SearchFilterControlViewModel(filterTypes){SearchModeEnabled = true};
            if (_dibClientManager.CustomAutoSearchTimerDelay != TimeSpan.Zero)
                _searchFilterControlViewModel.AutoSearchTimerDelay = _dibClientManager.CustomAutoSearchTimerDelay;
            _searchFilterControlViewModel.Initialize(null, this.BrowserType);
        }

         /// <summary>
        /// constructor used by unit testing
        /// </summary>
        /// <param name="browserType">Type of Browser (Tag or DataType)</param>
        /// <param name="searchFilterControlVm">ISearchFilterControlViewModel passed in by unit tests</param>
        public DataItemBrowserViewModel(DIBClientManager clientManager, string browserType, ISearchFilterControlViewModel searchFilterControlVM, IClientDataServices clientClientDataServices)
         {
             BrowserType = browserType;
             _searchFilterControlViewModel = searchFilterControlVM;
             _clientDataServices = clientClientDataServices;
             _dibClientManager = clientManager;
         }

        /// <summary>
        /// initialization routine for the DataItemBrowserViewModel
        /// </summary>
        /// <param name="homeContext">The resource ID to use for the home screen (use null to start at a device listing)</param>
        /// <param name="connectString">String identifying the item to select</param>
        public void Initialize(DataItemBrowserContext homeContext,
                               string connectString)
        {
            try
            {
                IsSearchActive = false;
                IsQueryBasedSearchActive = false;
                IsLastNavigateFromUserSearch = false;
                IsSearchEnabled = IsTagBrowser();

                if (this._dibClientManager.ShouldClearMRUListHistoryOnStartup())
                {
                    ClearSearchMRUListHistory();
                }

                // If the connectString is empty, then use the last Highlighted item to initialize the SelectedItem.
                // This will cause the DIB and the DTB to navigate back to the location of the previously selected tag or data type.
                // The intent is to put the user back into the context of his previous selection.
                if (String.IsNullOrEmpty(connectString))
                {
                    connectString = IsTagBrowser()
                                        ? DIBPersistedVariables.TagBrowser_LastHighLightedItem
                                        : DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem;
                }

                    // For the Datatype Browser, if the datatype specified in the connect string is a UDT, but the user did not prepend the controller
                    // then use the connect string
                else if (!IsTagBrowser() && // Data Type Browser
                         (!string.Equals(connectString, DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem,
                                         StringComparison.CurrentCultureIgnoreCase)) &&
                         // does connect string already equals DataTypeBrowser_LastHighLightedItem;
                         (connectString.IndexOf(DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER) == -1))
                    // connect string does not contain a "."
                {
                    // Is this possibly a UDT without its device?
                    string dt = DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER + connectString;
                    if (DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem.EndsWith(dt, StringComparison.CurrentCultureIgnoreCase))
                        connectString = DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem;
                            // Use last high lighted item              
                }

                if (_clientDataServices == null)
                    _clientDataServices = new ClientDataServices(ref _dataItems, _path, DataServicesLoadComplete, BrowserPerspective, this._dibClientManager);

                _clientDataServices.SetProblemCallback(SetProblemVars);
                _clientDataServices.PropertyChanged += new PropertyChangedEventHandler(_DataServices_PropertyChanged);

                //the data type browser does not support changing the data context
                if (this.BrowserPerspective == DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser)
                    homeContext = null;

                //disable search during datacontext or connect string load, enable when done
                IsSearchEnabled = false;
                _clientDataServices.Initialize(homeContext, (dataContext, error) =>
                        {
                            //create home path element based on the rootPath
                            HomePathElement homePath =
                                PathElementFactory.Instance().CreateHomePathElement(
                                    dataContext.RootPath.DataItemList) as
                                HomePathElement;
                            this.Path.Add(homePath);

                            bool hasError = !string.IsNullOrEmpty(error);
                            if (!hasError)
                            {
                                //check if there is a filter applied first (tag browsing only)
                                if (IsTagBrowser() && dataContext.FilterDefinition != null &&
                                    (dataContext.FilterDefinition.HasNonEmptySearchValue))
                                {
                                    //Show the load spinner
                                    NotifyNavigateStateChanged(true);
                                    //navigate to the home screen and then apply the filter
                                    this.NavigateNoGui(homePath.DataItem, (navError) =>
                                                                            {
                                                                                //make sure the load spinner is still showing for the filter operation, this can
                                                                                //happened when the DataServicesLoadComplete event fires
                                                                                NotifyNavigateStateChanged(true);
                                                                                
                                                                                //this must be called after navigate because navigate clears any search
                                                                                //initialize the search filter control VM with the filter definition
                                                                                this.SearchFilterControlVM.Initialize(dataContext.FilterDefinition);
                                                                                
                                                                                if (this.SearchFilterControlVM.HasError)
                                                                                {
                                                                                    // If the filter has an error (ex. parser error) based on requirements we want 
                                                                                    // to leave the DIB at the home screen and have the search control active
                                                                                    DataServicesLoadComplete(String.Empty);
                                                                                }
                                                                                // apply the filter if there is no parser error
                                                                                else
                                                                                {
                                                                                    ProcessFilter(false);
                                                                                }
                                                                                // Update whether the search control is enabled
                                                                                UpdateIsSearchEnabled();

                                                                                //on a query based search we need to select the item by its full path
                                                                                if (this.IsQueryBasedSearchActive)
                                                                                    //select the selected item
                                                                                    NotifySelectItemAfterLaunchWithSearch(connectString);
                                                                                //set launch with search, selected item path, which is used by DataServicesLoadComplete
                                                                                _launchWithSearchSelectedItemPath = connectString;

                                                                                //if the search is not query based then it will not get a DataServicesLoadComplete 
                                                                                //event to hide the spinner so do it now (view level filtering is almost immediate)
                                                                                if (!this.IsQueryBasedSearchActive)
                                                                                    NotifyNavigateStateChanged(false);
                                                                            });
                                }
                                else if (IsAOGPropertyBrowser())
                                {
                                    // Two cases when browsing AOG properties:
                                    //   1) empty : connectString, create string to drill into the screen properties
                                    //   2) none empty : drill into and attempt to select the specified property
                                    string screenName = string.IsNullOrWhiteSpace(CurrentScreenName) ? DIResource.DI_COMMON_RESOURCETYPE_AOGS : CurrentScreenName;
                                    string propertyName = connectString;
                                    connectString = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER
                                                    + DIResource.DI_COMMON_LOCAL_HMIDEVICE_DISPLAY_NAME 
                                                    + DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER 
                                                    + screenName
                                                    + DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER 
                                                    + propertyName;

                                    //Show the load spinner
                                    NotifyNavigateStateChanged(true);
                                    NavigateString(Path, connectString, dataContext);
                                }
                                //see if we have a connect string path
                                else if (!string.IsNullOrEmpty(connectString))
                                {
                                    //Show the load spinner
                                    NotifyNavigateStateChanged(true);
                                    if (_dibClientManager.IsGenericDIBBrowser())
                                    {
                                        NavigateDIBString(Path, connectString, dataContext);
                                    }
                                    else
                                    {
                                        NavigateString(Path, connectString, dataContext);
                                    }
                                }
                                else
                                {
                                    Navigate(dataContext.RootPath.DataItem);
                                    //update search state after datacontext or connect string load is complete in tag browser
                                    UpdateIsSearchEnabled();
                                }

                            }
                            else
                            {
                                NotifyNavigateStateChanged(false);
                            }
                        });                
            }
            catch (Exception ex)
            {
                LogWrapper.LogException("DataItemBrowserViewModel Initialize Exception: ", ex);  
                return;
            }

            // listen for Path property change notifications
            Path.PropertyChanged += new PropertyChangedEventHandler(Path_PropertyChanged);
            Path.AddActivePathChangedEventHandler(
                new System.ComponentModel.PropertyChangedEventHandler(Path_ActivePathChanged));
        }

        private void _DataServices_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            //if the dataview has changed then send event on to listener
            if (e.PropertyName == "DataView")
            {
                NotifyDataViewChanged();
            }
        }

        #endregion Initialize

        #region Close

        /// <summary>
        /// Must be called before garbage collecting the view model
        /// </summary>
        public void Close()
        {
            LogWrapper.DibStartUpLog.Info("Initiated DataItemBrowserViewModel.Close ...");
            // clean-up Path event handler
            Path.PropertyChanged -= new PropertyChangedEventHandler(Path_PropertyChanged);

            // Clearing path to remove event handler for each path element
            Path.Clear();

            try
            {
                // Tell CDS to Close, not Shutdown. 
                // 'Close' will close the DIB but leave DibQuery reference and connections active
                _clientDataServices.Close();
            }
            catch (Exception ex)
            {
                LogWrapper.LogException("DataItemBrowserViewModel Close Exception: ", ex);  
                return;
            }

            LogWrapper.DibStartUpLog.Debug("... Completed DataItemBrowserViewModel.Close.");   
        }

        #endregion Close

        #region Navigation

        /// <summary>
        /// Navigation when all you have is the string of the dataitem's path
        /// Build the "path" representation of the "fullpath".
        /// </summary>
        /// <param name="path">path to manipulate</param>
        /// <param name="fullPath">dataitem's path </param>
        /// <param name="dataContext">data context of the navigation</param>
        public void NavigateString(Path path, string fullPath, DataContext dataContext)
        {
            _connectStringProcessor = new ConnectStringProcessor(path, this, dataContext);
            _connectStringProcessor.NavigateString(fullPath, (navigatedTo, highlighteditem) =>
                {
                    NotifyDataGridColsChanged();
                    if (highlighteditem != null)
                    {
                        // Path.Last will become the SavedHighlightedElement
                        IPathElement savedHighlightedElement = Path.Last;
                        // The previous element becomes the Active one
                        Path.SetActive(Path.Back);
                        // Removes the SavedHighLightedItem from the collection
                        Path.RemoveInactiveElements();
                        // Reestablish the SavedHighlightedElement
                        Path.SavedHighlightedElement = savedHighlightedElement;
                        //Ensure the path is updated (the grid will do this as well but we need to be correct at all times
                        // for ViewModel based automated test which would not receive the grid view path on selected item changed
                        Path.HighlightedElement = savedHighlightedElement;
                    }

                    if (navigatedTo != null)
                    {
                        // A navigate has occurred in the connect string processing.
                        // Don't do another one again, as this could cause a a severe performance 
                        // hit (for instance into a very large array).
                        DataServicesLoadComplete(String.Empty);
                    }
                    else if (navigatedTo == null && !String.IsNullOrEmpty(ProblemText))
                    {
                        //The connect string navigate failed so forward on a data load complete with the
                        // error text
                        DataServicesLoadComplete(ProblemText);
                    }
                    else if (dataContext != null && dataContext.HasRoot())
                    {
                        // Invalid device name in connect string, navigate to datacontext's root
                        Navigate(dataContext.RootPath.DataItem);
                    }
                    else
                    {
                        // Invalid connect string, nothing was navigated to
                        // Clean out last highlighted item, selected item will already be empty so just send
                        // the notification to simulate/force the change
                        PersistLastHighlightedItem(string.Empty);
                        NotifySelectedItemPathChanged();
                        
                        // Navigate to DSV
                        Navigate(null);
                    }
                });
        }

        /// <summary>
        /// Executes a navigate to the children of the passed data item
        /// </summary>
        /// <param name="dataItem">The data item to show the children of (drill in to)</param>
        /// <param name="clearSearch">Whether the search should be cleared as a result of the call</param>
        /// <param name="fromUserSearch">Whether the navigate was called as a result of a search operation</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1026:DefaultParametersShouldNotBeUsed",Justification = "Called from too many places")]
        public void Navigate(DataItemBase dataItem, bool clearSearch = true, bool fromUserSearch = false)
        {
            IsLastNavigateFromUserSearch = fromUserSearch;

            LogWrapper.DibGeneralLog.Info("Received DataItemBrowserViewModel.Navigate for DataItem: " + (dataItem == null? "null": dataItem.ToString()));  

            //TAF actors may result in this being called with a data item which is not structured
            // If that is the case, "simulate" a navigate complete, but don't really do anything
            if (dataItem != null && !dataItem.IsStructured)
            {
                NotifyNavigateComplete();
                return;
            }

            // Prior to navigating (which could take awhile depending on the number of dataitems)
            // disable or enable the search control based on Path.ActiveElement
            UpdateIsSearchEnabled();

            if (clearSearch)
            {
                //Hide any search crumb / inactivate the search / and save that we're not in a search
                NotifySearchBreadCrumbChanged(false);
                _searchFilterControlViewModel.ClearSearch();

                //If we're transitioning away from a search, clear the saved highlighted element
                //as the view after clearing the search may not contain the saved item          
                if (IsSearchActive || IsQueryBasedSearchActive)
                {
                    this.Path.SavedHighlightedElement = null;
                    IsSearchActive = false;
                    IsQueryBasedSearchActive = false;
                }
            }

            //Show the load spinner
            NotifyNavigateStateChanged(true);

            UpdateFolderDataItems(dataItem);

            //Use our data service to perform the actual drill in    
            bool issuedQuery = _clientDataServices != null && _clientDataServices.DrillIn(dataItem);

            //Update the grid columns based on the drill in (as long as we issued a query)            
            if (issuedQuery)
                NotifyDataGridColsChanged();
            
        }

        public void NavigateDIBString(Path path, string fullPath, DataContext dataContext)
        {
            List<DataItemBase> navigateList = _dibClientManager.GetDataItemsFromPath(fullPath);
            if (navigateList == null || navigateList.Count == 0)
            {
                // dib user does not want the DIB to auto-drill-in.  
                // dib user can build the breadcrumbs by overriding PopulatePathWithInitialItemsBeforeHomeLaunch 
                Navigate(null);
                return;
            }

            _connectStringProcessor = new ConnectStringProcessor(path, this, dataContext);
            _connectStringProcessor.NavigateString(navigateList, (navigatedTo, highlighteditem) =>
            {
                NotifyDataGridColsChanged();

                if (navigatedTo != null)
                {
                    // A navigate has occurred in the connect string processing.
                    // Don't do another one again, as this could cause a severe performance 
                    // hit (for instance into a very large array).
                    DataServicesLoadComplete(String.Empty);
                }
                else if (navigatedTo == null && !String.IsNullOrEmpty(ProblemText))
                {
                    //The connect string navigate failed so forward on a data load complete with the
                    // error text
                    DataServicesLoadComplete(ProblemText);
                }
                else if (dataContext != null && dataContext.HasRoot())
                {
                    // Invalid device name in connect string, navigate to datacontext's root
                    Navigate(dataContext.RootPath.DataItem);
                }
                else
                {
                    // Invalid connect string, nothing was navigated to
                    // Clean out last highlighted item, selected item will already be empty so just send
                    // the notification to simulate/force the change
                    PersistLastHighlightedItem(string.Empty);
                    NotifySelectedItemPathChanged();

                    // Navigate to DSV
                    Navigate(null);
                }
            });

        }

        /// <summary>
        /// Update the TagsAndProperties, Programs, DataLog, and Screens DataItems so they are aware of the specific controller or HMIDevice
        /// </summary>
        /// <param name="dataItem">dataItem to consider</param>
        private void UpdateFolderDataItems(DataItemBase dataItem)
        {
            // give the host a chance to populate the breadcrumbs
            if (dataItem == null)
            {
                this._dibClientManager.PopulatePathWithInitialItemsBeforeHomeLaunch(this.Path, _clientDataServices.QueryCache);
            }

            if (_clientDataServices != null && DIResource.IsFolderItem(dataItem))
            {
                string newValue = string.Empty;
                //make sure back exists, this can happen if the home is a tags and properties pathelement
                if (Path.Back == null)
                {
                    HomePathElement homePE = Path.ActiveElement as HomePathElement;
                    if (homePE != null && homePE.ParentDataItem != null)
                        newValue = homePE.ParentDataItem.CommonID;
                }
                else
                {
                    newValue = Path.Back.DataItem.CommonID;
                }
                dataItem.CommonID = newValue;
            }
        }

        /// <summary>
        /// Executes a navigate to the children of the passed data item
        /// </summary>
        /// <param name="parentItem">Item to navigate to</param>
        /// <param name="callback">Delegate to be called after the data items are loaded</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1725:ParameterNamesShouldMatchBaseDeclaration", MessageId = "0#",Justification = "parameter name is more descriptive")]
        public void NavigateNoGui(DataItemBase parentItem, DataLoadComplete callback)
        {
            UpdateFolderDataItems(parentItem);
            _clientDataServices.DrillIn(parentItem, callback);
        }

        #endregion Navigation

        #region ItemSelectionChangedCommand

        /// <summary>
        /// Item Selection Changed  command
        /// </summary>
        public ICommand ItemSelectionChangedCommand
        {
            get
            {
                if (_itemSelectionChangedCommand == null)
                {
                    _itemSelectionChangedCommand = new SimpleCommand()
                                                       {
                                                           ExecuteDelegate = x =>
                                                                                 {
                                                                                     //Ignore item highlighting when search is active since we may not have the full path
                                                                                     // available to construct the string and resource id based properties to a client
                                                                                     if (IsSearchActive)                                                                                     
                                                                                         return;                                                                                     

                                                                                     List<IPathElement>selectedPathList = this.Path.SelectedPath;

                                                                                     // Make sure to check whether we have any items in the path
                                                                                     // list as we won't upon navigating home
                                                                                     if (selectedPathList.Count == 0)
                                                                                     {
                                                                                         SelectedItemPath = String.Empty;
                                                                                     }
                                                                                     else
                                                                                     {
                                                                                         PathElementBase selectedItemName = x as PathElementBase;
                                                                                         if (selectedItemName != null)
                                                                                         {
                                                                                             Path.HighlightedElement = selectedItemName;
                                                                                             selectedPathList.Add(Path.HighlightedElement);
                                                                                         }

                                                                                         SelectedItemPath = this.PathToString(selectedPathList,null);
                                                                                     }
                                                                                 }
                                                       };
                }
                return _itemSelectionChangedCommand;
            }
        }

        #endregion ItemSelectionChangedCommand

        /// <summary>
        /// converts a <see cref="List<IPathElement>"/> and optional NameToSelect into a full connection path
        /// </summary>
        /// <param name="fullPath">list of IPathElement objects</param>
        /// <param name="nameToSelect">the selected item component of a full Path</param>
        /// <returns>string representing the full connection path</returns>
        public string PathToString(List<IPathElement> fullPath, string nameToSelect)
        {
            return _dibClientManager.PathToString(fullPath, nameToSelect, BrowserPerspective);
        }

        #region SelectedItemCommand

        /// <summary>
        /// Item Selection Changed command
        /// </summary>
        public ICommand SelectedItemCommand
        {
            get
            {
                if (_selectedItemCommand == null)
                {
                    _selectedItemCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {
                            DataItemBase selectedDataItemBase = x as DataItemBase;
                                        
                            //If an item was selected from the search results, 
                            //we need to make a call to create path elements
                            if (this.IsQueryBasedSearchActive)
                            {
                                this.IsQueryBasedSearchActive = false;

                                //If the callback is used, return since we'll run the actual SelectedItemCommand from the callback itself
                                bool usedCallback = this.PopulatePathFromDataItemPath(selectedDataItemBase, (error) =>
                                {
                                    if (String.IsNullOrEmpty(error))                                                                                    
                                    {
                                        this.SelectedItemCommand.Execute(x);
                                    }
                                });
                                if (usedCallback) return;
                            }

                            // Select a non-search item
                            List<IPathElement> selectedPathList = this.Path.SelectedPath;

                            AddSelectedNodeToList(selectedDataItemBase, selectedPathList);

                            SelectedItemPath = this.PathToString(selectedPathList, null);
                            if (IsAOGPropertyBrowser())
                            {
                                // for AOG browsing, remove AOG screen name and everything before it.
                                string screenName = string.IsNullOrWhiteSpace(CurrentScreenName) ? DIResource.DI_COMMON_RESOURCETYPE_AOGS : CurrentScreenName;

                                int itemLocation = SelectedItemPath.IndexOf(screenName);
                                if (itemLocation >= 0 && SelectedItemPath.Length > itemLocation + screenName.Length)
                                {
                                    SelectedItemPath = SelectedItemPath.Substring(itemLocation + screenName.Length + 1);
                                }
                                else
                                {
                                    SelectedItemPath = string.Empty;
                                }
                            }

                            //not updating the userSetHighlightedPath through the gridview during search, 
                            //so we are updating it after a select if we are in search mode
                            if (IsSearchActive)
                            {
                                Path.UserSetHighlightedPath = selectedPathList;
                                this.UserSetHighlightedItemCommand.Execute(x);
                            }

                            //create and generate the CompositeDataItem using SelectedPathList
                            this.SelectedCompositeDataItem = new CompositeDataItem(selectedPathList, BrowserPerspective);
                            this.SelectedDataItemBase = selectedDataItemBase;

                            this.NotifyDoubleClickSelect();
                            }
                    };
                }
                return _selectedItemCommand;
            }
        }

        #endregion SelectedItemCommand

        /// <summary>
        /// Adds the DataItemBase to the List of IPathElements
        /// </summary>
        /// <param name="selectedDataItemBase"></param>
        /// <param name="selectedPathList"></param>
        private static void AddSelectedNodeToList(DataItemBase selectedDataItemBase, List<IPathElement> selectedPathList)
        {            
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(selectedDataItemBase);
            selectedPathList.Add(pathElement);
        }

        #region UserSetHighlightedItemCommand

        /// <summary>
        /// User-driven highlighted item changed command
        /// </summary>
        public ICommand UserSetHighlightedItemCommand
        {
            get
            {
                if (_userSetHighlightedItemCommand == null)
                {
                    _userSetHighlightedItemCommand = new SimpleCommand()
                                                         {
                                                             ExecuteDelegate = x =>
                                                            {                                                                
                                                                //contains the whole path including item                                                                                    
                                                                List<IPathElement> userSetHighlightedPathList = this.Path.UserSetHighlightedPath;

                                                                UserSetHighlightedItemPath = this.PathToString(userSetHighlightedPathList,null);

                                                                //create and generate the CompositeDataItem using SelectedPathList
                                                                this.UserSetHighlightedItemResourceID = new CompositeDataItem(userSetHighlightedPathList,BrowserPerspective);
                                                            }
                                                         };
                }
                return _userSetHighlightedItemCommand;
            }
        }

        #endregion UserSetHighlightedItemCommand

        #region GetChildren

        /// <summary>
        /// get the datasource children for droparrow navigation
        /// </summary>
        /// <param name="dataSourceName">datasource name, can be empty string</param>
        /// <returns>list of droparrow items</returns>
        public List<DropArrowItem> getChildren(string dataSourceName, ACrumb hostCrumb)
        {
            //Get the name of the next item
            IPathElement nextPathElem = Path.GetPathElementAfterThisDataSource(dataSourceName);
            string nextItemName = nextPathElem != null ? nextPathElem.DisplayName : String.Empty;
            return _clientDataServices.GetChildrenOfCrumb(hostCrumb, nextItemName);
        }

        #endregion GetChildren

        public void CleanupEventSubscriptions()
        {
            Path.PropertyChanged -= new PropertyChangedEventHandler(Path_PropertyChanged);
            Path.RemoveActivePathChangedEventHandler(new System.ComponentModel.PropertyChangedEventHandler(Path_ActivePathChanged));
        }

        /// <summary>
        /// Get the list of cached devices
        /// </summary>
        /// <returns>ICollection<DataItemBase> representing the Devices</returns>
        public ICollection<DataItemBase> GetCachedDevices()
        {
            if (_clientDataServices == null) return null;
            return _clientDataServices.GetCachedDevices();
        }

        #endregion IDataItemBrowserViewModel Members

      /// <summary>
      /// Is the current view displayed in the grid?
      /// </summary>
        public bool IsGridView()
        {
            return _clientDataServices.DataView.IsGridView();
        }

        /// <summary>
        /// Is the current view displayed a list view?
        /// </summary>
        public bool IsListView()
        {
            return _clientDataServices.DataView.IsListView();
        }
               
        /// <summary>
        /// Is the current view displayed a web view?
        /// </summary>
        public bool IsWebView()
        {
            return _clientDataServices.DataView.IsWebView();
        }
                
        /// <summary>
        /// Is the current view displayed a data source view?
        /// </summary>
        public bool IsTreeView()
        {
            return _clientDataServices.DataView.IsTreeView();
        }
             
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion

        /// <summary>
        /// Refresh our current view.
        /// This adds ability for DIBCLientManagers to refresh GUI for any reason
        /// </summary>
        internal void RefreshCurrentView()
        {
            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.SystemIdle, (Action)(() =>
            {
                DataItemBase itemToNavigate = (Path.ActiveElement == null ? null : Path.ActiveElement.DataItem);
                this.Navigate(itemToNavigate);
            }));
        }
    }
}