﻿using RockwellAutomation.UI.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.DIBQuery;

namespace DataItemBrowserUT
{
  
    /// <summary>
    ///This is a test class for ConnectStringTest and is intended
    ///to contain all ConnectStringTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ConnectStringTest
    {        
        private PrivateObject _connectStringProcessorPrivate = null;
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //

        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            DataItemBrowserViewModel dibVM = null;            
            Path path = null;
            DataContext dataContext = null;            
            ConnectStringProcessor _connectStringProcessor = new ConnectStringProcessor(path,dibVM,dataContext);
            _connectStringProcessorPrivate = new PrivateObject(_connectStringProcessor);                       
        }

        //
        //Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {
            _connectStringProcessorPrivate = null;
        }
        
        #endregion


        /// <summary>
        ///A test for ConnectString Constructor
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ConnectStringConstructorTest()
        {
           
            Assert.IsTrue((null == _connectStringProcessorPrivate.GetFieldOrProperty("_dibVM")), "Assignment to _dibVM failed");            
            Assert.IsTrue((null == _connectStringProcessorPrivate.GetFieldOrProperty("_path")), "Assignment to _path failed");
            Assert.IsTrue((null == _connectStringProcessorPrivate.GetFieldOrProperty("_dataContext")), "Assignment to _dataContext failed");
        } 

        /// <summary>
        ///A test for INITIAL and TERMINAL
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void CheckForInitialAndTerminalTokens()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", string.Empty);
            bool actual = (bool)_connectStringProcessorPrivate.Invoke("GetToken");
            Assert.IsFalse(actual, "GetToken returned true");
            Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("INITIAL"), "Current token is not INITIAL");
            Assert.IsTrue(GetTokensProperty("NextGroup") == GetTokenString("TERMINAL"), "Next token is not TERMINAL");
        } // Test

        PrivateObject GetTokens()
        {
            object tokensObj = _connectStringProcessorPrivate.GetFieldOrProperty("_tokens");
            return new PrivateObject(tokensObj);
        }

        string GetTokensProperty(string prop)
        {
            return (string)(GetTokens().GetFieldOrProperty(prop));
        }

        string GetTokenString(string enumString)
        {            
            PrivateType TokenType = new PrivateType(typeof (Tokens));
            string val = (string)TokenType.GetStaticFieldOrProperty(enumString);
            return val;
        }

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\@DL
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_DataLog_Name()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom\@DataLogs\DataLog1");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DATALOGS"), "Must be DATALOGS");
                        Assert.IsTrue(GetTokensProperty("Name") == GetTokenString("DATALOGS"), "Must be DataLogs");
                       break;
                    case 3:
                       Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DATALOG"), "Must be DATALOG");
                       Assert.IsTrue(GetTokensProperty("Name") == "DataLog1", "Must be DataLog1");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\@DataLogs\
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_DataLog_Indicator()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom\@DataLogs\");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DATALOGS"), "Must be DataLogs");
                        Assert.IsTrue(GetTokensProperty("Name") == GetTokenString("DATALOGS"), "Must be DataLogs");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DRILLIN"), "Must be DRILLIN");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Program_Indicator()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom\");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DRILLIN"), "Must be DRILLIN");
                        break;
                    case 3:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\1 (invalid bit)
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Program_NamedBit()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom\1");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.AreEqual(GetTokenString("DEVICE"), GetTokensProperty("Group"), "Must be DEVICE");
                        Assert.AreEqual("MixingRoom", GetTokensProperty("Name"), "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.AreEqual(GetTokenString("PROGRAMS"), GetTokensProperty("Group"), "Must be PROGRAMS");
                        break;
                    case 3:
                        Assert.AreEqual(GetTokenString("PROGRAM"), GetTokensProperty("Group"), "Must be PROGRAM");
                        Assert.AreEqual("  1", GetTokensProperty("Name"), "Must be <space>*1");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\1a1 (invalid name)
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Program_NumericStartName()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom\1a1");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.AreEqual(GetTokenString("DEVICE"), GetTokensProperty("Group"), "Must be DEVICE");
                        Assert.AreEqual("MixingRoom", GetTokensProperty("Name"), "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.AreEqual(GetTokenString("PROGRAMS"), GetTokensProperty("Group"), "Must be PROGRAMS");
                        break;
                    case 3:
                        Assert.AreEqual(GetTokenString("PROGRAM"), GetTokensProperty("Group"), "Must be PROGRAM");
                        Assert.AreEqual("1a", GetTokensProperty("Name"), "Must be 1a");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\= (invalid symbol)
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Program_SymbolName()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom\=");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.AreEqual(GetTokenString("DEVICE"), GetTokensProperty("Group"), "Must be DEVICE");
                        Assert.AreEqual("MixingRoom", GetTokensProperty("Name"), "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.AreEqual(GetTokenString("PROGRAMS"), GetTokensProperty("Group"), "Must be PROGRAMS");
                        break;
                    case 3:
                        Assert.AreEqual(GetTokenString("PROGRAM"), GetTokensProperty("Group"), "Must be PROGRAM");
                        Assert.AreEqual("=", GetTokensProperty("Name"), "Must be =");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\a
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Program_SingleAlpha()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom\a");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.AreEqual(GetTokenString("DEVICE"), GetTokensProperty("Group"), "Must be DEVICE");
                        Assert.AreEqual("MixingRoom", GetTokensProperty("Name"), "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.AreEqual(GetTokenString("PROGRAMS"), GetTokensProperty("Group"), "Must be PROGRAMS");
                        break;
                    case 3:
                        Assert.AreEqual(GetTokenString("PROGRAM"), GetTokensProperty("Group"), "Must be PROGRAM");
                        Assert.AreEqual("a", GetTokensProperty("Name"), "a");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1.T1
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Name()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", "::MixingRoom.Tag_3_UDT");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                         Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                         Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                         break;
                    case 2:
                         Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                         break;
                    case 3:
                         Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                         Assert.IsTrue(GetTokensProperty("Name") == "Tag_3_UDT", "Must be Tag_3_UDT");
                         break;
                    case 4:
                         Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                         break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1._T1
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Name_Underscore()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", "::MixingRoom._Tag_3_UDT");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "_Tag_3_UDT", "Must be _Tag_3_UDT");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1.T1[
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Name_Bracquet()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", "::MixingRoom.Tag_3_UDT[");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Tag_3_UDT", "Must be Tag_3_UDT");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("BRACQUET_TERMINATOR"), "Must be BRACQUET_TERMINATOR");
                        break;
                    case 5:
                         Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                         break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\P1.T1[1,1,1]
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Program_Name_ArrayIndex()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1.Ph_ModuleDefined_WithArray_O3[1,1,1]");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAMS"), "Must be PROGRAMS");
                        Assert.IsTrue(GetTokensProperty("Name") == string.Empty, "Must be empty");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAM"), "Must be PROGRAM");
                        Assert.IsTrue(GetTokensProperty("Name") == "Phase_1", "Must be Phase_1");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Ph_ModuleDefined_WithArray_O3", "Must be Ph_ModuleDefined_WithArray_O3");
                        break;
                    case 5:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("ARRAY_INDEX"), "Must be ARRAY_INDEX");
                        Assert.IsTrue(GetTokensProperty("Name") == "[1,1,1]", "Must be [1,1,1]");
                        break;
                    case 6:
                         Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\P1.T1[1,1,1
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Program_Name_ARRAY_INDEX_TERMINATOR()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1.Ph_ModuleDefined_WithArray_O3[1,1,1");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAMS"), "Must be PROGRAMS");
                        Assert.IsTrue(GetTokensProperty("Name") == string.Empty, "Must be empty");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAM"), "Must be PROGRAM");
                        Assert.IsTrue(GetTokensProperty("Name") == "Phase_1", "Must be Phase_1");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Ph_ModuleDefined_WithArray_O3", "Must be Ph_ModuleDefined_WithArray_O3");
                        break;
                    case 5:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("ARRAY_INDEX_TERMINATOR"), "Must be ARRAY_INDEX_TERMINATOR");
                        Assert.IsTrue(GetTokensProperty("Name") == "[1,1,1", "Must be [1,1,1");
                        break;
                    case 6:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\P1.T1[1,1,1].
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Program_Name_ArrayIndex_Dot()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1.Ph_ModuleDefined_WithArray_O3[1,1,1]");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAMS"), "Must be PROGRAMS");
                        Assert.IsTrue(GetTokensProperty("Name") == string.Empty, "Must be empty");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAM"), "Must be PROGRAM");
                        Assert.IsTrue(GetTokensProperty("Name") == "Phase_1", "Must be Phase_1");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Ph_ModuleDefined_WithArray_O3", "Must be Ph_ModuleDefined_WithArray_O3");
                        break;
                    case 5:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("ARRAY_INDEX"), "Must be ARRAY_INDEX");
                        Assert.IsTrue(GetTokensProperty("Name") == "[1,1,1]", "Must be [1,1,1]");
                        break;
                    case 6:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test



        /// <summary>
        ///A test for ParseTagBrowserConnectString - Blanks in Array Index
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Blanks_In_ArrayIndex()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1.Ph_ModuleDefined_WithArray_O3[ 1, 1, 1]");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.AreEqual(GetTokenString("DEVICE"), GetTokensProperty("Group"), "Must be DEVICE");
                        Assert.AreEqual(GetTokensProperty("Name"), "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.AreEqual(GetTokenString("PROGRAMS"), GetTokensProperty("Group"), "Must be PROGRAMS");
                        Assert.AreEqual(string.Empty, GetTokensProperty("Name"), "Must be empty");
                        break;
                    case 3:
                        Assert.AreEqual(GetTokenString("PROGRAM"), GetTokensProperty("Group"), "Must be PROGRAM");
                        Assert.AreEqual("Phase_1", GetTokensProperty("Name"), "Must be Phase_1");
                        break;
                    case 4:
                        Assert.AreEqual(GetTokenString("MEMBER_NAME"), GetTokensProperty("Group"), "Must be MEMBER_NAME");
                        Assert.AreEqual("Ph_ModuleDefined_WithArray_O3", GetTokensProperty("Name"), "Must be Ph_ModuleDefined_WithArray_O3");
                        break;
                    case 5:
                        Assert.AreEqual(GetTokenString("INVALIDNAME"), GetTokensProperty("Group"), "Must be INVALIDNAME");
                        Assert.AreEqual("[", GetTokensProperty("Name"), "Must be [");
                        break;
                    case 6:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\P1.Name
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Program_Name()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1.Ph_Alarm_PreDefArray2");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAMS"), "Must be PROGRAMS");
                        Assert.IsTrue(GetTokensProperty("Name") == string.Empty, "Must be empty");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAM"), "Must be PROGRAM");
                        Assert.IsTrue(GetTokensProperty("Name") == "Phase_1", "Must be Phase_1");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Ph_Alarm_PreDefArray2", "Must be Ph_Alarm_PreDefArray2");
                        break;
                    case 5:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\P1.Name.Name
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Program_Name_Name()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1.Ph_Alarm_PreDefArray2.xyzzy");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAMS"), "Must be PROGRAMS");
                        Assert.IsTrue(GetTokensProperty("Name") == string.Empty, "Must be empty");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAM"), "Must be PROGRAM");
                        Assert.IsTrue(GetTokensProperty("Name") == "Phase_1", "Must be Phase_1");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Ph_Alarm_PreDefArray2", "Must be Ph_Alarm_PreDefArray2");
                        break;
                    case 5:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "xyzzy", "Must be xyzzy");
                        break;
                    case 6:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\P1.Name.
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Program_Name_Dot()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1.Ph_Alarm_PreDefArray2.");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAMS"), "Must be PROGRAMS");
                        Assert.IsTrue(GetTokensProperty("Name") == string.Empty, "Must be empty");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAM"), "Must be PROGRAM");
                        Assert.IsTrue(GetTokensProperty("Name") == "Phase_1", "Must be Phase_1");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Ph_Alarm_PreDefArray2", "Must be Ph_Alarm_PreDefArray2");
                        break;
                    case 5:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DOT_TERMINATOR"), "Must be DOT_TERMINATOR");
                        break;
                    case 6:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DRILLIN"), "Must be DRILLIN");
                        break;
                    case 3:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1.
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Dot()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom.");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DRILLIN"), "Must be DRILLIN");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\P1
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Program()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAMS"), "Must be PROGRAMS");
                        Assert.IsTrue(GetTokensProperty("Name") == string.Empty, "Must be empty");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAM"), "Must be PROGRAM");
                        Assert.IsTrue(GetTokensProperty("Name") == "Phase_1", "Must be Phase_1");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1\P1.
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Program_Dot()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::PackagingLine\Phase_1");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAMS"), "Must be PROGRAMS");
                        Assert.IsTrue(GetTokensProperty("Name") == string.Empty, "Must be empty");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("PROGRAM"), "Must be PROGRAM");
                        Assert.IsTrue(GetTokensProperty("Name") == "Phase_1", "Must be Phase_1");
                        break;
                    case 4:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1.T1.Bit
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Name_Bit()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", "::MixingRoom.Local:1:C.2");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Local:1:C", "Must be Local:1:C");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("BIT"), "Must be BIT");
                        break;
                    case 5:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1.T1.Bit.
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Name_Bit_Dot()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", "::MixingRoom.Local:1:C.RealTimeSample.2.");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Local:1:C", "Must be Local:1:C");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "RealTimeSample", "Must be RealTimeSample");
                        break;
                    case 5:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("BIT"), "Must be BIT");
                        break;
                    case 6:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1.T1.Bit.Bit
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Name_Name_Bit_Bit()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", @"::MixingRoom.Local:1:C.RealTimeSample.2.3");
            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "Local:1:C", "Must be Local:1:C");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "RealTimeSample", "Must be RealTimeSample");
                        break;
                    case 5:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("BIT"), "Must be BIT");
                        Assert.IsTrue(GetTokensProperty("Name") == "  2", "Must be \"  2\"");
                       break;
                    case 6:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                       break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1.T1[]
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Name_ArrayIndex()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", "::MixingRoom.GuardDoorOpen[0,0,0]");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "GuardDoorOpen", "Must be GuardDoorOpen");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("ARRAY_INDEX"), "Must be ARRAY_INDEX");
                        Assert.IsTrue(GetTokensProperty("Name") == "[0,0,0]", "Must be [0,0,0]");
                        break;
                    case 5:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
       } // Test

        /// <summary>
        ///A test for ParseTagBrowserConnectString - ::C1.T1[].
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_Name_ArrayIndex_Dot()
        {
            _connectStringProcessorPrivate.Invoke("ParseTagBrowserConnectString", "::MixingRoom.GuardDoorOpen[0,0,0].");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "MixingRoom", "Must be MixingRoom");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("TAGS_AND_PROPERTIES"), "Must be TAGS_AND_PROPERTIES");
                        break;
                    case 3:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("MEMBER_NAME"), "Must be MEMBER_NAME");
                        Assert.IsTrue(GetTokensProperty("Name") == "GuardDoorOpen", "Must be GuardDoorOpen");
                        break;
                    case 4:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("ARRAY_INDEX"), "Must be ARRAY_INDEX");
                        Assert.IsTrue(GetTokensProperty("Name") == "[0,0,0]", "Must be [0,0,0]");
                        break;
                    case 5:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DRILLIN"), "Must be DRILLIN");
                        break;
                    case 6:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseDataTypeBrowserConnectString - DataTypeName
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_DataTypeName()
        {
            _connectStringProcessorPrivate.Invoke("ParseDataTypeBrowserConnectString", "Alarm");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DATA_TYPE"), "Must be DATA_TYPE");
                        Assert.IsTrue(GetTokensProperty("Name") == "Alarm", "Must be Alarm");
                        break;
                    case 2:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test

        /// <summary>
        ///A test for ParseDataTypeSelector - ::c1.DT
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Parse_Controller_DataType()
        {
            _connectStringProcessorPrivate.Invoke("ParseDataTypeBrowserConnectString", "::PackagingLine.booltest");

            GetTokens().Invoke("Reset");
            int i = 0;
            while (GetTokensProperty("Group") != GetTokenString("TERMINAL"))
            {
                ++i;
                switch (i)
                {
                    case 1:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DEVICE"), "Must be DEVICE");
                        Assert.IsTrue(GetTokensProperty("Name") == "PackagingLine", "Must be PackagingLine");
                        break;
                    case 2:
                        Assert.IsTrue(GetTokensProperty("Group") == GetTokenString("DATA_TYPE"), "Must be DATA_TYPE");
                        Assert.IsTrue(GetTokensProperty("Name") == "booltest", "Must be booltest");
                        break;
                    case 3:
                        Assert.Fail("Unexpected Token = " + GetTokensProperty("Group") + "(" + GetTokensProperty("Name") + ")");
                        break;
                }
                GetTokens().Invoke("Next");
            }
        } // Test
        
    } // Class


} // Namespace
