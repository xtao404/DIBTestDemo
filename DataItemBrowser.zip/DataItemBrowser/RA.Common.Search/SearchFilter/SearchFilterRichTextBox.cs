﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Documents;
using RockwellAutomation.UI.CommonControls.SearchFilter.ViewModels;
using RockwellAutomation.UI.CommonControls.ViewModels;
using System.Windows.Media;
using System.Windows;

namespace RockwellAutomation.UI.CommonControls
{
    /// <summary>
    /// The rich text box used in the search filter control (underlines any invalid syntax with the standard red wavy brush)
    /// </summary>
    class SearchFilterRichTextBox : RichTextBox, IDisposable
    {
        private DrawingBrush _underlineBrush = null;
        private ISearchFilterControlViewModel _viewModel;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="viewModel">passed in for unit testing, default set to null</param>
        public SearchFilterRichTextBox()
        {
            this.Initialize(null);

            DataObject.AddPastingHandler(this, TextBoxPastingEventHandler);
        }

        /// <summary>
        /// used for unit testing
        /// </summary>
        /// <param name="viewModel">passed in for unit testing, default set to null</param>
        public void Initialize(ISearchFilterControlViewModel viewModel)
        {
            _viewModel = viewModel;
        }

        private ISearchFilterControlViewModel viewModel
        {
            get
            {
                if (_viewModel == null)
                    return this.DataContext as SearchFilterControlViewModel;
                return _viewModel;
            }
           
        }

        //Dependency property backed for the value of the Text standard .NET property such that data binding
        // can occur in our style templates
        public string SearchText
        {
            get { return (string)GetValue(SearchTextProperty); }
            set { SetValue(SearchTextProperty, value); }
        }

        //Using a DependencyProperty as the backing store for SearchText.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SearchTextProperty =
            DependencyProperty.Register("SearchText", typeof(string), typeof(SearchFilterRichTextBox), new UIPropertyMetadata(String.Empty));
       
        /// <summary>
        /// Gets/Sets the text content of the rich text box (setting will move the caret to the end of the control)
        /// </summary>
        public String Text
        {
            get
            {
                return RawTextRangeText.Replace((char)160, ' ');
            }
            set
            {
                TextRange searchTextRange = new TextRange(this.Document.ContentStart, this.Document.ContentEnd);
                searchTextRange.Text = value;

                //Make sure the caret is set to the end of the text since the assignment above will set the
                // caret to the beginning by default
                this.CaretPosition = this.Document.ContentEnd;
            }
        }

        /// <summary>
        /// Returns the raw text from the text range (no space replacement performed)
        /// </summary>
        private String RawTextRangeText
        {
            get
            {
                return (new TextRange(this.Document.ContentStart, this.Document.ContentEnd).Text).Replace("\r\n", String.Empty);
            }
        }

        /// <summary>
        /// Handler for the on text changed event.  Search text is what is data bound to the text box but the Text
        /// property is set at various places by various clients in code and in these situations, we need to make
        /// sure that the value that gets programmatically set is represented in the search control (i.e. SearchText)
        /// </summary>
        /// <param name="e"></param>
        protected override void OnTextChanged(TextChangedEventArgs e)
        {
            base.OnTextChanged(e);

            //Keep the search text property in sync with the text property
            string TextBoxText = this.RawTextRangeText;
            if (SearchText != TextBoxText)
            {
                SearchText = TextBoxText;

                UpdateRichTextBoxFormatting();
            }
        }

        protected override void OnPreviewGotKeyboardFocus(System.Windows.Input.KeyboardFocusChangedEventArgs e)
        {
            base.OnPreviewGotKeyboardFocus(e);

            SetSyntaxUnderlineColor(true);
        }

        protected override void OnPreviewLostKeyboardFocus(System.Windows.Input.KeyboardFocusChangedEventArgs e)
        {
            base.OnPreviewLostKeyboardFocus(e);

            SetSyntaxUnderlineColor(false);
        }

        /// <summary>
        /// Sets the color of the error underline based on if the control has focus
        /// </summary>
        /// <param name="hasFocus">Whether the control has keyboard focus</param>
        private void SetSyntaxUnderlineColor(bool hasFocus)
        {
            if(_underlineBrush!=null)
                (_underlineBrush.Drawing as GeometryDrawing).Pen.Brush = hasFocus ? Brushes.Red : Brushes.Gray;
        }

        /// <summary>
        /// Underline the text of the rich text box with any syntax error
        /// </summary>
        /// <param name="errorBrush">Brush that should be used for the error underline</param>
        /// <returns>Tuple whose value 1 reflects the error start index and value 2 reflects the error length
        /// (or -1 in both cases if no error)</returns>
        public Tuple<int, int> UnderlineError(DrawingBrush errorBrush)
        {
            _underlineBrush = errorBrush;

            int errorStart = -1;
            int errorLength = -1;

            if(viewModel != null)
            {
                //If we have error, underline it
                if (viewModel.HasError)
                {
                    //Save the error positions for return value
                    errorStart = viewModel.ErrorStartIndex;
                    errorLength = Math.Max(viewModel.ErrorLength, 1);

                    int startAdjust = 2;
                    TextPointer textPointerStart = this.Document.ContentStart.GetPositionAtOffset(errorStart + startAdjust);
                    TextPointer textPointerEnd = this.Document.ContentStart.GetPositionAtOffset(errorStart + startAdjust + errorLength);
                    if (textPointerEnd == null)
                        textPointerEnd = this.Document.ContentEnd;
                    if (textPointerStart == null)
                        textPointerStart = this.Document.ContentStart;

                    TextDecorationCollection errorTextDecorations = new TextDecorationCollection();
                    errorTextDecorations.Add(new TextDecoration() { Location = TextDecorationLocation.Underline, PenOffset = 2, Pen = new Pen { Brush = errorBrush, Thickness = 5 } });
                    TextRange errorRange = new TextRange(textPointerStart, textPointerEnd);
                    errorRange.ApplyPropertyValue(Run.TextDecorationsProperty, errorTextDecorations);
                }
                //If no error, clear any property which may be decorating the control
                else
                {
                    TextRange searchTextRange = new TextRange(this.Document.ContentStart, this.Document.ContentEnd);
                    searchTextRange.ClearAllProperties();
                }
            }

            return new Tuple<int, int>(errorStart, errorLength);
        }

        /// <summary>
        /// Handler for the pasting event for this text box
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void TextBoxPastingEventHandler(object sender, DataObjectPastingEventArgs e)
        {
            //If we are pasting non-text, cancel the operation since we only want the
            // rich text box to contain text
            if (!e.SourceDataObject.GetDataPresent(DataFormats.Text, true))
            {
                e.CancelCommand();
                e.Handled = true;
                return;
            }

            //Make sure we use plain text as opposed something else like to rich text, xaml, etc.
            e.FormatToApply = DataFormats.Text;
        }

        /// <summary>
        /// Update the syntax formatting for the text
        /// </summary>
        private void UpdateRichTextBoxFormatting()
        {
            TextRange searchTextRange = new TextRange(this.Document.ContentStart, this.Document.ContentEnd);

            //Remove any existing error annotations (underline)
            searchTextRange.ClearAllProperties();

            //If text is copied from the clipboard, any rich formatting may come with it, and the clear
            // all properties call above doesn't clear this if the text being copied starts at the beginning
            // of the text box, so explicitly set the font attributes of the rich text
            searchTextRange.ApplyPropertyValue(TextElement.FontFamilyProperty, this.FontFamily);
            searchTextRange.ApplyPropertyValue(TextElement.FontSizeProperty, this.FontSize);
            searchTextRange.ApplyPropertyValue(TextElement.FontStretchProperty, this.FontStretch);
            searchTextRange.ApplyPropertyValue(TextElement.FontStyleProperty, this.FontStyle);
            searchTextRange.ApplyPropertyValue(TextElement.FontWeightProperty, this.FontWeight);

            string replaceTextWith = String.Empty;

            //If a multi-line string was pasted, we should clear out the new lines to preserve the fact
            // that the search filter control should only ever be a single line of text
            if (this.Text.Contains("\n"))
            {
                replaceTextWith = searchTextRange.Text.Replace('\r', ' ').Replace('\n', ' ');
            }

            //If the text box ends with a space, make sure it is a single non-breaking space so the
            // underlining works properly (underlining won't apply on a normal space)
            if (this.Text.EndsWith(" "))
            {
                replaceTextWith = this.Text.TrimEnd(new char[] { ' ', (char)160 }) + (char)160; //160 char code is non-breaking space
            }

            //If we have replacement text, go ahead and make the modification
            if (!String.IsNullOrEmpty(replaceTextWith))
            {
                int charsFromStart = this.Document.ContentStart.GetOffsetToPosition(this.CaretPosition);
                
                searchTextRange.Text = replaceTextWith;

                //Setting the text property of a text range moves the caret to the beginning of the string
                // so make sure we set it back to where it was originally
                try 
                { 
                    this.CaretPosition = this.Document.ContentStart.GetPositionAtOffset(charsFromStart);
                }
                catch (Exception e)
                {
                    if (e != null)
                        this.CaretPosition = this.Document.ContentEnd;
                }
            }

            if (viewModel != null)
                viewModel.SearchErrorIndicatorMessage = String.Empty;
        }

        #region IDisposable Members

        public void Dispose()
        {
            DataObject.RemovePastingHandler(this, TextBoxPastingEventHandler);
        }

        #endregion
    }
}
