﻿using RockwellAutomation.UI.CommonControls.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.CommonControls;
using System.Collections.ObjectModel;
using RockwellAutomation.UI;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query.Common;


namespace DataItemBrowserUT
{
    
    ///<summary>
    /// This is a test class for SearchFilterControlViewModelTest and is intended
    /// to contain SearchFilterControlViewModel Unit Tests which have not been 
    /// tested in other unit tests.
    ///</summary>
    [TestClass()]
    public class SearchFilterControlViewModelTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SearchFilterVM SearchFilterText and its PropertyChange notification
        ///</summary>
        [TestMethod()]
        public void SearchFilterVM_TextTest()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            string propertyName = "SearchFilterText";
            string actual = "Hello World";

            targetPrivate.Invoke("add_PropertyChanged", new System.ComponentModel.PropertyChangedEventHandler(CatchPropertyChanged));
            
            // Following causes PropertyChanged notification
            target.SearchFilterText = actual;

            Assert.AreEqual(actual, target.SearchFilterText, "SearchFilterTextTest failed: SearchFilterText not set to Hello World");
            Assert.AreEqual(propertyName, PropertyChangedName, "SearchFilterTextTest failed: SearchFilterText did not cause PropertyChange notification");
        }

        
        private string _propertyChangedName = string.Empty;
        public string PropertyChangedName
        {
            get { return _propertyChangedName; }
            internal set { _propertyChangedName = value; }
        }

        void CatchPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            PropertyChangedName = e.PropertyName;
        }


        /// <summary>
        ///A test for SearchFilterVM SearchFilterText Intialize
        ///</summary>
        [TestMethod()]
        public void SearchFilterVM_InitializeTest()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            SearchFilterDefinition filterDef = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            filterDef.AddFilter("dt:", "DINT", false, SearchFilterDefinition.StatementLogic.AND);
            target.Initialize(filterDef);

            Assert.AreEqual(0, string.Compare("dt:DINT", target.SearchFilterText.Trim()), "SearchFilterTextTest failed: SearchFilterText not set to dt:DINT");
            // Items do not get added to MRU during launch. Search text is added to pendingMRU in case the search is parsed as invalid
            Assert.AreEqual(0, target.SearchMruList.Count, "There should NOT be an item added to SearchMruList");
            Assert.IsFalse(target.SearchMruListHasItems, "SearchMruListHasItems should be false");
            Assert.IsTrue(string.IsNullOrEmpty(target.SearchErrorIndicatorMessage), "SearchErrorIndicatorMessage should be empty");
        }


        /// <summary>
        ///A test for SearchFilterVM is active
        ///</summary>
        [TestMethod()]
        public void SearchFilterVM_IsActiveTest()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            SearchFilterDefinition filterDef = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            filterDef.AddFilter("dt:", "DINT", false, SearchFilterDefinition.StatementLogic.AND);
            target.Initialize(filterDef);
            
            Assert.AreEqual(0, string.Compare("dt:DINT", target.SearchFilterText.Trim()), "SearchFilterTextTest failed: SearchFilterText not set to dt:DINT");
            Assert.IsTrue(target.IsActive, "IsActive should be true");
            Assert.IsTrue(target.HasNonEmptySearchValue, "HasNonEmptySearchValue should be true");
        }

        /// <summary>
        ///A test for SearchFilterVM Clear Search
        ///</summary>
        [TestMethod()]
        public void SearchFilterVM_ClearSearchTest()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            SearchFilterDefinition filterDef = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            filterDef.AddFilter("dt:", "DINT", false, SearchFilterDefinition.StatementLogic.AND);
            target.Initialize(filterDef);

            Assert.AreEqual(0, string.Compare("dt:DINT", target.SearchFilterText.Trim()), "SearchFilterTextTest failed: SearchFilterText not set to dt:DINT");
            Assert.IsTrue(target.IsActive, "IsActive should be true");
            Assert.IsTrue(target.HasNonEmptySearchValue, "HasNonEmptySearchValue should be true");
        }

        /// <summary>
        ///A test for SearchFilterVM SearchErrorIndicatorMessage and its PropertyChange notification
        ///</summary>
        [TestMethod()]
        public void SearchFilterVM_SearchErrorIndicatorMessageTest()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            string propertyName = "SearchErrorIndicatorMessage";
            string actual = "Hello World";

            targetPrivate.Invoke("add_PropertyChanged", new System.ComponentModel.PropertyChangedEventHandler(CatchPropertyChanged));
            
            // Following causes PropertyChanged notification
            target.SearchErrorIndicatorMessage = actual;

            Assert.AreEqual(actual, target.SearchErrorIndicatorMessage, "SearchErrorIndicatorMessageTest failed: SearchErrorIndicatorMessage not set to Hello World");
            Assert.AreEqual(propertyName, PropertyChangedName, "SearchErrorIndicatorMessageTest failed: SearchErrorIndicatorMessage did not cause PropertyChange notification");
        }

        /// <summary>
        ///A test for SearchFilterVM SearchErrorIndicatorMessage and its PropertyChange notification
        ///</summary>
        [TestMethod()]
        public void SearchFilterVM_ExecuteFilterCommandHasError()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            string searchText = "datatype:(one";

            PrivateObject execFilterCommand = new PrivateObject(targetPrivate.GetFieldOrProperty("ExecuteFilterCommand"));
            execFilterCommand.Invoke("Execute", searchText);

            Assert.IsFalse(string.IsNullOrEmpty(target.SearchErrorIndicatorMessage), "SearchErrorIndicatorMessageTest failed: SearchErrorIndicatorMessage is not empty");
            Assert.IsTrue(target.HasError, "SearchErrorIndicatorMessageTest failed:HasError should be true");
            Assert.IsFalse(target.IsActive, "SearchErrorIndicatorMessageTest failed:IsActive should be false");
            
        }

        /// <summary>
        ///A test for SearchFilterVM SearchErrorIndicatorMessage and its PropertyChange notification
        ///</summary>
        [TestMethod()]
        public void SearchFilterVM_ExecuteFilterCommandSuccess()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            string searchText = "datatype:DINT";

            PrivateObject execFilterCommand = new PrivateObject(targetPrivate.GetFieldOrProperty("ExecuteFilterCommand"));
            execFilterCommand.Invoke("Execute", searchText);

            Assert.IsTrue(string.IsNullOrEmpty(target.SearchErrorIndicatorMessage), "SearchErrorIndicatorMessageTest failed: SearchErrorIndicatorMessage is not empty");
            Assert.IsFalse(target.HasError, "SearchErrorIndicatorMessageTest failed:HasError should be true");
            Assert.IsTrue(target.IsActive, "SearchErrorIndicatorMessageTest failed:IsActive should be false");
        }

        /// <summary>
        ///A test for SearchFilterVM FilterTypes 
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterVM_FilterTypesTest()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
 			ObservableCollection<FilterType>_filterTypes = new ObservableCollection<FilterType>();
            PropertyChangedName = "";

            // Validate AddFilterOption populates FilterTypes
            Assert.AreEqual(3, target.FilterTypes.Count, "FilterTypesTest failed: FilterTypes count wrong");
            Assert.AreEqual(DIBConstants.Common.Name, target.FilterTypes[0].Name, "FilterTypesTest failed: DI_COMMON_NAME not present");
            Assert.AreEqual(DIBConstants.Common.DataType, target.FilterTypes[1].Name, "FilterTypesTest failed: DI_COMMON_DATATYPE not present");
            Assert.AreEqual(DIBConstants.Common.Description, target.FilterTypes[2].Name, "FilterTypesTest failed: DI_COMMON_DESCRIPTION not present");

            // Validate FilterTypes collection property is correct
            _filterTypes = target.FilterTypes;
            Assert.AreEqual(3, _filterTypes.Count, "FilterTypesTest failed: _filterTypes count wrong");
            Assert.AreEqual(_filterTypes[0].Name, target.FilterTypes[0].Name, "FilterTypesTest failed: _filterTypes[0] not equal to DI_COMMON_NAME");
            Assert.AreEqual(_filterTypes[1].Name, target.FilterTypes[1].Name, "FilterTypesTest failed: _filterTypes[1] not equal to DI_COMMON_DATATYPE");
            Assert.AreEqual(_filterTypes[2].Name, target.FilterTypes[2].Name, "FilterTypesTest failed: _filterTypes[2] not equal to DI_COMMON_DESCRIPTION");

        }

        ///<summary>
        /// Test that the MRU list is updated correctly
        /// </summary>        
        [TestMethod()]
        public void SearchFilterVM_EnsureMruUpdated_pendingSearchMruItemExists_UpdateMRUClearpendingSearchMRUItemTest()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);
            targetPrivate.SetFieldOrProperty("_pendingSearchMruItem", "d:test");
            target.EnsureMruUpdated();

            //SearchMruListHasItems does not get set when items are added to the MRU list 
            //Assert.IsTrue(target.SearchMruListHasItems,"MRU list should have an item");            
            
            Assert.IsTrue(target.SearchMruList.Count>0, "The MRU list should have an item");
            Assert.AreEqual(0, ((string)targetPrivate.GetFieldOrProperty("_pendingSearchMruItem")).Length,"The _pendingSearchMruItem should be empty");
        }

        ///<summary>
        /// Test that the MRU list is cleared correctly
        /// </summary>        
        [TestMethod()]
        public void SearchFilterVM_MRUList_Clear()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            target.SearchModeEnabled = true;
            PrivateObject targetPrivate = new PrivateObject(target);
            target.Initialize(null);

            PrivateObject execFilterCommand = new PrivateObject(targetPrivate.GetFieldOrProperty("ExecuteFilterCommand"));
            execFilterCommand.Invoke("Execute", "testSearch");

            Assert.IsTrue(target.SearchMruListHasItems, "MRU list should have an item");
            Assert.AreEqual(1, target.SearchMruList.Count, "The MRU list should have one item");

            target.ClearMruList();

            Assert.AreEqual(0, target.SearchMruList.Count, "The MRU list should have no items after a clear");
            Assert.IsFalse(target.SearchMruListHasItems, "MRU list should be empty after a clear");
        }

        ///<summary>
        /// Test that the MRU list is cleared correctly when using named contexts
        /// </summary>        
        [TestMethod()]
        public void SearchFilterVM_MRUList_Clear_Contexts()
        {
            //Init Tag search VM
            SearchFilterControlViewModel searchFilterTagVM = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true)) { SearchModeEnabled = true };
            PrivateObject searchFilterTagVM_private = new PrivateObject(searchFilterTagVM);
            PrivateObject execFilterCommandTag = new PrivateObject(searchFilterTagVM_private.GetFieldOrProperty("ExecuteFilterCommand"));
            searchFilterTagVM.Initialize(null, "tag");

            //Add and verify two items to the Tag search
            execFilterCommandTag.Invoke("Execute", "tagSearch1");
            execFilterCommandTag.Invoke("Execute", "tagSearch2");
            Assert.AreEqual(2, searchFilterTagVM.SearchMruList.Count, "The MRU list should have two items");

            //Init Data Type search VM
            SearchFilterControlViewModel searchFilterDataTypeVM = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(false)) { SearchModeEnabled = true };
            PrivateObject searchFilterDataTypeVM_private = new PrivateObject(searchFilterDataTypeVM);
            PrivateObject execFilterCommandDataType = new PrivateObject(searchFilterDataTypeVM_private.GetFieldOrProperty("ExecuteFilterCommand"));
            searchFilterDataTypeVM.Initialize(null, "datatype");

            //Make sure no MRU items appear
            Assert.AreEqual(0, searchFilterDataTypeVM.SearchMruList.Count, "The MRU list in new context should have no items");

            //Add data type search and verify the single item
            execFilterCommandDataType.Invoke("Execute", "datatypeSearch1");
            Assert.AreEqual(1, searchFilterDataTypeVM.SearchMruList.Count, "The MRU list in data type context should have the new item just added");

            //Verify the tag MRU still has its own two items
            Assert.AreEqual(2, searchFilterTagVM.SearchMruList.Count, "The MRU list back in the tag context should still have two items");

            //Clear all named contexts
            SearchFilterControlViewModel.ClearMruListContexts();

            //Tag and data type contexts should now be empty
            Assert.AreEqual(0, searchFilterTagVM.SearchMruList.Count, "The MRU list for tag context should be empty after a clear");
            Assert.AreEqual(0, searchFilterDataTypeVM.SearchMruList.Count, "The MRU list for data type context should be empty after a clear");
        }

        /// <summary>
        /// FilterStates
        ///    Initial = 0,
        ///    Searching = 1,
        ///    Cancelling = 2
        /// 
        /// </summary>
        [TestMethod()]
        public void SearchFilterVM_IsClientOnlyCancelRequest_FilterState_Initial_True()
        {
            //ARRANGE
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            target.SearchFilterText = string.Empty;            
            target.CurrentState = SearchFilterControlViewModel.FilterState.Initial;
            target.PreviousState = SearchFilterControlViewModel.FilterState.Initial;

            //ACT
            bool value = target.IsClientOnlyCancelRequest();

            //ASSERT
            Assert.IsTrue(value,"Should be a client only cancel request.");
            
        }

        /// <summary>
        /// FilterStates
        ///    Initial = 0,
        ///    Searching = 1,
        ///    Cancelling = 2
        /// </summary>
        [TestMethod()]
        public void SearchFilterVM_IsClientOnlyCancelRequest_FilterState_Searching_False()
        {
            //ARRANGE
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            target.SearchFilterText = "bool";            
            target.CurrentState = SearchFilterControlViewModel.FilterState.Searching;
            target.PreviousState = SearchFilterControlViewModel.FilterState.Initial;

            //ACT
            bool value = target.IsClientOnlyCancelRequest();

            //ASSERT
            Assert.IsFalse(value, "Should NOT be a client only cancel request.");

        }

        /// <summary>
        /// FilterStates
        ///    Initial = 0,
        ///    Searching = 1,
        ///    Cancelling = 2
        /// </summary>
        [TestMethod()]
        public void SearchFilterVM_IsClientOnlyCancelRequest_FilterState_Cancelling_False()
        {
            //ARRANGE
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            target.SearchFilterText = "array";            
            target.CurrentState = SearchFilterControlViewModel.FilterState.Canceling;
            target.PreviousState = SearchFilterControlViewModel.FilterState.Searching;

            //ACT
            bool value = target.IsClientOnlyCancelRequest();

            //ASSERT
            Assert.IsFalse(value, "Should NOT be a client only cancel request.");

        }

        /// <summary>
        /// FilterStates
        ///    Initial = 0,
        ///    Searching = 1,
        ///    Cancelling = 2
        /// </summary>
        [TestMethod()]
        public void SearchFilterVM_IsClientOnlyCancelRequest_FilterState_Cancelling_True()
        {
            //ARRANGE
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            target.SearchFilterText = "array";            
            target.CurrentState = SearchFilterControlViewModel.FilterState.Canceling;
            target.PreviousState = SearchFilterControlViewModel.FilterState.Canceling;

            //ACT
            bool value = target.IsClientOnlyCancelRequest();

            //ASSERT
            Assert.IsTrue(value, "Should be a client only cancel request.");

        }

        /// <summary>
        /// Call ClearSearch() after executing a search
        /// verify all the properties are set correctly
        /// </summary>
        [TestMethod()]
        public void SearchFilterVM_ClearSearch_ValidSearchText_Cleared()
        {
            //ARRANGE
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            string searchText = "datatype:(one";

            PrivateObject execFilterCommand = new PrivateObject(targetPrivate.GetFieldOrProperty("ExecuteFilterCommand"));
            execFilterCommand.Invoke("Execute", searchText);

            //verify that there is an error message so that we know that it was cleared after the ClearSearch call
            Assert.IsNotNull(target.SearchErrorIndicatorMessage);
            Assert.IsTrue(target.SearchFilterText.Length == searchText.Length);

            //ACT
            target.ClearSearch();

            Assert.IsTrue(target.SearchFilterText == string.Empty);
            Assert.IsTrue(target.SearchErrorIndicatorMessage == string.Empty);
            Assert.IsTrue(target.CurrentState == SearchFilterControlViewModel.FilterState.Canceling);
        }

        /// <summary>
        ///A test for SearchFilterVM ErrorStart index and length valid
        ///</summary>
        [TestMethod()]
        public void SearchFilterVM_ErrorStart_ErrorLength_Valid()
        {
            SearchFilterControlViewModel target = new SearchFilterControlViewModel(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            string searchText = "datatype:(one";

            PrivateObject execFilterCommand = new PrivateObject(targetPrivate.GetFieldOrProperty("ExecuteFilterCommand"));
            execFilterCommand.Invoke("Execute", searchText);

            Assert.IsNotNull(target.SearchErrorIndicatorMessage);
            Assert.IsTrue(target.HasError, "SearchErrorIndicatorMessageTest failed:HasError should be true");
            Assert.IsTrue(target.ErrorStartIndex == 9); //position of first open parenthesis
            Assert.IsTrue(target.ErrorLength == 1); //length of open parenthesis

        }
    }
}
