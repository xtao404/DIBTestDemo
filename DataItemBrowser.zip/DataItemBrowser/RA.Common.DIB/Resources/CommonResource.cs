/* ****************************************************************************
*
*  Copyright 2014 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

#region references

using System;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Logging;
using System.Reflection;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.Client.Services.Query.Common;

#endregion

namespace RockwellAutomation.UI
{

    /// <summary>
    /// Common string values shared by all resource's
    /// </summary>
    public static class DIResource
    {
        #region public members

        // DataType types
        public static readonly string DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE;
        public static readonly string DI_COMMON_RESOURCETYPE_MODULE_DATATYPE;
        public static readonly string DI_COMMON_RESOURCETYPE_USER_DATATYPE;
        public static readonly string DI_COMMON_RESOURCETYPE_NONE;
        public static readonly string DI_COMMON_RESOURCETYPE_DTB_NONE;


        // Device and Data Item Types
        public static readonly string DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW;
        public static readonly string DI_COMMON_RESOURCETYPE_DEVICE;
        public static readonly string DI_COMMON_RESOURCETYPE_CONTROLLER;
        public static readonly string DI_COMMON_RESOURCETYPE_HMIDEVICE;
        public static readonly string DI_COMMON_RESOURCETYPE_TAG;
        public static readonly string DI_COMMON_RESOURCETYPE_CONTROLLERTAGS;
        public static readonly string DI_COMMON_RESOURCETYPE_DATATYPE;
        public static readonly string DI_COMMON_RESOURCETYPE_WEB;
        public static readonly string DI_COMMON_RESOURCETYPE_DATATYPEMEMBER;
        public static readonly string DI_COMMON_RESOURCETYPE_TAGSPROPERTIES;
        public static readonly string DI_COMMON_RESOURCETYPE_CONTROLLERTAGSPROPERTIES;
        public static readonly string DI_COMMON_RESOURCETYPE_HMITAGSPROPERTIES;
        public static readonly string DI_COMMON_RESOURCETYPE_PROGRAMS;
        public static readonly string DI_COMMON_RESOURCETYPE_PROGRAM;
        public static readonly string DI_COMMON_RESOURCETYPE_DATALOGS;
		public static readonly string DI_COMMON_RESOURCETYPE_DATALOGS_UI;
        public static readonly string DI_COMMON_RESOURCETYPE_DATALOG;
        public static readonly string DI_COMMON_RESOURCETYPE_SCREENS;
        public static readonly string DI_COMMON_RESOURCETYPE_AOGS;

        public static readonly string DI_COMMON_RESOURCETYPE_SINT;
        public static readonly string DI_COMMON_RESOURCETYPE_DINT;
        public static readonly string DI_COMMON_RESOURCETYPE_INT;
        public static readonly string DI_COMMON_RESOURCETYPE_LINT;
        public static readonly string DI_COMMON_RESOURCETYPE_REAL;
        public static readonly string DI_COMMON_RESOURCETYPE_STRING;
        public static readonly string DI_COMMON_RESOURCETYPE_BOOL;
        public static readonly char DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER;
        public static readonly char DI_COMMON_RESOURCETYPE_ARRAY_END_DELIMITER;
        public static readonly char DI_COMMON_RESOURCETYPE_ARRAY_DIMENSIONS_SEPERATOR;
        public static readonly string DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER;
        public static readonly string DI_COMMON_RESOURCETYPE_PATH_DELIMITER;
        public static readonly string DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER;
        public static readonly string DI_COMMON_RESOURCETYPE_DB_BEGIN_DELIMITER;
        public static readonly string DI_COMMON_RESOURCETYPE_DB_END_DELIMITER;
        public static readonly string DI_COMMON_RESOURCETYPE_SYSTEM_DEFINED_PATH_DELIMITER;
        public static readonly string DI_COMMON_RESOURCETYPE_SYSTEM_DEFINED_FOLDER_DELIMITER;

        public static readonly string DI_COMMON_IDENTIFIER_DISPLAY_NAME;
        public static readonly string DI_COMMON_IDENTIFIER_TYPE;

        public static readonly string DI_COMMON_LOCAL_HMIDEVICE_DISPLAY_NAME;

        public const double DI_COMMON_COLUMNCONFIG_MIN_WIDTH = 120;
        public const double DI_COMMON_COLUMNCONFIG_CURRENT_WIDTH = 120;
        public const double DI_COMMON_COLUMNCONFIG_DATATYPE_WIDTH = 80;
        
        //Create a data item base for the UserDefined grid row 
        private static DataItemBase _UserDefinedDIB;
        public static DataItemBase DIB_UserDefined
        { 
            get
            {
                if (_UserDefinedDIB == null)
                    _UserDefinedDIB = new DataItemBase() { 
                        CommonName = DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE,
                        CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE,
                        CommonResourceType = TypeIdentifiers.ResourceType_DataType.ToString(),
                        GUISupportsDrillIn = "true",
                        IsStructured = true};
                return _UserDefinedDIB;
            }
        }

        //Create a data item base for the PreDefined grid row 
        private static DataItemBase _PreDefinedDIB;
        public static DataItemBase DIB_PreDefined
        {
            get
            {
                if (_PreDefinedDIB == null)
                    _PreDefinedDIB = new DataItemBase {
                        CommonName = DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE,
                        CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE,
                        CommonResourceType = TypeIdentifiers.ResourceType_DataType.ToString(),
                        GUISupportsDrillIn = "true",
                        IsStructured = true};
                return _PreDefinedDIB;
            }
        }

        //Create a data item base for the ModuleDefined grid row 
        private static DataItemBase _ModuleDefinedDIB;
        public static DataItemBase DIB_ModuleDefined
        { 
            get
            {
                if (_ModuleDefinedDIB == null)
                    _ModuleDefinedDIB = new DataItemBase {
                        CommonName = DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE,
                        CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE,
                        CommonResourceType = TypeIdentifiers.ResourceType_DataType.ToString(),
                        GUISupportsDrillIn = "true",
                        IsStructured = true};
                return _ModuleDefinedDIB;
            }
        }

        //Create a data item base for the tags and properties grid row 
        private static DataItemBase _tagsAndPropsDIB;
        public static DataItemBase DIB_TagsAndProps
        { 
            get
            {
                if (_tagsAndPropsDIB == null)
                    _tagsAndPropsDIB = new DataItemBase(){
                        CommonName = DIResource.DI_COMMON_RESOURCETYPE_TAGSPROPERTIES,
                        CommonDataType = String.Empty,
                        CommonResourceType = TypeIdentifiers.ResourceType_TagsAndProperties.ToString(),
                        CommonDescription = String.Empty,
                        GUISmallImagePath = "/RA.Common.DIB;component/Bitmaps/TagsAndProps.png",
                        GUIAutomationID = "TagsAndProps",
                        GUIAutomationName = "TagsAndProps",
                        GUISupportsDrillIn = "true",
                        IsStructured = true};
                return _tagsAndPropsDIB;
            }
        }

        /// <summary>
        /// Based on wether we are browsing an HMI device or Controller, we want the tags and properties data item to have a different name
        /// Set the name according to what resource type we are browsing
        /// </summary>
        /// <param name="resourceType">UUID of resource type</param>  
        public static void UpdateTagsAndPropertiesItem(UUID controllerOrHMIResourceType)
        {
            if (ResourceBase.IsEqual(controllerOrHMIResourceType, TypeIdentifiers.getResourceType_Controller()))
            {
                DIResource.DIB_TagsAndProps.CommonName = DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGSPROPERTIES;
            }
            else if (ResourceBase.IsEqual(controllerOrHMIResourceType, TypeIdentifiers.ResourceType_HMIDevice))
            {
                DIResource.DIB_TagsAndProps.CommonName = DIResource.DI_COMMON_RESOURCETYPE_HMITAGSPROPERTIES;
            }
        }

        //Create a data item base for the Programs grid row 
        private static DataItemBase _programsDIB;
        public static DataItemBase DIB_Programs
        {
            get
            {
                if (_programsDIB == null)
                    _programsDIB = new DataItemBase()
                    {
                        CommonName = DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS,
                        CommonDataType = String.Empty,
                        CommonResourceType = TypeIdentifiers.ResourceType_Programs.ToString(),
                        CommonDescription = String.Empty,
                        GUISmallImagePath = "/RA.Common.DIB;component/Bitmaps/Programs.png",
                        GUIAutomationID = "Programs",
                        GUIAutomationName = "Programs",
                        GUISupportsDrillIn = "true",
                        IsStructured = true
                    };
                return _programsDIB;
            }
        }

        //Create a data item base for the DataLogs grid row 
        private static DataItemBase _dataLogs;
        public static DataItemBase DIB_DataLogs
        {
            get
            {
                if (_dataLogs == null)
                    _dataLogs = new DataItemBase()
                    {
                        CommonName = DIResource.DI_COMMON_RESOURCETYPE_DATALOGS_UI,
                        CommonDataType = String.Empty,
                        CommonResourceType = TypeIdentifiers.ResourceType_DataLogs.ToString(),
                        CommonDescription = String.Empty,
                        GUISmallImagePath = "/RA.Common.DIB;component/Bitmaps/DataLogs.png",
                        GUIAutomationID = "DataLogs",
                        GUIAutomationName = "DataLogs",
                        GUISupportsDrillIn = "true",
                        IsStructured = true
                    };
                return _dataLogs;
            }
        }

        //Create a data item base for the Screens grid row 
        private static DataItemBase _screens;
        public static DataItemBase DIB_Screens
        {
            get
            {
                if (_screens == null)
                    _screens = new DataItemBase()
                    {
                        CommonName = DIResource.DI_COMMON_RESOURCETYPE_SCREENS,
                        CommonDataType = String.Empty,
                        CommonResourceType = TypeIdentifiers.ResourceType_Screens.ToString(),
                        CommonDescription = String.Empty,
                        IsStructured = true
                    };
                return _screens;
            }
        }

        //Create a data item base for the AOGs grid row 
        private static DataItemBase _AOGs;
        public static DataItemBase DIB_AOGs
        {
            get
            {
                if (_AOGs == null)
                    _AOGs = new DataItemBase()
                    {
                        CommonName = DIResource.DI_COMMON_RESOURCETYPE_AOGS,
                        CommonDataType = String.Empty,
                        CommonResourceType = TypeIdentifiers.ResourceType_AOG.ToString(),
                        CommonDescription = String.Empty,
                        IsStructured = true
                    };
                return _AOGs;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataItem"></param>
        /// <returns></returns>
        public static bool IsResourceTypeController(DataItemBase dataItem)
        { 
            return ResourceBase.IsEqual(
                dataItem.GetResourceTypeAsUUID(), 
                TypeIdentifiers.getResourceType_Controller());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataItem"></param>
        /// <returns></returns>
        public static bool IsResourceTypeHMIDevice(DataItemBase dataItem)
        {
            return ResourceBase.IsEqual(
                dataItem.GetResourceTypeAsUUID(),
                TypeIdentifiers.ResourceType_HMIDevice);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataItem"></param>
        /// <returns></returns>
        public static bool IsResourceTypeControllerOrHMIDevice(DataItemBase dataItem)
        {
            if (dataItem == null) return false;

            UUID ResourceId = dataItem.GetResourceTypeAsUUID();

            if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.getResourceType_Controller())) return true;
            if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_HMIDevice)) return true;

            return false;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataItem"></param>
        /// <returns></returns>
        public static bool IsResourceTypeNonSearchableInVieweGUI(DataItemBase dataItem)
        {
            if (dataItem == null) return false;

            UUID ResourceId = dataItem.GetResourceTypeAsUUID();

            if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_DataLogs)) return true;
            if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_Programs)) return true;
            if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_Screens)) return true;

            return false;
        }

        /// <summary>
        /// This method interrogates the DataItemBase to obtain its RESOURCE_TYPE, it then returns the Resource type as a string.
        /// </summary>
        /// <param name="dataItem">The item for which the resource type is extracted.</param>
        /// <param name="isTagBrowser"> </param>
        /// <returns>string representation of the resource type</returns>
        public static string GetResourceTypeString(DataItemBase dataItem, bool isTagBrowser)
        {
            string ResourceType = DIResource.DI_COMMON_RESOURCETYPE_NONE;
            if (!isTagBrowser)
                ResourceType = DIResource.DI_COMMON_RESOURCETYPE_DTB_NONE;

            if (dataItem != null)
            {
                UUID ResourceId = dataItem.GetResourceTypeAsUUID();  
                
                if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_Device))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_DEVICE;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.getResourceType_Controller()))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_HMIDevice))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_Tag))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_TAG;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_DataType))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_DATATYPE;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_Programs))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_Program))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_PROGRAM;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_TagsAndProperties))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGS;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_DataTypeMember))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_DATATYPEMEMBER;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_DataLogs))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_DATALOGS;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_DataLog))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_DATALOG;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_Screens))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_SCREENS;

                else if (ResourceBase.IsEqual(ResourceId, TypeIdentifiers.ResourceType_AOG))
                    ResourceType = DIResource.DI_COMMON_RESOURCETYPE_AOGS;

                else
                    ResourceType = String.Empty;
            }

            return ResourceType;
        }


        /// <summary>
        /// Does this DataItemBase represent a folder?
        /// </summary>
        /// <param name="dib">DatItemBase in question</param>
        /// <returns></returns>
        public static bool IsFolderItem(DataItemBase dib)
        {
            return dib == DIResource.DIB_TagsAndProps ||
                   dib == DIResource.DIB_Programs ||
                   dib == DIResource.DIB_DataLogs ||
                   dib == DIResource.DIB_Screens ||
                   dib == DIResource.DIB_AOGs;
        }

        #endregion

        /// <summary>
        /// static constructor
        /// </summary>
        /// The following warning is suppressed because if we initialize the static fields where they are declared obfuscation will not obfuscate the strings.
        /// When we initialize the static fields in the static constructor, obfuscation does obfuscate the fields
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1810:InitializeReferenceTypeStaticFieldsInline")]
        static DIResource()
        {
            DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE = "Predefined";
            DI_COMMON_RESOURCETYPE_MODULE_DATATYPE = "Module-Defined";
            DI_COMMON_RESOURCETYPE_USER_DATATYPE = "User-Defined";
            DI_COMMON_RESOURCETYPE_NONE = "none";
            DI_COMMON_RESOURCETYPE_DTB_NONE = "DTBNone";
            DI_COMMON_RESOURCETYPE_DEVICE = "Device";
            DI_COMMON_RESOURCETYPE_CONTROLLER = "Controller";
            DI_COMMON_RESOURCETYPE_HMIDEVICE = "HMIDevice";
            DI_COMMON_RESOURCETYPE_TAG = "Tag";
            DI_COMMON_RESOURCETYPE_CONTROLLERTAGS = "ControllerTags";
            DI_COMMON_RESOURCETYPE_WEB = "Web";
            DI_COMMON_RESOURCETYPE_DATATYPE = "DataType";
            DI_COMMON_RESOURCETYPE_DATATYPEMEMBER = "DataTypeMember";
		    DI_COMMON_RESOURCETYPE_TAGSPROPERTIES = "Tags";
            DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW = "GenericDIBItemView";
		    DI_COMMON_RESOURCETYPE_CONTROLLERTAGSPROPERTIES = "Controller Tags";
		    DI_COMMON_RESOURCETYPE_HMITAGSPROPERTIES = "HMI Device Tags";
            DI_COMMON_RESOURCETYPE_PROGRAMS = "Programs";
            DI_COMMON_RESOURCETYPE_PROGRAM = "Program";
            DI_COMMON_RESOURCETYPE_DATALOGS = "DataLogs";
		    DI_COMMON_RESOURCETYPE_DATALOGS_UI = "Data Logs";
            DI_COMMON_RESOURCETYPE_DATALOG = "DataLog";
            DI_COMMON_RESOURCETYPE_SCREENS = "Screens";
            DI_COMMON_RESOURCETYPE_AOGS = "AOGs";
            DI_COMMON_RESOURCETYPE_SINT = "SINT";
            DI_COMMON_RESOURCETYPE_DINT = "DINT";
            DI_COMMON_RESOURCETYPE_INT = "INT";
            DI_COMMON_RESOURCETYPE_LINT = "LINT";
            DI_COMMON_RESOURCETYPE_REAL = "REAL";
            DI_COMMON_RESOURCETYPE_STRING = "STRING";
            DI_COMMON_RESOURCETYPE_BOOL = "BOOL";
            DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER = '[';
            DI_COMMON_RESOURCETYPE_ARRAY_END_DELIMITER = ']';
            DI_COMMON_RESOURCETYPE_ARRAY_DIMENSIONS_SEPERATOR = ',';
            DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER = "::";
            DI_COMMON_RESOURCETYPE_PATH_DELIMITER = "\\";
            DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER = ".";
            DI_COMMON_RESOURCETYPE_DB_BEGIN_DELIMITER = "<";
            DI_COMMON_RESOURCETYPE_DB_END_DELIMITER = ">";
            DI_COMMON_RESOURCETYPE_SYSTEM_DEFINED_PATH_DELIMITER = DI_COMMON_RESOURCETYPE_PATH_DELIMITER + DI_COMMON_RESOURCETYPE_SYSTEM_DEFINED_FOLDER_DELIMITER;
            DI_COMMON_RESOURCETYPE_SYSTEM_DEFINED_FOLDER_DELIMITER = "@";
            DI_COMMON_IDENTIFIER_DISPLAY_NAME = "DisplayName";
            DI_COMMON_IDENTIFIER_TYPE = "Type";
            DI_COMMON_LOCAL_HMIDEVICE_DISPLAY_NAME = "Local:HMIDevice";
        } 
    }

    /// <summary>
    /// This class has utility methods for UUID manipulation
    /// </summary>
    public static class ResourceBase
    {
        /// <summary>
        /// Converts a GUID string into a UUID 
        /// The GUID string format that is expected is
        /// hi:24321234234342\n lo:234123423423424\n. This format can be obtained by using UUID.ToString();
        /// </summary>
        /// <param name="guid">The Guid String to be converted.</param>
        /// <returns>a UUID representation of the given string.</returns>
        static public ServiceFramework.DataTypes.UUID GuidStringToId(string guid)
        {
            if (String.IsNullOrEmpty(guid)) return null;

            string[] Lines = guid.Split('\n');
            string HiString = Lines[0].Substring(Lines[0].LastIndexOf(':') + 1).Trim();
            string LoString = Lines[1].Substring(Lines[1].LastIndexOf(':') + 1).Trim();
            ulong Hi = Convert.ToUInt64(HiString, 10);
            ulong Lo = Convert.ToUInt64(LoString, 10);            
            return RockwellAutomation.ServiceFramework.DataTypes.UUID.CreateBuilder().SetHi(Hi).SetLo(Lo).Build();
        }

        /// <summary>            
        /// convert the UUID to the GUID string which matches the database entry, currently this is for test purposes to compare the 
        /// popup test host output strings with the values in the database
        /// The GUID string returned from this is in this format
        /// 91f4fd46-12f3-4d05-891c-d8e2b3a47744
        /// to compare with the entries in the h2 database
        /// </summary>
        /// <param name="id"></param> UUID of a data item
        /// <returns>string</returns> a string which represents the GUID
        static public string UidToGuidString(RockwellAutomation.ServiceFramework.DataTypes.UUID id)
        {
            string guidStr = string.Empty;
            
            if (id != null)
            {
                try
                {
                    long hival = (long)id.Hi;
                    string hiValStr = Convert.ToString(hival, 16);
                    if (hiValStr.Length >= 8) hiValStr = hiValStr.Insert(8, "-");
                    if (hiValStr.Length >= 13) hiValStr = hiValStr.Insert(13, "-");
                    guidStr = hiValStr + "-";

                    long loval = (long)id.Lo;
                    string loValStr = Convert.ToString(loval, 16);
                    if (loValStr.Length >= 4) loValStr = loValStr.Insert(4, "-");
                    guidStr += loValStr;
                }
                catch (OverflowException e)
                {
                    LogWrapper.LogException(MethodBase.GetCurrentMethod().ToString() + ": Unable to convert UUID to GUID string.", e);
                }
            }
            return guidStr;
        }

        /// <summary>
        /// Helper to compare two UUIDs
        /// </summary>
        /// <param name="source"></param>
        /// <param name="destination"></param>
        /// <returns>boolean indication of source and destination equality</returns>
        public static bool IsEqual(UUID source, UUID destination)
        {
            bool success = false;

            if ((source != null) && (destination != null))
            {
                success = ((source.Hi == destination.Hi) && (source.Lo == destination.Lo));
            }
            return success;
        }


        public static string generateRandomUUIDString()
        {
            return ResourceBase.generateRandomUUID().ToString();
        }

        public static UUID generateRandomUUID()
        {
            Guid uuid = System.Guid.NewGuid();
            UUID newUUID;

            byte[] byteArray = uuid.ToByteArray();

            ulong hi = ((ulong)byteArray[3] << 56) | ((ulong)byteArray[2] << 48) | ((ulong)byteArray[1] << 40) | ((ulong)byteArray[0] << 32) |
                       ((ulong)byteArray[5] << 24) | ((ulong)byteArray[4] << 16) | ((ulong)byteArray[7] << 8) | ((ulong)byteArray[6]);
            ulong lo = ((ulong)byteArray[8] << 56) | ((ulong)byteArray[9] << 48) | ((ulong)byteArray[10] << 40) | ((ulong)byteArray[11] << 32) |
                       ((ulong)byteArray[12] << 24) | ((ulong)byteArray[13] << 16) | ((ulong)byteArray[14] << 8) | ((ulong)byteArray[15]);

            newUUID = UUID.CreateBuilder()
                                .SetHi(hi)
                                .SetLo(lo)
                                .Build();
            return newUUID;
        }

    }
    
}