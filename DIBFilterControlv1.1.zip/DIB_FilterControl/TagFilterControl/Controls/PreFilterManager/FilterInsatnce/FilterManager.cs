﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.Object;

namespace TagFilterControl.Controls.PreFilterManager.FilterInsatnce
{
    public class FilterManager
    {
        private TagFilter tagFilter = new TagFilter();
        public String Reason { get; private set; }

        public void Initialize(FilterOptionsSubProfileContent profileContent)
        {
            if (profileContent is FilterOptionsSubProfileContent)
            {
                try
                {
                    FilterOptionsSubProfileContent filterInfo = profileContent as FilterOptionsSubProfileContent;
                    foreach (FilterReturnBase filterOption in filterInfo.FilterOptions)
                    {
                        tagFilter.Initialize(filterOption);
                    }
                }
                catch (Exception ex)
                {
                }
            }
        }

        public bool ApplyFilters(TagObjects tag)
        {
            bool result = true;
            result = tagFilter.Apply(tag);
            Reason = tagFilter.Reason;
            return result;
        }
    }
}
