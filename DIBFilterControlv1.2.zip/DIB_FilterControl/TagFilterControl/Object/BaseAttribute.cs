﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Object
{
    public class BaseAttribute
    {
        public string Name { get; set; }

        private bool isCheckedControlTags = true;
        public bool IsCheckedControlTags
        {
            get { return isCheckedControlTags; }
            set { isCheckedControlTags = value; }
        }

        private bool isCheckedProTags = true;
        public bool IsCheckedProTags
        {
            get { return isCheckedProTags; }
            set { isCheckedProTags = value; }
        }
    }
}
