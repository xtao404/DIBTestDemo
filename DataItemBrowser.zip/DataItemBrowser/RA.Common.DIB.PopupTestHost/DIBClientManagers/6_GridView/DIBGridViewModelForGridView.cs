﻿/* ****************************************************************************
*
*  Copyright 2015 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using RockwellAutomation.UI.ViewModels;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    /// <summary>
    /// Model used with the GridView
    /// </summary>
    public class DIBGridViewModelForGridView : DIBGridViewModel
    {
        private NaturalCompare _naturalCompare;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dibVM">reference to the DataItemBrowser view model</param>
        public DIBGridViewModelForGridView(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
            _naturalCompare = new NaturalCompare();
        }

        /// <summary>
        /// Provide custom compare methods
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns>IComparer for the provided column</returns>
        protected override IComparer GetComparerForColumn(String columnName)
        {
            if (columnName.Equals("RandomNumber"))
            {
                return _naturalCompare;
            }

            return base.GetComparerForColumn(columnName);
        }

        /// <summary>
        /// Perform a Natural Sort/Compare
        /// </summary>
        private class NaturalCompare : IComparer
        {
            public int Compare(object xArg, object yArg)
            {
                String xStr = xArg as String;
                String yStr = yArg as String;
                if (xStr == null)
                {
                    return -1;
                }
                if (yStr == null)
                {
                    return 1;
                }

                int x = 0;
                int.TryParse(xStr, out x);

                int y = 0;
                int.TryParse(yStr, out y);

                return x - y;
            }
        }
    }
}
