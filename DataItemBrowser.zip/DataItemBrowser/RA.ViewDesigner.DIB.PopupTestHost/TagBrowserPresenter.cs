﻿using System.Windows;

namespace PopUpTestHost
{
    /// <summary>
    /// Tag Browser Presenter which is used by the Tag Browser Popup Window.
    /// </summary>
    public class TagBrowserPresenter  
    {

        #region INotifyPropertyChanged Members
        /// <summary>
        /// Property Changed event
        /// </summary>
        //public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Properties
        
      
        /// <summary>
        /// resize the window rect to fit in the screen height and width
        /// </summary>
        /// <param name="windowRect">the rect for Tag Browser popup window</param>
        /// <param name="screenRect">the rect of the virtual screen</param>
        /// <returns></returns>
        public static Rect ResizeRectToFitInScreen(Rect windowRect, Rect screenRect)
        {

            //is the top of the window off the top of the screen?
            if (windowRect.Top < screenRect.Top)
            {
                windowRect.Height -= screenRect.Top - windowRect.Top;
                windowRect.Y = screenRect.Top;
            }
            //is the bottom of the window off the bottom of the screen?
            if (windowRect.Bottom > screenRect.Top + screenRect.Height)
            {
                windowRect.Height -= windowRect.Bottom - screenRect.Bottom;
            }
            //is the left of the window off the left of the screen?
            if (windowRect.Left < screenRect.Left)
            {
                windowRect.Width -= screenRect.Left - windowRect.Left;
                windowRect.X = screenRect.Left;
            }
            //is the right of the window off the right of the screen?
            if (windowRect.Right > screenRect.Right)
            {
                windowRect.Width -= windowRect.Right - screenRect.Right;
            }
            return windowRect;
        }
        #endregion Properties
        #region Constructor and initialization
        /// <summary>
        /// TagBrowser data presenter constructor
        /// </summary>
        public TagBrowserPresenter()
        {
        }

        #endregion Constructor and initialization


    }
}
