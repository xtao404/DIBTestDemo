﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

namespace RockwellAutomation.UI.DIBQuery
{
    /// <summary>
    /// IDIBDataViewType interface definition.
    /// </summary>
    public interface IDIBDataViewType
    {
        bool IsListView();
        bool IsGridView();
        bool IsControllerView();
        bool IsUnknownView();
        bool IsTreeView();
        bool IsWebView();

        /// <summary>
        /// Obtains prefix for a column's name in the key field stored in the user.config file
        /// The views identified in ColumnsInfo.xml that are to use the same prefixes in the user.config file
        /// must have the same number of columns with the same name.
        /// </summary>
        string GetUserConfigPrefix();
    }
}
