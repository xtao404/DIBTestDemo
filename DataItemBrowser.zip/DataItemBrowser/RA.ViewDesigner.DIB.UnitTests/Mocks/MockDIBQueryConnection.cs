
#region references

using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query;
using System;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.Common;

#endregion

namespace DataItemBrowserUT
{   
    /// <summary>
    /// This class mock access to QSP and ROA Common services so that DIB unit tests can now use ClientDataServices as the regular DIB does.
    /// To use this mock, just assign it to cds: cds.SetDIBQueryConnection(mockDIBQuery) before executing CDS initialize
    /// A couple features worth mentioning in this mock is that by default it returns specific data for certain queries. (Look at AddFakeDataItemsOnQueryExecute)
    /// You can overide this default behavior and have the mock return back a specific user defined result by setting DataItemsToReturnOnNextExecute.
    /// </summary>
    class MockDIBQueryConnection : IDIBQueryConnection
    {
        #region "Instance Variables"

        // Hold onto CDS instance so we can use it to notofy callback for query complete
        private IClientDataServices _cds;
        // THis allows users to specify what resaults to return for next query
        public List<DataItemBase> DataItemsToReturnOnNextExecute = new List<DataItemBase>();
        // Store the last executed command
        public IDIBQueryCommand LastExecutedQueryCommand;
        public String ErrorText = String.Empty;

        #endregion

        #region "Constructor"

        /// <summary>
        /// Constructor
        /// </summary>
        public MockDIBQueryConnection()
        {
        }

        #endregion

        #region "Init/Release""

        public bool isQueryInitialized()
        {
            return true;
        }

        /// <summary>
        //  Create and initialize a query so we can talk to data via the query service provider
        /// </summary>
        public void CreateConnection()
        {
        }

        /// <summary>
        /// Used to set a new package and project context for the query service provider to use.
        /// If the package and project context have changed, we want to shutdown the query service provider
        /// </summary>
        /// <param name="packageContext"></param>
        /// <param name="projectContext"></param>
        public void SetPackageAndProjectContext(UUID packageContext, UUID projectContext)
        {
        }

        public bool HasValidPackageAndProjectContext()
        {
            return true;
        }

        /// <summary>
        /// Shutdown query service provider completely along with any open connections
        /// </summary>
        public void Shutdown()
        {
        }

        /// <summary>
        /// Register for Data Load complete Event
        /// Need to be carefull here because we could be using a cached _query but a new 
        /// instance of cds, so we make sure to reset the instance of CDS we are using
        /// </summary>
        public void RegisterForEvents(IClientDataServices cds)
        {
            _cds = cds;
        }

        /// <summary>
        /// Unregister for Data Load complete Event, but leave the current query service provider available to be used in the future for performance caching reasons
        /// </summary>
        public void UnRegisterForEvents()
        {
        }

        /// <summary>
        /// Called to set which resource service type to use by the QSP
        /// <param name="UseMock">indicator to select the mock services, by default, it is set to false.</param>
        /// </summary>
        public static void SetResourceServiceType(bool UseMock = false)
        {
        }

        #endregion

        #region "Execute"

        /// <summary>
        /// Called to run the query 
        /// </summary>        
        /// <param name="qRequest">QueryRequest</param>
        /// <param name="queryCache">DIBQueryCache</param>
        public void Execute(IDIBQueryCommand queryCommand, DIBQueryCache queryCache)
        {
            ErrorText = String.Empty;
            this.AddFakeDataItemsOnQueryExecute(queryCommand, queryCache);
            this.LastExecutedQueryCommand = queryCommand;

            // Create a Query response. This is the same type of thing that QSP does.
            QueryResponse queryResponse = new QueryResponse.CreateBuilder()
                .SetQueryRequest(queryCommand.CurrentQueryRequest)
                .SetTotalItemCount(this.DataItemsToReturnOnNextExecute.Count)
                .SetIsCancelled(false)
                .Build();

            Query_DataLoadComplete(queryResponse, null);
        }

        public void CallbackLoadInitialItems(List<DataItemBase> items, int count)
        {
        }

        public void CallbackLoadFinalItems(List<DataItemBase> items, int count)
        {
        }

        /// <summary>
        /// Called when the query services have finished obtaining data for us
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Query_DataLoadComplete(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            QueryResponse qResponse = sender as QueryResponse;
            _cds.PerformQuery_DataLoadComplete(qResponse);       
        }

        #endregion

        #region "Error Handling"

        
        public string ProcessExceptionErrorResponse(Exception exception, IClientDataServices cds)
        {
            ErrorText = exception.ToString();
            return ErrorText;
        }


        #endregion

        #region "Test data"


        private void AddFakeDataItemsOnQueryExecute(IDIBQueryCommand queryCommand, DIBQueryCache queryCache)
        {
            // No reason to add fake return items if the query cahce is not created
            if (queryCache == null) return;

            if (this.DataItemsToReturnOnNextExecute.Count > 0)
            {
                queryCache.AddDataItems(this.DataItemsToReturnOnNextExecute);
                return;
            }

            if (queryCommand.QueryType() == PredefinedQueryType.Devices)
            {
                queryCache.AddDataItems(MockDIBQueryConnection.SampleDevicesList());
                return;
            }
            if (queryCommand.QueryType() == PredefinedQueryType.Tags)
            {
                queryCache.AddDataItems(MockDIBQueryConnection.SampleTagsAndPropertiesList());
                return;
            }
        }

        static public List<DataItemBase> SampleDevicesList()
        {

            DataItemBase _controller1 = new DataItemBase() { 
                CommonName = "Controller1", 
                CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString(), 
                CommonDataType = string.Empty, 
                CommonDescription = string.Empty };
            _controller1.IsStructured = true;

            DataItemBase _controller2 = new DataItemBase() { CommonName = "Controller2", CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString(), CommonDataType = string.Empty, CommonDescription = string.Empty };
            _controller2.IsStructured = true;

            List<DataItemBase> results = new List<DataItemBase>();
            results.Add(_controller1);
            results.Add(_controller2);

            return results;
        }

        static public List<DataItemBase> SampleTagsAndPropertiesList()
        {

            DataItemBase _tag1 = new DataItemBase() { 
                CommonName = "tag1", 
                CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString(), 
                CommonDataType = string.Empty, 
                CommonDescription = "This is tag1" };
            _tag1.IsStructured = true;

            DataItemBase _tag2 = new DataItemBase() { 
                CommonName = "tag2", 
                CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString(), 
                CommonDataType = string.Empty, 
                CommonDescription = "This is tag2" };
            _tag2.IsStructured = true;

            List<DataItemBase> results = new List<DataItemBase>();
            results.Add(_tag1);
            results.Add(_tag2);

            return results;
        }

        #endregion
    }
}
