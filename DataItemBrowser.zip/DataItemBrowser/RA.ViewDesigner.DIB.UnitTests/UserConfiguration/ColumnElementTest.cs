﻿using RockwellAutomation.UI.UserConfiguration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for ColumnElementTest and is intended
    ///to contain all ColumnElementTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ColumnElementTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for VisiblePosition
        ///</summary>
        [TestMethod()]
        public void VisiblePositionTest()
        {
            ColumnElement target = new ColumnElement();
            string expected = "3";
            string actual;
            target.VisiblePosition = expected;
            actual = target.VisiblePosition;
            Assert.AreEqual(expected, actual, "VisiblePositionTest failed - 3 not returned");
        }

        /// <summary>
        ///A test for Visible
        ///</summary>
        [TestMethod()]
        public void VisibleTest()
        {
            ColumnElement target = new ColumnElement();
            string expected = "false";
            string actual;
            target.Visible = expected;
            actual = target.Visible;
            Assert.AreEqual(expected, actual, "VisibleTest failed - false not returned");
        }

        /// <summary>
        ///A test for SortIndex
        ///</summary>
        [TestMethod()]
        public void SortIndexTest()
        {
            ColumnElement target = new ColumnElement();
            string expected = "3";
            string actual;
            target.SortIndex = expected;
            actual = target.SortIndex;
            Assert.AreEqual(expected, actual, "SortIndexTest failed - 3 not returned");
        }

        /// <summary>
        ///A test for SortDirection
        ///</summary>
        [TestMethod()]
        public void SortDirectionTest()
        {
            ColumnElement target = new ColumnElement();
            SortDirection expected = SortDirection.Ascending;
            string actual;
            target.SortDirection = expected.ToString();
            actual = "Ascending";
            Assert.AreEqual(expected.ToString(), actual, "SortDirectionTest failed - Ascending not returned");
        }

        /// <summary>
        ///A test for Key
        ///</summary>
        [TestMethod()]
        public void KeyTest()
        {
            ColumnElement target = new ColumnElement();
            string expected = "cmn_Name";
            string actual;
            target.Key = expected;
            actual = target.Key;
            Assert.AreEqual(expected, actual, "KeyTest failed - cmn_Name not returned");
        }

        /// <summary>
        ///A test for FieldName
        ///</summary>
        [TestMethod()]
        public void FieldNameTest()
        {
            ColumnElement target = new ColumnElement();
            string expected = "Name";
            string actual;
            target.FieldName = expected;
            actual = target.FieldName;
            Assert.AreEqual(expected, actual, "FieldNameTest failed - Name not returned");
        }

        /// <summary>
        ///A test for CurrentWidth
        ///</summary>
        [TestMethod()]
        public void CurrentWidthTest()
        {
            ColumnElement target = new ColumnElement();
            string expected = "120";
            string actual;
            target.CurrentWidth = expected;
            actual = target.CurrentWidth;
            Assert.AreEqual(expected, actual, "ColumnWidth did not return 120");
        }

        /// <summary>
        ///A test for ColumnElement Constructor
        ///</summary>
        [TestMethod()]
        public void ColumnElementConstructorTest()
        {
            string key = "cmn_Name";
            string fieldName = "Name";
            bool visible = true; 
            int visiblePosition = 0;
            double currentwidth = 120;
            SortDirection sortDirection = SortDirection.Ascending;
            int sortIndex = 0; 
            ColumnElement target = new ColumnElement(key, fieldName, visible, visiblePosition, currentwidth, sortDirection, sortIndex);
            Assert.AreEqual(key, target.Key, "ColumnElementConstructorTest failed - key did not match");
            Assert.AreEqual(fieldName, target.FieldName, "ColumnElementConstructorTest failed - fieldName did not match");
            Assert.AreEqual(visible, (string.Compare(target.Visible, "true", true) == 0) ? true : false, "ColumnElementConstructorTest failed - visible did not match");
            Assert.AreEqual(visiblePosition, int.Parse(target.VisiblePosition), "ColumnElementConstructorTest failed - visiblePosition did not match");
            Assert.AreEqual(currentwidth, double.Parse(target.CurrentWidth), "ColumnElementConstructorTest failed - currentwidth did not match");
            Assert.AreEqual("1", target.SortDirection, "ColumnElementConstructorTest failed - sortDirection did not match");
            Assert.AreEqual(sortIndex, int.Parse(target.SortIndex), "ColumnElementConstructorTest failed - sortIndex did not match");
        }
    }
}
