﻿using System.Configuration;
using System.Globalization;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.Logging;
using System;

namespace RockwellAutomation.UI.UserConfiguration
{
    // Define the properties for the <Column .../> element
    // Properties:
    //    name - name of the column
    //    visible - is the column visible or not
    //    visibleposition - where does the column appear (left to right order)
    //    currentwidth - current width of the column
    //    sortDirection - ascending, descending
    //    sortindex - 1 if this is the primary sort column
    public class ColumnElement : ConfigurationElement
    {
        // Create the element.
        public ColumnElement()
        { }

        // Create the element.
        public ColumnElement(string key, string fieldName, bool visible, int visiblePosition, double currentWidth, SortDirection sortDirection, int sortIndex)
        {
            this.Key = key;
            this.FieldName = fieldName;
            this.Visible = visible.ToString(CultureInfo.CurrentCulture);
            this.VisiblePosition = visiblePosition.ToString(CultureInfo.CurrentCulture);
            this.CurrentWidth = currentWidth.ToString(CultureInfo.CurrentCulture);
            this.SortDirection = sortDirection.ToString();
            this.SortIndex = sortIndex.ToString(CultureInfo.CurrentCulture);
        }

        #region Properties

        // Get or set the key - unique identifier
        [ConfigurationProperty("key", IsRequired = true)]
        public string Key
        {
            get
            {
                return (string)this["key"];
            }
            set
            {
                this["key"] = value;
            }
        }
        // Get or set the fieldname (language neutral name)of the column.  Not the column's Title which is language knowledgable.
        [ConfigurationProperty("fieldname", IsRequired = true)]
        public string FieldName
        {
            get
            {
                return (string)this["fieldname"];
            }
            set
            {
                this["fieldname"] = value;
            }
        }

        // Is the column visible?
        [ConfigurationProperty("visible", IsRequired = true)]
        public string Visible
        {
            get
            {
                // Name field is always visible
                if (string.Compare(this.FieldName, "Name", true) == 0)
                    return "true";

                string temp = (string)this["visible"];
                if (string.Compare(temp, "true", true) == 0)
                    return temp;
 
                return "false";
            }
            set
            {
                this["visible"] = value;
            }
        }

        // Where does the column reside within the grid of columns
        [ConfigurationProperty("visibleposition", IsRequired = true)]
        public string VisiblePosition
        {
            get
            {
                // Name field is always in position 0
                if (string.Compare(this.FieldName, "Name", true) == 0)
                    return "0";

                // validate that visibleposition is a number greater than 0
                string temp = (string)this["visibleposition"];
                try
                {
                    int x = int.Parse(temp);
                    if (x <= 0)
                    {
                        temp = "1";
                        LogWrapper.DibGeneralLog.Debug(String.Format("UserConfig data for {0} {1} VisiblePosition <= 0. Set to 1.", this.Key, this.FieldName));
                    }
                }
                catch (Exception e)
                {
                    temp = "1";
                    LogWrapper.DibGeneralLog.Debug(String.Format("UserConfig data for {0} {1} VisiblePosition was not a number. Set to 1.", this.Key, this.FieldName));
                    LogWrapper.DibGeneralLog.Debug(e.Message);
                }
                return temp;
            }
            set
            {
                this["visibleposition"] = value;
            }
        }

        // What is the current width of the column
        [ConfigurationProperty("currentwidth", IsRequired = true)]
        public string CurrentWidth
        {
            get
            {
                // validate currentwidth is a positive number - the actual value is validated against the minimum width externally
                string temp = (string)this["currentwidth"];
                try
                {
                    double x = double.Parse(temp);
                    if (x < 0)
                    {
                        temp = "0";
                        LogWrapper.DibGeneralLog.Debug(String.Format("UserConfig data for {0} {1} CurrentWidth < 0. Set to 0.", this.Key, this.FieldName));
                    }
                }
                catch (Exception e)
                {
                    temp = "0";
                    LogWrapper.DibGeneralLog.Debug(String.Format("UserConfig data for {0} {1} CurrentWidth was not a number. Set to 0.", this.Key, this.FieldName));
                    LogWrapper.DibGeneralLog.Debug(e.Message);
                }
                return temp;
            }
            set
            {
                this["currentwidth"] = value;
            }
        }

        // What is the sort direction for the column?
        [ConfigurationProperty("sortdirection", IsRequired = true)]
        public string SortDirection
        {
            get
            {
                string temp = (string)this["sortdirection"];
                if (string.Compare(temp, "None", true) == 0)
                    return "0";
                else if (string.Compare(temp, "Ascending", true) == 0)
                    return "1";
                else if (string.Compare(temp, "Descending", true) == 0)
                    return "2";
                LogWrapper.DibGeneralLog.Debug(String.Format("UserConfig data for {0} {1} SortDirection was not None, Ascending, or Descending. Set to None.", this.Key, this.FieldName));
                return "0";
            }
            set
            {
                this["sortdirection"] = value;
            }
        }

        // What is the sort priority for the column?
        [ConfigurationProperty("sortindex", IsRequired = true)]
        public string SortIndex
        {
            get
            {
                string temp = (string)this["sortindex"];

                // validate it is a number and greater than or equal to -1 (no priority)
                try
                {
                    int x = int.Parse(temp);
                    if (x < -1)
                    {
                        temp = "-1";
                        LogWrapper.DibGeneralLog.Debug(String.Format("UserConfig data for {0} {1} SortIndex < -1. Set to No Priority.", this.Key, this.FieldName));
                    }
                }
                catch (Exception e)
                {
                    temp = "-1";
                    LogWrapper.DibGeneralLog.Debug(String.Format("UserConfig data for {0} {1} SortIndex was not a number. Set to No Priority.", this.Key, this.FieldName));
                    LogWrapper.DibGeneralLog.Debug(e.Message);
                }
                return temp;
            }
            set
            {
                this["sortindex"] = value;
            }
        }

        #endregion Properties
    }
}
