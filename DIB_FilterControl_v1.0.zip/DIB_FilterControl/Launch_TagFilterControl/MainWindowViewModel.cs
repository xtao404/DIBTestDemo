﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TagFilterControl.Common;

namespace Launch_TagFilterControl
{
    public class MainWindowViewModel : BaseViewModel
    {
        private CustomCommand launchCommand;
        public CustomCommand LaunchCommand
        {
            get
            {
                return this.launchCommand ?? (this.launchCommand = new CustomCommand(() =>
                {
                    DIB_Window win = new DIB_Window();
                    win.Show();
                }));
            }
        }

        private CustomCommand browserCommand;
        public CustomCommand BrowserCommand
        {
            get
            {
                return this.browserCommand ?? (this.browserCommand = new CustomCommand(() =>
                {
                    OpenFileDialog openFileDialog = new OpenFileDialog();
                    openFileDialog.Title = "Select a file";
                    openFileDialog.Filter = "ACD File|*.ACD";
                    openFileDialog.FileName = string.Empty;
                    openFileDialog.FilterIndex = 1;
                    openFileDialog.RestoreDirectory = true;
                    openFileDialog.DefaultExt = "ACD";
                    DialogResult result = openFileDialog.ShowDialog();
                    if (result == DialogResult.Cancel)
                    {
                        return;
                    }
                    this.ACDPath = openFileDialog.FileName;
                }));
            }
        }

        private string acdPath;
        public string ACDPath
        {
            get { return acdPath; }
            set
            {
                acdPath = value;
                this.RaisePropertyChangedEvent(() => this.ACDPath);
            }
        }
    }
}
