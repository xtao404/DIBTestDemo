﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapClasses;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapSearchFilterClasses;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.Client.Services.Query.Common;


namespace DataItemBrowserUT.CodedUI
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class SearchFilterTest : CodedUITestBase
    {
        public SearchFilterTest()
        {
            //USE ONE OF THE CALLS TO SetProjectFile

            //Use this to call the Mock to avoid requiring the ROA stack to be running for the tests to run. This must be used to 
            //run the tests as part of the build process
            // SetProjectFile(new Tuple<string, string, string>("Controller1", "StructuresArraysBits_filter_V21", "Controller"));

            //Use this if you just want to have the tests run by development but do not want to have it run as part of the 
            //build process. All the methods must have [TestCategory("ExcludeOnAutoBuild")] so they are not run as part of the build.
            SetProjectFile("DataItemBrowserUT.CodedUI.Projects.Project12.VPD");
        }

        /// <summary>
        /// Search Filter: NAME
        /// Execution: SELECT ENTER
        /// Verification: SearchText,Breadcrumbs,MRU List
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void SearchDataSource_Name_VerifySearchTextBreadCrumbsMRUResults()
        {
            //Open tag browser
            this.UIMap.PTH_ClickTagBrowserButton();
            //kludge to ensure that DIB opens to the datasources view and not the last hightlighted item
            UIMap.PTH_EnterDotInReadTagTextBox();
            this.UIMap.PTH_ClickReadTagElipsisButton();

            this.UIMapSearchFilter.DIB_SearchFilterControl_FilterBuilder_SelectFilterType(UIMapSearchFilter.FilterTypeEnum.Name);

            //ASSERT
            this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value("name:");

            //ARRANGE
            string searchTextValue = "ph_rampsoak";
            this.UIMapSearchFilter.DIB_SearchFilterControl_TypeSearchFilterText(searchTextValue);

            //ASSERT
            string newSearchTextValue = "name:" + searchTextValue;
            this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value(newSearchTextValue);
            
            //ACT -- execute the search
            this.UIMapSearchFilter.DIB_SearchFilterControl_SearchFilterText_SelectEnter();

            //ASSERT -- search text should contain the same value
            this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value(newSearchTextValue);

            //ASSERT --datagridview contents are valid            
            DIB_Assert_DataGridView_Contents(3,"Name",searchTextValue,false);

            //ASSERT -- search breadcrumb is there
            this.UIMapSearchFilter.DIB_Assert_SearchFilterControl_SearchBreadCrumbExists();

            //ACT -- select MRU list
            this.UIMapSearchFilter.DIB_SearchFilterControl_SelectMRUListDropDown();

            //ASSERT -- the contents of the MRU list is correct
            List<string> validMRUList = new List<string>();
            validMRUList.Add(newSearchTextValue);
            this.UIMapSearchFilter.DIB_Assert_SearchFilterControl_MRUList_ContentsValid(validMRUList);
            
                   
        }

         /// <summary>
        /// Search Filter: DATATYPE
        /// Execution: SELECT ENTER
        /// Verification: SearchText,Breadcrumbs,MRU List
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void SearchControllerView_DataType_VerifySearchTextBreadCrumbsMRUResults()
         {
             //ARRANGE
             //Open tag browser
             this.UIMap.PTH_ClickTagBrowserButton();
             //kludge to ensure that DIB opens to the datasources view and not the last hightlighted item
             UIMap.PTH_EnterDotInReadTagTextBox();
             this.UIMap.PTH_ClickReadTagElipsisButton();
             //Drill into controller 1
             this.UIMap.DIB_DataSources_ClickController1();

             //search
             string searchTextValue = "dt:AB:DMB30_CUSTOMUSER_DEFINED:I:0";
             this.UIMapSearchFilter.DIB_SearchFilterControl_TypeSearchFilterText(searchTextValue);
            
             //ACT -- execute the search
             this.UIMapSearchFilter.DIB_SearchFilterControl_SearchFilterText_SelectEnter();

             //ASSERT   -- search text should remain in the control          
             this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value(searchTextValue);
            
            //wait for the search results to appear before validating
            DIB_WaitForSpinnerStop();

             //ASSERT --datagridview contents are valid                    
            DIB_Assert_DataGridView_Contents(13, DIBConstants.Common.DataType, "AB:DMB30_CUSTOMUSER_DEFINED:I:0", false);

            //ASSERT -- search breadcrumb is there
            this.UIMapSearchFilter.DIB_Assert_SearchFilterControl_SearchBreadCrumbExists();

            //ACT -- clear searchtext
            this.UIMapSearchFilter.DIB_SearchFilterControl_ClearSearchText();

            //ASSERT             
            this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value(string.Empty);
           
         }

        /// <summary>
        /// Search Filter: DEFAULT/NO FILTER SPECIFIED (NAME OR DESCRIPTION)
        /// Execution: SELECT ENTER
        /// Verification: SearchText,Breadcrumbs,MRU List
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void SearchControllerView_NoFilter_VerifySearchTextBreadCrumbsMRUResults()
        {
            //ARRANGE
            //Open tag browser
            this.UIMap.PTH_ClickTagBrowserButton();
            //kludge to ensure that DIB opens to the datasources view and not the last hightlighted item
            UIMap.PTH_EnterDotInReadTagTextBox();
            this.UIMap.PTH_ClickReadTagElipsisButton();
            //Drill into controller 1
            this.UIMap.DIB_DataSources_ClickController1();

            //search
            string searchTextValue = "alarm";
            this.UIMapSearchFilter.DIB_SearchFilterControl_TypeSearchFilterText(searchTextValue);

            //ACT -- execute the search
            this.UIMapSearchFilter.DIB_SearchFilterControl_SearchFilterText_SelectEnter();

            //ASSERT   -- search text should remain in the control          
            this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value(searchTextValue);

            //wait for the search results to appear before validating
            DIB_WaitForSpinnerStop();

            //ASSERT --datagridview contents are valid        
            DIB_Assert_DataGridview_NameORDescription_Contents(15, searchTextValue, false);

            //ASSERT -- search breadcrumb is there
            this.UIMapSearchFilter.DIB_Assert_SearchFilterControl_SearchBreadCrumbExists();

            //ACT -- select MRU list
            this.UIMapSearchFilter.DIB_SearchFilterControl_SelectMRUListDropDown();

            //ASSERT -- the contents of the MRU list is correct
            List<string> validMRUList = new List<string>();
            validMRUList.Add(searchTextValue);
            this.UIMapSearchFilter.DIB_Assert_SearchFilterControl_MRUList_ContentsValid(validMRUList);

            //ACT -- clear searchtext
            this.UIMapSearchFilter.DIB_SearchFilterControl_ClearSearchText();

            //ASSERT             
            this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value(string.Empty);

            //do another search to add items to the MRU list
            searchTextValue = "d:\"UDT Structured\"";
            this.UIMapSearchFilter.DIB_SearchFilterControl_TypeSearchFilterText(searchTextValue);

            //ACT -- execute the search
            this.UIMapSearchFilter.DIB_SearchFilterControl_SearchFilterText_SelectEnter();

            //ASSERT   -- search text should remain in the control          
            this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value(searchTextValue);

            //wait for the search results to appear before validating
            DIB_WaitForSpinnerStop();

            //ASSERT --datagridview contents are valid                    
            DIB_Assert_DataGridView_Contents(35, DIBConstants.Common.Description, "UDT Structured", false);

            //wait for the search results to appear before validating
            DIB_WaitForSpinnerStop();

            //ASSERT -- search breadcrumb is there 
            //  Clear out old reference to button by setting it to null as that reference is lazy initialized
            this.UIMapSearchFilter.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.mUISearchButtonButton = null;
            this.UIMapSearchFilter.DIB_Assert_SearchFilterControl_SearchBreadCrumbExists();

            //ACT -- select MRU list
            this.UIMapSearchFilter.DIB_SearchFilterControl_SelectMRUListDropDown();

            //select the search string that was executed first
            this.UIMapSearchFilter.DIB_SearchFilterControl_SelectMRUListItem("alarm");

            //ASSERT   -- search text should get updated        
            this.UIMapSearchFilter.DIB_Assert_SearchFilterText_Value("alarm");

        }

        #region Additional test attributes

        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            CodedUITestBase.BaseClassInitialize(testContext);
        }

        [ClassCleanup]
        public static void MyClassCleanup()
        {
            CodedUITestBase.BaseClassCleanup();
        }

        //Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void MyTestInitialize()
        {
            //this.BaseTestInitialize();
            SetupGridSerialization();
        }

        //Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {
            CleanUpGridSerialization();

            //close DIB
            UIMap.ClickHomeCrumbButton();
            DIB_WaitForSpinnerStop();
            UIMap.DIB_PressESC();  
  
        }

        #endregion

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public new TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;

        public UIMap UIMap
        {
            get
            {
                if ((this.map == null))
                {
                    this.map = new UIMap();
                }

                return this.map;
            }
        }

        public UIMapSearchFilter UIMapSearchFilter
        {
            get
            {
                if ((this.searchFilterMap == null))
                {
                    this.searchFilterMap = new UIMapSearchFilter();
                }
                return this.searchFilterMap;
            }
        }
        private UIMap map;
        private UIMapSearchFilter searchFilterMap;
    }
}
