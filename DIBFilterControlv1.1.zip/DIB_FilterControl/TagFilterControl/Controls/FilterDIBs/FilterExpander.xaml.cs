﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TagFilterControl.Common;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.DIBClientManagers.DataGridViewSimple;
using TagFilterControl.Tags;

namespace TagFilterControl.UserControls
{
    public partial class FilterExpander : UserControl
    {
        private Config config = Config.GetInstance();
        public FilterExpander()
        {
            InitializeComponent();
            UIDispatcher._Dispatcher = this._Dispatcher;
            this.ViewModel = new FilterExppanderViewModel();
            this.DataContext = this.ViewModel;
        }

        public System.Windows.Threading.Dispatcher _Dispatcher
        {
            get { return this.Dispatcher; }
        }

        public FilterExppanderViewModel ViewModel { get; set; }

        private void TreeViewGrid_RefreshClick(object sender, RoutedEventArgs e)
        {
            this.ViewModel.ItemChangedCommand.Execute(sender);
        }
    }
}
