/*************************************************************************************
                                                                     
   ViewE DIBQueryCommandTest Class
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using DataItemBrowserUT.Mocks;
using FakeItEasy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.Models;
using System;
using RockwellAutomation.UI.WindowsControl.DIBClient;

#endregion

namespace DataItemBrowserUT
{

    /// <summary>
    /// Test DIBQueryCommand and all its sublclasses
    /// We might want to consider breaking this test up into individual tests for each command
    /// </summary>
    [TestClass]
    public class DIBQueryCommandTest
    {
        /// <summary>
        /// Use TestInitialize to run code before running each test
        /// </summary>
        [TestInitialize()]
        public void MyTestInitialize()
        {
            DIBClientManagerForViewe.Instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, 
                DIBQueryCommandTest.SamplePackageContextUUID, DIBQueryCommandTest.SampleProjectContextUUID);
            PathElementFactory.SetInstance(new PathElementFactoryForViewe());
        }

        /// <summary>
        /// Use TestCleanup to run code after each test has run
        /// </summary>
        [TestCleanup()]
        public void MyTestCleanup()
        {
            DIBClientManagerForViewe.Instance.Shutdown();
        }

        public static UUID SamplePackageContextUUID = UUID.CreateBuilder().SetHi(1112042260990610512).SetLo(11142126344913406607).Build();
        public static UUID SampleProjectContextUUID = UUID.CreateBuilder().SetHi(1111112260990610512).SetLo(11111126344913406607).Build();

        /// <summary>
        /// Test GetQueryType
        /// Helper to obtain which predefined query type should be used when drilling in to the passed data item
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_GetQueryType()
        {
            DataItemBase dataItem = null;
            QueryRequest.CreateBuilder queryBuilder = new QueryRequest.CreateBuilder();

            queryBuilder.SetParentDataItemBase(dataItem);

            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.DataTypes, "Invalid PredefinedQueryType. PredefinedQueryType.DataTypes");

            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.Devices, "Invalid PredefinedQueryType. PredefinedQueryType.Devices");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.Undefined, "Invalid PredefinedQueryType. PredefinedQueryType.Undefined");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonResourceType = TypeIdentifiers.ResourceType_Device.ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.Undefined, "Invalid PredefinedQueryType. PredefinedQueryType.Undefined");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.DataTypeMembers, "Invalid PredefinedQueryType. PredefinedQueryType.DataTypeMembers");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonResourceType = TypeIdentifiers.ResourceType_DataType.ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.DataTypes, "Invalid PredefinedQueryType. PredefinedQueryType.DataTypes");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonResourceType = TypeIdentifiers.ResourceType_Program.ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.Tags, "Invalid PredefinedQueryType. PredefinedQueryType.Tags");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonResourceType = TypeIdentifiers.ResourceType_Programs.ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.Programs, "Invalid PredefinedQueryType. PredefinedQueryType.Programs");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonResourceType = TypeIdentifiers.ResourceType_DataLogs.ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.DataLogs, "Invalid PredefinedQueryType. PredefinedQueryType.DataLogs");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonName = DIResource.DI_COMMON_RESOURCETYPE_TAGSPROPERTIES, CommonResourceType = TypeIdentifiers.ResourceType_TagsAndProperties.ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.Tags, "Invalid PredefinedQueryType. PredefinedQueryType.Tags");

            queryBuilder.SetParentDataItemBase(new DataItemBase() { CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString() });
            Assert.IsTrue(DIBQueryCommandForViewe.TypeFor(queryBuilder).QueryType() == PredefinedQueryType.DataTypeMembers, "Invalid PredefinedQueryType. PredefinedQueryType.DataTypeMembers");
        }


        /// <summary>
        /// Test DIBQueryCommandForDevicesTest
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]       
        public void DIBQueryCommandForDevices_Test()
        {
           
            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
            QueryRequest.CreateBuilder queryBuilder = new QueryRequest.CreateBuilder();
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(queryBuilder);            
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual(null, command.ParentDataItem(), "Parent Data item was specified in creation is null");
            Assert.AreEqual(null, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation is null");
            Assert.AreEqual(PredefinedQueryType.Devices, command.QueryType(), "This is a query for devices");

            // Use the mock CDS
            IClientDataServices cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;
            command.Execute(cds);

            // Validate state of command after execution
            Assert.AreEqual(command.ParentDataItem(), null, "Parent Data item was specified in creation as null");
            Assert.AreEqual(command.ParentResourceTypeId(), null, "Parent ResourceID was specified in creation as null");
            Assert.AreEqual(command.QueryType(), PredefinedQueryType.Devices, "This is a query for devices");
            Assert.AreEqual(command.CacheQueryResults, true, "Device query always wants to cache results");
            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");

            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(queryRequest.GetPredefinedQuery, PredefinedQueryType.Devices, "The request should have been for devices");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsFalse(queryRequest.HasParentResourceType, "We didnt specify a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsFalse(queryRequest.HasParentDataItemBase, "We didnt specify a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");

            //TODO: 
            // Add another test for DIBQueryCommandForDevices that generates a query condition. This is done in DIBQueryCommandForDevices>>GenerateQueryCondition
            // and requires the Data Context to not include HMI Devices
        }

        /// <summary>
        /// Test DIBQueryCommandForDevicesTest
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForDevices_ExcludeHMIDevice()
        {
            //ARRANGE
            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
            QueryRequest.CreateBuilder queryBuilder = new QueryRequest.CreateBuilder();
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(queryBuilder);
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual(null, command.ParentDataItem(), "Parent Data item was specified in creation is null");
            Assert.AreEqual(null, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation is null");
            Assert.AreEqual(PredefinedQueryType.Devices, command.QueryType(), "This is a query for devices");

            // Use the mock CDS
            MockClientDataService mockcds = new MockClientDataService();
            mockcds.DibClientManager = DIBClientManagerForViewe.Instance;
            mockcds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(mockcds);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;
            

            //create a datacontext with an include path, Note: not used in the mock, but passed in to show that this is how the method would be called to
            //access the GenerateSearchWithIncludeCondition method in the DIBQueryCommandForAllTags class
            mockcds.Initialize(DataItemBrowserContextUtility.SampleExcludeHMIDeviceDataItemBrowserContext(), null);

            //create a mockDataContext and set up the exclude path
            MockDataContext datacontext = new MockDataContext();
            datacontext.ExcludeAllOfType = DataItemBrowserContext.ExcludeAllOfTypeEnum.HMIDevice;
            
            //set up the root path in the DataContext
            List < DataItemBase > rootPathItems = new List<DataItemBase>();
            DataItemBase dibRoot = new DataItemBase();
            rootPathItems.Add(dibRoot);
            datacontext.RootPath = new ContextPath(rootPathItems);
            datacontext.DisplayMetaData = false; //this is returned in DIBQueryCommand
            //set the mockDataContext in the Mock CDS
            mockcds.DataContext = datacontext;

            //ACT
            command.Execute(mockcds);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual(command.ParentDataItem(), null, "Parent Data item was specified in creation as null");
            Assert.AreEqual(command.ParentResourceTypeId(), null, "Parent ResourceID was specified in creation as null");
            Assert.AreEqual(command.QueryType(), PredefinedQueryType.Devices, "This is a query for devices");
            Assert.AreEqual(command.CacheQueryResults, true, "Device query always wants to cache results");
            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");

            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(queryRequest.GetPredefinedQuery, PredefinedQueryType.Devices, "The request should have been for devices");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsFalse(queryRequest.HasParentResourceType, "We didnt specify a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsFalse(queryRequest.HasParentDataItemBase, "We didnt specify a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsTrue(queryRequest.HasCondition, "We specified a condition");
            //test condition
            IList<QueryConditionItem> conditionItems = queryRequest.GetConditionConfig.GetQueryConditionItems;
            Assert.IsTrue(1== conditionItems.Count,"Number of conditionitems should be 1");
            Assert.AreEqual(TypeIdentifiers.getResourceType_Controller().ToString(), conditionItems[0].GetValue,"The condition should be type controller");
                       
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, mockcds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, mockcds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");

            
        }

        /// <summary>
        /// Helper method for this test class to create an instance of QueryRequest.CreateBuilder
        /// </summary>
        /// <param name="parentResourceTypeId"></param>
        /// <param name="parentItem"></param>
        /// <param name="queryCondition"></param>
        /// <returns></returns>
        public QueryRequest.CreateBuilder createQueryRequestBuilderFor(UUID parentResourceTypeId, DataItemBase parentItem, QueryConditionConfig queryCondition)
        {
            return
                new QueryRequest.CreateBuilder()
                .SetParentDataItemBase(parentItem) // Set the parent we are drilling into
                .SetCondition(queryCondition)
                .SetParentResourceType(parentResourceTypeId);
        }



        /// <summary>
        /// Test DIBQueryCommandForAllTags
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]        
        public void DIBQueryCommandForAllTags_Test()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateControllerPathElement("C1");

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.getResourceType_Controller(), pathElement.DataItem, null),
                                                true);            

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("C1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.getResourceType_Controller(), command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.AllTags,command.QueryType(), "This is a query for devices");

            // Use the mock CDS            
            IClientDataServices cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;

            //ACT
            command.Execute(cds);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("C1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.getResourceType_Controller(), command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(command.QueryType(), PredefinedQueryType.AllTags, "This is a query for AllTags");
            Assert.AreEqual(false, command.CacheQueryResults, "AllTags does not cache results");

            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");

            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(queryRequest.GetPredefinedQuery, PredefinedQueryType.AllTags, "The request should have been for AllTags");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");

        }  
      
        /// <summary>
        /// Test DIBQueryCommandForAllTags With a DataContext 
        /// This simulates the use case where the user has a DataContext IncludePath and types in a search text
        /// This will Generate a QueryCondition based on the DataContext and FilterQueryCondition
        /// The QueryRequest that gets submitted to QSP should have a QueryCondition
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]   
        public void DIBQueryCommandForAllTags_WithDataContextTest()
        {            
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateControllerPathElement("C1");

            //the filterQueryCondition            
            SearchFilterItem filterItem = new SearchFilterItem.CreateBuilder().SetIdentifier("DisplayName")
                                                                                .SetValue("array")
                                                                                .SetLogicOperator(SearchFilterDefinition.StatementLogic.AND)
                                                                                .SetIsExactMatch(false).SetIsIdentifierColumnConfigKey(false).Build();
            
            QueryConditionConfig.CreateBuilder conditionBuilder = new QueryConditionConfig.CreateBuilder();
               
            conditionBuilder.AddConditionItem(DIBQueryConditionHelper.BuildQueryConditionItemFor(filterItem));

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.getResourceType_Controller(), pathElement.DataItem, conditionBuilder.Build()),
                                                true);       

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("C1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.getResourceType_Controller(), command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.AllTags,command.QueryType(), "This is a query for devices");

            MockClientDataService mockcds = new MockClientDataService();
            //create a datacontext with an include path, Note: not used in the mock, but passed in to show that this is how the method would be called to
            //access the GenerateSearchWithIncludeCondition method in the DIBQueryCommandForAllTags class
            mockcds.DibClientManager = DIBClientManagerForViewe.Instance;
            mockcds.Initialize(DataItemBrowserContextUtility.SampleIncludePathDataItemBrowserContext(), null);

            //create a mockDataContext and set up an include path
            DataContext datacontext = new MockDataContext();
            List<DataItemBase> dataItems = new List<DataItemBase>();
            DataItemBase dibController = PathElementUtility.Instance().CreateDataItemBase("Controller1",TypeIdentifiers.getResourceType_Controller());
            dataItems.Add(dibController);
            DataItemBase dibPrograms = PathElementUtility.Instance().CreateDataItemBase("Programs", TypeIdentifiers.ResourceType_Programs);
            dataItems.Add(dibPrograms);
            DataItemBase dibProgram = PathElementUtility.Instance().CreateDataItemBase("Program_1", TypeIdentifiers.ResourceType_Program);
            dataItems.Add(dibProgram);
            ContextPath includePath = new ContextPath(dataItems);
            datacontext.IncludePath = includePath;
            datacontext.ExcludeAllChildrenFromRoot = true;
            //set up the root path in the DataContext
            List < DataItemBase > rootPathItems = new List<DataItemBase>();
            DataItemBase dibRoot = PathElementUtility.Instance().CreateDataItemBase("Controller1", TypeIdentifiers.getResourceType_Controller());
            rootPathItems.Add(dibRoot);
            datacontext.RootPath = new ContextPath(rootPathItems);
            
            //set the mockDataContext in the Mock CDS
            mockcds.DataContext = datacontext;

            //set up a MockDIBQueryCache in the MockCDS
            TSObservableCollection<DataItemBase> griddataItems = new TSObservableCollection<DataItemBase>();
            DIBQueryCache cache = new MockDIBQueryCache(griddataItems);
            MockDIBQueryCache mockcache = cache as MockDIBQueryCache;
            //the cache should have the cachedDevices set, It should be set to LocalHMIDevices and Controller1
            List<DataItemBase> cachedDataItems = new List<DataItemBase>();
            DataItemBase dibHMI = PathElementUtility.Instance().CreateDataItemBase("Local:HMIDevice", TypeIdentifiers.ResourceType_HMIDevice);
            cachedDataItems.Add(dibHMI);
            cachedDataItems.Add(dibController); //created above
            mockcache.cachedDevices = new TSObservableCollection<DataItemBase>(cachedDataItems);
            mockcds.QueryCache = cache;
        
            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(mockcds);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;

            //ACT
            command.Execute(mockcds);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("C1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.getResourceType_Controller(), command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(command.QueryType(), PredefinedQueryType.AllTags, "This is a query for AllTags");
            Assert.AreEqual(false, command.CacheQueryResults, "AllTags does not cache results");

            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");

            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(queryRequest.GetPredefinedQuery, PredefinedQueryType.AllTags, "The request should have been for AllTags");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsTrue(queryRequest.HasCondition, "The include condition should be specified");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, mockcds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, mockcds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
            //should have a ConditionConfig set up, with 3 items
            IList<QueryConditionItem> queryItems = queryRequest.GetConditionConfig.GetQueryConditionItems;
            Assert.IsTrue(3 == queryItems.Count, "Should have 3 QueryConditionItems");
            Assert.AreEqual("::Local:HMIDevice",queryItems[0].GetValue);            
            //second item should have two items in it for the include
            IList<QueryConditionItem> queryItems2 = queryItems[1].GetQueryConditionItems;
            Assert.IsTrue(2==queryItems2.Count);
            Assert.AreEqual("::Controller1.", queryItems2[0].GetValue);
            Assert.AreEqual("::Controller1\\Program_1.", queryItems2[1].GetValue);
            //filterconfig is part of it
            Assert.AreEqual("array",queryItems[2].GetValue);
        }

        /// <summary>
        /// Test DIBQueryCommandForDataLogs
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForDataLogs_Test()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateDataLogsPathElement();

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_DataLogs, pathElement.DataItem, null),
                                                false);

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("Data Logs", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataLogs, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.DataLogs, command.QueryType(), "This is a query for datatypes");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds as IClientDataServices);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;
            TSObservableCollection<DataItemBase> dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache = new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds as IClientDataServices);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("Data Logs", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataLogs, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.DataLogs, command.QueryType(), "This is a query for DataTypes");
            Assert.IsFalse(command.CacheQueryResults, "DataTypes does not cache results");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");
            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.DataLogs, queryRequest.GetPredefinedQuery, "The request should have been for devices since we passed in a null parent");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }

        /// <summary>
        /// Test DIBQueryCommandForDataTypeMembers
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForDataTypeMembers_Test()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateDataTypeMemberPathElement("UDT_1", "[0]");

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_DataTypeMember, pathElement.DataItem, null),
                                                false);

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("UDT_1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataTypeMember, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.DataTypeMembers, command.QueryType(), "This is a query for datatypes");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds as IClientDataServices);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;
            TSObservableCollection<DataItemBase> dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache = new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds as IClientDataServices);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("UDT_1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataTypeMember, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.DataTypeMembers, command.QueryType(), "This is a query for DataTypes");
            Assert.IsFalse(command.CacheQueryResults, "DataTypes does not cache results");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");
            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.DataTypeMembers, queryRequest.GetPredefinedQuery, "The request should have been for devices since we passed in a null parent");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }

        /// <summary>
        /// Test DIBQueryCommandForDataTypes
        /// Create the command with a null parent item, which should create the cache with the user-defined, pre-defined and module defined
        /// datatypes, there should be no request to QSP
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForDataTypes_NullParent_DeviceView()
        {
            //ARRANGE            
            // Create a query command will no parent
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_DataType, null, null),
                                                false); 
            
            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            //Assert.AreEqual("UDT_1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.DataTypes, command.QueryType(), "This is a query for datatypes");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds as IClientDataServices);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;

            TSObservableCollection < DataItemBase > dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache= new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds as IClientDataServices);

            //ASSERT
            // Validate state of command after execution           
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.DataTypes, command.QueryType(), "This is a query for DataTypes");
            Assert.IsTrue(command.CacheQueryResults, "DataTypes without a parent caches results for the device view");
            Assert.IsTrue(3 == cds.QueryCache.DataItems.Count,"The User-defined,Pre-defined and Module-defined should be in the cache");
            Assert.AreEqual(DIResource.DIB_UserDefined,cds.QueryCache.DataItems[0]);
            Assert.AreEqual(DIResource.DIB_PreDefined, cds.QueryCache.DataItems[1]);
            Assert.AreEqual(DIResource.DIB_ModuleDefined, cds.QueryCache.DataItems[2]);            
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");

            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.Devices, queryRequest.GetPredefinedQuery, "The request should have been for devices since we passed in a null parent");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsFalse(queryRequest.HasParentDataItemBase, "There should not be a parent");            
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            //Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }

        /// <summary>
        /// Test DIBQueryCommandForDataTypes
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForDataTypes_ValidParent()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateDataTypePathElement("UDT_1", DataTypePECategory.User);

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_DataType, pathElement.DataItem, null),
                                                false); 

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("UDT_1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.DataTypeMembers, command.QueryType(), "This is a query for datatypes");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds as IClientDataServices);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;

            TSObservableCollection<DataItemBase> dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache = new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds as IClientDataServices);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("UDT_1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.DataTypeMembers, command.QueryType(), "This is a query for DataTypes");
            Assert.IsFalse(command.CacheQueryResults, "DataTypes does not cache results");            
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");
            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.DataTypeMembers, queryRequest.GetPredefinedQuery, "The request should have been for devices since we passed in a null parent");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }
        /// <summary>
        /// Test DIBQueryCommandForModuleDataTypes
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForModuleDataTypes_Test()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateDataTypePathElement("module1Type", DataTypePECategory.User);
            pathElement.DataItem.CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE;

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_DataType, pathElement.DataItem, null),
                                                false); 

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("module1Type", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.Module_DataTypes, command.QueryType(), "This is a query for datatypes");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds as IClientDataServices);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;
            TSObservableCollection<DataItemBase> dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache = new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds as IClientDataServices);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("module1Type", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.Module_DataTypes, command.QueryType(), "This is a query for DataTypes");
            Assert.IsFalse(command.CacheQueryResults, "DataTypes does not cache results");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");
            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.Module_DataTypes, queryRequest.GetPredefinedQuery, "The request should have been for devices since we passed in a null parent");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }

        /// <summary>
        /// Test DIBQueryCommandForProductDataTypes
        /// Also know as Pre-defined datatypes
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForProductDataTypes_Test()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateDataTypePathElement("INT", DataTypePECategory.User);
            pathElement.DataItem.CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE;

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_DataType, pathElement.DataItem, null),
                                                false); 

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("INT", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.Product_DataTypes, command.QueryType(), "This is a query for datatypes");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds as IClientDataServices);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;

            TSObservableCollection<DataItemBase> dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache = new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds as IClientDataServices);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("INT", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.Product_DataTypes, command.QueryType(), "This is a query for DataTypes");
            Assert.IsFalse(command.CacheQueryResults, "DataTypes does not cache results");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");
            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.Product_DataTypes, queryRequest.GetPredefinedQuery, "The request should have been for devices since we passed in a null parent");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }

        /// <summary>
        /// Test DIBQueryCommandForPrograms
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForPrograms_Test()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateProgramsPathElement();

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_Programs, pathElement.DataItem, null),
                                                false); 

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("Programs", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_Programs, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.Programs, command.QueryType(), "This is a query for controller");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleIncludePathDataItemBrowserContext(), null);
            //set up a mockDataContext for CDS to use
            DataContext mockDataContext = new MockDataContext();

              List<DataItemBase> dataItems = new List<DataItemBase>();
            DataItemBase controller = PathElementUtility.Instance().CreateDataItemBase("c1", TypeIdentifiers.getResourceType_Controller());            
            dataItems.Add(controller);
            DataItemBase programs = PathElementUtility.Instance().CreateDataItemBase("Programs", TypeIdentifiers.ResourceType_Programs);
            dataItems.Add(programs);
            DataItemBase program = PathElementUtility.Instance().CreateDataItemBase("Program_1", TypeIdentifiers.ResourceType_Program);            
            dataItems.Add(program);
            
            mockDataContext.IncludePath = new ContextPath(dataItems);
            mockDataContext.ExcludeAllChildrenFromRoot = true;
            cds.DataContext = mockDataContext;

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;
            TSObservableCollection<DataItemBase> dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache = new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds);

            //ASSETR
            // Validate state of command after execution
            Assert.AreEqual("Programs", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_Programs, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.Programs, command.QueryType(), "This is a query for Controller");
            Assert.AreEqual(true, command.CacheQueryResults, "Programs cache results");

            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");

            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.Programs, queryRequest.GetPredefinedQuery, "The request should have been for Programs");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }

        /// <summary>
        /// Test DIBQueryCommandForHMIDevice
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForHMIDevice_Test()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateHMIDevicePathElement("Local:HMIDevice");

            // Create a query commandTagBrowser
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_HMIDevice, pathElement.DataItem, null),
                                                false); 

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("Local:HMIDevice", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_HMIDevice, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.Undefined, command.QueryType(), "This is a query for datatypes");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds as IClientDataServices);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;

            TSObservableCollection<DataItemBase> dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache = new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds as IClientDataServices);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("Local:HMIDevice", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_HMIDevice, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.Undefined, command.QueryType(), "This is a query for DataTypes");
            Assert.IsTrue(command.CacheQueryResults, "HMIDevice does cache results");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");
           
            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.Devices, queryRequest.GetPredefinedQuery, "The request should have been for devices since we passed in a null parent");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");            
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }


        /// <summary>
        /// Test DIBQueryCommandForUndefined
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForUndefined_Test()
        {
            // TODO: Add Test here
        }

        /// <summary>
        /// Test DIBQueryCommandForUserDataTypes.
        /// Test the DIB Command by manually creating an instance and then executing it with a mock CDS and mock DIBQueryConnection
        /// The purpose of the DIB Command execute is to generate QueryRequest object so this test validates the created QueryRequest
        /// </summary>
        [TestMethod]
        public void DIBQueryCommandForUserDataTypes_Test()
        {
            //ARRANGE
            //The parent we are drilling into
            IPathElement pathElement = PathElementUtility.Instance().CreateDataTypePathElement("UDT_1", DataTypePECategory.User);
            pathElement.DataItem.CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE;

            // Create a query command
            DIBClientManagerForViewe.Instance.BrowserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
            IDIBQueryCommand command = DIBQueryCommandForViewe.CreateFor(
                                                this.createQueryRequestBuilderFor(TypeIdentifiers.ResourceType_DataType, pathElement.DataItem, null),
                                                false); 

            //some initial ASSERTs
            Assert.AreEqual(command.CurrentQueryRequest, null, "Current Request should not be created untill a command is executed");
            Assert.AreEqual(command.GetRequestID(), 0UL, "Current Request ID should not be created untill a command is executed");
            Assert.AreEqual("UDT_1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.User_DataTypes, command.QueryType(), "This is a query for datatypes");

            // Use the mock CDS            
            MockClientDataService cds = new MockClientDataService();
            cds.DibClientManager = DIBClientManagerForViewe.Instance;
            cds.Initialize(DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext(), null);

            // Execute the command with a mock Query Connection
            MockDIBQueryConnection mockDIBQueryConnection = new MockDIBQueryConnection();
            mockDIBQueryConnection.RegisterForEvents(cds as IClientDataServices);
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQueryConnection;
            TSObservableCollection<DataItemBase> dataItemCollection = new TSObservableCollection<DataItemBase>();
            MockDIBQueryCache queryCache = new MockDIBQueryCache(dataItemCollection);
            cds.QueryCache = queryCache;

            //ACT
            command.Execute(cds as IClientDataServices);

            //ASSERT
            // Validate state of command after execution
            Assert.AreEqual("UDT_1", command.ParentDataItem().ToString(), "Parent Data item was specified in creation");
            Assert.AreEqual(TypeIdentifiers.ResourceType_DataType, command.ParentResourceTypeId(), "Parent ResourceID was specified in creation");
            Assert.AreEqual(PredefinedQueryType.User_DataTypes, command.QueryType(), "This is a query for DataTypes");
            Assert.IsFalse(command.CacheQueryResults, "DataTypes does not cache results");
            Assert.AreEqual(mockDIBQueryConnection.ErrorText, String.Empty, "We should not have encountered any errors executing the command");
            Assert.AreEqual(command, mockDIBQueryConnection.LastExecutedQueryCommand, "We should have executed our instance of DIBcommand");
            // Validate query request that was generated during DIBcommand execution
            QueryRequest queryRequest = command.CurrentQueryRequest;
            Assert.IsNotNull(queryRequest, "We should have created our query request");
            Assert.AreEqual(PredefinedQueryType.User_DataTypes, queryRequest.GetPredefinedQuery, "The request should have been for devices since we passed in a null parent");
            Assert.IsTrue(queryRequest.HasPreDefinedQuery, "A valid request always has a predefined query");
            Assert.IsTrue(queryRequest.HasParentResourceType, "there should be a parent");
            Assert.AreEqual(queryRequest.GetResourceParentType, command.ParentResourceTypeId(), "The request ID is whatever the command specifies");
            Assert.IsTrue(queryRequest.HasParentDataItemBase, "There should be a parent");
            Assert.AreEqual(queryRequest.GetParentDataItemBase, command.ParentDataItem(), "The value for ParentDataItem should be whatever the command specifies");
            Assert.IsFalse(queryRequest.HasCondition, "We didnt specify a condition");
            Assert.IsTrue(queryRequest.HasColumnConfig, "We specified a column config");
            Assert.AreEqual(queryRequest.GetColumnConfig.GetColumnMapItems.Count, cds.Columns.Count, "The column config in the request should should be whatever CDS specifies");
            Assert.AreEqual(queryRequest.GetDisplayMetaDataForBitsAndProperties, cds.ShouldDisplayMetaData(), "The value for ShouldDisplayMetaData should be whatever CDS specifies");
            Assert.AreEqual(command.GetRequestID(), queryRequest.GetRequestID, "The command requestID should be the same as the queryRequest requestID");
        }

        /// <summary>
        /// DataServices load complete callback
        /// This is the same callback that DataBrowserViewModel registers for during navigation
        /// </summary>
        private void loadCompleteCallback(string error)
        {
            Assert.IsTrue(string.IsNullOrEmpty(error), "DataServicesLoadComplete returned an error = " + error);
        }

        private string _problemText = string.Empty;
        /// <summary>
        /// This is a callback from CDS that informs of any errors that happened during naavigation
        /// </summary>
        private void SetProblemVars(string text, string helpid = "", bool disableSearch = false, bool disableCrumbs = false)
        {
            _problemText = text;
        }

    }
}
