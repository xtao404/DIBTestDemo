/* ****************************************************************************
*
*  Copyright 2016 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

#region references

using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.ComponentModel;
using RockwellAutomation.UI.CommonControls;
using System;
using System.Collections.ObjectModel;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.Models;
using System.Collections.Generic;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;
using RockwellAutomation.Logging;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.WindowsControl.DIBClient;

#endregion

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// View model supporting the <c>DIBTreeView</c>
    /// </summary>
    public class VieweDataSourcesTreeViewModel : DIBTreeViewModel
    {
        #region "Constructor"

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">DataItemBrowser View Model</param>
        public VieweDataSourcesTreeViewModel(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Represents if the current browser is a Tag browser versus another type such as a Data Type Picker
        /// </summary>
        public bool IsTagBrowser
        {
            get { return _dibViewModel.IsTagBrowser(); }
        }

        #endregion Properties

        #region Event Handlers

        /// <summary>
        /// Handler for DataSources' OC changing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        override protected void DataItemBrowserViewModel_TreeViewOCChanged(object sender, PropertyChangedEventArgs e)
        {
            SelectedItemPropertyChangedEventArgs DSOCArgs = e as SelectedItemPropertyChangedEventArgs;

            if (DSOCArgs != null) SetSources(DSOCArgs.SelectedItem);

            //determine if the ControllerIconVisibility should be set to Collapsed to remove the space between the drillin arrow and the controller name
            //if there are Controllers then go through the children and see if the ImagePresenter.ImageState = EnumImageState.SYNCHED
            //for all children, set ControllerIconVisibility = Collapsed in this case
            
            bool allSynched = false;
            foreach (var device in DataSources)
            {
                if (device.VisualType == VisualType.vtControllers)
                {
                    foreach (IVisualBase visualBase in device.Children)
                    {
                        DIBTreeViewItem vb = visualBase as DIBTreeViewItem;
                        if (vb != null && vb.ImagePresenter.ImageState == EnumImageState.SYNCHED)
                        {
                            allSynched = true;
                        }
                        else
                        {
                            allSynched = false;
                            break;
                        }
                    }
                }
                else
                {
                    allSynched = true;
                }
            }
            if (allSynched)
                ControllerIconVisibility = Visibility.Collapsed;
            else
                ControllerIconVisibility = Visibility.Visible;
        }

        /// <summary>
        /// Creates the DIBTreeViewItem tree containing either the "Controllers" node and its child Controller nodes, or the "HMI Devices" and its
        /// children. It sets the requested datasource's IsSelected for highlighting purposes.
        /// </summary>
        /// <param name="dataSourceToSelect">The name of the datasource to set highlighted.</param>
        override protected void SetSources(string dataSourceToSelect)
        {
            //make sure you clean up any previous items
            DisposeItems();
            this._dataSourceToSelect = dataSourceToSelect;
            
            if (this._dibViewModel.IsTagBrowser())
            {
                DIBTreeViewItem controllersNode = null;
                DIBTreeViewItem HMIDevicesNode = null;

                // Group the devices by their Resource Type
                var dsTypes = from di in _dibViewModel.DataItems
                                orderby di.ToString() ascending
                                group di by new { ResourceType = di.CommonResourceType } into diGroup
                                select new { ResourceType = diGroup.Key.ResourceType, Children = diGroup.ToList() };

                if (!this._dibViewModel.IsAOGPropertyBrowser())
                {
                    // Create Controllers even if none have yet been specified (refer to DFCTS00297309)
                    controllersNode = new DIBTreeViewItem(null, "Controllers", VisualType.vtControllers, null, DIBClientManagerForViewe.Instance)
                    {
                        IsExpanded = true,
                        IsSelected = false,

                    };
                }

 

                // Create a DIBTreeViewItem object for each dataitem, and add it to either the Controllers or Devices node
                foreach (var device in dsTypes)
                    if (ResourceBase.IsEqual(ResourceBase.GuidStringToId(device.ResourceType), TypeIdentifiers.getResourceType_Controller()))
                    {
                        // Controllers
                        foreach (DataItemBase di in device.Children)
                        {
                            if (controllersNode != null)
                            {
                                CreateChildNodeVisualBase(di, di.ToString(), VisualType.vtController, controllersNode, DIBClientManagerForViewe.Instance);
                            }
                        }
                    }
                    else
                    {
                        // HMI Devices
                        HMIDevicesNode = new DIBTreeViewItem(null, "HMI Devices", VisualType.vtHMIDevices, null, DIBClientManagerForViewe.Instance) { IsExpanded = true, IsSelected = false };
                        foreach (DataItemBase di in device.Children)
                            CreateChildNodeVisualBase(di, di.ToString(), VisualType.vtHMIDevice, HMIDevicesNode, DIBClientManagerForViewe.Instance);
                    }

                // Add the nodes to the Data Sources View
                // Special handling required for IsSelected on root nodes
                if (HMIDevicesNode != null)
                {
                    if (this._dataSourceToSelect == null)
                        HMIDevicesNode.IsSelected = true;
                    DataSources.Add(HMIDevicesNode);
                }
                if (controllersNode != null)
                {
                    if (this._dataSourceToSelect == null && HMIDevicesNode == null)
                        controllersNode.IsSelected = true;
                    DataSources.Add(controllersNode);
                }
            }
            else
            {
                // DataType Browser
                DIBTreeViewItem dataTypesNode = new DIBTreeViewItem(null, "Data Types", VisualType.vtDataTypes, null, DIBClientManagerForViewe.Instance) { IsExpanded = true, IsSelected = true };
                foreach (DataItemBase di in _dibViewModel.DataItems)
                    CreateChildNodeVisualBase(di, di.ToString(), VisualType.vtDataTypes, dataTypesNode, DIBClientManagerForViewe.Instance);

                try
                {
                    DataSources.Add(dataTypesNode);
                }
                catch (System.InvalidOperationException exception)
                {
                    // If we encounter a recursive .net error setting data sources, we retry.
                    LogWrapper.LogException("Encountered Error setting DataSources in Data Type Browser: ", exception);
                    if (!ContainsAutomationRecursionError(exception)) return;
                    RetrySetSources(dataTypesNode, 2);
                }
            }
            this._dataSourceToSelect = String.Empty;
        }

        /// <summary>
        /// Override the base class implementation of this method for performance reasonse.
        /// We dont need to recursively look for children as Viewe tree view does not go more than 2 levels deep
        /// </summary>
        /// <param name="vbParent">The DataitemBase to add children to</param>
        override protected void CreateChildrenFor(DIBTreeViewItem vbParent)
        {
            // Find children of diParent in our DataItems list and add them 
            foreach (DataItemBase diChild in _dibViewModel.DataItems)
            {
                if (diChild.GUITreeViewParentID == vbParent.DataItem.GUITreeViewID)
                    CreateChildNodeVisualBase(diChild, diChild.ToString(), VisualType.vtDataTypes, vbParent);
            }
        }

        override public string CurrentPathStringFor(List<IPathElement> tempList)
        {
            return Path.PathToString(tempList, null, IsTagBrowser ? DIBViewItemBase.VisualPerspectiveEnum.TagBrowser : DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser);
        }


        /// <summary>
        /// Set the Visual Type for those VisualBases that are data types
        /// </summary>
        /// <param name="item">DIBTreeViewItem to update</param>
        override protected void UpdateVisualType(VisualType visualType, DIBTreeViewItem item)
        {
            if (visualType != VisualType.vtDataTypes) return;

            String dtString = item.DataItem.CommonDataType;
            if (dtString == null) return;
            if (dtString.Equals(DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE))
                item.VisualType = VisualType.vtPredefined;
            else if (dtString.Equals(DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE))
                item.VisualType = VisualType.vtUserDefined;
            else if (dtString.Equals(DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE))
                item.VisualType = VisualType.vtModuleDefined;
            else throw new NotSupportedException("Data Type not supported"); 
        }

        #endregion Event Handlers

        #region Commands

        /// <summary>
        /// Creates the path which specifies the Controller to drill into and then navigates into it.
        /// </summary>
        public override SimpleCommand CreateDrillInCommand()
        {
            return new SimpleCommand()
            {
                ExecuteDelegate = x =>
                {
                    if (_dibViewModel.IsTagBrowser())
                    {
                        DIBTreeViewItem treeItem = x as DIBTreeViewItem;
                        if (treeItem != null && treeItem.DataItem != null)
                        {
                            if ((_dibViewModel.Path.Forward != null) &&
                                (treeItem.VisualName == _dibViewModel.Path.Forward.DisplayName))
                                _dibViewModel.Path.SetActive(_dibViewModel.Path.Forward);
                            else
                            {
                                IPathElement newPE = PathElementFactory.Instance().CreatePathElement(treeItem.DataItem);
                                _dibViewModel.Path.Add(newPE);

                            }
                            //handle highlighted item processing
                            this.Path.HighlightedElement = Path.ActiveElement;
                            _dibViewModel.Navigate(treeItem.DataItem);

                        }
                    }
                    else
                    {
                        DIBTreeViewItem node = x as DIBTreeViewItem;
                        if (node == null) return;

                        // Data Type Browser
                        if ((node.VisualType == VisualType.vtUserDefined) ||
                            (node.VisualType == VisualType.vtPredefined) ||
                            (node.VisualType == VisualType.vtModuleDefined))
                        {
                            // Create the DataTypePathElement representing PDT, MDT, or UDT
                            DataTypePECategory cat = new DataTypePECategory();
                            switch (node.VisualType)
                            {
                                case (VisualType.vtUserDefined):
                                    cat = DataTypePECategory.User;
                                    break;
                                case (VisualType.vtModuleDefined):
                                    cat = DataTypePECategory.Module;
                                    break;
                                case (VisualType.vtPredefined):
                                    cat = DataTypePECategory.Product;
                                    break;
                            }
                            IPathElement newPE = PathElementFactory.Instance().CreateDataTypePathElement(node.DataItem, cat);

                            _dibViewModel.Path.Add(newPE);
                            _dibViewModel.Navigate(node.DataItem);

                        }
                    }
                }
            };
        }

        #endregion Commands

    }
}
