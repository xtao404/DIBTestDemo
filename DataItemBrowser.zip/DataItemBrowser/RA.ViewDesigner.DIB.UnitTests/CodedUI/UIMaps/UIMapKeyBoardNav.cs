﻿
namespace DataItemBrowserUT.CodedUI.UIMaps.UIMapKeyBoardNavClasses
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Text.RegularExpressions;
    using Microsoft.VisualStudio.TestTools.UITest.Extension;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
    using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
    using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
    using MouseButtons = System.Windows.Forms.MouseButtons;
    using Microsoft.VisualStudio.TestTools.UITesting.WpfControls;
    using System.Windows.Input;
    using System.CodeDom.Compiler;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;


    public partial class UIMapKeyBoardNav
    {

        public void DIB_Keyboard_Tab_1_From_FilterContext()
        {
            #region Variable Declarations

            WpfMenu uIFilterBuilderBtn_ConMenu = this.UIDataItemBrowserHostWWindow.UIFilterBuilderBtn_ConMenu;

            #endregion

            // Type '{Tab}' in 'FilterBuilderBtn_ContextMenu' popup menu
            Keyboard.SendKeys(uIFilterBuilderBtn_ConMenu, this.DIB_Keyboard_Tab_3_In_Opened_DIBParams.UIFilterBuilderBtn_ConMenuSendKeys, ModifierKeys.None);
        }

        /// <summary>
        /// DIB_Assert_FilterContextMenu_Focus - Use 'DIB_Assert_FilterContextMenu_FocusExpectedValues' to pass parameters into this method.
        /// </summary>
        public void DIB_Assert_FilterContextMenu_Focus()
        {
            #region Variable Declarations

            WpfMenu uIFilterBuilderBtn_ConMenu = this.UIDataItemBrowserHostWWindow.UIFilterBuilderBtn_ConMenu;

            #endregion

            // Verify that 'FilterBuilderBtn_ContextMenu' has focus
            Assert.IsTrue(uIFilterBuilderBtn_ConMenu.HasFocus);

        }

        /// <summary>
        /// DIB_Keyboard_ShiftTab_From_SearchText - Use 'DIB_Keyboard_ShiftTab_From_SearchTextParams' to pass parameters into this method.
        /// </summary>
        public void DIB_Keyboard_ShiftTab_From_SearchText()
        {
            #region Variable Declarations
            WpfEdit uISearchFilterTextBoxEdit = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UISearchFilterTextBoxEdit;
            #endregion

            // Type 'Shift + {Tab}' in 'SearchFilterTextBox'
            Keyboard.SendKeys(uISearchFilterTextBoxEdit, this.DIB_Keyboard_ShiftTab_From_SearchTextParams.UISearchFilterTextBoxEdit_Sendkeys, ModifierKeys.Shift);
        }

        public virtual DIB_Keyboard_ShiftTab_From_SearchTextParams DIB_Keyboard_ShiftTab_From_SearchTextParams
        {
            get
            {
                if ((this.mDIB_Keyboard_ShiftTab_From_SearchTextParams == null))
                {
                    this.mDIB_Keyboard_ShiftTab_From_SearchTextParams = new DIB_Keyboard_ShiftTab_From_SearchTextParams();
                }
                return this.mDIB_Keyboard_ShiftTab_From_SearchTextParams;
            }
        }

        private DIB_Keyboard_ShiftTab_From_SearchTextParams mDIB_Keyboard_ShiftTab_From_SearchTextParams;

        /// <summary>
        /// DIB_Assert_DataGrid_Alarm_PreDefArray1_Enabled - Use 'DIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues' to pass parameters into this method.
        /// </summary>
        public void DIB_Assert_DataGrid_Alarm_PreDefArray1_Enabled()
        {
            #region Variable Declarations
            WpfPane uIAlarm_PreDefArray1Pane = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataGridViewTable.UIAlarm_PreDefArray1Pane;
            #endregion

            // Verify that 'Alarm_PreDefArray1' pane's property 'Enabled' equals 'True'
            Assert.AreEqual(this.DIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues.UIAlarm_PreDefArray1PaneEnabled, uIAlarm_PreDefArray1Pane.Enabled);
        }

        public virtual DIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues DIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues
        {
            get
            {
                if ((this.mDIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues == null))
                {
                    this.mDIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues = new DIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues();
                }
                return this.mDIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues;
            }
        }

        private DIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues mDIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues;

        /// <summary>
        /// DIB_Assert_BreadCrumb_Button_Enabled - Use 'uIDataItemBrowserContrCustom1' to pass parameters into this method.
        /// </summary>
        public void DIB_Assert_BreadCrumb_Button_Enabled(string buttonName)
        {
            #region Variable Declarations
            UIDataItemBrowserContrCustom1 uIDataItemBrowserContrCustom1 = new UIDataItemBrowserContrCustom1(this.UIDataItemBrowserHostWWindow);
            uIDataItemBrowserContrCustom1.BreadCrumbButtonName = buttonName;
            WpfButton uIBreadCrumbButton = null;
            uIBreadCrumbButton = uIDataItemBrowserContrCustom1.UIBreadCrumbButton;
            #endregion

            // Verify that breadcrumbs button's property 'Enabled' equals 'True'
            Assert.AreEqual(true, uIBreadCrumbButton.Enabled);
        }

        public virtual DIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues DIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues
        {
            get
            {
                if ((this.mDIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues == null))
                {
                    this.mDIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues = new DIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues();
                }
                return this.mDIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues;
            }
        }

        private DIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues mDIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues;

        /// <summary>
        /// DIB_Keyboard_ALT_LeftArrow_TagsProps_to_Controller 
        /// </summary>
        public void DIB_Keyboard_ALT_LeftArrow_TagsProps_to_Controller()
        {
            #region Variable Declarations
            WinWindow uIDataItemBrowserHostWWindow1 = this.UIDataItemBrowserHostWWindow1;
            WpfListItem uITagsandPropertiesListItem = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDevice_ListViewList.UITagsandPropertiesListItem;
            #endregion

            // Type 'Alt + {Left}' in 'Tags and Properties' list item
            Keyboard.SendKeys(uITagsandPropertiesListItem, this.DIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams.UITagsandPropertiesListItemSendKeys, ModifierKeys.Alt);
        }

        /// <summary>
        /// DIB_Keyboard_ALT_LeftArrow_Controller_to_DataSources 
        /// </summary>
        public void DIB_Keyboard_ALT_LeftArrow_Controller_to_DataSources()
        {
            #region Variable Declarations
            WinWindow uIDataItemBrowserHostWWindow1 = this.UIDataItemBrowserHostWWindow1;
            WpfListItem uITagsandPropertiesListItem = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDevice_ListViewList.UITagsandPropertiesListItem;
            #endregion

            // Type 'Alt + {Left}' in 'DataItemBrowser Host Window' window
            Keyboard.SendKeys(uIDataItemBrowserHostWWindow1, this.DIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams.UIDataItemBrowserHostWWindow1SendKeys, ModifierKeys.Alt);
        }

        public virtual DIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams DIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams
        {
            get
            {
                if ((this.mDIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams == null))
                {
                    this.mDIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams = new DIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams();
                }
                return this.mDIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams;
            }
        }

        private DIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams mDIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams;

        /// <summary>
        /// DIB_Keyboard_ALT_RightArrow_Controller1_TagsProps - Use 'DIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams' to pass parameters into this method.
        /// </summary>
        public void DIB_Keyboard_ALT_RightArrow_Controller1_TagsProps()
        {
            //#region Variable Declarations
            //WpfListItem uITagsandPropertiesListItem = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDevice_ListViewList.UITagsandPropertiesListItem;
            //#endregion

            // Type 'Alt + {Right}' in 'Tags and Properties' list item
            Keyboard.SendKeys(this.DIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams.UITagsandPropertiesListItemSendKeys, ModifierKeys.Alt);
        }

        public virtual DIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams DIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams
        {
            get
            {
                if ((this.mDIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams == null))
                {
                    this.mDIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams = new DIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams();
                }
                return this.mDIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams;
            }
        }

        private DIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams mDIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams;
    }


    /// <summary>
    /// copy of the UIDataItemBrowserContrCustom in the UIMapKeyBoardNavDesigner.cs
    /// 
    /// </summary>
    public class UIDataItemBrowserContrCustom1 : WpfCustom
    {
        public UIDataItemBrowserContrCustom1(UITestControl searchLimitContainer) :
            base(searchLimitContainer)
        {
            #region Search Criteria
            this.SearchProperties[UITestControl.PropertyNames.ClassName] = "Uia.DataItemBrowser";
            this.SearchProperties["AutomationId"] = "DataItemBowser.userControl";
            this.WindowTitles.Add("DataItemBrowser Host Window");
            #endregion
        }

        #region Properties
        public string BreadCrumbButtonName = string.Empty;
        public WpfButton UIBreadCrumbButton
        {
            get
            {
                if ((this.mBreadCrumbButton == null))
                {
                    this.mBreadCrumbButton = new WpfButton(this);
                    #region Search Criteria
                    this.mBreadCrumbButton.SearchProperties[WpfButton.PropertyNames.AutomationId] = BreadCrumbButtonName;
                    this.mBreadCrumbButton.WindowTitles.Add("DataItemBrowser Host Window");
                    #endregion
                }
                return this.mBreadCrumbButton;
            }
        }

        #endregion

        #region Fields
        private WpfButton mBreadCrumbButton;
        #endregion
    }




    /// <summary>
    /// Parameters to be passed into 'DIB_Keyboard_ShiftTab_From_SearchText'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_Keyboard_ShiftTab_From_SearchTextParams
    {

        #region Fields
        /// <summary>
        /// Type '' in 'SearchFilterTextBox' text box
        /// </summary>
        public string UISearchFilterTextBoxEdit_Sendkeys = "{Tab}";
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_Assert_DataGrid_Alarm_PreDefArray1_Focused'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_Assert_DataGrid_Alarm_PreDefArray1_EnabledExpectedValues
    {

        #region Fields
        /// <summary>
        /// Verify that 'Alarm_PreDefArray1' pane's property 'HasFocus' equals 'True'
        /// </summary>
        public bool UIAlarm_PreDefArray1PaneEnabled = true;
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_Assert_BreadCrumb_Alarm_PreDefArray3_Enabled'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_Assert_BreadCrumb_Alarm_PreDefArray3_EnabledExpectedValues
    {

        #region Fields
        /// <summary>
        /// Verify that 'AlarmPreDefArray3' button's property 'Enabled' equals 'True'
        /// </summary>
        public bool UIAlarmPreDefArray3ButtonEnabled = true;
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSources'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.415")]
    public class DIB_Keyboard_ALT_LeftArrow_TagsProps_to_DataSourcesParams
    {

        #region Fields
        /// <summary>
        /// Type 'Alt + {Left}' in 'DataItemBrowser Host Window' window
        /// </summary>
        public string UIDataItemBrowserHostWWindow1SendKeys = "{Left}";

        /// <summary>
        /// Type 'Alt + {Left}' in 'Tags and Properties' list item
        /// </summary>
        public string UITagsandPropertiesListItemSendKeys = "{Left}";
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_Keyboard_ALT_RightArrow_Controller1_TagsProps'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.415")]
    public class DIB_Keyboard_ALT_RightArrow_Controller1_TagsPropsParams
    {

        #region Fields
        /// <summary>
        /// Type 'Alt + {Right}' in 'Tags and Properties' list item
        /// </summary>
        public string UITagsandPropertiesListItemSendKeys = "{Right}";
        #endregion
}
}
