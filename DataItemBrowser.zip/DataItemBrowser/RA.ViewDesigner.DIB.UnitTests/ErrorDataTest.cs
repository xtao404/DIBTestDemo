﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace DataItemBrowserUT
{
    
    
    ///// <summary>
    /////This is a test class for ErrorDataTest and is intended
    /////to contain all ErrorDataTest Unit Tests
    /////</summary>
    //[TestClass()]
    //public class ErrorDataTest
    //{


    //    private TestContext testContextInstance;

    //    /// <summary>
    //    ///Gets or sets the test context which provides
    //    ///information about and functionality for the current test run.
    //    ///</summary>
    //    public TestContext TestContext
    //    {
    //        get
    //        {
    //            return testContextInstance;
    //        }
    //        set
    //        {
    //            testContextInstance = value;
    //        }
    //    }

    //    #region Additional test attributes
    //    // 
    //    //You can use the following additional attributes as you write your tests:
    //    //
    //    //Use ClassInitialize to run code before running the first test in the class
    //    //[ClassInitialize()]
    //    //public static void MyClassInitialize(TestContext testContext)
    //    //{
    //    //}
    //    //
    //    //Use ClassCleanup to run code after all tests in a class have run
    //    //[ClassCleanup()]
    //    //public static void MyClassCleanup()
    //    //{
    //    //}
    //    //
    //    //Use TestInitialize to run code before running each test
    //    //[TestInitialize()]
    //    //public void MyTestInitialize()
    //    //{
    //    //}
    //    //
    //    //Use TestCleanup to run code after each test has run
    //    //[TestCleanup()]
    //    //public void MyTestCleanup()
    //    //{
    //    //}
    //    //
    //    #endregion


    //    /// <summary>
    //    ///A test for Token
    //    ///</summary>
    //    [TestMethod()]
    //    public void ErrorData_TokenTest()
    //    {
    //        ErrorData_Accessor target = new ErrorData_Accessor();
    //        ParserToken expectedToken = new ParserToken("myToken", 10, true);
    //        target.Token = expectedToken;
    //        ParserToken actual = target.Token;
    //        Assert.AreEqual(expectedToken, actual);
    //    }

    //    ///// <summary>
    //    /////A test for StartIndex
    //    /////</summary>
    //    //[TestMethod()]
    //    //public void ErrorData_StartIndexTest()
    //    //{
    //    //    ErrorData_Accessor target = new ErrorData_Accessor(); 
    //    //    int expected = 5; 
    //    //    target.StartIndex = expected;
    //    //    int actual = target.StartIndex;
    //    //    Assert.AreEqual(expected, actual);
    //    //}

    //    /// <summary>
    //    ///A test for Reason
    //    ///</summary>
    //    [TestMethod()]
    //    public void ErrorData_ReasonTest()
    //    {
    //        ErrorData_Accessor target = new ErrorData_Accessor();
    //        string expected = "myTag";
    //        target.Reason = expected;
    //        string actual = target.Reason;
    //        Assert.AreEqual(expected, actual);
    //    }

    //    /// <summary>
    //    ///A test for Length
    //    ///</summary>
    //    [TestMethod()]
    //    public void ErrorData_LengthTest()
    //    {
    //        ErrorData_Accessor target = new ErrorData_Accessor(); 
    //        string name = "myToken";
    //        FilterToken token = new FilterToken(name,10,true);
    //        target.Token = token;
    //        int actual = target.Token.Length;
    //        Assert.AreEqual(name.Length, actual);
    //    }

  
    //}
}
