﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.Models;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.DIBQuery
{        
    /// <summary>
    /// This command is used for DIB search related functionality. 
    /// DIBQueryCommandForAllTags is responsbile is generating search conditions
    /// </summary>
    class DIBQueryCommandForAllTags : DIBQueryCommandForViewe
    {
        #region "Creation/Init"

        public DIBQueryCommandForAllTags(QueryRequest.CreateBuilder queryRequestBuilder)
            : base(queryRequestBuilder) { }

        #endregion

        #region "Base Overides"

        public override PredefinedQueryType QueryType()
        {
            return PredefinedQueryType.AllTags;
        }

        /// <summary>
        /// Generate Query Condition.
        /// </summary>
        /// <param name="cds"></param>
        /// <returns>QueryConditionConfig representing search conditions</returns>
        public override QueryConditionConfig GenerateQueryCondition(IClientDataServices cds)
        {
            //is this is a query based search with an include path
            if (cds.DataContext.HasInclude() && cds.DataContext.IncludePath.ParentDataItem != null)
            {
                //combine the filter and include conditions if needed
                QueryConditionConfig queryCondition = DIBQueryCommandForAllTags.GenerateSearchWithIncludeCondition(cds, cds.DataContext, this.QueryRequestBuilder.GetCondition());
                return queryCondition;
            }
            return base.GenerateQueryCondition(cds);
        }


        /// <summary>
        /// combine the filter and include conditions if needed
        /// create a condition config builder for a query based search with an include path
        /// </summary>
        /// <param name="cds"></param>
        /// <param name="dataContext"></param>
        /// <param name="filterQueryCondition">original query filter that needs the conditions added</param>
        /// <returns>QueryConditionConfig representing search conditions</returns>
        public static QueryConditionConfig GenerateSearchWithIncludeCondition(IClientDataServices cds, DataContext dataContext, QueryConditionConfig filterQueryCondition)
        {
            if (cds == null)
            {
                LogWrapper.DibGeneralLog.Error("IClientDataServices is null");
                return null;
            }
            //we do not need to check root or exclude because the datacontext will
            //not allow an exclude to exist if there is not include
            if (dataContext.IncludePath.DataItemList.Count == 0)
                return filterQueryCondition;

            //make sure the devices are in the cache
            if (cds.GetCachedDevices() == null)
                return filterQueryCondition;


            //get include path and exlcude dataitem name
            string includePath = Path.HomeDataItemsToString(dataContext.IncludePath.DataItemList);
            string excludeName = string.Empty;
            excludeName = dataContext.ExcludeAllChildrenFromRoot ? dataContext.RootPath.DataItem.CommonName : dataContext.ExcludeAllChildrenFromPath.DataItem.CommonName;

            QueryConditionConfig.CreateBuilder builder = new QueryConditionConfig.CreateBuilder();

            //first condition must be an AND
            LogicOperatorType oper = LogicOperatorType.AND;

            //iterate all devices
            foreach (DataItemBase item in cds.GetCachedDevices())
            {
                QueryConditionItem.CreateBuilder queryConditionItemParent = new QueryConditionItem.CreateBuilder();
                queryConditionItemParent.SetLogicOperator(oper);

                string itemName = item.CommonName;
                //does this device have children that are excluded?
                if (string.Compare(excludeName, itemName, true) == 0)
                {

                    string tagsAndPropsPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + excludeName + DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER;
                    //add device tags 
                    queryConditionItemParent.AddConditionItem(new QueryConditionItem.CreateBuilder().SetIdentifier(DIBConstants.Common.AbsoluteName).SetIsExactMatch(false).SetValue(tagsAndPropsPath).SetLogicOperator(oper).Build());
                    //add the "included" item tags
                    queryConditionItemParent.AddConditionItem(new QueryConditionItem.CreateBuilder().SetIdentifier(DIBConstants.Common.AbsoluteName).SetIsExactMatch(false).SetValue(includePath + DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER).SetLogicOperator(LogicOperatorType.OR).Build());
                }
                else
                {
                    //just add all the devices that do not have an exclude
                    queryConditionItemParent.AddConditionItem(new QueryConditionItem.CreateBuilder().SetIdentifier(DIBConstants.Common.AbsoluteName).SetIsExactMatch(false).SetValue(DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + itemName).SetLogicOperator(oper).Build());
                }

                QueryConditionItem queryConditionItemParentBuilt = queryConditionItemParent.Build();
                //If there was only one item added, we dont need it to be nested.
                if (queryConditionItemParentBuilt.GetQueryConditionItems.Count == 1) builder.AddConditionItem(queryConditionItemParentBuilt.GetQueryConditionItems[0]);
                //If there were multiple items added, keep them nested
                if (queryConditionItemParentBuilt.GetQueryConditionItems.Count > 1) builder.AddConditionItem(queryConditionItemParentBuilt);
                //only the first condition should be an AND
                if (oper == LogicOperatorType.AND)
                    oper = LogicOperatorType.OR;

            }
            //add any search/filter conditions to end of the builder
            if (filterQueryCondition != null)
            {
                QueryConditionItem.CreateBuilder filterConditionItemParent = new QueryConditionItem.CreateBuilder();
                filterConditionItemParent.SetLogicOperator(LogicOperatorType.AND);
                foreach (QueryConditionItem item in filterQueryCondition.GetQueryConditionItems)
                {
                    //the filter condition will have an AND operator
                    filterConditionItemParent.AddConditionItem(item);
                }
                QueryConditionItem filterConditionItemParentBuilt = filterConditionItemParent.Build();
                //If there was only one item added, we dont need it to be nested.
                if (filterConditionItemParentBuilt.GetQueryConditionItems.Count == 1) builder.AddConditionItem(filterConditionItemParentBuilt.GetQueryConditionItems[0]);
                //If there were multiple items added, keep them nested
                if (filterConditionItemParentBuilt.GetQueryConditionItems.Count > 1) builder.AddConditionItem(filterConditionItemParentBuilt);
            }
            return builder.Build();
        }


        #endregion
    }
}
