﻿using System;
using System.IO;
using AvalonUnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.Views;

namespace DataItemBrowserUT
{
    [TestClass]
    public class DataGridViewTest
    {
        /// <summary>
        /// DataGridView UI data binding check.
        /// </summary>
        [TestMethod()]
        public void DataGridView_DataBindingIsCorrectTest()
        {
            AvalonTestRunner.RunInSTA(delegate()
            {
                // Create the control using a delegate to ensure binding errors generated during
                // control creation are caught.
                Func<object> controlCreator = delegate()
                {
                    // what ever your control is called
                    DIBGridView control = new DIBGridView();
                    return control;
                };

                AvalonTestRunner.RunDataBindingTests(controlCreator);
            });
        }


        /// <summary>
        /// Test static data related to DIBGridViewAutomationManager
        /// </summary>
        [TestMethod()]
        public void DataGridView_GridSerilizationInitializeTest()
        {
            
            string GridRowDataFilePath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Rockwell Automation", "DIBdata.txt");
            FileInfo fileInfo = new FileInfo(GridRowDataFilePath);
            if (fileInfo.Exists)
                fileInfo.Delete(); //Delete is here to make sure that its not older than 2 days. Code in DIBGridViewAutomationManager checks last write time to the file 

            try
            {
                using (FileStream fs = fileInfo.Create()) { } //Create an emmpty file
            }
            catch (DirectoryNotFoundException e)
            {
                // If this user does not have the Designer installed....then lets not run the rest of this test
                // That will mean this test will only run on dev machines.
                e.ToString(); //This line only here to suppress compile warning "unused variable e"
                return;
            }

            fileInfo = null;

            DIBGridViewAutomationManager.HasInitializedStaticData = false;
            Assert.IsFalse(DIBGridViewAutomationManager.HasInitializedStaticData);

            DIBGridViewAutomationManager gridAutomationManager = new DIBGridViewAutomationManager();

            Assert.IsTrue(DIBGridViewAutomationManager.HasInitializedStaticData);

            gridAutomationManager.ColumnVisibleChanged(null);
            gridAutomationManager.GridDataLoadComplete(null);

            fileInfo = new FileInfo(GridRowDataFilePath);
            Assert.AreEqual(fileInfo.Length, 0);

            if (fileInfo.Exists) fileInfo.Delete(); 
        }
    }
}
