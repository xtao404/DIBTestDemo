﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Tags;

namespace TagFilterControl.DIBClientManagers
{
    public class Config
    {
        private static Config instance = new Config();
        private Config() { }
        public static Config GetInstance()
        {
            if (instance == null)
            {
                instance = new Config();
            }
            return instance;
        }

        public string Usage { get; set; }

        private bool isRefreshed = false;
        public bool IsRefreshed
        {
            get { return isRefreshed; }
            set { isRefreshed = value; }
        }

        private Dictionary<string, TagNode> isCheckedTags = new Dictionary<string, TagNode>();
        public Dictionary<string, TagNode> IsCheckedTags
        {
            get { return isCheckedTags; }
            set { isCheckedTags = value; }
        }

        private Dictionary<string, TagNode> acmCustomPropertiesFilter = new Dictionary<string, TagNode>();
        public Dictionary<string, TagNode> ACMCustomPropertiesFilter
        {
            get { return acmCustomPropertiesFilter; }
            set { acmCustomPropertiesFilter = value; }
        }

        private Dictionary<string, TagNode> memFilter = new Dictionary<string, TagNode>();
        public Dictionary<string, TagNode> MemFilter
        {
            get { return memFilter; }
            set { memFilter = value; }
        }
    }
}
