/*************************************************************************************
                                                                     
   ViewE DIBGridView
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.ComponentModel;
using Xceed.Wpf.DataGrid;
using Xceed.Wpf.DataGrid.Views;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.Logging;
using System.Windows.Automation.Peers;
using System.Windows.Data;



#endregion

namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Interaction logic for DIBGridView.xaml
    /// </summary>
    public partial class DIBGridView : Xceed.Wpf.DataGrid.DataGridControl
    {

        #region private members

        // table view used by xceed datagrid
        private TableView _DataItemTableView = new TableView();

        // Needed to react to changes in the Column's VisiblePosition dependency property.
        private DependencyPropertyDescriptor ColumnVisiblePositionPropertyDescriptor = null;
        private Column _MainColumn = null;
        private Column _DrillInArrowColumn = null;

        // Reflects the column manager row of the grid when the mouse is
        // down/dragging on a non-fixed column
        ColumnManagerRow _DraggingColManRow = null;

        // reference to the DataGrid view model
        private DIBGridViewModel _gridViewModel = null;

        // Needed to react to changes in the Column's SortDirection dependency property.
        private DependencyPropertyDescriptor ColumnSortDirectionPropertyDescriptor = null;

        // Needed to react to changes in the Column's SortIndex dependency property.
        private DependencyPropertyDescriptor ColumnSortIndexPropertyDescriptor = null;

        // Needed to react to changes in the Column's Visible dependency property.
        private DependencyPropertyDescriptor ColumnVisiblePropertyDescriptor = null;

        // Needed to react to changes in the Column's Width dependency property.
        private DependencyPropertyDescriptor ColumnWidthPropertyDescriptor = null;

        // When grid is active and user presses an alphanumeric keyboard key, we select a row whose first column name matches what was typed (AutoSelection feature)
        // The list of characters is stored in currentAutoCompleteString
        private String currentAutoCompleteString { get; set; }
        //The last time a user types in a key
        private DateTime lastAutoCompleteKeyInputTime { get; set; }

        private DIBGridViewAutomationManager gridViewAutomationManager = new DIBGridViewAutomationManager();

        //Used so that we can "inflate" the width of a column after a column header was double clicked (to
        // auto-size the column) as the default algorithm is slightly too tight and sometimes results in
        // ellipses remaining for the text in the widest column (not because of the TextBlockService but
        // because of the TextTrim setting of the TextBlock being computed by WPF)
        private double _DoubleClickedColumnWidth = 0;
        private readonly double _DoubleClickedColumnAutoFitInflation = 2;

        // Cached Styles and templates
        Style _TableViewDataRowStyle = null;
        DataTemplate _ColumnManagerRowTemplate = null;
        DataTemplate _ColumnDataTemplate = null;
        DataTemplate _DrillinColumnDataTemplate = null;
        TableViewScrollViewer _TemplateTableViewScrollViewer = null;

        public bool EnableSizeToContentWidth
        {
            get { return (bool)GetValue(EnableSizeToContentWidthProperty); }
            set { SetValue(EnableSizeToContentWidthProperty, value); }
        }

        /// <summary>
        /// True if this control is being asked to calculate it's width based
        /// on the current content
        /// </summary>
        public static readonly DependencyProperty EnableSizeToContentWidthProperty =
            DependencyProperty.Register("EnableSizeToContentWidth", typeof(bool), typeof(DIBGridView), new PropertyMetadata(false));       

        #endregion
        
        #region constructor

        /// <summary>
        /// constructor
        /// </summary>
        public DIBGridView()
        {
            InitializeComponent();
        }

        #endregion

        #region public interface

        /// <summary>
        /// Switch view presentation command between list view and table view
        /// </summary>
        private SimpleCommand _switchGridViewCommand = null;
        public ICommand SwitchGridViewCommand
        {
            get
            {
                if (_switchGridViewCommand == null)
                {

                    _switchGridViewCommand = new SimpleCommand()
                    {

                        ExecuteDelegate = x =>
                        {                            
                            //load the selected view
                            this.LoadViewPresentation();
                        }
                    };
                }
                return _switchGridViewCommand;
            }
        }

        #endregion

        #region "Keyboard Navigation"

        /// <summary>
        /// Attempt to drill into currently selected Item and give keyboard focus afterwards
        /// </summary>
        public void ProcessKeyboardRequestDrillIn()
        {
            // Dont even attempt this if we are not visible
            if (this._gridViewModel.Visible != Visibility.Visible)
                return;
            DataItemBase itemObj = (DataItemBase)this.SelectedItem;
            if (itemObj == null) return;
            //We cant drill into terminal node tags 
            if (!itemObj.IsStructured)
                return;

            _gridViewModel.DrillInCommand.Execute(itemObj);
        }

        /// <summary>
        /// Attempt to drill out from currently selected Item and give keyboard focus afterwards
        /// </summary>
        public void ProcessKeyboardRequestDrillOut()
        {
            // Dont even attempt this if we are not visible
            if (this._gridViewModel.Visible != Visibility.Visible)
                return;
            _gridViewModel.DrillOutCommand.Execute(null);
        }

        /// <summary>
        /// Attempt to select and give keyboard focus to the item above the currently selected tiem
        /// </summary>
        public void ProcessKeyboardRequestSelectPrevious()
        {
            // Dont even attempt this if we are not visible
            if (this._gridViewModel.Visible != Visibility.Visible)
                return;
            this.ProcessKeyboardRequestFocus();
            if (this.SelectedItem == null) return;
            if (this.Items.CurrentPosition == 0) return; //Don't allow a move up if we already at the top
            this.Items.MoveCurrentToPrevious();
            UserChangedHighlightedItem();
        }

        /// <summary>
        /// Attempt to select and give keyboard focus to the item below the currently selected item
        /// </summary>
        public void ProcessKeyboardRequestSelectNext()
        {
            // Dont even attempt this if we are not visible
            if (this._gridViewModel.Visible != Visibility.Visible)
                return;
            this.ProcessKeyboardRequestFocus();
            if (this.SelectedItem == null) return;
            if (this.Items.CurrentPosition == this.Items.Count - 1) return; //Don't allow a move down if we already at the bottom
            this.Items.MoveCurrentToNext();
            UserChangedHighlightedItem();
        }

        /// <summary>
        /// Give Keyboard Focus to the Grid
        /// </summary>
        public void ProcessKeyboardRequestFocus()
        {
            // Dont even attempt this if we are not visible
            if (this._gridViewModel != null && this._gridViewModel.Visible != Visibility.Visible)
                return;
            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, new System.Threading.ThreadStart(() =>
            {
                PrimProcessKeyboardRequestFocus(this);
            }));
        }

        /// <summary>
        /// Give Keyboard Focus
        /// </summary>
        /// <param name="iElement"></param>
        private static void PrimProcessKeyboardRequestFocus(IInputElement iElement)
        {
            if (iElement == null) return;
            Keyboard.Focus(iElement);
        }

        #region "GridAutoSelection functionality"

        /// <summary>
        /// Attempt to autoselect a row in the grid based on user keyboard input
        /// </summary>
        private void ProcessKeyboardAutoSelect(KeyEventArgs e)
        {
            this.AddToCurrentAutoCompleteString(e);
            string input = this.currentAutoCompleteString;
            int count = this.Items.Count;
            if (count < 1) return;
            //Look for autocomplete selection string
            for (int i = 0; i != count; i = i + 1)
            {
                DataItemBase s = this.Items[i] as DataItemBase;
                if (s == null) continue;
                String tName = s.ToString().Trim().ToLower();
                if (tName.StartsWith(input))
                {
                    this.CurrentItem = s;
                    this.BringItemIntoView(this.CurrentItem);
                    e.Handled = true;
                    return;
                }
            }

            //if we have only one character in the currentAutoCompleteString and we didn't find any selection, empty out currentAutoCompleteString
            if (this.currentAutoCompleteString.Length == 1) currentAutoCompleteString = String.Empty;
        }

        /// <summary>
        /// Add the key contained in "e" to the auto complete string
        /// </summary>
        /// <param name="e">Contains the key to add</param>
        private void AddToCurrentAutoCompleteString(KeyEventArgs e)
        {
            if (this.lastAutoCompleteKeyInputTime == null) this.lastAutoCompleteKeyInputTime = DateTime.Now;
            //if its been over 2 seconds since the last keypress, then reset the currentAutoComplete string
            if (DateTime.Now.Subtract(lastAutoCompleteKeyInputTime) >= TimeSpan.FromSeconds(2)) this.currentAutoCompleteString = String.Empty;
            currentAutoCompleteString = currentAutoCompleteString + KeyboardNavigation.stringValueOfKey(e);
            this.lastAutoCompleteKeyInputTime = DateTime.Now;
        }

        #endregion "GridAutoSelection functionality"

        #endregion "Keyboard Navigation"

        #region private interface

        /// <summary>
        /// datagrid control has completed loading
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridControl_Loaded(object sender, RoutedEventArgs e)
        {
            // cache a pointer to the VieweTagGridViewModel
            _gridViewModel = (DataContext as DIBGridViewModel);
            // return if we can't get the VieweTagGridViewModel, this is for the unit tests to run correctly
            if (_gridViewModel == null)
            {
                LogWrapper.DibGeneralLog.Debug("DataGridControl loaded but can't get dataGridViewModel, returning without finishing");
                return;
            }
            // listen for column configuration changes
            _gridViewModel.ColumnConfigurationChanged += new PropertyChangedEventHandler(dgVM_ColumnConfigurationChanged);
            _gridViewModel.GridDataLoadComplete += new PropertyChangedEventHandler(dgVM_GridDataLoadComplete);

            // Moved from the constructor
            this.View = _DataItemTableView;

            // Scrolling gives immediate update
            this.ItemScrollingBehavior = ItemScrollingBehavior.Immediate;

            // Select rows and not cells
            this.NavigationBehavior = NavigationBehavior.RowOnly;

            // Create DependencyPropertryDescriptor for SortDirectionProperty so change notifications can be handled
            ColumnSortDirectionPropertyDescriptor = DependencyPropertyDescriptor.FromProperty(Column.SortDirectionProperty, typeof(Column));

            // Create DependencyPropertryDescriptor for SortIndexProperty so change notifications can be handled
            ColumnSortIndexPropertyDescriptor = DependencyPropertyDescriptor.FromProperty(Column.SortIndexProperty, typeof(Column));

            // Create DependencyPropertryDescriptor for VisiblePositionProperty so change notifications can be handled
            ColumnVisiblePositionPropertyDescriptor = DependencyPropertyDescriptor.FromProperty(Column.VisiblePositionProperty, typeof(Column));

            // Create DependencyPropertryDescriptor for VisibleProperty so change notifications can be handled
            ColumnVisiblePropertyDescriptor = DependencyPropertyDescriptor.FromProperty(Column.VisibleProperty, typeof(Column));

            // Create DependencyPropertryDescriptor for WidthProperty so change notifications can be handled
            ColumnWidthPropertyDescriptor = DependencyPropertyDescriptor.FromProperty(Column.WidthProperty, typeof(Column));

            SetViewPresentation();
        }

        /// <summary>
        /// Called by View model when we have finished loading items in the grid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgVM_GridDataLoadComplete(object sender, PropertyChangedEventArgs e)
        {
            this.gridViewAutomationManager.GridDataLoadComplete(this);
        }

        /// <summary>
        /// Called by the framework when the DataGridControl gets focus
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void DataGridControl_GotFocus(object sender, RoutedEventArgs e)
        {
            //Manually make sure the focus is set to either the tags and properties
            // row or the previously selected row
            if (this.Visibility != Visibility.Visible) return;

            EnsureSelectedItemIsVisible();
        }

        /// <summary>
        /// event handler for column configuration changed in the view model
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dgVM_ColumnConfigurationChanged(object sender, PropertyChangedEventArgs e)
        {
            SetViewPresentation();
        }

        /// <summary>
        /// mouse double click in the datagrid control
        /// </summary>
        /// <param name="sender">dataRow</param>
        /// <param name="e"></param> 
        private void DataGridControl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DataRow dataRow = sender as DataRow;
            if (dataRow == null) return;
            if (this.SelectedItem == null) return;

            // Retrieve the name of the item from the DataSourceViewModel
            DataItemBase item = this.SelectedItem as DataItemBase;

            // Obtain the item slightly differently if SelectedItem is null which will be the
            // case when we double click on the tags and properties in the fixed header area
            if (this.SelectedItem == null) item = dataRow.Cells.First().DataContext as DataItemBase;

            if (item == null) return;

            // Defect 119781: DIB/DTB:  Double-clicking on drill-in arrow erroneously closes window and populates connect string.
            //   check if the mouse postion is over the Drillin arrow cell.
            Point mousePos = e.GetPosition(this);
            bool isMouseInDrillinCol = mousePos.X < _DrillInArrowColumn.ActualWidth;
            if (isMouseInDrillinCol) return;

            this.DataGridControl_processTagSelectAndClose(item);
        }

        /// <summary>
        /// The user has selected a TAG and indicated their intent to close the DIB.
        /// </summary>
        private void DataGridControl_processTagSelectAndClose(DataItemBase item)
        {
            if (item == null) return;
            
            // Keep the current item in sync with the selected item
            // Do this as the grid keeps the CurrentItem visible
            // and keyboard focused when the grid gains focus
            this.CurrentItem = this.SelectedItem;

            IPathElement pathElement = null;

            pathElement = PathElementFactory.Instance().CreatePathElement(item);

            // if we are in the DT Browser perspective, we need to decorate the path element 
            // with details required for proper DT Browser functionality.
            if (this._gridViewModel.Path.ActiveElement is DataTypePathElement)
            {
                // Drilling into a data type
                // The pathElement that was created will support a breadcrumb that may have a picture.
                // Save the path information from the DataItemBase in this pathElement.

                // Set the data type specific information
                DataItemPathElement dataItemPathElement = pathElement as DataItemPathElement;
                if (dataItemPathElement == null) throw new ArgumentNullException("dataItemPathElement");
                dataItemPathElement.AddPath(item.CommonOwner);
                dataItemPathElement.IsRootType = true;

                DataTypePathElement dataTypePathElement = this._gridViewModel.Path.ActiveElement as DataTypePathElement;
                if (dataTypePathElement.PathList.Count > 0)
                    dataTypePathElement.PathList[0] = item.CommonOwner;
                else
                    dataTypePathElement.PathList.Add(item.CommonOwner);
            }
            this._gridViewModel.Path.HighlightedElement = pathElement;

            _gridViewModel.DoubleClickSelection(item);
        }

        /// <summary>
        /// key down event in the datagrid control
        /// </summary>
        /// <param name="sender">not used</param>
        /// <param name="e"></param>
        private void DataGridControl_KeyDown(object sender, KeyEventArgs e)
        {
            //Attempt to process Grid AutoSelection (Select row in grid with first column Name matching keyboard string user has entered during last 2 seconds)
            if (!KeyboardNavigation.IsValidGridAutoSelectionKey(e)) return;
            this.ProcessKeyboardAutoSelect(e);
        }

        private void DataGridControl_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // We need to process ENTER here in PreviewKeyDown since eXced grid doesn't fire the ENTER keypress from KeyDown event
            if (e.Key == Key.Enter)
            {
                DataItemBase item = this.SelectedItem as DataItemBase;
                if (item == null) return;
                e.Handled = true;
                this.DataGridControl_processTagSelectAndClose(item);
            }
            //Fix for Defect DFCTS00293270. Page up or Down repeating (button is pressed continously) does not update the GUI during scroll
            else if (e.IsRepeat && (e.Key == Key.Next || e.Key == Key.Prior)) this.UpdateLayout();
        }

        /// <summary>
        /// User has selected an item in the grid via left mouse click, or navigation via up and down arrows.
        /// Xceed's grid instigates this event.  Triggers the setting of HighlightedElement
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataGridControl_SelectionChanged(object sender, DataGridSelectionChangedEventArgs e)
        {
            if (_gridViewModel == null)
                return;

            DataItemBase selectedItem = SelectedItem as DataItemBase;

            _gridViewModel.HandleSelectionChange(selectedItem);

            // Keep the current item in sync with the selected item
            // Do this as the grid keeps the CurrentItem visible
            // and keyboard focused when the grid gains focus
            CurrentItem = selectedItem;

            EnsureSelectedItemIsVisible();
        }

        /// <summary>
        /// Handler for the PreviewMouseLeftButtonDown so we can prevent "fixed"
        /// columns (drill-in and name) from being moved from their leftmost
        /// positions
        /// </summary>
        /// <param name="sender">The ColumnManagerCell that was clicked</param>
        /// <param name="e">Standard event args from the framework</param>
        void ColumnManagerMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //Determine if the left mouse button down was on a column manager cell
            // (i.e. a column header such as Name, Data Type, etc.)
            ColumnManagerCell clickedColMan = sender as ColumnManagerCell;
            if (clickedColMan != null)
            {
                //Determine if the clicked column manager is fixed (drill-in or name)
                bool isDrillInCol = clickedColMan.FieldName == _DrillInArrowColumn.FieldName;
                bool isNameCol = clickedColMan.FieldName == _MainColumn.FieldName;
                bool isFixedCol = isDrillInCol || isNameCol;

                //Set allow column reorder based on if we clicked on a fixed column or not
                ColumnManagerRow clickedColManRow = clickedColMan.ParentRow as ColumnManagerRow;
                if (clickedColManRow != null)
                {
                    clickedColManRow.AllowColumnReorder = !isFixedCol;

                    //If we didn't click on a fixed column, cache the column manager row
                    // so the mouse move handler of this class can enforce where the drop
                    // can occur
                    if (!isFixedCol)
                        _DraggingColManRow = clickedColManRow;
                }

                //Prevent the drill in column from being moved by
                // handling the left mouse button down message.  We
                // can do this because the drill in column does not
                // support sorting.
                if (isDrillInCol)
                    e.Handled = true;
            }
        }

        /// <summary>
        /// If the mouse is dragging a column, make sure we don't allow
        /// it to be dropped to the left of the drill-in and name columns
        /// </summary>
        /// <param name="sender">Item the mouse moved over</param>
        /// <param name="e">Standard event args from the framework</param>
        void ColumnManagerMouseMove(object sender, MouseEventArgs e)
        {
            //If our mouse is moving after having clicked on a
            // column manager row
            if (_DraggingColManRow != null)
            {
                if (e.LeftButton == MouseButtonState.Pressed)
                {
                    //Determine if the mouse position is within the area of the
                    // fixed columns (by adding the drill-in and name column widths)
                    Point mousePos = e.GetPosition(this);
                    double fixedColWidth = _DrillInArrowColumn.ActualWidth + _MainColumn.ActualWidth;
                    bool isMouseInFixedCols = mousePos.X < fixedColWidth;

                    //Set the allow column reordering on the grid accordingly
                    _DraggingColManRow.AllowColumnReorder = !isMouseInFixedCols;
                }
                //If the left mouse button is no longer down, null out the column
                // manager row that gets set in the left mouse button down handler
                // It is convenient to do this here so we don't have to have a
                // seperate mouse button up handler to do this one line
                else
                    _DraggingColManRow = null;
            }
        }

        /// <summary>
        /// Capture the width of the column that was double clicked in this Preview
        /// event so we can properly determine in the standard (non-Preview) double
        /// click event whether an auto-fit column operation has occurred
        /// </summary>
        /// <param name="sender">The ColumnManagerCell that was double clicked</param>
        /// <param name="e">Standard event args from the framework</param>
        void ColumnManagerPreviewMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ColumnManagerCell colManagerCell = e.Source as ColumnManagerCell;
            _DoubleClickedColumnWidth = colManagerCell.ParentColumn.Width;
        }

        /// <summary>
        /// Inflate the column width when an auto fit operation occurs so we don't end
        /// up with unnecessary ellipses in the cell (texttrimming is turned on and the
        /// grid JUST slightly underallocates what is needed for the ellipses not to
        /// show by default)
        /// </summary>
        /// <param name="sender">The ColumnManagerCell that was double clicked</param>
        /// <param name="e">Standard event args from the framework</param>
        void ColumnManagerMouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            ColumnManagerCell colManagerCell = e.Source as ColumnManagerCell;
            //If the width of the column increased since the preview event, an auto resize
            // action occurred by the grid.  When this happens, we want to inflate the column
            // width slightly.
            if (_DoubleClickedColumnWidth != colManagerCell.ParentColumn.Width)
            {
                //Determine if this double click originated on the column resize thumb
                // and if so, increase the column size by a small amount.  This is done
                // because
                FrameworkElement clickedElement = e.OriginalSource as FrameworkElement;
                if (clickedElement != null && clickedElement.TemplatedParent != null)
                {
                    if (clickedElement.TemplatedParent is System.Windows.Controls.Primitives.Thumb)
                    {
                        colManagerCell.ParentColumn.Width += _DoubleClickedColumnAutoFitInflation;
                    }
                }
            }
        }

        /// <summary>
        /// We're interested in whether the user's selected a row (not drilling in) -- if they
        /// have, we fire an event.
        /// </summary>
        /// <param name="sender">unused</param>
        /// <param name="e">Standard event args from the framework</param>
        private void DataGridRow_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (_gridViewModel != null)
            {
                Point mousePos = e.GetPosition(this);
                bool isMouseInDrillinCol = mousePos.X < _DrillInArrowColumn.ActualWidth;
                if (isMouseInDrillinCol)
                    return;

                UserChangedHighlightedItem();
            }
        }

        /// <summary>
        /// We're interested in whether the user's selected a row (not drilling in) -- if they
        /// have, we fire an event.
        /// </summary>
        /// <param name="sender">unused</param>
        /// <param name="e">Standard event args from the framework</param>
        private void DataGridRow_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (_gridViewModel != null)
            {
                switch (e.Key)
                {
                    case Key.Up:
                    case Key.Down:
                    case Key.PageUp:
                    case Key.PageDown:
                    case Key.Home:
                    case Key.End:
                        UserChangedHighlightedItem();
                        break;

                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// The user may have changed the highlighted item -- we'll figure out if the
        /// highlighted item truly has changed and notify the user accordingly.
        /// </summary>
        private void UserChangedHighlightedItem()
        {
            //Ignore item highlighting when search is active since we may not have the full path
            // available to construct the string and resource id based properties to a client            
            if (_gridViewModel.IsSearchActive)
                return;

            List<IPathElement> tempList = _gridViewModel.Path.SelectedPath;

            //set the value of the path to be the parent path of the actual highlighted element, the highlighted element will be passed through the
            //UserChangedHighlightedItem below
            _gridViewModel.UserSetHighlightedPath = tempList;

            // One notable time this may be null -- when the user selects 'Tags and Properties'.
            // In that case, return without firing the event
            if (_gridViewModel.Path.HighlightedElement != null)
                tempList.Add(_gridViewModel.Path.HighlightedElement);


            // Set LastUserHighlightedItem if it has been changed
            string highlightedItem = _gridViewModel.CurrentPathStringFor(tempList);
            if (_gridViewModel.LastUserHighlightedItem != highlightedItem)
            {
                _gridViewModel.LastUserHighlightedItem = highlightedItem;
                _gridViewModel.UserChangedHighlightedItem(_gridViewModel.Path.HighlightedElement == null ? null : _gridViewModel.Path.HighlightedElement.DataItem);
            }
        }

        /// <summary>
        /// Use custom automation peer to expose more children of the data grid that exceed does by default
        /// </summary>
        /// <returns>Our custom flavor of automation peer</returns>
        protected override AutomationPeer OnCreateAutomationPeer()
        {
            return new DataGridAutomationPeer(this);
        }

        #endregion

        #region View initialization

        private Style TableViewDataRowStyle()
        {
            if (_TableViewDataRowStyle != null) return _TableViewDataRowStyle;
            _TableViewDataRowStyle = this.FindResource("TableViewDataRowStyle") as Style;
            return _TableViewDataRowStyle;
        }
        private DataTemplate ColumnManagerRowTemplate()
        {
            if (_ColumnManagerRowTemplate != null) return _ColumnManagerRowTemplate;
            _ColumnManagerRowTemplate = this.FindResource("columnManagerRowTemplate") as DataTemplate;
            return _ColumnManagerRowTemplate;
        }
        private DataTemplate ColumnDataTemplate()
        {
            if (_ColumnDataTemplate != null) return _ColumnDataTemplate;
            _ColumnDataTemplate = this.FindResource("ColumnDataTemplate") as DataTemplate;
            return _ColumnDataTemplate;
        }
        private DataTemplate DrillinColumnDataTemplate()
        {
            if (_DrillinColumnDataTemplate != null) return _DrillinColumnDataTemplate;
            _DrillinColumnDataTemplate = this.FindResource("DrillinColumnDataTemplate") as DataTemplate;
            return _DrillinColumnDataTemplate;
        }
        private TableViewScrollViewer TemplateTableViewScrollViewer()
        {
            if (_TemplateTableViewScrollViewer != null) return _TemplateTableViewScrollViewer;
            _TemplateTableViewScrollViewer = this.Template.FindName("PART_ScrollViewer", this) as TableViewScrollViewer;
            return _TemplateTableViewScrollViewer;
        }

        /// <summary>
        /// Sets up the table view and other grid related configuration settings (such as columns)
        /// </summary>
        private void SetViewPresentation()
        {
            RegisterColumnEventSubcriptions(true);

            this.ItemContainerStyle = this.TableViewDataRowStyle();

            //Set table view settings as desired
            _DataItemTableView.ShowFixedColumnSplitter = false;
            _DataItemTableView.FixedColumnSplitterWidth = 0;
            _DataItemTableView.FixedColumnSplitterDraggedCursor = Cursors.Arrow;
            _DataItemTableView.HorizontalGridLineThickness = 0;
            _DataItemTableView.VerticalGridLineThickness = 0;
            if (EnableSizeToContentWidth)
            {
                _DataItemTableView.ColumnStretchMode = ColumnStretchMode.None;
            }
            else
            {
                _DataItemTableView.ColumnStretchMode = ColumnStretchMode.Last;
            }
            _DataItemTableView.ShowRowSelectorPane = false;
            _DataItemTableView.AllowColumnChooser = true;
            _DataItemTableView.ColumnChooserSortOrder = ColumnChooserSortOrder.VisiblePosition;
            _DataItemTableView.UseDefaultHeadersFooters = false; //(no group-by control, column manager row, insertion row)
            this.View.FixedHeaders.Clear();
            this.View.FixedHeaders.Add(this.ColumnManagerRowTemplate());

            //Set up the columns array
            int visibleColumns = SetColumns();
            _DataItemTableView.FixedColumnCount = visibleColumns > 1 ? 2 : 1; // Fixed Column count represents the number of columns that do NOT scroll horizontally
                                                                              // when a user scrolls a horizonatal scroll bar. Here, we are saying that never want the 
                                                                              // 2 left most columns (drill in arrow column and name colomn) to scroll

            RegisterColumnEventSubcriptions();
        }

        /// <summary>
        /// Sets up the Columns property of the grid, clearing any existing items
        /// </summary>
        /// <returns>The number of visible columns added to the grid</returns>
        private int SetColumns()
        {
            int visibleColumns = 0;

            this.Columns.Clear();

            //order the column collection by the visible position (LINQ is so cool)
            var columnConfigs = from cc in _gridViewModel.Columns
                                orderby (cc.GetPosition) ascending
                                select cc;

            //add the drill-in button as the first column
            Column column = new Column
            {
                FieldName = "IsStructured", // The field name cannot be empty (XCeed rules), but needs to represent a method or property to call on the data source, 
                                            // (an instance of DataItemBase). If the FieldName does not exist, we will get a binding error and waste time 
                                            // in .net reflection looking for a property or method name that does not exists. 
                                            // The name of the property to execute in this situation is irrelevent as the cell content template for this column
                                            // only displays a drill in Arrow
                Width = 16,
                MaxWidth = 16,
                MinWidth = 16, 
                AllowSort=false,    // NO sorting on this column
                AllowGroup=false,   // Users cannot group by this column
                ReadOnly=true,      // Users cannot change the value or contents of this column
                Title = String.Empty,
                ShowInColumnChooser = false,
                CellContentTemplate = this.DrillinColumnDataTemplate()
            };

            //we do not want to be able to resize this column
            //no header title
            _DrillInArrowColumn = column;
            this.Columns.Add(column);

            // Create the grid's columns using the configuration data.
            foreach (ColumnConfigMapItem cc in columnConfigs)
            {
                // Create the grid's columns using the configuration data.
                column = new Column { FieldName = cc.GetColumn };

                if (cc.GetPosition == 0)
                {
                    // Remember the Main Column
                    _MainColumn = column;
                    column.IsMainColumn = true;

                    // Bind the name column's max width to the viewport (i.e. non-scrollbar area) width
                    // so that it doesn't ever get made so wide that it would otherwise not be possible
                    // to shrink back down (given it is a frozen/non-srolling column).  This keeps the
                    // name column resizer thumb at the rightmost part of the window where it will stop.
                    TableViewScrollViewer gridTableViewSv = this.TemplateTableViewScrollViewer();
                    if (gridTableViewSv != null)
                    {
                        Binding viewportWidthBinding = new Binding();
                        viewportWidthBinding.Source = gridTableViewSv;
                        viewportWidthBinding.Path = new PropertyPath(TableViewScrollViewer.ViewportWidthProperty.Name);
                        viewportWidthBinding.Mode = BindingMode.OneWay;
                        viewportWidthBinding.UpdateSourceTrigger = System.Windows.Data.UpdateSourceTrigger.PropertyChanged;
                        viewportWidthBinding.Converter = new NameColumnMaxWidthValueConverter();
                        viewportWidthBinding.ConverterParameter = _DrillInArrowColumn;
                        BindingOperations.SetBinding(column, Column.MaxWidthProperty, viewportWidthBinding);
                    }
                }

                if (cc.GetMinWidth.CompareTo(double.NaN) != 0) // if double.Nan then MinWidth not set
                {
                    column.MinWidth = cc.GetMinWidth;
                }

                // The title is used as the display string in the grid header for the column
                column.Title = cc.GetTitle;

                //add 1 because the drill in arrow is at position zero
                column.VisiblePosition = cc.GetPosition + 1;

                // Check cc.GetCurrentWidth < cc.GetMinWidth has been moved to ClientDataServices::UpdateColumnsWithPersistedData
                column.Width = cc.GetCurrentWidth;

                column.ShowInColumnChooser = cc.GetCanHide;
                column.Visible = cc.GetVisible;

                if (cc.GetVisible)
                    visibleColumns++;

                //Use custom data template so converter can be used to format cell values as desired
                column.CellContentTemplate = this.ColumnDataTemplate();

                this.Columns.Add(column);
            }

            return visibleColumns;
        }

        #region loadViewPresentation

        /// <summary>
        /// Loads our view presentation
        /// </summary>
        private void LoadViewPresentation()
        {
            // Null out the existing data template
            this.ItemTemplate = null;

            // Set all the attributes for our view
            this.SetViewPresentation();
        }

        #endregion

        #region ensureSelectedItemIsVisible

        /// <summary>
        /// Helper to make sure the selected item of the grid is scrolled into view
        /// </summary>
        private void EnsureSelectedItemIsVisible()
        {
            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Render, new System.Threading.ThreadStart(() =>
            {
                IInputElement selectedInputElement = null;

                if (this.SelectedItem != null)
                {
                    //For scrolling
                    this.BringItemIntoView(this.SelectedItem);
                    this.CurrentItem = this.SelectedItem;

                    selectedInputElement = this.GetContainerFromItem(this.SelectedItem) as IInputElement;
                }

                //For keyboard focus (i.e. the caret)
                if (selectedInputElement != null)
                {
                    FocusManager.SetFocusedElement(this, selectedInputElement);
                }

                //DON'T do a "this.Focus" here as this needs to be left up to those
                // changing the selected item of the grid (via navigate or other
                // means).  If we were to do this here, someone trying to set
                // explicit focus may be ignored because this happens on a different
                // thread.  An example of this is the ClearSearchCommand on the DIB
                // which sets focus back to the search filter textbox after
                // executing the filter command (which refreshes the view and thus
                // the selected item in the grid).

            }));
        }

        #endregion

        #endregion

        #region Column Configuration Change Handlers

        /// <summary>
        /// A column's visibility has changed
        /// </summary>
        protected void ColumnVisible_ChangeNotificationHandler(object sender, EventArgs e)
        {
            Column column = sender as Column;
            if (column != null)
            {
                LogWrapper.DibGeneralLog.Debug("Column " + column.FieldName + " visibility has changed to " + column.Visible.ToString()); 
                // Store the change notification into the ColumnConfig
                _gridViewModel.UpdateColumnConfig_Visible(column.FieldName, column.Visible);
            }

            int visibleColumns = this.Columns.Cast<Column>().Count(col => col.Visible);
            // The VisibleColums includes the DrillInArrowColumn
            _DataItemTableView.FixedColumnCount = visibleColumns > 2 ? 2 : 1;

            this.gridViewAutomationManager.ColumnVisibleChanged(this);
        }

        /// <summary>
        /// A column's width has changed
        /// </summary>
        protected void ColumnWidth_ChangeNotificationHandler(object sender, EventArgs e)
        {
            Column column = sender as Column;
            if (column != null)
            {
                LogWrapper.DibGeneralLog.Debug("Column " + column.FieldName + " width has changed to " + column.Width.ToString());
                // Store the change notification into the ColumnConfig
                _gridViewModel.UpdateColumnConfig_CurrentWidth(column.FieldName, column.Width);
            }
        }

        /// <summary>
        /// A column has been moved.  Persist the new change the ColumnConfig.
        /// </summary>
        protected void ColumnVisiblePosition_ChangeNotificationHandler(object sender, EventArgs e)
        {
            Column column = sender as Column;
            if (column != null)
            {
                LogWrapper.DibGeneralLog.Info("Moving column " + column.FieldName + " now: " + column.VisiblePosition); 
                // Store the change notification into the ColumnConfig.  Subtract 1 because the DrillIn column should not be counted.
                _gridViewModel.UpdateColumnConfig_VisiblePosition(column.FieldName, column.VisiblePosition - 1);

                this.gridViewAutomationManager.ColumnVisiblePositionChanged(this);
            }
        }


        /// <summary>
        /// The SortDirection on a column has changed
        /// </summary>
        protected void ColumnSortDirection_ChangeNotificationHandler(object sender, EventArgs e)
        {
            Column column = sender as Column;
            if (column != null)
            {
                // Store the col's SortDirection
                _gridViewModel.UpdateColumnConfig_SortDirection(column.FieldName, column.SortDirection);

                this.gridViewAutomationManager.ColumnSortDirectionChanged(this);
            }
        }


        /// <summary>
        /// The SortIndex on a column has changed
        /// </summary>
        protected void ColumnSortIndex_ChangeNotificationHandler(object sender, EventArgs e)
        {
            Column column = sender as Column;
            if (column != null)
            {
                // Store the col's SortIndex and SortDirection
                _gridViewModel.UpdateColumnConfig_SortIndex(column.FieldName, column.SortIndex);

                this.gridViewAutomationManager.ColumnSortIndexChanged(this);
            }
        }

        #endregion

        #region Event Subscriptions Cleanup

        /// <summary>
        /// Add or Remove event handlers registered for column headers
        /// </summary>
        /// <param name="remove">True to add value changed handlers, false to remove them</param>
        private void RegisterColumnEventSubcriptions(bool remove = false)
        {
            foreach (Column column in this.Columns.Cast<Column>().Where(col => col != _DrillInArrowColumn))
            {
                if (remove)
                {
                    ColumnSortDirectionPropertyDescriptor.RemoveValueChanged(column,   ColumnSortDirection_ChangeNotificationHandler);
                    ColumnSortIndexPropertyDescriptor.RemoveValueChanged(column,       ColumnSortIndex_ChangeNotificationHandler);
                    ColumnVisiblePositionPropertyDescriptor.RemoveValueChanged(column, ColumnVisiblePosition_ChangeNotificationHandler);
                    ColumnVisiblePropertyDescriptor.RemoveValueChanged(column,         ColumnVisible_ChangeNotificationHandler);
                    ColumnWidthPropertyDescriptor.RemoveValueChanged(column,           ColumnWidth_ChangeNotificationHandler);
                }
                else
                {
                    ColumnSortDirectionPropertyDescriptor.AddValueChanged(column,   new EventHandler(ColumnSortDirection_ChangeNotificationHandler));
                    ColumnSortIndexPropertyDescriptor.AddValueChanged(column,       new EventHandler(ColumnSortIndex_ChangeNotificationHandler));
                    ColumnVisiblePositionPropertyDescriptor.AddValueChanged(column, new EventHandler(ColumnVisiblePosition_ChangeNotificationHandler));
                    ColumnVisiblePropertyDescriptor.AddValueChanged(column,         new EventHandler(ColumnVisible_ChangeNotificationHandler));
                    ColumnWidthPropertyDescriptor.AddValueChanged(column,           new EventHandler(ColumnWidth_ChangeNotificationHandler));
                }
            }
        }

        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {
            _gridViewModel.Cleanup();
            _gridViewModel.ColumnConfigurationChanged -= new PropertyChangedEventHandler(dgVM_ColumnConfigurationChanged);
            _gridViewModel.GridDataLoadComplete -= new PropertyChangedEventHandler(dgVM_GridDataLoadComplete);

            RegisterColumnEventSubcriptions(true);
        }

        #endregion

    }
}
