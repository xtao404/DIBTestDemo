﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Controls.PreFilterManager.FilterObject
{
    public class FilterOptionsSubProfileContent
    {
        public List<FilterReturnBase> FilterOptions { get; set; }

        public FilterOptionsSubProfileContent()
        {
            FilterOptions = new List<FilterReturnBase>();
        }
    }
}
