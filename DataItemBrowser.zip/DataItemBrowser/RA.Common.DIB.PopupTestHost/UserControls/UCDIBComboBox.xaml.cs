﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Globalization;

namespace RockwellAutomation.DesignTimeClient.PopUpGenericTestHost
{
    /// <summary>
    /// Interaction logic for UCDIBComboBox.xaml
    /// </summary>
    public partial class UCDIBComboBox : UserControl
    {
        #region Constructor

        public UCDIBComboBox()
        {
            InitializeComponent();
        }

        #endregion

        #region Properties/ Variables / Dependency Properties

        /// <summary>
        /// Reference to the associated DIB
        /// </summary>
        private RockwellAutomation.UI.Views.DataItemBrowser dib = null;
        /// <summary>
        /// Reference to the Popup hosting the DIB
        /// </summary>
        private Popup popup = null;

        /// <summary>
        /// The string name of the class that represents the DIBClientManager
        /// </summary>
        public string DIBClientManagerName
        {
            get { return (string)GetValue(DIBClientManagerNameProperty); }
            set { SetValue(DIBClientManagerNameProperty, value); }
        }
        public static readonly DependencyProperty DIBClientManagerNameProperty =
            DependencyProperty.Register("DIBClientManagerName", typeof(string), typeof(UCDIBComboBox), new UIPropertyMetadata(String.Empty));

        /// <summary>
        /// The font size to use in all appropriate places in the DIB
        /// </summary>
        public double DesiredFontSize
        {
            get { return (double)GetValue(DesiredFontSizeProperty); }
            set { SetValue(DesiredFontSizeProperty, value); }
        }
        public static readonly DependencyProperty DesiredFontSizeProperty =
            DependencyProperty.Register("DesiredFontSize", typeof(double), typeof(UCDIBComboBox), new UIPropertyMetadata(0.0));

        /// <summary>
        /// The font to use in all appropriate places in the DIB
        /// </summary>
        public FontFamily DesiredFontFamily
        {
            get { return (FontFamily)GetValue(DesiredFontFamilyProperty); }
            set { SetValue(DesiredFontFamilyProperty, value); }
        }
        public static readonly DependencyProperty DesiredFontFamilyProperty =
            DependencyProperty.Register("DesiredFontFamily", typeof(FontFamily), typeof(UCDIBComboBox), new UIPropertyMetadata(null));

        /// <summary>
        /// The current HighlightedItem in the DIB
        /// </summary>
        public readonly static DependencyProperty HighlightedItemProperty =
            DependencyProperty.Register("HighlightedItem", typeof(string), typeof(UCDIBComboBox), new PropertyMetadata(String.Empty));
        public string HighlightedItem
        {
            get { return ((string)(base.GetValue(UCDIBComboBox.HighlightedItemProperty))); }
            set { base.SetValue(UCDIBComboBox.HighlightedItemProperty, value); }
        }

        /// <summary>
        /// Wether the Combo Box should be editable
        /// </summary>
        public bool IsComboTextBoxEditable
        {
            get { return (bool)GetValue(IsComboTextBoxEditableProperty); }
            set { SetValue(IsComboTextBoxEditableProperty, value); }
        }
        public static readonly DependencyProperty IsComboTextBoxEditableProperty =
            DependencyProperty.Register("IsComboTextBoxEditable", typeof(bool), typeof(UCDIBComboBox), new UIPropertyMetadata(true));

        #endregion

        #region Events

        /// <summary>
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dibComboBox_Loaded(object sender, RoutedEventArgs e)
        {
            DibComboBoxItem item = new DibComboBoxItem { ID = "Select an Item..." };
            dibComboBox.Items.Add(item);
            dibComboBox.SelectedItem = item;
        }

        /// <summary>
        /// Set the DIB reference
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataItemBrowser_Loaded(object sender, RoutedEventArgs e)
        {
            dib = sender as RockwellAutomation.UI.Views.DataItemBrowser;
        }

        /// <summary>
        /// An item in the DIB has been selected. 
        /// Change the implementation if we need multiple selection
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataItemBrowser_ItemSelected(object sender, RoutedEventArgs e)
        {
            String selecteditemStringName = string.Format(CultureInfo.InvariantCulture, "{0}", dib.SelectedItem);

            //Set the current DIB selected item in the combo box
            DibComboBoxItem selectedItem = new DibComboBoxItem() { ID = selecteditemStringName };
            dibComboBox.Items.Clear();
            dibComboBox.Items.Add(selectedItem);
            dibComboBox.SelectedItem = selectedItem;

            //Explicitly close the Popup
            popup.IsOpen = false;

            Keyboard.Focus(dibComboBox);
        }

        /// <summary>
        /// Allow for keyboard navigation in the DIB
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dibComboBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            //The Escape key normally closes the DIB window
            //We need to hook into the ESCAPE key using PreviewKeyDown (a tunnelling event) because the Xceed grid will not bubble an ESCAPE key KeyDown (a bubbling event). 
            //Here we check that context menus are not open. KeyUp would not work as a substitue to PreviewKeyDown since the context menus are already closed.
            if (e.Key == Key.Escape)
            {
                //Don't close if a DIB Search control context menu is up (we will get the ESC here before the search filter MRU given this is a preview event)
                if (!this.dib.IsSearchControlContextMenuOpen())
                {
                    e.Handled = true;
                    popup.IsOpen = false;
                    return;
                }
            }
            //If up or down is pressed and the data grid has focus but no selected item, make sure we send a secondary focus.
            // This solves a specific issue where we initially send focus to the grid when it has no items, and up and down key
            // presses are not picked up by the grid when items do start to load from the data services.
            else if (e.Key == Key.Down || e.Key == Key.Up)
            {
                //We not only check if the grid has focus but also if this (DIBWindow) has focus.  There is
                // a possibility that the window as a whole may get focus when selecting an item from a context
                // menu (specifically the forward/backward menu crumbs) and we still should consider this
                // a grid focused without selection with respect to the up/down arrow presses
                if (this.dib.IsDataGridFocusedWithNoSelection() || Keyboard.FocusedElement == this)
                {
                    this.dib.ProcessKeyboardRequestFocusToGrid();
                    //DON'T set e.handled to true here as we want the grid to handle the up/down press
                    return;
                }
            }

            //CTRL + F OR ALT + F. Attempt to give focus to the search textbox                      
            if ((Keyboard.Modifiers == ModifierKeys.Control) && (e.Key == Key.F) || (e.KeyboardDevice.Modifiers == ModifierKeys.Alt) && (e.SystemKey == Key.F))
            {
                e.Handled = true;
                this.dib.ProcessKeyboardRequestFocusToSearch();
                return;
            }
            //CTRL + L OR ALT + L. Give focus to Grid region
            if ((e.KeyboardDevice.Modifiers == ModifierKeys.Control) && (e.Key == Key.L) || (e.KeyboardDevice.Modifiers == ModifierKeys.Alt) && (e.SystemKey == Key.L))
            {
                e.Handled = true;
                this.dib.ProcessKeyboardRequestFocusToGrid();
                return;
            }

            if (e.KeyboardDevice.Modifiers != ModifierKeys.Alt) return;

            //ALT + LeftArrow. Attempt to Drill out 
            if (e.SystemKey == Key.Left)
            {
                e.Handled = true;
                this.dib.ProcessKeyboardRequestDrillOut();
                return;
            }
            //ALT + RightArrow. Attempt to Drill in 
            if (e.SystemKey == Key.Right)
            {
                e.Handled = true;
                this.dib.ProcessKeyboardRequestDrillIn();
                return;
            }
            //ALT + UpArrow. Attempt to select TAG above current tag in the data grid
            if (e.SystemKey == Key.Up)
            {
                e.Handled = true;
                this.dib.ProcessKeyboardRequestSelectPrevious();
                return;
            }
            //ALT + DownArrow. Attempt to select TAG below current tag in the data grid
            if (e.SystemKey == Key.Down)
            {
                e.Handled = true;
                this.dib.ProcessKeyboardRequestSelectNext();
                return;
            }
            //ALT. We dont want this key to close the DIB so dont allow them to bubble to the main window
            if ((e.SystemKey == Key.LeftAlt) || (e.SystemKey == Key.RightAlt))
            {
                //Let the ALT go through if a context menu is open on the search filter control (otherwise the
                // MRU list won't close when pressing ALT)
                if (!this.dib.IsSearchControlContextMenuOpen())
                    e.Handled = true;
            }
        }

        /// <summary>
        /// We activate the DIB when we receive notification that the Combo Box Drop down is opened. We could have done 
        /// this BEFORE the combo box drop down event so that when the drop down event is received, we display the DIB 
        /// faster but that would be at the performance expense of initializing the containing window
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dibComboBox_DropDownOpened(object sender, EventArgs e)
        {
            ComboBox combo = sender as ComboBox;
            popup = combo.Template.FindName("PART_Popup", combo) as Popup;

            dib.BrowserType = "tag"; //For now this must be set....untill further Generic DIB refactoring
            // Set the binding for the Font size and family
            dib.SetBinding(RockwellAutomation.UI.Views.DataItemBrowser.FontSizeProperty, new Binding("DesiredFontSize") { Source = this });
            dib.SetBinding(RockwellAutomation.UI.Views.DataItemBrowser.FontFamilyProperty, new Binding("DesiredFontFamily") { Source = this });

            // Set the DIB Client Manager
            RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager viewManager;
            viewManager = RockwellAutomation.DesignTimeClient.PopUpGenericTestHost.Window1.GetDIBClientManagerFor(this.DIBClientManagerName);
            viewManager.InitializeDIBControlOnStartup(dib, new System.Text.StringBuilder());
            viewManager.InitialLaunchString = dibComboBox.Text;

            dib.Initialize(viewManager,
                dibComboBox.Text);

            // Open the popUp manually
            popup.IsOpen = true;
            //Keyboard.Focus(dib);
        }

        /// <summary>
        /// Close the DIB when we lost keyboard focus except if the DIB has any ContextMenu's open
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dibComboBoxPopup_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            base.OnLostKeyboardFocus(e);

            // If no focused element, a different app has focus so okay to close
            if (Keyboard.FocusedElement == null)
            {
                popup.IsOpen = false;
                return;
            }
            // Don't close if we are showing a child window (i.e. the column filter builder dialog)
            if (dib.ChildWindowOpen)
            {
                Keyboard.Focus(dib);
                return;
            }
            // Don't close if we lost the keyboard focus to MRU Btton in DIB
            else if (Keyboard.FocusedElement is ToggleButton)
            {
                if ((Keyboard.FocusedElement as ToggleButton).Name == "SearchMruBtn")
                {
                    this.dib.ProcessKeyboardRequestFocusToSearch();
                    return;
                }
            }
            // Dont close the DIB if there is a context menu open
            else if (this.dib.IsAnyContextMenuOpen())
            {
                return;
            }
            // Don't close if we lost the keyboard focus to a child of the Popup
            else if (this.popup.IsAncestorOf(Keyboard.FocusedElement as DependencyObject))
            {
                Keyboard.Focus(dib);
                return;
            }
            // Don't close if we lost the keyboard focus to a child of the DIB
            else if (this.dib.IsAncestorOf(Keyboard.FocusedElement as DependencyObject))
            {
                return;
            }
            // Don't close if we lost the keyboard focus to a context menu of ours
            else if (Keyboard.FocusedElement is ContextMenu)
            {
                ContextMenu focusedContextMenu = Keyboard.FocusedElement as ContextMenu;
                if (focusedContextMenu.PlacementTarget != null &&
                    this.dib.IsAncestorOf(focusedContextMenu.PlacementTarget))
                {
                    Keyboard.Focus(dib);
                    return;
                }
            }
            // Check to make sure the parent of the focused element is a popup, the popup does
            // does not get the focus, the control inside the popup gets the focus
            else if (FindAncestor<Popup>(Keyboard.FocusedElement as FrameworkElement) != null)
            {
                //If this window is the ancestor of the popup's placement target then 
                //do not close the window
                Popup focusedPopup = FindAncestor<Popup>(Keyboard.FocusedElement as FrameworkElement);
                if (focusedPopup.PlacementTarget != null &&
                    IsAncestorOf(focusedPopup.PlacementTarget))
                {
                    Keyboard.Focus(dib);
                    return;
                }
            }

            // Close the popup
            popup.IsOpen = false;
        }

        /// <summary>
        /// find the ancestor framework element that is of type T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="fe"></param>
        /// <returns></returns>
        public static T FindAncestor<T>(FrameworkElement fe) where T : FrameworkElement
        {
            while (fe != null)
            {
                T o = fe as T;
                if (o != null)
                    return o;
                fe = fe.Parent as FrameworkElement;
            }
            return null;
        }

        #endregion

        #region DibComboBoxItem Class

        private class DibComboBoxItem
        {
            public string ID { get; set; }
            public override string ToString()
            {
                return ID;
            }
        }
        #endregion

    }
}
