﻿/* ****************************************************************************
*
*  Copyright 2015 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System;
using System.Windows;
using System.Windows.Data;
using RockwellAutomation.UI.Models;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    /// <summary>
    /// Separate window containing DIB Control
    /// 
    /// The window determines its size based on DIB content
    /// </summary>
    public partial class DIBContainerWindowSizeToContent : Window
    {
        public DIBClientManager DIBClientManager;
        public DIBContainerWindowSizeToContent(string stringDIBClientManagerName, string launchText)
        {
            RockwellAutomation.UI.XceedDeploymentLicense.SetLicense();

            InitializeComponent();

            dib.BrowserType = "tag"; //For now this must be set....until further Generic DIB refactoring

            // Set the DIB Client Manager
            this.DIBClientManager = RockwellAutomation.DesignTimeClient.PopUpGenericTestHost.Window1.GetDIBClientManagerFor(stringDIBClientManagerName);
            this.DIBClientManager.InitializeDIBControlOnStartup(dib, new System.Text.StringBuilder());
            this.DIBClientManager.InitialLaunchString = launchText;

            this.dib.Initialize(
                this.DIBClientManager,
                launchText);
        }
    }
}
