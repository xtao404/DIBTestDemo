﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using RockwellAutomation.UI.Windows;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    /// <summary>
    /// Interaction logic for DIBTesterWindow_5_ListView.xaml
    /// </summary>
    public partial class DIBTesterWindow_5_ListView : Window
    {
        public DIBTesterWindow_5_ListView()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DIBWindow dibBrowser = new DIBWindow(TextBoxLaunchDIBResults, new DIBClientManager_5_ListView()) { PersistWindow = false };
            dibBrowser.ItemSelectedEventHandler += new RoutedEventHandler(BrowserItemSelected);
            dibBrowser.Initialize(String.Empty);
            dibBrowser.Show();
        }

        private void BrowserItemSelected(object sender, RoutedEventArgs e)
        {
            this.TextBoxLaunchDIBResults.Text = ((DIBWindow)sender).SelectedItem;
        }
    }
}
