﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TagFilterControl.Common;
using TagFilterControl.Controls;
using TagFilterControl.DIBClientManagers.DataGridViewSimple;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace TagFilterControl.UserControls
{
    public partial class FilterDIB : UserControl
    {
        public FilterDIBViewModel FilterDIBVM { get; set; }
        public FilterDIBInstance FilterDIBIn { get; set; }
        public FilterDIB()
        {
            InitializeComponent();
            FilterDIBVM = new FilterDIBViewModel(this);
            this.DataContext = FilterDIBVM;

            FilterDIBIn = FilterDIBInstance.GetInstance();
            FilterDIBIn.InitializeDIBClientManager(this);
            FilterDIBIn.Trigger();
        }

        public System.Windows.Threading.Dispatcher _Dispatcher
        {
            get { return this.Dispatcher; }
        }
    }
}
