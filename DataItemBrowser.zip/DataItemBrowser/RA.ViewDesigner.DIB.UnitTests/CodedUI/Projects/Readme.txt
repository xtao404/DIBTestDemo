This folder contains:
	
Project12.vpd 
	- This is the current viewe project used to run the coded UI tests with

StructuresArraysBits_filter_V21.beforeQSPMockShrink.L5X
	- This represents the lf5 file used to create the Project12.vpd file.
	
StructuresArraysBits_filter_V21.L5X
	- This file is similar to StructuresArraysBits_filter_V21.beforeQSPMockShrink.L5X except that it has been purposely shrunk in order to have QSP 
mock work. Currently, QSP mock gets a out of memory error when loading the larger L5X file and so we strip out unneded info.
The best fix to this will be to change QSP Mock to use a different parsing technique so we dont need to strip down the size of the L5x file.
TO DO: Change QSP Mock to not use the full DOM parser that loads the full xml file contents in memory, but a parser that reads one line at a time.