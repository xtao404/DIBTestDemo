﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.IO;
using System.Text.RegularExpressions;
using TagFilterControl.Object;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Tags;
using TagFilterControl.Controls.PreFilterManager.Common;
using System.Xml.Serialization;

namespace TagFilterControl.Utility
{
    public class XMLHelper
    {
        private Config config = Config.GetInstance();

        #region Sets
        public Dictionary<string, List<BaseAttribute>> ControllerSubChildrensKeyValuePair { get; private set; }

        public Dictionary<string, List<TagObjects>> ProgramTagsKeyValuePair { get; private set; }

        public List<TagDataType> DataTypes { get; private set; }

        public List<TagDataType> UserDefined { get; private set; }

        public List<TagDataType> Strings { get; private set; }

        public List<TagDataType> AddOnDefined { get; private set; }

        public List<TagDataType> PreDefined { get; private set; }

        public List<TagDataType> ModuleDefined { get; private set; }

        public List<TagObjects> Usage { get; private set; }

        public List<string> TempUsage { get; set; }

        public List<TagObjects> ControllerTags { get; private set; }

        public List<string> UsedTags { get; set; }

        public List<LibraryEntity> Libs { get; set; }

        public Dictionary<string, string> TagOwners { get; set; }
        #endregion

        public string ControllerName { get; private set; }

        private static XMLHelper instance;
        public XMLHelper()
        {
            ControllerSubChildrensKeyValuePair = new Dictionary<string, List<BaseAttribute>>();
            ProgramTagsKeyValuePair = new Dictionary<string, List<TagObjects>>();
            ControllerTags = new List<TagObjects>();
            DataTypes = new List<TagDataType>();
            UserDefined = new List<TagDataType>();
            Strings = new List<TagDataType>();
            AddOnDefined = new List<TagDataType>();
            PreDefined = new List<TagDataType>();
            ModuleDefined = new List<TagDataType>();
            Usage = new List<TagObjects>();
            TempUsage = new List<string>();
            UsedTags = new List<string>();
            Libs = new List<LibraryEntity>();
            TagOwners = new Dictionary<string, string>();
        }
        public static XMLHelper GetInstance()
        {
            if (instance == null)
            {
                instance = new XMLHelper();
            }
            return instance;
        }

        public void LoadTagsTreeStructure(XmlDocument xmlDoc)
        {
            if (xmlDoc == null)
            {
                return;
            }
            try
            {
                XmlElement controller = xmlDoc.DocumentElement.SelectSingleNode("/RSLogix5000Content/Controller") as XmlElement;
                XmlNodeList controllerTags = xmlDoc.DocumentElement.SelectNodes("/RSLogix5000Content/Controller/Tags/Tag");
                XmlNodeList programs = xmlDoc.DocumentElement.SelectNodes("/RSLogix5000Content/Controller/Programs/Program");
                XmlNodeList dataTypes = xmlDoc.DocumentElement.SelectNodes("/RSLogix5000Content/Controller/DataTypes/DataType");
                XmlNodeList aois = xmlDoc.DocumentElement.SelectNodes("/RSLogix5000Content/Controller/AddOnInstructionDefinitions/AddOnInstructionDefinition");

                XmlNodeList customProperties = xmlDoc.DocumentElement.SelectNodes("/RSLogix5000Content/Controller/CustomProperties/Provider");


                #region TagsInUsed
                XmlNodeList tagsInSFC = xmlDoc.DocumentElement.SelectNodes("/RSLogix5000Content/Controller/Programs/Program/Routines/Routine/SFCContent");
                XmlNodeList tagsInFBD = xmlDoc.DocumentElement.SelectNodes("/RSLogix5000Content/Controller/Programs/Program/Routines/Routine/FBDContent/Sheet");
                XmlNodeList tagsInLR = xmlDoc.DocumentElement.SelectNodes("/RSLogix5000Content/Controller/Programs/Program/Routines/Routine/RLLContent/Rung");
                #endregion

                string controllerName = controller.GetAttribute("Name");
                ControllerName = controllerName;
                ControllerSubChildrensKeyValuePair[controllerName] = new List<BaseAttribute>();
                ControllerSubChildrensKeyValuePair[controllerName].Add(new BaseAttribute() { Name = "ControllerTags" });
                ControllerSubChildrensKeyValuePair[controllerName].Add(new BaseAttribute() { Name = "ProgramTags" });

                #region Tags
                foreach (XmlElement tag in controllerTags)
                {
                    try
                    {
                        TagObjects tempTag = GetTagAttr(tag);
                        if (ControllerTags.Find(t => t.Name.Equals(tempTag.Name)) == null)
                        {
                            if (!ControllerTags.Contains(tempTag))
                            {
                                ControllerTags.Add(tempTag);
                            }
                        }
                    }
                    catch (Exception)
                    {
                    }
                }

                foreach (XmlElement program in programs)
                {
                    try
                    {
                        string programName = program.GetAttribute("Name");
                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(program.OuterXml);
                        XmlNodeList programTags = doc.DocumentElement.SelectNodes("/Program/Tags/Tag");
                        foreach (XmlElement tag in programTags)
                        {
                            try
                            {
                                TagObjects tempTag = GetTagAttr(tag);
                                if (!ProgramTagsKeyValuePair.Keys.Contains(programName))
                                {
                                    ProgramTagsKeyValuePair[programName] = new List<TagObjects>() { tempTag };
                                }
                                else
                                {
                                    ProgramTagsKeyValuePair[programName].Add(tempTag);
                                }
                            }
                            catch (Exception)
                            {
                            }
                        }
                    }
                    catch (Exception)
                    {
                    }
                }
                #endregion

                #region DataTypes
                foreach (XmlElement dataType in dataTypes)
                {
                    try
                    {
                        GetDataTypeAttr(dataType);
                    }
                    catch (Exception)
                    {
                    }
                }

                foreach (XmlElement aoi in aois)
                {
                    try
                    {
                        GetDataTypeAttr(aoi, true);
                    }
                    catch (Exception)
                    {
                    }
                }
                #endregion

                #region UsedTags
                foreach (XmlElement item in tagsInSFC)
                {
                    foreach (XmlElement child in item.ChildNodes)
                    {
                        string operand = child.GetAttribute("Operand");
                        if (operand.Contains("."))
                        {
                            operand = operand.Substring(0, operand.IndexOf('.'));
                        }
                        if (!string.IsNullOrEmpty(operand) && !UsedTags.Contains(operand))
                        {
                            UsedTags.Add(operand);
                        }
                    }
                }

                foreach (XmlElement item in tagsInFBD)
                {
                    foreach (XmlElement child in item.ChildNodes)
                    {
                        string operand = child.GetAttribute("Operand");
                        if (operand.Contains("."))
                        {
                            operand = operand.Substring(0, operand.IndexOf('.'));
                        }
                        if (!string.IsNullOrEmpty(operand) && !UsedTags.Contains(operand))
                        {
                            UsedTags.Add(operand);
                        }
                    }
                }

                foreach (XmlElement item in tagsInLR)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(item.OuterXml);

                    XmlElement child = doc.DocumentElement.SelectSingleNode("/Rung/Text") as XmlElement;
                    string cdata = child.InnerText;

                    string partten = @"\(\w*\)*";
                    Regex reg = new Regex(partten);
                    MatchCollection mc = reg.Matches(cdata);
                    foreach (Match m in mc)
                    {
                        string st = m.Value;
                        st = st.TrimStart('(').TrimEnd(')');

                        if (st.Contains("."))
                        {
                            st = st.Substring(0, st.IndexOf('.'));
                        }

                        if (!string.IsNullOrEmpty(st) && !UsedTags.Contains(st))
                        {
                            UsedTags.Add(st);
                        }
                    }
                }
                #endregion

                #region CustomProperties
                string xmlCOA = string.Empty;
                foreach (XmlElement item in customProperties)
                {
                    int ext;
                    if (int.TryParse(item.GetAttribute("Ext"), out ext))
                    {
                        if (ext == 0)
                        {
                            continue;
                        }
                        XmlDocument tempDco = new XmlDocument();
                        tempDco.LoadXml(item.OuterXml);
                        XmlElement coa = tempDco.DocumentElement.SelectSingleNode("/Provider/Data/Val") as XmlElement;
                        xmlCOA = xmlCOA + coa.InnerText;
                    }
                }

                XmlDocument xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(xmlCOA);
                XmlNodeList libs = xmlDocument.DocumentElement.SelectNodes("/ControllerCOA/Private/Lib");
                foreach (XmlElement item in libs)
                {
                    string guid = item.GetAttribute("Guid");
                    string catalogNumber = item.GetAttribute("CatalogNumber");
                    string libraryType = item.GetAttribute("LibraryType");
                    string contentType = item.GetAttribute("ContentType");

                    LibraryEntity lib = new LibraryEntity()
                    {
                        Guid = guid,
                        CatalogNumber = catalogNumber,
                        LibraryType = libraryType,
                        ContentType = contentType
                    };
                    this.Libs.Add(lib);
                }
                #endregion
            }
            catch (Exception)
            {
            }
        }

        private void GetDataTypeAttr(XmlElement dataType, bool isAOI = false)
        {
            TagDataType tempDataType = new TagDataType();
            string name = dataType.GetAttribute("Name");
            string uid = dataType.GetAttribute("UId");
            string parentUId = dataType.GetAttribute("ParentUId");
            if (!isAOI)
            {
                string family = dataType.GetAttribute("Family");
                string typeClass = dataType.GetAttribute("Class");
                string size = dataType.GetAttribute("Size");
                tempDataType.Family = (TagFamily)Enum.Parse(typeof(TagFamily), family);
                tempDataType.Class = (TagClass)Enum.Parse(typeof(TagClass), typeClass);
                tempDataType.Size = size;
            }
            else
            {
                tempDataType.Class = (TagClass)Enum.Parse(typeof(TagClass), "AOI");
            }
            tempDataType.Name = name;
            tempDataType.UId = uid;
            tempDataType.ParentUId = parentUId;

            switch (tempDataType.Class)
            {
                case TagClass.ProductDefined:
                    Distinct(this.PreDefined, tempDataType);
                    break;
                case TagClass.IO:
                    Distinct(this.ModuleDefined, tempDataType);
                    break;
                case TagClass.User:
                    if (tempDataType.Family == TagFamily.StringFamily)
                    {
                        Distinct(this.Strings, tempDataType);
                    }
                    else
                    {
                        Distinct(this.UserDefined, tempDataType);
                    }
                    break;
                case TagClass.AOI:
                    Distinct(this.AddOnDefined, tempDataType);
                    break;
                default:
                    break;
            }
            Distinct(this.DataTypes, tempDataType);
        }

        private void Distinct(List<TagDataType> types, TagDataType tempDataType)
        {
            if (types.Find(t => t.Name.Equals(tempDataType.Name)) == null)
            {
                types.Add(tempDataType);
            }
        }

        private TagObjects GetTagAttr(XmlElement tag)
        {
            string tagName = tag.GetAttribute("Name");
            string tagType = tag.GetAttribute("TagType");
            string _dataType = tag.GetAttribute("DataType");
            string radix = tag.GetAttribute("Radix");
            string usage = tag.GetAttribute("Usage");
            string constant = tag.GetAttribute("Constant");
            string externalAccess = tag.GetAttribute("ExternalAccess");

            TagObjects tempTag = new TagObjects();
            tempTag.Name = tagName;
            tempTag.TagType = (TagType)Enum.Parse(typeof(TagType), tagType);
            tempTag.DataType = _dataType;
            tempTag.Radix = radix;
            tempTag.Usage = (TagUsage)Enum.Parse(typeof(TagUsage), string.IsNullOrEmpty(usage) ? "None" : usage);
            tempTag.Constant = constant;
            tempTag.ExternalAccess = externalAccess;

            if (!TempUsage.Contains(tempTag.Usage.ToString()))
            {
                Usage.Add(tempTag);
                TempUsage.Add(tempTag.Usage.ToString());
            }

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(tag.OuterXml);
            XmlNodeList tagProviders = doc.DocumentElement.SelectNodes("/Tag/CustomProperties/Provider");

            foreach (XmlElement item in tagProviders)
            {
                string ext = item.GetAttribute("Ext");
                if (ext.StartsWith("Origin"))
                {
                    if (ext.StartsWith("Origin_0"))
                    {
                        continue;
                    }

                    XmlDocument tempDco = new XmlDocument();
                    tempDco.LoadXml(item.OuterXml);
                    XmlElement val = tempDco.DocumentElement.SelectSingleNode("/Provider/Data/Val") as XmlElement;
                    XmlDocument tempDco2 = new XmlDocument();
                    tempDco2.LoadXml(val.InnerText);
                    XmlNodeList owners = tempDco2.DocumentElement.SelectNodes("/Origin/Owners/OwnedBy");
                    foreach (XmlElement oitem in owners)
                    {
                        string lGuid = oitem.GetAttribute("LGuid");
                        string instName = oitem.GetAttribute("InstName");
                        if (!tempTag.Owners.Keys.Contains(lGuid))
                        {
                            tempTag.Owners[lGuid] = instName;
                        }

                        if (!TagOwners.Keys.Contains(lGuid))
                        {
                            TagOwners[lGuid] = instName;
                        }
                    }
                }
            }

            XmlNodeList dataValueMembers = doc.DocumentElement.SelectNodes("/Tag/Data/Structure/DataValueMember");

            foreach (XmlElement item in dataValueMembers)
            {
                try
                {
                    string name = item.GetAttribute("Name");
                    string dataType = item.GetAttribute("DataType");
                    string _radix = item.GetAttribute("Radix");
                    string value = item.GetAttribute("Value");

                    DataValueMember dvm = new DataValueMember();
                    dvm.Name = name;
                    dvm.DataType = dataType;
                    dvm.TagType = tempTag.TagType;
                    dvm.Radix = _radix;
                    dvm.Value = value;

                    tempTag.DataValueMembers.Add(dvm);
                }
                catch (Exception)
                {
                }
            }
            return tempTag;
        }

        public XmlDocument XmlDoc { get; set; }

        public string fileName = "TagFilterConfig.xml";
        public void LoadXmlFile()
        {
            string path = string.Format("{0}\\{1}", Environment.CurrentDirectory, fileName);
            XmlDoc = new XmlDocument();
            XmlDoc.Load(path);
            //CacheFilterObject(XmlDoc);
        }

        private void CacheFilterObject(XmlDocument xmlDoc)
        {
            XmlElement filterTagType = xmlDoc.DocumentElement.SelectSingleNode("/TagFilterItems/TagType") as XmlElement;
            XmlNodeList filterDataTypes = xmlDoc.DocumentElement.SelectNodes("/TagFilterItems/DataTypes/DataType");

            string usage = filterTagType.GetAttribute("Name");
            config.Usage = usage;
            foreach (XmlElement item in filterDataTypes)
            {
                string dataType = item.GetAttribute("Name");
                string type = item.GetAttribute("Type");
                if (!string.IsNullOrEmpty(dataType) && !config.IsCheckedTags.Keys.Contains(dataType))
                {
                    config.IsCheckedTags[dataType] = new TagNode() { ParentName = type };
                }
            }
        }

        public List<List<String>> QueryValues()
        {
            List<List<String>> values = new List<List<string>>();
            XmlNode tagFilterItems = this.XmlDoc.DocumentElement.SelectSingleNode("/TagFilterItems");

            foreach (XmlElement tagFilterItem in tagFilterItems)
            {
                try
                {
                    List<string> val = new List<string>();
                    string id = tagFilterItem.GetAttribute("ID");
                    string name = tagFilterItem.GetAttribute("Name");
                    string action = tagFilterItem.GetAttribute("Action");

                    XmlDocument xmlDoc = new XmlDocument();
                    xmlDoc.LoadXml(tagFilterItem.OuterXml);
                    XmlNode stringContentNode = xmlDoc.SelectSingleNode("/TagFilterItem/StringContent");
                    XmlNode filterContentNode = xmlDoc.SelectSingleNode("/TagFilterItem/FilterContent");

                    string stringContent = stringContentNode.InnerText;
                    string filterContent = filterContentNode.InnerText;

                    val.Add(id);
                    val.Add(name);
                    val.Add(action);
                    val.Add(stringContent);
                    val.Add(filterContent);

                    values.Add(val);
                }
                catch (Exception)
                {
                }
            }
            return values;
        }
    }
}
