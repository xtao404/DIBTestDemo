﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Object
{
    public class LibraryEntity
    {
        public string Guid { get; set; }

        public string CatalogNumber { get; set; }

        public string LibraryType { get; set; }

        public string Owner { get; set; }

        public string ContentType { get; set; }

        public InterfaceLinks InterfaceLink { get; set; }
    }

    public class InterfaceLinks
    {
        public InterfaceLinks()
        {
            this.Interfaces = new List<Interface>();
        }

        public List<Interface> Interfaces { get; set; }
    }

    public class Interface
    {
        public string Name { get; set; }

        public string KeyId { get; set; }

        public string LinkId { get; set; }

        public string Rev { get; set; }

        public string Keying { get; set; }

        public string Usage { get; set; }

        public string Description { get; set; }

        public Members Member { get; set; }
    }

    public class Members
    {
        public Members()
        {
            this.Mems = new List<Mem>();
        }

        public List<Mem> Mems { get; set; }
    }

    public class Mem
    {
        public string Name { get; set; }

        public string DataType { get; set; }

        public string Value { get; set; }
    }
}
