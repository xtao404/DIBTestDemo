﻿namespace TagFilterControl.Common.Controls
{
    public enum WindowState
    {
        Closed,
        Open
    }

    public enum WindowStartupLocation
    {
        Center,
        Manual
    }
}
