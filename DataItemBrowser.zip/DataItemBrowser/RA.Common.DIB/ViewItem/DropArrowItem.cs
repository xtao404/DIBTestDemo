
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System;
namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// Objects of this type act as backing objects to menu items found in a crumb's
    /// context menu
    /// </summary>
    public class DropArrowItem
    {
        /// <summary>
        /// constructor
        /// </summary>
 
        public DropArrowItem() { }

        /// <summary>
        /// DisplayName property
        /// </summary>
        private string _DisplayName = String.Empty;
        public string DisplayName
        {
            get { return _DisplayName; }
            set { _DisplayName = value; }
        }

        /// <summary>
        /// is this element a container element
        /// </summary>
        private bool _isContainer;
        public bool IsContainer
        {
            get { return _isContainer; }
            set { _isContainer = value; }
        }

        /// <summary>
        /// Is the item text bold property
        /// </summary>
        private bool _isBold;
        public bool IsBold
        {
            get { return _isBold; }
            set {_isBold = value; }
        }

        /// <summary>
        /// HostCrumb: literally the crumb whose context menu acts as
        /// host to this item
        /// </summary>
        private ACrumb _hostCrumb = null;
        public ACrumb HostCrumb
        {
            get { return _hostCrumb; }
            set { _hostCrumb = value; }
        }

        /// <summary>
        /// Is this item decorated with an icon?
        /// </summary>
        public bool DisplayIcon
        {
            get
            {
                // TextCrumbs which represent a data type that is either ambiguous, duplicate, or both will obtain a display icon.
                TextCrumb crumb = HostCrumb as TextCrumb;
                if (crumb != null)
                {
                    return crumb.DisplayIcon;
                }
                else
                {
                    return false;
                }
            }
        }

		/// <summary>
		/// The unique id for the underlying component.
		/// </summary>
		private UUID _resourceId = null;
		public UUID ResourceId
		{
			get { return _resourceId; }
			set { _resourceId = value; }
		}

		/// <summary>
		/// The data item base for the underlying component.
		/// </summary>
		private DataItemBase _dataItem = null;
		public DataItemBase DataItem
		{
			get { return _dataItem; }
			set { _dataItem = value; }
		}

        /// <summary>
        /// If false the droparrowitem represents a separator that the context menu
        /// will not select.  If true this is a selectable droparrowitem.
        /// </summary>
        private bool _isSelectable = true;
        public bool IsSelectable
        {
            get { return _isSelectable; }
            set { _isSelectable = value; }
        }
    }
}
