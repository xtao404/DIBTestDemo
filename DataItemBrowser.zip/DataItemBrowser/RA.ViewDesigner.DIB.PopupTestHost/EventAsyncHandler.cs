﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;


namespace RockwellAutomation.DesignTimeClient.PopUpTestHost
{
    /// <summary>
    /// Class that handles asynchronous results from the ROA Session services.
    /// Handles all the locking and retries that are needed.
    /// 
    /// NOTE: There seem to be timing issues and/or false notifications 
    /// that require significant retry logix.
    /// 
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1001:TypesThatOwnDisposableFieldsShouldBeDisposable")]
    public class EventAsyncHandler
    {
        #region private members

        //
        // Each handler instance should have its own variables.
        // NOTE:
        //   These should NOT be static as is shown in the CS example code.
        //   Each handler must have its own List and Signal / Event.
        //
        private String _name = null;
        private LinkedList<Google.ProtocolBuffers.ByteString> responseList = new LinkedList<Google.ProtocolBuffers.ByteString>(); 
        private EventWaitHandle waitHandle = new AutoResetEvent(false); 
        private int responseReceived = 0;

        //
        // Timeout, Retry and Debug constants
        //
        private const int MAX_MSG_SIZE = 300;
        private const int TIMEOUT = 3000;       // 3 seconds per wait
        private const int RETRIES = 20;         // 20 wait retries

        #endregion

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="name">A friendly name (for debugging) of the Handler</param>
        public EventAsyncHandler(String name) { _name = name; }

        /// <summary>
        /// Helper method to log debug messages to TAF
        /// </summary>
        /// <param name="messageBody">the message to log</param>
        /// <param name="isEvent">true if this is an event receipt from ROA services, false if it is the TAF code retrieving the message</param>
        private void LogMessage(Google.ProtocolBuffers.ByteString messageBody, bool isEvent)
        {
            String msg = "[" + _name + "]" + (isEvent ? "EventSynchHandler: Received event #" : "EventSynchHandler: Found response for event #");
            if (messageBody == null)
            {
                //Log.Warning(msg + responseReceived + " NULL message body!");
                return;
            }

            //if (messageBody.Length < MAX_MSG_SIZE)
            //    Log.Debug(msg + responseReceived + " message body: " + messageBody.ToStringUtf8());
            //else
            //    Log.Debug(msg + responseReceived + " message body size: " + messageBody.Length);
        }

        /// <summary>
        /// Reset the handler to its initial state. Clear the queue and reset the event.
        /// </summary>
        public void Reset()
        {
            responseList.Clear();
            responseReceived = 0;
            waitHandle.Reset();
        }

        /// <summary>
        /// Called by the ROA services (actually the proxy) when an event message is received.
        /// </summary>
        /// <param name="messageBody">the received message</param>
        public void Handler(Google.ProtocolBuffers.ByteString messageBody) 
        { 
            Interlocked.Increment(ref responseReceived);

//            LogMessage(messageBody, true);

            // Lock the list since mutliple threads can hit it at the same time
            lock (responseList)
            {
                responseList.AddLast(messageBody);
            }
            // Fire the signal that an item is in the list
            waitHandle.Set();

            return; 
        }

        /// <summary>
        /// Check the list for a response message
        /// </summary>
        /// <returns>the message from the list or null if there is none</returns>
        private Google.ProtocolBuffers.ByteString CheckForResponse()
        {
            Google.ProtocolBuffers.ByteString messageBody = null;
            bool isFound = false;
            // Lock the list since mutliple threads can hit it at the same time
            lock (responseList)
            {
                if (responseList.Count > 0) {
                    messageBody = responseList.First();
                    responseList.RemoveFirst();
                    isFound = true;
                }
            }
            if (isFound) LogMessage(messageBody, false);
            return messageBody;
        }

        /// <summary>
        /// Wait for response data from the ROA Session services.
        /// Includes timeout and retry logic in an attempt to make sure
        /// a valid message is returned.
        /// </summary>
        /// <returns>the received message</returns>
        public Google.ProtocolBuffers.ByteString GetResponseData() 
        {
            bool success = false;
            int count = -1;

            // Check the list first since something may already be there
            // and we missed the signal because it's alrady fired.
            Google.ProtocolBuffers.ByteString messageBody = CheckForResponse();
            if (messageBody != null)
                return messageBody;

            // Wait for timer expiration events for no more than TIMEOUT seconds.
            // Retry RETRIES times before giving up.
            do
            {
                success = waitHandle.WaitOne(TIMEOUT, false);

                // Got a signal (or not), check for a response message
                // TODO: 
                //   There are cases where the signal fires, but there is no message.
                //   We are either getting a false signal or a null message on the Handler.
                //   This may require more investigation.
                messageBody = CheckForResponse();
                if (messageBody == null)
                {
                    //if (success) 
                    //    Log.Info("EventSynchHandler: found NULL response data, retrying");
                    //else if (count > 0)
                    //    Log.Warning("EventSynchHandler: TIMEOUT waiting for response data.  Timeout count: " + count);

                    success = false;
                }
                count++;

            } while (!success && (count < RETRIES));

            //if (messageBody == null)
            //    Log.Error("EventSynchHandler: returning NULL response data, signaled: ", success.ToString());

            return messageBody;
        } 
    } 
} 
 
   