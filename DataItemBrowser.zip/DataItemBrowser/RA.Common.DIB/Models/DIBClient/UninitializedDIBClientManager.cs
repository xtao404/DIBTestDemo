﻿using System.Collections.Generic;
using System.Text;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Views;
using System.Collections.ObjectModel;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    public class UninitializedDIBClientManager: DIBClientManager
    {
        override public System.IO.Stream GetGridColumnMetaData()
        {
            return null;
        }

        override public void DrillInFor(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        { 
            // Do nothing;
        }
    }
}
