﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public class FilterPolicyConverter : IValueConverter
    {
        private RuleItemForDisplay ruleItem;

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var item = value as ConditionFilterBase;
            Visibility visi = Visibility.Collapsed;
            RuleItemForDisplay rule = item.Rule as RuleItemForDisplay;
            ruleItem = rule;
            if (rule != null)
            {
                switch (rule.FilterRuleType)
                {
                    case FilterRuleType.Unknown:
                        break;
                    case FilterRuleType.TagType:
                    case FilterRuleType.UserDefined:
                    case FilterRuleType.Strings:
                    case FilterRuleType.AddOnDefined:
                    case FilterRuleType.ModuleDefined:
                    case FilterRuleType.PreDefined:
                    case FilterRuleType.TagOwner:
                        if (parameter.Equals("EditValueTB"))
                        {
                            visi = Visibility.Collapsed;
                        }
                        else if (parameter.Equals("EditValueCB"))
                        {
                            visi = Visibility.Visible;
                        }
                        break;
                    case FilterRuleType.TagName:
                        if (parameter.Equals("EditValueCB"))
                        {
                            visi = Visibility.Collapsed;
                        }
                        else if (parameter.Equals("EditValueTB"))
                        {
                            visi = Visibility.Visible;
                        }
                        break;
                    default:
                        break;
                }
            }

            return visi;

        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return ruleItem != null ? ruleItem : value;
        }
    }

    public class FilterPolicyForegroundConvertor : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var format = parameter.ToString();
            Color color = Colors.Black;

            if (format.Equals("DisplayValue"))
            {
                switch ((bool)value)
                {
                    case true:
                        color = Colors.Black;
                        break;

                    case false:
                        color = Color.FromArgb(255, 170, 170, 170);
                        break;
                }
            }
            else if (format.Equals("Foreground"))
            {

                switch ((ColorState)value)
                {
                    case ColorState.Normal:
                        color = Colors.Black;
                        break;
                    case ColorState.WaterMark:
                        color = Color.FromArgb(255, 170, 170, 170);
                        break;
                    case ColorState.Error:
                        color = Colors.Red;
                        break;
                }
            }

            return new SolidColorBrush(color);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value;
        }
    }
}
