﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public class FilterProfile
    {
        public string ID { get; set; }

        public string Name { get; set; }

        public string Content { get; set; }

        public FilterOptionsSubProfileContent FilterContent { get; set; }

        public OperationAction OperationActionType { get; set; }
    }

    public enum OperationAction
    {
        None,
        CreateNew,
        Update,
        Delete,
    }
}
