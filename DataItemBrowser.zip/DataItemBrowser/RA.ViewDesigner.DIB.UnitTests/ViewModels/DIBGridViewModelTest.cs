﻿/*************************************************************************************
                                                                     
   DIBGridViewModelTest Class
   Copyright © 2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System.Collections.ObjectModel;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Xceed.Wpf.DataGrid;

using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.WindowsControl.DIBClient;


namespace DataItemBrowserUT
{
    /// <summary>
    ///This is a test class for DIBGridViewModel and is intended to contain all DIBGridViewModel Unit Tests
    ///</summary>
    [TestClass()]
    public class DIBGridViewModelTest
    {
        [ClassInitialize()]
        public static void DIBGridViewModelTestClassInit(TestContext testContext)
        {
            // because these unit tests have the potential to call on the Xceed 
            // data grid, we need to make sure we set the license key so the 
            // unit tests don't get stuck with a license key exception.
            XceedDeploymentLicense.SetLicense();
        }

        /// <summary>
        /// A test for SelectedItem
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DIBGridViewModel_SelectedItemTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            DIBGridViewModel target = new DIBGridViewModel(mock);
            DataItemBase expected = new DataItemBase();
            //create Name property and assign it to the dataItemBase
            expected.CommonName = "selectedDataItemBase";
            target.SelectedItem = expected;
            DataItemBase actual = target.SelectedItem;
            Assert.AreEqual(expected.CommonName, actual.CommonName);
        }

        /// <summary>
        /// A test for ItemsSource
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DIBGridViewModel_ItemsSourceTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            DIBGridViewModel target = new DIBGridViewModel(mock);
            ObservableCollection<DataItemBase> dibs = new ObservableCollection<DataItemBase>();
            DataItemBase dib1 = new DataItemBase() { CommonName = "tag1" };
            dibs.Add(dib1);
            DataItemBase dib2 = new DataItemBase() { CommonName = "tag2" };
            dibs.Add(dib2);
            DataItemBase dib3 = new DataItemBase() { CommonName = "tag3" };
            dibs.Add(dib3);

            DataGridCollectionView expected = new DataGridCollectionView(dibs);
            PrivateObject privateTarget = new PrivateObject(target);
            privateTarget.SetProperty("ItemsSource", expected);

            DataGridCollectionView actual = target.ItemsSource;
            Assert.AreEqual(dibs[0].CommonName, (actual.GetItemAt(0) as DataItemBase).CommonName);
            Assert.AreEqual(dibs[1].CommonName, (actual.GetItemAt(1) as DataItemBase).CommonName);
            Assert.AreEqual(dibs[2].CommonName, (actual.GetItemAt(2) as DataItemBase).CommonName);
        }

        /// <summary>
        /// A test for GetDefaultItemtoSelectFrom that verifies that if we have a list of DataItemBases
        /// with one having its GUIIsInitiallyHighlighted value as true, then that item will be returned as the
        /// item to select.
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void GetSelectedDataItem_IfOneDataItemSelected_ReturnsThatItem()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            DIBGridViewModel target = new DIBGridViewModel(mock);
            ObservableCollection<DataItemBase> dibs = new ObservableCollection<DataItemBase>();
            DataItemBase dib1 = new DataItemBase() { CommonName = "tag1" };
            dibs.Add(dib1);
            DataItemBase dib2 = new DataItemBase() { CommonName = "tag2", GUIIsInitiallyHighlighted = "tRuE"};
            dibs.Add(dib2);
            DataItemBase dib3 = new DataItemBase() { CommonName = "tag3" };
            dibs.Add(dib3);

            DataGridCollectionView expected = new DataGridCollectionView(dibs);
            PrivateObject privateTarget = new PrivateObject(target);
            privateTarget.SetProperty("ItemsSource", expected);

            DataItemBase defaultItemToSelectFrom = privateTarget.Invoke("getDefaultItemToSelectFrom", privateTarget.GetProperty("ItemsSource", null)) as DataItemBase;
            Assert.AreNotEqual(dib1.CommonName, defaultItemToSelectFrom.CommonName);
            Assert.AreEqual(dib2.CommonName, defaultItemToSelectFrom.CommonName);
            Assert.AreNotEqual(dib3.CommonName, defaultItemToSelectFrom.CommonName);
        }

        /// <summary>
        /// A test for GetDefaultItemtoSelectFrom that verifies that if we have a list of DataItemBases
        /// with two having their GUIIsInitiallyHighlighted value as true, then the first of those will 
        /// be returned as the item to select.
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void GetSelectedDataItem_IfMultipleDataItemSelected_ReturnFirstSelectedItem()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            DIBGridViewModel target = new DIBGridViewModel(mock);
            ObservableCollection<DataItemBase> dibs = new ObservableCollection<DataItemBase>();
            DataItemBase dib1 = new DataItemBase() { CommonName = "tag1" };
            dibs.Add(dib1);
            DataItemBase dib2 = new DataItemBase() { CommonName = "tag2", GUIIsInitiallyHighlighted = "TRUE" };
            dibs.Add(dib2);
            DataItemBase dib3 = new DataItemBase() { CommonName = "tag3", GUIIsInitiallyHighlighted = "true" };
            dibs.Add(dib3);

            DataGridCollectionView expected = new DataGridCollectionView(dibs);
            PrivateObject privateTarget = new PrivateObject(target);
            privateTarget.SetProperty("ItemsSource", expected);

            DataItemBase defaultItemToSelectFrom = privateTarget.Invoke("getDefaultItemToSelectFrom", privateTarget.GetProperty("ItemsSource", null)) as DataItemBase;
            Assert.AreNotEqual(dib1.CommonName, defaultItemToSelectFrom.CommonName);
            Assert.AreEqual(dib2.CommonName, defaultItemToSelectFrom.CommonName);
            Assert.AreNotEqual(dib3.CommonName, defaultItemToSelectFrom.CommonName);
        }

        /// <summary>
        /// A test for GetDefaultItemtoSelectFrom that verifies that if we have a list of DataItemBases
        /// with none having their GUIIsInitiallyHighlighted value as true, then the first list element will 
        /// be returned as the item to select.
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void GetSelectedDataItem_IfNoDataItemSelected_ReturnsFirstListItem()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            DIBGridViewModel target = new DIBGridViewModel(mock);
            ObservableCollection<DataItemBase> dibs = new ObservableCollection<DataItemBase>();
            DataItemBase dib1 = new DataItemBase() { CommonName = "tag1" };
            dibs.Add(dib1);
            DataItemBase dib2 = new DataItemBase() { CommonName = "tag2" };
            dibs.Add(dib2);
            DataItemBase dib3 = new DataItemBase() { CommonName = "tag3" };
            dibs.Add(dib3);

            DataGridCollectionView expected = new DataGridCollectionView(dibs);
            PrivateObject privateTarget = new PrivateObject(target);
            privateTarget.SetProperty("ItemsSource", expected);

            DataItemBase defaultItemToSelectFrom = privateTarget.Invoke("getDefaultItemToSelectFrom", privateTarget.GetProperty("ItemsSource", null)) as DataItemBase;
            Assert.AreEqual(dib1.CommonName, defaultItemToSelectFrom.CommonName);
            Assert.AreNotEqual(dib2.CommonName, defaultItemToSelectFrom.CommonName);
            Assert.AreNotEqual(dib3.CommonName, defaultItemToSelectFrom.CommonName);
        }

        /// <summary>
        /// A test for GetDefaultItemtoSelectFrom that verifies that if we have an empty list of DataItemBases
        /// a NullReferenceException will be thrown.
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        [ExpectedException(typeof(System.NullReferenceException))]
        public void GetSelectedDataItem_IfDataListEmpty_ThrowsException()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            DIBGridViewModel target = new DIBGridViewModel(mock);
            ObservableCollection<DataItemBase> dibs = new ObservableCollection<DataItemBase>();

            DataGridCollectionView expected = new DataGridCollectionView(dibs);
            PrivateObject privateTarget = new PrivateObject(target);
            privateTarget.SetProperty("ItemsSource", expected);

            DataItemBase defaultItemToSelectFrom = privateTarget.Invoke("getDefaultItemToSelectFrom", privateTarget.GetProperty("ItemsSource", null)) as DataItemBase;
        }

    }
}
