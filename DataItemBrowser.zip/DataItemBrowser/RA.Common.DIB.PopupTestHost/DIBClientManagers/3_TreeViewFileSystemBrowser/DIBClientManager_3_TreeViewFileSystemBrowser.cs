﻿using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.DIBQuery;
using System.IO;
using System;
using System.Text;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.Views;
using System.Collections.ObjectModel;
using System.Xml.Linq;
using System.Linq;

/*
 * This sample demonstrates how to use the DIB as a tree-view file system browser.
 * 
 * If nothing is specified in the edit box next to the launch [...] button before launching the DIB the
 * content of c:\ will be displayed. If a location is specified, the dib will be navigated to that location.
 * 
 * To demonstrate how to perform initial drill in and item highlighting, populate the edit box next to the
 * launch [...] button before launching the DIB.  For this file system browser, enter either a path to a
 * file or directory.  If the last item of the drill in path is a directory, that path will be expanded
 * but no items selected. for example:
 * 
 *      Initial drill in path                        |    Displayed in DIB
 * --------------------------------------------------+------------------------------------
 * C:\directoryA\directoryB\directoryC\FileName.txt  | directoryC contents with FileName.txt highlighted and 
 *                                                   | visible in the DIB with the breadcrumbs populated
 * C:\directoryA\directoryB\                         | directoryB contents displayed with nothing in the 
 *                                                   | directory highlighted, the breadcrumbs populated
 * C:\directoryA\directoryB                          | directoryA contents with directoryB highlighted, 
 *                                                   | the breadcrumbs populated
 * 
 * Two methods of how to drill in are provided and controlled by setting useDibAutoDrillinFeature.  
 * 
 * One method used the DIB build-in drill in functionality. This method will perform calls to DrillInFor()
 * for each level (such as C:\,C:\AAAAAA,C:\AAAAAA\RSL5K,C:\AAAAAA\RSL5K\UnitTest).  
 * 
 * The other preferred method is to use PopulatePathWithInitialItemsBeforeHomeLaunch() where the breadcrumb and breadcrumb dropdown menus are created
 * and initialLaunchDirectory is set.  DrillInFor() is called once to populate the specified initialLaunchDirectory path.
 * 
 * This example also demonstrates how to localize search filter text. See GetFilterTypes() where the search columns are determined and display text set. 
 */

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    public class DIBClientManager_3_TreeViewFileSystemBrowser : DIBClientManager
    {

        private string baseAssemblyLocation;
        private string baseAssemblyLocationURIString;
        private string baseNodeCommonLocation = string.Empty;
        private string itemToHighlight = string.Empty;

        // set to true to demonstrate the DIB auto-drill-in to a path (see GetDataItemsFromPath)
        // set to false to demonstrate how to manually populate the bread crumb path (see PopulatePathWithInitialItemsBeforeHomeLaunch)
        private bool useDibAutoDrillinFeature = false;

        // flag to indicate if the cache was set so don't overwrite
        private bool cacheValuesSet = false;

        // set the home
        private string homeLocation = "C:\\";
        private string initialLaunchDirectory = string.Empty;
        private string userSelectedSearchPath = string.Empty;

        // options when using PopulatePathWithInitialItemsBeforeHomeLaunch to populate the initial drill-in
        // when false and the home breadcrumb is clicked, the DIB will navigate to the initial launch location.
        // when true and the home breadcrumb is clicked, the DIB will navigate to specified homeLocation location
        private bool breadcrumbHomeButtonGoToHomeLocation = true;

        // collection to hold localized search filter strings
        private ObservableCollection<CommonControls.FilterType> _filterType = null;
        private System.Globalization.CultureInfo currentLocale = System.Globalization.CultureInfo.CurrentUICulture;
        private SortedDictionary<string, string> sortNameMap = new SortedDictionary<string, string>();

        #region View Creation


        override public void InitializeDIBControlOnStartup(DataItemBrowser dataItemBrowserControl, StringBuilder logger)
        {
            baseAssemblyLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            baseAssemblyLocationURIString = "file:\\\\" + baseAssemblyLocation;

        }

        override public DIBCachingMode BreadcrumbCachingMode()
        {
            if (useDibAutoDrillinFeature)
                // auto-drill-in performed by the DIB - cache in default mode
                return DIBCachingMode.DefaultCachingMode;
            else
            {
                if (!cacheValuesSet)
                    return DIBCachingMode.DefaultCachingMode;

                // auto-drill-in using PopulatePathWithInitialItemsBeforeHomeLaunch().  As the cache is filled in there, disable all caching otherwise
                // the initial load will use a null DataItemBase causing the default caching to occur in PerformQuery_DataLoadComplete() and overwriting 
                // any cache values that were previously set.
                return DIBCachingMode.CachingAlwaysDisabled;
            }
        }

        /// <summary>
        /// This method is called to build the breadcrumbs.
        /// </summary>
        /// <param name="breadcrumbPath">The breadcrumb element list to add additional elements.  Do not remove the 1st element in this list.  The 1st element is the home path element.</param>
        override public void PopulatePathWithInitialItemsBeforeHomeLaunch(RockwellAutomation.UI.Models.Path breadcrumbPath, DIBQueryCache QueryCache)
        {
            cacheValuesSet = false;
            if(useDibAutoDrillinFeature)
                return;

            // if there is not a path to navigate to just return
            if (string.IsNullOrEmpty(this.InitialLaunchString))
                return;

            string[] pathParts = this.InitialLaunchString.Split(Path.DirectorySeparatorChar);

            // remove all but the 1st item in the list (the home crumb)
            while (breadcrumbPath.Items.Count > 1)
            {
                breadcrumbPath.Items.RemoveAt(breadcrumbPath.Items.Count - 1);
            }

            // get the parts of the path
            string strCommonRefTargetId = string.Empty;
            for (int partIndex = 0; partIndex < pathParts.Length; partIndex++)
            {
                string partName = pathParts[partIndex];
                if (string.IsNullOrWhiteSpace(partName))
                    continue;

                // set the last item in the list as the item to highlight after the drill-in
                itemToHighlight = partName;

                // don't add the last item to list to expand because if the item was a container the container is expanded rather than highlighted.
                if (partIndex == pathParts.Length - 1)
                    break;

                bool itemIsAFile = true;
                FileAttributes itemAttributes = 0;
                strCommonRefTargetId += partName;
                try
                {
                    itemAttributes = File.GetAttributes(strCommonRefTargetId);
                    itemIsAFile = (itemAttributes & FileAttributes.Directory) == FileAttributes.Directory ? false : true;
                }
                catch (Exception)
                { }

                if (itemIsAFile)
                    continue; // add only containers to the list


                strCommonRefTargetId += Path.DirectorySeparatorChar;

                if (partIndex == 0)
                {
                    baseNodeCommonLocation = strCommonRefTargetId;
                }

                DataItemBase pathNode = new DataItemBase()
                {
                    CommonName = partName,
                    CommonAbsoluteName = partName,
                    CommonDataType = itemIsAFile ? "File" : "Directory",
                    CommonDescription = "sample description",
                    CommonLocation = strCommonRefTargetId,
                    CommonRefTargetId = strCommonRefTargetId,
                    GUIToolTip = "sample tooltip",
                    GUISupportsDrillIn = itemIsAFile ? "false" : "true",
                    GUISupportsSelection = "true",
                    // set to true to support auto caching in default caching mode - false no caching AND no bread crumb drop down menu
                    // in this example we are filling the cache and want the breadcrumb arrow menu to be available.
                    GUIShowChildrenInBreadCrumbTrail = "true", 
                    CommonID = ResourceBase.generateRandomUUIDString(),
                    IsStructured = itemIsAFile ? false : true
                };

                if (partIndex > 0)
                {
                    // don't add the root item to the crumb trail as the home item was already added.
                    IPathElement aBreadCrumbElement = PathElementFactory.Instance().CreatePathElement(pathNode);
                    breadcrumbPath.Add(aBreadCrumbElement);
                }

                if (QueryCache != null)
                {
                    // fill the cache so the drop menus work
                    string directoryPathToFill = strCommonRefTargetId;
                    if (partIndex > 0)
                        directoryPathToFill = strCommonRefTargetId.Substring(0, strCommonRefTargetId.Length - 1); // remove the trailing \

                    TSObservableCollection<DataItemBase> crumbCache = new TSObservableCollection<DataItemBase>();
                    DirectoryInfo taskDirectory = new DirectoryInfo(directoryPathToFill);
                    DirectoryInfo[] taskDirectories = taskDirectory.GetDirectories();
                    foreach (DirectoryInfo dir in taskDirectories)
                    {
                        DataItemBase newDIB = new DataItemBase()
                        {
                            CommonName = dir.Name,
                            CommonDataType = "Directory",
                            CommonDescription = dir.Attributes.ToString(),
                            CommonLocation = dir.FullName,
                            CommonRefTargetId = dir.FullName,
                            GUITreeViewID = dir.FullName,
                            GUITreeViewParentID = dir.Parent.Name,
                            GUISupportsDrillIn = "true",    // needed to get this item added to the drop down menu
                            GUISupportsSelection = "true",
                            IsStructured = true             // needed to allow navigation to proceed (otherwise item is considered and end node like a file and cant navigate)
                        };
                        crumbCache.Add(newDIB);
                    }

                    // add to the menu cache
                    QueryCache.AddCachedItem(strCommonRefTargetId, crumbCache);
                    cacheValuesSet = true;
                }
            }

            // the selection path is adjusted to not include the last item in the selection path as that item will get highlighted
            this.initialLaunchDirectory = strCommonRefTargetId;

        }

        override public DIBTreeViewModel createDIBTreeViewModel(DataItemBrowserViewModel mainViewModel)
        {
            return new DIBTreeViewModelFor_3_TreeViewFileSystemBrowser(mainViewModel);
        }

        /// <summary>
        /// Return the proper view based on the data that needs to be displayed
        /// </summary>
        /// <param name="resourceType"></param>
        /// <returns></returns>
        override public IDIBDataViewType GetDataViewTypeFor(string resourceType)
        {
            if (resourceType.Equals(ClientDataServices.SearchTags)) 
                return new DIBDataViewTypeSearchGrid();
            return new DIBDataViewTypeTreeView();
        }

        /// <summary>
        /// Indicate which columns can be used as a filter
        /// </summary>
        /// <returns></returns>
        override public ObservableCollection<CommonControls.FilterType> GetFilterTypes()
        {
            if (this._filterType == null)
            {
                sortNameMap.Clear();
                System.Diagnostics.Debug.WriteLine("Cleared map.");

                // attempt to get the filter text from the GridColumnMetaData file
                this._filterType = new ObservableCollection<CommonControls.FilterType>();
                Stream xmlStream = GetGridColumnMetaData();
                if (xmlStream == null)
                {
                    // GridColumnsInfo.xml was not found so load some defaults
                    this._filterType = base.GetFilterTypes(); // base adds only Name and Description
                    this._filterType.Add(new CommonControls.FilterType("Data Type", true));
                }
                else
                {
                    //
                    // read GridColumnsInfo.xml and use the selected language string for the search filter strings
                    XDocument xmlDoc = XDocument.Load(xmlStream);

                    // get the searchtags element
                    XElement itemFirst =
                            (from el in xmlDoc.Descendants("View")
                             where (string)el.Attribute("Context") == ClientDataServices.SearchTags
                             select el).FirstOrDefault();

                    // should be just one of these
                    if (itemFirst != null)
                    {
                        // get the list of the column resources for this element
                        IEnumerable<XElement> colResources = itemFirst.Descendants("ColumnResource");
                        foreach (XElement colResource in colResources)
                        {
                            // get the KeyName for this colResource in the searchtags element
                            XAttribute attr = colResource.Attribute("KeyName");
                            string nameVal = attr.Value;

                            // get the specified column element
                            XElement columnNode =
                                    (from resource in xmlDoc.Descendants("Column")
                                    where (string)resource.Attribute("Key") == nameVal
                                    select resource).FirstOrDefault();

                            if (columnNode != null)
                            {
                                XAttribute columnAttribute = columnNode.Attribute("Name");
                                string itemName = columnAttribute.Value;
                                string filterDisplayName = string.Empty;

                                // try to get the full language name
                                XElement languageText = (from titleItem in columnNode.Descendants("Title") where (string)titleItem.Attribute("{http://www.w3.org/XML/1998/namespace}lang") == currentLocale.Name select titleItem).FirstOrDefault();
                                if (languageText != null)
                                {
                                    filterDisplayName = languageText.Value;
                                }

                                if (string.IsNullOrWhiteSpace(filterDisplayName) && currentLocale.Name != currentLocale.TwoLetterISOLanguageName)
                                {
                                    // try and get the two char language name
                                    languageText = (from titleItem in columnNode.Descendants("Title") where (string)titleItem.Attribute("{http://www.w3.org/XML/1998/namespace}lang") == currentLocale.TwoLetterISOLanguageName select titleItem).FirstOrDefault();
                                    if (languageText != null)
                                    {
                                        filterDisplayName = languageText.Value;
                                    }
                                }
                                if (string.IsNullOrWhiteSpace(filterDisplayName))
                                {
                                    //System.Windows.MessageBox.Show("Unable to load the search filter language string for the selected language: " + currentLocale.NativeName + ", culture name: " + currentLocale.Name + "\n\nPlease add the language to GridColumnsInfo.xml", "Language Missing", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Exclamation);
                                    filterDisplayName = nameVal;
                                }

                                this._filterType.Add(new CommonControls.FilterType(columnAttribute.Value, filterDisplayName, true, false));
                                //
                                // add this item - used for the server side search to resolve the column name.
                                sortNameMap.Add(filterDisplayName, columnAttribute.Value);
                                System.Diagnostics.Debug.WriteLine("Adding " + filterDisplayName + " to map.");
                            }
                        }
                    }
                }
            }
            return this._filterType;
        }

        /// <summary>
        /// Indicate how the search should be performed for a given path
        /// Can either search the data already in the view or perform 
        /// a server side search.
        /// </summary>
        /// <param name="path">breadcrumb path</param>
        /// <returns>true to perform server side search, otherwise false</returns>
        override public bool ShouldSearchViaQuery(RockwellAutomation.UI.Models.Path path)
        {
            //We want to do server side search only if we are located at or within c:\Temp
            userSelectedSearchPath = string.Empty;
            if (path == null || path.Items.Count < 1) 
                return false;
            
            // use the selected path index as the last path item maybe >> which is the last path item but not the current location
            int selectedIndex = path.SelectedPath.Count - 1;
            DataItemBase pathItem = selectedIndex < path.Items.Count ? path.Items[selectedIndex].DataItem : path.Last.DataItem;
            string currentFolder = pathItem == null ? homeLocation : pathItem.CommonLocation;

            if (path.Last.DataItem != null && currentFolder.ToLower().Contains("c:\\temp"))
            {
                userSelectedSearchPath = currentFolder;
                return true;
            }
            
            return false;
        }

        /// <summary>
        /// map any Viewe mappings back to original
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private string mapVieweNameToOriginalName(string name)
        {
            if (string.Compare(name, RockwellAutomation.UI.CommonControls.SearchFilterDefinition.NameIdentifier) == 0)
                return RockwellAutomation.UI.CommonControls.SearchFilterDefinition.ColumnNameString;
            else if (string.Compare(name, RockwellAutomation.UI.CommonControls.SearchFilterDefinition.DataTypeIdentifier) == 0)
                return RockwellAutomation.UI.CommonControls.SearchFilterDefinition.ColumnDatatypeString;
            else if (string.Compare(name, RockwellAutomation.UI.CommonControls.SearchFilterDefinition.DescriptionIdentifier) == 0)
                return RockwellAutomation.UI.CommonControls.SearchFilterDefinition.ColumnDescriptionString;
            else if (string.Compare(name, RockwellAutomation.UI.CommonControls.SearchFilterDefinition.PathIdentifier) == 0)
                return RockwellAutomation.UI.CommonControls.SearchFilterDefinition.ColumnLocationString;

            return name;
        }
        

        /// <summary>
        /// Perform a server side search
        /// </summary>
        /// <param name="queryConditionConfig">search filter specified by user</param>
        /// <param name="dibQueryCache">cache to be filled with the search result</param>
        override public void SearchFor(Client.Services.Query.QueryConditionConfig queryConditionConfig, DIBQueryCache dibQueryCache)
        {
            string searchFilterName = string.Empty;
            // in this example, don't allow server side searches for any filter but Name (RockwellAutomation.UI.CommonControls.SearchFilterDefinition.NameIdentifier)
            // use only the 1st specified filter...
            // first go through the list of search filters and report any non-supported filters
            foreach (Client.Services.Query.QueryConditionItem queryItem in queryConditionConfig.GetQueryConditionItems)
            {
                if (queryItem.GetIdentifier == null)
                    // user entered a search string without a column name
                    continue;

                string backFromRename = mapVieweNameToOriginalName(queryItem.GetIdentifier);
                sortNameMap.TryGetValue(backFromRename, out searchFilterName);
                /*
                 * 
                 * Note that the when the search column is added to the QueryConditionConfig the GetIdentifier name may be changed.
                 * for example, of the column name specified in GridColumnsInfo.xml is "Location" the name is changed to "AbsoluteName".  
                 * If the column name is not one of the predefined names the name value will be used.
                 * 
                 */
                if (string.Compare(searchFilterName, "randomNum", true) == 0 ||
                    string.Compare(searchFilterName, "Data Type", true) == 0 ||
                    string.Compare(searchFilterName, "Description", true) == 0 ||
                    string.Compare(searchFilterName, "Location", true) == 0)
                {
                    string displayString = "This example does not support \"" + backFromRename + "\" as a filter.";
                    DataItemBase newDIB = new DataItemBase()
                    {
                        CommonName = "Server side search performed",
                        CommonDataType = "None",
                        CommonDescription = "See SearchFor()",
                        CommonLocation = displayString,
                        CommonRefTargetId = "0",
                        GUISupportsDrillIn = "false",
                        GUISupportsSelection = "True",
                    };
                    newDIB.SetStringMapValue("randomNum", "---");
                    dibQueryCache.AddDataItem(newDIB);
                }
            }

            if (dibQueryCache.DataItemsCount() > 0 || queryConditionConfig.GetQueryConditionItems.Count == 0)
                return;

            RockwellAutomation.Client.Services.Query.QueryConditionItem item = queryConditionConfig.GetQueryConditionItems[0];
            if (item == null || item.GetIdentifier == null)
            {
                DataItemBase newDIB = new DataItemBase()
                {
                    CommonName = "Server side search performed",
                    CommonDataType = "None",
                    CommonDescription = "See SearchFor()",
                    CommonLocation = "Only Name search filter are supported in this example.",
                    CommonRefTargetId = "0",
                    GUISupportsDrillIn = "false",
                    GUISupportsSelection = "True",
                };
                newDIB.SetStringMapValue("randomNum", "---");
                dibQueryCache.AddDataItem(newDIB);
                return;
            }

            // get the items that match the search filter
            // for this example search, do the search for the DisplayName filter
            if (!string.IsNullOrWhiteSpace(userSelectedSearchPath) && Directory.Exists(userSelectedSearchPath))
            {
                Random rndNumGenerator = new Random();
                string filter = item.GetValue + "*";
                List<string> files = new List<string>(Directory.GetFiles(userSelectedSearchPath, filter, SearchOption.AllDirectories));
                foreach (string fileFullName in files)
                {
                    string itemName = Path.GetFileName(fileFullName);
                    DataItemBase newDIB = new DataItemBase()
                    {
                        CommonName = itemName,
                        CommonDataType = "File",
                        CommonDescription = "Search: " + userSelectedSearchPath + filter,
                        CommonLocation = fileFullName,
                        CommonRefTargetId = fileFullName,
                        GUISupportsDrillIn = "false",
                        GUISupportsSelection = "True",
                    };
                    newDIB.SetStringMapValue("randomNum", rndNumGenerator.Next(1, 5).ToString());
                    dibQueryCache.AddDataItem(newDIB);
                }
            }

        }

        #endregion

        #region Path Related Functionality

        override public string PathToString(List<IPathElement> fullPath, string nameToSelect, DIBViewItemBase.VisualPerspectiveEnum browserPerspective)
        {
            StringBuilder stringBuilder = new StringBuilder();
            if (fullPath.Count > 1) stringBuilder.Append(fullPath[fullPath.Count - 1].DataItem.CommonLocation);
            return stringBuilder.ToString();
        }

        #endregion

        #region DataGridMetaData

        override public System.IO.Stream GetGridColumnMetaData()
        {
            System.IO.Stream xmlStream = File.OpenRead("DIBClientManagers/3_TreeViewFileSystemBrowser/GridColumnsInfo.xml");
            return xmlStream;
        }

        #endregion


        #region Navigation overrides

        override public string GetResourceTypeString(DataItemBase dataItem)
        {
            return DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW;
        }

        override public string GetBreadCrumbCacheKeyFor(DataItemBase dataItem)
        {
            if (dataItem == null)
            {
                if (!string.IsNullOrWhiteSpace(baseNodeCommonLocation))
                    return baseNodeCommonLocation;
                return DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW;
            }
            return dataItem.CommonLocation;
        }

        /// <summary>
        /// Give the host a chance to populate a drill-in list to use the default DIB drill in.
        /// <para>The launch string passed in is the launch string set by the host of the DIB.  This method will parse the string and create DataItemBase items for each item in the path.  The DrillInFor method below will be called for each item in the List.</para>
        /// </summary>
        /// <param name="path">InitialLaunchString value set in the view manager.
        /// </param>
        /// <returns>Path items to navigate through</returns>
        override public List<DataItemBase> GetDataItemsFromPath(string path)
        {
            if(!useDibAutoDrillinFeature)
                return null;

            baseNodeCommonLocation = string.Empty;
            if (string.IsNullOrWhiteSpace(path))
                return null;

            string[] pathParts = path.Split(Path.DirectorySeparatorChar);

            List<DataItemBase> resultList = new List<DataItemBase>();
                       
            string strCommonRefTargetId = string.Empty;
            for (int partIndex = 0; partIndex < pathParts.Length; partIndex++)
            {
                string partName = pathParts[partIndex];
                if (string.IsNullOrWhiteSpace(partName))
                    continue;

                // set the last item in the list as the item to highlight after the drill-in
                itemToHighlight = partName;

                // don't add the last item to list to expand because if the item was a container the container is expanded rather than highlighted.
                if (partIndex == pathParts.Length - 1)
                    break;

                bool itemIsAFile = false;
                FileAttributes itemAttributes = 0;
                strCommonRefTargetId += partName;
                try
                {
                    itemAttributes = File.GetAttributes(strCommonRefTargetId);
                    itemIsAFile = (itemAttributes & FileAttributes.Directory) == FileAttributes.Directory ? false : true;
                }
                catch (Exception)
                {}

                if (itemIsAFile)
                    continue; // add only containers to the list


                strCommonRefTargetId += Path.DirectorySeparatorChar;

                
                if (resultList.Count == 0)
                {
                    baseNodeCommonLocation = strCommonRefTargetId;
                }

                DataItemBase pathNode = new DataItemBase()
                {
                    CommonName = partName,
                    CommonAbsoluteName = partName,
                    CommonDataType = itemIsAFile ? "File":"Directory",
                    CommonDescription = "sample description",
                    CommonLocation = strCommonRefTargetId,
                    CommonRefTargetId = strCommonRefTargetId,
                    GUIToolTip = "sample tooltip",
                    GUISupportsDrillIn = itemIsAFile?"false":"true",
                    GUISupportsSelection = "true",
                    GUIShowChildrenInBreadCrumbTrail = itemIsAFile ? "false" : "true",
                    CommonID = ResourceBase.generateRandomUUIDString(),
                    IsStructured = itemIsAFile?false:true
                };
                resultList.Add(pathNode);
            }

            return resultList;
        }

        override public void DrillInFor(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            bool bIsPathDirectory = true;
            String dirToBrowse;
            if (dataItemToDrillInto == null)
            {
                if (String.IsNullOrWhiteSpace(this.initialLaunchDirectory))
                    dirToBrowse = homeLocation;
                else
                {
                    // check the sanity of the this.initialLaunchDirectory as this can be edited in the demo application
                    dirToBrowse = this.initialLaunchDirectory;

                    if (breadcrumbHomeButtonGoToHomeLocation)
                    {
                        this.InitialLaunchString = string.Empty;
                        this.initialLaunchDirectory = string.Empty;
                    }
                    FileAttributes itemAttributes = 0;
                    while (itemAttributes == 0)
                    {
                        try
                        {
                            itemAttributes = File.GetAttributes(dirToBrowse);
                        }
                        catch (Exception exAttr)
                        {
                            System.Windows.MessageBox.Show(exAttr.Message + "\n\nWill browse to home location [" + homeLocation + "]", "Path Exception", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Exclamation);
                            dirToBrowse = homeLocation;
                        }
                    }

                    // if a file was specified - remove it from the path
                    bool itemIsAFile = (itemAttributes & FileAttributes.Directory) == FileAttributes.Directory ? false : true;

                    if (itemIsAFile)
                    {
                        // file was specified - remove the name
                        dirToBrowse = Path.GetDirectoryName(dirToBrowse);
                    }

                    if (!new DirectoryInfo(dirToBrowse).Exists)
                    {
                        System.Windows.MessageBox.Show("Unable to locate the directory to navigate to [" + dirToBrowse + "\n\nBrowsing to home location [" + homeLocation + "]", "Path Not Found", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                        dirToBrowse = homeLocation;
                    }
                }
            }
            else
            {
                dirToBrowse = dataItemToDrillInto.CommonRefTargetId;
                bIsPathDirectory = dataItemToDrillInto.IsStructured;
            }

            Random rndNumGenerator = new Random();
            DataItemBase rootNode = new DataItemBase()
            {
                CommonName = dirToBrowse,
                CommonDataType = "root",
                CommonDescription = "root",
                CommonLocation = dirToBrowse,
                GUITreeViewID = dirToBrowse,
                GUITreeViewParentID = string.Empty,
                GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\16by16\\drive.png",
                GUIToolTip = "This is the Managers Folder. You can't navigate to this item",
                GUISupportsDrillIn = "False",
                GUISupportsSelection = "False",
                GUITextFontWeight = "Bold",
                GUIIsExpanded = "true",
                GUIShowChildrenInBreadCrumbTrail = "true",
            };
            rootNode.SetStringMapValue("itemName", "root");
            rootNode.SetStringMapValue("randomNum", rndNumGenerator.Next(1, 5).ToString());
            queryCache.AddDataItem(rootNode);

            try
            {
                DirectoryInfo taskDirectory = new DirectoryInfo(dirToBrowse);
                DirectoryInfo[] taskDirectories = taskDirectory.GetDirectories();
                foreach (DirectoryInfo dir in taskDirectories)
                {
                    DataItemBase newDIB = new DataItemBase()
                    {
                        CommonName = dir.Name,
                        CommonDataType = "Directory",
                        CommonDescription = dir.Attributes.ToString(),
                        CommonLocation = dir.FullName,
                        CommonRefTargetId = dir.FullName,
                        GUITreeViewID = dir.FullName,
                        GUITreeViewParentID = rootNode.GUITreeViewID,
                        GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\16by16\\folder.png",
                        GUIToolTip = "Full Path: " + dir.FullName + " Attributes: " + dir.Attributes.ToString(),
                        GUISupportsDrillIn = "true",
                        GUISupportsSelection = "true",
                        GUIIsInitiallyHighlighted = dir.Name == itemToHighlight ? "True" : "False",
                        IsStructured = true,
                        GUIShowChildrenInBreadCrumbTrail = "true"
                    };
                    newDIB.SetStringMapValue("itemName", dir.Name);
                    newDIB.SetStringMapValue("randomNum", rndNumGenerator.Next(1, 5).ToString());
                    //Any path that ends with the string "VieweSprint175" will not have a drop down context menu for children in the breadcrumb trail
                    // NOTE: this means that children directories will show children
                    if (newDIB.CommonLocation.EndsWith("VieweSprint175")) newDIB.GUIShowChildrenInBreadCrumbTrail = "false";
                    queryCache.AddDataItem(newDIB);
                }

                FileInfo[] taskFiles = taskDirectory.GetFiles();
                foreach (FileInfo file in taskFiles)
                {
                    DataItemBase newDIB = new DataItemBase()
                    {
                        CommonName = file.Name,
                        CommonDataType = "File",
                        CommonDescription = file.Attributes.ToString(),
                        CommonLocation = file.FullName,
                        CommonRefTargetId = file.FullName,
                        GUITreeViewID = file.FullName,
                        GUITreeViewParentID = rootNode.GUITreeViewID,
                        GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\16by16\\detail.png",
                        GUIToolTip = "Full Path: " + file.FullName + " Attributes: " + file.Attributes.ToString(),
                        GUISupportsDrillIn = "False",
                        GUISupportsSelection = "True",
                        GUIIsInitiallyHighlighted = file.Name == itemToHighlight ? "True" : "False",
                        GUIShowChildrenInBreadCrumbTrail = "False"
                    };
                    newDIB.SetStringMapValue("itemName", file.Name);
                    newDIB.SetStringMapValue("randomNum", rndNumGenerator.Next(1, 5).ToString());
                    queryCache.AddDataItem(newDIB);
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                System.Windows.MessageBox.Show(ex.Message, "Exception", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
            }

        }
        #endregion



    }
}
