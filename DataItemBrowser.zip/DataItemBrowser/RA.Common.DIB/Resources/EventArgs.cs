using System.ComponentModel;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.Generic;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// Active Path Changed event arguments class
    /// </summary>
    public class ActivePathChangedEventArgs : PropertyChangedEventArgs
    {
        /// <summary>
        /// does this argument have any active elements
        /// </summary>
        private bool _hasActiveElements;
        public bool HasActiveElements
        {
            get { return _hasActiveElements; }
        }
        /// <summary>
        /// consturctor
        /// </summary>
        /// <param name="hasActiveElements">has active elements</param>
        /// <param name="propertyName">name of the property</param>
        public ActivePathChangedEventArgs(string propertyName, bool hasActiveElements)
            : base(propertyName)
        {
            _hasActiveElements = hasActiveElements;
        }
    }

	/// <summary>
	/// observable collection property changed event arguments class
	/// </summary>
	public class SelectedItemPropertyChangedEventArgs : PropertyChangedEventArgs
	{
		/// Item to select in a view property (string)
		private string _selectedItem;
		public string SelectedItem
		{
			get { return _selectedItem; }
		}

		/// <summary>
		/// constructor
		/// </summary>
		/// <param name="propertyName">name of the property changing</param>
        /// <param name="selectedItem">selected item in the view</param>
		public SelectedItemPropertyChangedEventArgs(string propertyName, string selectedItem)
			: base(propertyName)
		{
            _selectedItem = selectedItem;
		}
	}

    /// <summary>
    /// datagrid observable collection property changed event arguments class
    /// </summary>
    public class DGOCPropertyChangedEventArgs : PropertyChangedEventArgs
    {
        /// <summary>
        /// Item to select in the datagrid view property (DataItemBase)
        /// </summary>
        private DataItemBase _itemToSelect = null;
        public DataItemBase ItemToSelect
        {
            get { return _itemToSelect; }
        }
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="propertyName">name of the property changing</param>
        /// <param name="itemToSelect">item to be selected in the view</param>
        public DGOCPropertyChangedEventArgs(string propertyName, DataItemBase itemToSelect)
            : base(propertyName)
        {
            _itemToSelect = itemToSelect;
        }
    }

    /// <summary>
    /// search breadcrumb property changed event arguments class
    /// </summary>
    public class SearchBreadCrumbPropertyChangedEventArgs : PropertyChangedEventArgs
    {
        /// <summary>
        /// are we adding or deleting the crumb
        /// </summary>
        private bool _add = false;
        public bool Add
        {
            get { return _add; }
        }
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="propertyName">name of the property changing</param>
        /// <param name="add">add or remove this crumb</param>
        public SearchBreadCrumbPropertyChangedEventArgs(string propertyName, bool add)
            : base(propertyName)
        {
            _add = add;
        }
    }

    /// <summary>
    /// Active Path Changed event arguments class
    /// </summary>
    public class NavigateStateChangedEventArgs : PropertyChangedEventArgs
    {
        /// <summary>
        /// does this argument have any active elements
        /// </summary>
        private bool _begin;
        public bool Begin
        {
            get { return _begin; }
            internal set { _begin = value; }
        }
        /// <summary>
        /// consturctor
        /// </summary>
        /// <param name="hasActiveElements">has active elements</param>
        /// <param name="propertyName">name of the property</param>
        public NavigateStateChangedEventArgs(string propertyName, bool begin)
            : base(propertyName)
        {
            Begin = begin;
        }
    }

	/// <summary>
	/// Navigate Property Changed event arguments class
	/// </summary>
	public class NavigatePropertyChangedEventArgs : System.ComponentModel.PropertyChangedEventArgs
	{

		#region private members

		private string _nameToSelect = string.Empty;
		private List<IPathElement> _fullPath = null;

		#endregion

		#region public members

		/// <summary>
		/// get list of Path Elements
		/// </summary>
		public List<IPathElement> FullPath
		{
			get { return _fullPath; }
		}

		/// <summary>
		/// get NameToSelect value
		/// </summary>
		public string NameToSelect
		{
			get { return _nameToSelect; }
		}

		#endregion

		public NavigatePropertyChangedEventArgs(string propertyName, List<IPathElement> fullPath, string nameToSelect)
			: base(propertyName)
		{
			_fullPath = fullPath;
			_nameToSelect = nameToSelect;
		}
	}

    /// <summary>
    /// select item after launch with search event arguments class
    /// </summary>
    public class SelectItemAfterLaunchWithSearchEventArgs : PropertyChangedEventArgs
    {
        /// <summary>
        /// selected item path
        /// </summary>
        private string _selectedItemPath = string.Empty;
        public string SelectedItemPath
        {
            get { return _selectedItemPath; }
        }
        /// <summary>
        /// consturctor
        /// </summary>
        /// <param name="hasActiveElements">has active elements</param>
        /// <param name="propertyName">name of the property</param>
        public SelectItemAfterLaunchWithSearchEventArgs(string propertyName, string selectedItemPath)
            : base(propertyName)
        {
            _selectedItemPath = selectedItemPath;
        }
    }

}