/* ****************************************************************************
*
*  Copyright 2016 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

#region references

using System.Collections.Generic;
using RockwellAutomation.UI.CommonControls.SearchFilter.ViewModels;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI;
using RockwellAutomation.UI.Models;
using System.ComponentModel;
using System.Windows.Input;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query;
using System.Linq;
using System;
using RockwellAutomation.UI.CommonControls.ViewModels;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.WindowsControl.DIBClient;

#endregion

namespace DataItemBrowserUT
{
    class MockDataItemBrowserViewModel : IDataItemBrowserViewModel
    {
        #region testing interfaces
        /// <summary>
        /// these are mock interfaces to query for test results
        /// </summary>
        /// 
        private bool _isListView = false;
        public bool IsListViewValue
        {
            get { return _isListView; }
            internal set { _isListView = value; }
        }
        private bool _isInitialized = false;
        public bool IsInitialized
        {
            get { return _isInitialized; }
            internal set { _isInitialized = value; }
        }
        private bool _isClosed = false;
        public bool IsClosed
        {
            get { return _isClosed; }
            internal set { _isClosed = value; }
        }

        private List<IPathElement> _navPathList = null;
        public List<IPathElement> NavPathList
        {
            get { return _navPathList; }
            internal set { _navPathList = value; }
        }
        private string _navNameToSelect = String.Empty;
        public string NavNameToSelect
        {
            get { return _navNameToSelect; }
            internal set { _navNameToSelect = value; }
        }

        private string _navFullPath = null;
        public string NavFullPath
        {
            get { return _navFullPath; }
            internal set { _navFullPath = value; }
        }
        private List<DropArrowItem> _children = new List<DropArrowItem>();
        public List<DropArrowItem> Children
        {
            get { return _children; }
            set { _children = value; }
        }

        #endregion 
        
        private bool _requestFromHomeCrumb = false;

        IObservableCollection<DataItemBase> _items = null;
        public IObservableCollection<DataItemBase> DataItems
        {
            get
            {
                if (_items == null)
                    _items = new TSObservableCollection<DataItemBase>();
                return _items;
            }
            set
            {
                if (_items == null)
                    _items = new TSObservableCollection<DataItemBase>();

                if (_items != value)
                {
                    _items = value;
                    //NotifyPropertyChanged("Items");
                }
            }
        }
        public bool CanInitiateNewQuery(DataItemBase item)
        {
            return true;
        }

        public string PathToString(List<IPathElement> fullPath, string nameToSelect)
        {
            return string.Empty;
        }

        public void RunQuery(PredefinedQueryType type, UUID parent) { }

		public DataItemBase GetDeviceItemByName(string deviceName) { return null; }
		public DataItemBase GetDataItemByName(string itemName) { return null; }
        public bool IsQueryCancelling { get { return false; } }
		public void Initialize(DataItemBrowserContext homeContext, string connectString)
        {
            IsInitialized = true;

        }
        public void Close()
        {
            IsClosed = true;
        }

        /// <summary>
        /// Special Navigation function used to identify navigation via the HomeCrumb selected.
        /// </summary>
        /// <param name="PathList">active path list</param>
        /// <param name="NameToSelect">name of the item we will select in the view</param>
        /// <param name="HomeCrumbRequest">indicator that the home crumb was selected.</param>
        public void Navigate(List<IPathElement> pathList, string NameToSelect, bool HomeCrumbRequest)
        {
            NavPathList = pathList;
            NavNameToSelect = NameToSelect;
            _requestFromHomeCrumb = HomeCrumbRequest;
            return;
        }

        public void Navigate(string fullPath, DataContext dataContext)
        {
            NavFullPath = fullPath;
        }

        public void Navigate(List<IPathElement> pathList, string NameToSelect)
        {
            NavPathList = pathList;
            NavNameToSelect = NameToSelect;
            return;
        }
		public void Navigate(DataItemBase dataItem, bool clearSearch = true, bool fromUserSearch = false)
		{
			NavPathList = Path.Items.ToList<IPathElement>();
			
			//Code same as DIBVM.DataServicesLoadComplete
			if (_path != null)
			{
				// If there is a forward Path Element, that is the ItemToSelect.
				if (_path.Forward != null)
					NavNameToSelect = _path.Forward.DisplayName;
				else
				{
					// If the Active Element is the last element, use the SavedHighlightedItem, which may or may not be set.
					if (_path.SavedHighlightedElement != null)
						NavNameToSelect = _path.SavedHighlightedElement.DisplayName;
				}
			}

            NotifyDataGridColsChanged();

            //Refresh the column config / selected item / etc.
            //if (_DataServices.DataView == ClientDataServices.DataViewType.DataSource)
            //{
            //    NotifyTreeViewOCChanged(NavNameToSelect);
            //}
            //else
            //    NotifyDataGridOCChanged(dataItem);

            //This allows users above the DIBViewModel to know when Navigate is complete.  
            List<IPathElement> fullPath = this.Path.Items.Count > 0 ? this.Path.Items.ToList<IPathElement>() : null;
            string nameToSelect = this.Path.ActiveElement != null ? this.Path.ActiveElement.DisplayName : String.Empty;
            if (NavigateComplete != null)
                NavigateComplete(this, new NavigatePropertyChangedEventArgs("NavigateComplete", fullPath, nameToSelect));


			return;
		}
  
		public void NavigateNoGui(DataItemBase parentItem, DataLoadComplete callback)
		{
			Navigate(parentItem);
		}

		public event PropertyChangedEventHandler TreeViewOCChanged;
		protected void NotifyTreeViewOCChanged(string selectedName)
		{
			if (TreeViewOCChanged != null)
			{
				TreeViewOCChanged(this, new SelectedItemPropertyChangedEventArgs(String.Empty, selectedName));
			}
		}

        public event PropertyChangedEventHandler DataGridOCChanged;
        protected void NotifyDataGridOCChanged(DataItemBase ItemToSelect)
        {
            if (DataGridOCChanged != null)
            {
                DataGridOCChanged(this, new DGOCPropertyChangedEventArgs(String.Empty, ItemToSelect));
            }
        }

        public event PropertyChangedEventHandler WebViewOCChanged;
        protected void NotifyWebViewOCChanged(string selectedName)
        {
            if (WebViewOCChanged != null)
                WebViewOCChanged(this, new SelectedItemPropertyChangedEventArgs(String.Empty, selectedName));
        }

        /// <summary>
        /// event handler for ListView ObservableCollection changes 
        /// </summary>
        /// <param name="itemToSelect"></param>
        public event PropertyChangedEventHandler ListViewOCChanged;
        protected void NotifyListViewOCChanged(string selectedName)
        {
            if (ListViewOCChanged != null)
                ListViewOCChanged(this, new SelectedItemPropertyChangedEventArgs(String.Empty, selectedName));
        }

		public event PropertyChangedEventHandler DataGridColsChanged;
		protected void NotifyDataGridColsChanged()
		{
			if (DataGridColsChanged != null)
			{
				DataGridColsChanged(this, new PropertyChangedEventArgs(String.Empty));
			}
		}

        public event PropertyChangedEventHandler SearchBreadCrumbChanged;
        public void NotifySearchBreadCrumbChanged(bool add)
        {
            if (SearchBreadCrumbChanged != null)
            {
                SearchBreadCrumbChanged(this, new SearchBreadCrumbPropertyChangedEventArgs(String.Empty, add));
            }
        }

        public event PropertyChangedEventHandler NavigateComplete;
        public void NotifyNavigateComplete()
        {
            if (NavigateComplete != null)
            {
                NavigateComplete(this, new PropertyChangedEventArgs("NavigateComplete"));
            }
        }

        /// <summary>
        /// Event routing triggered when DataView changes
        /// </summary>
        public event EventHandler DataViewChanged;
        
        /// <summary>
        /// notify that navigation state has changed
        /// </summary>
        public void NotifyDataViewChanged()
        {
            if (DataViewChanged != null)
                DataViewChanged(this, new EventArgs());

        }
        /// <summary>
        /// select item after launching with search
        /// </summary>
        public event PropertyChangedEventHandler SelectItemAfterLaunchWithSearch;
        /// <summary>
        /// notify to select an item after launching with a search
        /// </summary>
        protected void NotifySelectItemAfterLaunchWithSearch(string selectedItemPath)
        {
            if (SelectItemAfterLaunchWithSearch != null)
            {
                SelectItemAfterLaunchWithSearch(this, new SelectItemAfterLaunchWithSearchEventArgs("SelectItemAfterLaunchWithSearch", selectedItemPath));
            }
        }

        private RockwellAutomation.UI.Models.Path _path = new RockwellAutomation.UI.Models.Path();
        public RockwellAutomation.UI.Models.Path Path
        {
            get { return _path; }
            internal set { _path = value; }
        }

		public List<ColumnConfigMapItem> Columns
		{
			get
			{
				return new List<ColumnConfigMapItem>();
			}
		}

		public DataItemBase TagsAndPropsItem
		{
			get
			{
				return new DataItemBase();
			}
		}

        public ISearchFilterControlViewModel SearchFilterControlVM
        {
            get { return null; }
        }

        IDIBDataViewType _dataView = new DIBDataViewTypeTreeView();
        public IDIBDataViewType DataView
        {
            get { return _dataView; }
            set { _dataView = value; }
        } 

        public DataItemBase HomeItem
        {
            get
            {
                return new DataItemBase();
            }
        }

		public bool IsSearchActive
		{
			get;
			set;
		}

		public bool IsQueryBasedSearchActive
		{
			get;
			set;
		}

        public bool IsGridView()
        {
            return false;
        }

        public bool IsListView()
        {
            return _isListView;
        }

        public bool IsWebView()
        {
            return false;
        }

		public void UpdateColumnConfig(ColumnAttribute columnAttribute, string columnName, object columnValue)
		{
		}

		public void SaveColumnConfig()
		{
		}
      
        public List<DropArrowItem> getChildren(string dataSourceName,ACrumb hostCrumb)
        {
            return _children;
        }

        private string _selectedItemCommandName = String.Empty;
        public string SelectedItemCommandName
        {
            get { return _selectedItemCommandName; }
        }
        public ICommand ItemSelectionChangedCommand
        {
            get { return null; }
        }
        private string _userSetHighlightedItemCommandName = String.Empty;
        public string UserSetHighlightedItemCommandName
        {
            get { return _userSetHighlightedItemCommandName; }
        }
        private SimpleCommand _userSetHighlightedItemCommand = null;
        public ICommand UserSetHighlightedItemCommand
        {
            get
            {
                if (_userSetHighlightedItemCommand == null)
                {
                    _userSetHighlightedItemCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {
                             DataItemBase dataItem = x as DataItemBase;
                             List<IPathElement> list = this.Path.UserSetHighlightedPath;
                             AddSelectedNodeToList(dataItem, list);
                             _userSetHighlightedItemCommandName = Path.PathToString(list, null, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
                        }

                    };
                }
                return _userSetHighlightedItemCommand;
            }
        }

        /// <summary>
        /// The last item explicitly highlighted by the user (i.e. via mouse click or keyboard)
        /// </summary>        
        public string LastUserHighlightedItem { get; set; }

        /// <summary>
        /// Adds the DataItemBase to the List of IPathElements
        /// </summary>
        /// <param name="selectedDataItemBase"></param>
        /// <param name="SelectedPathList"></param>
        private void AddSelectedNodeToList(DataItemBase selectedDataItemBase, List<IPathElement> SelectedPathList)
        {
            string selectedItemNameString = selectedDataItemBase.CommonName;

            if (IsTagBrowser())
            {
                // Determine the type of element to create for this selection.
                if ((SelectedPathList.Count == 1) && (SelectedPathList[0] is ControllerPathElement))
                {
                    if (selectedItemNameString.Equals(DIResource.DI_COMMON_RESOURCETYPE_TAGSPROPERTIES))
                    {
                        IPathElement tagsPropsPathElement = PathElementFactory.Instance().CreatePathElement(selectedDataItemBase);
                        SelectedPathList.Add(tagsPropsPathElement);
                    }
                    else
                    {
                        IPathElement progPathElement = PathElementFactory.Instance().CreatePathElement(selectedDataItemBase);
                        SelectedPathList.Add(progPathElement);
                    }
                }
                else
                {
                    IPathElement dataItemPathElement = PathElementFactory.Instance().CreatePathElement(selectedDataItemBase);
                    SelectedPathList.Add(dataItemPathElement);
                }
            }
            else
            {
                IPathElement dataItemPathElement = PathElementFactory.Instance().CreatePathElement(selectedDataItemBase);
                SelectedPathList.Add(dataItemPathElement);
            }
        }       

        private SimpleCommand _selectedItemCommand = null;
        public ICommand SelectedItemCommand
        {
            get
            {
                if (_selectedItemCommand == null)
                {
                    _selectedItemCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {
                             DataItemBase dataItem = x as DataItemBase;
                             List<IPathElement> list = this.Path.SelectedPath;
                             AddSelectedNodeToList(dataItem, list);
                             _selectedItemCommandName = Path.PathToString(list, null, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
                        }

                    };
                }
                return _selectedItemCommand;
            }
        }
        /// <summary>
        /// apply view filter to this item
        /// </summary>
        public bool ApplyViewFilter(DataItemBase dataItem, GetFieldValue getFieldValue)
        {
            return true;
        }

        /// <summary>
        /// Is this a Tag or Data Type browser?
        /// </summary>
        /// <returns>True if Tag browser</returns>
        public string BrowserType { get; set; }

        /// <summary>
        /// Is DIB a tag browser
        /// </summary>
        public bool IsTagBrowser()
        {
            if ((string.Compare(BrowserType, String.Empty, true)    == 0) ||
                (string.Compare(BrowserType, DIResource.DI_COMMON_RESOURCETYPE_TAG, true) == 0) ||
                (string.Compare(BrowserType, null, true)  == 0))
                return true;
            else
                return false;
        }

        /// <summary>
        /// Is the DIB a AOG property browser
        /// </summary>
        public bool IsAOGPropertyBrowser()
        {
            if (string.Compare(BrowserType, DIResource.DI_COMMON_RESOURCETYPE_AOGS, true) == 0)
                return true;
            return false;
        }

        /// <summary>
        /// Compares the container Path Items against the passed in current path items to determine if the container path elements match.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public bool IsNavigateOnCurrentPath(Path currentPath)
        {
            if ((currentPath.Items.Count == 0) || (Path.SelectedPath.Count == 0))
                return false;

            //  Check Controller name
            if (currentPath.Items[0].DisplayName != Path.SelectedPath[0].DisplayName)
                return false;

            // Check for Programs
            bool currPathHasProgram = false;
            bool newPathHasProgram = false;
            if (currentPath.Items.Count > 1)
                currPathHasProgram = currentPath.Items[1].IsContainer;
            if (Path.SelectedPath.Count > 1)
                newPathHasProgram = Path.SelectedPath[1].IsContainer;

            // Path is not the same if only one has a program item.
            if (currPathHasProgram != newPathHasProgram)
                return false;

            // If both do not have programs, then the controllers matched and the path is the same.
            if ((!currPathHasProgram) && (!newPathHasProgram))
                return true;

            // Check whether program name is the same.
            if (currentPath.Items[1].DisplayName != Path.SelectedPath[1].DisplayName)
                return false;

            // Controller names and Program names match
            return true;
        }

        /// <summary>
        /// Adds the path element to the _path for the passed data item
        /// </summary>
        /// <param name="dataItem">Data Item representing the element to add a path element for</param>
        /// <returns>True if the path was updated successfully</returns>
        public IPathElement CreatePathElement(DataItemBase dataItem)
        {
            IPathElement newPathElement = PathElementUtility.Instance().CreateDataItemPathElement(dataItem.ToString(), String.Empty, true);
            
            return newPathElement;
        }

        public bool PopulatePathFromDataItemPath(DataItemBase dataItem, DataLoadComplete callback)
        {
            return false;
        }
        public ICollection<DataItemBase> GetCachedDevices()
        {
            return null;
        }
    }
}
