﻿/* Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                         
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This software has been provided pursuant to a License Agreement containing 
   restrictions on its use. The  software contains valuable trade secrets and 
   proprietary information of Rockwell Automation and is protected by federal 
   copyright law. It may not be copied or distributed in any form or medium, 
   disclosed to third parties or used in any manner not provided for  in the 
   License Agreement except with prior written permission of Rockwell Automation.

 *************************************************************************************/

using System;

namespace RockwellAutomation.Client.Services.Query.Common
{
    public static class DIBConstantsViewe
    {
        /// <summary>
        /// ReplicationState
        /// </summary>
        public const String ReplicationState = "ReplicationState";
        /// <summary>
        /// ReplicationErrorMessage
        /// </summary>
        public const String ReplicationErrorMessage = "ReplicationErrorMessage";
    }

}