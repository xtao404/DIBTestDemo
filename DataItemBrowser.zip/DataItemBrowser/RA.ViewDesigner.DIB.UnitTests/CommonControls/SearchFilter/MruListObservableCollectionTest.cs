﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.CommonControls.Models;
namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for MruListObservableCollectionTest and is intended
    ///to contain all MruListObservableCollectionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class MruListObservableCollectionTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SimpleNamesTest
        ///</summary>
        [TestMethod()]
        public void MruListObservableCollection_SimpleNamesTest()
        {
            MruListObservableCollection target = new MruListObservableCollection();
            string mruItem1 = "dataType=(\"DINT\" OR \"SINT\")";
            string mruItem2 = "dataType=(\"DINT\" OR \"INT\") name=state";
            string mruItem3 = "dataType=\"DINT\" name=descrip";
            target.Add(mruItem1);
            target.Add(mruItem2);
            target.Add(mruItem3);
            //there were 3 items added
            Assert.AreEqual(3, target.Count);
            //list comes back in reverse order
            Assert.AreEqual(mruItem3, target[0]);
            Assert.AreEqual(mruItem2, target[1]);
            Assert.AreEqual(mruItem1, target[2]);

        }

        /// <summary>
        ///A test for EmptyMruStringTest
        ///</summary>
        [TestMethod()]
        public void MruListObservableCollection_EmptyMruStringTest()
        {
            MruListObservableCollection target = new MruListObservableCollection();
            string mruItem1 = "  ";
            target.Add(mruItem1);
            //since the mru was an empty string no items were added
            Assert.AreEqual(0, target.Count);
        }
        /// <summary>
        ///A test for ReplaceTopMruStringTest
        ///</summary>
        [TestMethod()]
        public void MruListObservableCollection_ReplaceTopMruStringTest()
        {
            MruListObservableCollection target = new MruListObservableCollection();
            string mruItem1 = "First";
            target.Add(mruItem1);
            //since the mru was an empty string no items were added
            Assert.AreEqual(1, target.Count);
            Assert.AreEqual(mruItem1, target[0]);
            //try adding it again
            target.Add(mruItem1);
            //since the mru was an empty string no items were added
            Assert.AreEqual(1, target.Count);
            Assert.AreEqual(mruItem1, target[0]);

        } 
        /// <summary>
        ///A test for RepeatNameTest
        ///</summary>
        [TestMethod()]
        public void MruListObservableCollection_RepeatNameTest()
        {
            MruListObservableCollection target = new MruListObservableCollection();
            string mruItem1 = "dataType:(\"DINT\" OR \"SINT\")";
            string mruItem2 = "dataType:(\"DINT\" OR \"INT\") name=state";
            string mruItem3 = "dataType:\"DINT\" name=descrip";
            string mruItem4 = "dataType:\"DINT\" OR name=Tag";
            target.Add(mruItem1);
            target.Add(mruItem2);
            target.Add(mruItem3);
            target.Add(mruItem4);
            target.Add(mruItem1);
            //since mruItem1 was added twice it will only show up once
            Assert.AreEqual(4, target.Count);
            //since mruItem1 was added for a second time it will be at the front of the list
            Assert.AreEqual(mruItem1, target[0]);
            Assert.AreEqual(mruItem4, target[1]);
            Assert.AreEqual(mruItem3, target[2]);
            Assert.AreEqual(mruItem2, target[3]);

        }


        /// <summary>
        ///A test for RepeatNameTest
        ///</summary>
        [TestMethod()]
        public void MruListObservableCollection_ExceedMax()
        {
            MruListObservableCollection target = new MruListObservableCollection();
            string[] mruItems = { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven" };
            foreach(string item in mruItems)
                target.Add(item);
            //limit the count to 10 items
            Assert.AreEqual(10, target.Count);
            for (int i = 0; i < target.Count; i++)
            {
                //added in reverse order
                Assert.AreEqual(mruItems[mruItems.Length - (i+1)], target[i]);
            }

        }
        /// <summary>
        ///A test for SimpleNamesTest
        ///</summary>
        [TestMethod()]
        public void MruListObservableCollection_StepByStepTest()
        {
            MruListObservableCollection target = new MruListObservableCollection();
            string mruItem1 = "dataType:(\"DINT\" OR \"SINT\")";
            string mruItem2 = "dataType:(\"DINT\" OR \"INT\") name=state";
            string mruItem3 = "dataType:\"DINT\" name=descrip";

            //add first item
            target.Add(mruItem1);
            //there is 1 items added
            Assert.AreEqual(1, target.Count);
            Assert.AreEqual(mruItem1, target[0]);

            //add second item
            target.Add(mruItem2);
            //there are 2 items added
            Assert.AreEqual(2, target.Count);
            Assert.AreEqual(mruItem2, target[0]);
            Assert.AreEqual(mruItem1, target[1]);

            //add third item
            target.Add(mruItem3);
            //there are 3 items added
            Assert.AreEqual(3, target.Count);
            Assert.AreEqual(mruItem3, target[0]);
            Assert.AreEqual(mruItem2, target[1]);
            Assert.AreEqual(mruItem1, target[2]);

            //add first item again this will change the order
            target.Add(mruItem1);

            //there are 3 items added
            Assert.AreEqual(3, target.Count);
            //list comes back in reverse order
            Assert.AreEqual(mruItem1, target[0]);
            Assert.AreEqual(mruItem3, target[1]);
            Assert.AreEqual(mruItem2, target[2]);

        } 
    }
}
