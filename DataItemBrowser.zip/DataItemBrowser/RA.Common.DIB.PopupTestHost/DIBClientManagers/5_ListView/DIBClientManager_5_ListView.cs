﻿
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.DIBQuery;
using System.IO;
using System;
using System.Text;
using System.Collections.Generic;
using System.Xml;
using System.Reflection;
using RockwellAutomation.UI.Views;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    public class DIBClientManager_5_ListView : DIBClientManager, IDisposable
    {

        private FileSystemWatcher watcher = new FileSystemWatcher();
        private string baseAssemblyLocation;
        private string baseAssemblyLocationURIString;
        DataItemBrowser dibControl;

        #region Startup/Shutdown

        override public void InitializeDIBControlOnStartup(DataItemBrowser dataItemBrowserControl, StringBuilder logger)
        {
            dibControl = dataItemBrowserControl;
            baseAssemblyLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            baseAssemblyLocationURIString = "file:\\\\" + baseAssemblyLocation;

            // Create a new FileSystemWatcher and set its properties.
            watcher.Path = baseAssemblyLocation + @"\DIBClientManagers\5_ListView\";
            /* Watch for changes in LastAccess and LastWrite times, and
               the renaming of files or directories. */
            watcher.NotifyFilter = NotifyFilters.LastWrite;
            // Only watch text files.
            watcher.Filter = "*.xml";

            // Add event handlers.
            watcher.Changed += new FileSystemEventHandler(OnFileChanged);

            // Begin watching.
            watcher.EnableRaisingEvents = true;
        }

        private void OnFileChanged(object source, FileSystemEventArgs e)
        {
            if (!e.FullPath.EndsWith("BooksXML.xml")) return;
            dibControl.RefreshCurrentView();
        }

       
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (watcher != null)
                {
                    watcher.Dispose();
                    watcher = null;
                }
            }
        }

        #endregion

        #region Path Related Functionality

        override public string PathToString(List<IPathElement> fullPath, string nameToSelect, DIBViewItemBase.VisualPerspectiveEnum browserPerspective)
        {
            // custom logic for string representation of 
            // Path (Collection of ordered DataItembase instances representing Path user has navigated to)
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("++");
            foreach (IPathElement pathElement in fullPath)
            {
                if (pathElement != null && pathElement.DataItem != null)
                {
                    if (pathElement.DataItem.CommonDataType == "Book")
                        stringBuilder.Append("\\Book=(" + pathElement.DataItem.CommonLocation + ")");
                    else
                    {
                        stringBuilder.Clear();
                        stringBuilder.Append("++");
                        stringBuilder.Append("\\Author=(" + pathElement.DataItem.CommonName + ")");
                    }
                }
            }
            return stringBuilder.ToString();
        }

        #endregion

        #region Navigation overrides

        override public string GetResourceTypeString(DataItemBase dataItem)
        {
            return DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW;
        }

        override public IDIBDataViewType GetDataViewTypeFor(string resourceType)
        {
            return new DIBDataViewTypeListView();
        }

        #endregion

        #region Navigation Functionality

        override public void DrillInFor(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            var xml = new XmlDocument();
            xml.Load(baseAssemblyLocation + @"\DIBClientManagers\5_ListView\BooksXML.xml");

            if (dataItemToDrillInto == null)
            { 
                this.DrillIntoBooks(queryCache, xml);
                return;
            }
            this.DrillIntoAuthors(dataItemToDrillInto, queryCache, xml);
        }

        private void DrillIntoBooks(DIBQueryCache queryCache, XmlDocument xml)
        {
            XmlNodeList xnList = xml.SelectNodes("/catalog/books/book");

            foreach (XmlNode xn in xnList)
            {
                string idString = xn.Attributes[0].Value;
                string authorString = xn["author"].InnerText;
                string titleString = xn["title"].InnerText;
                string genreString = xn["genre"].InnerText;
                string priceString = xn["price"].InnerText;
                string publishDateString = xn["publish_date"].InnerText;
                string descriptionString = xn["description"].InnerText;

                DataItemBase newDIB = new DataItemBase();
                newDIB.CommonName = titleString + "\n (" + authorString + ")" + "\n $" + priceString;
                newDIB.CommonDataType = "Book";
                newDIB.CommonDescription = descriptionString;
                newDIB.CommonLocation = titleString;
                newDIB.CommonRefTargetId = authorString;
                newDIB.GUITreeViewID = idString;
                newDIB.GUITreeViewParentID = string.Empty;
                newDIB.GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\48by48\\Book.png";
                newDIB.GUISmallImageHeight = "32";
                newDIB.GUISmallImageWidth = "32";
                newDIB.GUITextFontWeight = "Heavy";
                newDIB.GUIToolTip = "Genre: " + genreString + ", Price: " + priceString + ", Publish Date: " + publishDateString;
                newDIB.GUISupportsDrillIn = "True";
                newDIB.GUISupportsSelection = "False";
                queryCache.AddDataItem(newDIB);
            }
        }

        private void DrillIntoAuthors(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache, XmlDocument xml)
        {
            XmlNode root = xml.DocumentElement;
            string searchpath = "/catalog/authors/author[./name='" + dataItemToDrillInto.CommonRefTargetId + "']";
            XmlNode userNode = root.SelectSingleNode(searchpath);

            string idString = userNode.Attributes[0].Value;
            string nameString = userNode["name"].InnerText;
            string genreString = userNode["genre"].InnerText;
            string birthDateString = userNode["birth_date"].InnerText;
            string descriptionString = userNode["description"].InnerText;

            DataItemBase newDIB = new DataItemBase();
            newDIB.CommonName = nameString;
            newDIB.CommonDataType = "Author";
            newDIB.CommonDescription = " Genre: " + genreString + ", Birthdate: " + birthDateString + " \n " + descriptionString;
            newDIB.CommonLocation = nameString;
            newDIB.CommonRefTargetId = null;
            newDIB.GUITreeViewID = idString;
            newDIB.GUITreeViewParentID = string.Empty;
            newDIB.GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\48by48\\comment.png";
            newDIB.GUISmallImageHeight = "48";
            newDIB.GUISmallImageWidth = "48";
            newDIB.GUITextFontWeight = "Heavy";
            newDIB.GUIToolTip = "Genre: " + genreString + ", Birth Date: " + birthDateString;
            newDIB.GUISupportsDrillIn = "False";
            newDIB.GUISupportsSelection = "True";
            queryCache.AddDataItem(newDIB);
        }

        #endregion


    }
}
