﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Object;
using TagFilterControl.Tags;
using TagFilterControl.Utility;

namespace TagFilterControl.Service
{
    public class TagService : ITagService
    {
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private Config config = Config.GetInstance();

        public TagTreeViewResult LoadSubItems(TagNode selectNode, bool isChecked)
        {
            TagTreeViewResult result = new TagTreeViewResult();
            result.Children = new ObservableCollection<TagNode>();

            switch (selectNode.Name)
            {
                case "User-Defined":
                    GetDataTypes(xmlHelper.UserDefined, isChecked, result);
                    break;
                case "Strings":
                    GetDataTypes(xmlHelper.Strings, isChecked, result);
                    break;
                case "Add-On-Defined":
                    GetDataTypes(xmlHelper.AddOnDefined, isChecked, result);
                    break;
                case "PreDefined":
                    GetDataTypes(xmlHelper.PreDefined, isChecked, result);
                    break;
                case "Module-Defined":
                    GetDataTypes(xmlHelper.ModuleDefined, isChecked, result);
                    break;
                case "Usage":
                    GetTageUsage(xmlHelper.Usage, isChecked, result);
                    break;
                case "ACM":
                    GetCustomProperties(isChecked, result);
                    break;
                default:
                    break;
            }

            switch (selectNode.Type)
            {
                case Types.CatalogNumber:
                    GetCatalogNumbers(xmlHelper.Libs, isChecked, result);
                    break;
                case Types.Interface:
                    GetInterfaces(xmlHelper.Libs, isChecked, result);
                    break;
                case Types.DataMembers:
                    GetDataMembers(xmlHelper.Libs, isChecked, result);
                    break;
                case Types.Name:
                    break;
                case Types.KEYID:
                    break;

                default:
                    break;
            }
            return result;
        }

        private void GetCustomProperties(bool isChecked, TagTreeViewResult result)
        {
            TagNode tag = new TagNode();
            tag.Name = "Catalog Number";
            tag.IsChecked = isChecked;
            tag.Type = Types.CatalogNumber;
            tag.HasChild = true;

            TagNode itag = new TagNode();
            itag.Name = "Interface";
            itag.IsChecked = isChecked;
            itag.Type = Types.Interface;
            tag.HasChild = true;

            TagNode dtag = new TagNode();
            dtag.Name = "DataMembers";
            dtag.IsChecked = isChecked;
            dtag.Type = Types.DataMembers;
            tag.HasChild = true;

            result.Children.Add(tag);
            result.Children.Add(itag);
            result.Children.Add(dtag);
        }

        private void GetInterfaces(List<LibraryEntity> libs, bool isChecked, TagTreeViewResult result)
        {
            foreach (LibraryEntity lib in libs)
            {
                if (lib.InterfaceLink != null)
                {
                    foreach (Interface inter in lib.InterfaceLink.Interfaces)
                    {
                        TagNode tag = new TagNode();
                        tag.Name = inter.Name;
                        tag.IsChecked = isChecked;
                        tag.Type = Types.InterfaceSelf;
                        tag.HasChild = false;
                        result.Children.Add(tag);
                    }
                }
            }
            result.Children.Last().IsLastChild = true;
        }

        private void GetDataMembers(List<LibraryEntity> libs, bool isChecked, TagTreeViewResult result)
        {
            foreach (LibraryEntity lib in libs)
            {
                if (lib.InterfaceLink != null)
                {
                    foreach (Interface inter in lib.InterfaceLink.Interfaces)
                    {
                        if (inter.Member != null)
                        {
                            foreach (Mem mem in inter.Member.Mems)
                            {
                                TagNode tag = new TagNode();
                                tag.Name = mem.Name;
                                tag.IsChecked = isChecked;
                                tag.Type = Types.DataMemberSelf;
                                tag.HasChild = false;
                                result.Children.Add(tag);
                            }
                        }
                    }
                }
            }
            result.Children.Last().IsLastChild = true;
        }

        private void GetCatalogNumbers(List<LibraryEntity> libs, bool isChecked, TagTreeViewResult result)
        {
            foreach (LibraryEntity item in libs)
            {
                TagNode tag = new TagNode();
                tag.Name = item.CatalogNumber;
                tag.IsChecked = isChecked;
                tag.Type = Types.CatalogNumberSelf;
                tag.HasChild = false;
                result.Children.Add(tag);
            }
            result.Children.Last().IsLastChild = true;
        }

        private void GetDataTypes(List<TagDataType> dataTypes, bool isChecked, TagTreeViewResult result)
        {
            foreach (TagDataType item in dataTypes)
            {
                TagNode tag = new TagNode();
                tag.Name = item.Name;
                tag.IsChecked = isChecked;
                tag.Type = Types.None;
                tag.HasChild = false;
                result.Children.Add(tag);
            }
            result.Children.Last().IsLastChild = true;
        }

        private void GetTageUsage(List<TagObjects> tags, bool isChecked, TagTreeViewResult result)
        {
            foreach (TagObjects item in tags)
            {
                if (item.Usage == TagUsage.None)
                {
                    continue;
                }
                TagNode tag = new TagNode();
                tag.Name = item.Usage.ToString();
                tag.IsChecked = isChecked;
                tag.Type = Types.None;
                tag.HasChild = false;
                result.Children.Add(tag);
            }
            result.Children.Last().IsLastChild = true;
        }
    }
}
