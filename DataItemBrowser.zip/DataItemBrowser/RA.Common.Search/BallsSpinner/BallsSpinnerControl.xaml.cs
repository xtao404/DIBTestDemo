﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Media.Animation;

namespace RockwellAutomation.UI.CommonControls
{
    /// <summary>
    /// Interaction logic for BallsSpinnerControl.xaml
    /// consists of 8 balls of dimishing opacity that spin in a larger cirle
    /// Properties:
    ///     ForegroundColor will change the color of the balls
    ///     ScaleFactor will scale the entire spinner (1.0 is default)
    /// </summary>
    public partial class BallsSpinnerControl : UserControl
    {
        /// <summary>
        /// member the timer used to determine how long to wait before showing the spinner
        /// </summary>
        private DispatcherTimer _delayTimer = null;
        /// <summary>
        /// member that the spinner should be stopped, this may not get applied until the timer fires
        /// </summary>
        static bool _stopSpinner = false;
        /// <summary>
        /// member that the spinner timer has started 
        /// </summary>
        static bool _timerStarted = false;
        /// <summary>
        /// the delay time in milliseconds (default value 1 second or 1000 milliseconds
        /// </summary>
        public static DependencyProperty DelayTimeProperty = DependencyProperty.Register("DelayTime",
                                typeof(int), typeof(BallsSpinnerControl), new PropertyMetadata(1000));
        public int DelayTime
        {
            get { return (int)GetValue(BallsSpinnerControl.DelayTimeProperty); }
            set { SetValue(BallsSpinnerControl.DelayTimeProperty, value); }
        }
        /// <summary>
        /// the factor to scale the entire spinner (1.0 is the default value)
        /// </summary>
        public static DependencyProperty ScaleFactorProperty = DependencyProperty.Register("ScaleFactor",
                                typeof(double), typeof(BallsSpinnerControl), new PropertyMetadata(1.0d));
        public double ScaleFactor
        {
            get { return (double)GetValue(BallsSpinnerControl.ScaleFactorProperty); }
            set { SetValue(BallsSpinnerControl.ScaleFactorProperty, value); }
        }
        /// <summary>
        /// constructor
        /// </summary>
        public BallsSpinnerControl()
        {
            InitializeComponent();
 

        }
        /// <summary>
        /// start the spinner (it will not be visible until after the DelayTime has passed
        /// </summary>
        public void Start()
        {
            //has the timer alredy started, then just get out
            if (_timerStarted)
                return;
            //set the flags
            _timerStarted = true;
            _stopSpinner = false;
            //delay before showing the spinner
            _delayTimer = new DispatcherTimer(DispatcherPriority.Normal);
            _delayTimer.Interval = TimeSpan.FromMilliseconds(DelayTime);
            //when the timer fires then process the visibility
            _delayTimer.Tick += (obj, arg) =>
            {
                //was it stopped before the timer fired, then keep it collapsed
                if (_stopSpinner)
                    this.Visibility = Visibility.Collapsed;
                else
                    //otherwise show the spinner
                    this.Visibility = Visibility.Visible;
                _delayTimer.Stop();
                _timerStarted = false;
            };
            //start the timer
            _delayTimer.Start();       
        }

       
        /// <summary>
        /// stop the spinner
        /// </summary>
        public void Stop()
        {
            //make sure it is collapsed now
            this.Visibility = Visibility.Collapsed;
            //set this member so when the timer fires it will keep it hidden
            _stopSpinner = true;
        }

        /// <summary>
        /// Wether or not we are spinning
        /// </summary>
        /// <returns>true if the spinner is in motion, false otherwise</returns>
        public static bool IsSpinning()
        {
            return (_stopSpinner == false);
        }
   }
}
