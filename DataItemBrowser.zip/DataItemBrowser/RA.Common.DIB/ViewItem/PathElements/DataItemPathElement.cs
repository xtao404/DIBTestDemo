﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.AbstractItem;


namespace RockwellAutomation.UI
{
    /// <summary>
    /// DataItem PathElement
    /// </summary>
    public class DataItemPathElement : PathElementBase
    {
   
        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public DataItemPathElement(DataItemBase dataItem, string displayName)
                :base(dataItem, displayName)
        {
        }

        #endregion

        #region private members

        private string _displayName = string.Empty;
        private bool _hasChildren = false;
        private bool _isActive = true;
        private bool _isContainer = false;
        private bool _isRootType = false;
        private bool _pathListChanged = false;
        private List<string> _pathList = null;

        #endregion

        #region IFactoryPathElement Implementation

        // If true then this path element is either a tag or a data type
        public bool IsRootType
        {
            get { return _isRootType; }
            set { _isRootType = value; }
        }

        /// <summary>
        /// Use this method to add owners to the pathlist.
        /// Method validates that the owner does not already exist in the list.
        /// It causes a change notification if an owner is added.
        /// </summary>
        public void AddPath(string owner)
        {
            // Don't let empty strings be added 
            if (owner == null || owner.Length == 0)
                return;

            if (owner == "<Common>")
                return;

            if (_pathList == null)
            {
                // Create the list
                _pathList = new List<string>();
            }

            // validate owner does not already exist in the collection
            string result = _pathList.Find
            (
                delegate(string str)
                {
                    return str == owner;
                }
            );

            if (result == null)
            {
                _pathList.Add(owner);

                //notify any listeners of the change
                PathListChanged = true;
            }
        }

        /// <summary>
        /// Indicates that the PathList has changed.
        /// Currently it is only supported by AddPath 
        /// </summary>
        public bool PathListChanged
        {
            get { return _pathListChanged; }
            set
            {
                _pathListChanged = value;
                //notify any listeners of the change
                NotifyPropertyChanged("PathListChanged");
            }
        }


        /// <summary>
        /// returns the list of controllers which include this data type
        /// </summary>
        public IList<string> PathList
        {
            get
            {
                if (_pathList == null)
                {
                    // Create the list
                    _pathList = new List<string>();
                }
                return _pathList;
            }
        }

        /// <summary>
        /// If true if PathList is not empty
        /// </summary>
        public bool ContainsPaths
        {
            get { return PathList.Count > 0; }
        }

        #endregion

        #region PathElementBase overrides

        /// <summary>
        /// Property to get or set the path element's display name.
        /// </summary>
        public override string DisplayName
        {
            get { return _displayName; }
            set { _displayName = value; }
        }

        /// <summary>
        /// Property to get or set if the path element has children.
        /// </summary>
        public override bool HasChildren
        {
            get { return _hasChildren; }
        }

        /// <summary>
        /// Property to get or set if the path element is active.
        /// </summary>
        public override bool IsActive
        {
            get { return _isActive; }
            set
            {
                if (_isActive == value)
                    return;
                _isActive = value;
                // notify listeners
                NotifyPropertyChanged("IsActive");
            }
        }

        /// <summary>
        /// Property to get or set if the path element is a container.
        /// </summary>
        public override bool IsContainer
        {
            get { return _isContainer; }
        }

        #endregion
    }    
}
