﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public static class FilterPolicyManager
    {
        public static FilterPolicyCommonModel GetDestFilterUtil()
        {
            return new FilterPolicyModel();
        }
    }
}
