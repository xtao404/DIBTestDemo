﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Xml;
using TagFilterControl.Common;
using TagFilterControl.Common.Controls;
using TagFilterControl.Controls;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.UserControls;
using TagFilterControl.Utility;

namespace Launch_TagFilterControl
{
    public class MainWindowViewModel : BaseViewModel
    {
        public MainWindowViewModel()
        {
            config.ConditionContentAction += content =>
            {
                ConditionContent = content;
            };
        }

        private ACDHelper acdHelper = ACDHelper.GetInstance();
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private Config config = Config.GetInstance();
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();

        private bool isOpen;
        public bool IsOpen
        {
            get { return isOpen; }
            set
            {
                isOpen = value;
                this.RaisePropertyChangedEvent(() => this.IsOpen);
            }
        }

        private CustomCommand launchCommand;
        public CustomCommand LaunchCommand
        {
            get
            {
                return this.launchCommand ?? (this.launchCommand = new CustomCommand(() =>
                {
                    //DIB_Window win = new DIB_Window();
                    //win.ShowDialog();
                    config.IsFirstToFilterDIBControl = true;
                    this.DIBFilterContent = new FilterDIB();
                    this.IsOpen = true;
                }));
            }
        }

        private FrameworkElement dibFilterContent;
        public FrameworkElement DIBFilterContent
        {
            get { return dibFilterContent; }
            set
            {
                dibFilterContent = value;
                this.RaisePropertyChangedEvent(() => this.DIBFilterContent);
            }
        }

        private CustomCommand filterCommand;
        public CustomCommand FilterCommand
        {
            get
            {
                return filterCommand ?? (this.filterCommand = new CustomCommand(() =>
                    {
                        PopupController.Open<PreFilterDIBManager>();
                    }));
            }
        }

        private CustomCommand browserCommand;
        public CustomCommand BrowserCommand
        {
            get
            {
                return this.browserCommand ?? (this.browserCommand = new CustomCommand(() =>
                {
                    Dispose();
                    OpenFileDialog openFileDialog = new OpenFileDialog();
                    openFileDialog.Title = "Select a file";
                    openFileDialog.Filter = "ACD File|*.ACD";
                    openFileDialog.FileName = string.Empty;
                    openFileDialog.FilterIndex = 1;
                    openFileDialog.RestoreDirectory = true;
                    openFileDialog.DefaultExt = "ACD";
                    DialogResult result = openFileDialog.ShowDialog();
                    if (result == DialogResult.Cancel)
                    {
                        return;
                    }
                    this.ACDPath = openFileDialog.FileName;
                    acdHelper.Path = this.ACDPath;

                    XmlDocument xmlDoc = acdHelper.ConvertACDToXML();
                    xmlHelper.LoadTagsTreeStructure(xmlDoc);
                    xmlHelper.LoadXmlFile();
                }));
            }
        }

        private string acdPath;
        public string ACDPath
        {
            get { return acdPath; }
            set
            {
                acdPath = value;
                this.RaisePropertyChangedEvent(() => this.ACDPath);
            }
        }

        private string conditionContent;
        public string ConditionContent
        {
            get { return conditionContent; }
            set
            {
                conditionContent = value;
                this.RaisePropertyChangedEvent(() => this.ConditionContent);
            }
        }

        private void Dispose()
        {
            xmlHelper.ControllerSubChildrensKeyValuePair.Clear();
            xmlHelper.ProgramTagsKeyValuePair.Clear();
            xmlHelper.DataTypes.Clear();
            xmlHelper.UserDefined.Clear();
            xmlHelper.Strings.Clear();
            xmlHelper.AddOnDefined.Clear();
            xmlHelper.PreDefined.Clear();
            xmlHelper.ModuleDefined.Clear();
            xmlHelper.Usage.Clear();
            xmlHelper.TempUsage.Clear();
            xmlHelper.ControllerTags.Clear();
            xmlHelper.UsedTags.Clear();
            xmlHelper.Libs.Clear();
            xmlHelper.TagOwners.Clear();
            config.IsCheckedTags.Clear();
            config.FilterItem.Clear();
        }
    }
}
