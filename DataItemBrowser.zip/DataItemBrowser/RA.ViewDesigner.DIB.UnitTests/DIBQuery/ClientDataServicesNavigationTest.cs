
#region references

using DataItemBrowserUT.Mocks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using RockwellAutomation.UI;
using System;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Models;
using RockwellAutomation.ServiceFramework.DataTypes;
using FakeItEasy;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.WindowsControl.DIBClient;

#endregion

namespace DataItemBrowserUT
{
    /// <summary>
    /// Test navigation in ClietnDataServices by mocking out DIBQueryCommand to MockDIBQueryCommand. 
    /// Doing that allows us to use CDS during our unit testing (without calls to QSP) like it will be used in production (with calls to QSP)
    ///</summary>
    [TestClass]
    public class ClientDataServicesNavigationTest
    {
        #region "Members"

        private string _problemText = "";
        private static ClientDataServices target;
        private static PrivateObject targetPrivate;
        private static TSObservableCollection<DataItemBase> DataItems;
        private RockwellAutomation.UI.Models.Path _path;
        private DataItemBrowserContext _defaultDataItemBrowserContent;
        static private MockDIBQueryConnection mockDIBQuery;
        private TestContext testContextInstance;

        #endregion

        #region Additional test attributes

        public ClientDataServicesNavigationTest()
        {
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        
        // Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void ClientDataServicesTestInit()
        {

            DIBClientManagerForViewe.Instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, this.FakeUUID(), this.FakeUUID());

            _path = new RockwellAutomation.UI.Models.Path();
            mockDIBQuery = new MockDIBQueryConnection();
            DIBClientManagerForViewe.Instance.QueryConnection = mockDIBQuery;
            DataItems = new TSObservableCollection<DataItemBase>();
            _defaultDataItemBrowserContent = DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext();
            target = new ClientDataServices(ref DataItems, this._path, DataServicesLoadComplete, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, DIBClientManagerForViewe.Instance);
            targetPrivate = new PrivateObject(target);

        }

        //
        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void ClientDataServicesTestCleanup()
        {
            DIBClientManagerForViewe.Instance.Shutdown();
            target.Close();
            _path = null;
            mockDIBQuery = null;
            DataItems =  null;
            _defaultDataItemBrowserContent =  null;
            target = null;
            targetPrivate = null;
        }

        public ulong HiWord(string project)
        {
            return Convert.ToUInt64(project.Substring(0, 16), 16);
        }

        public ulong LoWord(string project)
        {
            return Convert.ToUInt64(project.Substring(16, 16), 16);
        }       

        #endregion

        /// <summary>
        /// Test drilling into Data Sources and the properties that are set in CDS once the query completes.
        /// This test calls CDS to initialize which does the drill into devices the same way that DIBVMN would.
        /// 
        /// Note that since this test class is set up to use MockDIBQueryConnection, we do not have to wory about dispatcher timing and asynchronous calls when executing queries
        /// We tell MockDIBQueryConnection what results to return before we execute the query and MockDIBQueryConnection returns those results without any asynch calls
        ///</summary>
        [TestMethod]
        public void ClientDataServicesTest_DrillIntoDataSources()
        {
            target.SetProblemCallback(SetProblemVars);
            Assert.IsTrue(targetPrivate.GetFieldOrProperty("CurrentQueryCommand")== null, "There should not be any executing Data Command");
            // Execute CDS initialize like DataItemBrowserViewModel does
            target.Initialize(this._defaultDataItemBrowserContent, (dataContext, error) =>
            {
                target.DrillIn(dataContext.RootPath.DataItem);
            });

            Assert.IsTrue(this._problemText == String.Empty, "We should not have encounered any errors");

            // Validate current Data View
            Assert.IsTrue(target.DataView.IsTreeView(), "We should be in Data Sources View");

            // Validate there is no current Data Command executing
            Assert.IsTrue(targetPrivate.GetFieldOrProperty("CurrentQueryCommand")== null, "There should not be any executing Data Command");

            // Validate last executed Query Command and Query Type
            Assert.IsTrue(mockDIBQuery.LastExecutedQueryCommand != null, "There should be a last executed query command");
            Assert.IsTrue(mockDIBQuery.LastExecutedQueryCommand.QueryType() == PredefinedQueryType.Devices, "We should have executed a query for devices");
            mockDIBQuery.LastExecutedQueryCommand = null;

            // Validate returned DataItembase Results
            Assert.IsTrue(target.QueryCache.DataItems.Count == DataItems.Count, "The results should be the same as what the QueryCache is holding onto");
            Assert.IsTrue(DataItems.Count == MockDIBQueryConnection.SampleDevicesList().Count, "The results should be the same as our sample results");
            Assert.IsTrue(DataItems[0].CommonName == "Controller1", "Wrong DataItembase returned");
            Assert.IsTrue(DataItems[1].CommonName == "Controller2", "Wrong DataItembase returned");

            // Validate column configuration
            Assert.IsTrue(target.Columns.Count == 3, "3 column should exist for the Data Sources View. count = " + target.Columns.Count.ToString());
            Assert.IsTrue(target.Columns[0].GetColumn == DIBConstants.Common.Name, "Invalid column name = " + target.Columns[0].GetColumn);
            Assert.IsTrue(target.Columns[1].GetColumn == DIBConstantsViewe.ReplicationState, "Invalid column name = " + target.Columns[1].GetColumn); ;
            Assert.IsTrue(target.Columns[2].GetColumn == DIBConstantsViewe.ReplicationErrorMessage, "Invalid column name = " + target.Columns[2].GetColumn);
        }

        /// <summary>
        /// Test drilling into a Controller and the properties that are set in CDS once the query completes.
        /// This test calls CDS DrillIn the same way that DIBVMN would.
        /// 
        /// Note that since this test class is set up to use MockDIBQueryConnection, we do not have to wory about dispatcher timing and asynchronous calls when executing queries
        /// We tell MockDIBQueryConnection what results to return before we execute the query and MockDIBQueryConnection returns those results without any asynch calls
        ///</summary>
        [TestMethod]
        public void ClientDataServicesTest_DrillIntoController()
        {
            ClientDataServicesTest_DrillIntoDataSources();

            Assert.IsTrue(targetPrivate.GetFieldOrProperty("CurrentQueryCommand")== null, "There should not be any executing Data Command");
            // DrillIn to Controller1 to Controller view;
            target.DrillIn(DataItems[0]);

            Assert.IsTrue(this._problemText == String.Empty, "We should not have encounered any errors");

            // Validate current Data View
            Assert.IsTrue(target.DataView.IsControllerView(), "We should be in Controller View");

            // Validate there is no current Data Command executing
            Assert.IsTrue(targetPrivate.GetFieldOrProperty("CurrentQueryCommand")== null, "There should not be any executing Data Command");

            // Validate last executed Query Command and Query Type
            Assert.IsTrue(mockDIBQuery.LastExecutedQueryCommand == null, "There should not be a last executed query command");

            // Validate returned DataItembase Results
            Assert.IsTrue(target.QueryCache.DataItems.Count == DataItems.Count, "The results should be the same as what the QueryCache is holding onto");
            Assert.IsTrue(DataItems.Count == 2, "We should have executed a query for controller view"); //Change this to 3 items after R1 release as DataLogs will be added to this list
            Assert.IsTrue(DataItems[0].CommonResourceType == TypeIdentifiers.ResourceType_TagsAndProperties.ToString(), "Wrong DataItembase returned. There should be an item for Tags and Properties");
            Assert.IsTrue(DataItems[1].CommonResourceType == TypeIdentifiers.ResourceType_Programs.ToString(), "Wrong DataItembase returned. There should be an item for Programs");
            //Assert.IsTrue(DataItems[2].CommonResourceType == TypeIdentifiers.ResourceType_DataLogs.ToString(), "Wrong DataItembase returned. . There should be an item for Datalogs");

            // Validate column configuration
            Assert.IsTrue(target.Columns.Count == 2, "2 column should exist for the Data Sources View. count = " + target.Columns.Count.ToString());
            Assert.IsTrue(target.Columns[0].GetColumn == DIBConstants.Common.Name, "Invalid column name = " + target.Columns[0].GetColumn);
            Assert.IsTrue(target.Columns[1].GetColumn == DIBConstants.Common.Description, "Invalid column name = " + target.Columns[1].GetColumn);
        }

        /// <summary>
        /// Test drilling into TagsAndProperties and the properties that are set in CDS once the query completes.
        /// This test calls CDS DrillIn the same way that DIBVMN would.
        /// 
        /// Note that since this test class is set up to use MockDIBQueryConnection, we do not have to wory about dispatcher timing and asynchronous calls when executing queries
        /// We tell MockDIBQueryConnection what results to return before we execute the query and MockDIBQueryConnection returns those results without any asynch calls
        ///</summary>
        [TestMethod]
        public void ClientDataServicesTest_DrillIntoTagsAndProperties()
        {
            ClientDataServicesTest_DrillIntoController();

            Assert.IsTrue(targetPrivate.GetFieldOrProperty("CurrentQueryCommand") == null, "There should not be any executing Data Command");
            // DrillIn to TagsAndProperties;
            target.DrillIn(DataItems[0]);

            Assert.IsTrue(this._problemText == String.Empty, "We should not have encounered any errors ");

            // Validate current Data View
            Assert.IsTrue(target.DataView.IsGridView(), "We should be in Data Grid View");

            // Validate there is no current Data Command executing
            Assert.IsTrue(targetPrivate.GetFieldOrProperty("CurrentQueryCommand") == null, "There should not be any executing Data Command");

            // Validate last executed Query Command and Query Type
            Assert.IsTrue(mockDIBQuery.LastExecutedQueryCommand != null, "There should be a last executed query command");
            Assert.IsTrue(mockDIBQuery.LastExecutedQueryCommand.QueryType() == PredefinedQueryType.Tags, "We should have executed a query for tags");
            mockDIBQuery.LastExecutedQueryCommand = null;

            // Validate returned DataItembase Results
            Assert.IsTrue(target.QueryCache.DataItems.Count == DataItems.Count, "The results should be the same as what the QueryCache is holding onto");
            Assert.IsTrue(DataItems.Count == MockDIBQueryConnection.SampleTagsAndPropertiesList().Count, "The results should be the same as our sample results");
            Assert.IsTrue(DataItems.Count == 2);
            Assert.IsTrue(DataItems[0].CommonName == "tag1");
            Assert.IsTrue(DataItems[1].CommonName == "tag2");

            // Validate column configuration
            Assert.IsTrue(target.Columns.Count == 3, "4 column should exist for the Data Grid View. Count = " + target.Columns.Count.ToString());
            Assert.IsTrue(target.Columns[0].GetColumn == DIBConstants.Common.Name, "Invalid column name = " + target.Columns[0].GetColumn);
            Assert.IsTrue(target.Columns[1].GetColumn == DIBConstants.Common.DataType, "Invalid column name = " + target.Columns[1].GetColumn);
            Assert.IsTrue(target.Columns[2].GetColumn == DIBConstants.Common.Description, "Invalid column name = " + target.Columns[2].GetColumn);
        }

        /// <summary>
        /// Test drilling into a Controller
        /// This test calls CDS DrillIn the same way that DIBVMN NavigateNoGui or DataContext GetPathItems would.
        /// 
        /// Note that since this test class is set up to use MockDIBQueryConnection, we do not have to wory about dispatcher timing and asynchronous calls when executing queries
        /// We tell MockDIBQueryConnection what results to return before we execute the query and MockDIBQueryConnection returns those results without any asynch calls
        ///</summary>
        [TestMethod]
        public void ClientDataServicesTest_DrillInWithCallback_VerifyCallbacks()
        {            
            target.SetProblemCallback(SetProblemVars);
            Assert.IsTrue(targetPrivate.GetFieldOrProperty("CurrentQueryCommand") == null, "There should not be any executing Data Command");


            //set up parameters for method under test
            DataItemBase dataItem = PathElementUtility.Instance().CreateDataItemBase("c1");
            dataItem.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();

            // Execute CDS initialize like DataItemBrowserViewModel does
            string _errMessage = "Bogus String";
            target.Initialize(this._defaultDataItemBrowserContent, (dataContext, error) =>
            {
                target.DrillIn(dataItem, (err) =>
                {
                    _errMessage = err;
                });
            });

            //verify                        
            Assert.AreEqual(string.Empty, _problemText);
            Assert.AreEqual(string.Empty, _errMessage);
            // Validate returned DataItembase Results
            Assert.IsTrue(target.QueryCache.DataItems.Count == DataItems.Count, "The results should be the same as what the QueryCache is holding onto");

            Assert.IsTrue(2 == DataItems.Count, "There should be 2 items"); //Change this to 3 items after R1 release as DataLogs will be added to this list
            Assert.IsTrue(DataItems[0].CommonResourceType == TypeIdentifiers.ResourceType_TagsAndProperties.ToString(), "Wrong DataItembase returned. There should be an item for Tags and Properties");
            Assert.IsTrue(DataItems[1].CommonResourceType == TypeIdentifiers.ResourceType_Programs.ToString(), "Wrong DataItembase returned. There should be an item for Programs");
            //Assert.IsTrue(DataItems[2].CommonResourceType == TypeIdentifiers.ResourceType_DataLogs.ToString(), "Wrong DataItembase returned. . There should be an item for Datalogs");
        }

        /// <summary>
        /// Test the Search method in CDS for the TagBrowser
        /// 
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_Search_VerifyViewCalls()
        {
            //ARRANGE
            //set up the DIBQueryConnection
            var fakeDIBQueryConnection = A.Fake<IDIBQueryConnection>();
            A.CallTo(() => fakeDIBQueryConnection.isQueryInitialized()).Returns(true);
            A.CallTo(() => fakeDIBQueryConnection.HasValidPackageAndProjectContext()).Returns(true);

            //set up DIBQueryCommand
            var fakeDIBQueryCommand = A.Fake<IDIBQueryCommand>();

            //set up DIBQueryCache
            TSObservableCollection<DataItemBase> dataitems = new TSObservableCollection<DataItemBase>();
            DIBQueryCache mockDIBQueryCache = new MockDIBQueryCache(dataitems);

            //set up CDS            
            Path path = new Path();           
            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("Local:HMIDevice"));
            path.Add(PathElementUtility.Instance().CreateControllerPathElement("c1"));
            targetPrivate.SetField("_currentPath", path);
            targetPrivate.SetField("_cache", mockDIBQueryCache);
            DIBClientManagerForViewe.Instance.QueryConnection = fakeDIBQueryConnection;
            target.SetProblemCallback(SetProblemVars);

            //set up parameters for the call
            DataItemBase parentDIB = DIBUtility.GetControllerDataItemBase();
            SearchFilterDefinition searchFilterDef = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            //needs to be a "DataType" or the FilterTypes above need to be updated to allow Name and/or description to be a launch filter
            searchFilterDef.AddFilter("dt:", "DINT", false, SearchFilterDefinition.StatementLogic.AND);            
            SearchFilterConfig filterConfig = searchFilterDef.GetFilterConfig();
            target.Initialize(null, initCallback);

            //ACT            
            target.Search(parentDIB, filterConfig);

            //ASSERT
            IDIBDataViewType dataView = target.DataView as DIBDataViewTypeSearchGrid;
            Assert.IsNotNull(dataView);
            MockDIBQueryCache testmockDIBQueryCache = mockDIBQueryCache as MockDIBQueryCache;
            Assert.IsTrue(testmockDIBQueryCache.ClearDataItemsCalled);
            Assert.IsTrue(init_error.Equals(string.Empty));
            Assert.IsTrue(_problemText.Equals(string.Empty));
           // PrivateType dibQCForAllTags = new PrivateType("RA.Common.DIB", "RockwellAutomation.UI.DIBQuery.DIBQueryCommandForAllTags");
            //IDIBQueryCommand queryCommand = targetPrivate.GetField("CurrentQueryCommand") as RockwellAutomation.UI.DIBQuery.DIBQueryCommandForAllTags;
            //Assert.IsNotNull(queryCommand);

        }

        #region "Test data"


        /// <summary>
        /// DataServices load complete callback
        /// This is the same callback that DataBrowserViewModel registers for during navigation
        /// </summary>
        private void DataServicesLoadComplete(string error)
        {
            Assert.IsTrue(string.IsNullOrEmpty(error), "DataServicesLoadComplete returned an error = " + error);
        }

      
        /// <summary>
        /// This is a callback from CDS that informs of any errors that happened during naavigation
        /// </summary>
        private void SetProblemVars(string text, string helpid = "", bool disableSearch = false, bool disableCrumbs = false)
        {
            _problemText = text;
        }

        DataContext _initDataContext;
        string init_error = string.Empty;
        /// <summary>
        /// This is the callbase for CDS initialize
        /// </summary>
        /// <param name="dataContext"></param>
        /// <param name="error"></param>
        private void initCallback(DataContext dataContext, string error)
        {
            _initDataContext = dataContext;
            init_error = error;
        }
        private UUID FakeUUID()
        {
            string project = "00000000000011110000000000002222";
            UUID fakeUUID = UUID.CreateBuilder().SetHi(HiWord(project)).SetLo(LoWord(project)).Build();
            return fakeUUID;
        }

        #endregion
    }
}
