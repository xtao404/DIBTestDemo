/*************************************************************************************
                                                                     
   ViewE SearchFilterParser, FilterToken, FilterType ErrorData, FilterStatement                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System;
using System.Linq;
using System.Collections.ObjectModel;
using System.Text.RegularExpressions;

namespace RockwellAutomation.UI.CommonControls
{
    public delegate string GetFieldValue(string fieldName, object item);

    /// <summary>
    /// this class will do these things:
    ///     Parse a search/filter string into tokens.
    ///     Validate these tokens and report errors.
    ///     Generate a class representation that can be used for apply the search/filter
    ///     The ability to apply these searches and filters to any DataItemBase object
    /// </summary>
    public class SearchFilterParser
    {
        #region readonly members and enums
        //parsing group names
        public static readonly string WhiteSpaceGroup;
        public static readonly string ExactMatchValueGroup;
        public static readonly string FilterOperatorGroup;
        public static readonly string OpenParenGroup;
        public static readonly string CloseParenGroup;
        public static readonly string ValueGroup;
        public static readonly string BaseOperatorGroup;

        //base operators
        public static readonly string AndOperator;
        public static readonly string OrOperator;
        public static readonly string FilterOperatorDelimiter;
        

        //search syntax state values
        private enum SearchSyntaxStateEnum
        {
            seekingFilterOperatorOrSearchValue = 0,
            seekingFilterValue = 1,
            seekingBaseOperator = 2,
            seekingWhiteSpace = 3
        }
        #endregion readonly members and enums

        #region properties

        public SearchFilterDefinition FilterDefinition { get; set; }

        private ParserToken ErrorToken = null;

        public Collection<ParserToken> TokenCollection { get; internal set; }


        /// <summary>
        /// Specifies whether the parser will allow searching
        /// </summary>
        private bool _searchModeEnabled { get; set; }

        #endregion Properties

        #region constructor

        /// <summary>
        /// static constructor
        /// </summary>
        /// The following warning is suppressed because if we initialize the static fields where they are declared obfuscation will not obfuscate the strings.
        /// When we initialize the static fields in the static constructor, obfuscation does obfuscate the fields
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1810:InitializeReferenceTypeStaticFieldsInline")]
        static SearchFilterParser()
        {
            WhiteSpaceGroup = "whiteSpace";
            ExactMatchValueGroup = "exactMatchValue";
            FilterOperatorGroup = "filterOperator";
            OpenParenGroup = "openParen";
            CloseParenGroup = "closeParen";
            ValueGroup = "value";
            BaseOperatorGroup = "baseOperator";            
            AndOperator = "AND";
            OrOperator = "OR";
            FilterOperatorDelimiter = ":";
        }      

        /// <summary>
        /// private constructor
        /// </summary>
        public SearchFilterParser()
        {
            FilterDefinition = new SearchFilterDefinition(null);
            TokenCollection = new Collection<ParserToken>();
        }
        #endregion constructor

        #region public methods
        /// <summary>
        /// Parses the search filter string passed in and creates a class representation of it
        /// First we tokenize the string based on the operators and the filter operators
        /// Next we check for any filter operators that are in value positions and update the token collection
        /// Next we validate tokens syntax
        /// Then we generate statements
        /// Finally we validate statements syntax
        /// </summary>
        /// <param name="searchText">the search filter string</param>
        /// <param name="allowableFilters">allowable filter types</param>
        /// <param name="enableSearchMode">indicator to allow searching</param>
        /// <returns>true if successful, false otherwise</returns>
        public bool Parse(string searchText, ObservableCollection<FilterType> allowableFilters, bool enableSearchMode)
        {
            _searchModeEnabled = enableSearchMode;
 
            ////clear all the internal data 
            FilterDefinition = new SearchFilterDefinition(allowableFilters);
            FilterDefinition.FilterSearchState = SearchFilterDefinition.FilterSearchStateEnum.UseFilter;
            TokenCollection.Clear();
            
            //parse the string into tokens that we can then analyze
            if (!ParseStringIntoTokens(searchText))
                return false;

            //if the string is empty then treat it as no search/filter            
            if (IsSearchStringEmpty(searchText))
            {
                FilterDefinition.ClearSearch();
                return true;
            }

            //check for matching parentheses
            if (!CheckTokensForMatchingParentheses())
                return false;

            //DFCTS00119881: allow filteroperators as values
            if (!UpdateFilterOperatorsThatShouldBeValues())
                return false;

            InsertImplicitAnds();

            if (!ValidateTokenSyntax())
                return false;
            
            //these statements are used to apply view filtering
            if (!GenerateStatements())
                return false;
            FilterDefinition.HasNonEmptySearchValue = true;
            return true;
        }

        /// <summary>
        /// checks if the search text is just an empty search
        /// 
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        private static bool IsSearchStringEmpty(string text)
        {            
            return text.Length == 0;
        }

        /// <summary>
        /// Checks for filter operators located in value positions in the string and convert those values.
        /// Ex. 'n:' should be a value in both filter strings for the following: "d:(somstring n: dt:) d: (n: somotherstring)"
        /// Does some syntax checking
        /// The tokens after the first filter operator are checked
        /// The token collection is updated with any changes (filter operator group to value group)
        /// </summary>        
        /// <returns>true if successful, false otherwise</returns>
        private bool UpdateFilterOperatorsThatShouldBeValues()
        {
            
            int i = 0;
            while (i < TokenCollection.Count())
            {
                //check for token to be a filter operator
                if (TokenCollection[i].ParseGroup != FilterOperatorGroup)
                {
                    i++;
                    continue;
                }
                //update any filter operators directly after a filter operator to a filter value
                i++;
                //must have other tokens after a filter operator
                if (i >= TokenCollection.Count)
                {
                    TokenCollection[i - 1].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_FILTER_VALUE_MISSING;
                    FilterDefinition.ReportErrorState(true, TokenCollection[i - 1]);
                    return false;
                }
                //filteroperator found after a filteroperator e.g. dt:dt:
                if (TokenCollection[i].ParseGroup == FilterOperatorGroup)
                {
                    //take care of any multiple filter operators and update the token collection
                    i = ConvertFilterOperatorsAndUpdateTokenCollection(i);
                }
                //within parenthesis determine if there are filter operators that need to be
                //converted to values e.g. name:(dt:)
                else if (TokenCollection[i].ParseGroup == OpenParenGroup)
                {
                    //Look through all remaining tokens untill we reach the close parenthesis and force every token to be a value.
                    //We know that there is an existing close parenthesis since we have aleady passed that validation
                    i++;
                    int j = i;
                    while (j < TokenCollection.Count() && TokenCollection[j].ParseGroup != CloseParenGroup)
                    {
                        if (TokenCollection[j].ParseGroup == FilterOperatorGroup)
                        {
                            j = ConvertFilterOperatorsAndUpdateTokenCollection(j);
                        }
                        else
                        {
                            j++;
                        }
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Takes the TokenCollection index value and updates the parse group and value 
        /// If there are multiple filteroperators concatenated they will become one filter value
        /// and the token collection will be updated accordingly
        /// </summary>
        /// <param name="tokenCollectionIndex">index of the token collection item to be updated</param>
        /// <returns>the index value after all operations are complete</returns>
        private int ConvertFilterOperatorsAndUpdateTokenCollection(int tokenCollectionIndex)
        {
            System.Collections.ArrayList valueTokenIndexList = new System.Collections.ArrayList();
            valueTokenIndexList.Add(tokenCollectionIndex);

            string parseGroup = ValueGroup;
            int index = TokenCollection[tokenCollectionIndex].StartingIndex;
            string value = TokenCollection[tokenCollectionIndex].Value;

            //take care of any additional filteroperators e.g. dt:dt:dt:n:
            tokenCollectionIndex++;
            while (tokenCollectionIndex < TokenCollection.Count)
            {
                if (TokenCollection[tokenCollectionIndex].ParseGroup == FilterOperatorGroup || TokenCollection[tokenCollectionIndex].ParseGroup == ValueGroup)
                {
                    value += TokenCollection[tokenCollectionIndex].Value;
                    valueTokenIndexList.Add(tokenCollectionIndex);
                }
                else
                {   //if other parsegroup exit loop
                    break;
                }
                tokenCollectionIndex++;
            }

            ParserToken token = new ParserToken(parseGroup, value, index, false);
            int[] tokenIndex = (int[])valueTokenIndexList.ToArray(typeof(int));
            for (int j = tokenIndex.Length - 1; j > -1; j--)
            {
                TokenCollection.RemoveAt(tokenIndex[j]);
            }
            //insert the new value
            if (TokenCollection.Count > tokenIndex[0])
            {
                TokenCollection.Insert(tokenIndex[0], token);
            }
            else
            {
                TokenCollection.Add(token);
            }
            int newparseindex = tokenIndex[0] + 1;
            return newparseindex;
        }

        #endregion public methods

        #region protected methods
        
        /// <summary>
        /// generate filter statements from token collection
        /// </summary>
        /// <returns>true if statements created,false otherwise</returns>
        protected bool GenerateStatements()
        {
            int startIndex = 0;
            //remove leading whitespace if necessary
            if (TokenCollection[0].ParseGroup == WhiteSpaceGroup)
                startIndex++;

            ISearchStatement newStatement = null;
            //start by looking for a filter operator or a search value
            SearchSyntaxStateEnum searchState = SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue;
            SearchSyntaxStateEnum lastSearchState = SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue;
            // walk all tokens
            for (int i = startIndex; i < TokenCollection.Count(); i++)
            {
                //are we seeking a filter operator or a search value?
                switch (searchState)
                {
                    case SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue:
                        if (TokenCollection[i].ParseGroup == FilterOperatorGroup)
                        {                                                          
                            if (newStatement != null)
                            {
                                // get the baseoperator if it exists, it needs to be associated to the value after it
                                ParserToken baseOperator = newStatement.OperatorToken;
                                newStatement = new FilterStatement { FilterType = TokenCollection[i], OperatorToken = baseOperator };
                            }
                            else
                            {
                                newStatement = new FilterStatement {FilterType = TokenCollection[i]};
                            }

                            lastSearchState = searchState;
                            //change the  search state to look for a filter value
                            searchState = SearchSyntaxStateEnum.seekingFilterValue;
                        }
                        else
                        {
                            //Only allow search if the search mode enabled flag is set
                            if (_searchModeEnabled)
                            {
                                if (newStatement == null)
                                    newStatement = new SearchStatement { SearchValue = TokenCollection[i] };
                                else
                                    (newStatement as SearchStatement).SearchValue = TokenCollection[i];

                                
                                lastSearchState = searchState;
                                searchState = SearchSyntaxStateEnum.seekingWhiteSpace;
                            }
                            else
                            {
                                TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_SEARCHING_NOT_SUPPORTED;
                                FilterDefinition.ReportErrorState(true, TokenCollection[i]);
                                return false;
                            }
                        }
                        
                        if (!FilterDefinition.HasNonEmptySearchValue)
                        {
                            //set the operator for the very first statement to AND, needed for QueryConditionConfig
                            newStatement.OperatorToken = new ParserToken(BaseOperatorGroup, AndOperator, 0, false);
                        }
                        break;
                    case SearchSyntaxStateEnum.seekingWhiteSpace:
                        switch (lastSearchState)
                        {
                            case SearchSyntaxStateEnum.seekingFilterValue:
                                lastSearchState = searchState;
                                searchState = SearchSyntaxStateEnum.seekingBaseOperator;
                                break;
                            case SearchSyntaxStateEnum.seekingBaseOperator:
                                lastSearchState = searchState;
                                searchState = SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue;
                                break;
                            default:
                                if (_searchModeEnabled && lastSearchState == SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue)
                                {
                                    lastSearchState = searchState;
                                    searchState = SearchSyntaxStateEnum.seekingBaseOperator;
                                    
                                    FilterDefinition.Add(newStatement);
                                    newStatement = null;
                                }
                                    //this should not  happen and this means there is a bug in the token validation code
                                else
                                    System.Diagnostics.Debug.Assert(false);
                                break;
                        }
                        break;
                    case SearchSyntaxStateEnum.seekingFilterValue:
                        if (TokenCollection[i].ParseGroup == OpenParenGroup || TokenCollection[i].ParseGroup == ValueGroup)
                        {
                            //get filter values
                            Collection<ParserToken> values = null;
                            ProcessFilterValues(ref i, ref values);
                            //add values to the filter statement
                            (newStatement as FilterStatement).FilterValues = values;
                            lastSearchState = searchState;
                            //set the search state to seek whitespace                    
                            searchState = SearchSyntaxStateEnum.seekingWhiteSpace;
                        }
                            //this should not  happen and this means there is a bug in the token validation code
                        else
                            System.Diagnostics.Debug.Assert(false);
                        break;
                    case SearchSyntaxStateEnum.seekingBaseOperator:
                        if (i < TokenCollection.Count() && TokenCollection[i].ParseGroup == BaseOperatorGroup)
                        {
                            //if the operator token is already set then begin a new statement
                            if (newStatement == null || newStatement.OperatorToken != null)
                            {
                                if (newStatement != null) FilterDefinition.Add(newStatement);
                                newStatement = new SearchStatement() { OperatorToken = TokenCollection[i] };
                            }
                            else
                                newStatement.OperatorToken = TokenCollection[i];                            
                                
                        }
                            // if we do not find a base operator then set the operator token to null
                        else if (newStatement != null) newStatement.OperatorToken = null;
                        
                        lastSearchState = searchState;
                        searchState = SearchSyntaxStateEnum.seekingWhiteSpace;
                        break;
                }

            }
            //add the last statement if there is one
            if (newStatement != null)
                FilterDefinition.Add(newStatement);

            return true;
        }

        /// <summary>
        /// process filter values, accumulate all the value tokens for this filter into a collection 
        /// Word quotes - char value � is alt-0148 (numbers on the keypad not number key row)
        /// char value � is alt-0147 this is not the same as " or double quotes
        /// Only double quotes are supported           
        /// </summary>
        /// <param name="index">current index</param>
        /// <param name="values">returned values</param>
        /// <returns>true if values found, false otherwise</returns>
        protected bool ProcessFilterValues(ref int index, ref Collection<ParserToken> values)
        {
            //when you enter this method you have already found a left paren
            values = new Collection<ParserToken>();

            //missing filter value error
            if (index >= TokenCollection.Count())
                return false;

            //is single filter value
            if (TokenCollection[index].ParseGroup == ValueGroup)
            {   
                TokenCollection[index].Value = TokenCollection[index].Value.Trim('\"');
                values.Add(TokenCollection[index]);
            }
            else
            {
                //process multiple values enclosed in parentheses
                if (!ProcessMultipleValues(ref index, ref values))
                    return false;
            }
            return true;
        }      

        /// <summary>
        /// process multiple filter values (enclosed in parentheses)
        /// </summary>
        /// <param name="index">current index</param>
        /// <param name="values">returned value tokens</param>
        /// <returns>true if values are valid, false otherwise</returns>
        protected bool ProcessMultipleValues(ref int index, ref Collection<ParserToken> values)
        {
            //if first token is not a left paren then return
            if (TokenCollection[index].ParseGroup != OpenParenGroup)
                return false;

            //skip left paren
            index++;
            for (int i = index; i < TokenCollection.Count(); i++)
            {
                //found a right paren then return
                if (TokenCollection[i].ParseGroup == CloseParenGroup)
                {
                    index = i;
                    return true;
                }
                else
                {                    
                    if (TokenCollection[i].ParseGroup == ValueGroup)
                    {
                        TokenCollection[i].Value = TokenCollection[i].Value.Trim('\"');                        
                    }
                    //add filter value to collection
                    values.Add(TokenCollection[i]);
                }
            }
            //never found right paren
            return false;
        }

        /// <summary>
        /// parse the string into parsing tokens
        /// does not support Word document quotes alt-0147 (�) and alt-0148 
        /// </summary>
        /// <param name="searchText">search text</param>
        /// <returns>true if parsing was successful, false otherwise</returns>
        protected bool ParseStringIntoTokens(string searchText)
        {
            System.Diagnostics.Trace.WriteLine("**** ParseStringIntoTokens: searchText = " + searchText);

            //use this pattern to parse the search text using regular expression matching
            //we do not parse for operators (OR and AND), because they are case sensitive 
            //and this pattern is parsed case insensitive, we will handle this at token
            //creation
            string pattern = "(?<" + WhiteSpaceGroup + @">\s{1,})"; //check for white space (one or more spaces)
            pattern += @"|(?<" + ExactMatchValueGroup + ">\"[^\"]*\")"; //check for exact match value, text in quotes

            //check for all the filter operators
            pattern += @"|(?<" + FilterOperatorGroup + ">" + SearchFilterDefinition.FilterTypes[0].Operator;
            for (int i = 1; i < SearchFilterDefinition.FilterTypes.Count(); i++)
            {
                pattern += "|" + SearchFilterDefinition.FilterTypes[i].Operator; //check for filter operators
            }
            for (int i = 0; i < SearchFilterDefinition.FilterTypes.Count(); i++)
            {
                pattern += "|" + SearchFilterDefinition.FilterTypes[i].Shortcut; //B-12775: also check for filter shortcuts
            }
            pattern += @")";
            pattern += @"|(?<" + OpenParenGroup + @">\()"; //check for open parentheses
            pattern += @"|(?<" + CloseParenGroup + @">\))"; //check for close parentheses
            pattern += "|(?<" + ValueGroup + @">[^\s()]*)"; //all others EXCEPT for whitespace'\s', open parentheses'\(', and close parentheses '\)' are considered values

            //load and parse the regular expressions pattern (not case sensitive)
            Regex regexPattern = new Regex(pattern, RegexOptions.IgnoreCase);

            //find matches in the searchText based on the regular expresssion pattern
            MatchCollection matches = regexPattern.Matches(searchText);

            //generate tokens from the match data
            foreach (Match match in matches)
            {
                // ignore group index of 0, that match method put things into this collection starting
                // at index 1  (from microsoft)
                for (int groupIndex = 1; groupIndex < match.Groups.Count; groupIndex++)
                {
                    Group group = match.Groups[groupIndex];
                    string matchValue = group.Value;
                    //successful non-empty match
                    if (group.Success && !String.IsNullOrEmpty(matchValue))
                    {
                        string groupName = regexPattern.GroupNameFromNumber(groupIndex);
                        //since we do not have case checking in the regular expression 
                        //we detect base operators now
                        if (matchValue.Trim() == OrOperator || matchValue.Trim() == AndOperator)
                            groupName = BaseOperatorGroup;
                        if (!GenerateToken(groupName, matchValue, group.Index, searchText.Length))
                            return false;
                    }
                }
            }

            return true;
        }

        /// <summary>
        /// inserts implicit AND when necessary,  the algorithm is lookiing for this triplet
        /// token = value or right parentheses
        /// token + 1 = whitespace
        /// token + 2 = anything but a base operator
        /// </summary>
        protected void InsertImplicitAnds()
        {
            Collection<ParserToken> newList = new Collection<ParserToken>();
            //iterate through all tokens
            for (int i = 0; i < TokenCollection.Count(); i++)
            {
                //you need 3 tokens to determine if you can insert an implied AND
                if (i < TokenCollection.Count() - 2)
                {
                    //if the current token is a value token or a close parentheses token and
                    //it is followed by a whitespace token, then followed by anything other than 
                    //a base operator token.   Add the implicit AND
                    if ((TokenCollection[i].ParseGroup == ValueGroup || TokenCollection[i].ParseGroup == SearchFilterParser.CloseParenGroup) &&
                        (TokenCollection[i + 1].ParseGroup == WhiteSpaceGroup) &&
                        (TokenCollection[i + 2].ParseGroup != BaseOperatorGroup && TokenCollection[i + 2].ParseGroup != SearchFilterParser.CloseParenGroup))
                    {
                        //add the value token
                        newList.Add(TokenCollection[i]);
                        //add a whitespace token
                        newList.Add(new ParserToken(WhiteSpaceGroup, " ", -1, false));
                        //add a base operator token with a value of AND
                        newList.Add(new ParserToken(BaseOperatorGroup, AndOperator, -1, false));
                    }
                    else
                        //not a match then just add the token
                        newList.Add(TokenCollection[i]);
                }
                else
                    //if there are not 3 tokens available then just add the token
                    newList.Add(TokenCollection[i]);

            }
            TokenCollection = newList;
        }

        /// <summary>
        /// this is basically a state machine where we try to match open and close parentheses
        /// 
        /// First look for a open parentheses token
        /// for each token in the token list
        ///     if you find a open parentheses token
        ///         if you already saved an open parenthese report error nest parenthese
        ///         if you have a saved filter operator then save open parentheses
        ///         else report error no parentheses outside filter operator
        ///     if you find a close parentheses
        ///         if you saved an open parentheses then clear it
        ///         else report error dangling close parentheses
        ///     if you find a filter operator then save it
        /// repeat until end of tokens
        /// if dangling open parenthese then report error
        /// </summary>
        /// <returns>true parentheses are matched, false otherwise</returns>
        protected bool CheckTokensForMatchingParentheses()
        {
            ParserToken openParenFound = null;
            ParserToken previousToken = null;
            bool postFilterOp = false;
            for (int i = 0; i < TokenCollection.Count(); i++)
            {
                if (TokenCollection[i].ParseGroup == SearchFilterParser.FilterOperatorGroup)
                {
                    postFilterOp = true;
                }
                //is this token an open parentheses
                else if (TokenCollection[i].ParseGroup == SearchFilterParser.OpenParenGroup)
                {
                    //make sure we do not have nested parentheses
                    if (openParenFound != null)
                    {
                        openParenFound.SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_PARENTHESES_CANNOT_BE_NESTED;
                        ErrorToken = new ParserToken(openParenFound) {Value = string.Empty};
                        FilterDefinition.ReportErrorState(true, ErrorToken);
                        return false;
                    }
                    //see if the previous token was filter operator
                    if (previousToken != null && previousToken.ParseGroup == FilterOperatorGroup)
                    {
                        openParenFound = TokenCollection[i];
                    }
                    //cannot have parentheses outside of a filter
                    else
                    {
                        TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_PARENTHESES_MUST_SURROUND_FILTER_VALUES;
                        ErrorToken = new ParserToken(TokenCollection[i]) {Value = string.Empty};
                        FilterDefinition.ReportErrorState(true, ErrorToken);
                        return false;
                    }
                }
                //is this token a close parentheses
                else if (TokenCollection[i].ParseGroup == CloseParenGroup)
                {
                    //was there an open parentheses
                    if (openParenFound != null)
                    {
                        //start the cycle all over
                        openParenFound = null;
                        postFilterOp = false;
                    }
                    else
                    {
                        //cannot have parentheses outside of a filter - we look to see if we are "after" a FilterOp so that
                        // things like n:A OR B) yield a missing open paren (even though from a pure syntax the space would
                        // denote that parens should only surround filter values)
                        if (postFilterOp==false && (previousToken == null || previousToken.ParseGroup == ValueGroup || previousToken.ParseGroup == WhiteSpaceGroup))
                        {
                            TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_PARENTHESES_MUST_SURROUND_FILTER_VALUES;
                            ErrorToken = new ParserToken(TokenCollection[i]) { Value = string.Empty };
                            FilterDefinition.ReportErrorState(true, ErrorToken);
                        }
                        //dangling close parenthesis
                        else
                        {
                            TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_OPEN_PARENTHESIS_MISSING;
                            FilterDefinition.ReportErrorState(true, TokenCollection[i]);
                        }

                        return false;
                    }
                }
                previousToken = TokenCollection[i];
            }
            //when we reach the end is there a dangling open parentheses
            if (openParenFound != null)
            {
                openParenFound.SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_CLOSE_PARENTHESIS_MISSING;
                FilterDefinition.ReportErrorState(true, openParenFound);
                return false;
            }
            return true;
        }

        /// <summary>
        ///this is basically a state machine where we follow these states:
        ///Start by seek a search value token or a filter operator token
        ///for each token in the tokenList
        ///    if you find a search value token next seek a whitespace token
        ///    if you find a filter operator token then seek a filter value token 
        ///          and then seek a whitespace token
        ///    if you find one or many filter value tokens then seek a whitespace token
        ///    if you find a whitespace token and the last state was seeking a filter value token
        ///          then seek a base operator token
        ///Repeat
        ///Report error if last token was a filter operator or a base operator
        /// </summary>
        /// <returns>true if the syntax is valid, false otherwise</returns>
        protected bool ValidateTokenSyntax()
        {
            int startIndex = 0;
            
            //remove leading whitespace if necessary
            if (TokenCollection[0].ParseGroup == WhiteSpaceGroup)
                startIndex++;

            ParserToken lastFilterOperator = null;
            //start seeking a search value of a filter operator
            SearchSyntaxStateEnum searchState = SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue;
            SearchSyntaxStateEnum lastSearchState = SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue;
            for (int i = startIndex; i < TokenCollection.Count(); i++)
            {
                //seeking search value or filter operator 
                if (searchState == SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue)
                {
                    //is this token a filter operator?
                    if (TokenCollection[i].ParseGroup == FilterOperatorGroup)
                    {
                        //set filter operator
                        lastFilterOperator = TokenCollection[i];
                        //reset the base operator and seek for a filter value
                        lastSearchState = searchState;
                        searchState = SearchSyntaxStateEnum.seekingFilterValue;
                    }
                    //is this token a value?
                    else if (TokenCollection[i].ParseGroup == ValueGroup)
                    {
                        //was the last token a filter operator then this is a search value
                        if (lastFilterOperator == null)
                        {
                            if (_searchModeEnabled)
                            {
                                if (!ValidateFilterValues(ref i))
                                    //the error status is reported in the ValidateFilterValues method
                                    return false;
                                lastSearchState = searchState;
                                searchState = SearchSyntaxStateEnum.seekingWhiteSpace;
                            }
                            else
                            {
                                TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_SEARCHING_NOT_SUPPORTED;
                                FilterDefinition.ReportErrorState(true, TokenCollection[i]);
                                return false;
                            }
                        }

                    }

                    //otherwise this is an error
                    else
                    {
                        //is this token a base operator, then dangling operator
                        TokenCollection[i].SyntaxErrorMessage = TokenCollection[i].ParseGroup == BaseOperatorGroup ? Properties.Resources.ERROR_SEARCH_KEYWORD_INCORRECTLY_USED : Properties.Resources.ERROR_SEARCH_FILTER_STATEMENT_MISSING;
                        ErrorToken = new ParserToken(TokenCollection[i]) { Value = String.Empty };
                        FilterDefinition.ReportErrorState(true, ErrorToken);
                        return false;
                    }
                }
                //seeking a filter value
                else if (searchState == SearchSyntaxStateEnum.seekingFilterValue)
                {
                    //there cannot be white space after a filter operator
                    if (TokenCollection[i].ParseGroup == WhiteSpaceGroup)
                    {
                        TokenCollection[i - 1].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_DELETE_BLANK_SPACES;
                        FilterDefinition.ReportErrorState(true, TokenCollection[i - 1]);
                        return false;
                    }
                    //do filter value processing
                    if (!ValidateFilterValues(ref i))
                        //the error status is reported in the ValidateFilterValues method
                        return false;
                    //then seek for white space 
                    lastSearchState = searchState;
                    searchState = SearchSyntaxStateEnum.seekingWhiteSpace;
                }
                //seeking white spsace
                else if (searchState == SearchSyntaxStateEnum.seekingWhiteSpace)
                {
                    //if it is white space
                    if (TokenCollection[i].ParseGroup == WhiteSpaceGroup)
                    {
                        //if the last state was seeking a filter value, then seek a base operator
                        switch (lastSearchState)
                        {
                            case SearchSyntaxStateEnum.seekingFilterValue:
                                lastSearchState = searchState;
                                searchState = SearchSyntaxStateEnum.seekingBaseOperator;
                                break;
                            case SearchSyntaxStateEnum.seekingBaseOperator:
                                lastSearchState = searchState;
                                searchState = SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue;
                                break;
                            default:
                                if (_searchModeEnabled && lastSearchState == SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue)
                                {
                                    lastSearchState = searchState;
                                    searchState = SearchSyntaxStateEnum.seekingBaseOperator;
                                }
                                else
                                {
                                    TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_UNEXPECTED_WHITESPACE;
                                    FilterDefinition.ReportErrorState(true, TokenCollection[i - 1]);
                                    return false;
                                }
                                break;
                        }
                    }
                    else
                    {
                        //not a whitespace token
                        TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_BLANK_SPACE_MISSING;
                        FilterDefinition.ReportErrorState(true, TokenCollection[i]);
                        return false;
                    }

                }
                //seeking a base operator
                else if (searchState == SearchSyntaxStateEnum.seekingBaseOperator)
                {
                    //is this token a base operator 
                    if (TokenCollection[i].ParseGroup == BaseOperatorGroup)
                    {
                        //Then seek for a filter operator or search value
                        lastFilterOperator = null;
                        lastSearchState = searchState;
                        searchState = SearchSyntaxStateEnum.seekingWhiteSpace;

                    }
                    //error missing operator if this is not a base operator token
                    else
                    {
                        TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_EXPECTED_OPERATOR;
                        FilterDefinition.ReportErrorState(true, TokenCollection[i]);
                        return false;
                    }

                }

            }
            //error if you are ending the search and you are still seeking a filter value 
            //(i.e. dangling filter operator)
            if (searchState == SearchSyntaxStateEnum.seekingFilterValue)
            {
                if (lastFilterOperator != null)
                {
                    lastFilterOperator.SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_FILTER_VALUE_MISSING;
                    FilterDefinition.ReportErrorState(true, lastFilterOperator);
                }
                return false;

            }
            //error if you are ending the search and you are still seeking a filter type or search value 
            //(i.e. dangling operator)
            if (searchState == SearchSyntaxStateEnum.seekingFilterOperatorOrSearchValue ||
               (searchState == SearchSyntaxStateEnum.seekingWhiteSpace && lastSearchState == SearchSyntaxStateEnum.seekingBaseOperator))
            {
                TokenCollection[TokenCollection.Count() - 1].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_FILTER_STATEMENT_MISSING;
                FilterDefinition.ReportErrorState(true, TokenCollection[TokenCollection.Count() - 1]);
                return false;

            }
            return true;
        }

        ///<summary>
        /// this is basically a state machine if the first token is a value then you are done
        ///the first token must be an open parentheses token then seek a filter value token
        ///for each token in the tokenlist
        //  if you find a filter value token then seek a whitespace token
        //  if you find a base operator token then seek a whitespace token
        //  if you find a whitespace token and the last seek was a filter value token then
        //      seek a base operator token
        //  if you find a whitespace token and the last seek was a base operator token then
        //      seek a filter value token
        /// if you find a close parenthese then break out of the loop
        ///repeat 
        ///report an error if you have a dangling operator when you are done
        /// </summary>
        /// <param name="index">starting index</param>
        /// <returns>true if the filter value syntax is valid, false otheriwise</returns>
        protected bool ValidateFilterValues(ref int index)
        {
            ParserToken lastOperator = null;

            //check for single value
            if (TokenCollection[index].ParseGroup == ValueGroup)
            {
                //trim out all quotes and spaces
                string checkValue = TokenCollection[index].Value.Trim('\"');
                if (checkValue.Length > 0)
                {
                    return true;                   
                }                
                else
                {  //we shouldn't get here since quote validation is done in GenerateToken
                    TokenCollection[index].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_QUOTATION_MARKS_INCORRECT;
                    ErrorToken = new ParserToken(TokenCollection[index]){Value = string.Empty};
                    FilterDefinition.ReportErrorState(true, ErrorToken);
                    return false;
                }
            }
            else if (TokenCollection[index].ParseGroup == FilterOperatorGroup)
            {
                //DFCTS00119881: make a filter operator in a value position a value
                TokenCollection[index].ParseGroup = ValueGroup;
                return true;
            }
            //parentheses have been validated prior to this call so we can assume there will be a close parentheses
            if (TokenCollection[index].ParseGroup == OpenParenGroup)
            {
                index++;
                //if there is leading whitespace then skip it
                if (TokenCollection[index].ParseGroup == WhiteSpaceGroup)
                    index++;
            }
            else
            {
                TokenCollection[index - 1].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_FILTER_VALUE_MISSING;
                FilterDefinition.ReportErrorState(true, TokenCollection[index - 1]);
                return false;
            }

            //set the current state
            SearchSyntaxStateEnum valueState = SearchSyntaxStateEnum.seekingFilterValue;
            SearchSyntaxStateEnum lastValueState = SearchSyntaxStateEnum.seekingFilterValue;

            // Assumption is that you have an open paren before getting here
            // this is a state machine looking for this pattern
            // alternating [value] and [operator] ending with a [closeParen]
            for (int i = index; i < TokenCollection.Count(); i++)
            {
                ////cannot have filter operators in the value list
                if (TokenCollection[i].ParseGroup == FilterOperatorGroup)
                {
                    // DFCTS00119881: Update FilterOperatorGroup to ValueGroup                                       
                    //change ParseGroup
                    TokenCollection[i].ParseGroup = ValueGroup;

                    lastOperator = null;
                    lastValueState = valueState;
                }

                //if this token is a close parentheses then exit the loop
                if (TokenCollection[i].ParseGroup == CloseParenGroup)
                {
                    index = i;
                    //
                    // DFCTS00119882: Verify that the lastOperator is set.
                    // If not, this means that we found both an open
                    // and a close paren without a value - e.g. "name:()"
                    // We need to find the open paren and set the lastOperator 
                    // so that the error can be appropriately returned.
                    //
                    if (null == lastOperator)
                    {
                        int temp = 0;
                        //backup until we find the matching open paren
                        for (temp = index - 1; temp > 0; temp--)
                        {
                            if (TokenCollection[temp].ParseGroup == OpenParenGroup)
                                break;
                        }
                        temp = (temp > 0) ? (temp - 1) : 0;
                        lastOperator = TokenCollection[temp];
                    }
                    break;
                }

                //if you are seeking a filter value
                if (valueState == SearchSyntaxStateEnum.seekingFilterValue)
                {
                    //make sure the token is a value
                    if (TokenCollection[i].ParseGroup == ValueGroup)
                    {
                        lastOperator = null;
                        lastValueState = valueState;
                        valueState = SearchSyntaxStateEnum.seekingWhiteSpace;
                    }
                    //report error dangling base operator
                    else
                    {
                        TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_KEYWORD_INCORRECTLY_USED;
                        ErrorToken = new ParserToken(TokenCollection[i]) { Value = String.Empty};
                        FilterDefinition.ReportErrorState(true, ErrorToken);
                        return false;
                    }
                }
                //are we seeking whitespace
                else if (valueState == SearchSyntaxStateEnum.seekingWhiteSpace)
                {
                    //report error if it is not a whitespace token
                    if (TokenCollection[i].ParseGroup == WhiteSpaceGroup)
                    {
                        //if the last state was seeking a filter value then seek a base operator
                        if (lastValueState == SearchSyntaxStateEnum.seekingFilterValue)
                        {
                            lastValueState = valueState;
                            valueState = SearchSyntaxStateEnum.seekingBaseOperator;
                        }
                        //if the last state was seeking a base operator then seek a filter value
                        else if (lastValueState == SearchSyntaxStateEnum.seekingBaseOperator)
                        {
                            lastValueState = valueState;
                            valueState = SearchSyntaxStateEnum.seekingFilterValue;
                        }
                    }
                    //otherwise report an error
                    else
                    {
                        TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_BLANK_SPACE_MISSING;
                        FilterDefinition.ReportErrorState(true, TokenCollection[i]);
                        return false;
                    }

                }
                //are we seeking a base operator
                else if (valueState == SearchSyntaxStateEnum.seekingBaseOperator)
                {
                    //is this token a base operator
                    if (TokenCollection[i].ParseGroup == BaseOperatorGroup)
                    {
                        //save the last operator and then seek white space
                        lastOperator = TokenCollection[i];
                        lastValueState = valueState;
                        valueState = SearchSyntaxStateEnum.seekingWhiteSpace;
                    }                    
                    else
                    {   //not expected to reach this since the search text is modified to avoid this error
                        TokenCollection[i].SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_EXPECTED_OPERATOR;
                        FilterDefinition.ReportErrorState(true, TokenCollection[i]);
                        return false;
                    }
                }

            }
            //the last token cannot be an operator
            if (valueState == SearchSyntaxStateEnum.seekingFilterValue ||
                (valueState == SearchSyntaxStateEnum.seekingWhiteSpace &&
                lastValueState == SearchSyntaxStateEnum.seekingBaseOperator))
            {
                lastOperator.SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_FILTER_VALUE_MISSING;
                FilterDefinition.ReportErrorState(true, lastOperator);
                return false;
            }
            return true;
        }

        /// <summary>
        /// generate a token from these parameters, this method can fail if there are errors
        /// with quotation marks
        /// THE ORDER OF VALIDATION MATTERS FOR THE CORRECT ERROR MESSAGE TO DISPLAY
        /// </summary>
        /// <param name="group">parser group name</param>
        /// <param name="value">token value</param>
        /// <param name="index">index of this token in the search string</param>
        /// <param name="length">the length of the entire search string</param>
        /// <returns>true token created successfully, false value with only one quote mark</returns>
        protected bool GenerateToken(string group, string value, int index, int length)
        {
            if (value==null)
                value = string.Empty;
            bool exactMatch = false;
            //an exact match value is really just a value with the exact match property set
            if (group == ExactMatchValueGroup)
            {
                group = ValueGroup;
                exactMatch = true;
            }
            //create token and add it to the list
            ParserToken token = new ParserToken(group, value, index, exactMatch);
            TokenCollection.Add(token);

            //check if the value starts with a space and contains only spaces and error now, don't let the search statement 
            //continue through the parser            
            if (index == 0 && string.IsNullOrWhiteSpace(value) && (length - value.Length == 0))
            {
                SetError(token, Properties.Resources.ERROR_SEARCH_CANNOT_START_WITH_SPACE,true);
                return false;
            }

            
            //count the quotation marks to see if they are matched
            int quoteCount = 0;
            int quote = value.IndexOf("\"");
            
            while (quote != -1)
            {
                quoteCount++;
                quote = value.IndexOf("\"", quote + 1);                
            }

            if (quoteCount == 0)
                return true;
            //empty quotes
            else if (quoteCount == 2 && exactMatch && value.Length <= 2)
            {   
                SetError(token,Properties.Resources.ERROR_SEARCH_QUOTATION_MARKS_INCORRECT,false);                
                return false;
            }
            //quotes within a string, if the value starts with a base operator set 
            //an error message that is more relevant for base operators, this check is not found in ValidateTokenSyntax since the 
            //base operator is not identified as a separate token e.g. dt:("a" OR"array"), OR"array" is a value token
            else if (quoteCount >= 2 && !exactMatch 
                && (value.StartsWith(OrOperator) || value.StartsWith(AndOperator)))
            {
                SetError(token, Properties.Resources.ERROR_SEARCH_BLANK_SPACE_MISSING,false);
                return false;
            }
            //quotes within a string
            else if (quoteCount >= 2 && !exactMatch)
            {
                SetError(token, Properties.Resources.ERROR_SEARCH_QUOTATION_MARKS_INCORRECT, false);
                return false;
            }
            else if (quoteCount == 2 && exactMatch && value.Length > 2)
                return true; //allow exact match searches

            //if the string value that does not have matched quotes is an error
            if (group == ValueGroup && !exactMatch && quoteCount % 2 == 1)
            {
                token.SyntaxErrorMessage = Properties.Resources.ERROR_SEARCH_QUOTATION_MARK_MISSING;
                FilterDefinition.ReportErrorState(true, token);
                return false;
            }
            var foundPreQuoteToken = FindTokenBeforeQuote();    

            if (!foundPreQuoteToken)
            {
                SetError(token, Properties.Resources.ERROR_SEARCH_QUOTATION_MARKS_INCORRECT,false);
                return false;
            }

            return true;
        }

        /// <summary>
        /// Go backwards in current token collection and report on wether or not we find a valid quote start identifier
        /// </summary>
        private bool FindTokenBeforeQuote()
        {
            //This token includes quotes and we need to verify that these quotes are located inside a search or filter statement.
            //Going backwards in the token list from the position we just added, we want to search for an open parenthesis, a filter operator token,
            // or a value (denoting the entire token is the search)
            //if one is not found, we have an error
            int i = TokenCollection.Count() - 1;
            Boolean foundPreQuoteToken = false;
            while (i >= 0)
            {
                if (TokenCollection[i].ParseGroup == FilterOperatorGroup || TokenCollection[i].ParseGroup == OpenParenGroup)
                {
                    foundPreQuoteToken = true;
                }
                i--;
            }
            return foundPreQuoteToken;
        }

        /// <summary>
        /// Set parse results as error
        /// </summary>
        /// <param name="token">The token being processed when error was encoutnered</param>
        /// <param name="errorMessage">Error string</param>
        /// <param name="clearErrorToken"></param>
        private void SetError(ParserToken token, string errorMessage, bool clearErrorToken)
        {
            token.SyntaxErrorMessage = errorMessage;
            ErrorToken = clearErrorToken ? new ParserToken(token) {Value = string.Empty} : token;

            FilterDefinition.ReportErrorState(true, ErrorToken);            
        }

        #endregion protected methods

    }
}
