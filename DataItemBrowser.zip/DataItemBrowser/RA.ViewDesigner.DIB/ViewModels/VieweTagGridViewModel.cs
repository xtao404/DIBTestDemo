/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System.Linq;
using System.Collections.Generic;
using System.Collections;
using System;

using Xceed.Wpf.DataGrid;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.Models;
using RockwellAutomation.Client.Services.Query.Common;

#endregion

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// View model supporting the Viewe <c>DIBGridView</c>
    /// </summary>
    public class VieweTagGridViewModel : DIBGridViewModel
    {        
        #region Properties/Variables

        /// <summary>
        /// Represents the tags and properties data item for 
        /// the current data items
        /// </summary>
        public static DataItemBase TagsAndPropsItem
        {
            get { return DIResource.DIB_TagsAndProps; }         
        }

        /// <summary>
        /// Represents if the current browser is a Tag browser 
        /// versus another type such as a Data Type Picker
        /// </summary>
        public bool IsTagBrowser
        {
            get { return _dibViewModel.IsTagBrowser(); }
        }
        
  		/// <summary>
        /// Represents if the current data items contain a 
        /// tags and properties item
  		/// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "value",Justification = "Leaving in for the short term to ensure we don't break TAF ViewModel API Actors")]
        public bool HasTagsAndProps
		{
			get
			{
				// We have tags and properties if we are currently scoped to a controller view or a HMIdevice view
                IPathElement currentElement = this.Path.ActiveElement;
                return ((currentElement as ControllerPathElement != null || (currentElement as HMIDevicePathElement != null)) && !this.IsQueryBasedSearchActive) 
                        ||
                        (currentElement is HomePathElement && !this.IsQueryBasedSearchActive && (DIResource.IsResourceTypeControllerOrHMIDevice(currentElement.DataItem)));
			}
			// Leaving in for the short term to ensure we don't break TAF ViewModel API Actors
			set {}
		}

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dibVM">reference to the DataItemBrowser view model</param>
        public VieweTagGridViewModel(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {         
        }

        #endregion

        #region Overrides

        /// <summary>
        /// Always allow drillins for viewe grid view.
        /// Note we still look at individual DataItemBase instances 
        /// to see whether they allow drillins
        /// </summary>
        public override bool AllowItemDrillIns
        {
            get { return _dibViewModel.IsTagBrowser(); }
        }

        /// <summary>
        /// Mouse double click selection method
        /// </summary>
        /// <param name="selectedNameDIB"></param>
        public override void DoubleClickSelection(DataItemBase selectedNameDIB)
        {
            // always allow an item to be selected when double clicking in the DIB
            _dibViewModel.SelectedItemCommand.Execute(selectedNameDIB);
        }

        protected override DataItemBase getDefaultItemToSelectFrom(DataGridCollectionView curCollectionView)
        {
            return this.HasTagsAndProps ? null : curCollectionView.GetItemAt(0) as DataItemBase;
        }

        protected override bool IsNextDrillInItemOfRootType()
        {
            // Determine if the request is to drill into a Tag.
            int count = _dibViewModel.Path.SelectedPath.Count;
            if (count > 0) return false;
            IPathElement lastPathItem = _dibViewModel.Path.SelectedPath.Last();
            if (lastPathItem is ProgramPathElement) return true;
            if (lastPathItem is TagsPropertiesPathElement) return true;

            return false;
        }

        ///<summary>
        /// There is a case where we can be drilling into TagsAndProperties 
        /// or a Tag and while the spinner is going the user can select 
        /// either TagsAndProperties or the same Tag again
        /// if this occurs we do not want it added to the breadcrumbs
        ///</summary>
        /// <param name="newPE"></param>
        protected override bool IsDuplicateDrillIn(IPathElement newPE)
        {
            bool isDuplicate = false;
            IPathElement existingPE = _dibViewModel.Path.SelectedPath.Last();
            TagsPropertiesPathElement tagsPropsPE = existingPE as TagsPropertiesPathElement;
            TagsPropertiesPathElement newTagsPropsElement = newPE as TagsPropertiesPathElement;

            // if the resource ids are equal a only one is a tags and properties 
            // then this is not a duplicate, tags and properties 
            // and the controller have the same resourceID
            if (ResourceBase.IsEqual(existingPE.ResourceId, newPE.ResourceId) && !(tagsPropsPE != null ^ newTagsPropsElement != null))
                isDuplicate = true;

            return isDuplicate;
        }
        
        override public string CurrentPathStringFor(List<IPathElement> tempList)
        {
            return Path.PathToString(tempList, null, IsTagBrowser ? DIBViewItemBase.VisualPerspectiveEnum.TagBrowser : DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser);
        }

        override protected void UpdatePropertiesOnDataItemBaseIfNeeded()
        {
            // Do nothing here. We already have everything we need on the DataItemBase instance
            // because they where created in QSP. 
        }

        /// <summary>
        /// Assign custom IComparer instances for columns that are 
        /// unique to ViewE
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns>IComparer that should be used for the provided column name</returns>
        protected override IComparer GetComparerForColumn(String columnName)
        {
            if (columnName.Equals(DIBConstants.Common.Name))
            {
                return NameWithDimsComparer.Instance;
            }
            else if (columnName.Equals(DIBConstants.Common.DataType))
            {
                return NameWithDimsComparer.Instance;
            }

            return base.GetComparerForColumn(columnName);
        }

        #endregion
      
    }
}
