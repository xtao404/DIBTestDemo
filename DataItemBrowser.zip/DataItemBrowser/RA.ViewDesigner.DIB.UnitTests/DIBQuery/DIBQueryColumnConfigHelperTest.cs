/*************************************************************************************
                                                                     
   ViewE DIBQueryColumnManagerTest Class
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.DIBQuery;
using System;
using RockwellAutomation.UI.WindowsControl.DIBClient;

#endregion

namespace DataItemBrowserUT
{

    /// <summary>
    /// Summary description for DIBQueryColumnManagerTest
    /// </summary>
    [TestClass]
    public class DIBQueryColumnConfigHelperTest
    {
        DIBClientManager dibClientManager = null;
        #region static members

        private static DIBQueryColumnConfigHelper target = null;
        private static TSObservableCollection<DataItemBase> DataItems = new TSObservableCollection<DataItemBase>();

        #endregion

        #region Additional test attributes

        /// <summary>
        /// Use TestInitialize to run code before running each test 
        /// </summary>
        [TestInitialize()]
        public void DIBQueryColumnConfigHelperTestInit()
        {
            dibClientManager = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, 
                DIBQueryCommandTest.SamplePackageContextUUID, DIBQueryCommandTest.SampleProjectContextUUID);

            ClearLocale();
        }

        /// <summary>
        /// Use TestCleanup to run code after each test has run
        /// </summary>
        [TestCleanup()]
        public void DIBQueryColumnConfigHelperTestCleanup()
        {
            dibClientManager.Shutdown();
            dibClientManager = null;
            ClearLocale();
        }

        private static void SetLocale(string localeString)
        {
            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = new System.Globalization.CultureInfo(localeString);
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = new System.Globalization.CultureInfo(localeString);
        }
        private static void ClearLocale()
        {
            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = null;
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = null;
        }

        #endregion

        public DIBQueryColumnConfigHelperTest()
        {
          
        }

        #region ColumnConfigMap - mapping of which columns are applicable for each resource type
        /// <summary>
        /// Loads the mapping of which columns are applicable for each resource type
        /// into the ResourceTypeToColumnConfigMap dictionary
        /// NOTE: more tests could be added for each individual field for each resource type.  Currently
        /// only checking for column names.
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_ColumnConfigMap()
        {

            target = new DIBQueryColumnConfigHelper();
            target.LoadUserAndColumnConfigData(dibClientManager);

            Assert.IsTrue(target.ResourceTypeToColumnConfigMap.Count == 14, "Number of elements in resourceTypeToColumnConfigMap is not 14. Count = " + target.ResourceTypeToColumnConfigMap.Count);
            foreach (KeyValuePair<string, Dictionary<string, ColumnConfigMapItem.CreateBuilder>> pair in target.ResourceTypeToColumnConfigMap)
            {
                String keyString = pair.Key;
                if (keyString.Equals("none"))
                    ValidateColumnConfigForResourceType_none(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER))
                    ValidateColumnConfigForResourceType_controller(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_TAG))
                    ValidateColumnConfigForResourceType_tag(pair.Value);
                else if (keyString.Equals("searchtags"))
                    ValidateColumnConfigForResourceType_searchtag(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_DATATYPE))
                    ValidateColumnConfigForResourceType_datatype(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_PROGRAM))
                    ValidateColumnConfigForResourceType_program(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGS))
                    ValidateColumnConfigForResourceType_controllertags(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_DATATYPEMEMBER))
                    ValidateColumnConfigForResourceType_datatypemember(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE))
                    ValidateColumnConfigForResourceType_controller(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS))
                    ValidateColumnConfigForResourceType_controller(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_DATALOGS))
                    ValidateColumnConfigForResourceType_datalogs(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_DTB_NONE))
                    ValidateColumnConfigForResourceType_dtbnone(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW))
                    ValidateColumnConfigForResourceType_GenericDIB(pair.Value);
                else if (keyString.Equals(DIResource.DI_COMMON_RESOURCETYPE_AOGS))
                    ValidateColumnConfigForResourceType_AOGS(pair.Value);
                else
                    Assert.IsTrue(false, "Unexpected level = " + pair.Key);
            }
         }

        private void ValidateColumnConfigForResourceType_AOGS(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 3, "'AOGS resourcetype' should have 3 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name:
                        break;
                    case DIBConstants.Common.Description:
                        break;
                    case DIBConstants.Common.DataType:
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }

        private void ValidateColumnConfigForResourceType_GenericDIB(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 3, "'GenericDIB resourcetype' should have 3 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    case DIBConstants.Common.Description: 
                        break;
                    case DIBConstants.Common.DataType: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }

        private void ValidateColumnConfigForResourceType_dtbnone(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 1, "'dtbnone resourcetype' should have 1 column. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }

        private void ValidateColumnConfigForResourceType_none(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 3, "'none resourcetype' should have 3 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    case DIBConstantsViewe.ReplicationState: 
                        break;
                    case DIBConstantsViewe.ReplicationErrorMessage: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
           }
        }

        // Test for controller, programs, and HMI Device
        private void ValidateColumnConfigForResourceType_controller(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 2, "'controller resourcetype' should have 2 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    case DIBConstants.Common.Description: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }


        // Test for datalogs
        private void ValidateColumnConfigForResourceType_datalogs(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 1, "'datalogs resourcetype' should have 1 column. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }

        private void ValidateColumnConfigForResourceType_searchtag(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 4, "'searchtags resourcetype' should have 4 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                ColumnConfigMapItem currentCol = column.Value.Build();
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    case DIBConstants.Common.Location: 
                        Assert.IsTrue(currentCol.GetFieldItems.Count == 1);
                        Assert.IsTrue(currentCol.GetFieldItems[0].GetFieldType == FieldType.Property);
                        Assert.IsTrue(currentCol.GetFieldItems[0].GetTransformationPattern == @"::[a-z][\w]*([\\:][a-z][\w]*){0,1}");
                        Assert.IsTrue(currentCol.GetFieldItems[0].GetField == DIBConstants.Common.AbsoluteName);
                        Assert.IsTrue(currentCol.GetFieldItems[0].GetAlternateField == null);
                        break;
                    case DIBConstants.Common.Description: 
                        break;
                    case DIBConstants.Common.DataType: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }
        private void ValidateColumnConfigForResourceType_tag(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 3, "'tag resourcetype' should have 3 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name:
                        break;
                    case DIBConstants.Common.Description: 
                        break;
                    case DIBConstants.Common.DataType: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }

        private void ValidateColumnConfigForResourceType_datatype(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 3, "'datatype resourcetype' should have 3 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                ColumnConfigMapItem currentCol = column.Value.Build();
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    case DIBConstants.Common.Description: 
                        break;
                    case DIBConstants.Common.Location: 
                        Assert.IsTrue(currentCol.GetFieldItems.Count == 1);
                        Assert.IsTrue(currentCol.GetFieldItems[0].GetTransformationPattern == @"::[a-z][\w]*([\\:][a-z][\w]*){0,1}");
                        Assert.IsTrue(currentCol.GetFieldItems[0].GetField == DIBConstants.Common.AbsoluteName);
                        Assert.IsTrue(currentCol.GetFieldItems[0].GetAlternateField == null);
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }

        private void ValidateColumnConfigForResourceType_program(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 3, "'program resourcetype' should have 3 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    case DIBConstants.Common.Description: 
                        break;
                    case DIBConstants.Common.DataType: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }

        private void ValidateColumnConfigForResourceType_controllertags(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 3, "'controllertags resourcetype' should have 3 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    case DIBConstants.Common.Description: 
                        break;
                    case DIBConstants.Common.DataType:
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }

        private void ValidateColumnConfigForResourceType_datatypemember(Dictionary<string, ColumnConfigMapItem.CreateBuilder> resourceTypeColumns)
        {
            Assert.IsTrue(resourceTypeColumns.Count == 3, "'datatypemember resourcetype' should have 4 columns. Count = " + resourceTypeColumns.Count);
            foreach (KeyValuePair<string, ColumnConfigMapItem.CreateBuilder> column in resourceTypeColumns)
            {
                switch (column.Key)
                {
                    case DIBConstants.Common.Name: 
                        break;
                    case DIBConstants.Common.Description: 
                        break;
                    case DIBConstants.Common.DataType: 
                        break;
                    default:
                        Assert.IsTrue(false, "Unexpected column = " + column.Key);
                        break;
                }
            }
        }
        #endregion ColumnConfigMap

        #region Columns
        /// <summary>
        /// Validate that the correct columns are returned given various configurations
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_getColumnsTest()
        {
            List<ColumnConfigMapItem> columnsConfigured = null;
            //call to set up the column config information 
            target = new DIBQueryColumnConfigHelper();
            target.LoadUserAndColumnConfigData(this.dibClientManager);

            IDIBDataViewType targetDataView = new DIBDataViewTypeDataType();
            PrivateObject privateTarget = new PrivateObject(target);
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_DATATYPE]);
            
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.Location);
            Assert.IsTrue(columnsConfigured[1].GetTitle == DIBConstants.Common.Location);
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == DIBConstants.Common.Description);

            targetDataView = new DIBDataViewTypeUnknown();
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 0);

            targetDataView = new DIBDataViewTypeListView();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER]);            
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 2);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[1].GetTitle == DIBConstants.Common.Description);

            targetDataView = new DIBDataViewTypeDataGrid();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGS]);            
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[1].GetTitle == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == DIBConstants.Common.Description);

            targetDataView = new DIBDataViewTypeSearchGrid();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_TAG]);           
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[1].GetTitle == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == DIBConstants.Common.Description);

            targetDataView = new DIBDataViewTypeHMIDevice();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE]);                       
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 2);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[1].GetTitle == DIBConstants.Common.Description);

            targetDataView = new DIBDataViewTypeProgramsGrid();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_PROGRAM]);                                   
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[1].GetTitle == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == DIBConstants.Common.Description);

            targetDataView = new DIBDataViewTypeDataLogsGrid();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_DATALOGS]);                 
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 1);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == DIBConstants.Common.Name);

            targetDataView = new DIBDataViewTypeDataType();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_DATATYPEMEMBER]);                             
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[1].GetTitle == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == DIBConstants.Common.Description);
        }


        /// <summary>
        /// Validate that the correct columns are returned given various configurations and locale settings
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_getColumnsWithLocaleTest_French()
        {
            SetLocale("fr");

            List<ColumnConfigMapItem> columnsConfigured = null;
            //call to set up the column config information 
            target = new DIBQueryColumnConfigHelper();
            target.LoadUserAndColumnConfigData(this.dibClientManager);

            IDIBDataViewType targetDataView = new DIBDataViewTypeDataType();
            PrivateObject privateTarget = new PrivateObject(target);
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_DATATYPE]);

            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == "Nom");
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.Location);
            Assert.IsTrue(columnsConfigured[1].GetTitle == "Emplacement");
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == "Description");

            targetDataView = new DIBDataViewTypeUnknown();
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 0);

            targetDataView = new DIBDataViewTypeListView();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER]);
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 2);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == "Nom");
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[1].GetTitle == "Description");

            targetDataView = new DIBDataViewTypeDataGrid();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGS]);
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == "Nom");
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[1].GetTitle == "Type de donn�es");
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == "Description");

            targetDataView = new DIBDataViewTypeSearchGrid();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_TAG]);
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == "Nom");
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[1].GetTitle == "Type de donn�es");
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == "Description");

            targetDataView = new DIBDataViewTypeHMIDevice();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE]);
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 2);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == "Nom");
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[1].GetTitle == "Description");

            targetDataView = new DIBDataViewTypeProgramsGrid();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_PROGRAM]);
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == "Nom");
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[1].GetTitle == "Type de donn�es");
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == "Description");

            targetDataView = new DIBDataViewTypeDataLogsGrid();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_DATALOGS]);
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 1);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == "Nom");

            targetDataView = new DIBDataViewTypeDataType();
            privateTarget.SetProperty("_columns", target.ResourceTypeToColumnConfigMap[DIResource.DI_COMMON_RESOURCETYPE_DATATYPEMEMBER]);
            columnsConfigured = target.Columns(targetDataView);
            Assert.IsTrue(columnsConfigured.Count == 3);
            Assert.IsTrue(columnsConfigured[0].GetColumn == DIBConstants.Common.Name);
            Assert.IsTrue(columnsConfigured[0].GetTitle == "Nom");
            Assert.IsTrue(columnsConfigured[1].GetColumn == DIBConstants.Common.DataType);
            Assert.IsTrue(columnsConfigured[1].GetTitle == "Type de donn�es");
            Assert.IsTrue(columnsConfigured[2].GetColumn == DIBConstants.Common.Description);
            Assert.IsTrue(columnsConfigured[2].GetTitle == "Description");
        }

        #endregion Columns

        #region GetUserConfigPrefix
        /// <summary>
        /// Verifies the correct prefix is returned for the DataViewType
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_GetUserConfigPrefixTest()
        {
            IDIBDataViewType targetDataView = new DIBDataViewTypeDataType();
            Assert.IsTrue("dt_" == targetDataView.GetUserConfigPrefix());

            targetDataView = new DIBDataViewTypeSearchGrid();
            Assert.IsTrue("sv_" == targetDataView.GetUserConfigPrefix());

            targetDataView = new DIBDataViewTypeProgramsGrid();
            Assert.IsTrue("programs_view_" == targetDataView.GetUserConfigPrefix());

            targetDataView = new DIBDataViewTypeDataLogsGrid();
            Assert.IsTrue("datalogs_view_" == targetDataView.GetUserConfigPrefix());

            targetDataView = new DIBDataViewTypeUnknown();
            Assert.IsTrue("cmn_" == targetDataView.GetUserConfigPrefix());

            targetDataView = new DIBDataViewTypeTreeView();
            Assert.IsTrue("cmn_" == targetDataView.GetUserConfigPrefix());

            targetDataView = new DIBDataViewTypeListView();
            Assert.IsTrue("cmn_" == targetDataView.GetUserConfigPrefix());

            targetDataView = new DIBDataViewTypeHMIDevice();
            Assert.IsTrue("cmn_" == targetDataView.GetUserConfigPrefix());

            targetDataView = new DIBDataViewTypeDataGrid();
            Assert.IsTrue("cmn_" == targetDataView.GetUserConfigPrefix());
        }
        #endregion GetUserConfigPrefix

    }
}
