﻿// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.
//
// To add a suppression to this file, right-click the message in the 
// Error List, point to "Suppress Message(s)", and click 
// "In Project Suppression File".
// You do not need to add suppressions to this file manually.

//Cyclomatic complexity will be dealt with in the future
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Scope = "member", Target = "RockwellAutomation.UI.CommonControls.SearchFilterParser.#ValidateTokenSyntax()")]

//Modifications to address this design cause crashes when running the coded ui test so we will keep until investigation on this occurs
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Rockwell.Design", "RA0006:ClassThatImplementsDisposeShouldAlsoImplementFinalizer", Scope = "type", Target = "RockwellAutomation.UI.CommonControls.SearchFilterRichTextBox")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA2210:AssembliesShouldHaveValidStrongNames", Justification = "Code will be signed in released builds")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1703:ResourceStringsShouldBeSpelledCorrectly", MessageId = "Logix", Scope = "resource", Target = "RockwellAutomation.UI.CommonControls.Properties.Resources.resources")]
