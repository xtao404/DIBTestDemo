﻿using RockwellAutomation.UI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.UI;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for DataItemBrowserContextTest and is intended
    ///to contain all DataItemBrowserContextTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DataItemBrowserContextTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        ///// <summary>
        ///// Use TestInitialize to run code before running each test
        ///// </summary>
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        ///// <summary>
        ///// Use TestCleanup to run code after each test has run
        ///// </summary>
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        
        #endregion

        /// <summary>
        /// Verifies that there is a ToString method and it writes out all the variables
        /// this test will fail if it is removed or contents are changed. 
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_StringTest()
        {
            
            string rootPath = "::MixingRoom";
            string include = "::MixingRoom\\MainProgram";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenFromRoot()
                                                                                      .Include(include)
                                                                                      .Build();
            string logMessage = target.ToString();
            
            //verify all the variables are in the string            
            Assert.IsTrue(logMessage.Contains("RootPath"));
            Assert.IsTrue(logMessage.Contains("RootNavIntoFolder"));
            Assert.IsTrue(logMessage.Contains("ExcludeAllChildrenFromRoot"));
            Assert.IsTrue(logMessage.Contains("ExcludeAllChildrenFromPath"));
            Assert.IsTrue(logMessage.Contains("ExcludeAllChildrenOfType"));
            Assert.IsTrue(logMessage.Contains("ExcludeAllOfType"));
            Assert.IsTrue(logMessage.Contains("IncludeAllOfType"));
            Assert.IsTrue(logMessage.Contains("SyntaxWarnings"));
            Assert.IsTrue(logMessage.Contains("FilterDefinition"));
            //verify the values
            Assert.IsTrue(logMessage.Contains(rootPath.Remove(0,2)));
            string[] pathItems = ParseTestPath(include);              
            Assert.IsTrue(logMessage.Contains(pathItems[1]));
            
        }
        
        #region "Tests without rootPath set"        

        //***ALREADY TESTED??? PATH IS NEVER REACHED.
        ///// <summary>
        /////Input: ExcludeAllChildrenFromRoot, NO rootPath
        ///// Expected Results: set ExcludeAllChildrenFromRoot false, syntax error
        /////</summary>
        //[TestMethod()]
        //[DeploymentItem("RA.Common.DIB.dll")]
        //public void DataItemBrowserContext_ExcludeAllChildrenFromRootNoRootPath_ExcludeAllChildrenFromRootSetFalseTest()
        //{            
         
        //    DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFromRoot()
        //                                                                              .Build();

        //    Assert.IsFalse(target.ExcludeAllChildrenFromRoot,"ExcludeAllChildrenFromRoot should be set false");            
        //    Assert.IsTrue(target.SyntaxWarnings.Count>0,"Should have a syntax error");
        //}

       
        //***ALREADY TESTED??? PATH IS NEVER REACHED.
        ///// <summary>
        /////Input: ExcludeAllChildrenFromRoot, rootPath not part of include, includePath 
        ///// Expected Results: set ExcludeAllChildrenFromRoot false, syntax error, clear include
        /////</summary>
        //[TestMethod()]
        //[DeploymentItem("RA.Common.DIB.dll")]
        //public void DataItemBrowserContext_ExcludeAllChildrenFromRootRootPathInclude_ExcludeAllChildrenFromRootSetFalseTest()
        //{
        //    string rootPath = "::MixingRoom";

        //    DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFromRoot()
        //                                                                               .Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
        //                                                                              .Build();

        //    Assert.IsFalse(target.ExcludeAllChildrenFromRoot, "ExcludeAllChildrenFromRoot should be set false");
        //    Assert.IsTrue(target.SyntaxWarnings.Count > 0, "Should have a syntax error");
        //    Assert.IsTrue(target.IncludePath.Count==0,"Include path should have been cleared");
        //}

        /// <summary>
        ///A test for empty Builder
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_buildWithoutAnyOptionsSet()
        {
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Build();
            Assert.IsNotNull(target);

        }

        /// <summary>
        ///A test for ExcludeAllChildrenFromPath controller
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ExcludeAllChildrenFromPath_ControllerTest()
        {
            //no root, exclude controller
            string exclude = "::MixingRoom";
            string include = "::MixingRoom\\MainProgram";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFrom(exclude)
                                                                                      .Include(include)
                                                                                      .Build();
            string[] pathItems = ParseTestPath(exclude);         
            
            Assert.AreEqual(pathItems[0], target.ExcludeAllChildrenFromPath[0],"ExcludeAllChildrenFromPath was not parse correctly");
           
        }

        /// <summary>
        ///A test for ExcludeAllChildrenFromPath program
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ExcludeAllChildrenFromPath_programWarningTest()
        {
            //no root, exclude program
            string exclude = "::MixingRoom\\Program";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFrom(exclude)
                                                                                      .Build();

                        
            Assert.AreEqual(1, target.SyntaxWarnings.Count, "only one warning");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenFrom removed,"), "ExcludeAllChildrenFromPath warning mismatch");
            Assert.AreEqual(0,target.ExcludeAllChildrenFromPath.Count, "ExcludeAllChildrenFrom not cleared");
           
        }
        /// <summary>
        ///A test for ExcludeAllChildrenFromPath too much
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ExcludeAllChildrenFromPath_tooMuchTest()
        {
            //no root, exclude tag
            string exclude = "::MixingRoom.TagA";
            string include = "::MixingRoom\\MainProgram";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFrom(exclude)
                                                                                      .Include(include)
                                                                                      .Build();
            string[] pathItems = ParseTestPath(exclude);
            
            //the tag part of the path is lost
            Assert.AreEqual(pathItems[0], target.ExcludeAllChildrenFromPath[0],"ExcludeAllChildrenFromPath controller mismatch");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenFrom,"), "ExcludeAllChildrenFromPath warning mismatch");
            Assert.AreEqual(1, target.SyntaxWarnings.Count, "Only 1 warning");
           
        }

        /// <summary>
        ///A test for IncludePath controller
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_IncludePath_ControllerTest()
        {
            //no root, include controller
            string include = "::MixingRoom\\MainProgram";
            string exclude = "::MixingRoom";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Include(include)
                                                                                      .ExcludeAllChildrenFrom(exclude)
                                                                                      .Build();
            string[] pathItems = ParseTestPath(include);

            Assert.AreEqual(pathItems[0], target.IncludePath[0], "IncludePath was not parse correctly");

        }

        /// <summary>
        ///A test for IncludePath program
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_InlcudePath_programTest()
        {
            //no root, include program
            string include = "::MixingRoom\\Program";
            string exclude = "::MixingRoom";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Include(include)
                                                                                      .ExcludeAllChildrenFrom(exclude)
                                                                                      .Build();

            string[] pathItems = ParseTestPath(include);

            Assert.AreEqual(pathItems[0], target.IncludePath[0], "IncludePath controller mismatch");
            Assert.AreEqual(pathItems[1], target.IncludePath[2], "IncludePath program mismatch");

        }
        /// <summary>
        ///A test for IncludePath too much
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_IncludePath_tooMuchTest()
        {
            //no root, include tag
            string exclude = "::MixingRoom";
            string include = "::MixingRoom\\MainProgram.TagA";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFrom(exclude)
                                                                                      .Include(include)
                                                                                      .Build(); 
            
            string[] pathItems = ParseTestPath(include);

            //the tag part of the path is lost
            Assert.AreEqual(pathItems[0], target.IncludePath[0], "IncludePath controller mismatch");
            Assert.AreEqual(pathItems[1], target.IncludePath[2], "IncludePath program mismatch");

        }

        /// <summary>
        ///Input: ExcludeAllChildrenFromRoot
        /// ExpectedActions: ExcludeAllChildrenFromRoot set to false, sytax warning
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_NoRootExcludeAllChildrenFromPath_SyntaxWarningTest()
        {
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFromRoot()
                                                                                      .Build(); 
            
            Assert.IsFalse(target.ExcludeAllChildrenFromRoot,"ExcludeAllChildrenFromRoot should be set to false");
        }
        #endregion "Tests without rootPath set"

        #region "Tests that contain a rootPath"

        /// <summary>
        ///Input: ExcludeAllChildrenFromRoot, rootPath, NO includePath
        /// Expected Results: set ExcludeAllChildrenFromPath false, syntax error
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ExcludeAllChildrenFromRootRootPathNoInclude_ExcludeAllChildrenFromRootSetFalseTest()
        {
            string rootPath = "::MixingRoom";

            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFromRoot()
                                                                                       .Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .Build();

            Assert.IsFalse(target.ExcludeAllChildrenFromRoot, "ExcludeAllChildrenFromRoot should be set false");
            Assert.IsTrue(target.SyntaxWarnings.Count > 0, "Should have a syntax error");
        }

        /// <summary>
        ///Input: ExcludeAllChildrenFromPath, rootPath, includePath doesn't contain exclude
        /// Expected Results: set ExcludeAllChildrenFromRootPath clear, include clear, syntax error
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ExcludeAllChildrenFromRootPathRootPathInclude_ExcludeAllChildrenFromRootPathClearTest()
        {
            string rootPath = "::MixingRoom";
            string exclude = "::MixingRoom\\Program1";
            string include = "::MixingRoom"; 
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                       .ExcludeAllChildrenFrom(exclude)
                                                                                       .Include(include)
                                                                                      .Build();

            Assert.IsTrue(target.ExcludeAllChildrenFromPath.Count == 0, "ExcludeAllChildrenFromPath should be cleared");
            Assert.IsTrue(target.IncludePath.Count == 0, "IncludePath should be cleared");
            Assert.IsTrue(target.SyntaxWarnings.Count > 0, "Should have a syntax error");
        }

        /// <summary>
        /// cannot have ExcludeAllChildrenFromRoot and ExcludeAllChildrenFromPath set at same time
        /// Input: rootPath,ExcludeAllChildrenFromRoot,ExcludeAllChildrenFromPath
        /// Expected Result: ExcludeAllChildrenFromRoot set to false, syntax warning
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_RootPathExcludeAllChildrenFromRootExcludeAllChildrenFromPath_SetExcludeAllChildrenFromRootFalseTest()
        {
            //controller path, no folder nav
            string rootPath = "::MixingRoom";
            string exclude = "::MixingRoom";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenFromRoot()
                                                                                      .ExcludeAllChildrenFrom(exclude)
                                                                                      .Build();

            Assert.IsFalse(target.ExcludeAllChildrenFromRoot,"ExcludeAllChildren from root should be false");
            Assert.IsTrue(target.SyntaxWarnings.Count>0,"Should have syntax warning");

        }

        /// <summary>
        ///A test for RootPath controller
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_RootPath_ControllerTest()
        {
            //controller path, no folder nav
            string rootPath = "::MixingRoom";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath,DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .Build();
            string[] pathItems = ParseTestPath(rootPath);

            Assert.AreEqual(pathItems[0], target.RootPath[0], "RootPath did not parse correctly");

        }

        /// <summary>
        ///A test for RootPath program
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_RootPath_programTest()
        {
            //program path, no folder nav
            string rootPath = "::MixingRoom\\Program";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath,DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .Build();

            string[] pathItems = ParseTestPath(rootPath);

            Assert.AreEqual(pathItems[0], target.RootPath[0], "RootPath controller mismatch");
            Assert.AreEqual(pathItems[1], target.RootPath[2], "RootPath program mismatch");

        }

        /// <summary>
        ///A test for RootPath program with the controller name being "Programs"
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_RootPath_programTest_WithContollerNameasPRORAMS()
        {
            //program path, no folder nav
            string rootPath = "::Programs\\Program1";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .Build();

            string[] pathItems = ParseTestPath(rootPath);

            Assert.AreEqual(pathItems[0], target.RootPath[0], "RootPath controller mismatch");
            Assert.AreNotEqual(pathItems[0], target.RootPath[1], "Controller name and Programs folder key should not be the same string");
            Assert.IsTrue(target.RootPath[0] == "Programs"); // The actual name of the controller is "Programs"
            Assert.AreEqual(target.RootPath[1], DataContext.PROGRAMSFOLDERKEY, "Programs folder key");

            Assert.AreEqual(pathItems[1], target.RootPath[2], "RootPath program mismatch");

        }

        /// <summary>
        ///A test for RootPath too much
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_RootPath_tooMuchTest()
        {
            //program path, no folder nav
            string rootPath = "::MixingRoom\\Program.TagA";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath,DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .Build();
             string[] pathItems = ParseTestPath(rootPath);

            //the tag part of the path is lost
            Assert.AreEqual(pathItems[0], target.RootPath[0], "RootPath controller mismatch");
            Assert.AreEqual(pathItems[1], target.RootPath[2], "RootPath program mismatch");

        }
        /// <summary>
        ///A test for ExcludeAllChildrenFromRoot
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ExcludeAllChildrenFromRootTest()
        {
             //controller path, no folder nav
            string rootPath = "::MixingRoom";
            string include = "::MixingRoom\\MainProgram";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath,DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                .ExcludeAllChildrenFromRoot()
                                                                                .Include(include)
                                                                               .Build();
           
            Assert.IsTrue(target.ExcludeAllChildrenFromRoot, "ExcludeAllChildrenFromRoot not set");
        }

       

        /// <summary>
        ///A test for RootNavIntoFolder
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserContext_RootNavIntoFolderTest()
        {
            //controller path, nav into tags and props
            string roothPath = "::MixingRoom";            
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(roothPath, DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps)                                                                                      
                                                                                      .Build();


            Assert.AreEqual(DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps, target.RootNavIntoFolder, "RootNavIntoFolder was not set correctly");
        }

        /// <summary>
        /// Inputs:RootPath, NavIntoTagsAndProps, IncludePath
        /// Expected Actions: Include Path is cleared and there is a warning
        /// </summary>
        [TestMethod()]
        public void DataItemBrowserContext_RootPathNavIntoTagsAndPropsInclude_SyntaxWarningTest()
        {
            //controller path, nav into tags and props
            string roothPath = "::MixingRoom";
            string include = "::MixingRoom\\MainProgram";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(roothPath, DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps)
                                                                                      .Include(include)
                                                                                      .Build();

            Assert.AreEqual(DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps, target.RootNavIntoFolder, "RootNavIntoFolder was not set correctly");
            Assert.IsTrue(target.IncludePath.Count==0,"IncludePath should have been cleared");
            Assert.IsTrue(target.SyntaxWarnings.Count>0);
        }

        #endregion "Tests that contain a rootPath"

        #region "Tests with Filter"
        
        /// <summary>
        ///A test for warning add filter 
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_AddFilter()
        {
            //add filter
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().AddFilter("datatype", "DINT", false)
                                                                                     .Build();


            Assert.AreEqual(0, target.SyntaxWarnings.Count, "There should be no warnings.");
            Assert.AreEqual(0,string.Compare(target.FilterDefinition.SearchString.Trim(),"datatype:DINT"),"Filter string is not valid");

        }
        /// <summary>
        ///A test for warning add filter 
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_AddFilterExactMatch()
        {
            //add filter
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().AddFilter("datatype", "DINT", true)
                                                                                     .Build();


            Assert.AreEqual(0, target.SyntaxWarnings.Count, "There should be no warnings.");
            Assert.AreEqual(0, string.Compare(target.FilterDefinition.SearchString.Trim(), "datatype:\"DINT\""), "Filter string is not valid");

        }
        
         /// <summary>
        ///A test for Root and ExcludeAllChildrenOfType, IncludeAllOfType
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_Root_ExcludeAllOfType_IncludeAllOfType()
        {
            //add filter
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root("::Controller1",DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .IncludeAllOfType(DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();


             Assert.AreEqual(0, target.SyntaxWarnings.Count, "There should be no warnings.");
             Assert.AreEqual(1, target.RootPath.Count,"Root path has just a controller");
             Assert.AreEqual(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller, target.ExcludeAllChildrenOfType,"exclude all children of type controller");
             Assert.AreEqual(DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs, target.IncludeAllOfType,"include all of type datalogs");

        }

        #endregion "Tests with Filter"

        /// <summary>
        ///A test warning program cannot have  includes
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ProgramNoIncludes()
        {
             
            //program path, no nav into folders
            string strPath = "::MixingRoom\\Program";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(strPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .Include(strPath)
                                                                                      .Build();
       
             Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(0,target.IncludePath.Count , "IncludePath not cleared");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("Include removed,"), "Include warning mismatch");

        }
     
        /// <summary>
        ///A test for warning program cannot have excludes
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ProgramNoExcludes()
        {
            //program path, no nav into folder
            string strPath = "::MixingRoom\\Program";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(strPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenFrom(strPath)
                                                                                      .Build();
       
            Assert.AreEqual(1,target.SyntaxWarnings.Count,  "There should only be one warning.");
            Assert.AreEqual(0, target.ExcludeAllChildrenFromPath.Count , "ExcludeAllChildrenFromPath not cleared");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenFrom cleared,"), "Exclude warning mismatch");

        }

         /// <summary>
        ///A test for warning program cannot have root excludes
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ProgramNoRootExcludes()
        {
            //program path, no nav into folder
             string strPath = "::MixingRoom\\Program";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(strPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenFromRoot()
                                                                                      .Build();
       
         
            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsFalse(target.ExcludeAllChildrenFromRoot, "ExcludeAllChildrenFromRoot not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenFromRoot reset,"), "Exclude warning mismatch");

        }
        /// <summary>
        ///A test for warning no root no excludes
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_NoRootNoExcludes()
        {
            //default root, nav into tags and props
            string strPath = "";
            string include = "::MixingRoom\\MainProgram";
            string exclude = "::MixingRoom\\";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(strPath, DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps)
                                                                                      .ExcludeAllChildrenFrom(exclude)
                                                                                      .Include(include)
                                                                                      .Build();


            Assert.AreEqual(1,target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsFalse(target.ExcludeAllChildrenFromRoot, "ExcludeAllChildrenFromRoot not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("RootNavIntoFolder reset,"), "NavigateIntoFolder warning mismatch");
  
        }

      
        /// <summary>
        ///A test for warning program cannot navigate into folder
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ProgramNoNavigateIntoFolder()
        {
            //program path, nav into tags and props 
            string strPath = "::MixingRoom\\Program";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(strPath, DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(DataItemBrowserContext.NavToFolderEnum.Nav_NoAction, target.RootNavIntoFolder, "RootNavIntoFolder not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("NavigateIntoFolder cleared,"), "NavigateIntoFolder warning mismatch");
 
        }

        /// <summary>
        ///A test for warning not root no navigate into folder
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_NoRootNoNavigateIntoFolder()
        {
            //default root, no nav into folder
            string strPath = "";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(strPath, DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps)
                                                                                      .Build();
       
         
            Assert.AreEqual(1,target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(DataItemBrowserContext.NavToFolderEnum.Nav_NoAction,target.RootNavIntoFolder, "RootNavIntoFolder not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("RootNavIntoFolder reset,"), "ExcludeAllChildrenFromRoot warning mismatch");

        }

        /// <summary>
        ///A test for warning include not in root path
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_IncludeNotInRoot()
        {
            //controller path, no nav into folder
             string rootPath = "::MixingRoom";
             string include = "::BogusPath";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .Include(include)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(0,target.IncludePath.Count, "IncludePath not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("Include removed,"), "Includes warning mismatch");

        }

        /// <summary>
        ///A test for warning exclude not in root path
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ExcludesNotInRoot()
        {
            //controller path, no nav into folder
            string rootPath = "::MixingRoom";
            string exclude = "::BogusPath";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenFrom(exclude)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(0,target.ExcludeAllChildrenFromPath.Count, "ExcludePath not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenFrom removed,"), "Excludes warning mismatch");

        }

        /// <summary>
        ///A test for warning exclude not in include path
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ExcludeNotInInclude()
        {
            //controller path, no nav into folder
            string rootPath = "::MixingRoom";
            string exclude = "::BogusPath";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(rootPath, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenFrom(exclude)
                                                                                      .Build();


            Assert.AreEqual(1,target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(0,target.ExcludeAllChildrenFromPath.Count,  "IncludePath not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenFrom removed,"), "ExcludeAllChildrenFromPath warning mismatch");

        }

        /// <summary>
        ///A test for warning exclude and no include path
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ExcludeNoIInclude()
        {
            //exclude controll path
            string exclude = "::MixingRoom";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFrom(exclude)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(0, target.ExcludeAllChildrenFromPath.Count, "ExcludeAllChildrenFrom not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenFrom removed,"), "ExcludeAllChildrenFromPath warning mismatch");

        }

        /// <summary>
        ///A test for warning include with program root
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_NotIncludeForProgramRoot()
        {
            //exclude controll path
            string root = "::MixingRoom\\MainProgram";
            string include = "::MixingRoom\\MainProgram";
            string exclude = "::MixingRoom\\MainProgram";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(root,DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                        .Include(include)
                                                                                        .ExcludeAllChildrenFrom(exclude)
                                                                                      .Build();

            //there will be an include removed followed by an exclude remove
            Assert.AreEqual(2, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(0, target.ExcludeAllChildrenFromPath.Count, "IncludePath not reset");
            Assert.AreEqual(0, target.IncludePath.Count, "IncludePath not reset");
           Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("Include removed,"), "IncludePath warning mismatch");
            Assert.IsTrue(target.SyntaxWarnings[1].StartsWith("ExcludeAllChildrenFrom cleared,"), "IncludePath warning mismatch");

        }

      

         /// <summary>
        ///A test for warning cannot have include without an exclude
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_NoIncludeWithoutExcludes()
        {
            //exclude controll path
            string root = "::MixingRoom";
            string include = "::MixingRoom\\MainProgram";
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root(root,DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .Include(include)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.AreEqual(0, target.ExcludeAllChildrenFromPath.Count, "IncludePath not reset");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("Include removed,"), "Remove excludes warning mismatch");

        }

        /// <summary>
        ///A test for warning invalid filter type
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_AddFilterInvalidFilterType()
        {
            //add filter
             DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().AddFilter("qq","rr",true)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsTrue(string.IsNullOrEmpty(target.FilterDefinition.SearchString), "There should be no search string");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("Filter removed, filter name"), "Filter name invalid warning");

        }
        /// <summary>
        ///A test for warning invalid filter type
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_AddFilterNoFilterValue()
        {
            //add filter
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().AddFilter("datatype", "", true)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsTrue(string.IsNullOrEmpty(target.FilterDefinition.SearchString), "There should be no search string");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("Filter removed, filter value"), "Filter value warning missing");

        }

        /// <summary>
        ///A test for IncludeAllOfType Without ExcludeAllChildrenOfType
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_IncludeAllOfTypeWithoutExcludeAllChildrenOfType()
        {
            //include all of type datalogs
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().IncludeAllOfType(DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("IncludeAllOfType removed, IncludeAllOfType"), "incorrect warning");

        }

        /// <summary>
        ///A test for ExcludeAllOfType With ExcludeAllChildrenOfType or IncludeAllOfType missing 1
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ExcludeAllOfTypeWithoutExcludeAllChildrenOfTypeOrIncludeAllOfTypeMissing1()
        {
            //include all of type datalogs, exclude all of type HMI Device
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().IncludeAllOfType(DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs)
                                                                                      .ExcludeAllOfType(DataItemBrowserContext.ExcludeAllOfTypeEnum.HMIDevice)
                                                                                       .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("IncludeAllOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType."), "incorrect warning");

        }

        /// <summary>
        ///A test for ExcludeAllOfType With ExcludeAllChildrenOfType or IncludeAllOfType missing 2
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ExcludeAllOfTypeWithoutExcludeAllChildrenOfTypeOrIncludeAllOfTypeMissing2()
        {
            //exclude all children of type controller, exclude all of type datalogs
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .ExcludeAllOfType(DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType."), "incorrect warning");

        }

        /// <summary>
        ///A test for Valid Type context but ExcludeAllOfType==IncludeAllOfType
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_ExcludeAllOfTypeEqualsIncludeAllOfType()
        {
            //exclude all children of type controller, exclude all of type datalogs
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .ExcludeAllOfType(DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs)
                                                                                      .IncludeAllOfType(DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();


            Assert.AreEqual(2, target.SyntaxWarnings.Count, "There should be two warnings.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllOfType and IncludeAllOfType removed, ExcludeAllOfType cannot be the same as IncludeAllOfType."), "incorrect warning");
            Assert.IsTrue(target.SyntaxWarnings[1].StartsWith("ExcludeAllChildrenOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType."), "incorrect warning");

        }
        /// <summary>
        /// A test for ExcludeAllChildrenOfType without an IncludeAllOfType
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataContext_ValidationWarning_ExcludeAllChildrenOfType_Controller()
        {
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .Build();

            Assert.AreEqual(1, target.SyntaxWarnings.Count,"There should be 1 warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllChildrenOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType."), "incorrect warning");


        }

        /// <summary>
        ///A test for cannot mix path based and typed based include/exclude
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_CannotMixPathAndTypeBasedIncludesExcludes()
        {
            //include path and exclude all of type datalog
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().ExcludeAllChildrenFrom("::Controller1")
                                                                                      .Include("::Controller1\\MainProgram")
                                                                                      .ExcludeAllOfType(DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("All path based exclude/includes removed, cannot mix Path based"), "incorrect warning");

        }

        /// <summary>
        ///A test for cannot mix path based and typed based include/exclude
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_CannotHaveAFilterWithATypeBasedIncludesExcludes()
        {
            //add filter and exclude all controllers
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().AddFilter("dt","REAL",false)
                                                                                      .ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .Build();


            Assert.AreEqual(2, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("Filter removed, a filter cannot be used with IncludeAllOfType"), "incorrect warning");
            Assert.IsTrue(target.SyntaxWarnings[1].StartsWith("ExcludeAllChildrenOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType."), "incorrect warning");
 
        }

      
        /// <summary>
        ///A test for Root, Nav into folder and ExcludeAllChildrenOfType, IncludeAllOfType
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_RootAndNavIntoFolder_ExcludeAllOfType_IncludeAllOfType()
        {
            //root controller1, nav into tags and props folder, exclude controller children, include datalogs
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root("::Controller1",DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps)
                                                                                      .ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .IncludeAllOfType(DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();


            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should only be one warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("NavigateIntoFolder removed, NavigateIntoFolder cannot be used with type based"), "incorrect warning");

        }

        /// <summary>
        ///A test for Root, ExcludeAllChildrenFromRoot and ExcludeAllChildrenOfType, IncludeAllOfType
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_RootAndExcludeAllChildrenFromRoot_ExcludeAllOfType_IncludeAllOfType()
        {
            //root controller1, exclude all root children, include controller1\MainProgram,  exclude controller children
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root("::Controller1", DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenFromRoot()
                                                                                      .Include("::Controller1\\MainProgram")
                                                                                      .ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .Build();


            Assert.AreEqual(2, target.SyntaxWarnings.Count, "There should be 2 warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("All path based exclude/includes removed, cannot mix Path based includes"), "incorrect warning");
            Assert.IsTrue(target.SyntaxWarnings[1].StartsWith("ExcludeAllChildrenOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType."),"incorrect warning");

        }

        /// <summary>
        ///A test for Root and ExcludeAllChildrenOfType, IncludeAllOfType Program
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_Root_ExcludeAllOfType_IncludeAllOfTypeProgram()
        {
            //root controller1\MainProgram, exclude controller children, include datalogs
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root("::Controller1\\MainProgram", DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .IncludeAllOfType(DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();


            Assert.AreEqual(2, target.SyntaxWarnings.Count, "There should be 2 warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllOfType and IncludeAllOfType removed, elements of the root path cannot be excluded."), "incorrect warning");
            Assert.IsTrue(target.SyntaxWarnings[1].StartsWith("ExcludeAllChildrenOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType."), "incorrect warning");

        }

        /// <summary>
        /// validate rootpath and ExcludeAllOfType don't include the same type
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_Root_ExcludeAllOfType_RemoveExcludedHMIDevice()
        {
            //ARRANGE AND ACT
            //root HMIDevice, ExcludeAllOfType HMIDevice
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root("::Local:HMIDevice", DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllOfType(DataItemBrowserContext.ExcludeAllOfTypeEnum.HMIDevice)                                                                                      
                                                                                      .Build();

            //ASSERT
            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should be 1 warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllOfType removed, elements of the root path cannot be excluded."), "incorrect warning");
            

        }

        /// <summary>
        /// validate rootpath and ExcludeAllOfType don't include the same type
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_Root_ExcludeAllOfType_RemoveExcludedDataLogs()
        {
            //ARRANGE AND ACT
            //root HMIDevice, ExcludeAllOfType HMIDevice
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root("::c1\\@DataLogs", DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllOfType(DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();

            //ASSERT
            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should be 1 warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllOfType removed, elements of the root path cannot be excluded."), "incorrect warning");


        }

        /// <summary>
        /// validate rootpath and ExcludeAllOfType don't include the same type
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserContext_ValidationWarning_Root_ExcludeAllOfType_ExcludeChildren_IncludeAllOfType_RemoveExcludedDataLogs()
        {
            //ARRANGE AND ACT
            //root HMIDevice, ExcludeAllOfType HMIDevice
            DataItemBrowserContext target = new DataItemBrowserContext.CreateBuilder().Root("::c1\\@DataLogs", DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                      .ExcludeAllChildrenOfType(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                                                                                      .ExcludeAllOfType(DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs)
                                                                                      .IncludeAllOfType(DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs)
                                                                                      .Build();

            //ASSERT
            Assert.AreEqual(1, target.SyntaxWarnings.Count, "There should be 1 warning.");
            Assert.IsTrue(target.SyntaxWarnings[0].StartsWith("ExcludeAllOfType removed, elements of the root path cannot be excluded."), "incorrect warning");


        }

        /// <summary>
        /// parse the path so we can validate results
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private string[] ParseTestPath(string path)
        {
            //first remove any tag portion of the path
            string temp = path;
            int index = path.IndexOf('.');
            if (index > 0)
                temp = temp.Substring(0, index);
            //remove the device delimeter
            temp = temp.Replace("::", "");
            //split the path items
            string[] pathItems = temp.Split('\\');
            return pathItems;
        }
    }
}
