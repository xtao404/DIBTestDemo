﻿using RockwellAutomation.UI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.Generic;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for PathElementObservableCollectionTest and is intended
    ///to contain all PathElementObservableCollectionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class PathElementObservableCollectionTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for pe_PropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void PathOC_pe_PropertyChangedTest()
        {
            _hasActiveElements = false;
            PathElementObservableCollection peOC = new PathElementObservableCollection();
            PrivateObject targetPrivate = new PrivateObject(peOC);
            object sender = null; 
            bool expected = true;
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("newController");

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            peOC.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems)); 
            peOC.Add(pe);
            PropertyChangedEventArgs e = new PropertyChangedEventArgs("IsActive"); 
            targetPrivate.Invoke("add_ActivePathChanged", new System.ComponentModel.PropertyChangedEventHandler(Test_ActivePathChanged));
            targetPrivate.Invoke("pe_PropertyChanged", new object[]{sender, e});
            //see if the event handler was called
            Assert.AreEqual(expected, _hasActiveElements);
        }


        /// <summary>
        ///A test for pe_PropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void PathOC_pe_PropertyChangedTest_HMIDevice()
        {
            _hasActiveElements = false;
            PathElementObservableCollection peOC = new PathElementObservableCollection();
            PrivateObject targetPrivate = new PrivateObject(peOC);
            object sender = null;
            bool expected = true;
            IPathElement pe = PathElementUtility.Instance().CreateHMIDevicePathElement("newController");

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            peOC.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            peOC.Add(pe);
            PropertyChangedEventArgs e = new PropertyChangedEventArgs("IsActive");
            targetPrivate.Invoke("add_ActivePathChanged", new System.ComponentModel.PropertyChangedEventHandler(Test_ActivePathChanged));
            targetPrivate.Invoke("pe_PropertyChanged", new object[]{sender, e});
            //see if the event handler was called
            Assert.AreEqual(expected, _hasActiveElements);
        }

        bool _hasActiveElements = false;
        /// <summary>
        /// method to support PathOC_pe_PropertyChangedTest
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Test_ActivePathChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            ActivePathChangedEventArgs activeArgs = e as ActivePathChangedEventArgs;
            _hasActiveElements = activeArgs.HasActiveElements;
        }

        /// <summary>
        ///A test for OnCollectionChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void PathOC_OnCollectionChangedTest()
        {
            _hasActiveElements = false;
            PathElementObservableCollection peOC = new PathElementObservableCollection();
            PrivateObject targetPrivate = new PrivateObject(peOC);
            IPathElement pe = PathElementUtility.Instance().CreateDataItemPathElement("AddMe", "", true);
            targetPrivate.Invoke("add_ActivePathChanged", new System.ComponentModel.PropertyChangedEventHandler(Test_ActivePathChanged));

            // this will cause on collection changed to be called
            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            peOC.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            peOC.Add(PathElementUtility.Instance().CreateControllerPathElement("Controller1"));
            peOC.Add(pe);
            //see if the event handler was called
            Assert.AreEqual(pe.IsActive, _hasActiveElements);

            //this will also cause on collection chagned to be called
            peOC.Remove(pe);
            //see if the event handler was called
            Assert.IsTrue(_hasActiveElements);
        }


        /// <summary>
        ///A test for OnCollectionChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void PathOC_OnCollectionChangedTest_HMIDevice()
        {
            _hasActiveElements = false;
            PathElementObservableCollection peOC = new PathElementObservableCollection();
            PrivateObject targetPrivate = new PrivateObject(peOC);
            IPathElement pe = PathElementUtility.Instance().CreateDataItemPathElement("AddMe", "", true);
            targetPrivate.Invoke("add_ActivePathChanged", new System.ComponentModel.PropertyChangedEventHandler(Test_ActivePathChanged));

            // this will cause on collection changed to be called
            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            peOC.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            peOC.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("Controller1"));
            peOC.Add(pe);
            //see if the event handler was called
            Assert.AreEqual(pe.IsActive, _hasActiveElements);

            //this will also cause on collection chagned to be called
            peOC.Remove(pe);
            //see if the event handler was called
            Assert.IsTrue(_hasActiveElements);
        }


        /// <summary>
        ///A test for NotifyActivePathChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void PathOC_NotifyActivePathChangedTest()
        {
            _hasActiveElements = true;
            PathElementObservableCollection target = new PathElementObservableCollection();
            PrivateObject targetPrivate = new PrivateObject(target);
            targetPrivate.Invoke("add_ActivePathChanged", new System.ComponentModel.PropertyChangedEventHandler(Test_ActivePathChanged));
            targetPrivate.Invoke("NotifyActivePathChanged");
            //since there  are no active elements in the collection _hasActiveElement will be false
            Assert.AreEqual(false,_hasActiveElements);
        }

        /// <summary>
        ///A test for Clear
        ///</summary>
        [TestMethod()]
        public void PathOC_ClearTest()
        {
            PathElementObservableCollection target = new PathElementObservableCollection();
            IPathElement pe = PathElementUtility.Instance().CreateDataItemPathElement("AddMe", "", true);
            target.Add(pe);

            IPathElement pe2 = PathElementUtility.Instance().CreateDataItemPathElement("AddMe2", "", true);
            // this will cause on collection changed to be called
            target.Add(pe);

            Assert.AreEqual(target.Count, 2);
            target.Clear();
            Assert.AreEqual(target.Count,0);
        }

  
    }
}
