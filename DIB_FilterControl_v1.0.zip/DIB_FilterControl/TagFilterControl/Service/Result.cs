﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Service
{
    public class Result
    {
         public bool HasError
        {
            get { return ErrorInformations.Count > 0; }
        }

        public List<string> ErrorInformations { get; set; }

        public Result()
        {
            ErrorInformations = new List<string>();
        }
    }
}
