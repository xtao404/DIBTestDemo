/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// A client of the DataItemBrowser, will use this builder class to define the DataItemBrowser launch context
    /// this includes:
    ///     Root - path of the Home screen (this can be empty)
    ///     ExcludeAllChildrenFromRoot - exclude all child components from the root (componets do not include tags)
    ///     ExcludeAllChildrenFrom - exclude all child components from this item
    ///     Include - Include this componet
    ///     AddFilter - adds a filter 
    ///     -------------------------
    ///     If your results do not look correct, you can look at the list of SyntaxWarnings for help
    ///     For more information look at the "DataItem Browser Invocation" section in the UI Design Doc.
    ///     As a client of the DIB, you should not code/integrate an instance of this class that has SyntaxWarnings.
    ///     
    ///     There is a known issue when the Root is set to the HMI Device and ExcludeAllOfType = HMIDevice. This situation
    ///     will not generate a warning (we do not know from the path string if it is an HMI Device) and the DIB will 
    ///     exclude the HMI Device and ignore the root.
    /// </summary>
    public class DataItemBrowserContext
    {
        #region enumerations
        /// <summary>
        /// do we navigate to a folder within the root enum
        /// </summary>
        public enum NavToFolderEnum
        {
            Nav_NoAction=0,
            Nav_IntoTagsProps=1
        }

        public enum ExcludeAllOfTypeEnum
        {
            None,
            HMIDevice,            
            DataLogs
        }
        public enum ExcludeAllChildrenOfTypeEnum
        {
            None,
            Controller
        }
        public enum IncludeAllOfTypeEnum
        {
            None,
            DataLogs
        }
        #endregion enumerations

        #region private data
        //the first item in the path is the device, e.g. controller name or HMIDevice
        private const int DEVICE_INDEX = 0;
        //the second item in the path is the folder index
        private const int FOLDER_INDEX = 1;
        //there will at least 2 items to have a folder in the path
        private const int FOLDER_PATH_COUNT = 2;
        //there will at least 1 items to have a device in the path
        private const int DEVICE_PATH_COUNT = 1;

        #endregion private data

        #region public properties
        /// <summary>
        /// gets value for Root
        /// </summary>
        public List<string> RootPath { get; private set; }
        public NavToFolderEnum RootNavIntoFolder { get; set; }
        public bool DisplayMetaData { get; private set; }
        public bool ExcludeAllChildrenFromRoot { get; private set; }
        public List<string> ExcludeAllChildrenFromPath { get; private set; }
        public List<string> IncludePath { get; private set; }
        public ExcludeAllChildrenOfTypeEnum ExcludeAllChildrenOfType { get; set; }
        public ExcludeAllOfTypeEnum ExcludeAllOfType { get; set; }
        public IncludeAllOfTypeEnum IncludeAllOfType { get; set; }
        public List<string> SyntaxWarnings { get; private set; }
        public SearchFilterDefinition FilterDefinition { get; private set; }

        public override String ToString()
        {
            // This method is used by log4net and unit tests
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.AppendLine("\t (");
            stringBuilder.AppendLine("\t RootPath: [count=" + RootPath.Count + "]");
            RootPath.ForEach(n => stringBuilder.AppendLine("\t \t '" + n.ToString() + "'"));
            stringBuilder.AppendLine("\t DisplayMetaData: " + DisplayMetaData);
            stringBuilder.AppendLine("\t RootNavIntoFolder: " + RootNavIntoFolder);
            stringBuilder.AppendLine("\t ExcludeAllChildrenFromRoot: " + ExcludeAllChildrenFromRoot);
            stringBuilder.AppendLine("\t ExcludeAllChildrenFromPath:  [count=" + ExcludeAllChildrenFromPath.Count + "]");
            ExcludeAllChildrenFromPath.ForEach(n => stringBuilder.AppendLine("\t \t '" + n.ToString() + "'"));
            stringBuilder.AppendLine("\t IncludePath: [count=" + IncludePath.Count + "]");
            IncludePath.ForEach(n => stringBuilder.AppendLine("\t \t '" + n.ToString() + "'"));
            stringBuilder.AppendLine("\t ExcludeAllChildrenOfType: " + ExcludeAllChildrenOfType);
            stringBuilder.AppendLine("\t ExcludeAllOfType: " + ExcludeAllOfType);
            stringBuilder.AppendLine("\t IncludeAllOfType: " + IncludeAllOfType);
            stringBuilder.AppendLine("\t SyntaxWarnings: [count=" + SyntaxWarnings.Count + "]");
            SyntaxWarnings.ForEach(n => stringBuilder.AppendLine("\t \t '" + n.ToString() + "'"));
            stringBuilder.AppendLine("\t FilterDefinition: ");
            stringBuilder.Append("\t (" + FilterDefinition);
            stringBuilder.AppendLine("\t )");
            stringBuilder.AppendLine("\t )");
            return stringBuilder.ToString();
        }

        /// <summary>
        /// this method not only validates the data context, but it will remove any includes or excludes
        /// that are not valid
        /// This allows us to simplify the way we apply these includes and excludes, so we should never
        /// leave data context in an invalid state, it may behave unexpectedly.
        /// THE ORDER OF THE VALIDATION IS IMPORTANT. PASSING UNIT TESTS WILL VERIFY THIS FUNCTIONALITY.
        /// </summary>               
        private void ValidateAndRepair()
        {           
            //make sure all paths have been created
            if (this.RootPath == null)
                this.RootPath = new List<string>();
            if (this.ExcludeAllChildrenFromPath == null)
                this.ExcludeAllChildrenFromPath = new List<string>();
            if (this.IncludePath == null)
                this.IncludePath = new List<string>();

           
            TypeAndPathBasedIncludeExcludeValidation();
           
            PathBasedIncludeExcludeValidation();

            TypeBasedIncludeExcludeValidation();    

        }

        /// <summary>
        /// Validates and Repairs any DataContext entries that are related to Type Based Includes and Excludes
        /// The repairs will fix any inconsistencies and enable the DataContext to launch the browser in a reasonable state.
        /// THE ORDER OF THE VALIDATION IS IMPORTANT. PASSING UNIT TESTS WILL VERIFY THIS FUNCTIONALITY.
        /// THIS MUST BE CALLED AFTER PathBasedIncludeExcludeValidation()
        /// </summary>
        private void TypeBasedIncludeExcludeValidation()
        {
            //Type based include/exclude validation
            //cannot have IncludeAllOfType without ExcludeAllChildrenOf
            //ExcludeAllOfType can be called alone or with both IncludeAllOfType and ExcludeAllChildrenOf
            if (ExcludeAllOfType != ExcludeAllOfTypeEnum.None)
            {
                if (string.Compare(IncludeAllOfType.ToString(), ExcludeAllOfType.ToString()) == 0)
                {
                    ExcludeAllOfType = ExcludeAllOfTypeEnum.None;
                    IncludeAllOfType = IncludeAllOfTypeEnum.None;
                    SyntaxWarnings.Add("ExcludeAllOfType and IncludeAllOfType removed, ExcludeAllOfType cannot be the same as IncludeAllOfType.");
                }
            }
            //ExcludeAllChildrenOfType must be paired with an IncludeAllOfType
            if (ExcludeAllChildrenOfType != ExcludeAllChildrenOfTypeEnum.None)
            {
                if (IncludeAllOfType == IncludeAllOfTypeEnum.None)
                {
                    ExcludeAllChildrenOfType = ExcludeAllChildrenOfTypeEnum.None;
                    SyntaxWarnings.Add("ExcludeAllChildrenOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType.");
                }
            }
            else
            {
                if (IncludeAllOfType != IncludeAllOfTypeEnum.None)
                {
                    IncludeAllOfType = IncludeAllOfTypeEnum.None;
                    SyntaxWarnings.Add("IncludeAllOfType removed, IncludeAllOfType must be paired with ExcludeAllChildrenOfType.");
                }
            }
        }

        /// <summary>
        /// Validates and Repairs any DataContext entries that are related to Path Based Includes and Excludes
        /// The repairs will fix any inconsistencies and enable the DataContext to launch the browser in a reasonable state.
        /// THE ORDER OF THE VALIDATION IS IMPORTANT. PASSING UNIT TESTS WILL VERIFY THIS FUNCTIONALITY.
        /// THIS MUST BE CALLED AFTER TypeAndPathBasedIncludeExcludeValidation()
        /// </summary>
        private void PathBasedIncludeExcludeValidation()
        {
            ProgramRootPathVerification();

            //cannot have an include path if there is a nav into tags and properties folder 
            if (RootPath.Count == DEVICE_PATH_COUNT && RootNavIntoFolder == NavToFolderEnum.Nav_IntoTagsProps && IncludePath.Count > 0)
            {
                IncludePath.Clear();
                SyntaxWarnings.Add("Include removed, cannot have an include when nav into tags and properties folder.");
            }
            //you cannot navigate into folder without a root path
            if (this.RootPath.Count == 0 && RootNavIntoFolder == NavToFolderEnum.Nav_IntoTagsProps)
            {
                RootNavIntoFolder = DataItemBrowserContext.NavToFolderEnum.Nav_NoAction;
                SyntaxWarnings.Add("RootNavIntoFolder reset, a root must be defined to use RootNavIntoFolder.");
            }
            //you cannot exclude from root without having a root path
            if (this.RootPath.Count == 0 && ExcludeAllChildrenFromRoot)
            {
                ExcludeAllChildrenFromRoot = false;
                SyntaxWarnings.Add("ExcludeAllChildrenFromRoot reset, ExcludeAllChildrenFromRoot cannot be set if there is no root.");
            }
            //root is not contained in the include path
            if (IncludePath.Count > 0 && !ListContains(IncludePath, RootPath))
            {
                IncludePath.Clear();
                SyntaxWarnings.Add("Include removed, the include must contain the root path & be 1 level deeper.");
            }
            //cannot have ExcludeAllChildrenFromRoot and ExcludeAllChildrenFromPath set at same time
            if (ExcludeAllChildrenFromRoot && ExcludeAllChildrenFromPath.Count > 0)
            {
                ExcludeAllChildrenFromRoot = false;
                SyntaxWarnings.Add("ExcludeAllChildrenFromRoot cleared, cannot have ExcludeAllChildrenFromRoot and ExcludeAllChildrenFrom set.");
            }

            ExcludeAllChildrenFromRootValidation();

            //do we have an exclude?
            if (ExcludeAllChildrenFromPath.Count > 0)
            {
                //we must have an include path too
                if (IncludePath.Count == 0)
                {
                    ExcludeAllChildrenFromPath.Clear();
                    SyntaxWarnings.Add("ExcludeAllChildrenFrom removed, the include path missing.");
                }
                    //the include path must contain the exclude path
                else if (IncludePath.Count <= ExcludeAllChildrenFromPath.Count || !ListContains(IncludePath, ExcludeAllChildrenFromPath))
                {
                    ExcludeAllChildrenFromPath.Clear();
                    IncludePath.Clear();
                    SyntaxWarnings.Add("Include and ExcludeAllChildrenFrom removed, the include must contain the exclude path & be 1 level deeper..");
                }
            }
            //we cannot have an ExcludeAllChildrenFromRoot and no include or an exclue path and no include
            if (ExcludeAllChildrenFromRoot && IncludePath.Count == 0 || ExcludeAllChildrenFromPath.Count > 0 && IncludePath.Count == 0)
            {
                ExcludeAllChildrenFromRoot = false;
                ExcludeAllChildrenFromPath.Clear();
                SyntaxWarnings.Add("ExcludeAllChildrenFrom and ExcludeAllChildrenFromRoot removed, missing include path.");
            }
            //cannot have an include without an exclude
            if (IncludePath.Count > 0 && (!ExcludeAllChildrenFromRoot && ExcludeAllChildrenFromPath.Count == 0))
            {
                IncludePath.Clear();
                SyntaxWarnings.Add("Include removed, missing ExcludeAllChildrenFromRoot or ExcludeAllChildrenFrom.");
            }
        }

        /// <summary>
        /// Verify the correct options are set or not set when ExcludeAllChildrenFromRoot is selected
        /// The repairs will fix any inconsistencies and enable the DataContext to launch the browser in a reasonable state.
        /// THE ORDER OF THE VALIDATION IS IMPORTANT. PASSING UNIT TESTS WILL VERIFY THIS FUNCTIONALITY.
        /// This is run as a part of PathBasedIncludeExcludeValidation()
        /// </summary>
        private void ExcludeAllChildrenFromRootValidation()
        {
            //do we have ExcludeAllChildrenFromRoot
            if (ExcludeAllChildrenFromRoot)
            {
                //must have a root path
                if (this.RootPath.Count == 0)
                {
                    ExcludeAllChildrenFromRoot = false;
                    IncludePath.Clear();
                    SyntaxWarnings.Add("ExcludeAllChildrenFromRoot & Include cleared, the include must contain the root path & be 1 level deeper.");
                }
                    //must have an include path
                else if (IncludePath.Count == 0)
                {
                    ExcludeAllChildrenFromRoot = false;
                    SyntaxWarnings.Add("ExcludeAllChildrenFromRoot cleared, missing an include path.");
                }
                    //root path must be contained in the include path
                else if (IncludePath.Count <= RootPath.Count || !ListContains(IncludePath, RootPath))
                {
                    ExcludeAllChildrenFromRoot = false;
                    IncludePath.Clear();
                    SyntaxWarnings.Add("ExcludeAllChildrenFromRoot & Include cleared, the include must contain the root path & be 1 level deeper.");
                }
            }
        }

        /// <summary>
        /// Validates and Repairs any DataContext entries that are related to specifying a Program as the RootPath
        /// The repairs will fix any inconsistencies and enable the DataContext to launch the browser in a reasonable state.
        /// THE ORDER OF THE VALIDATION IS IMPORTANT. PASSING UNIT TESTS WILL VERIFY THIS FUNCTIONALITY.
        /// This is run as a part of PathBasedIncludeExcludeValidation()
        /// </summary>
        private void ProgramRootPathVerification()
        {
            //a program cannot exclude or include 
            if (this.RootPath.Count >= FOLDER_PATH_COUNT)
            {
                if (IncludePath.Count > 0)
                {
                    IncludePath.Clear();
                    SyntaxWarnings.Add("Include removed, children cannot be included for a program root.");
                }
                if (ExcludeAllChildrenFromPath.Count > 0)
                {
                    ExcludeAllChildrenFromPath.Clear();
                    SyntaxWarnings.Add("ExcludeAllChildrenFrom cleared, children cannot be excluded for a program root.");
                }
                if (ExcludeAllChildrenFromRoot)
                {
                    ExcludeAllChildrenFromRoot = false;
                    SyntaxWarnings.Add("ExcludeAllChildrenFromRoot reset, root children cannot be excluded for a program root.");
                }
                if (RootNavIntoFolder == NavToFolderEnum.Nav_IntoTagsProps)
                {
                    RootNavIntoFolder = DataItemBrowserContext.NavToFolderEnum.Nav_NoAction;
                    SyntaxWarnings.Add("NavigateIntoFolder cleared, cannot navigate into tags and props folder for a program root.");
                }
            }
        }

        /// <summary>
        /// Validates and Repairs any DataContext entries that are related to Type and Path Based Includes and Excludes
        /// The repairs will fix any inconsistencies and enable the DataContext to launch the browser in a reasonable state.
        /// THE ORDER OF THE VALIDATION IS IMPORTANT. PASSING UNIT TESTS WILL VERIFY THIS FUNCTIONALITY.
        /// </summary>
        private void TypeAndPathBasedIncludeExcludeValidation()
        {
            //filters are not allowed with type based includes/excludes
            if (IncludeAllOfType != IncludeAllOfTypeEnum.None || ExcludeAllOfType != ExcludeAllOfTypeEnum.None || ExcludeAllChildrenOfType != ExcludeAllChildrenOfTypeEnum.None)
            {
                if (!String.IsNullOrEmpty(FilterDefinition.SearchString))
                {
                    FilterDefinition.ClearSearch();
                    SyntaxWarnings.Add("Filter removed, a filter cannot be used with IncludeAllOfType, ExcludeAllOfType or ExcludeAllChildrenOfType.");
                }
            }

            //nav into folder and exclude all children from root is not allowed with type based includes/excludes
            if (IncludeAllOfType != IncludeAllOfTypeEnum.None || ExcludeAllOfType != ExcludeAllOfTypeEnum.None || ExcludeAllChildrenOfType != ExcludeAllChildrenOfTypeEnum.None)
            {
                if (RootNavIntoFolder != NavToFolderEnum.Nav_NoAction)
                {
                    RootNavIntoFolder = NavToFolderEnum.Nav_NoAction;
                    SyntaxWarnings.Add("NavigateIntoFolder removed, NavigateIntoFolder cannot be used with type based excludes/includes.");
                }
            }
            //cannot mix Path based includes/excludes with type based includes/excludes, the root can be used with type based includes/excludes 
            if ((IncludePath.Count > 0 || ExcludeAllChildrenFromRoot || ExcludeAllChildrenFromPath.Count > 0))
            {
                if (IncludeAllOfType != IncludeAllOfTypeEnum.None || ExcludeAllChildrenOfType != ExcludeAllChildrenOfTypeEnum.None || ExcludeAllOfType != ExcludeAllOfTypeEnum.None)
                {
                    IncludePath.Clear();
                    ExcludeAllChildrenFromPath.Clear();
                    ExcludeAllChildrenFromRoot = false;
                    SyntaxWarnings.Add("All path based exclude/includes removed, cannot mix Path based includes and excludes with Type based includes and excludes.");
                }
            }

            //Validate that the root path and excludes don't contain the same type. If they are the same, the root path takes precedence   
            //if the root includes programs make sure program type has not been excluded           
            if (RootPath.Count >= FOLDER_PATH_COUNT && string.Compare(RootPath[FOLDER_INDEX], DataContext.PROGRAMSFOLDERKEY) == 0)
            {
                //has everything been excluded except datalogs?
                if (ExcludeAllChildrenOfType == ExcludeAllChildrenOfTypeEnum.Controller && IncludeAllOfType == IncludeAllOfTypeEnum.DataLogs)
                {
                    ExcludeAllOfType = ExcludeAllOfTypeEnum.None;
                    IncludeAllOfType = IncludeAllOfTypeEnum.None;
                    SyntaxWarnings.Add("ExcludeAllOfType and IncludeAllOfType removed, elements of the root path cannot be excluded.");
                }
            }

            //the first part of the root path should have the HMIDevice defined if it is in the path at all
            if (RootPath.Count >= DEVICE_PATH_COUNT && RootPath[DEVICE_INDEX].Contains(DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE) && ExcludeAllOfType == DataItemBrowserContext.ExcludeAllOfTypeEnum.HMIDevice)
            {
                //root path takes precedence
                ExcludeAllOfType = ExcludeAllOfTypeEnum.None;
                SyntaxWarnings.Add("ExcludeAllOfType removed, elements of the root path cannot be excluded.");
            }

            if (RootPath.Count >= FOLDER_PATH_COUNT && RootPath[FOLDER_INDEX].Contains(DIResource.DI_COMMON_RESOURCETYPE_DATALOGS) && ExcludeAllOfType == DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs)
            {
                //root path takes precedence
                ExcludeAllOfType = DataItemBrowserContext.ExcludeAllOfTypeEnum.None;
                SyntaxWarnings.Add("ExcludeAllOfType removed, elements of the root path cannot be excluded.");
            }
        }

       
        /// <summary>
        /// check to see if the list contains the containedList
        /// </summary>
        /// <param name="list">the list of items in the path</param>
        /// <param name="containedList">the list of items that are part of the context</param>
        /// <returns></returns>
        private static bool ListContains(List<string> list, List<string> containedList)
        {
            if (list.Count >= containedList.Count)
            {
                int i = 0;
                foreach (string containedName in containedList)
                {
                    if (string.Compare(containedName, list[i++], true) != 0) return false;
                }
                return true;
            }
            return false;
        }
        #endregion validation and repair
      

        #region CreateBuilder class
        /// <summary>
        ///  QueryRequest builder class.
        /// </summary>
        public class CreateBuilder
        {
            #region Private Members

            private List<string> _rootPath { get; set; }
            private NavToFolderEnum _rootNavIntoFolder { get; set; }
            private bool _excludeAllChildrenFromRoot { get; set; }
            private bool _displayMetaData { get; set; } 
            private List<string> _excludeAllChildrenFromPath { get; set; }
            private List<string> _includePath { get; set; }
            private ExcludeAllOfTypeEnum _excludeAllOfType { get; set; }
            private ExcludeAllChildrenOfTypeEnum _excludeAllChildrenOfType { get; set; }
            private IncludeAllOfTypeEnum _includeAllOfType { get; set; }
            private List<string> _parserWarnings { get; set; }
            private SearchFilterDefinition _filterDefinition { get; set; }

            #endregion

            
            /// <summary>
            /// default builder constructor
            /// </summary>
            public CreateBuilder(DIBClientManager dibClientManager = null)
            {
                _parserWarnings = new List<string>();
                // If a DIBClientManager was passes it use it to create filter types. 
                // Otherwise, use default filter types specified here
                if (dibClientManager == null)
                {
                    ObservableCollection<CommonControls.FilterType> filterTypes = new ObservableCollection<CommonControls.FilterType>();
                    filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.Name, true, false));
                    filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.DataType, false, true));
                    filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.Description, true, false));
                    _filterDefinition = new SearchFilterDefinition(filterTypes);
                }
                else
                    _filterDefinition = new SearchFilterDefinition(dibClientManager.GetFilterTypes());
                //we want default value here to be true
                _displayMetaData = true;
            }

            /// <summary>
            /// Sets the Root, or item that the dib will open to. Items above this item in the hierarchy will 
            /// not be able to be navigated to
            /// </summary>
            /// <param name="root">The base item that the dib will open to</param>
            /// <param name="rootNavIntoFolder">enumeration indicating whether to navigate into the tags and properties folder</param>
            public CreateBuilder Root(string rootItem, NavToFolderEnum rootNavIntoFolder)
            {
                _rootPath = ParsePath(rootItem,"Root");
                _rootNavIntoFolder = rootNavIntoFolder;
                return this;
            }

            /// <summary>
            /// Declares whether every child of the root (save Tags) are excluded
            /// </summary>
            public CreateBuilder ExcludeAllChildrenFromRoot() { _excludeAllChildrenFromRoot = true; return this; }

            /// <summary>
            /// Excludes all children from the specified parent
            /// </summary>
            /// <param name="parent"></param>
            public CreateBuilder ExcludeAllChildrenFrom(string parent)
            {
                _excludeAllChildrenFromPath = ParsePath(parent, "ExcludeAllChildrenFrom");
                return this;
            }

           
            /// <summary>
            /// Declares whether or not to display metadata
            /// </summary>
            public CreateBuilder DisplayMetaData(bool shouldDisplayMetaData)
            { 
                _displayMetaData = shouldDisplayMetaData; 
                return this; 
            }

            /// <summary>
            /// Include a specific resource within the dataset
            /// </summary>
            /// <remarks>This must be paired with some type of exclude</remarks>
            /// <param name="resource">include path</param>
            /// <returns>this</returns>
            public CreateBuilder Include(string resource)
            {
                _includePath = ParsePath(resource,"Include");
                
                return this;
            }

            /// <summary>
            /// this method will exclude all object based on the type 
            /// </summary>
            /// <param name="typeEnum">exclude type</param>
            /// <returns>this</returns>
            public CreateBuilder ExcludeAllOfType(ExcludeAllOfTypeEnum typeEnum)
            {
                _excludeAllOfType = typeEnum;
                return this;
            }

            /// <summary>
            /// include all objects of this type, this must be paired with ExcludeAllChildrenOfType
            /// </summary>
            /// <param name="typeEnum">include type</param>
            /// <returns>this</returns>
            public CreateBuilder IncludeAllOfType(IncludeAllOfTypeEnum typeEnum)
            {
                _includeAllOfType = typeEnum;
                return this;
            }

            /// <summary>
            /// exclude all children of objects of this type, this must be paired with IncludeAllOfType
            /// </summary>
            /// <param name="typeEnum">type of exclude parent</param>
            /// <returns>this</returns>
            public CreateBuilder ExcludeAllChildrenOfType(ExcludeAllChildrenOfTypeEnum typeEnum)
            {
                _excludeAllChildrenOfType = typeEnum;
                return this;
            }

            /// <summary>
            /// Add the filter to the dataset, the result will look the same as if the user 
            /// had typed a filter into the search filter control
            /// </summary>
            /// <param name="name">the filter operator</param>
            /// <param name="value">the value to filter</param>
            /// <param name="isExactMatch">whether the filter should do an exact match</param>
            /// <returns>this</returns>
            public CreateBuilder AddFilter(string name, string value, bool isExactMatch)
            {
                //if there is a filter name but no filter value then we cannot add it
                if (string.IsNullOrEmpty(value) && !string.IsNullOrEmpty(name))
                {
                    _parserWarnings.Add("Filter removed, filter value cannot be empty");
                    return this;
                }

                //remove the delimeter if it is in the text
                name = name.Replace(SearchFilterParser.FilterOperatorDelimiter,String.Empty);
                name = name + SearchFilterParser.FilterOperatorDelimiter;
                if (!_filterDefinition.AddFilter(name, value, isExactMatch, SearchFilterDefinition.StatementLogic.AND))
                    _parserWarnings.Add("Filter removed, filter name \"" + name + "\" is invalid");
                return this;
            }

            /// <summary>
            /// Validates and builds an instance of a <see cref="E:DataItemBrowserContext"/>.
            /// </summary>          
            public DataItemBrowserContext Build()
            {
                DataItemBrowserContext context = new DataItemBrowserContext
                {
                    RootPath = _rootPath,
                    ExcludeAllChildrenFromRoot = _excludeAllChildrenFromRoot,
                    ExcludeAllChildrenFromPath = _excludeAllChildrenFromPath,
                    DisplayMetaData = _displayMetaData,
                    IncludePath = _includePath,
                    RootNavIntoFolder = _rootNavIntoFolder,
                    SyntaxWarnings = _parserWarnings,
                    FilterDefinition = _filterDefinition,
                    ExcludeAllChildrenOfType = _excludeAllChildrenOfType,
                    ExcludeAllOfType = _excludeAllOfType,
                    IncludeAllOfType = _includeAllOfType

                };
                context.ValidateAndRepair();
                return context;
            }

            /// <summary>
            /// parse the path into a list of individual path items
            /// </summary>
            /// <param name="path">the path to the resource</param>
            /// <param name="pathName">the context action, whether to include or exclude</param>
            /// <returns></returns>
            private List<string> ParsePath(string path, string pathName)
            {
                List<string> pathItems = new List<string>();
                if (string.IsNullOrEmpty(path))
                    return pathItems;
                string tempPath = path;

                //remove the tag portion it is added of the path
                int iTag = tempPath.IndexOf(DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER);
                if (iTag >= 0)
                {
                    tempPath = tempPath.Substring(0, iTag).Trim();
                    _parserWarnings.Add(pathName + ", path should not contain tag information.");
                }

                //the path must start with ::
                if (tempPath.StartsWith(DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER) && tempPath.Length > DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER.Length)
                {
                    //remove device token
                    tempPath = tempPath.Replace(DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER, String.Empty);
                    
                    string[] pathStrings = tempPath.Split(DIResource.DI_COMMON_RESOURCETYPE_PATH_DELIMITER[0]);

                    foreach (string item in pathStrings)
                    {
                        if (!string.IsNullOrEmpty(item.Trim()))
                            pathItems.Add(item);
                    }
                     //If the path must have a folder and it does not start wih "@", currently we assume it must be a program,
                    //If it is a program we need to add the "Programs" folder to the path items /before the program name.
                    if (pathStrings.Count() == FOLDER_PATH_COUNT && !pathStrings[FOLDER_INDEX].StartsWith("@") && !string.IsNullOrEmpty(pathStrings[FOLDER_INDEX]))
                    {
                        //Add the program item to the end of path list  
                        pathItems.Add(pathItems[FOLDER_INDEX]);
                        //replace the current path item with the Program folder
                        pathItems[FOLDER_INDEX] = DataContext.PROGRAMSFOLDERKEY;
                    }
                }
                else
                    _parserWarnings.Add(pathName + ", invalid path.");

                
                return pathItems;
            }
        }

        #endregion CreateBuilder class
        #region constructor
        /// <summary>
        /// Default Constructor.
        /// <para>
        /// declared private as this class implements the builder pattern. This is intentionally left blank
        /// </para>
        /// </summary>
        private DataItemBrowserContext() { }
        #endregion constructor
    }

    
}
