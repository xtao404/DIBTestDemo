﻿using System;
using System.Windows;
using System.Windows.Data;
using RockwellAutomation.UI.Models;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    /// <summary>
    /// Seperate window containing DIB Control
    /// </summary>
    public partial class DIBContainerWindow : Window
    {
        public DIBClientManager DIBClientManager; 
        public DIBContainerWindow(string stringDIBClientManagerName, string launchText)
        {
            RockwellAutomation.UI.XceedDeploymentLicense.SetLicense();

            InitializeComponent();

            dib.BrowserType = "tag"; //For now this must be set....untill further Generic DIB refactoring

            // Set the DIB Client Manager
            this.DIBClientManager = RockwellAutomation.DesignTimeClient.PopUpGenericTestHost.Window1.GetDIBClientManagerFor(stringDIBClientManagerName);
            this.DIBClientManager.InitializeDIBControlOnStartup(dib, new System.Text.StringBuilder());
            this.DIBClientManager.InitialLaunchString = launchText;

            this.dib.Initialize(
                this.DIBClientManager,
                launchText);
        }

        private void dib_ItemSelected(object sender, RoutedEventArgs e)
        {
            lblOverview.Content = "You selected: " + this.dib.SelectedItem;
        }
    }
}
