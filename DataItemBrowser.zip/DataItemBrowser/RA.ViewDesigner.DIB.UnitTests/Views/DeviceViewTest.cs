﻿using System;
using System.Globalization;
using System.Windows;
using AvalonUnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.CommonControls.DeviceImage;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;
using RockwellAutomation.UI.Views;

namespace DataItemBrowserUT
{
    [TestClass]
    public class DeviceViewTest
    {
        /// <summary>
        /// DeviceView UI data binding check.
        /// </summary>
        [TestMethod()]
        public void DeviceView_DataBindingIsCorrectTest()
        {
            AvalonTestRunner.RunInSTA(delegate()
            {
                // Create the control using a delegate to ensure binding errors generated during
                // control creation are caught.
                Func<object> controlCreator = delegate()
                {
                    // what ever your control is called
                    DIBListView control = new DIBListView();
                    return control;
                };

                AvalonTestRunner.RunDataBindingTests(controlCreator);
            });
        }

        /// <summary>
        /// DeviceView converter test
        /// </summary>
        [TestMethod()]
        public void DeviceView_Converters_ImageNameToVisibilityConverter()
        {
            //ARRANGE
            ImageNameToVisibilityConverter converter = new ImageNameToVisibilityConverter();

            //ACT- ASSERT with various configurations
            //both value and param are null
            Visibility visibility = (Visibility) (converter.Convert(string.Empty, null, string.Empty, CultureInfo.CurrentCulture));
            Assert.AreEqual(visibility, Visibility.Collapsed);

            //either value or param is null
             visibility = (Visibility) converter.Convert(string.Empty, null, EnumImageState.ERROR, CultureInfo.CurrentCulture) ;
            Assert.AreEqual(visibility, Visibility.Collapsed);

            //either value or param is null
             visibility = (Visibility) converter.Convert(EnumImageState.OUTOFSYNCH, null, string.Empty, CultureInfo.CurrentCulture);
            Assert.AreEqual(visibility, Visibility.Collapsed);

            //both value and param are the same
             visibility = (Visibility) converter.Convert(EnumImageState.OUTOFSYNCH, null, EnumImageState.OUTOFSYNCH, CultureInfo.CurrentCulture);
             Assert.AreEqual(visibility, Visibility.Visible);

            //both value and param are the same
             visibility = (Visibility) converter.Convert(EnumImageState.SYNCHED, null, EnumImageState.SYNCHED, CultureInfo.CurrentCulture);
             Assert.AreEqual(visibility, Visibility.Visible);

            //both value and param are the same
             visibility = (Visibility) converter.Convert(EnumImageState.SYNCHING, null, EnumImageState.SYNCHING, CultureInfo.CurrentCulture);
             Assert.AreEqual(visibility, Visibility.Visible);

            //both value and param are the same
             visibility = (Visibility) converter.Convert(EnumImageState.SYNCHLOST, null, EnumImageState.SYNCHLOST, CultureInfo.CurrentCulture);
             Assert.AreEqual(visibility, Visibility.Visible);

            //both value and param are the same
             visibility = (Visibility) converter.Convert(EnumImageState.ERROR, null, EnumImageState.ERROR, CultureInfo.CurrentCulture);
             Assert.AreEqual(visibility, Visibility.Visible);

            //both value and param are the same
             visibility = (Visibility) converter.Convert(EnumImageState.WARNING, null, EnumImageState.WARNING, CultureInfo.CurrentCulture);
             Assert.AreEqual(visibility, Visibility.Visible);

            //convertback always returns null
             object ob = converter.ConvertBack(EnumImageState.WARNING, null, EnumImageState.SYNCHED, CultureInfo.CurrentCulture);
             Assert.IsNull(ob);


        }

        /// <summary>
        /// DeviceView converter test
        /// </summary>
        [TestMethod()]
        public void DeviceView_Converters_hideControllerVisibilityConverter()
        {
            hideControllerVisibilityConverter converter = new hideControllerVisibilityConverter();
            bool hideController = false;
            DisplayTypeEnum displaytype = DisplayTypeEnum.ControllerAndStatus;
            Visibility visibility = (Visibility)converter.Convert(hideController, null, displaytype, CultureInfo.CurrentCulture);
            Assert.AreEqual(visibility,Visibility.Visible);

            hideController = true;
            visibility = (Visibility)converter.Convert(hideController, null, displaytype, CultureInfo.CurrentCulture);
            Assert.AreEqual(visibility, Visibility.Collapsed);

            displaytype = DisplayTypeEnum.StatusOnly;
            visibility = (Visibility)converter.Convert(hideController, null, displaytype, CultureInfo.CurrentCulture);
            Assert.AreEqual(visibility, Visibility.Visible);

            hideController = false;
            visibility = (Visibility)converter.Convert(hideController, null, displaytype, CultureInfo.CurrentCulture);
            Assert.AreEqual(visibility, Visibility.Collapsed);
            
        }

        
    }
}
