﻿using RA.UI.TextBlockService;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Data;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for TextBlockServiceTest and is intended
    ///to contain all TextBlockServiceTest Unit Tests
    ///</summary>
    [TestClass()]
    public class TextBlockServiceTest
    {
        private TestContext testContextInstance;
        private PrivateType textBlockServicePrivate;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{ 
        //}
        
        ////Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        
        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            if(textBlockServicePrivate==null)
                textBlockServicePrivate = new PrivateType(new TextBlockService().GetType());
        }
        
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for IsTextTrimmed_True
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void TextBlockServices_IsTextTrimmedTest_True()
        {
            TextBlock target = new TextBlock(); 

            bool value = true;
            textBlockServicePrivate.InvokeStatic("SetIsTextTrimmed", new object[]{target, value});
            Assert.AreEqual(value,TextBlockService.GetIsTextTrimmed(target));
        }
        /// <summary>
        ///A test for IsTextTrimmed_False
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void TextBlockServices_IsTextTrimmedTest_False()
        {
            TextBlock target = new TextBlock();

            bool value = false;
            textBlockServicePrivate.InvokeStatic("SetIsTextTrimmed", new object[] { target, value });
            Assert.AreEqual(value, TextBlockService.GetIsTextTrimmed(target));
        }

        /// <summary>
        ///A test for AutomaticToolTipEnabled_False
        ///</summary>
        [TestMethod()]
        public void TextBlockServices_AutomaticToolTipEnabledTest_True()
        {
            DependencyObject element = new DependencyObject(); 
            bool value = true; 
            TextBlockService.SetAutomaticToolTipEnabled(element, value);
            Assert.AreEqual(value, TextBlockService.GetAutomaticToolTipEnabled(element));
        }


        /// <summary>
        ///A test for AutomaticToolTipEnabled_False
        ///</summary>
        [TestMethod()]
        public void TextBlockServices_AutomaticToolTipEnabledTest_False()
        {
            DependencyObject element = new DependencyObject();
            bool value = false;
            TextBlockService.SetAutomaticToolTipEnabled(element, value);
            Assert.AreEqual(value, TextBlockService.GetAutomaticToolTipEnabled(element));
        }
        /// <summary>
        ///A test for CalculateIsTextTrimmed_TextOnlyFalse
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void TextBlockServices_CalculateIsTextTrimmed_TextOnlyFalseTest()
        {
            TextBlock textBlock = new TextBlock();
            FontFamily ff = new FontFamily("Times New Roman");
            textBlock.FontFamily = ff;
            textBlock.FontSize = 20;
            textBlock.Text = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
            textBlock.Width = 20;
            bool expected = true; 
            bool actual = true;
            textBlockServicePrivate.InvokeStatic("SetIsTextTrimmed", new object[] { textBlock, true });
            actual = (bool)textBlockServicePrivate.InvokeStatic("CalculateIsTextTrimmed", new object[] { textBlock, false });
            Assert.AreEqual(expected, actual);
        }


        /// <summary>
        ///A test for CalculateIsTextTrimmed_TextOnlyTrue
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void TextBlockServices_CalculateIsTextTrimmed_TextOnlyTrueTest()
        {
            TextBlock textBlock = new TextBlock();
            FontFamily ff = new FontFamily("Times New Roman");
            textBlock.FontFamily = ff;
            textBlock.FontSize = 20;
            textBlock.Text = "aaaaaaaaaaaaaaaaaaa bbbbbbbbbbbbbbbbbbbbbbbbbbb";
            textBlock.Width = 20;
            bool expected = true;
            bool actual = true;
            textBlockServicePrivate.InvokeStatic("SetIsTextTrimmed", new object[] { textBlock, true });
            actual = (bool)textBlockServicePrivate.InvokeStatic("CalculateIsTextTrimmed", new object[] { textBlock, true });
            Assert.AreEqual(expected, actual);
        }
       

        /// <summary>
        ///A test for OnTextBlockSizeChanged_TextIsNotTrimmed
        ///</summary>
        [TestMethod()]
        public void TextBlockServices_OnTextBlockSizeChangedTest_TextIsNotTrimmed()
        {
            TextBlock tb = new TextBlock();
            tb.TextTrimming = TextTrimming.None;
            bool expected = false;
            //event arg is not used
            SizeChangedEventArgs e = null;
            TextBlockService.OnTextBlockSizeChanged(tb, e);
            Assert.AreEqual(expected, TextBlockService.GetIsTextTrimmed(tb));
        }
        /// <summary>
        ///A test for OnTextBlockSizeChanged_TextIsTrimmed
        ///</summary>
        [TestMethod()]
        public void TextBlockServices_OnTextBlockSizeChangedTest_TextIsTrimmed()
        {
            TextBlock tb = new TextBlock();
            tb.TextTrimming = TextTrimming.CharacterEllipsis;
            bool expected = true;
            //event arg is not used
            SizeChangedEventArgs e = null;
            textBlockServicePrivate.InvokeStatic("SetIsTextTrimmed", new object[] { tb, true });
            textBlockServicePrivate.InvokeStatic("OnTextBlockSizeChanged", new object[] { tb, e });
            Assert.AreEqual(expected, TextBlockService.GetIsTextTrimmed(tb));
        }

        /// <summary>
        ///A test for OnTextBlockTargetUpdated_TextIsNotTrimmed
        ///</summary>
        [TestMethod()]
        public void TextBlockServices_OnTextBlockTargetUpdatedTest_TextIsNotTrimmed()
        {
            TextBlock tb = new TextBlock();
            FontFamily ff = new FontFamily("Times New Roman");
            tb.FontFamily = ff;
            tb.FontSize = 10;
            tb.Width = 20;
            tb.Text = "aa";
            tb.TextTrimming = TextTrimming.None;
            bool expected = false;
            //event arg is not used
            DataTransferEventArgs e = null;
            TextBlockService.OnTextBlockTargetUpdated(tb, e);
            Assert.AreEqual(expected, TextBlockService.GetIsTextTrimmed(tb));
        }
        /// <summary>
        ///A test for OnTextBlockTargetUpdated_TextIsTrimmed
        ///</summary>
        [TestMethod()]
        public void TextBlockServices_OnTextBlockTargetUpdatedTest_TextIsTrimmed()
        {
            TextBlock tb = new TextBlock();
            FontFamily ff = new FontFamily("Times New Roman");
            tb.FontFamily = ff;
            tb.FontSize = 20;
            tb.Width = 20;
            tb.Text = "ddddddddd eeeeeeeeeeeee ffffffffffffffff";
            tb.TextTrimming = TextTrimming.CharacterEllipsis;
            bool expected = true;
            //event arg is not used
            DataTransferEventArgs e = null;
            textBlockServicePrivate.InvokeStatic("SetIsTextTrimmed", new object[] { tb, true });
            textBlockServicePrivate.InvokeStatic("OnTextBlockTargetUpdated", new object[] { tb, e });
            Assert.AreEqual(expected, TextBlockService.GetIsTextTrimmed(tb));
        }
    }
}
