﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System;
using System.Collections.Generic;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.Models;
using System.Windows;
using System.ComponentModel;
using System.Windows.Input;
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace RockwellAutomation.UI.ViewModels
{
    public class DIBViewModel: INotifyPropertyChanged
    {
        #region private members


        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields",
            Justification = "Suppress this message for now. Need to further refactor subclasses to make _dibViewModel a property")]
        protected IDataItemBrowserViewModel _dibViewModel = null;

        private SimpleCommand _drillInCommand = null;
        private SimpleCommand _drillOutCommand = null;

        #endregion

        #region properties

        virtual public bool isActive()
        {
            //let client overide
            return false;
        }

        /// <summary>
        /// visibility property that is bound in our associated XAML
        /// </summary>
        private Visibility? _visible = Visibility.Visible;
        public Visibility? Visible
        {
            get { return _visible; }
            set
            {
                if (_visible == value) return;
                _visible = value;
                NotifyPropertyChanged("Visible");
            }
        }

        /// <summary>
        /// Reference to the path object 
        /// </summary>
        public Path Path
        {
            get { return _dibViewModel.Path; }
        }

        /// <summary>
        /// is search active property
        /// </summary>
        public bool IsSearchActive
        {
            get
            {
                return _dibViewModel.IsSearchActive;
            }
        }

        /// <summary>
        /// Wether or not we will perform a client side or server side search
        /// TO DO: Change this method name to AllowServerSideSearch or I
        /// </summary>
        public bool IsQueryBasedSearchActive
        {
            get { return _dibViewModel.IsQueryBasedSearchActive; }
        }

        /// <summary>
        /// The last item explicitly highlighted by the user (i.e. via mouse click or keyboard) property
        /// </summary>
        public string LastUserHighlightedItem
        {
            get
            {
                return _dibViewModel.LastUserHighlightedItem ?? null;
            }

            set
            {
                if (_dibViewModel != null)
                    _dibViewModel.LastUserHighlightedItem = value;
            }
        }

        /// <summary>
        /// user set highlighted path property
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public List<IPathElement> UserSetHighlightedPath
        {
            get
            {
                return _dibViewModel.Path.UserSetHighlightedPath;
            }
            set
            {
                _dibViewModel.Path.UserSetHighlightedPath = value;
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">DataItemBrowser View Model</param>
        public DIBViewModel(IDataItemBrowserViewModel dibVM)
        {
            LastUserHighlightedItem = String.Empty;
            _dibViewModel = dibVM;

            _dibViewModel.DataViewChanged += new EventHandler(DataItemBrowserViewModel_DataViewChanged);
            _dibViewModel.SearchBreadCrumbChanged += new PropertyChangedEventHandler(DataItemBrowserViewModel_SearchBreadCrumbChanged);
        }

        #endregion Constructor

        #region Commands

        /// <summary>
        /// Creates the path which specifies the Controller to drill into and then navigates into it.
        /// </summary>
        public ICommand DrillOutCommand
        {
            get
            {
                if (_drillOutCommand != null) return _drillOutCommand;
                _drillOutCommand = CreateDrillOutCommand();
                return _drillOutCommand;
            }
        }

        public virtual SimpleCommand CreateDrillOutCommand()
        {
            return new SimpleCommand()
            {
                ExecuteDelegate = x =>
                {
                    DataItemBase item = x as DataItemBase;

                    //We cannot drill out if we are on initial and default path
                    if (_dibViewModel.Path.ActiveElement is HomePathElement) return;

                    // Navigation Back will always be done on the Path if it exists.
                    _dibViewModel.Path.NavigateBack();

                    if (item == null && _dibViewModel.Path.ActiveElement != null)
                    {
                        _dibViewModel.Navigate(_dibViewModel.Path.ActiveElement.DataItem);
                        return;
                    }
                    _dibViewModel.Navigate(item);
                }
            };
        }

        /// <summary>
        /// Creates the path which specifies the Controller to drill into and then navigates into it.
        /// </summary>
        public ICommand DrillInCommand
        {
            get
            {
                if (_drillInCommand != null) return _drillInCommand;
                _drillInCommand = CreateDrillInCommand();
                return _drillInCommand;
            }
        }

        /// <summary>
        /// Creates the path which specifies the Controller to drill into and then navigates into it.
        /// </summary>
        public virtual SimpleCommand CreateDrillInCommand()
        {
            return new SimpleCommand()
            {
                ExecuteDelegate = x =>
                {
                    DIBTreeViewItem node = x as DIBTreeViewItem;
                    if (node == null) return;
                    if (node.DataItem == null) return;

                    if ((_dibViewModel.Path.Forward != null) &&
                        (node.VisualName == _dibViewModel.Path.Forward.DisplayName))
                        _dibViewModel.Path.SetActive(_dibViewModel.Path.Forward);
                    else
                    {
                        IPathElement newPE = PathElementFactory.Instance().CreatePathElement(node.DataItem);
                        _dibViewModel.Path.Add(newPE);

                    }
                    //handle highlighted item processing
                    this.Path.HighlightedElement = Path.ActiveElement;
                    _dibViewModel.Navigate(node.DataItem);
                }
            };
        }

        #endregion

        #region EventHandlers

        /// <summary>
        /// mouse double click selection method
        /// </summary>
        /// <param name="selectedNameDIB"></param>
        virtual public void DoubleClickSelection(DataItemBase selectedNameDIB)
        {
            // execute the selected item command 
            string isSelectableStringValue = selectedNameDIB.GUISupportsSelection;
            if (String.IsNullOrWhiteSpace(isSelectableStringValue) || !Convert.ToBoolean(isSelectableStringValue)) return;

            _dibViewModel.SelectedItemCommand.Execute(selectedNameDIB);
        }

        /// <summary>
        /// data view has changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        virtual protected void DataItemBrowserViewModel_DataViewChanged(object sender, EventArgs e)
        {
            if (this.isActive())
                Visible = Visibility.Visible;
            else
            {
                Visible = Visibility.Collapsed;
                this.DisposeItems();
            }
        }

        /// <summary>
        /// handler for adding or removing the search crumb
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        virtual protected void DataItemBrowserViewModel_SearchBreadCrumbChanged(object sender, PropertyChangedEventArgs e)
        {
            SearchBreadCrumbPropertyChangedEventArgs arg = e as SearchBreadCrumbPropertyChangedEventArgs;
            if (arg != null && arg.Add)
            {
                // If we are adding the search crumb then a search is in progress
                // and we want to hide this view in favor of the GridView
                this.Visible = Visibility.Collapsed;
            }
            else
            {
                // Need to re-establish correct visibility because the user 
                // may be adjusting the search query and this does not 
                // cause the re-evaluation of the active view
                this.Visible = this.isActive() ?
                    Visibility.Visible :
                    Visibility.Collapsed;
            }
        }

        /// <summary>
        /// mouse single click/keyboard nav selection method
        /// </summary>
        /// <param name="highlightedItem"></param>
        public void UserChangedHighlightedItem(DataItemBase highlightedItem)
        {
            // execute the selected item command 
            _dibViewModel.UserSetHighlightedItemCommand.Execute(highlightedItem);
        }

        protected static bool ContainsAutomationRecursionError(Exception exception)
        {
            return exception.Message.Contains("Recursive call to Automation Peer API is not valid.");
        }
    
        #endregion

        #region Path related

        virtual public string CurrentPathStringFor(List<IPathElement> tempList)
        {
            return this._dibViewModel.PathToString(tempList, string.Empty);
        }

        #endregion

        #region Startup - Shutdown

        /// <summary>
        /// Remove event handlers and save column configuration
        /// </summary>
        virtual public void Cleanup()
        {
            _dibViewModel.DataViewChanged -= new EventHandler(DataItemBrowserViewModel_DataViewChanged);
            _dibViewModel.SearchBreadCrumbChanged -= new PropertyChangedEventHandler(DataItemBrowserViewModel_SearchBreadCrumbChanged);
            DisposeItems();    
        }

        /// <summary>
        /// dispose of all visual base items
        /// </summary>
        virtual protected void DisposeItems()
        {            
        }

        #endregion

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion
    }
}
