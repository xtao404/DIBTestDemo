/*************************************************************************************
                                                                     
   ViewE XceedDeploymentLicense Class                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System.ComponentModel;
using RockwellAutomation.Logging;

#endregion

namespace RockwellAutomation.UI
{
    /* =============================================================================
     * Class handles the setting of the license key for the Xceed WPF DataGrid
     * =============================================================================
     * IMPORTANT:
     * It it critical that the license key is appropriate for the version of the
     * Xceed WPF DataGrid being used. The digits following "DGP" indicate the 
     * latest version that this key is appropriate for.  This key can be used for
     * earlier versions as well.
     * 
     * If we upgrade to a version greater than this key supports, the Xceed WPF
     * DataGrid features for that version of the key will be unlocked, however
     * any features for the later version will run in trial-mode, and once that
     * time has elapsed those features will be disabled.
     * =============================================================================
     * Information pertaining to the license as well as all license key information
     * can be found on the Common Tag Feature Teams SharePoint site.  
	 * =============================================================================
     */
    public static class XceedDeploymentLicense
    {	
        /// <summary>
        /// Sets the Xceed WPF Data Grid license key.
        /// </summary>		 
        public static void SetLicense()
        {
            try
            {
                Xceed.Wpf.DataGrid.Licenser.LicenseKey = "DGP512D4PXU44MP2UXA";
#if DEBUG
                LogWrapper.DibStartUpLog.Debug("Active Xceed license key: " + Xceed.Wpf.DataGrid.Licenser.LicenseKey);
#else
                LogWrapper.DibStartUpLog.Debug("Active Xceed license key: " + Xceed.Wpf.DataGrid.Licenser.LicenseKey.Substring(0, 5) + "...");
#endif
            }
            catch (LicenseException licenseException)
            {
                LogWrapper.LogException("Unable to set the Xceed WPF DataGrid license key.", licenseException);
            }
        }

        /// <summary>
        /// Get the active license key. If in debug full license key is returned, else only partial.
        /// </summary>
        public static string ActiveLicenseKey
        {
#if DEBUG
            get { return Xceed.Wpf.DataGrid.Licenser.LicenseKey; }
#else
            get { return Xceed.Wpf.DataGrid.Licenser.LicenseKey.Substring(0, 5) + "..."; }
#endif 
        }

    }
}
