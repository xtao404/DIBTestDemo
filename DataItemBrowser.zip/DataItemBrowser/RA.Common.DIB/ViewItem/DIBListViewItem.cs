﻿using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// This class is a GUI object that is intended to be used in the ListView
    /// </summary>
    public class DIBListViewItem : DIBViewItemBase
    {
        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public DIBListViewItem(DataItemBase dataItem)
                :base(dataItem)
        {
        }

        #endregion
    }
}
