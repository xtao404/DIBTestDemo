﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using TagFilterControl.Common;
using TagFilterControl.Controls.PreFilterManager.Common;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.LaunchIn5000.PreFilterControl;
using TagFilterControl.UserControls;

namespace TagFilterControl
{
    public class ContentControlViewModel : BaseViewModel
    {
        private Config config = Config.GetInstance();

        public ContentControlViewModel()
        {
            this.FilterContent = new PreFilterDIBManagerUserControl();
        }

        private FrameworkElement filterContent;
        public FrameworkElement FilterContent
        {
            get { return filterContent; }
            set
            {
                filterContent = value;
                this.RaisePropertyChangedEvent(() => this.FilterContent);
            }
        }

        public ICommand CreateCommand
        {
            get
            {
                return new CustomCommand(
                    () =>
                    {
                        this.FilterContent = new PreConfigFilterDIBUserControl(null);
                        this.DIBManagerBottomButtonVisibility = Visibility.Hidden;
                        this.DIBConfigBottomButtonVisibility = Visibility.Visible;
                    });
            }
        }

        private CustomCommand editCommand;
        public CustomCommand EditCommand
        {
            get
            {
                return this.editCommand ?? (this.editCommand = new CustomCommand(
                    () =>
                    {
                        try
                        {
                            PreFilterDIBItem selectItem = config.CurrentSelectItem;
                            if (selectItem == null)
                            {
                                selectItem = config.FilterItems.FirstOrDefault();
                            }
                            this.FilterContent = new PreConfigFilterDIBUserControl(selectItem.Profile);
                            this.DIBManagerBottomButtonVisibility = Visibility.Hidden;
                            this.DIBConfigBottomButtonVisibility = Visibility.Visible;
                        }
                        catch (Exception)
                        {
                        }
                    }));
            }
        }

        private CustomCommand deleteCommand;
        public CustomCommand DeleteCommand
        {
            get
            {
                return this.deleteCommand ?? (this.deleteCommand = new CustomCommand(() =>
                {
                    try
                    {
                        PreFilterDIBItem selectItem = config.CurrentSelectItem;
                        if (selectItem == null)
                        {
                            selectItem = config.FilterItems.FirstOrDefault();
                        }

                        config.FilterItems.Remove(selectItem);
                        config.FilterItem.Remove(selectItem.Profile);
                    }
                    catch (Exception)
                    {
                    }
                }));
            }
        }

        private CustomCommand cancelCommand;
        public CustomCommand CancelCommand
        {
            get
            {
                return this.cancelCommand ?? (this.cancelCommand = new CustomCommand(() =>
                {
                    this.FilterContent = new PreFilterDIBManagerUserControl();
                    this.DIBManagerBottomButtonVisibility = Visibility.Visible;
                    this.DIBConfigBottomButtonVisibility = Visibility.Hidden;
                }));
            }
        }

        private CustomCommand saveCommand;
        public CustomCommand SaveCommand
        {
            get
            {
                return this.saveCommand ?? (this.saveCommand = new CustomCommand(() =>
                {
                    config.ConvertDIBManagerPageAction = () =>
                    {
                        if (config.ValidFlag)
                        {
                            this.FilterContent = new PreFilterDIBManagerUserControl();
                            this.DIBManagerBottomButtonVisibility = Visibility.Visible;
                            this.DIBConfigBottomButtonVisibility = Visibility.Hidden;
                        }
                    };
                    config.SaveCommandAction();
                }));
            }
        }

        private CustomCommand launchCommand;
        public CustomCommand LaunchCommand
        {
            get
            {
                return this.launchCommand ?? (this.launchCommand = new CustomCommand(() =>
                {
                    FilterAction();

                    config.IsFirstToFilterDIBControl = true;
                    this.DIBFilterContent = new FilterDIB();
                    this.IsOpen = true;
                }));
            }
        }

        private void FilterAction()
        {
            PreFilterDIBItem selectItem = config.CurrentSelectItem;
            if (selectItem == null)
            {
                selectItem = config.FilterItems.FirstOrDefault();
            }

            if (selectItem != null)
            {
                var profile = new FilterProfile()
                {
                    ID = selectItem.Profile.ID,
                    Name = selectItem.Profile.Name,
                    Content = selectItem.Profile.Content,
                    FilterContent = selectItem.Profile.FilterContent
                };

                config.SelectFilterProfile = profile;
            }
        }

        private FrameworkElement dibFilterContent;
        public FrameworkElement DIBFilterContent
        {
            get { return dibFilterContent; }
            set
            {
                dibFilterContent = value;
                this.RaisePropertyChangedEvent(() => this.DIBFilterContent);
            }
        }

        private bool isOpen;
        public bool IsOpen
        {
            get { return isOpen; }
            set
            {
                isOpen = value;
                this.RaisePropertyChangedEvent(() => this.IsOpen);
            }
        }

        private Visibility dibManagerBottomButtonVisibility = Visibility.Visible;
        public Visibility DIBManagerBottomButtonVisibility
        {
            get { return dibManagerBottomButtonVisibility; }
            set
            {
                this.dibManagerBottomButtonVisibility = value;
                this.RaisePropertyChangedEvent(() => this.DIBManagerBottomButtonVisibility);
            }
        }

        private Visibility dibConfigBottomButtonVisibility = Visibility.Hidden;
        public Visibility DIBConfigBottomButtonVisibility
        {
            get { return dibConfigBottomButtonVisibility; }
            set
            {
                this.dibConfigBottomButtonVisibility = value;
                this.RaisePropertyChangedEvent(() => this.DIBConfigBottomButtonVisibility);
            }
        }
    }
}
