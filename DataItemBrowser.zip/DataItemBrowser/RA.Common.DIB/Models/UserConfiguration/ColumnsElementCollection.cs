﻿using System.Configuration;

namespace RockwellAutomation.UI.UserConfiguration
{
    /// <summary>
    /// This supports the creation of multiple ColumnElement elements that
    /// can be indexed by the Key of the ColumnElement, or by its position.
    /// </summary>
    [ConfigurationCollection(typeof(ColumnElement), AddItemName = "Column",
    CollectionType = ConfigurationElementCollectionType.BasicMap)]
    //[ConfigurationCollection(typeof(ColumnElement),
    //CollectionType = ConfigurationElementCollectionType.AddRemoveClearMap)]
    public class ColumnsElementCollection : ConfigurationElementCollection
    {
        #region Constructor
        public ColumnsElementCollection()
        {
        }
        #endregion Constructor

        #region Fields
        private static ConfigurationPropertyCollection _properties = new ConfigurationPropertyCollection();
        #endregion Fields

        #region Properties
        protected override ConfigurationPropertyCollection Properties
        {
            get { return _properties; }
        }

        public override ConfigurationElementCollectionType CollectionType
        {
            get { return ConfigurationElementCollectionType.BasicMap; }
            //get { return ConfigurationElementCollectionType.AddRemoveClearMap; }
        }

        // Used for BasicMap
        protected override string ElementName
        {
            get
            {
                return "Column";
            }
        }
        #endregion Properties

        #region Indexers
        /// <summary>
        /// Get the ColumnConfig element by its position
        /// </summary>
        public ColumnElement this[int index]
        {
            get { return (ColumnElement)base.BaseGet(index); }
            set
            {
                if (base.BaseGet(index) != null)
                {
                    // Must remove before inserting
                    base.BaseRemoveAt(index);
                }
                base.BaseAdd(index, value);
            }
        }

        /// <summary>
        /// Get the ColumnConfig element by its Key
        /// </summary>
        public new ColumnElement this[string name]
        {
            get { return (ColumnElement)base.BaseGet(name); }
        }
        #endregion Indexers

        #region Overrides
        protected override ConfigurationElement CreateNewElement()
        {
            return new ColumnElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return (element as ColumnElement).Key;
        }
        #endregion Overrides

        #region Methods
        public void Add(ColumnElement column)
        {
            base.BaseAdd(column);
        }

        public void Remove(string name)
        {
            base.BaseRemove(name);
        }

        public void Remove(ColumnElement thing)
        {
            base.BaseRemove(GetElementKey(thing));
        }

        public void Clear()
        {
            base.BaseClear();
        }

        public void RemoveAt(int index)
        {
            base.BaseRemoveAt(index);
        }

        public string GetKey(int index)
        {
            return (string)base.BaseGetKey(index);
        }
        #endregion
    }
}
