﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using TagFilterControl.DIBClientManagers.DataGridViewSimple.LogixServices;
using RSLogix5000ServicesLib;

namespace TagFilterControl.Utility
{
    public class ACDHelper
    {
        private static ACDHelper instance = new ACDHelper();
        private ACDHelper()
        {
            logixService.InitialiseInstance();
        }

        public static ACDHelper GetInstance()
        {
            if (instance == null)
            {
                instance = new ACDHelper();
            }
            return instance;
        }

        private LogixService logixService = LogixService.GetInstance();

        public IController Controller { get; private set; }

        public string Path { get; set; }

        private void LoadACD()
        {
            try
            {
                object logixServices;
                string version = logixService.GetACDSupportedRevision(Path);
                logixServices = logixService.GetInstance(version);
                lgxOpenInfo openInfo = lgxOpenInfo.lgxOpenInfo_OpenFailed;
                Controller = (IController)logixServices.GetType().InvokeMember("OpenEx", System.Reflection.BindingFlags.InvokeMethod, null, logixServices, new object[3] { Path, lgxOpenMode.lgxOpenMode_OpenOriginal, openInfo });
            }
            catch (Exception)
            {
            }
        }

        public XmlDocument ConvertACDToXML()
        {
            LoadACD();
            XmlDocument xmlDoc = new XmlDocument();
            lgxExportOptions exportOptions = lgxExportOptions.LgxExport_DecoratedData |
                                            lgxExportOptions.LgxExport_ExtendedProperties |
                                            lgxExportOptions.LgxExport_UIds |
                                            lgxExportOptions.LgxExport_NoRawData |
                                            lgxExportOptions.LgxExport_AllProjDocTrans |
                                            lgxExportOptions.LgxExport_Reserved1 |
                                            lgxExportOptions.LgxExport_L5KData |
                                            lgxExportOptions.LgxExport_ProductDefinedTypes;

            RSLogix5000ServicesLib.lgxExportStatus finalStatus;
            string xmlString = this.Controller.ExportXMLToString(
                this.Controller.UId,
                string.Empty,
                exportOptions,
                true,
                out finalStatus);

            xmlDoc.LoadXml(xmlString);
            return xmlDoc;
        }
    }
}
