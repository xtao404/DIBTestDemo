﻿using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using System;

namespace RockwellAutomation.UI
{
    public class ColumnConfig
    {
        public ColumnConfig() {}

        // Internal name of column - matches element in dataitem
        private string _fieldName = String.Empty;
        public string FieldName
        {
            get { return _fieldName; }
            set { _fieldName = value; }
        }

        // Title will be the viewable column header - internationalized
        private string _title = String.Empty;
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        // 0 based location of column in column header
        // By convention the 0th column is the main column
        private int _visiblePosition = -1;
        public int VisiblePosition
        {
            get { return _visiblePosition; }
            set { _visiblePosition = value; }
        }

        // if true then the column is visible
        private bool _visible = false;
        public bool Visible
        {
            get { return _visible; }
            set { _visible = value; }
        }

        // Should the column be shown in the column chooser
        private bool _showInColumnChooser = true;
        public bool ShowInColumnChooser
        {
            get { return _showInColumnChooser; }
            set { _showInColumnChooser = value; }
        }

        // What is the minimum width of the column?
        // Default value = not set
        private double _minWidth = double.NaN;
        public double MinWidth
        {
            get { return _minWidth; }
            set { _minWidth = value; }
        }

        // What is the current width of the column?
        // Default value = not set
        private double _currentWidth = double.NaN;
        public double CurrentWidth
        {
            get { return _currentWidth; }
            set { _currentWidth = value; }
        }

        // Is the text in this column to wrap?
        // Default value = not set
        private bool _wrapping = false;
        public bool Wrapping
        {
            get { return _wrapping; }
            set { _wrapping = value; }
        }

        // Sort Direction of the column - ascending (0), descending (1), none(2)
        // Default value = none
		private SortDirection _sortDirection = SortDirection.None;
		public SortDirection SortDirection
        {
            get { return _sortDirection; }
            set { _sortDirection = value; }
        }

        // Sort Index of the column - primary sort = 0, secondary sort = 1, tertiary sort = 2, ...
        //                            not sorted = -1
        // Default value = not sorted
        private int _sortIndex = -1;
        public int SortIndex
        {
            get { return _sortIndex; }
            set { _sortIndex = value; }
        }
    }
}
