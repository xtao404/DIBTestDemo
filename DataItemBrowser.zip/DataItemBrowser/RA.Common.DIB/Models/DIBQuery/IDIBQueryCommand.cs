﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.DIBQuery
{
    /// <summary>
    /// IDIBQueryRequest interface definition.
    /// IDIBQueryRequest allows request to QSP to be represented as an object.
    /// </summary>
    public interface IDIBQueryCommand
    {
        /// <summary>
        /// Represents the QueryRequest sent to QSP
        /// </summary>
        /// <returns>QueryRequest</returns>
        QueryRequest CurrentQueryRequest
        {
            get;
        }

        /// <summary>
        /// Used to determine whether to cache results when the command completes.
        /// If we cache results, then the breadcrumb drop down list will display alternate paths from previous paths we already visited
        /// </summary>
        /// <returns>Whether to cache query results or not</returns>
        bool CacheQueryResults
        {
            get;
        }

        /// <summary>
        /// The type of query we are executing as defined in QSP.
        /// </summary>
        /// <returns>PredefinedQueryType</returns>
        PredefinedQueryType QueryType();

        /// <summary>
        /// The ParentDataItem representing the parent of the current command.
        /// If we are executing a query to drillinto a tag, this would reptesent the tag we are drilling into.
        /// If we are executing a query for all devices, this would be null
        /// </summary>
        /// <returns>DataItemBase</returns>
        DataItemBase ParentDataItem();

        /// <summary>
        /// The resource type of the item we are drilling into
        /// </summary>
        /// <returns>UUID of resource type</returns>
        UUID ParentResourceTypeId();

        /// <summary>
        /// A unique id representing this command. 
        /// </summary>
        /// <returns>ulong</returns>
        ulong GetRequestID();

        /// <summary>
        /// Execute our command on the queryConnection specified.
        /// This will execute the query in QSP using the queryConnection supplied.
        /// Query results will be provided by a callback from QSP that will be processed by queryConnection
        /// </summary>
        /// <param name="cds"></param>
        /// <param name="queryConnection">Used to call QSP to execute our command</param>
        void Execute(IClientDataServices cds);

        /// <summary>
        /// Perform any work needed after query has executed and response received from QSP 
        /// </summary>
        void CleanUp();
    }
}
