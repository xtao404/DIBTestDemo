﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for LighteningColorConverterTest and is intended
    ///to contain all LighteningColorConverterTest Unit Tests
    ///</summary>
    [TestClass()]
    public class LighteningColorConverterTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        //Method not implemented
        ///// <summary>
        /////A test for ConvertBack
        /////</summary>
        //[TestMethod()]
        //public void ConvertBackTest()
        //{
        //    LighteningColorConverter target = new LighteningColorConverter(); 
        //    object value = null; 
        //    Type targetTypes = null; 
        //    object param = null; 
        //    CultureInfo culture = null; 
        //    object expected = null; 
        //    object actual;
        //    actual = target.ConvertBack(value, targetTypes, param, culture);
        //    Assert.AreEqual(expected, actual);
        //    Assert.Inconclusive("Verify the correctness of this test method.");
        //}

        [TestMethod()]
        public void TestLighteningColorConverter()
        {
            LighteningColorConverter converter = new LighteningColorConverter(); 
            //Color startColor = new Color();

        ///A test for Convert
        ///
        ///         THIS TEST HAS BEEN OBVIATED BECAUSE THE SystemColor.HighlightBrush used in the Convert method
        ///         CAN VARY DEPENDING ON THE OPERATING SYSTEM ON WHICH IT IS BEING EXECUTED.
        ///         THIS LIGHTENING WILL NOW BE TESTED VIA A COLORADJUSTER TEST (AdjustColorTest_LighteningColor())
        //    Type targetType = typeof(Color); 
        //    CultureInfo culture = null; 
        //    Color expected = new Color(); 
        //    expected.A = 191;
        //    expected.R = 63;
        //    expected.G = 191;
        //    expected.B = 255;
        //    Color actual = (Color)target.Convert(startColor as object, targetType, 0.75, culture);
        //    Assert.AreEqual(expected, actual);
            // testing ConvertBack
            try
            {
                converter.ConvertBack(null, null, null, null);
            }
            catch (NotSupportedException exception)
            {
                Assert.AreEqual("Not supported", exception.Message);
            }
        }

        /// <summary>
        ///A test for LighteningColorConverter Constructor
        ///</summary>
        [TestMethod()]
        public void LighteningColorConverterConstructorTest()
        {
            LighteningColorConverter target = new LighteningColorConverter();
            Assert.AreNotEqual(target, null);
        }
    }
}
