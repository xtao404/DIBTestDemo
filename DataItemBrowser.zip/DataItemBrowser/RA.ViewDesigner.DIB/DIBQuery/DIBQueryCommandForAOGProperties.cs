﻿/* ****************************************************************************
*
*  Copyright 2016 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using System.Collections.Generic;

namespace RockwellAutomation.UI.DIBQuery
{
    class DIBQueryCommandForAOGProperties : DIBQueryCommandForViewe
    {
        #region "Creation/Init"

        public DIBQueryCommandForAOGProperties(QueryRequest.CreateBuilder queryRequestBuilder)
            : base(queryRequestBuilder)
        {
            CacheQueryResults = true;
        }

        #endregion

        #region "Base Overides"

        public override PredefinedQueryType QueryType()
        {
            if (ParentDataItem() != null && ParentDataItem().CommonResourceType == TypeIdentifiers.ResourceType_AOG.ToString())
            {
                return PredefinedQueryType.AllMembersForType;
            }

            return PredefinedQueryType.Undefined;
        }

        public override QueryConditionConfig GenerateQueryCondition(IClientDataServices cds)
        {

            if (ParentDataItem() != null && ParentDataItem().CommonResourceType == TypeIdentifiers.ResourceType_AOG.ToString())
            {
                string dataType = ParentDataItem().CommonDataType;

                //remove controller name if it exists
                int dotIndex = dataType.IndexOf('.');

                if (dotIndex > 0)
                {
                    dataType = dataType.Substring(dotIndex + 1);
                }


                QueryConditionConfig queryCondition = new QueryConditionConfig.CreateBuilder()
                    .AddConditionItem(new QueryConditionItem.CreateBuilder()
                        .SetIdentifier(DIResource.DI_COMMON_IDENTIFIER_DISPLAY_NAME)
                        .SetValue(dataType)
                        .SetLogicOperator(LogicOperatorType.AND)
                        .SetIsExactMatch(true)
                        .Build())
                    .Build();
                return queryCondition;
            }
            return null;
        }

        public override void Execute(IClientDataServices cds, IDIBQueryConnection queryConnection)
        {
            if (this.ParentDataItem() != null && this.ParentDataItem().CommonName != DIBClientManagerForViewe.Instance.AOGScreenName)
            {
                base.Execute(cds, queryConnection);
            }
            else
            {
                List<Models.DIBQuery.AOGItem> propertyList = DIBClientManagerForViewe.Instance.AOGItemList;
                foreach (Models.DIBQuery.AOGItem item in propertyList)
                {
                    DataItemBase itemDetails = new DataItemBase();
                    itemDetails.CommonName = item.ItemName;
                    itemDetails.CommonID = TypeIdentifiers.ResourceType_AOG.ToString();
                    itemDetails.CommonDataType = item.DataType;
                    itemDetails.CommonDescription = item.Description;
                    itemDetails.GUISupportsDrillIn = string.IsNullOrEmpty(item.DataType) ? "False" : "True";
                    itemDetails.GUISupportsSelection = "True";
                    itemDetails.CommonResourceType = TypeIdentifiers.ResourceType_AOG.ToString();
                    itemDetails.IsStructured = string.IsNullOrEmpty(item.DataType) ? false : true;
                    cds.QueryCache.AddDataItem(itemDetails);
                }
                ExecuteNonDBQueryResponse(queryConnection, cds.QueryCache);
            }
        }

        #endregion
    }
}
