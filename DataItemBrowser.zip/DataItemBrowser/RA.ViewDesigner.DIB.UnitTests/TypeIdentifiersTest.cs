﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RockwellAutomation.ServiceFramework.DataTypes;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for TypeIdentifiersTest and is intended
    ///to contain all TypeIdentifiersTest Unit Tests
    ///</summary>
    [TestClass()]
    public class TypeIdentifiersTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        // The following tests validate that if ct_dib changes a guid that is keyed into a database guid
        // something will break.

        /// <summary>
        ///A test for ResourceType_AOG
        ///</summary>
        [TestMethod()]
        public void getResourceType_AOGTest()
        {
            string expected = "hi: 13996149388021876831\nlo: 11684363924858740875\n"; 
            string actual;
            actual = TypeIdentifiers.ResourceType_AOG.ToString();
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for ResourceType_Alarm
        ///</summary>
        [TestMethod()]
        public void getResourceType_AlarmTest()
        {
            string expected = "hi: 16032615772887271170\nlo: 9867271880688580092\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_Alarm.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for getResourceType_Controller
        ///</summary>
        [TestMethod()]
        public void getResourceType_ControllerTest()
        {
            string expected = "hi: 8181955947408408666\nlo: 11502104724403191811\n";
            string actual;
            actual = TypeIdentifiers.getResourceType_Controller().ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_DataLog
        ///</summary>
        [TestMethod()]
        public void getResourceType_DataLogTest()
        {
            string expected = "hi: 12264130642010325784\nlo: 12185027975708363051\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_DataLog.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for getResourceType_DataLogs
        ///</summary>
        [TestMethod()]
        public void getResourceType_DataLogsTest()
        {
            string expected = "hi: 13089104315883274929\nlo: 10127117652173305247\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_DataLogs.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_DataType
        ///</summary>
        [TestMethod()]
        public void getResourceType_DataTypeTest()
        {
            string expected = "hi: 8181955947408408666\nlo: 11502104724403257360\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_DataType.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_DataTypeMember
        ///</summary>
        [TestMethod()]
        public void getResourceType_DataTypeMemberTest()
        {
            string expected = "hi: 8181955947408408666\nlo: 11502104724403257361\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_DataTypeMember.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_Database
        ///</summary>
        [TestMethod()]
        public void getResourceType_DatabaseTest()
        {
            string expected = "hi: 1566780146978933969\nlo: 13650850560392922945\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_Database.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_Device
        ///</summary>
        [TestMethod()]
        public void getResourceType_DeviceTest()
        {
            string expected = "hi: 8181955947408408666\nlo: 11502104724403191810\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_Device.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_HMIDevice
        ///</summary>
        [TestMethod()]
        public void getResourceType_HMIDeviceTest()
        {
            string expected = "hi: 8181955947408408666\nlo: 11502104724403191825\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_HMIDevice.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_LogixObject
        ///</summary>
        [TestMethod()]
        public void getResourceType_LogixObjectTest()
        {
            string expected = "hi: 8181955947408408666\nlo: 11502104724403257345\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_LogixObject.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_ProductDB
        ///</summary>
        [TestMethod()]
        public void getResourceType_ProductDBTest()
        {
            string expected = "hi: 11944790873796330490\nlo: 12965492671023786677\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_ProductDB.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_Program
        ///</summary>
        [TestMethod()]
        public void getResourceType_ProgramTest()
        {
            string expected = "hi: 8181955947408408666\nlo: 11502104724403257348\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_Program.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_Programs
        ///</summary>
        [TestMethod()]
        public void getResourceType_ProgramsTest()
        {
            string expected = "hi: 10569621170477223634\nlo: 12188386191288849582\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_Programs.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_Screen
        ///</summary>
        [TestMethod()]
        public void getResourceType_ScreenTest()
        {
            string expected = "hi: 5609122170359727717\nlo: 10016747083824068934\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_Screen.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_Screens
        ///</summary>
        [TestMethod()]
        public void getResourceType_ScreensTest()
        {
            string expected = "hi: 9447405734490034024\nlo: 13803189857550133427\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_Screens.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_Tag
        ///</summary>
        [TestMethod()]
        public void getResourceType_TagTest()
        {
            string expected = "hi: 8181955947408408666\nlo: 11502104724403257376\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_Tag.ToString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for ResourceType_TagsAndProperties
        ///</summary>
        [TestMethod()]
        public void getResourceType_TagsAndPropertiesTest()
        {
            string expected = "hi: 17334120166104580409\nlo: 10307459619794856573\n";
            string actual;
            actual = TypeIdentifiers.ResourceType_TagsAndProperties.ToString();
            Assert.AreEqual(expected, actual);

        }
    }
}
