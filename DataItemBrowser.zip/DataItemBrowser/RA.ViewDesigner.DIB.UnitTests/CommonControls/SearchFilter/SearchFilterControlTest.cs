﻿using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows;
using RockwellAutomation.UI;
using RockwellAutomation.UI.CommonControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using AvalonUnitTesting;
using RockwellAutomation.UI.CommonControls.ViewModels;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for SearchFilterControlTest and is intended
    ///to contain all SearchFilterControlTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SearchFilterControlTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        /// <summary>
        /// SearchFilterControl UI data binding check.
        /// </summary>
        [TestMethod()]
        public void SearchFilterControl_DataBindingIsCorrectTest()
        {
            AvalonTestRunner.RunInSTA(delegate()
            {
                // Create the control using a delegate to ensure binding errors generated during
                // control creation are caught.
                Func<object> controlCreator = delegate()
                {
                    // what ever your control is called
                    SearchFilterControl control = new SearchFilterControl();
                    return control;
                };

                AvalonTestRunner.RunDataBindingTests(controlCreator);
            });
        }

        /// <summary>
        ///A test for SearchFilterControl Constructor
        ///</summary>
        [TestMethod()]
        public void SearchFilterControlConstructorTest()
        {
            SearchFilterControl target = new SearchFilterControl();
            Assert.IsFalse(target.ShouldAutoOpenContextMenusOnFocus,"ShouldAutoOpenContextMenusOnFocus should be false");
            Assert.IsFalse(target.IgnoreNextTextBoxKeyEvent,"IgnoreNextTextBoxKeyEvent should be false");
            Assert.IsFalse(target.IsMRUListScrollingHorizontally, "IsMRUListScrollingHorizontally should be false");
            
        }

        /// <summary>
        /// filter types used by parse method
        /// </summary>
        private ObservableCollection<FilterType> _filterTypes = null;

        /// <summary>
        /// private method to generate the valid filter types
        /// </summary>
        private void GenerateFilterTypes()
        {
            _filterTypes = new ObservableCollection<FilterType>();
            _filterTypes.Add(new FilterType(DIBConstants.Common.Name, true, false));
            _filterTypes.Add(new FilterType(DIBConstants.Common.DataType, false, false));
            _filterTypes.Add(new FilterType(DIBConstants.Common.Description, true, false));
        }

        /// <summary>
        ///A test for ExecuteFilter
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void ExecuteFilter_TimerFalse_ValidSearchTextTest()
        {
            SearchFilterControl target = new SearchFilterControl(); // TODO: Initialize to an appropriate value
            PrivateObject targetPrivate = new PrivateObject(target);
            GenerateFilterTypes();
            SearchFilterControlViewModel searchFilterControlVM = new SearchFilterControlViewModel(_filterTypes);
            targetPrivate.SetFieldOrProperty("_viewModel", searchFilterControlVM);

            PrivateObject searchFilterTextBox = new PrivateObject(targetPrivate.GetFieldOrProperty("SearchFilterTextBox"));
            searchFilterTextBox.SetFieldOrProperty("Text", "N:test");
            bool fromTimer = false; // TODO: Initialize to an appropriate value
            targetPrivate.Invoke("ExecuteFilter", fromTimer);
            //check MRU list 
            Assert.IsTrue(searchFilterControlVM.SearchMruListHasItems, "MRU list should not be empty");
            //check currentState
            Assert.AreEqual(SearchFilterControlViewModel.FilterState.Searching, searchFilterControlVM.CurrentState, "current state should be searching");
            
        }
        /// <summary>
        ///A test for ExecuteFilter
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void ExecuteFilter_TimerFalse_InValidSearchTextTest()
        {
            SearchFilterControl target = new SearchFilterControl(); // TODO: Initialize to an appropriate value
            PrivateObject targetPrivate = new PrivateObject(target);
            GenerateFilterTypes();
            SearchFilterControlViewModel searchFilterControlVM = new SearchFilterControlViewModel(_filterTypes);
            targetPrivate.SetFieldOrProperty("_viewModel", searchFilterControlVM);

            PrivateObject searchFilterTextBox = new PrivateObject(targetPrivate.GetFieldOrProperty("SearchFilterTextBox"));
            searchFilterTextBox.SetFieldOrProperty("Text", "N:(test");
            bool fromTimer = false; // TODO: Initialize to an appropriate value
            targetPrivate.Invoke("ExecuteFilter", fromTimer);
            //check MRU list 
            Assert.IsFalse(searchFilterControlVM.SearchMruListHasItems, "MRU list should be empty");
            //check currentState
            Assert.AreEqual(SearchFilterControlViewModel.FilterState.Initial, searchFilterControlVM.CurrentState, "current state should be Initial");
            //check that SearchErrorIndicatorMessage exists
            Assert.IsNotNull(searchFilterControlVM.SearchErrorIndicatorMessage);
            Assert.IsTrue(searchFilterControlVM.SearchErrorIndicatorMessage.Length > 0);

        }
       
        /// <summary>
        ///A test for SearchFilterControl converter
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterControl_Converters_StringToTooltipConverter()
        {
            StringToTooltipConverter converter = new StringToTooltipConverter();

            string tooltip = (string)converter.Convert(string.Empty, null, null, CultureInfo.CurrentCulture);
            Assert.IsNull(tooltip);

            tooltip = (string)converter.Convert("       ", null, null, CultureInfo.CurrentCulture);
            Assert.IsNull(tooltip);

            string errorstring = "Some real error string";
            tooltip = (string)converter.Convert(errorstring, null, null, CultureInfo.CurrentCulture);
            Assert.AreEqual(tooltip, errorstring);

            tooltip = (string)converter.ConvertBack("anything", null, null, CultureInfo.CurrentCulture);
            Assert.IsNull(tooltip);

        }



    }
}
