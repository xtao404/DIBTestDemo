﻿using System;
using System.Windows;


namespace PopUpGenericTestHost
{
    /// <summary>
    /// The presenter class to support a property editor with a tag browser popup
    /// </summary>
    public class PropertyEditorWithTagBrowserPresenter : DependencyObject
    {

        #region Constructor
        /// <summary>
        /// constructor
        /// </summary>

        public PropertyEditorWithTagBrowserPresenter()
        {
        }
        #endregion Constructor

        #region calcualte window locatioin

        /// <summary>
        /// calculates the top/left corner of the browser based on the starting location, 
        /// editor offset and browser size
        /// </summary>
        /// <param name="targetPoint">starting topleft point</param>
        /// <param name="editorOffset">size of editing element that launched the browser</param>
        /// <param name="browserSize">size of browser window</param>
        /// <returns></returns>
        public static Point CalculateBrowserLocation(Point targetPoint, Size editorOffset, Size browserSize)
        {
            //set the base top and left point 
            Point topLeft = new Point(targetPoint.X, targetPoint.Y + editorOffset.Height);

            //get screen height and width
            Double screenWidth = System.Windows.SystemParameters.VirtualScreenWidth;
            Double screenHeight = System.Windows.SystemParameters.VirtualScreenHeight;

            //with the way the browser is launched there are only 2 conditions that the 
            //browser would need to be moved
            //1. If the browser is clipped by the right of the screen
            //2. If the browser is clipped by the top of the screen 
            //if tag browser right point is off the screen push it back on the screen
            if (topLeft.X + browserSize.Width > screenWidth)
                topLeft.X = screenWidth - browserSize.Width;
            //if tag browser top point is off the screen push it back on the screen
            if (topLeft.Y + browserSize.Height > screenHeight)
                topLeft.Y = topLeft.Y - editorOffset.Height - browserSize.Height;

            return topLeft;
        }
        #endregion calcualte window locatioin


    }
}
