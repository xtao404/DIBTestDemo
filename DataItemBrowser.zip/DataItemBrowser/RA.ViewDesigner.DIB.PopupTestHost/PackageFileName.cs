﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RockwellAutomation.ServiceFramework.DataTypes;
using System.IO;
using System.ComponentModel;

namespace PopupTestHost
{
    class PackageFileName : INotifyPropertyChanged
    {
        private string _uri;
        private UUID _packageId;
        private UUID _projectId;
        private string _content;
        private string _creationInfo;
        
        public PackageFileName(string uri, UUID packageId, UUID projectId)
        {
            _uri = uri;
            _packageId = packageId;
            _projectId = projectId;
            
            _content      = String.Empty;
            _creationInfo = String.Empty;

            if (File.Exists(uri))
            {
                _creationInfo = ("Created " + File.GetCreationTime(uri).ToString());
            }
            else
            {
                _content = "File not found";
            }
        }

        public string FullPath
        {
            get
            {
                return _uri;
            }
        }

        public string Content
        {
            get
            {
                return _content.Trim();
            }
        }

        public string CreationInfo
        {
            get
            {
                return _creationInfo;
            }
        }

        public bool IsOpen
        {
            get
            {
                return PackageId != null;
            }
        }

        public UUID PackageId
        {
            get
            {
                return _packageId;
            }
            set
            {
                _packageId = value;
                NotifyPropertyChanged("IsOpen");
            }
        }

        public UUID ProjectId
        {
            get
            {
                return _projectId;
            }
            set
            {
                _projectId = value;
            }
        }

        #region INotifyPropertyChanged Members
        /// <summary>
        /// implements that INotifyPropertyChanged inteface method NotifyPropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
