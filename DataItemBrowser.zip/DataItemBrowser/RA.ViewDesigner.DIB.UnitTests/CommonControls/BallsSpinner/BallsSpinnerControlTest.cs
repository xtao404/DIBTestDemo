﻿using System;
using System.Threading;
using System.Windows;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AvalonUnitTesting;
using RockwellAutomation.UI.CommonControls;

namespace DataItemBrowserUT
{
    [TestClass]
    public class BallsSpinnerControlTest
    {
        
        /// <summary>
        /// BallsSpinnerControl UI data binding check.
        /// </summary>
        [TestMethod()]
        public void BallSpinnerControl_DataBindingIsCorrectTest()
        {
            AvalonTestRunner.RunInSTA(delegate()
            {
                // Create the control using a delegate to ensure binding errors generated during
                // control creation are caught.
                Func<object> controlCreator = delegate()
                {
                    // what ever your control is called
                    BallsSpinnerControl control = new BallsSpinnerControl();
                    return control;
                };

                AvalonTestRunner.RunDataBindingTests(controlCreator);                
            });
            
        }

        ///// <summary>
        ///// Start the spinner
        ///// </summary>
        //[TestMethod()]
        //public void BallSpinner_Start_Spinning_Test()
        //{ ***NOTE: test failing when run with all the tests, maybe a setup/tear down issue?***
        //    BallsSpinnerControl control = new BallsSpinnerControl();
           
        //    Assert.AreEqual(Visibility.Visible, control.Visibility, "The spinner is not visible.");
          
        //    Assert.IsTrue(control.IsSpinning(),"Ball should be spinning");
            
        //}

        /// <summary>
        /// Stop the spinner
        /// </summary>
        [TestMethod()]
        public void BallSpinner_Stop_NotSpinning_Test()
        {
            BallsSpinnerControl control = new BallsSpinnerControl();
            control.Start();
            if (BallsSpinnerControl.IsSpinning())
            {
                control.Stop();
                Assert.IsFalse(BallsSpinnerControl.IsSpinning(), "Ball should not be spinning");
            }
            else
            {
                Assert.Fail("Can't stop spinning since it never started.");
            }

        }
    }
}
