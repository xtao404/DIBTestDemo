﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Globalization;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for CrumbEnabledConverterTest and is intended
    ///to contain all CrumbEnabledConverterTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CrumbEnabledConverterTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for ConvertBack
        ///</summary>
        [TestMethod()]
        public void CrumbEnabledConverter_ConvertBackTest()
        {
            //NOT implemented
        }

        /// <summary>
        ///A test for Convert
        ///</summary>
        [TestMethod()]
        public void CrumbEnabledConverter_ConvertTest_false()
        {
            CrumbEnabledConverter target = new CrumbEnabledConverter(); 
            bool expected = false; 
            bool isLast = true;
            bool isActive = true;

            object[] values = new object[] { isLast, isActive };

            object actual = target.Convert(values, null, null, null);
            Assert.AreEqual(expected,(bool) actual);
        }

        /// <summary>
        ///A test for Convert
        ///</summary>
        [TestMethod()]
        public void CrumbEnabledConverter_ConvertTest_true()
        {
            CrumbEnabledConverter target = new CrumbEnabledConverter();
            bool expected = true;
            bool isLast = false;
            bool isActive = true;

            object[] values = new object[] { isLast, isActive };

            object actual = target.Convert(values, null, null, null);
            Assert.AreEqual(expected, (bool)actual);
        }
    }
}
