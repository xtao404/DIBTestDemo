
#region references

using System.Windows.Input;
using System.ComponentModel;
using System;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.Models;
using System.Collections.Generic;
using System.Windows;


#endregion

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// View model supporting the <c>DataSourcesView</c>
    /// </summary>
    public class DIBListViewModel_4_TreeViewToListView : DIBListViewModel
    {
        #region "Constructor"

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">DataItemBrowser View Model</param>
        public DIBListViewModel_4_TreeViewToListView(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
        }

        #endregion

        #region Event Handlers

        override public void DoubleClickSelection(DataItemBase selectedNameDIB)
        {
            MessageBox.Show("You clicked on " + selectedNameDIB.ToString());

            base.DoubleClickSelection(selectedNameDIB);
        } 

        #endregion Event Handlers

    }
}
