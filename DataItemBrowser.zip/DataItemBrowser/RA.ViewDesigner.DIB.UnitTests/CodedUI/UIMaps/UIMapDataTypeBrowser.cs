﻿namespace DataItemBrowserUT.CodedUI.UIMaps.UIMapDataTypeBrowserClasses
{
    using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
    using Microsoft.VisualStudio.TestTools.UITesting.WpfControls;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Windows.Input;
    using System.CodeDom.Compiler;
    using System.Text.RegularExpressions;
    using Microsoft.VisualStudio.TestTools.UITest.Extension;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
    using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
    using MouseButtons = System.Windows.Forms.MouseButtons;


    public partial class UIMapDataTypeBrowser
    {

        /// <summary>
        /// DTB_KeyboardNav - Use 'DTB_KeyboardNavParams' to pass parameters into this method.
        /// </summary>
        public void DTB_KeyboardNav()
        {
            #region Variable Declarations
            WinWindow uIDataItemBrowserHostWWindow1 = this.UIDataItemBrowserHostWWindow1;
            WpfEdit uISearchFilterTextBoxEdit = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UISearchFilterTextBoxEdit;
            WpfButton uIClearSearchBtnButton = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIClearSearchBtnButton;
            WpfCustom uILocationCustom = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataGridViewTable.UISINT_ScalarArrayPane.UILocationCustom;
            WpfCustom uIDataItemBrowserContrCustom = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom;
            WpfTable uIDataGridViewTable = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataGridViewTable;
            WpfCustom uINameCustom = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataGridViewTable.UIUDT_ShortDescrPane.UINameCustom;
            WpfCustom uINameCustom1 = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataGridViewTable.UIAmbiguous_UDTPane.UINameCustom;
            WpfTitleBar uICommonTagPopupTestHoTitleBar = this.UICommonTagPopupTestHoWindow.UICommonTagPopupTestHoTitleBar;
            WpfButton uIFilterBuilderBtnButton = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIFilterBuilderBtnButton;
            #endregion

            // Click 'DataItemBrowser Host Window' window
            Mouse.Click(uIDataItemBrowserHostWWindow1, new Point(223, 3));

            // Type 'Control + F' in 'DataItemBrowser Host Window' window
            Keyboard.SendKeys(uIDataItemBrowserHostWWindow1, this.DTB_KeyboardNavParams.UIDataItemBrowserHostWWindow1SendKeys, ModifierKeys.Control);

            // Type 'array' in 'SearchFilterTextBox' text box
            uISearchFilterTextBoxEdit.Text = this.DTB_KeyboardNavParams.UISearchFilterTextBoxEditText;

            // Type '{Tab}' in 'SearchFilterTextBox' text box
            Keyboard.SendKeys(uISearchFilterTextBoxEdit, this.DTB_KeyboardNavParams.UISearchFilterTextBoxEditSendKeys, ModifierKeys.None);

            // Type '{Enter}' in 'ClearSearchBtn' button
            Keyboard.SendKeys(uIClearSearchBtnButton, this.DTB_KeyboardNavParams.UIClearSearchBtnButtonSendKeys, ModifierKeys.None);

        }

        public virtual DTB_KeyboardNavParams DTB_KeyboardNavParams
        {
            get
            {
                if ((this.mDTB_KeyboardNavParams == null))
                {
                    this.mDTB_KeyboardNavParams = new DTB_KeyboardNavParams();
                }
                return this.mDTB_KeyboardNavParams;
            }
        }

        private DTB_KeyboardNavParams mDTB_KeyboardNavParams;

        /// <summary>
        /// DTB_ConnectString_AddText - Use 'DTB_ConnectString_AddTextParams' to pass parameters into this method.
        /// </summary>
        public void DTB_ConnectString_AddText(string connectString)
        {
            #region Variable Declarations
            this.DTB_ConnectString_AddTextParams.UIDataType1_EditBoxEditText = connectString;
            WpfEdit uIDataType1_EditBoxEdit = this.UICommonTagPopupTestHoWindow.UIDataType1_EditBoxEdit;
            #endregion

            // Type in 'DataType1_EditBox' text box
            uIDataType1_EditBoxEdit.Text = this.DTB_ConnectString_AddTextParams.UIDataType1_EditBoxEditText;
        }

        public virtual DTB_ConnectString_AddTextParams DTB_ConnectString_AddTextParams
        {
            get
            {
                if ((this.mDTB_ConnectString_AddTextParams == null))
                {
                    this.mDTB_ConnectString_AddTextParams = new DTB_ConnectString_AddTextParams();
                }
                return this.mDTB_ConnectString_AddTextParams;
            }
        }

        private DTB_ConnectString_AddTextParams mDTB_ConnectString_AddTextParams;

       
    }
    /// <summary>
    /// Parameters to be passed into 'DTB_KeyboardNav'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DTB_KeyboardNavParams
    {

        #region Fields
        /// <summary>
        /// Type 'Control + F' in 'DataItemBrowser Host Window' window
        /// </summary>
        public string UIDataItemBrowserHostWWindow1SendKeys = "F";

        /// <summary>
        /// Type 'array' in 'SearchFilterTextBox' text box
        /// </summary>
        public string UISearchFilterTextBoxEditText = "array";

        /// <summary>
        /// Type '{Tab}' in 'SearchFilterTextBox' text box
        /// </summary>
        public string UISearchFilterTextBoxEditSendKeys = "{Tab}";

        /// <summary>
        /// Type '{Enter}' in 'ClearSearchBtn' button
        /// </summary>
        public string UIClearSearchBtnButtonSendKeys = "{Enter}";


        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DTB_ConnectString_AddText'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DTB_ConnectString_AddTextParams
    {

        #region Fields
        /// <summary>
        /// Type in 'DataType1_EditBox' text box
        /// </summary>
        public string UIDataType1_EditBoxEditText = string.Empty;
        #endregion
}
}
