﻿using System;
using System.Reflection;
using RockwellAutomation.UI.UserConfiguration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Configuration;
using System.Collections.Generic;
using System.IO;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.Common;
//using RockwellAutomation.Client.Services.Query.Common;
//using RockwellAutomation.Client.Services.Query.AbstractItem;
//using RockwellAutomation.Client.Services.Query;

namespace DataItemBrowserUT
{
    
    /// <summary>
    ///This is a test class for UserConfigurationIOTest and is intended
    ///to contain all UserConfigurationIOTest Unit Tests
    ///</summary>
    [TestClass()]
    public class UserConfigurationIOTest
    {

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SaveWindowSize and ReadWindowSize
        ///</summary>
        [TestMethod()]
        public void SaveAndReadWindowSizeTest()
        {
            int height = 1000; 
            int heightExpected = 1000; 
            int width = 2000; 
            int widthExpected = 2000;
            UserConfigurationIO.SaveWindowSize(height, width);
            UserConfigurationIO.ReadWindowSize(ref heightExpected, ref widthExpected);
            Assert.AreEqual(height, heightExpected, "SaveAndReadWindowSizeTest failed - height not saved or read correctly");
            Assert.AreEqual(width, widthExpected, "SaveAndReadWindowSizeTest failed - width not saved or read correctly");
        }

        /// <summary>
        ///A test for SaveColumnConfiguration and ReadColumnConfiguration
        ///</summary>
        [TestMethod()]
        public void SaveAndReadColumnConfigurationTest()
        {
            // Delete curren user.config so we have a clean slate
            DeleteUserConfigFileTest();
 
            Dictionary<string, ColumnConfig> userChanges = GenerateColumnConfig();
            UserConfigurationIO.SaveColumnConfiguration(userChanges);

            Dictionary<string, ColumnConfig> actual;
            actual = UserConfigurationIO.ReadColumnConfiguration();

            ColumnConfig expectedConfig = null;
            ColumnConfig actualConfig = null;
            foreach (KeyValuePair<string, ColumnConfig> cfg in userChanges)
            {
                expectedConfig = cfg.Value;
                actualConfig = actual[cfg.Key];
                // Assert.AreEqual was failing for some reason
                Assert.IsTrue( CompareColumnConfigs(expectedConfig, actualConfig), "SaveAndReadColumnConfigurationTest failed - Saving or Reading column configuration failed");
            }
        }

        /// <summary>
        /// Validate the default user.config values
        ///</summary>
        [TestMethod()]
        public void ValidateDefaultValuesTest()
        {
            // Delete curren user.config so we have a clean slate
            DeleteUserConfigFileTest();

            int height = 0;
            int width = 0;
            UserConfigurationIO.ReadWindowSize(ref height, ref width);
            Assert.AreEqual(height, 300, "ValidateDefaultValuesTest failed - default height invalid");
            Assert.AreEqual(width, 415, "ValidateDefaultValuesTest failed - default width invalid");

            Dictionary<string, ColumnConfig> columns = UserConfigurationIO.ReadColumnConfiguration();
            Assert.AreEqual(0, columns.Count, "ValidateDefaultValuesTest failed - no columns exist");

        }

        /// <summary>
        /// Assert.AreEqual was failing for some reason so this method was created
        /// </summary>
        /// <param name="expectedConfig"></param>
        /// <param name="actualConfig"></param>
        /// <returns></returns>
        private bool CompareColumnConfigs(ColumnConfig expectedConfig, ColumnConfig actualConfig)
        {
            bool result = false;
            if ((expectedConfig.FieldName == actualConfig.FieldName) &&
                (expectedConfig.CurrentWidth == actualConfig.CurrentWidth) &&
                (expectedConfig.MinWidth == actualConfig.MinWidth) &&
                (expectedConfig.ShowInColumnChooser == actualConfig.ShowInColumnChooser) &&
                (expectedConfig.SortDirection == actualConfig.SortDirection) &&
                (expectedConfig.SortIndex == actualConfig.SortIndex) &&
                (expectedConfig.Title == actualConfig.Title) &&
                (expectedConfig.Visible == actualConfig.Visible) &&
                (expectedConfig.VisiblePosition == actualConfig.VisiblePosition) &&
                (expectedConfig.Wrapping == actualConfig.Wrapping))
            {
                result = true;
            }

            return result;
        }

        /// <summary>
        /// Generate a dictionary of 3 ColumnConfigs
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, ColumnConfig> GenerateColumnConfig()
        {
            // Note Title, MinWidth, ShowInColumnChooser and Wrapping are not persisted but default values are set
            Dictionary<string, ColumnConfig> columnConfig = new Dictionary<string, ColumnConfig>();

            // For the data type of TAG, setup the default column configuration.
            ColumnConfig cc = new ColumnConfig();
            cc.FieldName = DIBConstants.Common.Name;
            cc.Title = "";
            cc.MinWidth = 0;
            cc.CurrentWidth = DIResource.DI_COMMON_COLUMNCONFIG_MIN_WIDTH;
            cc.ShowInColumnChooser = false;
            cc.Visible = true;
            cc.VisiblePosition = 0;
            cc.Wrapping = false;
            cc.SortDirection = RockwellAutomation.Client.Services.Query.SortDirection.Ascending;
            cc.SortIndex = 0;
            columnConfig.Add("cmn_" + DIBConstants.Common.Name, cc);

            cc = new ColumnConfig();
            cc.FieldName = DIBConstants.Common.DataType;
            cc.Title = "";
            cc.CurrentWidth = DIResource.DI_COMMON_COLUMNCONFIG_DATATYPE_WIDTH;
            cc.MinWidth = 0;
            cc.ShowInColumnChooser = false;
            cc.Visible = true;
            cc.VisiblePosition = 1;
            cc.Wrapping = false;
            cc.SortDirection = RockwellAutomation.Client.Services.Query.SortDirection.None;
            cc.SortIndex = -1;
            columnConfig.Add("cmn_" + DIBConstants.Common.DataType, cc);
            
            cc = new ColumnConfig();
            cc.FieldName = DIBConstants.Common.Description;
            cc.Title = "";
            cc.CurrentWidth = DIResource.DI_COMMON_COLUMNCONFIG_CURRENT_WIDTH;
            cc.MinWidth = 0;
            cc.Visible = true;
            cc.ShowInColumnChooser = false;
            cc.VisiblePosition = 2;
            cc.Wrapping = false;
            cc.SortDirection = RockwellAutomation.Client.Services.Query.SortDirection.Descending;
            cc.SortIndex = -1;
            columnConfig.Add("cmn_" + DIBConstants.Common.Description, cc);

            return columnConfig;
        }

        /// <summary>
        ///A test for DeleteUserConfigFile
        ///</summary>
        [TestMethod()]
        public void DeleteUserConfigFileTest()
        {
            // Make sure user.config exists
            PrivateType configType = new PrivateType(typeof (UserConfigurationIO));
            configType.InvokeStatic("Initialize");
            Configuration roamingConfig = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
            Assert.IsTrue(File.Exists(roamingConfig.FilePath), "DeleteUserConfigFileTest failed - user.config was not created");

            string errMsg = string.Empty; 
            string errMsgExpected = "Worked"; 
            bool expected = true; 
            bool actual;
            
            object[] args = new object[1];
            args[0] = errMsg;
            actual = (bool)configType.InvokeStatic("DeleteUserConfigFile", new [] { typeof(string).MakeByRefType() }, args);
                
            Assert.AreEqual(errMsgExpected, args[0]);
            Assert.AreEqual(expected, actual);
            Assert.IsFalse(File.Exists(roamingConfig.FilePath), "DeleteUserConfigFileTest failed - user.config still exists");
        }
    }
}
