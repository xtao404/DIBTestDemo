﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using RockwellAutomation.ServiceFramework.DataTypes;

namespace RockwellAutomation.UI
{
	/// <summary>
	/// Common class for sharing resource UUIDS
	/// </summary>
	/// <remarks>
	/// The UUID values are hardcoded as static long values
	/// The static long values are then used to create the individual UUID values.
	/// The hard coded static long values are an unsigned long representation of the Type UUID from the
	/// product_library schema for the given type.
    /// 
    /// Those UUIDs designated ROA should match the constants found in
    /// ...\ct_query_rt\src\ct_query_rt\dotnet\Query\Query\Resources\QueryUtils.cs
	/// </remarks>
	public static class TypeIdentifiers
	{
		#region ResourceType_Device
        // Specified by ROA 
		// <ItemType UUID="718c2595-952c-405a-9f9f-af4e5b650002" Name="Device" DisplayName="Device" Description="Any Device in the ViewE System">
        // "hi: 8181955947408408666\nlo: 11502104724403191810\n"
		private static UUID DEVICE_UUID = UUID.CreateBuilder().SetHi(0x718c2595952c405aL).SetLo(0x9f9faf4e5b650002L).Build();

		public static UUID ResourceType_Device
		{
            get { return DEVICE_UUID; }
		}

		#endregion

		#region ResourceType_Controller
        // Specified by ROA
		// <ItemType UUID="718c2595-952c-405a-9f9f-af4e5b650003" Name="Controller" DisplayName="Controller" Description="Logix Controller" ParentType="718c2595-952c-405a-9f9f-af4e5b650002">
        // "hi: 8181955947408408666\nlo: 11502104724403191811\n"
		private static UUID CONTROLLER_UUID = UUID.CreateBuilder().SetHi(0x718c2595952c405aL).SetLo(0x9f9faf4e5b650003L).Build();

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate",Justification = "used in too many places, do later")]
        public static UUID getResourceType_Controller()
		{
			return CONTROLLER_UUID;
		}

		#endregion

        #region ResourceType_HMIDevice
        // Specified by ROA
        // <ItemType UUID="718c2595-952c-405a-9f9f-af4e5b650011" Name="HMI Device" DisplayName="HMI Device" Description="HMI Device" ParentType="718c2595-952c-405a-9f9f-af4e5b650002">
        // "hi: 8181955947408408666\nlo: 11502104724403191825\n"
        private static UUID HMIDEVICE_UUID = UUID.CreateBuilder().SetHi(0x718c2595952c405aL).SetLo(0x9f9faf4e5b650011L).Build();

        public static UUID ResourceType_HMIDevice
        {
            get { return HMIDEVICE_UUID; }
        }

        #endregion

        #region ResourceType_DataType
        // Specified by ROA
		// <ItemType UUID="718c2595-952c-405a-9f9f-af4e5b660010" Name="DataType" DisplayName="Data Type" Description="" ParentType="718c2595-952c-405a-9f9f-af4e5b660001">
        // "hi: 8181955947408408666\nlo: 11502104724403257360\n"
		private static UUID DATATYPE_UUID = UUID.CreateBuilder().SetHi(0x718c2595952c405aL).SetLo(0x9f9faf4e5b660010L).Build();

		public static UUID ResourceType_DataType
		{
            get { return DATATYPE_UUID; }
		}

		#endregion

		#region ResourceType_DataTypeMember
        // Specified by ROA
		// <ItemType UUID="718c2595-952c-405a-9f9f-af4e5b660011" Name="DataTypeMember" DisplayName="Data Type Member" Description="" ParentType="718c2595-952c-405a-9f9f-af4e5b660001">
        // "hi: 8181955947408408666\nlo: 11502104724403257361\n"
		private static UUID MEMBER_UUID = UUID.CreateBuilder().SetHi(0x718c2595952c405aL).SetLo(0x9f9faf4e5b660011L).Build();

		public static UUID ResourceType_DataTypeMember
		{
            get { return MEMBER_UUID; }
		}

		#endregion

		#region ResourceType_Program
        // Specified by ROA
		// <ItemType UUID="718c2595-952c-405a-9f9f-af4e5b660004" Name="Program" DisplayName="Program" Description="Logix Program" ParentType="718c2595-952c-405a-9f9f-af4e5b660001">
        // "hi: 8181955947408408666\nlo: 11502104724403257348\n"
		private static UUID PROGRAM_UUID = UUID.CreateBuilder().SetHi(0x718c2595952c405aL).SetLo(0x9f9faf4e5b660004L).Build();

		public static UUID ResourceType_Program
		{
            get { return PROGRAM_UUID; }
		}

		#endregion

		#region ResourceType_Tag
        // Specified by ROA
		// <ItemType UUID="718c2595-952c-405a-9f9f-af4e5b660020" Name="Tag" DisplayName="Tag" Description="" ParentType="718c2595-952c-405a-9f9f-af4e5b660001">
        // "hi: 8181955947408408666\nlo: 11502104724403257376\n"
		private static UUID TAG_UUID = UUID.CreateBuilder().SetHi(0x718c2595952c405aL).SetLo(0x9f9faf4e5b660020L).Build();

		public static UUID ResourceType_Tag
		{
            get { return TAG_UUID; }
		}

		#endregion

		#region ResourceType_LogixObject
        // Specified by ROA
		// <ItemType UUID="718c2595-952c-405a-9f9f-af4e5b660001" Name="LogixObject" DisplayName="Logix Object" Description="Abstraction / Base Class for any Logix Object">
        // "hi: 8181955947408408666\nlo: 11502104724403257345\n"
		private static UUID LOGIXOBJECT_UUID = UUID.CreateBuilder().SetHi(0x718c2595952c405aL).SetLo(0x9f9faf4e5b660001L).Build();

		public static UUID ResourceType_LogixObject
		{
            get { return LOGIXOBJECT_UUID; }
		}

		#endregion

		#region ResourceType_Alarm
        // Specified by ROA
		// <ItemType UUID="de7f4b19-db45-4702-88ef-977f16a4b5fc" Name="Alarm" Description="Top level alarm resource class.">
        // "hi: 16032615772887271170\nlo: 9867271880688580092\n"
		private static UUID ALARM_UUID = UUID.CreateBuilder().SetHi(0xde7f4b19db454702L).SetLo(0x88ef977f16a4b5fcL).Build();

		public static UUID ResourceType_Alarm
		{
            get { return ALARM_UUID; }
		}

		#endregion

		#region ResourceType_Database
        // Specified by ROA
		// <ItemType UUID="15be523e-15d0-4cd1-bd71-904266298741" Name="Database">
        // "hi: 1566780146978933969\nlo: 13650850560392922945\n"
		private static UUID DB_UUID = UUID.CreateBuilder().SetHi(0x15be523e15d04cd1L).SetLo(0xbd71904266298741L).Build();

		public static UUID ResourceType_Database
		{
            get { return DB_UUID; }
		}

		#endregion

		#region ResourceType_TagsAndProperties
        // DIB only
		// <ItemType UUID="F08F2A73-7299-4139-8F0B-73E9B68E2A7D" Name="Tags and Properties">
        // "hi: 17334120166104580409\nlo: 10307459619794856573\n"
		private static UUID TAGSPROPS_UUID = UUID.CreateBuilder().SetHi(0xF08F2A7372994139L).SetLo(0x8F0B73E9B68E2A7DL).Build();

		public static UUID ResourceType_TagsAndProperties
		{
            get { return TAGSPROPS_UUID; }
		}
		#endregion

        #region ResourceType_Programs
        // DIB only - Folders for Progams
        // <ItemType UUID="92AED674-4CBE-4ED2-A925-D8AA050C54AE" Name="Programs">
        // "hi: 10569621170477223634\nlo: 12188386191288849582\n"
        private static UUID PROGRAMS_UUID = UUID.CreateBuilder().SetHi(0x92AED6744CBE4ED2L).SetLo(0xA925D8AA050C54AEL).Build();

        public static UUID ResourceType_Programs
        {
            get { return PROGRAMS_UUID; }
        }
        #endregion

        #region ResourceType_DataLogs
        // DIB only - This represents the folder for DataLogs. This is just for the DIB. ROA has no need for this.
        // <ItemType UUID="B5A5D706-B841-42B1-8C8A-BFD95060B59F" Name="DataLogs" Description="The folder for DataLogs in the ViewE System">
        // "hi: 13089104315883274929\nlo: 10127117652173305247\n"
        private static UUID DATALOGS_UUID = UUID.CreateBuilder().SetHi(0xB5A5D706B84142B1L).SetLo(0x8C8ABFD95060B59FL).Build();
        public static UUID ResourceType_DataLogs
        {
            get { return DATALOGS_UUID; }
        }
        #endregion

        #region ResourceType_DataLog
        // Specified by ROA. This represents a single DataLog. 
        // <ItemType UUID="aa32f1d7-3c02-4318-a919-ea62864b492b" Name="DataLog" Description="Any DataLog in the ViewE System">
        // "hi: 12264130642010325784\nlo: 12185027975708363051\n"
        private static UUID DATALOG_UUID = UUID.CreateBuilder().SetHi(0xaa32f1d73c024318L).SetLo(0xa919ea62864b492bL).Build();
        public static UUID ResourceType_DataLog
        {
            get { return DATALOG_UUID; }
        }
        #endregion

        #region ResourceType_Screens
        // DIB only. This represents the screens folder. 
        // <ItemType UUID="831BED76-0544-4F68-BF8E-C80B028CE8B3" Name="Screens">
        // "hi: 9447405734490034024\nlo: 13803189857550133427\n"
        private static UUID SCREENS_UUID = UUID.CreateBuilder().SetHi(0x831BED7605444F68L).SetLo(0xBF8EC80B028CE8B3L).Build();

        public static UUID ResourceType_Screens
        {
            get { return SCREENS_UUID; }
        }
        #endregion

        #region ResourceType_Screen
        // Specified by ROA. This represents a single screen.
        // <ItemType UUID="4DD79AE5-420F-4665-8B02-A266D8437946" Name="Screen">
        // "hi: 5609122170359727717\nlo: 10016747083824068934\n"
        private static UUID SCREEN_UUID = UUID.CreateBuilder().SetHi(0x4DD79AE5420F4665L).SetLo(0x8B02A266D8437946L).Build();

        public static UUID ResourceType_Screen
        {
            get { return SCREEN_UUID; }
        }
        #endregion


        #region ResourceType_AOG
        // Specified by ROA. Not yet specified.
        // <ItemType UUID="C23C4FB6-B058-485F-A227-33154F98208B" Name="AOGss">
        // "hi: 13996149388021876831\nlo: 11684363924858740875\n"
        private static UUID AOG_UUID = UUID.CreateBuilder().SetHi(0xC23C4FB6B058485FL).SetLo(0xA22733154F98208BL).Build();

        public static UUID ResourceType_AOG
        {
            get { return AOG_UUID; }
        }
        #endregion


        #region ResourceType_ProductDB
        // Specified by ROA.
        // <ItemType UUID="a5c46c03-74f5-43fa-b3ee-aee3e24daab5" Name="ProductDB" Description="T">
        // "hi: 11944790873796330490\nlo: 12965492671023786677\n"
        private static UUID PRODUCT_DB_UUID = UUID.CreateBuilder().SetHi(11944790873796330490).SetLo(12965492671023786677).Build();

        public static UUID ResourceType_ProductDB
        {
            get { return PRODUCT_DB_UUID; }
        }

        #endregion
	}
}
