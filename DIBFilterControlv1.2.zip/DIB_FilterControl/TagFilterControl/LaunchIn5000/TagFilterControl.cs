﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PluginConnectorInterfacesLib;
using RSLogix5000ServicesLib;
using System.Xml.Linq;
using ACM.LogixServicesProvider.Interfaces;
using ACM.Shared.Common.COAModels;
using ACM.LogixServicesProvider.LogixCoa;
using System.Xml;
using TagFilterControl.Utility;
using ACM.LogixServicesProvider;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Controls;
using TagFilterControl.Common.Controls;

namespace TagFilterControl
{
    public partial class TagFilterControl : UserControl, IPluginConnector2
    {
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private Config config = Config.GetInstance();
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();

        public TagFilterControl()
        {
            InitializeComponent();
            this.logixServicesWrapper = LogixServicesProviderWrapper.GetInstance();
        }

        public bool Close()
        {
            Dispose();

            if (this.logixServicesWrapper != null)
            {
                ((LogixServicesProviderWrapper)logixServicesWrapper).InstanceShutDown(); 
                this.logixServicesWrapper = null;
            }
            return true;
        }

        private void Dispose()
        {
            filterDIBIn.DIBClientManager = null;
            config.IsCheckedTags.Clear();
            config.ACMCustomPropertiesTagOwnersFilter.Clear();
        }

        public int GetInitialHeight()
        {
            return 700;
        }

        public int GetInitialWidth()
        {
            return 700;
        }

        public int GetMinimumHeight()
        {
            return this.MinimumSize.Height;
        }

        public int GetMinimumWidth()
        {
            return this.MinimumSize.Width;
        }

        public string GetTitle()
        {
            return "Filter";
        }

        private ObjectTypesEnum selectedDataTypes;
        private IPluginHostConnector pluginHostConnector;
        private IServicesProvider logixServicesWrapper;

        public IList<Tuple<string, int>> SelectedUids { get; set; }

        public void Initialize(IPluginHostConnector pConnector, object pDispController, Array selectedUIDs, Array selectedObjectTypes, lgxOrganizationalModels organizationalModels)
        {
            int major = ((IController)pDispController).GetSoftwareMajorVersion();
            if ((major < 27 || major > 30))
            {
                MessageBox.Show(string.Format("ACD version '{0}' is not supported by this version of ACM. Please upgrade to the latest version of ACM.", major), "Failed to Launch Library Designer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (pConnector != null)
                {
                    pConnector.Close();
                }
                return;
            }

            try
            {
                int[] uids = (int[])selectedUIDs;
                string[] corespondingTypes = (string[])selectedObjectTypes;
                IList<Tuple<string, int>> selectedUids = new List<Tuple<string, int>>();
                this.pluginHostConnector = pConnector;

                for (int i = 0; i < selectedUIDs.Length; i++)
                {
                    selectedUids.Add(new Tuple<string, int>(corespondingTypes[i], uids[i]));
                }

                if (selectedUids != null && selectedUids.Count() > 0)
                {
                    this.logixServicesWrapper.Controller = pDispController;
                    this.logixServicesWrapper.PluginHostConnector = this.pluginHostConnector;
                    Enum.TryParse(corespondingTypes[corespondingTypes.Count() - 1], true, out this.selectedDataTypes);
                    this.SelectedUids = selectedUids;
                    this.logixServicesWrapper.SelectedUid = this.SelectedUids.LastOrDefault().Item2;
                    string loadingError = String.Empty;
                    ACM.LogixServicesProvider.LogixCoa.LogixCoa logixCoa = new ACM.LogixServicesProvider.LogixCoa.LogixCoa(this.logixServicesWrapper.Controller);
                    string cpVersion;
                    if (!logixCoa.CheckControllerCPVersion(out cpVersion))
                    {
                        MessageBox.Show(string.Format("Controller Custom Property version '{0}' is not supported by this version of ACM. Please upgrade to the latest version of ACM.", cpVersion), "Failed to Launch Library Designer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        if (pConnector != null)
                        {
                            pConnector.Close();
                        }
                        return;
                    }

                    CoaService.Coa = logixCoa.LoadLogixCoa(out loadingError);
                    int controllerUid = this.logixServicesWrapper.Controller.UId;
                    lgxExportOptions options = ExportOptionsForController();
                    for (int i = 0; i < this.SelectedUids.Count; i++)
                    {
                        Tuple<string, int> selectedObject = this.SelectedUids[i];
                        string xmlString = ((ILogixCoa)CoaService.Coa).ReadObjectData(selectedObject.Item2, options);
                        XmlDocument xmlDoc = new XmlDocument();
                        xmlDoc.LoadXml(xmlString);
                        xmlHelper.LoadTagsTreeStructure(xmlDoc);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public lgxExportOptions ExportOptionsForController()
        {
            lgxExportOptions options = lgxExportOptions.LgxExport_AllProjDocTrans |
                                        lgxExportOptions.LgxExport_ExtendedProperties |
                                        lgxExportOptions.LgxExport_UIds |
                                        lgxExportOptions.LgxExport_NoRawData |
                                        lgxExportOptions.LgxExport_Context |
                                        lgxExportOptions.LgxExport_Reserved1 |  
                                        lgxExportOptions.LgxExport_Dependencies |
                                        lgxExportOptions.LgxExport_References;  

            return options;
        }

        public void InitializeEx(IPluginHostConnector pConnector, object pDispController, string context)
        {
            try
            {
                XDocument docContext = XDocument.Parse(context);
                var vModel = from model in docContext.Descendants("OrganizationalModel")
                             select model.Value;
                var vObject = from pluginObject in docContext.Descendants("PluginObject")
                              select new
                              {
                                  uid = pluginObject.Element("UID").Value,
                                  type = pluginObject.Element("Type").Value
                              };

                List<uint> selectedUIDS = new List<uint>();
                List<string> selectedTypes = new List<string>();
                foreach (var plugin in vObject)
                {
                    selectedUIDS.Add(uint.Parse(plugin.uid));
                    selectedTypes.Add(plugin.type);
                }

                this.Initialize(pConnector, pDispController, selectedUIDS.ToArray(), selectedTypes.ToArray(), (lgxOrganizationalModels)Enum.Parse(typeof(lgxOrganizationalModels), vModel.FirstOrDefault()));
            }
            catch (Exception)
            {
            }
        }

        public void ResizeControl(int newWidth, int newHeight)
        {
            this.SuspendLayout();
            this.Width = newWidth;
            this.Height = newHeight;
            this.ResumeLayout();
        }

        public void Save()
        {
        }
    }

    public enum ObjectTypesEnum
    {
        All = 0x0,
        Controller = 0x2,
        DataType = 0x4,
        AddOnInstructionDefinition = 0x8,
        Tag = 0x10,
        Program = 0x20,
        Routine = 0x40,
        Rung = 0x80,
        Task = 0x100,
        Sheet = 0x200,
        Line = 0x400,
        SfcContent = 0x800,
        Module = 0x1000,
        Trend = 0x2000
    }
}
