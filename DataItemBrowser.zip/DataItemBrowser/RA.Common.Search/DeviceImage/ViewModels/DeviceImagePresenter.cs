/* ****************************************************************************
*
*  Copyright 2012 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/
#region references
using System;
using System.ComponentModel;
using System.Resources;
using System.Collections.Generic;

#endregion references

namespace RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels
{

    #region enumerations
    /// <summary>
    /// Display type enum used to determine display type (show or hide controller0
    /// </summary>
    public enum DisplayTypeEnum
    {
        /// <summary>
        /// device and status are visible
        /// </summary>
        ControllerAndStatus = 0,
        /// <summary>
        /// status only is visible
        /// </summary>
        StatusOnly
    }
    /// <summary>
    /// Image state enumeration
    /// </summary>
    public enum EnumImageState
    {
        /// <summary>
        /// device is synchronized
        /// </summary>
        SYNCHED = 0,
        /// <summary>
        /// device out of synchronization
        /// </summary>
        OUTOFSYNCH = 1,
        /// <summary>
        /// device is synchronizing
        /// </summary>
        SYNCHING = 2,
        /// <summary>
        /// device lost synchronization
        /// </summary>
        SYNCHLOST = 3,
        /// <summary>
        /// device has errors
        /// </summary>
        ERROR = 4,
        /// <summary>
        /// device has warnings
        /// </summary>
        WARNING = 5
    }

    #endregion enumerations
    /// <summary>
    /// this class displays the device image and also includes a decorator image to indicator if 
    /// the device is in one of these states, 
    /// </summary>
    public class DeviceImagePresenter :  INotifyPropertyChanged, IDisposable
    {
        #region private members

        private IDeviceStatus _device = null;

        #endregion private members

        #region ReplicationStateType

        //Local copies of integer based replication states, as we don't want this assembly
        // to have a reference to the RADeviceMessages dll where the enum for these is.
        // Clients are expected to call SetReplicationStateValues to provide the correct
        // values for the states defined here
        public class ReplicationStateType
        {
            //Represents the string value of the replication state (as defined externally)
            public string Value { get; set; }

            public static ReplicationStateType UNINITIATED { get; set; }
            public static ReplicationStateType EXTRACTING { get; set; }
            public static ReplicationStateType SYNCHED { get; set; }
            public static ReplicationStateType DETECTINGCHANGES { get; set; }
            public static ReplicationStateType NEEDSUPDATING { get; set; }
            public static ReplicationStateType UPDATING { get; set; }
            public static ReplicationStateType SYNCHLOST { get; set; }
            public static ReplicationStateType INDETERMINATE { get; set; }
            public static ReplicationStateType RESYNCHRONIZING { get; set; }
            public static ReplicationStateType EROA_UNINITIATED { get; set; }
            public static ReplicationStateType EROA_DATA { get; set; }

            //Dictionary to store mapping of replication values (ints) to ReplicationStateType objects so
            // that we ensure we only create a single instance of each one
            static Dictionary<string, ReplicationStateType> ReplicationStateValues = new Dictionary<string, ReplicationStateType>();

            /// <summary>
            /// Creates a new ReplicationStateType object based on the passed string value
            /// </summary>
            /// <param name="value">String representation of the replication state</param>
            /// <returns>The ReplicationStateType object representation of the passed string state</returns>
            public static implicit operator ReplicationStateType(string value)
            {
                if (!ReplicationStateValues.ContainsKey(value))
                    ReplicationStateValues[value] = new ReplicationStateType { Value = value };

                return FromString(value);
            }

            /// <summary>
            /// Returns the ReplicationStateType object corresponding to the passed string
            /// </summary>
            /// <param name="value">Replication type string to lookup the type object for</param>
            /// <returns>ReplicationStateType object corresponding to the passed string or
            /// INDETERMINATE if not found</returns>
            public static ReplicationStateType FromString(string value)
            {
                if (ReplicationStateValues.ContainsKey(value))
                {
                    return ReplicationStateValues[value];
                }

                return INDETERMINATE;
            }
        }

        #endregion ReplicationStateType

        #region properties

        //default replication state should correspond to default image state
        private ReplicationStateType _replicationState = ReplicationStateType.SYNCHED;
        /// <summary>
        /// the replication state of this device 
        /// </summary>                        
        public ReplicationStateType ReplicationState
        {
            get { return _replicationState; }
            set
            {
                if (_replicationState != value)
                {
                    _replicationState = value;
                    UpdateImageState();
                }
            }
        }

        //default replication state should correspond to default image state
        private EnumImageState _imageState = EnumImageState.SYNCHED;
        /// <summary>
        /// the image state property
        /// </summary>
        public EnumImageState ImageState
        {

            get { return _imageState; }
            internal set
            {
                if (_imageState != value)
                {
                    _imageState = value;
                    NotifyPropertyChanged("ImageState");
                }
            }
        }

        private string _replicationError = null;
        /// <summary>
        /// error property
        /// </summary>
        public string ReplicationError
        {
            get { return _replicationError; }
            internal set
            {
                if (_replicationError != value)
                {
                    _replicationError = value;
                    NotifyPropertyChanged("ReplicationError");
                    //update image state
                    UpdateImageState();

                }
            }
        }

        private string _tooltip = null;
        /// <summary>
        /// the tooltip property
        /// </summary>
        public string Tooltip
        {

            get { return _tooltip; }
            internal set
            {
                if (_tooltip != value)
                {
                    _tooltip = value;
                    NotifyPropertyChanged("Tooltip");
                }
            }
        }

        private bool _tooltipEnabled = false;
        /// <summary>
        /// the tooltip enabled property
        /// </summary>
        public bool TooltipEnabled
        {

            get { return _tooltipEnabled; }
            internal set
            {
                if (_tooltipEnabled != value)
                {
                    _tooltipEnabled = value;
                    NotifyPropertyChanged("TooltipEnabled");
                }
            }
        }

        private string _tooltipHeader = string.Empty;
        /// <summary>
        /// the tooltip header property
        /// </summary>
        public string TooltipHeader
        {

            get { return _tooltipHeader; }
            internal set
            {
                if (_tooltipHeader != value)
                {
                    _tooltipHeader = value;
                    NotifyPropertyChanged("TooltipHeader");
                }
            }
        }

        private string _tooltipHelpTopicID = String.Empty;
        /// <summary>
        /// the tooltip help topic ID property
        /// </summary>
        public string TooltipHelpTopicID
        {

            get { return _tooltipHelpTopicID; }
            internal set
            {
                if (_tooltipHelpTopicID != value)
                {
                    _tooltipHelpTopicID = value;
                    NotifyPropertyChanged("TooltipHelpTopicID");
                }
            }
        }
        #endregion properties

        #region constructor
        /// <summary>
        /// constructor
        /// </summary>
        public DeviceImagePresenter()
        {
        }
        #endregion constructor

        /// <summary>
        /// initialize this class
        /// </summary>
        /// <param name="device">device data model</param>
        public void Initialize(IDeviceStatus device)
        {
            if (device == null)
                return;

            //clean up old notifications
            if (_device != null)
                _device.PropertyChanged -= new PropertyChangedEventHandler(Controller_PropertyChanged);
 
            _device = device;
            ReplicationState = _device.ReplicationState;
            ReplicationError = _device.ReplicationError;

            //listen for device property changed events
            device.PropertyChanged += new PropertyChangedEventHandler(Controller_PropertyChanged);
        }

        /// <summary>
        /// device property changed method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Controller_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            IDeviceStatus c = (IDeviceStatus)sender;
            if (c == null)
                return;
            if (e.PropertyName == "ReplicationError")
                ReplicationError = c.ReplicationError;
            else if (e.PropertyName == "ReplicationState")
                ReplicationState = c.ReplicationState;
        }

        /// <summary>
        /// Called by client to inform the presenter on the correct enumeration values for
        /// all of the replication state definitions
        /// </summary>
        /// <param name="stateUninitiated">Defined value of UNINITIATED state</param>
        /// <param name="stateExtracting">Defined value of EXTRACTING state</param>
        /// <param name="stateSynched">Defined value of SYNCHED state</param>
        /// <param name="stateDetectingChanges">Defined value of DETECTINGCHANGES state</param>
        /// <param name="stateNeedsUpdating">Defined value of NEEDSUPDATING state</param>
        /// <param name="stateUpdating">Defined value of UPDATING state</param>
        /// <param name="stateSynchLost">Defined value of SYNCHLOST state</param>
        /// <param name="stateIndeterminate">Defined value of INDETERMINATE state</param>
        /// <param name="stateResynchronizing">Defined value of RESYNCHRONIZING state</param>
        /// <param name="stateEROAUninitiated">Defined value of EROA_UNINITIATED state</param>
        /// <param name="stateEROAData">Defined value of EROA_DATA state</param>
        public static void SetReplicationStateValues(string stateUninitiated,
                                                     string stateExtracting,
                                                     string stateSynched,
                                                     string stateDetectingChanges,
                                                     string stateNeedsUpdating,
                                                     string stateUpdating,
                                                     string stateSynchLost,
                                                     string stateIndeterminate,
                                                     string stateResynchronizing,
                                                     string stateEROAUninitiated,
                                                     string stateEROAData)
        {
            ReplicationStateType.UNINITIATED      = stateUninitiated;
            ReplicationStateType.EXTRACTING       = stateExtracting;
            ReplicationStateType.SYNCHED          = stateSynched;
            ReplicationStateType.DETECTINGCHANGES = stateDetectingChanges;
            ReplicationStateType.NEEDSUPDATING    = stateNeedsUpdating;
            ReplicationStateType.UPDATING         = stateUpdating;
            ReplicationStateType.SYNCHLOST        = stateSynchLost;
            ReplicationStateType.INDETERMINATE    = stateIndeterminate;
            ReplicationStateType.RESYNCHRONIZING  = stateResynchronizing;
            ReplicationStateType.EROA_UNINITIATED = stateEROAUninitiated;
            ReplicationStateType.EROA_DATA        = stateEROAData;
        }
        
        #region private helper methods
        /// <summary>
        /// update image based on replication state and error string
        /// </summary>
        private void UpdateImageState()
        {
            //Initially clear all tooltip info as it will get set below if needed
            this.TooltipEnabled = false;
            this.Tooltip = null;
            this.TooltipHeader = string.Empty;
            //super Tooltip is not supported in the DTC now, so do not set the help topic ID
            this.TooltipHelpTopicID = string.Empty;

            //Controller is invalid (errors) - show error state image
            if (!string.IsNullOrEmpty(ReplicationError))
            {
                this.ImageState = EnumImageState.WARNING;
                this.TooltipHeader = Properties.Resources.CONTROLLER_ERROR_HEADING;
                this.Tooltip = ReplicationError;
                this.TooltipEnabled = true;              
            }

            //If we're syncing, show the spinner (let the error message take precedence above since
            // with "auto-sync" we'd always be in one of these states although an error is preventing
            // the sync from really happening so showing the error to the user is more helpful than
            // showing a spinner when the error cause is fixed and the device really starts syncing.
            else if (ReplicationState == ReplicationStateType.EXTRACTING ||
                     ReplicationState == ReplicationStateType.UPDATING ||
                     ReplicationState == ReplicationStateType.RESYNCHRONIZING ||
                     ReplicationState == ReplicationStateType.EROA_DATA)
            {
                this.ImageState = EnumImageState.SYNCHING;
                this.TooltipEnabled = true;
                this.Tooltip = Properties.Resources.OUT_OF_SYNC_TIP2;
                this.TooltipHeader = Properties.Resources.OUT_OF_SYNC_HEADING;
            }
            //Device synced with no errors - do not show a state image
            else if(ReplicationState == ReplicationStateType.SYNCHED ||
                    ReplicationState == ReplicationStateType.DETECTINGCHANGES)
            {
                this.ImageState = EnumImageState.SYNCHED;
            }
            //Device is out of sync
            else if (ReplicationState == ReplicationStateType.UNINITIATED ||
                     ReplicationState == ReplicationStateType.NEEDSUPDATING ||
                     ReplicationState == ReplicationStateType.EROA_UNINITIATED ||
                     ReplicationState == ReplicationStateType.SYNCHLOST ||
                     ReplicationState == ReplicationStateType.INDETERMINATE)
            {
                this.ImageState = EnumImageState.OUTOFSYNCH;
                this.TooltipEnabled = true;
                this.Tooltip = Properties.Resources.OUT_OF_SYNC_TIP1;
                this.TooltipHeader = Properties.Resources.OUT_OF_SYNC_HEADING;
            }   
        }

        #endregion private helper methods

        #region implement IDisposable
        protected bool IsDisposed
        {
            get;
            private set;
        }

        // Implementing Design pattern for a base class
        // http://msdn.microsoft.com/en-us/library/b1yfkh5e%28v=vs.80%29.aspx
        //Implement IDisposable.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (IsDisposed)
                return;

            if (disposing)
            {
                // clean up managed resources here, you may also chain it to a private method in this class
                if (_device != null)
                    _device.PropertyChanged -= new PropertyChangedEventHandler(Controller_PropertyChanged);
                _device = null;
            }

            IsDisposed = true;
        }

        // Use C# destructor syntax for finalization code.
        ~DeviceImagePresenter()
        {
            Dispose(false);
        }
        #endregion dispose method

        #region INotifyPropertyChanged Members
        /// <summary>
        /// implements that INotifyPropertyChanged inteface method NotifyPropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
