using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using System.Diagnostics;
using System.Windows.Controls.Primitives;
using RockwellAutomation.UI.Views;
using RockwellAutomation.UI.Resources;
using RockwellAutomation.UI.Models;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace RockwellAutomation.UI.Windows  
{
    /// <summary>
    /// Interaction logic for DIBWindow.xaml
    /// </summary>
    public partial class DIBWindow : Window
    {
        #region private data
        private DataItemBrowserWindowViewModel _presenter;
        private DIBClientManager _clientManager;
        public DIBClientManager DIBClientManager {
            get { return _clientManager; }   
        }

        private bool _Closing;

        #endregion private data

        #region Properties
        /// <summary>
        /// Persist window dependency property 
        /// </summary>
        public readonly static DependencyProperty PresistWindowProperty = DependencyProperty.Register("PresistWindow", typeof(bool), typeof(DIBWindow),
                                        new PropertyMetadata(false));
        public bool PersistWindow
        {
            get
            {
                return ((bool)(base.GetValue(DIBWindow.PresistWindowProperty)));
            }
            set
            {
                base.SetValue(DIBWindow.PresistWindowProperty, value);
            }
        }

        /// <summary>
        /// SelectedItem property
        /// </summary>
        public string SelectedItem
        {
            get { return this.DataItemBrowserControl.SelectedItem; }
            set { this.DataItemBrowserControl.SelectedItem = value; }
        }

        /// <summary>
        /// SelectedDataItemBaseItem property
        /// </summary>
        public DataItemBase SelectedDataItemBase
        {
            get { return this.DataItemBrowserControl.SelectedDataItemBase; }
        }

        
        /// <summary>
        /// SelectedItemResourceIDProperty dependency property
        /// </summary>
        public static DependencyProperty SelectedItemResourceIDProperty = DependencyProperty.Register("SelectedItemResourceID",
                                typeof(CompositeDataItem), typeof(DIBWindow), new PropertyMetadata(null));
        public CompositeDataItem SelectedItemResourceID
        {
            get { return (CompositeDataItem)GetValue(DIBWindow.SelectedItemResourceIDProperty); }
            set { SetValue(DIBWindow.SelectedItemResourceIDProperty, value); }
        }


        /// <summary>
        /// HighlightedItem  property
        /// </summary>
        public string HighlightedItem
        {
            get { return this.DataItemBrowserControl.HighlightedItem; }
            set { this.DataItemBrowserControl.HighlightedItem = value; }
        }

        /// <summary>
        /// UserSetHighlightedItemProperty dependency property
        /// </summary>
        public static DependencyProperty UserSetHighlightedItemProperty = DependencyProperty.Register("UserSetHighlightedItem",
                                typeof(string), typeof(DIBWindow), new PropertyMetadata(null));
        public string UserSetHighlightedItem
        {
            get { return (string)GetValue(DIBWindow.UserSetHighlightedItemProperty); }
            set { SetValue(DIBWindow.UserSetHighlightedItemProperty, value); }
        }

        /// <summary>
        /// UserSetHighlightedItemResourceIDProperty dependency property
        /// </summary>
        public static DependencyProperty UserSetHighlightedItemResourceIDProperty = DependencyProperty.Register("UserSetHighlightedItemResourceID",
                                typeof(CompositeDataItem), typeof(DIBWindow), new PropertyMetadata(null));
        public CompositeDataItem UserSetHighlightedItemResourceID
        {
            get { return (CompositeDataItem)GetValue(DIBWindow.UserSetHighlightedItemResourceIDProperty); }
            set { SetValue(DIBWindow.UserSetHighlightedItemResourceIDProperty, value); }
        }
     
        #endregion Properties

        #region Event handling

        /// <summary>
        /// Event routing triggered when the user clicks on a hyperlink
        /// </summary>
        public static readonly RoutedEvent ItemSelectedEvent =
            EventManager.RegisterRoutedEvent("ItemSelected", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(DIBWindow));

        /// <summary>
        /// Provide CLR accessors for the DrillInClick event
        /// </summary>
        public event RoutedEventHandler ItemSelectedEventHandler
        {
            add { AddHandler(ItemSelectedEvent, value); }
            remove { RemoveHandler(ItemSelectedEvent, value); }
        }

        /// <summary>
        /// Raises the ItemSelected event
        /// </summary>
        private void RaiseItemSelectedEvent()
        {
            RoutedEventArgs args = new RoutedEventArgs(DIBWindow.ItemSelectedEvent);
            RaiseEvent(args);
        }

        private void OnItemSelected(object sender, RoutedEventArgs e)
        {
            RaiseItemSelectedEvent();
        }

        /// <summary>
        /// Event routing triggered when the user clicks on a hyperlink
        /// </summary>
        public static readonly RoutedEvent HighlightedItemChangedEvent =
            EventManager.RegisterRoutedEvent("HighlightedItemChanged", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(DIBWindow));

        /// <summary>
        /// Provide CLR accessors for the DrillInClick event
        /// </summary>
        public event RoutedEventHandler HighlightedItemChangedEventHandler
        {
            add { AddHandler(HighlightedItemChangedEvent, value); }
            remove { RemoveHandler(HighlightedItemChangedEvent, value); }
        }

        /// <summary>
        /// Raises the HighlightedItemChanged event
        /// </summary>
        private void RaiseHighlighedItemChangedEvent()
        {
            RoutedEventArgs args = new RoutedEventArgs(DIBWindow.HighlightedItemChangedEvent);
            RaiseEvent(args);
        }

        private void OnHighlightedItemChanged(object sender, RoutedEventArgs e)
        {
            RaiseHighlighedItemChangedEvent();
        }

        /// <summary>
        /// Event routing triggered when the user clicks on a hyperlink
        /// </summary>
        public static readonly RoutedEvent UserSetHighlightedItemChangedEvent =
            EventManager.RegisterRoutedEvent("UserSetHighlightedItemChanged", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(DIBWindow));

        /// <summary>
        /// Provide CLR accessors for the DrillInClick event
        /// </summary>
        public event RoutedEventHandler UserSetHighlightedItemChangedEventHandler
        {
            add { AddHandler(UserSetHighlightedItemChangedEvent, value); }
            remove { RemoveHandler(UserSetHighlightedItemChangedEvent, value); }
        }

        /// <summary>
        /// Raises the UserSetHighlightedItemChanged event
        /// </summary>
        private void RaiseUserSetHighlightedItemChangedEvent()
        {
            RoutedEventArgs args = new RoutedEventArgs(DIBWindow.UserSetHighlightedItemChangedEvent);
            RaiseEvent(args);
        }

        #endregion

        #region Constructor

        public void Initialize(string selectedItem)
        {
            DataItemBrowserContext.CreateBuilder contextBuilder = new DataItemBrowserContext.CreateBuilder(this._clientManager);
            DataItemBrowserContext diContext = contextBuilder.Build();

            this.DataItemBrowserControl.BrowserType = "tag";
            Initialize(diContext, selectedItem);
        }

        /// <summary>
        /// Initialize
        /// Given a datacontext  and a selecteditem , drive the DIB toward its first navigation.
        /// </summary>
        /// <param name="dibContext"></param>
        /// <param name="selectedItem"></param>
        public void Initialize(DataItemBrowserContext dibContext, string selectedItem)
        {
            LogWrapper.DibStartUpLog.Info("DIB starting up");

            StringBuilder trace = new StringBuilder();
            trace.AppendLine("Initialize DIB Window with:")
                .AppendLine("\t(PersistWindow=" + this.PersistWindow + ")")
                .AppendLine("\t(HomeContext=")
                .Append(dibContext!=null ? dibContext.ToString() : "null")
                .AppendLine("\t)")
                .AppendLine("\t(Highlighteditem=" + this.HighlightedItem + ")")
                .AppendLine("\t(UserSetHighlightedItem=" + this.UserSetHighlightedItem + ")")
                .AppendLine("\t(UserSetHighlightedItemResourceID=" + this.UserSetHighlightedItemResourceID + ")")
                .AppendLine("\t(SelectedItem=" + selectedItem + ")")
                .Append("\t(SelectedItemResourceID=" + this.SelectedItemResourceID + ")");

            _clientManager.InitializeDIBControlOnStartup(this.DataItemBrowserControl, trace);
            LogWrapper.LogTraceContainingNewLines(LogWrapper.DibStartUpLog, "Debug", trace.ToString());

            DataItemBrowserControl.Initialize(_clientManager, dibContext, selectedItem);
        }


        /// <summary>
        /// constructor
        /// For now this will default to CenterScreen, if reasons arise to change this it can be done at that time.
        /// </summary>
        /// 
        public DIBWindow(DIBClientManager dibClientManager)
        {
            // Set the Xceed WPF DataGrid licensing. This has to be done 'first' before
            // any other initialization occurs.
            XceedDeploymentLicense.SetLicense();

            InitializeComponent();
            _presenter = new DataItemBrowserWindowViewModel((int)this.MinHeight, (int)this.MinWidth);
            this.DataContext = _presenter;
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            _clientManager = dibClientManager;
        }


        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="parentElement">Parent element instatiating this window.</param>
        public DIBWindow(FrameworkElement parentElement, DIBClientManager dibClientManager)
        {
            // Set the Xceed WPF DataGrid licensing. This has to be done 'first' before
            // any other initialization occurs.            
            XceedDeploymentLicense.SetLicense();
            InitializeComponent();
            _presenter = new DataItemBrowserWindowViewModel((int)this.MinHeight, (int)this.MinWidth);
            this.DataContext = _presenter;
            _clientManager = dibClientManager;
            if (null != parentElement)
            {
                DataItemBrowserWindowViewModel.SetDPI(parentElement);

                // Determine the screen position based on the location of the property text
                // Get upper-left location
                Point locationFromScreen = parentElement.PointToScreen(new Point(0, 0));

                // Transform screen point to WPF device independent point
                PresentationSource source = PresentationSource.FromVisual(parentElement);

                //Transform WPF device independent point to relative to this control
                if (source != null)
                {
                    if (source.CompositionTarget != null)
                    {
                        Point targetPoint = source.CompositionTarget.TransformFromDevice.Transform(locationFromScreen);

                        // Calculate the position of the browser
                        // When persisted values are stored in user.config had to change CalculateBrowserLocation signature and
                        // not pass in a Size consisting of this.Height and this.Width.  this.Height and this.Width were NaNs.  They
                        // were not set at this time as they had been before  (timing issue).
                        Point topLeft = _presenter.CalculateBrowserLocation(targetPoint,
                                                                            new Size(parentElement.ActualWidth, parentElement.ActualHeight));
                        this.Top = topLeft.Y;
                        this.Left = topLeft.X;
                    }
                }
            }
            else
            {
                this.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            }
        }
        #endregion Constructor

        /// <summary>
        /// window loaded event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            //listen for the ItemSelected event from the DataItemBrowser
            this.DataItemBrowserControl.ItemSelected += new RoutedEventHandler(DataItemBrowserControl_ItemSelected);

            //listen for the highlighted item events from the DataItemBrowser
            this.DataItemBrowserControl.HighlightedItemChanged += new RoutedEventHandler(DataItemBrowserControl_HighlightedItemChanged);            
            
            this.DataItemBrowserControl.UserSetHighlightedItemChanged += new RoutedEventHandler(DataItemBrowserControl_UserSetHighlightedItemChanged);
        }

        /// <summary>
        /// Used in the lost keyboard focus handler to cache the previously FocusedElement
        /// </summary>
        private Visual _LastFocusedElement = null;

        /// <summary>
        /// Handle the OnLostKeyboardFocus to close this modeless window if necessary (handling
        /// the Window deactivated was not a viable solution as we got a rogue deactivate event
        /// when in the DTC environment when closing one of our context menus.  Additionally,
        /// using the lost keyboard focus method prevents the DIB from staying open when clicking
        /// on the top level menu of the Visual Studio shell which caused problems when closing
        /// the IDE (the are you sure you want to save dialog was suppressed if the DIB was shown)
        /// </summary>
        /// <param name="e">Standard KeyboardFocusChangedEventArgs from the framework</param>
        protected override void OnLostKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            base.OnLostKeyboardFocus(e);
 
            //Don't close if we are set to persist the window
            if (this.PersistWindow)
                return;
#if DEBUG
            else
            {
                //Don't close if we are in debug and TAF is open (helps in automation development)
                Process[] TafProcs = Process.GetProcessesByName("tafdesigner");
                if (TafProcs != null && TafProcs.Length > 0)
                    return;
            }
#endif

            //Check the current focused element and return right away if we don't want to
            // close (if no focused element, a different app has focus so okay to close)
            if (Keyboard.FocusedElement != null)
            {
                //Don't close if we are showing a child window (i.e. the datatype filter builder dialog)
                if (DataItemBrowserControl.ChildWindowOpen)
                {
                    _LastFocusedElement = Keyboard.FocusedElement as Visual;
                    return;
                }
                //Don't close if we lost keyboard focus to a hyperlink (special case since we can't call IsAncestorOf
                // on a hyperlink because it is not a Visual/Visual3d and thus would throw an exception)
                else if (Keyboard.FocusedElement is System.Windows.Documents.Hyperlink)
                {
                    DependencyObject LinkParent = LogicalTreeHelper.GetParent(Keyboard.FocusedElement as DependencyObject);
                    if(LinkParent!=null && IsAncestorOf(LinkParent))
                    {
                        _LastFocusedElement = LinkParent as Visual;
                        return;
                    }
                }
                //Don't close if we lost the keyboard focus to a child of us
                else if (IsAncestorOf(Keyboard.FocusedElement as DependencyObject))
                {
                    _LastFocusedElement = Keyboard.FocusedElement as Visual;
                    return;
                }
                //Don't close if we lost the keyboard focus to a context menu of ours
                else if (Keyboard.FocusedElement is ContextMenu)
                {
                    ContextMenu focusedContextMenu = Keyboard.FocusedElement as ContextMenu;
                    if (focusedContextMenu.PlacementTarget != null &&
                        IsAncestorOf(focusedContextMenu.PlacementTarget))
                    {
                        _LastFocusedElement = Keyboard.FocusedElement as Visual;
                        return;
                    }
                }
                //Check to make sure the parent of the focused element is a popup, the popup does
                //does not get the focus, the control inside the popup gets the focus
                else if (FindAncestor<Popup>(Keyboard.FocusedElement as FrameworkElement) != null)
                {
                    //If this window is the ancestor of the popup's placement target then 
                    //do not close the window
                    Popup focusedPopup = FindAncestor<Popup>(Keyboard.FocusedElement as FrameworkElement);
                    if (focusedPopup.PlacementTarget != null &&
                        IsAncestorOf(focusedPopup.PlacementTarget))
                    {
                        _LastFocusedElement = Keyboard.FocusedElement as Visual;
                        return;
                    }
                }
                //Check to see if the current focus is not a child of the previously focused element
                // If we did not close when this previous element was focused, we should not close
                // for a child of that element either (we see this for items within a popup)
                else if (_LastFocusedElement != null)
                {
                    if (_LastFocusedElement.IsAncestorOf(Keyboard.FocusedElement as DependencyObject))
                    {
                        return;
                    }
                }
            }

            //If we've made it through the checks above, perform actions to close the window
           
            //if we are already closing do not do it again (this only happens when we select an item)
            if (_Closing)
                return;

            // DFCTS00119788 -If the DIB window was resized by a TAF resize actor, window's size and actual size are out of sync
            _presenter.DIBWindow_Width = (int)this.ActualWidth;
            _presenter.DIBWindow_Height = (int)this.ActualHeight;

            // save the window's size
            this._presenter.SaveWindowSize();

            // Remove event handlers
            CleanupEventSubscriptions();
            
            //finally, close the window
            this.Close();
		}

        /// <summary>
        /// find the ancestor framework element that is of type T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="fe"></param>
        /// <returns></returns>
        public static T FindAncestor<T>(FrameworkElement fe) where T : FrameworkElement
        {
            while (fe != null)
            {
                T o = fe as T;
                if (o != null)
                    return o;
                fe = fe.Parent as FrameworkElement;
            }
            return null;
        }
		
        #region UserSetHighlightedItem Events

        /// <summary>
        /// User-driven highlighted item changed event from the dataitembrowser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void DataItemBrowserControl_UserSetHighlightedItemChanged(object sender, RoutedEventArgs e)
        {
            this.UserSetHighlightedItem = DataItemBrowserControl.UserSetHighlightedItem;
            this.UserSetHighlightedItemResourceID = DataItemBrowserControl.UserSetHighlightedItemResourceID;
            //Raise event so owner of this window can get the selected item            
            this.RaiseUserSetHighlightedItemChangedEvent();
        }
        #endregion UserSetHighlightedItem Events


        /// <summary>
        /// Remove event handlers
        /// </summary>
        private void CleanupEventSubscriptions()
        {
            DataItemBrowserControl.CleanupEventSubscriptions();
            DataItemBrowserControl.ItemSelected -= new RoutedEventHandler(DataItemBrowserControl_ItemSelected);
            DataItemBrowserControl.HighlightedItemChanged -= new RoutedEventHandler(DataItemBrowserControl_HighlightedItemChanged);            
            DataItemBrowserControl.UserSetHighlightedItemChanged -= new RoutedEventHandler(DataItemBrowserControl_UserSetHighlightedItemChanged);
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            base.OnClosing(e);

        }

        private void Window_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            //The Escape key normally closes the DIB window
            //We need to hook into the ESCAPE key using PreviewKeyDown (a tunnelling event) because the Xceed grid will not bubble an ESCAPE key KeyDown (a bubbling event). 
            //Here we check that context menus are not open. KeyUp would not work as a substitue to PreviewKeyDown since the context menus are already closed.
            if (e.Key == Key.Escape)
            {
                //Don't close if a DIB Search control context menu is up (we will get the ESC here before the search filter MRU given this is a preview event)
                if (!this.DataItemBrowserControl.IsSearchControlContextMenuOpen())
                {
                    e.Handled = true;

                    // save the window's size
                    this._presenter.SaveWindowSize();

                    CleanupEventSubscriptions();
                    this.Close();
                }
            }
            //If up or down is pressed and the data grid has focus but no selected item, make sure we send a secondary focus.
            // This solves a specific issue where we initially send focus to the grid when it has no items, and up and down key
            // presses are not picked up by the grid when items do start to load from the data services.
            else if (e.Key == Key.Down || e.Key == Key.Up)
            {
                //We not only check if the grid has focus but also if this (DIBWindow) has focus.  There is
                // a possibility that the window as a whole may get focus when selecting an item from a context
                // menu (specifically the forward/backward menu crumbs) and we still should consider this
                // a grid focused without selection with respect to the up/down arrow presses
                if (this.DataItemBrowserControl.IsDataGridFocusedWithNoSelection() || Keyboard.FocusedElement==this)
                {
                    this.DataItemBrowserControl.ProcessKeyboardRequestFocusToGrid();
                    //DON'T set e.handled to true here as we want the grid to handle the up/down press
                    return;
                }
            }

            //CTRL + F OR ALT + F. Attempt to give focus to the search textbox                      
            if ((Keyboard.Modifiers == ModifierKeys.Control) && (e.Key == Key.F) || (e.KeyboardDevice.Modifiers == ModifierKeys.Alt) && (e.SystemKey == Key.F))
            {
                e.Handled = true;
                this.DataItemBrowserControl.ProcessKeyboardRequestFocusToSearch();
                return;
            }
            //CTRL + L OR ALT + L. Give focus to Grid region
            if ((e.KeyboardDevice.Modifiers == ModifierKeys.Control) && (e.Key == Key.L) || (e.KeyboardDevice.Modifiers == ModifierKeys.Alt) && (e.SystemKey == Key.L))
            {
                e.Handled = true;
                this.DataItemBrowserControl.ProcessKeyboardRequestFocusToGrid();
                return;
            }

            if (e.KeyboardDevice.Modifiers != ModifierKeys.Alt) return;

            //ALT + LeftArrow. Attempt to Drill out 
            if (e.SystemKey == Key.Left)
            {
                e.Handled = true;
                this.DataItemBrowserControl.ProcessKeyboardRequestDrillOut();
                return;
            }
            //ALT + RightArrow. Attempt to Drill in 
            if (e.SystemKey == Key.Right)
            {
                e.Handled = true;
                this.DataItemBrowserControl.ProcessKeyboardRequestDrillIn();
                return;
            }
            //ALT + UpArrow. Attempt to select TAG above current tag in the data grid
            if (e.SystemKey == Key.Up)
            {
                e.Handled = true;
                this.DataItemBrowserControl.ProcessKeyboardRequestSelectPrevious();
                return;
            }
            //ALT + DownArrow. Attempt to select TAG below current tag in the data grid
            if (e.SystemKey == Key.Down)
            {
                e.Handled = true;
                this.DataItemBrowserControl.ProcessKeyboardRequestSelectNext();
                return;
            }
            //ALT. We dont want this key to close the DIB so dont allow them to bubble to the DTC window
            if ((e.SystemKey == Key.LeftAlt) || (e.SystemKey == Key.RightAlt))
            {
                //Let the ALT go through if a context menu is open on the search filter control (otherwise the
                // MRU list won't close when pressing ALT)
                if(!this.DataItemBrowserControl.IsSearchControlContextMenuOpen())
                    e.Handled = true;
            }
        }
		
        #region DTC workaround - Project Context 
        /// <summary>
        /// change project context in the view model
        /// </summary>
        /// <param name="project"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "project")]
        public void ChangeProjectContext(string project)
        {
            // DataItemBrowserControl.ChangeViewModel(project);
        }
        #endregion

        #region Item Selected Events

        /// <summary>
        /// Item selected event from the dataitembrowser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void DataItemBrowserControl_ItemSelected(object sender, RoutedEventArgs e)
        {
            //Raise event so owner of this window can get the selected item
            this.RaiseItemSelectedEvent();

            if (!_clientManager.ShouldCloseOnSelect()) return;

            //set the closing flag so it will not attempt to close in lost keyboard focus also
            _Closing = true;

            // save the window's size
            this._presenter.SaveWindowSize();

            // Remove event handlers
            CleanupEventSubscriptions();

            this.Close();
        }
        #endregion Item Selected Events

        #region HighlightedItem Events

        /// <summary>
        /// Item selected event from the dataitembrowser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void DataItemBrowserControl_HighlightedItemChanged(object sender, RoutedEventArgs e)
        {
            //Raise event so owner of this window can get the selected item
            this.RaiseHighlighedItemChangedEvent();
        }
        #endregion HighlightedItem Events

        /// <summary>
        /// Handle the window left mouse down so we can allow for the window to be moved
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //We'll get this event anywhere in the background of the DIB Window so only
            // do the drag if we're on the special border area as defined by our XAML.
            if (e.OriginalSource == DIBWindowMoveOverlay)
                this.DragMove();
        }

        /// <summary>
        /// Clears the last highlighted item memory so when the DIB is launched it will no longer navigate to the
        /// previously highlighted tag (if no selected item string is provided)
        /// </summary>
        public void ClearLastHighlightedItemInfo()
        {
            DataItemBrowserViewModel dibVM = this.DataItemBrowserControl.DataContext as DataItemBrowserViewModel;
            dibVM.ClearLastHighlightedItemInfo();
        }

        /// <summary>
        /// Clears the search MRU list history
        /// </summary>
        public void ClearSearchMRUListHistory()
        {
            this.DataItemBrowserControl.ClearSearchMRUListHistory();
        }
    }
}
