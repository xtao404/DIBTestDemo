﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Tags;

namespace TagFilterControl.Service
{
    interface ITagService
    {
        TagTreeViewResult LoadSubItems(TagNode selectNode, bool isChecked);
    }

    public class TagTreeViewResult : Result
    {
        public ObservableCollection<TagNode> Children { get; set; }
    }
}
