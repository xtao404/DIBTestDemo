﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Exposes attached behaviors that can be applied to TreeViewItem objects.
    /// This is used by our DataSourceView in order to allow items in the tree to be highlighted when selected.
    /// Every tree view item is given the IsBroughtIntoViewWhenSelectedProperty attached property
    /// </summary>
    public static class TreeViewItemBehavior
    {
        public static readonly DependencyProperty IsBroughtIntoViewWhenSelectedProperty =
            DependencyProperty.RegisterAttached(
            "IsBroughtIntoViewWhenSelected",
            typeof(bool),
            typeof(TreeViewItemBehavior),
            new UIPropertyMetadata(false, OnIsBroughtIntoViewWhenSelectedChanged));

        static void OnIsBroughtIntoViewWhenSelectedChanged(DependencyObject depObj, DependencyPropertyChangedEventArgs e)
        {
            TreeViewItem item = depObj as TreeViewItem;
            if (item == null)
                return;

            if (e.NewValue is bool == false)
                return;

            // register for select and unselect events with methods on this class
            if ((bool)e.NewValue)
                item.Selected += OnTreeViewItemSelected;
            else
                item.Selected -= OnTreeViewItemSelected;
        }

        /// <summary>
        /// Dependency property getter
        /// </summary>
        public static bool GetIsBroughtIntoViewWhenSelected(DependencyObject treeViewItem)
        {
            return (bool)treeViewItem.GetValue(IsBroughtIntoViewWhenSelectedProperty);
        }

        /// <summary>
        /// Dependency property setter
        /// </summary>
        public static void SetIsBroughtIntoViewWhenSelected(DependencyObject treeViewItem, bool value)
        {
            treeViewItem.SetValue(IsBroughtIntoViewWhenSelectedProperty, value);
        }

        /// <summary>
        /// Once an item is selected we want to make sure to give keyboard focus to that item using the dispatcher
        /// </summary>
        static void OnTreeViewItemSelected(object sender, RoutedEventArgs e)
        {
            // Only react to the Selected event raised by the TreeViewItem
            // whose IsSelected property was modified.  Ignore all ancestors
            // who are merely reporting that a descendant's Selected fired.
            if (!Object.ReferenceEquals(sender, e.OriginalSource))
                return;

            TreeViewItem item = e.OriginalSource as TreeViewItem;
            if (item != null)
            {
                item.BringIntoView();
                if (!item.IsFocused && (Keyboard.FocusedElement==null || item.IsDescendantOf((DependencyObject)Keyboard.FocusedElement)))
                    item.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, (Action)(() => Keyboard.Focus(item)));
            }
        }
    }
}