﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using System;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI.Models;
using RockwellAutomation.Logging;
using System.Reflection;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query.Common;


namespace RockwellAutomation.UI.DIBQuery
{    
    /// <summary>
    /// DIBQueryCommand allows request to QSP to be represented as an object.
    /// Sublcasses specialize the differnet types of commands that can be sent to QSP.
    /// The main purpose of a DIBQueryCommand is to generate a QueryRequest object that is sent to QSP in the QSP Request.
    /// Note that QueryRequest implementes the builder pattern, and the builder is stored in _queryRequestBuilder.
    /// </summary>
    public abstract class DIBQueryCommand : IDIBQueryCommand
    {
        #region "Variables"

        /// <summary>
        /// Represents the QueryRequest that was sent to QSP. 
        /// Note that this is created using _queryRequestBuilder (Builder patern)
        /// right before sending a request to QSP
        /// </summary>
        private QueryRequest _CurrentQueryRequest = null;
        public QueryRequest CurrentQueryRequest
        {
            get { return _CurrentQueryRequest;}
            protected set { _CurrentQueryRequest = value;}
        }

        /// <summary>
        /// Used to determine whether to cache results when command completes.
        /// </summary>
        private bool _CacheQueryResults = false;
        public bool CacheQueryResults
        {
            get { return _CacheQueryResults; }
            protected set { _CacheQueryResults = value; }
        }

        private QueryRequest.CreateBuilder _queryRequestBuilder;
        protected QueryRequest.CreateBuilder QueryRequestBuilder { get { return _queryRequestBuilder; } }

        #endregion

        #region "Creation/Init"

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="queryRequestBuilder">The builder to use to generate the QueryRequest</param>
        protected DIBQueryCommand(QueryRequest.CreateBuilder queryRequestBuilder)
        {
            this._queryRequestBuilder = queryRequestBuilder;
        }

        /// <summary>
        /// Provide ability to create a specific command based on requested type
        /// </summary>
        /// <param name="browserPerspective"></param>
        /// <param name="parentResourceTypeId">The Resource Type of the parent, even if no parent is specified</param>
        /// <param name="parentItem">The DataItemBase that represents the parent. This can be null if there is no parent</param>
        /// <param name="queryCondition"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "isForDIBSearch")]
        static public IDIBQueryCommand CreateFor(QueryRequest.CreateBuilder queryRequestBuilder, bool isForDIBSearch = false)
        {
            return new DIBQueryCommandForClientExecutedQuery(queryRequestBuilder);
        }

        #endregion

        #region "IDIBQueryCommand implementation"

        public DataItemBase ParentDataItem()
        { 
            if (this._queryRequestBuilder == null) return null;
            return this.QueryRequestBuilder.GetParentDataItemBase();
        }

        public ulong GetRequestID()
        {
            if (this.CurrentQueryRequest == null) return 0;
            return CurrentQueryRequest.GetRequestID;
        }

        /// <summary>
        /// Force subclasses to specify a QueryType
        /// </summary>
        public abstract PredefinedQueryType QueryType();

        public virtual void CleanUp()
        {
            this._queryRequestBuilder = null;
            this.CurrentQueryRequest = null;
        }

        /// <summary>
        /// Execute a Query to back end using the specified DIBQueryConnection and ClientDataService
        /// </summary>
        /// <param name="cds"></param>
        /// <param name="queryConnection"></param>
        public virtual void Execute(IClientDataServices cds)
        {
            // let subclasses override
        }

        #endregion

        #region "Public"


        public UUID ParentResourceTypeId()
        {
            if (this._queryRequestBuilder == null) return null;
            return this._queryRequestBuilder.GetParentResourceType();
        }

        /// <summary>
        /// Let subclasses generate query conditions as they are usually specific to the type of command
        /// </summary>
        /// <param name="cds"></param>
        public virtual QueryConditionConfig GenerateQueryCondition(IClientDataServices cds)
        {
            return null;
        }


        #endregion

        #region "Private/Protected"

        protected void SetColumnConfigIfNeeded(IClientDataServices cds)
        {
            RockwellAutomation.Client.Services.Query.ColumnConfig columnConfig = cds.GenerateColumnConfig();
            if (columnConfig != null)
                _queryRequestBuilder.SetColumnConfig(columnConfig);
        }

        protected void SetConditionConfigIfNeeded(IClientDataServices cds)
        {
            QueryConditionConfig queryCond = GenerateQueryCondition(cds);
            if (queryCond != null)
                _queryRequestBuilder.SetCondition(queryCond);
        }

        /// <summary>
        /// Represents the column config to use when executing a nonDBQuery response
        /// </summary>
        /// <returns>ColumnConfig</returns>
        protected static Client.Services.Query.ColumnConfig NonDBQueryColumnConfig()
        {
            RockwellAutomation.Client.Services.Query.ColumnConfig.CreateBuilder columns = new RockwellAutomation.Client.Services.Query.ColumnConfig.CreateBuilder();
            return columns.Build();
        }

        #endregion
    }
}
