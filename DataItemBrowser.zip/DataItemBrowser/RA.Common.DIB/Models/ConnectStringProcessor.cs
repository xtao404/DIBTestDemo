/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2016 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 
 *************************************************************************************
 This file contains the classes associated with the Connect String functionality
 *************************************************************************************/
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.ViewModels
{
    public delegate void NavigateStringDelegate( DataItemBase navigatedTo, DataItemBase highLightedItem );
 
    public static class Tokens
    {   
        // Tokens used to parse ConnectString
        public static readonly string DEVICE_DELIMITER;
        public static readonly string DEVICE;
        public static readonly string DOT_DELIMITER;
        public static readonly string PATH_DELIMITER;
        public static readonly string PROGRAMS;
        public static readonly string PROGRAM;
        public static readonly string DATALOGS;
        public static readonly string DATALOG;
        public static readonly string DATA_TYPE;
        public static readonly string NAME;
        public static readonly string INVALIDNAME;
        public static readonly string MEMBER_NAME;
        public static readonly string ARRAY_INDEX;
        public static readonly string ARRAY_INDEX_TERMINATOR;
        public static readonly string BIT;
        public static readonly string METADATA;
        public static readonly string TAGS_AND_PROPERTIES;
        public static readonly string DRILLIN;
        public static readonly string BRACQUET_TERMINATOR;
        public static readonly string PATH_TERMINATOR;
        public static readonly string DOT_TERMINATOR;
        public static readonly string TERMINAL;
        public static readonly string TERMINAL_STRING;
        public static readonly string INITIAL;
        public static readonly string INVALID;

        /// <summary>
        /// static constructor
        /// Note if you add/delete/change any of these strings be sure to READ THE FOLLOWING NOTE.  
        /// Due to changes necessary to support obfuscation there are Case statements in methods within the ConnectStringProcessor class which use these literal strings and they also MUST be changed.
        /// The following warning is suppressed because if we initialize the static fields where they are declared obfuscation will not obfuscate the strings.
        /// When we initialize the static fields in the static constructor, obfuscation does obfuscate the fields
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1810:InitializeReferenceTypeStaticFieldsInline")]
        static Tokens()
        {
            DEVICE_DELIMITER = "DeviceDelimiter";
            DEVICE = "Device";
            DOT_DELIMITER = "DotDelimiter";
            PATH_DELIMITER = "PathDelimiter";
            PROGRAMS = "Programs";  // Programs folder
            PROGRAM = "Program";
            DATALOGS = "DataLogs";   // DataLogs folder
            DATALOG = "DataLog";
            DATA_TYPE = "DataType";
            NAME = "Name";
            INVALIDNAME = "InvalidName";
            MEMBER_NAME = "MemberName";
            ARRAY_INDEX = "ArrayIndex";
            ARRAY_INDEX_TERMINATOR = "ArrayIndexTerminator";
            BIT = "Bit";
            METADATA = "MetaData";
            TAGS_AND_PROPERTIES = "TagsAndProperties";
            DRILLIN = "DrillIn";
            BRACQUET_TERMINATOR = "Bracquet_Terminator";
            PATH_TERMINATOR = "Path_Terminator";
            DOT_TERMINATOR = "Dot_Terminator";
            TERMINAL = "Terminal";
            TERMINAL_STRING = "==" + TERMINAL + "==";
            INITIAL = "Initial";
            INVALID = "InvalidToken";
        }

    } // Tokens

    public class ConnectStringProcessor
    {
        private DataItemBrowserViewModel _dibVM = null;
        private ConnectStringTokens _tokens = new ConnectStringTokens();
        private NavigateStringTokens _navigateTokens = new NavigateStringTokens();        
        private DataContext _dataContext = null;
        private Path _path = null;
        private int _lastIndex = 0;
        private int _lastLength = 0;
        private MatchCollection _matches = null;
        private Regex _regexPattern = null;
        private enum ParseStates { Initial, PostDeviceDelimiter, PostDevice, Program, PostProgram, PostDataLogs, DataLog, PostPath, PreDot, PostDot, PostTagsAndMembers, PostDataType };
        private IEnumerator _matchEnumerator;
        // Required to display the connect string in Catch blocks
        private string ConnectString { get; set; }


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="path">Reference to the path to control the path elements for</param>
        /// <param name="dibVM">DataItemBrowserViewModel associated with</param>        
        /// <param name="dataContext">Reference to the data context object</param>
        public ConnectStringProcessor(Path path, DataItemBrowserViewModel dibVM, DataContext dataContext)
        {
            _path = path;
            _dibVM = dibVM;            
            _dataContext = dataContext;
        }

        /// <summary>
        /// Generic DIB navigation
        /// </summary>
        /// <param name="navigateList">List of items to navigate</param>
        /// <param name="callback">Delegate to call when done</param>
        public void NavigateString(List<DataItemBase> navigateList, NavigateStringDelegate callback)
        {
            // fill the path to navigate
            _navigateTokens.AddRange(navigateList);

            try
            {
                LogWrapper.DibInterfaceLog.Info("Navigating " + navigateList.Count.ToString() + " items");
                NavigateGenericTypeBrowser(_navigateTokens.Current(), callback);
            }
            catch (System.Exception e)
            {
                string msg = " Connect string = " + ConnectString +
                    " Previous token = " + _tokens.PreviousGroup + "(" + _tokens.PreviousName + ")" +
                    " Current token = " + _tokens.Group + "(" + _tokens.Name + ")";
                LogWrapper.LogException("NavigateString Error:" + msg, e);
                // Display Home
                callback(null, null);
            }
        }

        /// <summary>
        /// Perform the navigation for the generic DIB
        /// </summary>
        /// <param name="parentItem">item to navigate to</param>
        /// <param name="callback">Delegate to call when done</param>
        private void NavigateGenericTypeBrowser(DataItemBase parentItem, NavigateStringDelegate callback)
        {
            // Navigate to parentItem to acquire its children

            _dibVM.NavigateNoGui(parentItem, (error) =>
            {
                try
                {
                    // Callback function
                    if (String.IsNullOrEmpty(error))
                    {
                        DataItemBase nextItem = _navigateTokens.GetNextItem();
                        if (nextItem != null && nextItem.IsStructured)
                        {
                            // only structured items are added to the trail
                            _path.Add(PathElementFactory.Instance().CreatePathElement(nextItem));
                            NavigateGenericTypeBrowser(nextItem, callback);
                        }
                        else
                        {
                            // reached the end of the trial
                            if (_path.Items.Count > 1)
                            {
                                callback(_path.Last.DataItem, null);
                            }
                            else
                            {
                                callback(parentItem, null);
                            }
                        }
                    }
                    else
                    {
                        LogWrapper.LogException("NavigateGenericTypeBrowser Error: ", new Exception(error));
                        // Navigate back to the parent as this is the last correct dataitem
                        callback(parentItem, null);
                    }

                } // try
                catch (System.Exception e)
                {
                    string msg = " Connect string = " + ConnectString +
                        " Previous token = " + _tokens.PreviousGroup + "(" + _tokens.PreviousName + ")" +
                        " Current token = " + _tokens.Group + "(" + _tokens.Name + ") e = ";
                    LogWrapper.LogException("NavigateGenericTypeBrowser Error:" + msg, e);
                    // Navigate back to DataTypeView
                    callback(null, null);
                }
            });  // NavigateNoGui
        }

        /// <summary>
        /// Navigate to the connect string
        /// </summary>
        /// <param name="connectString">SelectedItem's full path</param>
        /// <param name="callback">Delegate to call when done</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1720:IdentifiersShouldNotContainTypeNames", MessageId = "string",Justification = "connectString is the generic meaningful name for this variable")]
        public void NavigateString(string connectString, NavigateStringDelegate callback)
        {
            try
            {
                ConnectString = connectString;

                LogWrapper.DibInterfaceLog.Info("Connection string: " + connectString);

                if (_dibVM.IsTagBrowser() || _dibVM.IsAOGPropertyBrowser())
                {
                    ParseTagBrowserConnectString(ConnectString);
                    BuildPathForTagBrowser( ( navigatedTo, highLightedItem) =>
                        {
                            callback(navigatedTo, highLightedItem);
                        });
                }
                else
                {
                    ParseDataTypeBrowserConnectString(ConnectString);
                    BuildPathForDataTypeBrowser( ( navigatedTo, highLightedItem) =>
                        {
                            callback(navigatedTo, highLightedItem);
                        });
                }
            }
            catch (System.Exception e)
            {
                string msg = " Connect string = " + ConnectString +
                    " Previous token = " + _tokens.PreviousGroup + "(" + _tokens.PreviousName + ")" +
                    " Current token = " + _tokens.Group + "(" + _tokens.Name + ")";
                LogWrapper.LogException("NavigateConnectString Error:" + msg, e);
                // Display Home
                callback(null, null);
            }
        }

        /// <summary>
        /// Get the next token from the regex matches
        /// </summary>
        /// <returns>true if valid token was found</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1806:DoNotIgnoreMethodResults", MessageId = "System.Int32.TryParse(System.String,System.Int32@)",Justification = "bit is implicitly checked in the if (bit<10) statement below the call to TryParse")]
        private bool GetToken()
        {
            bool found = _matchEnumerator.MoveNext();
            if (!found)
                return found;

            Match match = (Match)_matchEnumerator.Current;
            // Find the name of the group associated with the match
            for (int groupIndex = 0; groupIndex < match.Groups.Count; groupIndex++)
            {
                Group group = match.Groups[groupIndex];

                string matchValue = group.Value;
                //successful non-empty match
                if (group.Success && !string.IsNullOrEmpty(matchValue))
                {
                    // Get the group's name via the groupIndex
                    string groupName = _regexPattern.GroupNameFromNumber(groupIndex);

                    //We will get subgroups named "0", "1", etc. as a result of parens in the regex we use.  Since we only 
                    // want to match the named groups we defined in the regex patterns, we can ignore these numeric ones
                    if (!_regexPattern.ToString().Contains("<" + groupName + ">"))
                        continue;

                    LogWrapper.DibGeneralLog.Debug("===== String Matched = " + matchValue + " by pattern " + groupName + " Index = " + match.Index + " Length = " + match.Length);

                    // If the the tokens are not adjacent, then there exists an invalid string
                    // between the tokens - stop the parsing
                    if (_lastIndex + _lastLength != match.Index)
                    {
                        _tokens.Add(Tokens.INVALID, Tokens.INVALID);
                        break;
                    }

                    // Save the following information so we can detect if the tokens are not adjacent
                    _lastIndex = match.Index;
                    _lastLength = match.Length;

                    // A bit's name must have three characters for bits 0-9 (for visual appearance) but only
                    // 2 characters for bits 10-...
                    switch (groupName)
                    {
                        case "Bit": //Tokens.BIT
                            {
                                matchValue = matchValue.TrimStart(new char[] { '.', ' ' });
                                int bit = 0;
                                int length = 2;
                                int.TryParse(matchValue, out bit);
                                if (bit < 10)
                                    length = 3;
                                for (int i = 0; matchValue.Length < length; i++)
                                    matchValue = matchValue.Insert(0, " ");
                            }
                            break;
                    }

                    // Add a valid token
                    _tokens.Add(groupName, matchValue);
                    break;
                }
            }
            return true;
        }

        /// <summary>
        /// Break the connectString into individual matches using regex
        /// </summary>
        /// <param name="connectString"></param>
        private void PerformRegexParsing(string connectString)
        {
            // Remove leading and trailing white space
            connectString = connectString.Trim();

            LogWrapper.DibGeneralLog.Debug("**** Path.StringToPath: connectString = " + connectString);

            //Use these patterns to parse the connectString using regular expression matching into tokens.
            //The parse is case insensitive
            string pattern = "(?<" + Tokens.DEVICE_DELIMITER + @">::)";            // ::
            // PATH_TERMINATOR must precede PATH_DELIMITER
            pattern += "|(?<" + Tokens.PATH_TERMINATOR + @">\\$)"; // Detect '\' at the end of the connect string
            pattern += "|(?<" + Tokens.PATH_DELIMITER + @">\\)";                   // "\"
            // DOT_TERMINATOR must precede DOT_DELIMITER
            pattern += "|(?<" + Tokens.DOT_TERMINATOR + @">\.$)"; // Detect '.' at the end of the connect string
            pattern += "|(?<" + Tokens.DOT_DELIMITER + @">\.)";                    // "."
            pattern += "|(?<" + Tokens.DATALOGS + @">@DataLogs)";                  // @DataLogs
            pattern += "|(?<" + Tokens.NAME + @">([a-z]|_(?!_))[\w:]*)";           // A name name starts with a letter or underscore and can then be 
            // followed by characters, digits, colons, or underscores
            pattern += "|(?<" + Tokens.ARRAY_INDEX + @">\[(\d+,){0,2}\d+\])";      // Check for 1, 2, or 3 indices
            pattern += "|(?<" + Tokens.ARRAY_INDEX_TERMINATOR + @">\[(\d+,){0,2}\d+)"; // Check for 1, 2, or 3 indices (without trailing bracket)
            pattern += "|(?<" + Tokens.BRACQUET_TERMINATOR + @">\[$)"; // Detect '[' at the end of the connect string
            pattern += "|(?<" + Tokens.INVALIDNAME + @">\d*[^\d\\\.\@ ]+)";        // Track separately a name which doesn't conform to the valid rules
            // Make sure its more than 2 chars though to not conflict with a bit
            pattern += "|(?<" + Tokens.BIT + @">\d+)";                             // Detect a bit reference
            pattern += "|(?<" + Tokens.METADATA + @">\@[a-z][\w]*)";               // Detect a metadata reference. The first character is @ followed by other characters

            //load and parse the regular expressions pattern (not case sensitive)
            _regexPattern = new Regex(pattern, RegexOptions.IgnoreCase);

            //find matches in the searchText based on the regular expression pattern
            _matches = _regexPattern.Matches(connectString);
        }

        /// <summary>
        /// Parse the DataType Selector's connect string into a list of tokens. Syntactic check only.
        /// If an invalid token is detected the parsing stops.
        /// </summary>
        /// <param name="connectString">DataType Browser's connect string</param>
        private void ParseDataTypeBrowserConnectString(string connectString)
        {
            // Use RegEx to parse the connect string
            PerformRegexParsing(connectString);
            _matchEnumerator = _matches.GetEnumerator();
            _matchEnumerator.Reset();  // Sets the initial position to before the first element in the _matches collection

            ParseStates parseState = ParseStates.Initial;
            while (GetToken())
            {  
                switch (parseState)
                {
                    case ParseStates.Initial:
                        switch (_tokens.Group)
                        {
                            case "DeviceDelimiter": // Tokens.DEVICE_DELIMITER
                                _tokens.Delete();   // "::" no longer needed
                                parseState = ParseStates.PostDeviceDelimiter;
                                break;
                            case "Name": // Tokens.NAME
                                _tokens.RenameGroup(Tokens.DATA_TYPE);
                                return; // Parsing complete
                            default:
                                _tokens.Delete();
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.PostDeviceDelimiter:
                        switch (_tokens.Group)
                        {
                            case "Name": // Tokens.NAME ie. Controller's Name
                                _tokens.RenameGroup(Tokens.DEVICE);
                                parseState = ParseStates.PostDevice;
                                break;
                            default:
                                _tokens.Delete();
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.PostDevice:
                        switch (_tokens.Group)
                        {
                            case "Terminal": // Tokens.TERMINAL
                                return; // Parsing complete
                            
                            case "DotDelimiter": // Tokens.DOT_DELIMITER
                                _tokens.Delete();
                                parseState = ParseStates.PostDot;
                                break;

                            default:
                                _tokens.Delete();
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.PostDot:
                        switch (_tokens.Group)
                        {
                            case "Name": // Tokens.NAME // Highlight Name in ::c1.DT
                                _tokens.RenameGroup(Tokens.DATA_TYPE);
                                parseState = ParseStates.PostDataType;
                                break;

                            default:
                                _tokens.Delete();
                                return; // Parsing complete
                        }
                        break;


                    case ParseStates.PostDataType:
                        _tokens.Delete();  // Delete will not delete the TERMINAL
                        return;
                }
            }
        }

        /// <summary>
        /// The connect string has been parsed, now build the Path for it.
        /// </summary>
        /// <param name="callback">Delegate to call when done</param>
        private void BuildPathForDataTypeBrowser(NavigateStringDelegate callback)
        {
            _tokens.Reset();

            if (_tokens.Group == Tokens.TERMINAL)
            {
                // Display the DataTypes View
                callback(null, null);
            }
            else
                NavigateDataTypeBrowser(null, callback);
        }

        /// <summary>
        /// Walk the list of tokens in _tokens, and navigate to each item building up the Path.
        /// This recursive method initially is passed the DataItemBase for the Predefined if the
        /// path to the connect string does NOT contain a device.  If a device is specified then
        /// DIB_UserDefined is the initial parentItem.
        /// </summary>
        /// <param name="parentItem">DataItemBase for either DIB_PreDefined, DIB_ModuleDefined, or DIB_UserDefined.</param>
        /// <param name="callback">Delegate to call when done</param>
        private void NavigateDataTypeBrowser(DataItemBase parentItem, NavigateStringDelegate callback)
        {
            // Navigate to parentItem to acquire its children
            _dibVM.NavigateNoGui(parentItem, (error) =>
            {
                try
                {
                    // Callback function
                    if (String.IsNullOrEmpty(error))
                    {
                        // Create the dataitems for the three dataitems and build the cache collection for these datatypes
                        if (parentItem == null)
                        {
                            if (_tokens.Group == Tokens.DEVICE) // ::c1.DT
                            {
                                NavigateDataTypeBrowser(DIResource.DIB_UserDefined, callback);
                            }
                            else if (_tokens.Group == Tokens.DATA_TYPE)
                            {
                                NavigateDataTypeBrowser(DIResource.DIB_PreDefined, callback);
                            }
                        }
                        else
                        {
                            // parent's dataitems was successfully loaded
                            switch (_tokens.Group)
                            {
                                case "DataType": // Tokens.DATA_TYPE
                                    // Only the datatype was referenced in the string
                                    // Search until found starting with the PreDefined, then ModuleDefined, and finally UserDefined

                                    // Is the name of the datatype found in the parentItem's dataitems?
                                    DataItemBase dataTypeDib = _dibVM.GetDataItemByName(_tokens.Name);
                                    if (dataTypeDib != null)
                                    {
                                        // Name was found

                                        //Set up VM to highlight by name since the GetDataItemByName above might have returned
                                        // the first of what could be an ambiguous data type
                                        _dibVM.SetValue(DIBGridViewModel.ItemSelectionModeProperty, DIBGridViewModel.MatchMode.ByName);

                                        // Highlight DataType
                                        _path.Add(PathElementFactory.Instance().CreatePathElement(parentItem));
                                        _path.SavedHighlightedElement = PathElementFactory.Instance().CreatePathElement(dataTypeDib);
                                        _path.HighlightedElement = _path.SavedHighlightedElement;
                                        callback(parentItem, null);

                                        // search stops
                                    }
                                    else if (parentItem == DIResource.DIB_PreDefined)
                                    {   // Not a PDT
                                        // Is the DataType found within the Module Defines?
                                        NavigateDataTypeBrowser(DIResource.DIB_ModuleDefined, callback);

                                    }
                                    else if (parentItem == DIResource.DIB_ModuleDefined)
                                    {
                                        // Not a MDT
                                        // Is this an ambiguous User Define?  No device prefix
                                        NavigateDataTypeBrowser(DIResource.DIB_UserDefined, callback);
                                    }
                                    else if (parentItem == DIResource.DIB_UserDefined)
                                    {
                                        // The datatype name was not found
                                        // No match - Display the DataTypeView
                                        callback(null, null);
                                    }
                                    break;

                                // Qualified User-Defined ::C1/DT
                                case "Device": // Tokens.DEVICE
                                    string location = _tokens.Name;
                                    string datatype = string.Empty;
                                    _tokens.Next();
                                    if (_tokens.Group == Tokens.DATA_TYPE)
                                    {
                                        datatype = _tokens.Name;
                                    }
                                    // Does this datatype exist?
                                    DataItemBase locationDib = _dibVM.GetDataTypeItemByLocation(datatype, location);
                                    if (locationDib != null)
                                    {
                                        // DataType found
                                        // Highlight the datatype
                                        _path.Add(PathElementFactory.Instance().CreatePathElement(parentItem));
                                        _path.SavedHighlightedElement = PathElementFactory.Instance().CreatePathElement(locationDib);
                                        _path.HighlightedElement = _path.SavedHighlightedElement;
                                        callback(parentItem, null);
                                    }
                                    else
                                    {
                                        // The name of the datatype has either been mistyped, or no longer exists.
                                        // No match - Display the DataTypeView
                                        callback(null, null);
                                    }
                                    break;
                            }
                        }
                    }
                    else
                    {
                        LogWrapper.LogException("NavigateDataTypeBrowser Error: ", new Exception(error));
                        // Navigate back to the parent as this is the last correct dataitem
                        callback(parentItem, null);
                    }

                } // try
                catch (System.Exception e)
                {
                    string msg = " Connect string = " + ConnectString +
                        " Previous token = " + _tokens.PreviousGroup + "(" + _tokens.PreviousName + ")" +
                        " Current token = " + _tokens.Group + "(" + _tokens.Name + ") e = ";
                    LogWrapper.LogException("NavigateDataTypeBrowser Error:" + msg, e);
                    // Navigate back to DataTypeView
                    callback(null, null);
                }
            });  // NavigateNoGui
        }

        private void BuildRemainingPathForAOGBrowser(NavigateStringDelegate callback)
        {
            //if this was not processed as part of the root, check to see if it is a device
            if (_tokens.Group == Tokens.DEVICE)
            {
                // Does device exist?
                DataItemBase deviceItem = _dibVM.GetDataItemByName(_tokens.Name);
                if (deviceItem != null)
                {
                    //Add device path element
                    _path.Add(PathElementFactory.Instance().CreatePathElement(deviceItem));
                    NavigateTagBrowser(deviceItem, callback);
                }
                else //invalid selectedItem then navigate to root
                {
                    // Invalid device name. Display the DSV
                    callback(null, null);
                }

            }
            else
            {
                //step back so it will be on the last token 
                _tokens.Previous();
                //use the root dataitem to continue to drill into this path
                NavigateTagBrowser(_dataContext.RootPath.DataItem, callback);
            }

        }

        /// <summary>
        /// Parse the TagBroswer's connect string into a list of tokens. Syntactic check only.
        /// If an invalid token is detected the parsing stops.
        /// </summary>
        /// <param name="connectString">String to Parse</param>
        private void ParseTagBrowserConnectString(string connectString)
        {
            // Use RegEx to parse the connect string
            PerformRegexParsing(connectString);
            _matchEnumerator = _matches.GetEnumerator();
            _matchEnumerator.Reset();  // Sets the initial position to before the first element in the _matches collection

            ParseStates parseState = ParseStates.Initial;
            //Use a bool to track if we have parsed past the name of a first level child of a device (i.e. Tag or Program, etc).
            bool IsPastDeviceObjectName = false;

            while (GetToken())
            {
                switch (parseState)
                {
                    case ParseStates.Initial:
                        switch (_tokens.Group)
                        {
                            case "DeviceDelimiter": // Tokens.DEVICE_DELIMITER
                                _tokens.Delete(); // delete "::"
                                parseState = ParseStates.PostDeviceDelimiter;
                                break;

                            default:
                               _tokens.Delete();
                               return; // parsing complete
                        }
                        break;

                    case ParseStates.PostDeviceDelimiter:  // "::"???
                        switch (_tokens.Group)
                        {
                            case "Name": // Tokens.NAME
                                _tokens.RenameGroup(Tokens.DEVICE);  // ::c1
                                parseState = ParseStates.PostDevice;
                                break;

                            default:
                               _tokens.Delete();
                               return; // parsing complete
                        }
                        break;

                    case ParseStates.PostDevice: // ::c1???
                        switch (_tokens.Group)
                        {
                            case "Terminal": // Tokens.TERMINAL: // ::c1
                                return; // Parsing complete

                            case "PathDelimiter": // Tokens.PATH_DELIMITER: // ::c1\
                                _tokens.Delete();       // delete "\"
                                parseState = ParseStates.PostPath;
                                break;

                            case "Dot_Terminator": // Tokens.DOT_TERMINATOR: // ::c1. 
                                // Drill into Tags and Properties
                                _tokens.Replace(Tokens.TAGS_AND_PROPERTIES);
                                _tokens.Add(Tokens.DRILLIN, string.Empty);
                                return; // Parsing complete

                            case "Path_Terminator": // Tokens.PATH_TERMINATOR: // ::c1\
                                // This is invalid. Drill into the controller view
                                _tokens.Delete();
                                _tokens.InsertBefore(Tokens.DRILLIN);
                                return; // Parsing complete

                            case "DotDelimiter": // Tokens.DOT_DELIMITER: // ::c1. becomes ::c1 T&P
                                _tokens.Delete();
                                // _dibVM will be null for unit test ConnectStringTest
                                if (_dibVM == null || !_dibVM.IsAOGPropertyBrowser())
                                {
                                    // don't add TagsAndProperties to the token list
                                    _tokens.Add(Tokens.TAGS_AND_PROPERTIES, String.Empty);
                                }
                                parseState = ParseStates.PostDot;
                                break;

                            default:
                                // Invoke Controller View
                                _tokens.Delete();
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.PostPath:  // ::c1\???
                        IsPastDeviceObjectName = true;
                        switch (_tokens.Group)
                        {
                            case "Name": // Tokens.NAME: // ::c1\P1
                                _tokens.RenameGroup(Tokens.PROGRAM);
                                _tokens.InsertBefore(Tokens.PROGRAMS);  // create the Programs folder
                                parseState = ParseStates.PostProgram;
                                break;

                            case "InvalidName": // Tokens.INVALIDNAME: // ::c1\<invalid char>
                            case "Bit": // Tokens.BIT: // ::c1\<number> - since a bit in this position is a variation of invalid name
                                _tokens.RenameGroup(Tokens.PROGRAM);
                                _tokens.InsertBefore(Tokens.PROGRAMS);  // create the Programs folder
                                return; // Parsing complete

                            case "DataLogs": // Tokens.DATALOGS: // :c1\@DataLogs
                                parseState = ParseStates.PostDataLogs;
                                break;

                            default:
                                // Invoke Controller View
                                _tokens.Delete();
                                _tokens.InsertBefore(Tokens.DRILLIN);
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.PostProgram:  // ::c1\P1???
                        IsPastDeviceObjectName = true;
                        switch (_tokens.Group)
                        {
                            case "Terminal": // Tokens.TERMINAL: // ::c1\P1
                                return; // Parsing complete

                            case "DotDelimiter": // Tokens.DOT_DELIMITER:
                                _tokens.Delete();
                                parseState = ParseStates.PostDot;
                                break;

                            case "Dot_Terminator": // Tokens.DOT_TERMINATOR: // ::c1\P1. 
                                // Drill into program's tags
                                _tokens.Replace(Tokens.DRILLIN);
                                return; // Parsing complete

                            default:
                                _tokens.Delete();
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.PostDataLogs:  // ::c1\@DataLogs???
                        IsPastDeviceObjectName = true;
                        switch (_tokens.Group)
                        {
                            case "PathDelimiter": // Tokens.PATH_DELIMITER:
                                _tokens.Delete();  // delete "\"
                                parseState = ParseStates.DataLog;
                                break;

                            case "Path_Terminator": // Tokens.PATH_TERMINATOR:
                                _tokens.Replace(Tokens.DRILLIN);
                                return; // Parsing complete

                            default: // ::c1\@DataLogs 
                                // Display the controller view
                                _tokens.Previous();
                                _tokens.Delete();
                                _tokens.Replace(Tokens.DRILLIN);
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.DataLog:  // ::c1\@DataLogs\???
                        switch (_tokens.Group)
                        {
                            case "Name": // Tokens.NAME:  // ::c1\@DataLogs\DL
                            case "Bit": //Tokens.BIT:   // ::c1\@DataLogs\123
                            case "InvalidName": //Tokens.INVALIDNAME:   // ::c1\@DataLogs\123aa
                                _tokens.RenameGroup(Tokens.DATALOG);
                                break;
                            case "Terminal": // Tokens.TERMINAL: // ::c1\@DataLogs\
                                return; // Parsing complete

                            default:  // currently nothing else is supported
                                _tokens.Delete();
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.PreDot:  // expecting dot
                        switch (_tokens.Group)
                        {
                            case "DotDelimiter": // Tokens.DOT_DELIMITER:
                                _tokens.Delete();
                                parseState = ParseStates.PostDot;
                                break;

                            case "Dot_Terminator": // Tokens.DOT_TERMINATOR:
                                 if (_tokens.PreviousGroup == Tokens.BIT)
                                {   // Can not have .1.
                                    _tokens.Replace(Tokens.TERMINAL);
                                    return; // Parsing complete
                                }
                               _tokens.Replace(Tokens.DRILLIN);
                                return; // Parsing complete

                            default:
                                _tokens.Replace(Tokens.TERMINAL);
                                return; // Parsing Complete
                        }
                        break;

                    case ParseStates.PostDot:
                        switch (_tokens.Group)
                        {
                            case "InvalidToken": // Tokens.INVALID:
                                _tokens.Replace(Tokens.TERMINAL);
                                _tokens.InsertBefore(Tokens.DRILLIN);
                                return; // Parsing Complete

                            case "Name": // Tokens.NAME:
                                IsPastDeviceObjectName = true;
                                _tokens.RenameGroup(Tokens.MEMBER_NAME);
                                parseState = ParseStates.PostTagsAndMembers;
                                break;

                            case "MetaData": // Tokens.METADATA:
                                return; // Parsing Complete

                            case "Bit": // Tokens.BIT:
                                if (_tokens.PreviousGroup == Tokens.BIT)
                                {   // Can not have .1.3
                                    _tokens.Replace(Tokens.TERMINAL);
                                    return; // Parsing complete
                                }
                                parseState = ParseStates.PreDot;
                                break;

                            case "Terminal": // Tokens.TERMINAL:
                                return; // Parsing complete

                            default:
                                _tokens.Delete();
                                return; // Parsing complete
                        }
                        break;

                    case ParseStates.PostTagsAndMembers:  // name????
                        switch (_tokens.Group)
                        {
                            case "DotDelimiter": // Tokens.DOT_DELIMITER:
                                _tokens.Delete();
                                parseState = ParseStates.PostDot;
                                break;
                            case "MetaData": // Tokens.METADATA:
                                break;
                            case "ArrayIndex": // Tokens.ARRAY_INDEX:
                            case "ArrayIndexTerminator": // Tokens.ARRAY_INDEX_TERMINATOR:
                                if (_tokens.Group == Tokens.ARRAY_INDEX_TERMINATOR)
                                {
                                    return; // Parsing complete
                                }
                                parseState = ParseStates.PreDot;
                                break;

                            case "Bracquet_Terminator": // Tokens.BRACQUET_TERMINATOR:
                            case "Dot_Terminator": // Tokens.DOT_TERMINATOR:
                                // Can not have .1[$ or .1.$
                                if (_tokens.PreviousGroup == Tokens.BIT)
                                {
                                    _tokens.Replace(Tokens.TERMINAL);
                                    return; // Parsing complete
                                }
                                // The correct handling of these requires datatype information
                                break;

                            default:
                                return; // Parsing complete
                        }
                        break;
                }
            }

            //If the connect string ended with a device name, we should drill in to the device view
            // even though that is syntactically incorrect.  We are doing this until we commit to update
            // the code to remember which folder you may have selected in the device view (since folders
            // are only GUI elements and not official component path items, we need some additional
            // logic to support this)
            if (parseState == ParseStates.PostDevice)
            {
                //If path was just C1 (and nothing after) we insert drillin after
                _tokens.InsertAfter(Tokens.DRILLIN, string.Empty);
            }
            else if (parseState == ParseStates.PostPath)
            {
                //If path was C1\<something> where the something didn't match any other part of the regex,
                // (C1\@ is an example) then we should insert before since the parser already moved past the device
                _tokens.InsertBefore(Tokens.DRILLIN);
            }
            else if (parseState == ParseStates.PostDot && IsPastDeviceObjectName)
            {
                //If path was C1<somepath>.<something> where the somepath was the name of a first level object beneath a device,
                // and the something didn't match any other part of the regex, (C1.tag.@ is an example) we should drill in 
                _tokens.InsertBefore(Tokens.DRILLIN);
            }
        }

        /// <summary>
        /// Walk the list of tokens in _tokens, and navigate to each item building up the Path.
        /// Perform semantic analysis - i.e. validating the a device comes before a tag
        /// </summary>
        /// <param name="callback">Delegate to call when done</param>
        private void BuildPathForTagBrowser(NavigateStringDelegate callback)
        {
            Action<NavigateStringDelegate> BuildRemainingPathForBrowser = null;
            if (_dibVM.IsAOGPropertyBrowser())
            {
                BuildRemainingPathForBrowser = (x) => BuildRemainingPathForAOGBrowser(x);
            }
            else
            {
                BuildRemainingPathForBrowser = (x) => BuildRemainingPathForTagBrowser(x);
            }

            _tokens.Reset();
            // First token must be a device
            if (_tokens.Group != Tokens.DEVICE)
            {
                // Display the root
                callback(null, null);
            }

            //if there is a root path make sure the selectedItem is in the root path
            else if (_dataContext != null && _dataContext.HasRoot())
            {
                //see if the connect string matches the root              
                if (BuildPathFromDataContextRoot())
                {
                    //build the remaining path items
                    BuildRemainingPathForBrowser((navigatedTo, highlighteditem) =>
                    {
                        callback(navigatedTo, highlighteditem);
                    });
                }
                else
                {
                    // Navigate to the root
                    this._dibVM.NavigateNoGui(_dataContext.RootPath.DataItem, (error) =>
                    {
                        callback(_dataContext.RootPath.DataItem, null);
                    });
                }
            }
            else
            {
                //navigate to the data sources view so we can start to drill into the children
                this._dibVM.NavigateNoGui((DataItemBase)null, (error) =>
                {
                    if (String.IsNullOrEmpty(error))
                    {
                        //build the remaining path items
                        BuildRemainingPathForBrowser((navigatedTo, highlighteditem) =>
                        {
                            callback(navigatedTo, highlighteditem);
                        });
                    }
                    else
                    {
                        LogWrapper.LogException("ConnectStringProcessor Building path for tag browser ", new Exception(error));

                        callback(null, null);
                    }
                });
            }
        }

        /// <summary>
        /// build the path from the datacontext root path
        /// </summary>
        /// <returns>true if the root path matches the connect string; false otherwise</returns>
        private bool BuildPathFromDataContextRoot()
        {
            bool bControllerPath = false;
            bool bFirstRootItem = true;
            foreach (DataItemBase rootItem in _dataContext.RootPath.DataItemList)
            {
                
                //skip the token if the names match
                if ((_tokens.Group == Tokens.PROGRAMS && rootItem == DIResource.DIB_Programs) ||
                    (_tokens.Group == Tokens.DATALOGS && rootItem == DIResource.DIB_DataLogs) ||
                    _tokens.Name == rootItem.CommonName)                    
                {
                    //have we excluded all children (currently it can only be controllers)
                    if (_dataContext.ExcludeAllChildrenOfType != DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.None)
                    {

                        UUID resourceId = rootItem.GetResourceTypeAsUUID();
                        //is the first item a controller?
                        if (bFirstRootItem && (ResourceBase.IsEqual(resourceId, TypeIdentifiers.getResourceType_Controller())))
                        {
                            bControllerPath = true;
                            bFirstRootItem = false;
                        }
                        //is this a controller path and datalogs have been included
                        else if (bControllerPath && _dataContext.IncludeAllOfType == DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs)
                        {
                            //if the item is not datalogs or a datalog then exit connect string processing
                            if (!ResourceBase.IsEqual(resourceId, TypeIdentifiers.ResourceType_DataLogs) &&
                                !ResourceBase.IsEqual(resourceId, TypeIdentifiers.ResourceType_DataLog))
                                return false;
                        }
                    }
                    _tokens.Next();
                }
                else
                    return false;
 
            }
            return true;
        }
        /// <summary>
        /// Walk the list of remaining tokens in _tokens, and navigate to each item building up the Path.
        /// Perform semantic analysis - i.e. validating the a device comes before a tag
        /// </summary>
        /// <param name="callback">Delegate to call when done</param>
        private void BuildRemainingPathForTagBrowser( NavigateStringDelegate callback)
        {
            //if this was not processed as part of the root, check to see if it is a device
            if (_tokens.Group == Tokens.DEVICE)
            {
                // Does device exist?
                DataItemBase deviceItem = _dibVM.GetDeviceItemByName(_tokens.Name);
                if (deviceItem != null)
                {
                    //if the device is an HMI Device and HMI Devices are excluded then leave
                    UUID resourceId = deviceItem.GetResourceTypeAsUUID();

                    // if the device is an HMI Device and NextGroup = Programs or Datalogs then leave as this is not valid
                    if (ResourceBase.IsEqual(resourceId, TypeIdentifiers.ResourceType_HMIDevice) && ((_tokens.NextGroup == Tokens.PROGRAMS) || (_tokens.NextGroup == Tokens.DATALOGS)))
                    {
                        //We do want this to navigate in to the HMI device view to reinforce that eventually a slash (i.e. syntactically programs or datalogs)
                        // may place you into a child folder of an HMI device (screens / AOG) or eventually user defined tags and folders
                        _path.Add(PathElementFactory.Instance().CreatePathElement(deviceItem));
                        _tokens.Replace(Tokens.DRILLIN);
                        _tokens.Previous();
                        NavigateTagBrowser(deviceItem, callback);
                    }
                    //if the device is an HMI Device and it's HMI Devices are excluded then leave
                    else if (ResourceBase.IsEqual(resourceId, TypeIdentifiers.ResourceType_HMIDevice) && 
                        _dataContext.ExcludeAllOfType == DataItemBrowserContext.ExcludeAllOfTypeEnum.HMIDevice)
                    {
                        callback(null, null);
                    }
                    else
                    {
                        //Add device path element
                        _path.Add(PathElementFactory.Instance().CreatePathElement(deviceItem));
                        NavigateTagBrowser(deviceItem, callback);
                    }
                }
                else //invalid selectedItem then navigate to root
                {
                    // Invalid device name. Display the DSV
                    callback(null, null);
                }
 
            }
            else
            {
                //step back so it will be on the last token 
                _tokens.Previous();
                //use the root dataitem to continue to drill into this path
                NavigateTagBrowser(_dataContext.RootPath.DataItem, callback);
            }
            
        }

        /// <summary>
        /// Responsible for recursively navigating into the tokens collection.
        /// </summary>
        /// <param name="parentItem">Load the dataitems for the parent</param>
        /// <param name="callback">Delegate to call when done</param>
        private void NavigateTagBrowser(DataItemBase parentItem, NavigateStringDelegate callback)
        {
            try
            {
                // Get the next token
                _tokens.Next();

                if ((_tokens.Group == Tokens.TERMINAL) || (!parentItem.IsStructured))
                {
                    // The valid parts of the SelectedItem have been navigated to.
                    // Navigate to the last dataitem and highlight the SavedHighlightedElement
                    if (_path.Items.Count > 1)
                    {
                        DataItemBase hilightedItem = _path.Last.DataItem;
                        
                        //Special case: we don't want to highlight the data logs folder because there is not a direct
                        // link between it and the "@DataLogs" string
                        if(_path.Last.DataItem == DIResource.DIB_DataLogs)
                            hilightedItem = null;

                        callback(_path.Last.DataItem, hilightedItem);
                    }
                    else
                    {
                        callback(parentItem, null);
                    }
                }
                //are we trying to navigate to a situation that should not be navigable because of datacontext?
                else if ((_tokens.Group == Tokens.PROGRAM  && !_dataContext.IsProgramPathIncluded(_path,_tokens.Name))
                        || (_tokens.Group==Tokens.PROGRAMS && !_dataContext.IsProgramTypeIncluded())
                        || (_tokens.Group == Tokens.DATALOGS && !_dataContext.IsDataLogTypeIncluded())
                        || (_tokens.Group == Tokens.TAGS_AND_PROPERTIES && !_dataContext.IsTagsAndPropertiesTypeIncluded()))
                {
                    // parentItem was valid, navigate into it
                    _dibVM.NavigateNoGui(parentItem, (error) =>
                    {
                        callback(parentItem, null);
                    });
                    return;
                }
                else
                {
                    // Navigate to parentItem to acquire its children
                    _dibVM.NavigateNoGui(parentItem, (error) =>
                    {
                        ProcessNavigateTagBrowser(parentItem, callback, error);
                    });
                }
            }
            catch (System.Exception e)
            {
                string msg = " Connect string = " + ConnectString +
                    " Previous token = " + _tokens.PreviousGroup + "(" + _tokens.PreviousName + ")" +
                    " Current token = " + _tokens.Group + "(" + _tokens.Name + ") e = ";
                LogWrapper.LogException("NavigateTagBrowser Error:" + msg, e);

                // Navigate back to the parent as this is the last correct dataitem
                callback(parentItem, null);
            }
        } //NavigateTagBrowser

        /// <summary>
        /// This method is responsible for using the tokens found in _tokens to navigate to the last valid dataitem.
        /// The semantic analysis for the connect string is performed here as the dataitem's type is available.
        /// The first call to this method is sent the dataitem for the device.
        /// The method is recursive, so each subsequent invocation contains the next dataitem associated with
        /// the next token.  Some of the tokens are commands: 
        ///     Tokens.DRILLIN - Drill into the parentItem.  Highlight the first dataitem
        ///     Tokens.TERMINAL - The list of tokens has been traversed. Establish the SavedHighlightedElement and highlight it..
        ///     Tokens.DOT_TERMINATOR - Validate that the preceding dataitem supports the DOT_TERMINATOR
        ///     Tokens.BRACQUET_TERMINATOR - Validate that the preceding dataitem supports the BRACQUET_TERMINATOR
        ///     Tokens.TAGS_AND_PROPERTIES - Create a path element for the TagsAndPropsItem folder
        ///     Tokens.PROGRAM - Create a path element for the Programs folder
        ///     Tokens.DATALOG - Create a path element for the DataLogs folder
        /// </summary>
        /// <param name="parentItem">Load the dataitems for the parent</param>
        /// <param name="callback">Delegate to call when done</param>
        /// <param name="error">Error string</param>
        private void ProcessNavigateTagBrowser(DataItemBase parentItem, NavigateStringDelegate callback, string error)
        {
            try
            {
                // Callback function
                if (String.IsNullOrEmpty(error))
                {
                    // parent's dataitems were successfully loaded
                    string name = string.Empty;
                    switch (_tokens.Group)
                    {
                        // Drill into the last element in the Path and highlight the first dataitem
                        case "DrillIn": // Tokens.DRILLIN:
                            callback(parentItem, null);
                            return;

                        // Add TagsAndPropsItem to the Path
                        case "TagsAndProperties": // Tokens.TAGS_AND_PROPERTIES:
                            _path.Add(PathElementFactory.Instance().CreatePathElement(DIResource.DIB_TagsAndProps));
                            NavigateTagBrowser(DIResource.DIB_TagsAndProps, callback);
                            return;

                        // Add Programs to the Path
                        case "Programs": // Tokens.PROGRAMS:
                            _path.Add(PathElementFactory.Instance().CreatePathElement(DIResource.DIB_Programs));
                            NavigateTagBrowser(DIResource.DIB_Programs, callback);
                            return;

                        // Add DataLogs to the Path
                        case "DataLogs": // Tokens.DATALOGS:

                            //If this is the last token, skip adding the Data Logs folder since we won't be drilling in
                            if (_tokens.NextGroup == Tokens.TERMINAL)
                            {
                                callback(parentItem, null);
                            }
                            else
                            {
                                _path.Add(PathElementFactory.Instance().CreatePathElement(DIResource.DIB_DataLogs));
                                NavigateTagBrowser(DIResource.DIB_DataLogs, callback);
                            }
                            
                            return;

                        // The parent must be an array, otherwise we terminate
                        case "ArrayIndex": // Tokens.ARRAY_INDEX:
                        case "ArrayIndexTerminator": // Tokens.ARRAY_INDEX_TERMINATOR:
                            if (MetaDataHelper.IsArrayBaseType(parentItem))
                                name = _tokens.PreviousName + _tokens.Name;
                            else
                            {
                                // parentItem was not an array
                                callback(parentItem, null);
                                return;
                            }
                            break;

                        // Highlight the parentItem
                        case "Dot_Terminator": // Tokens.DOT_TERMINATOR:
                        case "Bracquet_Terminator": // Tokens.BRACQUET_TERMINATOR:
                            _path.SetActive(_path.Last);
                            callback(parentItem, null);
                            return;

                        // Only need the name of the token
                        case "MemberName": // Tokens.MEMBER_NAME:
                        case "Program": // Tokens.PROGRAM:
                        case "DataLog": // Tokens.DATALOG:
                        case "Bit": // Tokens.BIT:
                        case "MetaData": // Tokens.METADATA:
                            name = _tokens.Name;
                            break;

                        default:
                            LogWrapper.LogException("ProcessNavigateTagBrowser: unexpected token was encountered", new Exception(error));
                            // Navigate back to the parent as this is the last correct dataitem
                            callback(parentItem, null);
                            return;
                    }

                    // Get the DataItem designated by its name
                    DataItemBase validDib = _dibVM.GetDataItemByName(name);
                    if (validDib != null)
                    {
                        // The name of the dataitem exists.
                        // Create a path element and add it to path
                        _path.Add(PathElementFactory.Instance().CreatePathElement(validDib));

                        if (_tokens.Group == Tokens.MEMBER_NAME)
                        {
                            bool stopNavigate = false;
                            //If the next group is a path separator or invalid name, stop the navigate since those should not allow
                            // for entry into a tag/member name (only valid for "top level objects" like Programs, Data Logs, etc)
                            if (_tokens.NextGroup == Tokens.PATH_DELIMITER ||
                               _tokens.NextGroup == Tokens.PATH_TERMINATOR ||
                               _tokens.NextGroup == Tokens.INVALIDNAME)
                            {
                                stopNavigate = true;
                            }
                            else
                            {
                                bool isArray = MetaDataHelper.IsArrayBaseType(validDib);
                                bool NextIsForArray = (_tokens.NextGroup == Tokens.BRACQUET_TERMINATOR) ||
                                                      (_tokens.NextGroup == Tokens.ARRAY_INDEX) ||
                                                      (isArray && _tokens.NextGroup == Tokens.METADATA) ||
                                                      (_tokens.NextGroup == Tokens.ARRAY_INDEX_TERMINATOR);

                                //If the next group does not match whether we are an array or not, stop the navigation
                                if (isArray != NextIsForArray)
                                    stopNavigate = true;
                            }

                            //If we determined above we want to stop the navigate, enter the token to make it happen
                            if(stopNavigate)
                                _tokens.InsertAfter(Tokens.TERMINAL, string.Empty);
                        }

                        // Traverse to the next level
                        NavigateTagBrowser(validDib, callback);
                    }
                    else
                    {
                        // An invalid token was encountered (no DataItemBase for the name within the specified parent)
                        // Need to check the parentItem's type to determine what to do.
                        if (MetaDataHelper.IsArrayBaseType(parentItem))
                        {
                            // Invalid array index - drill into the array
                            callback(parentItem, null);
                        }

                        // Note - the following all Navigate to parentItem.  I left this code this way
                        // as it denotes the error conditions being caught
                        else if (MetaDataHelper.IsNumericBaseType(parentItem))
                        {
                            // Invalid bit index - drill into the integer
                            // Invalid MetaData
                            callback(parentItem, null);
                        }
                        else
                            // ::c1\qq Invalid program
                            // ::c1\P1.qq Invalid name following valid program
                            // ::c1\P1\T1.qq Invalid name following a non-array structure T1
                            callback(parentItem, null);
                    }
                }
                else
                {
                    LogWrapper.DibGeneralLog.Warn("Drilling into a connect string returned an error from NavigateNoGui", new Exception(error));
                    // Navigate back to the parent as this is the last correct dataitem
                    callback(parentItem, null);
                }
            } // try
            catch (System.Exception e)
            {
                string msg = " Connect string = " + ConnectString +
                    " Previous token = " + _tokens.PreviousGroup + "(" + _tokens.PreviousName + ")" +
                    " Current token = " + _tokens.Group + "(" + _tokens.Name + ") e = ";
                LogWrapper.LogException("NavigateTagBrowser for " + (_dibVM.IsAOGPropertyBrowser() ? "AOG Properties" : "Tags") + " Error:" + msg, e);
                // Navigate back to the parent as this is the last correct dataitem
                callback(parentItem, null);
            }
        } // ProcessNavigateTagBrowser

        /// <summary>
        /// class to manage the generic DIB navigate list
        /// </summary>
        class NavigateStringTokens
        {
            private List<DataItemBase> _tokens = new List<DataItemBase>();
            private int _index = 0;  // Protected index into tokens

            public NavigateStringTokens()
            {
                _index = 0;
            }

            /// <summary>
            /// Get the current item. internal index is not changed
            /// </summary>
            /// <returns>item at the current index or null if at the end of the list</returns>
            public DataItemBase Current()
            {
                if (_index < _tokens.Count)
                    return _tokens[_index];

                return null;
            }

            /// <summary>
            /// Advance the internal index and get the item at that index.
            /// </summary>
            /// <returns>The next item or null if at the end of the list</returns>
            public DataItemBase GetNextItem()
            {
                if (_index < _tokens.Count - 1)
                {
                    ++_index;
                    return _tokens[_index];
                }
                return null;
            }

            /// <summary>
            /// Set the items in the internal list to same as newList
            /// </summary>
            /// <param name="newList">Items list</param>
            public void AddRange(List<DataItemBase> newList)
            {
                _tokens.Clear();
                _tokens.AddRange(newList);
                _index = 0;
            }
        } // NavigateStringTokens

        class ConnectStringTokens
        {

            private List<Token> _tokens = new List<Token>(); // List of Tokens to be manipulated
            private int _index = 0;  // Protected index into tokens

            /// <summary>
            /// Constructor
            /// Create sentinels at either end of the collection
            /// </summary>
            public ConnectStringTokens()
            {
                _tokens.Add(new Token { Group = Tokens.INITIAL, Name = Tokens.INITIAL });
                _tokens.Add(new Token { Group = Tokens.TERMINAL, Name = Tokens.TERMINAL_STRING });
                _index = 0;
            }

            /// <summary>
            /// Add a token just prior to the TERMINAL
            /// </summary>
            /// <param name="group">Group name of the token</param>
            /// <param name="name">Name of the token</param>
            public void Add(string group, string name)
            {
                _index = _tokens.Count - 1;              
                if (group != Tokens.TERMINAL)
                {
                    // strip off one or more leading characters that act as delimiters
                    name = name.TrimStart(new char[] { '.', ':', '\\', (group == Tokens.METADATA ? Char.MinValue : '@')});
                    _tokens.Insert(_index, new Token { Group = group, Name = name });
                }
            }

            /// <summary>
            /// Delete the current token.  It is syntactically correct but semantically invalid
            /// </summary>
            public void Delete()
            {
                if ((_tokens[_index].Group != Tokens.INITIAL) &&
                    (_tokens[_index].Group != Tokens.TERMINAL))
                    _tokens.RemoveAt(_index);
            }


            /// <summary>
            /// Insert a token just before the current token
            /// </summary>
            /// <param name="group">Group name of the token</param>
            public void InsertBefore(string group)
            {
                _tokens.Insert(_index, new Token { Group = group, Name = string.Empty });
            }

            /// <summary>
            /// Insert a token just after the current token
            /// </summary>
            /// <param name="group">Group name of the token</param>
            /// <param name="name">Name of the token</param>
            public void InsertAfter(string group, string name)
            {
                name = name.TrimStart(new char[] { '.', ':', '\\' });
                _tokens.Insert(_index + 1, new Token { Group = group, Name = name });
            }

            /// <summary>
            /// Replace the current token's group
            /// </summary>
            /// <param name="group">Group name of the token</param>
            public void Replace(string group)
            {
                _tokens[_index].Group = group;
            }

            /// <summary>
            /// Return the Group of the current token
            /// </summary>
            public string Group
            {
                get { return _tokens[_index].Group; }
            }

            /// <summary>
            /// Return the Group of the previous token
            /// Protecting against array boundary 
            /// </summary>
            public string PreviousGroup
            {
                get
                {
                    int index = _index - 1;
                    if (index < 0)
                        index = 0;
                    return _tokens[index].Group;
                }
            }

            /// <summary>
            /// Return the Group of the next token
            /// Protecting against array boundary 
            /// </summary>
            public string NextGroup
            {
                get
                {
                    int index = _index + 1;
                    if (index == _tokens.Count)
                        index = _index;
                    return _tokens[index].Group;
                }
            }

            /// <summary>
            /// Change the group name of the current token
            /// </summary>
            public void RenameGroup( string group )
            {
                _tokens[_index].Group = group;
            }

            /// <summary>
            /// Return the Name of the current token
            /// </summary>
            /// <returns></returns>
            public string Name
            {
                get { return _tokens[_index].Name; }
            }

            /// <summary>
            /// Return the Name of the previous token
            /// Protecting against array boundary 
            /// </summary>
            public string PreviousName
            {
                get
                {
                    int index = _index - 1;
                    if (index < 0)
                        index = 0;
                    return _tokens[index].Name;
                }
            }

            /// <summary>
            /// Walk to the next token
            /// </summary>
            public void Next()
            {
                if (_index != _tokens.Count)
                    ++_index;
            }

            /// <summary>
            /// Walk to the previous token
            /// </summary>
            public void Previous()
            {
                if (_index >0 )
                    --_index;
            }

            /// <summary>
            /// Must be called prior to using the collection
            /// </summary>
            public void Reset()
            {
                _index = 1;
            }
        } // ConnectStringTokens


        /// Helper class for ConnectStringTokens
        public class Token
        {
            public string Group { get; set; }
            public string Name { get; set; }
        }

    }  // ConnectString
} // Namespace
