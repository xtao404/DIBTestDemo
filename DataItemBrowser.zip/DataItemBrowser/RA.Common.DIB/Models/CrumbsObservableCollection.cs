using System.Linq;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System;

namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// wraps the generic observable collection so it can handle PathElements notifications
    /// </summary>
    public class CrumbsObservableCollection : ObservableCollection<ACrumb>
    {

        /// <summary>
        /// holds a reference to the Path object that holds the PathElements collection
        /// </summary>
        private Path _path;

        /// <summary>
        /// constructor - passes in a reference to the DIBViewModel's Path object
        /// </summary>
        /// <param name="path"></param>
        public CrumbsObservableCollection(Path path)
        {
            _path = path;
                       
            //listen for PathElements collection changes
            _path.Items.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(PathElements_CollectionChanged);
            
            //listen for PathElements active path changes
			_path.Items.ActivePathChanged += new System.ComponentModel.PropertyChangedEventHandler(PathElements_ActivePathChanged);
        }

        /// <summary>
        /// notification that the PathElements collection has changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void PathElements_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            //assumption that delete always deletes from the end of the collection
            if (e.OldItems != null)
            {

 
                //remove each crumb in the collection skipping the home/menu crumbs based on the
                // computations above
                foreach (IPathElement oldPathElement in e.OldItems)
                {

                    for (int i = this.Count - 1; i >= 0; i--)
                    {
                        ACrumbWithPathElement peCrumb = this[i] as ACrumbWithPathElement;
                        if (peCrumb != null && oldPathElement == peCrumb.PathElement)
                        {
                            RemoveAt(i);
                            break;
                        }
                    }
                }
            }

            //this is always called after the delete
            if (e.NewItems != null)
            {
               
                //adding the home crumb
                if (this.Count == 0)
                {
                    // create a home crumb - note that this is not in the PathElements
                    ACrumb crumb = new HomeCrumb(e.NewItems[0] as IPathElement);
                    Add(crumb);

                    // create a menu crumb for the backward overflow menu
                    Add(new LMenuCrumb());

                    //add a text crumb for each PathElement in the collection
                    for (int i = 1; i < e.NewItems.Count; i++)
                    {
                        crumb = new TextCrumb(e.NewItems[i] as IPathElement);
                        Add(crumb);
                    }

                    crumb.IsLast = true;

                    // create a menu crumb for the forward overflow menu
                    Add(new RMenuCrumb());
                }
                else
                {
                    foreach (IPathElement pe in e.NewItems)
                    {
                        TextCrumb tCrumb = new TextCrumb(pe);

                        //Insert in the next to last crumb index
                        // as the last crumb will always be the
                        // forward overflow menu crumb
                        Insert(this.Count - 1, tCrumb);
                    }
                }
            }
            

            UpdateCrumbAttributes();
        }

		/// <summary>
		/// notification that the PathElements active path has changed
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		void PathElements_ActivePathChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			UpdateCrumbAttributes();
			
			NotifyActiveCrumbChanged();
		}

        /// <summary>
        /// Navigate to the first forward crumb, if this crumb does not exist nothing happens
        /// </summary>
        public void NavigateForward()
        {
            //defer work to the Path object
            _path.NavigateForward();
        }

        /// <summary>
        /// get forward crumb, null if one does not exist
        /// </summary>
        public IPathElement Forward
        {
            get
            {
                //defer property to the Path object
                return _path.Forward;
            }
        }

        /// <summary>
        /// Navigate to the first backward crumb, if this crumb does not exist nothing happens
        /// </summary>
        public void NavigateBack()
        {
            //defer work to the Path object
            _path.NavigateBack();
        }

        /// <summary>
        /// get backward crumb, null if one does not exist
        /// </summary>
        public IPathElement Back
        {
            get
            {
                //defer property to the Path object
                return _path.Back;
            }
        }

        /// <summary>
        /// get the active element in the collection
        /// </summary>
        public IPathElement ActiveElement
        {
            get
            {
                //defer property to the Path object
                return _path.ActiveElement;
            }
        }

        /// <summary>
        /// set the active element in the collection
        /// </summary>
        /// <param name="activeCrumb"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        public void SetActive(TextCrumb activeCrumb)
        {
            //defer work to the Path object
            _path.SetActive(activeCrumb == null ? null : activeCrumb.PathElement);
        }
        
        /// <summary>
        /// Updates various crumb attributes (IsLast, HasChildren)
		/// based on the current state of the crumbs in this OC
        /// </summary>
        private void UpdateCrumbAttributes()
        {
			//Loop through the crumbs to find the last text crumb
			// also recording whether there are any forward crumbs
			TextCrumb lastTextCrumb = null;
            ACrumb lastCrumb = null;
			bool HasForward = false;
			foreach (ACrumb crumb in this)
			{
				crumb.IsLast = false;
				
				TextCrumb textCrumb = crumb as TextCrumb;
                if (textCrumb != null)
                {
                    textCrumb.BeforeForwardCrumb = false;

                    if (textCrumb.IsActive)
                    {
                        lastTextCrumb = textCrumb;
                        lastCrumb = crumb;
                    }
                    else
                    {
                        HasForward = true;
                    }

                }
                else
                {
                    SearchCrumb searchCrumb = crumb as SearchCrumb;
                    //since search crumb is always the active crumb then set last crumb
                    if (searchCrumb != null)
                    {
                        lastCrumb = crumb;
                    }
                }
			}

			//set the last crumb attribute if we found an active text crumb
            if (lastCrumb != null)
			{
                //set last crumb
                lastCrumb.IsLast = true;
                //if the last crumb is a TextCrumb also set its BeforeFrowardCrumb 
                if (lastCrumb == lastTextCrumb)
                {
                    lastTextCrumb.IsLast = true;
                    lastTextCrumb.BeforeForwardCrumb = HasForward;
                }
			}
			
			//set whether the home crumb is before only forward crumbs
			HomeCrumb homeCrumb = this.First() as HomeCrumb;
            homeCrumb.BeforeOnlyForwardCrumbs = (lastCrumb == null && HasForward);
            homeCrumb.IsLast = this.ActiveElement == homeCrumb.PathElement && lastCrumb==null;
               
			//set whether the forward menu crumb has children
			MenuCrumb ForwardMenuCrumb = this.Last() as MenuCrumb;
            if (ForwardMenuCrumb != null)
			    ForwardMenuCrumb.HasChildren = HasForward;
        }

        /// <summary>
        /// The the last container element in the collection
        /// </summary>
        public IPathElement LastContainerElement
        {
            get
            {
                //defer property to the Path object
                return _path.LastContainerElement;
            }
        }

        /// <summary>
        /// Add search crumb to the end of the crumb collection
        /// </summary>
        public void AddSearchCrumb()
        {
            //make sure you do not already have a search crumb
            if (FindSearchCrumb() == -1)
            {
                //add search crumb
                SearchCrumb searchCrumb = new SearchCrumb();
                //remove forward crumbs on a search
                this._path.RemoveInactiveElements();
                //must be before the right menu crumb that holds forward crumbs
                this.Insert(this.Count() - 1, searchCrumb);
                //update attributes and notify to update view
                UpdateCrumbAttributes();
                NotifyActiveCrumbChanged();
            }
        }

        /// <summary>
        /// Remove search crumb from the crumb collection
        /// </summary>
        public void RemoveSearchCrumb()
        {
            //find the search crumb
            int i = FindSearchCrumb();
            //already deleted then just return
            if (i == -1)
                return;
            //remove it and updates the notify
            this.RemoveAt(i);
            //update attributes and notify to update view
            UpdateCrumbAttributes();
            NotifyActiveCrumbChanged();
        }

        /// <summary>
        /// is there a search crumb in this collection
        /// </summary>
        /// <returns></returns>
        public bool HasSearchCrumb()
        {
            //find the search crumb
            int i = FindSearchCrumb();
            //already deleted then just return
            if (i == -1)
                return false;
            return true;
        }
        /// <summary>
        /// find the index of the search crumb
        /// </summary>
        /// <returns></returns>
        private int FindSearchCrumb()
        {
            for (int i = this.Count() - 1; i >= 0; i--)
            {
                if ((this[i] as SearchCrumb) != null)
                    return i;
            }
            return -1;
        }

        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {
            foreach (ACrumb crumb in this)
            {
                if (crumb is TextCrumb)
                {
                    ((TextCrumb)crumb).CleanupEventSubscriptions();
                }

            }

            _path.Items.CollectionChanged -= new System.Collections.Specialized.NotifyCollectionChangedEventHandler(PathElements_CollectionChanged);

            _path.Items.ActivePathChanged -= new System.ComponentModel.PropertyChangedEventHandler(PathElements_ActivePathChanged);
        }

        #region Active crumb event handling

        /// <summary>
        /// Event routing triggered when the active crumb is changed
        /// </summary>
        public event PropertyChangedEventHandler ActiveCrumbChanged;

		protected void NotifyActiveCrumbChanged()
		{
			if (ActiveCrumbChanged != null)
			{
				ActiveCrumbChanged(this, new PropertyChangedEventArgs(String.Empty));
			}
		}

		#endregion
    }
}
