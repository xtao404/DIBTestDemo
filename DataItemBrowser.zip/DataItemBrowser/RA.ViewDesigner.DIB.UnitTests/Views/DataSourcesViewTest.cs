﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using AvalonUnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.Views;

namespace DataItemBrowserUT
{
    [TestClass]
    public class DataSourcesViewTest
    {
        /// <summary>
        /// DataSourcesView UI data binding check.
        /// </summary>
        [TestMethod()]
        public void DataSourcesView_DataBindingIsCorrectTest()
        {
            AvalonTestRunner.RunInSTA(delegate()
            {
                // Create the control using a delegate to ensure binding errors generated during
                // control creation are caught.
                Func<object> controlCreator = delegate()
                {
                    // what ever your control is called
                    DIBTreeView control = new DIBTreeView();
                    return control;
                };

                AvalonTestRunner.RunDataBindingTests(controlCreator);
            });
        }
    }
}
