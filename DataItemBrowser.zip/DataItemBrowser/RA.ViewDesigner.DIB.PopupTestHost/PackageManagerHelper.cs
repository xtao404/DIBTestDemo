﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.CompilerServices;
using RockwellAutomation.Message.PackageManager;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI;
using System.IO;
using RockwellAutomation.Message.RoaPackages;
using System.Diagnostics;

namespace RockwellAutomation.DesignTimeClient.PopUpTestHost
{
    /// <summary>
    /// Class to help interface with the ROA Package Manager Service
    /// </summary>
    class PackageManagerHelper
    {
        private static PackageManagerHelper _self;

        private IPackageManagerService _packageManagerService = null;

        //This is consistent with the way DTC creates projects
        private static string PROJECT_DB_NAME = "ViewProject.h2.db";

        private EventAsyncHandler _createPackageEvent       = new EventAsyncHandler("CreatePackage");
        private EventAsyncHandler _openPackageEvent         = new EventAsyncHandler("OpenPackage");
        private EventAsyncHandler _savePackageEvent         = new EventAsyncHandler("SavePackage");
        private EventAsyncHandler _closePackageEvent        = new EventAsyncHandler("ClosePackage");
        private EventAsyncHandler _getOpenPackagesEvent     = new EventAsyncHandler("GetOpenPackages");
        private EventAsyncHandler _addNewDatabasesEvent     = new EventAsyncHandler("AddNewDatabases");
        private EventAsyncHandler _readPackageManifestEvent = new EventAsyncHandler("ReadPackageManifest");

        //Strings to cache any errors that may have occurred as a result of most recent package operations
        public string LastPackageOpenResponseError { get; set; }
        public string LastInitializeError { get; set; }

        /// <summary>
        /// Return true if the package manager helper has been successfully initialized
        /// </summary>
        public bool Initialized
        {
            get
            {
                return _packageManagerService != null && string.IsNullOrEmpty(LastInitializeError);
            }
        }

        /// <summary>
        /// Constructor (private as class uses singleton pattern)
        /// </summary>
        private PackageManagerHelper()
        {
        }

        /// <summary>
        /// Gets single instance of the PackageManagerHelper
        /// </summary>
        /// <returns>The PackageManagerHelper singleton</returns>
        [MethodImpl(MethodImplOptions.Synchronized)]
        [DebuggerStepThrough]
        public static PackageManagerHelper Instance()
        {
            if (_self == null)
                _self = new PackageManagerHelper();

            return _self;
        }

        /// <summary>
        /// Connects to the package manager service and sets up various handlers
        /// </summary>
        /// <returns>True if successful</returns>
        public bool Initialize()
        {
            bool Success = true;
            LastInitializeError = String.Empty;

            try
            {
                _packageManagerService = PackageManagerServiceProxyFactory.instance().packageManagerService("PackageManagerService");
                _packageManagerService.AddCreatePackageEventHandler(_createPackageEvent.Handler);
                _packageManagerService.AddOpenPackageEventHandler(_openPackageEvent.Handler);
                _packageManagerService.AddSavePackageEventHandler(_savePackageEvent.Handler);
                _packageManagerService.AddClosePackageEventHandler(_closePackageEvent.Handler);
                _packageManagerService.AddGetOpenPackagesEventHandler(_getOpenPackagesEvent.Handler);
                _packageManagerService.AddAddNewDatabasesEventHandler(_addNewDatabasesEvent.Handler);
                _packageManagerService.AddReadPackageManifestEventHandler(_readPackageManifestEvent.Handler);

                // Create a V3 package. By default a V2 package is created
                const uint designerVersion = 3;

                SetDesignerVersionRequest.Builder builder = SetDesignerVersionRequest.CreateBuilder();
                SetDesignerVersionRequest setDesignerVersionRequest = builder.SetDesignerVersion(designerVersion).Build();
                _packageManagerService.SetDesignerVersion(setDesignerVersionRequest);
            }
            catch (Exception ex)
            {
                LastInitializeError = ex.Message;
                Console.WriteLine("PackageManagerHelper Initialize: Failed to connect to the package manager service " + ex.Message);
                _packageManagerService = null;
                Success = false;
            }

            return Success;
        }

        /// <summary>
        /// Well known data base name to be used when adding a project to a package
        /// </summary>
        public static string ProjectDatabaseName { get { return PROJECT_DB_NAME; } }

        /// <summary>
        /// Gets a list of open packages
        /// </summary>
        /// <returns>An IList of OpenPackageInfo objects representing any open currently open packages</returns>
        public IList<OpenPackageInfo> GetOpenPackages()
        {
            if (_packageManagerService == null)
            {
                throw new NullReferenceException("GetOpenPackages failure: no connection exists to the package manager service");
            }

            //Make a call to get the open packages
            _packageManagerService.GetOpenPackages(GetOpenPackagesRequest.DefaultInstance);

            //Wait for the response data to come back
            Google.ProtocolBuffers.ByteString messageBody = _getOpenPackagesEvent.GetResponseData();

            //Format the response data
            GetOpenPackagesResponse openPackages = GetOpenPackagesResponse.CreateBuilder().MergeFrom(messageBody).Build();

            return openPackages != null ? openPackages.OpenPackagesList : null;
        }

        /// <summary>
        /// Creates a ViewE package at the path specified
        /// </summary>
        /// <param name="uri">path (ending in .VPD) to the package on the file system to create</param>
        /// <returns>Package id for the created package (or null if there was an error creating)</returns>
        public UUID CreatePackage(string uri)
        {
            if (uri == null || !uri.EndsWith(".VPD"))
            {
                throw new InvalidOperationException("CreatePackage failure: uri must be a valid system path which ends in the VPD extension");
            }
            else if (_packageManagerService == null)
            {
                throw new NullReferenceException("CreatePackage failure: no connection exists to the package manager service");
            }
            
            //Create a package request object
            PackageCreateRequest.Builder packageCreateRequest = new PackageCreateRequest.Builder();
            packageCreateRequest.SetUri(uri).SetRequestUUID(UniversalIdentifier.GenerateNewValue()._uuid);

            //Make the call to create the package
            _packageManagerService.CreatePackage(packageCreateRequest.Build());

            //Wait for the reponse data to come back
            Google.ProtocolBuffers.ByteString messageBody = _createPackageEvent.GetResponseData();

            //Format the response data
            PackageCreateResponse packageCreatedResponse = PackageCreateResponse.CreateBuilder().MergeFrom(messageBody).Build();

            //Determine success
            bool bSuccess = (packageCreatedResponse != null && !packageCreatedResponse.HasPackageFault && packageCreatedResponse.HasPackageUUID);

            return bSuccess ? packageCreatedResponse.PackageUUID : null;
        }

        /// <summary>
        /// Creates a ViewE project inside the passed package
        /// </summary>
        /// <param name="packageId">id of the package to create a project database in</param>
        /// <returns>Project id for the created project (or null if there was an error creating)</returns>
        public UUID CreateProjectDbInPackage(UUID packageId)
        {
            if (packageId == null)
            {
                throw new InvalidOperationException("CreateProject failure: packageId must be a valid package id");
            }
            else if (_packageManagerService == null)
            {
                throw new NullReferenceException("CreateProject failure: no connection exists to the package manager service");
            }

            DatabaseInfo ProjectDb = DatabaseInfo.CreateBuilder().SetDatabaseUUID(UniversalIdentifier.GenerateNewValue()._uuid)
                                                                 .SetName(PROJECT_DB_NAME).Build();

            //Make a call to open the package
            PackageAddNewDatabaseRequest packageAddNewDbRequest = PackageAddNewDatabaseRequest.CreateBuilder()
                            .AddNewDatabase(ProjectDb)
                            .SetRequestUUID(UniversalIdentifier.GenerateNewValue()._uuid)
                            .SetPackageUUID(packageId)
                            .Build();
            _packageManagerService.AddNewDatabases(packageAddNewDbRequest);

            //Wait for the response data to come back
            Google.ProtocolBuffers.ByteString messageBody = _addNewDatabasesEvent.GetResponseData();

            //Format the response data
            PackageAddNewDatabaseResponse packageAddNewDbResponse = PackageAddNewDatabaseResponse.CreateBuilder().MergeFrom(messageBody).Build();

            //Determine success
            bool bSuccess = (packageAddNewDbResponse != null && !packageAddNewDbResponse.HasPackageFault);

            return bSuccess ? ProjectDb.DatabaseUUID : null;
        }

        /// <summary>
        /// Attempts to open the package at the specified file URI
        /// </summary>
        /// <param name="uri">file path and name to the package to open</param>
        /// <returns>Package id for the opened package (or null if there was an error opening)</returns>
        public UUID OpenPackage(string uri)
        {
            //Allow lowercase vpd since at one point we created the VPD lowercase
            if (uri == null || !uri.ToLower().EndsWith(".vpd") || !File.Exists(uri))
            {
                throw new InvalidOperationException("OpenPackage failure: uri must be a valid system path which ends in the vpd extension");
            }
            else if (_packageManagerService == null)
            {
                throw new NullReferenceException("OpenPackage failure: no connection exists to the package manager service");
            }

            //Make a call to open the package
            PackageOpenRequest packageOpenRequest = PackageOpenRequest.CreateBuilder().SetUri(uri).SetRequestUUID(UniversalIdentifier.GenerateNewValue()._uuid).Build();
            _packageManagerService.OpenPackage(packageOpenRequest);

            //Wait for the response data to come back
            Google.ProtocolBuffers.ByteString messageBody = _openPackageEvent.GetResponseData();

            //Format the response data
            PackageOpenResponse packageOpenResponse = PackageOpenResponse.CreateBuilder().MergeFrom(messageBody).Build();

            //Determine success
            bool bSuccess = (packageOpenResponse != null && !packageOpenResponse.HasPackageFault && packageOpenResponse.HasPackageUUID);

            //Update last error string
            LastPackageOpenResponseError = packageOpenResponse!=null && !bSuccess ? packageOpenResponse.PackageFault.Message : string.Empty;
            
            return bSuccess ? packageOpenResponse.PackageUUID : null;
        }

        /// <summary>
        /// Attempts to save the package identified by the passed id
        /// </summary>
        /// <param name="packageId">UUID of the package to save</param>
        /// <returns>true if successful</returns>
        public bool SavePackage(UUID packageId)
        {
            if (packageId == null)
            {
                throw new InvalidOperationException("SavePackage failure: packageId must be a valid package id");
            }
            else if (_packageManagerService == null)
            {
                throw new NullReferenceException("SavePackage failure: no connection exists to the package manager service");
            }

            //Make a call to save the package
            PackageSaveRequest packageSaveRequest = PackageSaveRequest.CreateBuilder().SetPackageUUID(packageId).SetRequestUUID(UniversalIdentifier.GenerateNewValue()._uuid).Build();
            _packageManagerService.SavePackage(packageSaveRequest);

            //Wait for the response data to come back
            Google.ProtocolBuffers.ByteString messageBody = _savePackageEvent.GetResponseData();

            //Format the response data
            PackageSaveResponse packageSaveResponse = PackageSaveResponse.CreateBuilder().MergeFrom(messageBody).Build();

            //Return true if success (def of success below comes from the documentation)
            return packageSaveResponse != null && packageSaveResponse.ReturnStatus == 1 && !packageSaveResponse.HasPackageFault;
        }

        /// <summary>
        /// Attempts to close the package identified by the passed id
        /// </summary>
        /// <param name="packageId">UUID of the package to close</param>
        /// <returns>true if successful</returns>
        public bool ClosePackage(UUID packageId)
        {
            if (packageId == null)
            {
                throw new InvalidOperationException("ClosePackage failure: packageId must be a valid package id");
            }
            else if (_packageManagerService == null)
            {
                throw new NullReferenceException("ClosePackage failure: no connection exists to the package manager service");
            }
            else
            {
                bool FoundOpenPackage = false;
                foreach (OpenPackageInfo openPackage in GetOpenPackages())
                {
                    if (ResourceBase.IsEqual(openPackage.PackageUUID, packageId))
                    {
                        FoundOpenPackage = true;
                        break;
                    }
                }

                if(!FoundOpenPackage)
                    throw new InvalidOperationException("ClosePackage failure: packageId does not represent an open package id");
            }

            //Make a call to close the package
            PackageCloseRequest packageCloseRequest = PackageCloseRequest.CreateBuilder().SetPackageUUID(packageId).SetRequestUUID(UniversalIdentifier.GenerateNewValue()._uuid).Build();
            _packageManagerService.ClosePackage(packageCloseRequest);

            //Wait for the response data to come back
            Google.ProtocolBuffers.ByteString messageBody = _closePackageEvent.GetResponseData();

            //Format the response data
            PackageCloseResponse packageCloseResponse = PackageCloseResponse.CreateBuilder().MergeFrom(messageBody).Build();

            //Return true if success (def of success below comes from the documentation)
            return packageCloseResponse!=null && packageCloseResponse.ReturnStatus==1 && !packageCloseResponse.HasPackageFault;
        }

        /// <summary>
        /// Gets the project database UUID for the passed package
        /// </summary>
        /// <param name="packageId">UUID of the package to obtain the project id for</param>
        /// <returns>Project Id if the passed package has one, else null</returns>
        public UUID GetProjectDatabaseIdFromPackage(UUID packageId)
        {
            if (packageId == null)
            {
                throw new InvalidOperationException("GetProjectDatabaseIdFromPackage failure: packageId must be a valid package id");
            }
            else if (_packageManagerService == null)
            {
                throw new NullReferenceException("GetProjectDatabaseIdFromPackage failure: no connection exists to the package manager service");
            }

            //Make a call to read the package manifest
            PackageReadManifestRequest packageReadManifestRequest = PackageReadManifestRequest.CreateBuilder().SetPackageUUID(packageId).SetRequestUUID(UniversalIdentifier.GenerateNewValue()._uuid).Build();
            _packageManagerService.ReadPackageManifest(packageReadManifestRequest);

            //Wait for the response data to come back
            Google.ProtocolBuffers.ByteString messageBody = _readPackageManifestEvent.GetResponseData();

            //Format the response data
            PackageReadManifestResponse packageReadManifestResponse = PackageReadManifestResponse.CreateBuilder().MergeFrom(messageBody).Build();

            UUID projectId = null;
            //if success (def of success below comes from the documentation)
            if(packageReadManifestResponse != null && packageReadManifestResponse.ReturnStatus == 1 && !packageReadManifestResponse.HasPackageFault)
            {
                foreach (DatabaseInfo dbInfo in packageReadManifestResponse.ResultsList)
                {
                    if (dbInfo.HasName && dbInfo.Name.Equals(PROJECT_DB_NAME))
                    {
                        projectId = dbInfo.DatabaseUUID;
                        break;
                    }
                }
            }

            return projectId;
        }

        /// <summary>
        /// Closes any open handlers / references to the package manager service
        /// </summary>
        public void Shutdown()
        {
            try
            {
                //close the package manager service
                if (_packageManagerService != null)
                {
                    _packageManagerService.RemoveCreatePackageEventHandler(_createPackageEvent.Handler);
                    _packageManagerService.RemoveOpenPackageEventHandler(_openPackageEvent.Handler);
                    _packageManagerService.RemoveSavePackageEventHandler(_savePackageEvent.Handler);
                    _packageManagerService.RemoveClosePackageEventHandler(_closePackageEvent.Handler);
                    _packageManagerService.RemoveGetOpenPackagesEventHandler(_getOpenPackagesEvent.Handler);
                    _packageManagerService.RemoveAddNewDatabasesEventHandler(_addNewDatabasesEvent.Handler);
                    _packageManagerService.RemoveReadPackageManifestEventHandler(_readPackageManifestEvent.Handler);
                    _packageManagerService.close();
                    _packageManagerService = null;
                }
            }
            catch (Exception ex)
            {
                // Swallow it, we're shutting down anyway
                Console.WriteLine("Exception during Disconnect " + ex.Message);
            }
            finally
            {
                _createPackageEvent.Reset();
                _openPackageEvent.Reset();
                _savePackageEvent.Reset();
                _closePackageEvent.Reset();
                _getOpenPackagesEvent.Reset();
                _addNewDatabasesEvent.Reset();
                _readPackageManifestEvent.Reset();
            }
        }
    }
}
