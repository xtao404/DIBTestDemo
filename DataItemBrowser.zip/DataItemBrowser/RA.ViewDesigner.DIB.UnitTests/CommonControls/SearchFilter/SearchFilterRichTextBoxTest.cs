﻿using System.Windows;
using System.Windows.Controls;
using FakeItEasy;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.CommonControls.SearchFilter.ViewModels;
using RockwellAutomation.UI.CommonControls.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Windows.Media;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for SearchFilterRichTextBoxTest and is intended
    ///to contain all SearchFilterRichTextBoxTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SearchFilterRichTextBoxTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for UnderlineError
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void UnderlineErrorTest_ValidErrorLength_ValidValues()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.ErrorStartIndex = 1;
            fakeViewModel.ErrorLength = 3;
            fakeViewModel.HasError = true;
            fakeViewModel.SearchErrorIndicatorMessage = "";
            fakeViewModel.SearchFilterText = "";

            PrivateObject searchFilterRichTextBox = new PrivateObject("RA.Common.Search", "RockwellAutomation.UI.CommonControls.SearchFilterRichTextBox", null);
            searchFilterRichTextBox.Invoke("Initialize", fakeViewModel);                                  
            DrawingBrush wavyBrush  = new DrawingBrush();
            
            //ACT
            Tuple<int,int> expected = new Tuple<int, int>(1,3);
            Tuple<int, int> actual = (Tuple<int, int>)searchFilterRichTextBox.Invoke("UnderlineError", wavyBrush);

            //ASSERT
            Assert.AreEqual(expected, actual);            
        }

        /// <summary>
        ///A test for UnderlineError
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void UnderlineErrorTest_ZeroErrorLength_AdjustedValues()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.ErrorStartIndex = 0;
            fakeViewModel.ErrorLength = 0;
            fakeViewModel.HasError = true;
            fakeViewModel.SearchErrorIndicatorMessage = "";
            fakeViewModel.SearchFilterText = "";

            PrivateObject searchFilterRichTextBox = new PrivateObject("RA.Common.Search", "RockwellAutomation.UI.CommonControls.SearchFilterRichTextBox", null);
            searchFilterRichTextBox.Invoke("Initialize", fakeViewModel);
            DrawingBrush wavyBrush = new DrawingBrush();

            //ACT
            Tuple<int, int> expected = new Tuple<int, int>(0, 1);
            Tuple<int, int> actual = (Tuple<int, int>)searchFilterRichTextBox.Invoke("UnderlineError", wavyBrush);

            //ASSERT
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for UnderlineError
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void UnderlineErrorTest_NoError_NegValues()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.ErrorStartIndex = 0;
            fakeViewModel.ErrorLength = 0;
            fakeViewModel.HasError = false;
            fakeViewModel.SearchErrorIndicatorMessage = "";
            fakeViewModel.SearchFilterText = "";

            PrivateObject searchFilterRichTextBox = new PrivateObject("RA.Common.Search", "RockwellAutomation.UI.CommonControls.SearchFilterRichTextBox", null);
            searchFilterRichTextBox.Invoke("Initialize", fakeViewModel);
            DrawingBrush wavyBrush = new DrawingBrush();

            //ACT
            Tuple<int, int> expected = new Tuple<int, int>(-1, -1);
            Tuple<int, int> actual = (Tuple<int, int>)searchFilterRichTextBox.Invoke("UnderlineError", wavyBrush);

            //ASSERT
            Assert.AreEqual(expected, actual);
        }
    }
}
