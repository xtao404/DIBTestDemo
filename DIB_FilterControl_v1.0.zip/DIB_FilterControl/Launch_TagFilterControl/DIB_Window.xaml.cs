﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Utility;

namespace Launch_TagFilterControl
{
    /// <summary>
    /// Interaction logic for DIB_Window.xaml
    /// </summary>
    public partial class DIB_Window : Window
    {
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private Config config = Config.GetInstance();
        public DIB_Window()
        {
            InitializeComponent();
            this.Closed += DIBWindow_Closed;
        }

        void DIBWindow_Closed(object sender, EventArgs e)
        {
            Dispose();
        }

        private void Dispose()
        {
            xmlHelper.ControllerSubChildrensKeyValuePair.Clear();
            xmlHelper.ProgramTagsKeyValuePair.Clear();
            xmlHelper.DataTypes.Clear();
            xmlHelper.UserDefined.Clear();
            xmlHelper.Strings.Clear();
            xmlHelper.AddOnDefined.Clear();
            xmlHelper.PreDefined.Clear();
            xmlHelper.ModuleDefined.Clear();
            xmlHelper.Usage.Clear();
            xmlHelper.TempUsage.Clear();
            xmlHelper.ControllerTags.Clear();
            xmlHelper.UsedTags.Clear();
            xmlHelper.Libs.Clear();
            xmlHelper.CatalogNumber.Clear();
            xmlHelper.Interface.Clear();
            xmlHelper.Mems.Clear();
            config.IsCheckedTags.Clear();
            config.MemFilter.Clear();
            config.ACMCustomPropertiesFilter.Clear();
        }
    }
}
