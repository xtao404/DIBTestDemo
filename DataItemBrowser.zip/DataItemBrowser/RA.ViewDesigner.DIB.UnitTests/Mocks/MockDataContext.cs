﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RockwellAutomation.UI.Models;

namespace DataItemBrowserUT.Mocks
{
    class MockDataContext:DataContext
    {
        private ContextPath _includePath = null;

         /// <summary>
        /// has an include path
        /// </summary>
        /// <returns>true if an include path is set.</returns>
        public new bool HasInclude()
         {
             return true;
         }

        /// <summary>
        /// include path dataitems
        /// </summary>
        /// <returns>ContextPath</returns>
        public new ContextPath IncludePath
        {
            get { return _includePath; }
            set { _includePath = value; }
        }

        /// <summary>
        /// is the HMIDeviceIncluded
        /// </summary>
        /// <returns></returns>
        public override bool IsHMIDeviceTypeIncluded()
        {
            return false;
        }
    }
}
