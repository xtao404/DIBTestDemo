/*************************************************************************************                                                                  
   ViewE ClientDataServices
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Globalization;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;

using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.Logging;
using System.Reflection;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.DIBQuery
{
    /// <summary>
    /// Client Data Services provide clients with data manipulation, DibQuery access and wrapper methods as well as 
    /// ColumnConfiguration setup, access and persistent storage functionality.
    /// Client Data Services acts like is a Mediator (http://en.wikipedia.org/wiki/Mediator_pattern) to DIBQueryCache, DIBCommand, DIBConnection.
    /// </summary>
    public class ClientDataServices : IClientDataServices, INotifyPropertyChanged
    {
        #region "Variables/Properties"

        // The current path. This reference is also held onto by DataBrowserViewModel
        private RockwellAutomation.UI.Models.Path _currentPath;

        // The current DIBQueryRequestCommand. This gets reset on every command execution
        internal IDIBQueryCommand CurrentQueryCommand = null;

        // Delegates used for callbacks on query response
        private DataLoadComplete _loadCompleteDelegate = null;
        private DataLoadComplete _loadCompleteDelegateOverride = null;
        private ProblemSetFunc _setProblemInfoDelegate = null; 

        private DataItemBrowserContext _lastInitializedDibContext = null;
        private DIBViewItemBase.VisualPerspectiveEnum _browserPerspective;
 
        // _columnManager is responsible for column detail persistance and user configuration
        private DIBQueryColumnConfigHelper _columnManager;

        // Data context that was assigned during DIB startup
        private DataContext _dataContext = null;
        public DataContext DataContext
        {
            get { return _dataContext; }
        }

        private DIBClientManager _dibClientManager = null;
        public DIBClientManager DibClientManager
        {
            get { return _dibClientManager; }
            set { if (_dibClientManager != value) _dibClientManager = value; }
        }
        
        // The current Query cache that holds onto the data collection and cached results
        private DIBQueryCache _cache;
        public DIBQueryCache QueryCache
        {
            get { return _cache; }
        }

        // What view the GUI is using
        private IDIBDataViewType _dataView = new DIBDataViewTypeUnknown();
        public IDIBDataViewType DataView
        {
            get { return _dataView; }
            set
            {
                if (_dataView != value)
                {
                    _dataView = value;
                    NotifyPropertyChanged("DataView");
                }
            }
        }

        #endregion

        #region "Static Variables"

        //used for testing/simulating a specific problem
        static public ProblemInfoType _forcedProblemType = ProblemInfoType.NoProblem; 

        public const string SearchTags = "searchtags";

        #endregion

        #region "Init/Release"

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItems">Ref to the collection storing the current data items</param>
        /// <param name="path"> The Path to use. This represent the active path in the DIB and is the same instance held onto by DataItemBrowserViewModel</param>
        /// <param name="loadCompleteCallback">callback Method to be invoked when the DibQuery complete data loading.</param>
        /// <param name="browserPerspective">identifies the DIB perspective; either tag or datatype</param>
        public ClientDataServices(ref TSObservableCollection<DataItemBase> dataItems, 
                                    RockwellAutomation.UI.Models.Path path,
                                    DataLoadComplete loadCompleteCallback,
                                    DIBViewItemBase.VisualPerspectiveEnum browserPerspective, 
                                    DIBClientManager dibClientManager)
        {
            this._dibClientManager = dibClientManager;
            _browserPerspective = browserPerspective;
			DataView = new DIBDataViewTypeUnknown();
            _cache = new DIBQueryCache(dataItems);
            _currentPath = path;
		    _loadCompleteDelegate = loadCompleteCallback;
        }

        /// <summary>
        /// Initialize the navigation state (query service, etc).
        /// This method can throw a QueryException from the query initialization.
        /// </summary>      
        /// <param name="context">data item browser context</param>
        /// <param name="initCallback">callback Method to be invoked when the DibQuery complete data loading</param>       
        public void Initialize(DataItemBrowserContext context, InitializationComplete initCallback)
        {
            Initialize(context, initCallback, false);
        }

        /// <summary>
        /// Initialize the navigation state (query service, etc).
        /// This method can throw a QueryException from the query initialization.
        /// </summary>      
        /// <param name="context">data item browser context</param>
        /// <param name="initCallback">callback Method to be invoked when the QSP complete data loading</param>       
        /// <param name="isReinit">reflects if the initialize is being called from a re-initialization</param>       
        private void Initialize(DataItemBrowserContext context,  InitializationComplete initCallback, bool IsReinit)
        {
            String initializeErrorString = String.Empty;

            //Load our persisted size and column config data
            _columnManager = new DIBQueryColumnConfigHelper();
            _columnManager.LoadUserAndColumnConfigData(this.DibClientManager);

            _lastInitializedDibContext = context;

            _dataContext = new DataContext();

            //Clear problem text before initialize (since we might be on a re-initialize after a previous error)
            _setProblemInfoDelegate(string.Empty, string.Empty);

            if (!this.DibClientManager.InitializeDIBQueryConnection(this, ref initializeErrorString, IsReinit))
            {
                initCallback(this.DataContext, initializeErrorString);
                return;
            }

            if (!String.IsNullOrEmpty(initializeErrorString))
            {
                this.DibClientManager.Close();
                initCallback(_dataContext, initializeErrorString);
            }
            //if the context is null then just create a null root path
            else if (context == null)
            {
                initCallback(_dataContext, String.Empty);
            }
            else
            {
                //process the data item browser context
                _dataContext.ProcessDataContext(this, context, (error) =>
                {
                    initCallback(_dataContext, error);
                });
            }
        }

        /// <summary>
        /// Helper for the drill in and search methods to re-initialize if needed (would be called if an error,
        /// either real or simulated, occurred.
        /// </summary>
        /// <param name="initCallback">Callback for a drill in operation that should be called if the reinit succeeds</param>
        /// <param name="searchCallback">Callback for a search operation that should be called if the reinit succeeds</param>
        /// <param name="dataItem">DataItem to use for the drill in if this method was called for that purpose</param>
        private void Reinitialize(Action<DataItemBase> drillinCallback, ProcessSearch searchCallback, DataItemBase dataItem)
        {
            Initialize(_lastInitializedDibContext, (dataContext, error) =>
            {
                //Perform the operation if we don't get an initialization error
                if (string.IsNullOrEmpty(error))
                {
                    if (drillinCallback != null)
                        drillinCallback.Invoke(dataItem);
                    else if (searchCallback != null)
                        searchCallback.Invoke();
                }
                else
                {
                    //Since this was a followup initialization, the breadcrumbs are okay (from the original init),
                    // but make sure we use callback to stop the load spinner
                    _loadCompleteDelegate(error);
                }
            }, true); //True will avoid the initialization from falling into the forced override code!
        }

        /// <summary>
        /// Close this instance of CDS, but leave the DIBQueryConnection open for caching and performance reasons
        /// </summary>
        public void Close()
        {
            this.DibClientManager.Close();
        }

        #endregion

        #region "Public"


        /// <summary>
        /// Represents the current DataItemBase we are trying to drill into
        /// </summary>
        public DataItemBase CurrentParentDataItem()
        {
            DataItemBase item = null;
            if (!this.IsExecutingQueryCommand()) return null;
            if (CurrentQueryCommand != null)
                item = CurrentQueryCommand.ParentDataItem();
            return item;
        }

        public DIBViewItemBase.VisualPerspectiveEnum CurrentBrowserPerspective()
        {
            return this._browserPerspective;
        }

        /// <summary>
        /// Check if the browser type is a tag browser.
        /// </summary>
        /// <returns>true if tag browser, otherwise false</returns>
        public bool IsTagBrowser()
        {
            return this.CurrentBrowserPerspective() == DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
        }

        public bool IsDataTypeBrowser()
        {
            return this.CurrentBrowserPerspective() == DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
        }

        public bool IsAOGPropertyBrowser()
        {
            return this.CurrentBrowserPerspective() == DIBViewItemBase.VisualPerspectiveEnum.AOGPropertiesBrowser;
        }

		/// <summary>
		/// Returns the children of the passed crumb.  Determined based on the cached
		/// result set from a previously executed query
		/// </summary>
		/// <param name="crumb">Crumb to obtain the children for</param>
		/// <param name="nextName">Name of the next crumb in the path (used for bold text setting)</param>
		/// <returns>List of DropArrowItem representing the children of the passed crumb</returns>
		public List<DropArrowItem> GetChildrenOfCrumb(ACrumb crumb, string nextName)
		{
            return this.QueryCache.GetChildrenOfCrumb(crumb, nextName, this._dataContext, this);
		}

        /// <summary>
        /// This function returns whether or not the current path is inside an HMI Device.
        /// </summary>
        /// <returns>Boolean representing whether or not the current path is inside an HMI Device.</returns>
        public bool IsBrowsingHMIDevice()
        {
            return _currentPath.isBrowsingHMIDevice();
        }

        /// <summary>
        /// This function returns whether or not we are curently executing a query command to QSP.
        /// </summary>
        /// <returns>Boolean representing whether or not a QSP query is in progress.</returns>
        public bool IsExecutingQueryCommand()
        {
            return this.CurrentQueryCommand != null;
        }
                
        /// <summary>
        /// This function returns whether or not we should display MetaData
        /// </summary>
        /// <returns>Boolean representing whether or not we should display MetaData.</returns>
        public bool ShouldDisplayMetaData()
        {
            return _dataContext.DisplayMetaData;
        }
        #endregion "Public API"

        #region "Drillin/Search"

        /// <summary>
        /// Perform Drill in 
        /// </summary>
        /// <param name="dataItem">What to drill into</param>
        private void DrillinFunc(DataItemBase dataItem)
        {
            //Clear problem text before drill in (since this will result in another query request)
            _setProblemInfoDelegate(string.Empty, string.Empty);

            string resourceType = this.DibClientManager.GetResourceTypeString(dataItem);

            if (String.IsNullOrEmpty(resourceType))
            {
                _loadCompleteDelegate("Could not get resource type from data item.  No query issued.");
                return;
            }

            // Update the column list for the client based on the data item type
            // Important to do this before setting the data view so clients that see the data view change
            // notification have the right column data to act on (i.e. the data grid)
            this._columnManager.SetColumns(resourceType);

            // Clear our data items collection as we will be issuing a new query. Doing this before setting 
            // the data view prevents a new data view from prematurely binding to data items intended for an old data view
            this.QueryCache.ClearDataItems();

            // Update data view based on resource type
            SetDataView(resourceType);

            //Make a call to send the query request
            UUID itemId = null;
            if ((resourceType == DIResource.DI_COMMON_RESOURCETYPE_TAG) ||
                (resourceType == DIResource.DI_COMMON_RESOURCETYPE_DATATYPEMEMBER))
            {
                itemId = dataItem != null ? ResourceBase.GuidStringToId(dataItem.CommonRefTargetId) : null;
                RunQuery(itemId, dataItem, null);
            }
            else
            {
                itemId = dataItem != null ? ResourceBase.GuidStringToId(dataItem.CommonID) : null;
                RunQuery(itemId, dataItem, null);
            }
        }

        /// <summary>
        /// Performs a drill in to the passed data item, if a query is in process, the query will be cancelled and the 
        /// new drill in performed
        /// </summary>
        /// <param name="dataItem">Parent item to drill in to</param>
        /// <returns>True if we performed a query request as a result of this call</returns>
        public bool DrillIn(DataItemBase dataItem)
        {
            // reset the delegate overide on every drill-in.
            _loadCompleteDelegateOverride = null;

            //If we hadn't successfully initialized, we are in an error scenario, so try to re-init and then drill in
            if (!this.DibClientManager.IsReadyForNavigationRequests())
            {
                Reinitialize(DrillinFunc, null, dataItem);
                return true;
            }

            DrillinFunc(dataItem);
            return true;
        }

        /// <summary>
        /// Performs a drill in to the passed data item only if necessary (will return the cached
        /// data if available)
        /// </summary>
        /// <param name="dataItem">Parent item to drill in to</param>
        /// <param name="callback">Callback to execute after drill in is complete</param>
        /// <returns>True if we performed a query request as a result of this call</returns>
        public bool DrillIn(DataItemBase dataItem, DataLoadComplete callback)
        {
            _loadCompleteDelegateOverride = callback;
            DrillinFunc(dataItem);
            return true;
        }

        /// <summary>
        /// Performs a search/filter
        /// </summary>
        /// <param name="dataItem">Parent item to drill in to</param>
        /// <param name="filterConfig">Structure containing the filter items the client specified.</param>
        /// <returns>True if we performed a query request as a result of this call</returns>
        public bool Search(DataItemBase dataItem, SearchFilterConfig filterConfig)
        {
            bool ret = true;

            ProcessSearch processSearchFunc = delegate()
            {
                //Clear problem text before search (since this will result in another query request)
                _setProblemInfoDelegate(string.Empty, string.Empty);

                //Update the column list for the client based on the data item type
                // Important to do this before setting the data view so clients that see the data view change
                // notification have the right column data to act on (i.e. the data grid)
                this._columnManager.SetColumns(SearchTags);

                //Update data view based on resource type
                SetDataView(SearchTags);

                //convert it into query condition configuration object
                QueryConditionConfig.CreateBuilder conditionBuilder = new QueryConditionConfig.CreateBuilder();
                foreach (SearchFilterItem filterItem in filterConfig.GetFilterItems)
                {
                    conditionBuilder.AddConditionItem(DIBQueryConditionHelper.BuildQueryConditionItemFor(filterItem));
                }

                //Make a call to send the query request
                UUID itemId = dataItem != null ? ResourceBase.GuidStringToId(dataItem.CommonID) : null;
                RunQuery(itemId, dataItem, conditionBuilder.Build(), true);

            };

            //If we hadn't successfully initialized, we are in an error scenario, so try to re-init and then search
            if (!this.DibClientManager.IsReadyForNavigationRequests())
            {
                Reinitialize(null, processSearchFunc, null);
                return ret;
            }

            processSearchFunc.Invoke();
            return ret;
        }

        /// <summary>
        /// Helper to set the DataView member based on the passed resource type (representing the "parent"
        /// component being displayed in the current browser view)
        /// </summary>
        /// <param name="resourceType">One of "controller", "tag", "datatype"</param>
        private void SetDataView(string resourceType)
        {
            DataView = this.DibClientManager.GetDataViewTypeFor(resourceType);
        }

        #endregion

        #region "DIBQuery"

        /// <summary>
        /// Called when the query services have finished obtaining data for us. This method is usually called from a UI Dispatcher thread 
        /// </summary>
        /// <param name="qResponse"></param>
        public void PerformQuery_DataLoadComplete(QueryResponse qResponse)
        {
            if (this.CurrentQueryCommand == null)
            {
                LogWrapper.DibQueryDibInterfaceLog.Info("Ignoring Query Response (RequestID: " + (qResponse != null ? qResponse.GetQueryRequest.GetRequestID.ToString(CultureInfo.CurrentCulture) : "NA") + "). We are not waiting for any response.");
                return;
            }
            else if (qResponse != null && qResponse.GetQueryRequest.GetRequestID != this.CurrentQueryCommand.GetRequestID())
            {
                LogWrapper.DibQueryDibInterfaceLog.Info("Ignoring Query Response (RequestID: " + (qResponse.GetQueryRequest.GetRequestID.ToString(CultureInfo.CurrentCulture)) + "). We are waiting for Request ID: " + this.CurrentQueryCommand.GetRequestID());
                return;
            }

            string msg = string.Empty;
            bool bForcingProblem = _forcedProblemType != ProblemInfoType.NoProblem;
            bool bQueryHasException = qResponse != null && qResponse.HasException;
            if (bQueryHasException || bForcingProblem)
            {
                if (bQueryHasException)
                {
                    LogWrapper.DibQueryDibInterfaceLog.Error("Error returned from QSP for QueryRequestID: " + qResponse.GetQueryRequest.GetRequestID, qResponse.GetException);
                
                    msg = qResponse.GetException.Message;
                    this.DibClientManager.ProcessExceptionErrorResponse(qResponse.GetException as Exception, this);
                }
                //Allow test client to set specific problem type but only after we check for a real problem (above)
                else if (bForcingProblem)
                {
                    msg = SetProblemInfo(_forcedProblemType);
                    this.DibClientManager.ProcessExceptionErrorResponse(null, this);
                }

                this.DibClientManager.Close();
            }
            else
            {
                // Cache results from last query if needed. These cached items are used in the breadcrumb drop down lists 
                if (this.DibClientManager.BreadcrumbCachingMode() == DIBClientManager.DIBCachingMode.DefaultCachingMode)
                {
                    if (this.CurrentQueryCommand.CacheQueryResults)
                        this.QueryCache.AddCachedItem(
                            this.DibClientManager.GetBreadCrumbCacheKeyFor(this.CurrentQueryCommand.ParentDataItem()),
                            new TSObservableCollection<DataItemBase>(this.QueryCache.DataItems));
                }
                else if (this.DibClientManager.BreadcrumbCachingMode() == DIBClientManager.DIBCachingMode.CachingAlwaysEnabled)
                {
                    this.QueryCache.AddCachedItem(
                            this.DibClientManager.GetBreadCrumbCacheKeyFor(this.CurrentQueryCommand.ParentDataItem()),
                            new TSObservableCollection<DataItemBase>(this.QueryCache.DataItems));
                }

                LogWrapper.DibQueryDibInterfaceLog.Info("Total items returned from query (RequestID: " + (qResponse != null ? qResponse.GetQueryRequest.GetRequestID.ToString(CultureInfo.CurrentCulture) : "NA") + ")  is " + this.QueryCache.DataItemsCount());
            }

            CurrentQueryCommand.CleanUp();
            CurrentQueryCommand = null;

            //If there is a custom delegate set, use it and clear it for the next data load call
            if (_loadCompleteDelegateOverride != null)
            {
                //Clear the saved callback before we call it so we don't get back here on a subsequent drill in
                DataLoadComplete loadCompleteDelegateOverride = _loadCompleteDelegateOverride;
                _loadCompleteDelegateOverride = null;
                loadCompleteDelegateOverride(msg);
            }
            else //Otherwise use the standard (set in the constructor) delegate
            {
                _loadCompleteDelegate(msg);
            }

        }

        /// <summary>
        /// Executes a query for data asychronously
        /// </summary>             
        /// <param name="parentResourceTypeId">UUID representing the Parent Resource Type ID</param>
        /// <param name="parentItem">DataItemBase for the parent</param>
        /// <param name="queryCondition">any additional conditions to be applied to the query statement</param>
        private void RunQuery(UUID parentResourceTypeId, DataItemBase parentItem, QueryConditionConfig queryCondition, bool isDIBSearching = false)
        {
            CurrentQueryCommand = this.DibClientManager.createQueryCommandFor(
                new QueryRequest.CreateBuilder()
                    .SetParentDataItemBase(parentItem)
                    .SetCondition(queryCondition)
                    .SetParentResourceType(parentResourceTypeId), 
                isDIBSearching);
            this.QueryCache.ClearDataItems();
            if (CurrentQueryCommand != null) CurrentQueryCommand.Execute(this);
        }

        #endregion "Private"

        #region "INotifyPropertyChanged Members"

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region "Column Config"

        /// <summary>
        /// Generate a column config to use in query requests
        /// </summary>
        /// <returns>RockwellAutomation.Client.Services.Query.ColumnConfig</returns>
        public RockwellAutomation.Client.Services.Query.ColumnConfig GenerateColumnConfig()
        {
            return this._columnManager.GenerateColumnConfig();
        }

        /// <summary>
        /// This method performs a single update to the Column Configuration based on the provided parameters.
        /// </summary>
        /// <param name="columnAttribute">The attribute to be update (Width, visibility, etc)</param>
        /// <param name="columnName">the column name used to generate an key to the correct location</param>
        /// <param name="columnValue">The column Value to set</param>
        public void UpdateColumnConfig(ColumnAttribute columnAttribute, string columnName, object columnValue)
        {
            this._columnManager.UpdateColumnConfig(this.DataView, columnAttribute, columnName, columnValue);
        }

        /// <summary>
        /// Represents what columns the GUI should display given the current context
        /// </summary>
        /// <returns>List<ColumnConfigMapItem></returns>
        public List<ColumnConfigMapItem> Columns
        {
            get
            {
                return this._columnManager.Columns(this.DataView);
            }
        }

        /// <summary>
        /// Persist the user config to disk
        /// </summary>
        public void SaveColumnConfig()
        {
            this._columnManager.SaveColumnConfig();
        }

        #endregion

        #region "QueryCache and lookup"

        /// <summary>
        /// Get the list of cached devices
        /// </summary>
        /// <returns>ObservableCollection<DataItemBase> representing the Devices</returns>
        public IObservableCollection<DataItemBase> GetCachedDevices()
        {
            return this.QueryCache.GetCachedDevices();
        }

        /// <summary>
		/// Helper to obtain the data item for a device given a string name
		/// </summary>
		/// <param name="deviceName">Name of the device to search for</param>
		/// <returns>Data item matching the passed device name or null if not found</returns>
		public DataItemBase GetDeviceItemByName(string deviceName)
		{
            return this.QueryCache.GetDeviceItemByName(deviceName);
		}

        /// <summary>
        /// Helper to obtain the data item for the passed name (using the current DataItems)
        /// </summary>
        /// <param name="itemName">Name of the item to search for</param>        
        /// <returns>Data item matching the passed name or null if not found</returns>
        public DataItemBase GetDataItemByName(string itemName)
        {
            return this.QueryCache.GetDataItemByName(itemName, null);
        }
        /// <summary>
        /// Helper to obtain the data item for the passed name (using the current DataItems)
        /// </summary>
        /// <param name="itemName">Name of the item to search for</param>
        /// <param name="location">Path of the dataItem or where it is located</param>
        /// <returns>Data item matching the passed name or null if not found</returns>
        public DataItemBase GetDataItemByName(string itemName, string location)
        {
            return this.QueryCache.GetDataItemByName(itemName, location);
		}

        /// <summary>
        /// Helper to obtain the dataitem for the datatype found in device "location" (using the current collection of DataItems)
        /// </summary>
        /// <param name="datatype">Name of the datatype to search for</param>
        /// <param name="location">Location associated with the datatype</param>
        /// <returns>Data item matching the passed name and location or null if not found</returns>
        public DataItemBase GetDataTypeItemByLocation(string datatype, string location)
        {
            return this.QueryCache.GetDataTypeItemByLocation(datatype, location);
        }
        #endregion

        #region "Error Handling"

        /// <summary>
        /// Can be called to "simulate" a problem.  If normal navigation/execution completes successfully,
        /// the problem type passed to this method will be used.  This offers a way for us to test otherwise
        /// difficult scenarios (timeout / response error) to make sure our GUI is correct in those situations.
        /// </summary>
        /// <param name="problem">The problem to simulate experiencing during any followup navigations/searches</param>
        static public void ForceProblemType(ProblemInfoType problem)
        {
            _forcedProblemType = problem;
        }

        /// <summary>
        /// Used to set the problem callback that should be called by client data services
        /// if a problem occurs during navigation or execution
        /// </summary>
        /// <param name="probDelegate">Callback to use if a problem is encountered</param>
        public void SetProblemCallback(ProblemSetFunc probDelegate)
        {
            _setProblemInfoDelegate = probDelegate;
        }

        /// <summary>
        /// Helper to set the problem info members based on the passed problem type.  This method will handle
        /// setting the strings/helpids based on the category of problem
        /// </summary>
        /// <param name="probType">Type of problem we encountered</param>
        /// <returns>Error string</returns>
        public string SetProblemInfo(ProblemInfoType probType)
        {
            string probText = String.Empty;
            string probHelpId = String.Empty;
            bool disableSearch = true;
            bool disableCrumbs = true;

            if (probType != ProblemInfoType.NoProblem)
            {
                if (probType == ProblemInfoType.InvalidContextGuid)
                {
                    probText = "Project File Error: Cannot read information from project database.";
                    probHelpId = "82014";
                }
                else if (probType == ProblemInfoType.ResourceServiceDown)
                {
                    probText = "Service Down: Cannot connect with the resource service (raOSGI).";
                    probHelpId = "81160";
                }
                else if (probType == ProblemInfoType.ResourceServiceTimeout)
                {
                    probText = "Data Timeout: Unable to communicate with the resource service.";
                    probHelpId = "82011";
                    disableSearch = false;
                    disableCrumbs = false;
                }
                else if (probType == ProblemInfoType.ResourceServiceError)
                {
                    probText = "Response Error: Unable to obtain data from the resource service.";
                    probHelpId = "82012";
                    disableSearch = false;
                    disableCrumbs = false;
                }
                else if (probType == ProblemInfoType.InitializationError)
                {
                    probText = "Initialize Exception: Data services cannot be initialized.";
                    probHelpId = "82013";
                }
                else
                {
                    //All problem info types should be handled
                    System.Diagnostics.Debug.Assert(false, "Unknown problem info type");
                }
            }
            _setProblemInfoDelegate(probText, probHelpId, disableSearch, disableCrumbs);
            return probText;
        }

        #endregion

    }
}
