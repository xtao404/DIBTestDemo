﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public class FilterTypeSwitchUtil
    {
        public static AndOrValue ConvertToMigrationAndOr(object type)
        {
            switch (((conAndOrItemBase)type).AndOrType)
            {
                case AndOr.And:
                    return AndOrValue.And;
                case AndOr.None:
                    return AndOrValue.None;
                case AndOr.Or:
                    return AndOrValue.Or;
                default: return AndOrValue.None;
            }
        }

        public static object ConvertToValueItem(ValueBase value)
        {
            if (value.RuleType != RuleType.TagName)
            {
                return FilterPolicyCommonUtil.GetValueByRule(GetRlueType(value.RuleType), value.Value);
                //return new FilterPolicyStringValue() { RangeType = value.Value as string };
            }
            return new FilterPolicyStringValue() { DisplayValue = value.Value as string };
        }

        public static List<RuleItemBase> ConvertToRuleItems(ObservableCollection<RuleItemForDisplay> items)
        {
            List<RuleItemBase> lists = new List<RuleItemBase>();

            foreach (var s in items)
            {
                lists.Add(new RuleItemBase() { Id = s.ID.ToString(), RuleType = GetRlueType(s.FilterRuleType), ColumnName = s.ColumnName == null ? string.Empty : s.ColumnName, DisplayName = s.DisplayValue, MetaDataType = (RuleMetaDataType)s.conRuleType });
            }
            return lists;
        }

        public static RuleType GetRlueType(FilterRuleType type)
        {
            switch (type)
            {
                case FilterRuleType.TagName:
                    return RuleType.TagName;
                case FilterRuleType.TagType:
                    return RuleType.TagType;
                case FilterRuleType.UserDefined:
                    return RuleType.UserDefined;
                case FilterRuleType.Strings:
                    return RuleType.Strings;
                case FilterRuleType.AddOnDefined:
                    return RuleType.AddOnDefined;
                case FilterRuleType.ModuleDefined:
                    return RuleType.ModuleDefined;
                case FilterRuleType.PreDefined:
                    return RuleType.PreDefined;
                default:
                    return RuleType.Unknown;
            }
        }

        public static FilterRuleType GetRlueType(RuleType type)
        {
            switch (type)
            {
                case RuleType.TagName:
                    return FilterRuleType.TagName;
                case RuleType.TagType:
                    return FilterRuleType.TagType;
                case RuleType.UserDefined:
                    return FilterRuleType.UserDefined;
                case RuleType.Strings:
                    return FilterRuleType.Strings;
                case RuleType.AddOnDefined:
                    return FilterRuleType.AddOnDefined;
                case RuleType.ModuleDefined:
                    return FilterRuleType.ModuleDefined;
                case RuleType.PreDefined:
                    return FilterRuleType.PreDefined;
                default:
                    return FilterRuleType.Unknown;
            }
        }

        public static ConditionItemBase ConvertToConditionItem(ConditionItemForDisplay item)
        {
            return new ConditionItemBase() { DisplayName = item.DisplayValue, ConditionType = FilterTypeSwitchUtil.GetMIGConditionType(item.ConConditionType) };
        }

        public static ConditionType GetMIGConditionType(FilterConditionType type)
        {
            switch (type)
            {
                case FilterConditionType.Equal:
                    return ConditionType.Equal;
                case FilterConditionType.UnEqual:
                    return ConditionType.UnEqual;
                case FilterConditionType.Contain:
                    return ConditionType.Contain;
                case FilterConditionType.Except:
                    return ConditionType.Except;
                case FilterConditionType.IsExactly:
                    return ConditionType.IsExactly;
                case FilterConditionType.LargerThan:
                    return ConditionType.LargerThan;
                case FilterConditionType.LessThan:
                    return ConditionType.LessThan;
                default:
                    return ConditionType.None;
            }
        }

        public static ValueBase ConvertToValueItem(ConditionFilterBase condition)
        {
            ValueBase value = new ValueBase()
            {
                MetadataType = GetMIGRuleMetaDataType((FilterRuleCustomType)(condition.Rule as RuleItemForDisplay).conRuleType),
                ConditionType = GetMIGConditionType((condition.Condition as ConditionItemForDisplay).ConConditionType),
                RuleType = GetRlueType((condition.Rule as RuleItemForDisplay).FilterRuleType)
            };

            ValueItemForDisplay itemValue = condition.Value as ValueItemForDisplay;
            value.Value = string.IsNullOrEmpty(itemValue.DisplayValue) ? itemValue.InfoString : itemValue.DisplayValue;
            return value;
        }

        public static RuleMetaDataType GetMIGRuleMetaDataType(FilterRuleCustomType type)
        {
            switch (type)
            {
                case FilterRuleCustomType.Number:
                    return RuleMetaDataType.Number;
                case FilterRuleCustomType.String:
                    return RuleMetaDataType.String;
                case FilterRuleCustomType.Enum:
                    return RuleMetaDataType.Enum;
                default:
                    return RuleMetaDataType.None;
            }
        }
    }

    public class FilterCommonMethod
    {
        public static List<FilterReturnBase> GetFilterReturnBase(List<FilterItemBase> items)
        {
            List<FilterReturnBase> bases = new List<FilterReturnBase>();
            if (items != null && items.Count != 0)
            {
                FilterReturnBase bb = new FilterReturnBase() { Conditions = new List<FilterItemBase>() };
                bb.Conditions = items;
                bases.Add(bb);
            }
            return bases;
        }
    }
}
