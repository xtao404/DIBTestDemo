﻿using System.Configuration;

namespace RockwellAutomation.UI.UserConfiguration
{
    /// <summary>
    /// The WindowElement class contains the properties associated with the Browser's window
    /// </summary>
    public class WindowElement : ConfigurationElement
    {
        public WindowElement()
        { }

        #region Properties
        // Set or get the width of the Browser's window. 
        //DFCTS00119897 increase default width to avoid horizontal scroll bar 
        [ConfigurationProperty("DIBWindow_Width", DefaultValue = UserWindowSize.DefaultWindowWidth, IsRequired = true)]
        public int DIBWindow_Width
        {
            get
            {
                return ((int)this["DIBWindow_Width"]);
            }
            set
            {
                this["DIBWindow_Width"] = value;
            }
        }

        // Set or get the width of the Browser's window. 
        [ConfigurationProperty("DIBWindow_Height", DefaultValue = UserWindowSize.DefaultWindowHeight, IsRequired = true)]
        public int DIBWindow_Height
        {
            get
            {
                return ((int)this["DIBWindow_Height"]);
            }
            set
            {
                this["DIBWindow_Height"] = value;
            }
        }

        #endregion Properties
    }
}
