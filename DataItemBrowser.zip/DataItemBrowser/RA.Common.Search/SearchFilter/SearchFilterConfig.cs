﻿/*************************************************************************************
                                                                     
   ViewE SearchFilterConfig
   Copyright © 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;


namespace RockwellAutomation.UI.CommonControls.SearchFilter
{
      /// <summary>
    /// Represents a fully constructed search filter item
    /// </summary>
    /// <remarks>
    /// </remarks>
    /// <author>ViewE Common Tag Team</author>
    public class SearchFilterItem
    {
        private List<SearchFilterItem> _nestedItems;
        /// <summary>
        /// Gets the children list of <see cref="E:SearchFilterItem"/>'s.
        /// </summary>
        /// <remarks>
        /// The list is immutable (i.e. read-only). <see cref="E:QueryConditionConfigItem"/> instances
        /// cannot be removed, added or modified.
        /// </remarks>
        public IList<SearchFilterItem> GetNestedItems { get { return _nestedItems.AsReadOnly(); } }

        /// <summary>
        /// Gets value for Identifier property.
        /// </summary>
        public string GetIdentifier { get; private set; }

        /// <summary>
        /// Gets value for AlternateValue property.
        /// </summary>
        public string GetAlternateIdentifier { get; private set; }

        /// <summary>
        /// Gets value for Value property.
        /// </summary>
        public string GetValue { get; private set; }

        /// <summary>
        /// Gets value for IsExactMatch property.
        /// </summary>
        public bool IsExactMatch { get; private set; }

        /// <summary>
        /// Get value for Is Identifier Column Config Key
        /// </summary>
        public bool IsIdentifierColumnConfigKey { get; private set; }

        /// <summary>
        /// Gets value for LogicOperator property.
        /// </summary>
        public SearchFilterDefinition.StatementLogic GetLogicOperator { get; private set; }

        /// <summary>
        /// SearchFilterItem builder class.
        /// </summary>
        public class CreateBuilder
        {
            #region Private Members

            private List<SearchFilterItem> _items { get; set; }
            private string _identifier { get; set; }
            private string _alternateIdentifier { get; set; }
            private string _value { get; set; }
            private bool _isExactMatch { get; set; }
            private bool _isIdentifierColumnConfigKey { get; set; }
            private SearchFilterDefinition.StatementLogic _logicOperator { get; set; }

            #endregion

            /// <summary>
            /// default builder constructor
            /// </summary>
            public CreateBuilder()
            {
                _items = new List<SearchFilterItem>();
            }

            /// <summary>
            /// Adds a search filter item to this config
            /// list.
            /// </summary>            
            /// <param name="filterItem">An instance of a search filter item to add to the list.</param>            
            public CreateBuilder AddItem(SearchFilterItem filterItem)
            { _items.Add(filterItem); return this; }

            /// <summary>
            /// Sets the value for the identifier field.
            /// </summary>
            /// <remarks>SetIdentifier is a required field, it must be set.</remarks>
            /// <param name="identifier">representing the identifier to use in the condition.</param>
            public CreateBuilder SetIdentifier(string identifier = null)
            { _identifier = identifier; return this; }

            /// <summary>
            /// Sets the condition alternate identifier field. If the _identifer resolves to null or an empty string, 
            /// the alternate identifier will be used instead in order to compute the result for this SearchFilterItem
            /// </summary>            
            /// <param name="value">representing the search filter item alternate identifier.</param>            
            public CreateBuilder SetAlternateIdentifier(string value = null)
            { _alternateIdentifier = value; return this; }

            /// <summary>
            /// Sets the condition value.
            /// </summary>            
            /// <param name="value">representing the search filter item value.</param>            
            public CreateBuilder SetValue(string value = null)
            { _value = value; return this; }

            /// <summary>
            /// Sets the isExactMatch value.
            /// </summary>
            /// <param name="value"> representing whether we want to match exactly.</param>            
            public CreateBuilder SetIsExactMatch(bool value = false)
            { _isExactMatch = value; return this; }

            /// <summary>
            /// Sets the logicOperator Match value.
            /// </summary>
            /// <param name="logic"> representing logical operator.</param>            
            public CreateBuilder SetLogicOperator(SearchFilterDefinition.StatementLogic logic = SearchFilterDefinition.StatementLogic.AND)
            { _logicOperator = logic; return this; }

            public CreateBuilder SetIsIdentifierColumnConfigKey (bool isIdentifierColumnConfigKey)
            {
                _isIdentifierColumnConfigKey = isIdentifierColumnConfigKey;
                return this;
            }
            /// <summary>
            /// Validates and builds an instance of a search filter item.
            /// </summary>            
            public SearchFilterItem Build()
            {
                return new SearchFilterItem
                {
                    _nestedItems = _items, 
                    GetIdentifier = _identifier,
                    GetValue = _value,
                    GetAlternateIdentifier = _alternateIdentifier,
                    IsExactMatch = _isExactMatch,
                    GetLogicOperator = _logicOperator,
                    IsIdentifierColumnConfigKey = _isIdentifierColumnConfigKey
                };
            }
        }

        /// <summary>
        /// Default Constructor.
        /// <para>
        /// declared private as this class implements the builder pattern. The constructor
        /// is intentionally left empty.
        /// </para>
        /// </summary>
        private SearchFilterItem() { }
    }
    /// <summary>
    /// Represents a fully constructed <see cref="E:SearchFilterConfig"/> instance. 
    /// </summary>
    /// <remarks>   
    /// <para>
    /// A <see cref="E:SearchFilterConfig"/> will be used ...
    /// </para>
    /// <para>
    /// This class is immutable, which means that once an instance of <see cref="SearchFilterItem"/>
    /// has been created it cannot be changed.  For this class that means that the <see cref="E:List"/>
    /// of <see cref="E:SearchFilterItem"/> objects are read-only, the items in the list can not 
    /// be added, deleted or modified.
    /// </para>
    /// <para>
    /// This class implements the <c>Builder</c> design pattern.  For information on this
    /// design pattern go here http://en.wikipedia.org/wiki/Builder_pattern.
    /// </para>
    /// </remarks>
    /// <author>ViewE Common Tag Team</author>
    public class SearchFilterConfig
    {
        private List<SearchFilterItem> _mapItems;

        /// <summary>
        /// Gets the list of <see cref="E:SearchFilterItem"/>'s.
        /// </summary>
        /// <remarks>
        /// The list is immutable (i.e. read-only). <see cref="E:FilterConfigItem"/> instances
        /// cannot be removed, added or modified.
        /// </remarks>
        public IList<SearchFilterItem> GetFilterItems { get { return _mapItems.AsReadOnly(); } }

        /// <summary>
        /// SearchFilterConfig builder class.
        /// </summary>
        public class CreateBuilder
        {
            #region Private Members

            private List<SearchFilterItem> _items { get; set; }

            #endregion

            /// <summary>
            /// default builder constructor
            /// </summary>
            public CreateBuilder()
            {
                _items = new List<SearchFilterItem>();
            }

            /// <summary>
            /// Adds a search filter item to this config
            /// list.
            /// </summary>            
            /// <param name="filterItem">An instance of a search filter item to add to the list.</param>            
            public CreateBuilder AddItem(SearchFilterItem filterItem)
            { _items.Add(filterItem); return this; }

            /// <summary>
            /// Validates and builds <see cref="E:SearchFilterConfig"/> instance.
            /// </summary> 
            public SearchFilterConfig Build()
            {
                return new SearchFilterConfig
                {
                    _mapItems = _items,
                };
            }
           
        }
        /// <summary>
        /// Goes through the filter items and prints it out for debugging purposes
        /// </summary>
        /// <returns>string</returns>
        public override string ToString()
        {
            var filterItems =  GetFilterItems;
            
            StringBuilder output = new StringBuilder();
            foreach (var filterItem in filterItems)
            {
                output.Append("Identifier: '")
                    .Append(filterItem.GetIdentifier)
                    .Append("' AlternateIdentifier: '")
                    .Append(filterItem.GetAlternateIdentifier)
                    .Append("' Value: '").Append(filterItem.GetValue)
                    .Append("' IsExactMatch: ")
                    .Append(filterItem.IsExactMatch)
                    .Append(" IsIdentifierColumnConfigKey: ")
                    .Append(filterItem.IsIdentifierColumnConfigKey)
                    .Append(" GetLogicOperator: ")
                    .Append(filterItem.GetLogicOperator)
                    .AppendLine(string.Empty);
                var nestedItems = filterItem.GetNestedItems;
                int num = nestedItems.Count;
                foreach (var nestedItem in nestedItems)
                {
                    output.Append("( Identifier: '" + nestedItem.GetIdentifier)
                        .Append("' AlternateIdentifier: '")
                        .Append(filterItem.GetAlternateIdentifier)
                        .Append("' Value: '")
                        .Append(nestedItem.GetValue)
                        .Append("' IsExactMatch: ")
                        .Append(nestedItem.IsExactMatch)
                        .Append(" IsIdentifierColumnConfigKey: ")
                        .Append(nestedItem.IsIdentifierColumnConfigKey)
                        .Append(" GetLogicOperator: ")
                        .Append(nestedItem.GetLogicOperator)
                        .AppendLine(string.Empty);
               }
                if (num > 0)
                    output.Append(")");
            }
            return output.ToString();
        }
        /// <summary>
        /// Default Constructor.
        /// <para>
        /// declared private as this class implements the builder pattern. The constructor
        /// is intentionally left empty.
        /// </para>
        /// </summary>
        private SearchFilterConfig() { }
    }
}
