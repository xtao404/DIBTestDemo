/*************************************************************************************
                                                                     
   ViewE ClientDataServiesTest Class
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System.Collections.Generic;
using System.Reflection;
using DataItemBrowserUT.Mocks;
using FakeItEasy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI;
using System;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query;

#endregion

namespace DataItemBrowserUT
{

    /// <summary>
    /// Summary description for ClientDataServicesTest
    /// </summary>
    [TestClass]
    public class ClientDataServicesTest
    {
        #region static members

        private static ClientDataServices target = null;
        private static PrivateObject targetPrivate = null;
        private static TSObservableCollection<DataItemBase> DataItems = new TSObservableCollection<DataItemBase>();

        #endregion

        public ClientDataServicesTest()
        {
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext) 
        //{ 
        //}
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //


        /// <summary>
        /// Use TestInitialize to run code before running each test 
        /// </summary>
        [TestInitialize()]
        public void ClientDataServicesTestInit()
        {
            DIBClientManagerForViewe.Instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, DIBQueryCommandTest.SamplePackageContextUUID, DIBQueryCommandTest.SampleProjectContextUUID);

            if ((target == null))
            {
                // Mimics UI thread
                BackgroundWorkerSyncContextHelper.DoTests(() =>
                {
                    TSObservableCollection<DataItemBase> _dataItems = new TSObservableCollection<DataItemBase>();
                    DataItems = _dataItems;
                    target = new ClientDataServices(ref _dataItems, null, DataServicesLoadComplete, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, DIBClientManagerForViewe.Instance);

                    targetPrivate = new PrivateObject(target);
                });
            }
        }
        
        /// <summary>
        /// Use TestCleanup to run code after each test has run
        /// </summary>
        [TestCleanup()]
        public void ClientDataServicesTestCleanup()
        {
            DIBClientManagerForViewe.Instance.Shutdown();

            if (target == null) return;
            //target.Shutdown();
            target = null;
            targetPrivate = null;
        }

        public ulong HiWord(string project)
        {
            return Convert.ToUInt64(project.Substring(0, 16), 16);
        }

        public ulong LoWord(string project)
        {
            return Convert.ToUInt64(project.Substring(16, 16), 16);
        }        

        /// <summary>
        /// DataServices load complete callback
        /// 
        /// Note: This callback is called once the data services has obtained a load complete
        ///       event from the underlying query services.
        /// </summary>
        /// <param name="error">If non-empty, reflects an error obtained by the query services</param>
        private void DataServicesLoadComplete(string error)
        {
            System.Diagnostics.Trace.WriteLine("============ # of DataItems = " + DataItems.Count.ToString());
            Assert.IsTrue(string.IsNullOrEmpty(error), "DataServicesLoadComplete returned an error = " + error);
        }

        #endregion

        #region Mock QSP tests
        
        // Following commented out so Mock DibQuery is not used 

        /// <summary>
        /// used to pause an asynchronous unit tests until the async operation
        /// has completed and raised the appropriate PropertyChangeNotification.
        /// </summary>
        /// <param name="millisecond_interval">milliseconds to have the thread sleep before next polling</param>
        //public void WaitForAsyncCompleteEvent(int millisecond_interval)
        //{
        //    // set max wait time before a time out
        //    // Note: currently set to 300000ms (5 mins) to compensate for the 
        //    //       ResourceServiceProvider current performance issues.  once
        //    //       that has been addressed we could lower the max time to 
        //    //       something more reasonable
        //    int max_wait = 300000;
        //    int wait_time = 0;

        //    if (millisecond_interval < 3000)
        //        millisecond_interval = 3000;

        //    while (ClientDataServices.IsBusy && (wait_time < max_wait))
        //    {
        //        wait_time += millisecond_interval;
        //        Thread.Sleep(millisecond_interval);
        //    }
        //    if (ClientDataServices.IsBusy)
        //        Assert.Fail("Maximum wait time exceeded, unit test failed");
        //}

        //// The list of controllers were retrieved in ClientDataServicesTestInit. Validate the returned information.
        //[TestMethod]
        //public void ClientDataServicesTest_DrillIn()
        //{

        //    // Use Mock resource service type for the DibQuery
        //    ClientDataServices.SetResourceServiceType(true);
        //    string project = "00000000000011110000000000002222";
        //    UUID projectContext = UUID.CreateBuilder().SetHi(HiWord(project)).SetLo(LoWord(project)).Build();
        //    target.SetProjectContext(projectContext);
        //    target.Initialize(null);

        //    // Wait for DrillIn to controllers
        //    WaitForAsyncCompleteEvent(3000);

            //// Validate 4 controllers are returned
            //Assert.IsTrue(DataItems.Count == 4, "DataItems.Count is not equal to 4. DataItems.Count = " + DataItems.Count.ToString());
 
            //// Validate resource type for a controller
            //Assert.IsTrue(target.GetResourceTypeString(DataItems[0]) == DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER, "Invalid resource type = " + target.GetResourceTypeString(DataItems[0]));

            //// Validate column configuration
            //Assert.IsTrue(target.Columns.Count == 1, "1 column should exist for the Data Sources View. count = " + target.Columns.Count.ToString());
            //Assert.IsTrue(target.Columns[0].GetColumn == "Name", "Invalid column name = " + target.Columns[0].GetColumn);

            // Following doesn't work for some reason
            //// DrillIn to Controller1's programs
            //target.DrillIn(DataItems[0]);

            //WaitForAsyncCompleteEvent(3000);

            //// Validate 4 controllers are returned
            //Assert.IsTrue(DataItems.Count == 1, "DataItems.Count is not equal to 1. DataItems.Count = " + DataItems.Count.ToString());

            //// Validate resource type for a controller
        //Assert.IsTrue(target.GetResourceTypeString(DataItems[0]) == DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER, "Invalid resource type = " + target.GetResourceTypeString(DataItems[0]));

            //// Validate column configuration
            //Assert.IsTrue(target.Columns.Count == 2, "2 column should exist for the Data Sources View. count = " + target.Columns.Count.ToString());
            //Assert.IsTrue(target.Columns[0].GetColumn == "Name", "Invalid column name = " + target.Columns[0].GetColumn);
            //Assert.IsTrue(target.Columns[1].GetColumn == "Description", "Invalid column name = " + target.Columns[1].GetColumn);

        //}
        #endregion Mock QSP tests

        /// <summary>
        /// Test GetResourceTypeString and SetDataView
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_GetResourceTypeString_and_SetDataView()
        {
            DataItemBase dataItem = null;
            Assert.IsTrue(DIResource.GetResourceTypeString(dataItem, true) == "none", "Invalid resource type. Expected 'none' received = " + DIResource.GetResourceTypeString(dataItem, true));

            dataItem = new DataItemBase();
            dataItem.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();
            Assert.IsTrue(DIResource.GetResourceTypeString(dataItem, true) == DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER, "Invalid resource type. Expected 'Controller' received = " + DIResource.GetResourceTypeString(dataItem, true));
            targetPrivate.Invoke("SetDataView", DIResource.GetResourceTypeString(dataItem, true));
            Assert.IsTrue(target.DataView.IsControllerView(), "Invalid DataView for getResourceType_Controller");

            dataItem = new DataItemBase();
            dataItem.CommonResourceType = TypeIdentifiers.ResourceType_Device.ToString();
            Assert.IsTrue(DIResource.GetResourceTypeString(dataItem, true) == DIResource.DI_COMMON_RESOURCETYPE_DEVICE, "Invalid resource type. Expected 'Device' received = " + DIResource.GetResourceTypeString(dataItem, true));
            targetPrivate.Invoke("SetDataView", DIResource.GetResourceTypeString(dataItem, true));
            Assert.IsTrue(target.DataView.IsTreeView(), "Invalid DataView for ResourceType_Device");

            dataItem = new DataItemBase();
            dataItem.CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString();
            Assert.IsTrue(DIResource.GetResourceTypeString(dataItem, true) == DIResource.DI_COMMON_RESOURCETYPE_TAG, "Invalid resource type. Expected 'Tag' received = " + DIResource.GetResourceTypeString(dataItem, true));
            targetPrivate.Invoke("SetDataView", DIResource.GetResourceTypeString(dataItem, true));
            Assert.IsTrue(target.DataView.IsGridView(), "Invalid DataView for ResourceType_Tag");

            dataItem = new DataItemBase();
            dataItem.CommonResourceType = TypeIdentifiers.ResourceType_DataType.ToString();
            Assert.IsTrue(DIResource.GetResourceTypeString(dataItem, false) == DIResource.DI_COMMON_RESOURCETYPE_DATATYPE, "Invalid resource type. Expected 'DataType' received = " + DIResource.GetResourceTypeString(dataItem, false));
            targetPrivate.Invoke("SetDataView", DIResource.GetResourceTypeString(dataItem, false));
            Assert.IsTrue(target.DataView.GetType().Name.Contains("DIBDataViewTypeDataType"), "Invalid DataView for ResourceType_DataType");

            dataItem = new DataItemBase();
            dataItem.CommonResourceType = TypeIdentifiers.ResourceType_Program.ToString();
            Assert.IsTrue(DIResource.GetResourceTypeString(dataItem, true) == DIResource.DI_COMMON_RESOURCETYPE_PROGRAM, "Invalid resource type. Expected 'Program' received = " + DIResource.GetResourceTypeString(dataItem, true));
            targetPrivate.Invoke("SetDataView", DIResource.GetResourceTypeString(dataItem, true));
            Assert.IsTrue(target.DataView.IsGridView(), "Invalid DataView for ResourceType_Program");

            dataItem = new DataItemBase();
            dataItem.CommonResourceType = TypeIdentifiers.ResourceType_TagsAndProperties.ToString();
            Assert.IsTrue(DIResource.GetResourceTypeString(dataItem, true) == DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGS, "Invalid resource type. Expected 'Controllertags' received = " + DIResource.GetResourceTypeString(dataItem, true));
            targetPrivate.Invoke("SetDataView", DIResource.GetResourceTypeString(dataItem, true));
            Assert.IsTrue(target.DataView.IsGridView(), "Invalid DataView for ResourceType_TagsAndProperties");

            dataItem = new DataItemBase();
            dataItem.CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString();
            Assert.IsTrue(DIResource.GetResourceTypeString(dataItem, true) == DIResource.DI_COMMON_RESOURCETYPE_DATATYPEMEMBER, "Invalid resource type. Expected 'DataTypeMember' received = " + DIResource.GetResourceTypeString(dataItem, true));
            targetPrivate.Invoke("SetDataView", DIResource.GetResourceTypeString(dataItem, true));
            Assert.IsTrue(target.DataView.IsGridView(), "Invalid DataView for ResourceType_DataTypeMember");
        }


        #region IsDeviceView

        /// <summary>
        /// Validate that the correct response is returned given various configurations
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_IsDeviceViewTest()
        {
            target.DataView = new DIBDataViewTypeDataType();
            Assert.IsFalse(target.DataView.IsListView());

            target.DataView = new DIBDataViewTypeSearchGrid();
            Assert.IsFalse(target.DataView.IsListView());

            target.DataView = new DIBDataViewTypeProgramsGrid();
            Assert.IsFalse(target.DataView.IsListView());

            target.DataView = new DIBDataViewTypeDataLogsGrid();
            Assert.IsFalse(target.DataView.IsListView());

            target.DataView = new DIBDataViewTypeUnknown();
            Assert.IsFalse(target.DataView.IsListView());

            target.DataView = new DIBDataViewTypeTreeView();
            Assert.IsFalse(target.DataView.IsListView());

            target.DataView = new DIBDataViewTypeListView();
            Assert.IsTrue(target.DataView.IsListView());

            target.DataView = new DIBDataViewTypeHMIDevice();
            Assert.IsTrue(target.DataView.IsListView());

            target.DataView = new DIBDataViewTypeDataGrid();
            Assert.IsFalse(target.DataView.IsListView());
        }
        #endregion IsDeviceView

        #region IsGridView
        /// <summary>
        /// Validate that the correct response is returned given various configurations
        /// </summary>
        [TestMethod]
        public void ClientDataServicesTest_IsGridViewTest()
        {
            target.DataView = new DIBDataViewTypeDataType();
            Assert.IsTrue(target.DataView.IsGridView());

            target.DataView = new DIBDataViewTypeSearchGrid();
            Assert.IsTrue(target.DataView.IsGridView());

            target.DataView = new DIBDataViewTypeProgramsGrid();
            Assert.IsTrue(target.DataView.IsGridView());

            target.DataView = new DIBDataViewTypeDataLogsGrid();
            Assert.IsTrue(target.DataView.IsGridView());

            target.DataView = new DIBDataViewTypeUnknown();
            Assert.IsFalse(target.DataView.IsGridView());

            target.DataView = new DIBDataViewTypeTreeView();
            Assert.IsFalse(target.DataView.IsGridView());

            target.DataView = new DIBDataViewTypeListView();
            Assert.IsFalse(target.DataView.IsGridView());

            target.DataView = new DIBDataViewTypeHMIDevice();
            Assert.IsFalse(target.DataView.IsGridView());

            target.DataView = new DIBDataViewTypeDataGrid();
            Assert.IsTrue(target.DataView.IsGridView());
        }

        #endregion IsGridView
        
        /// <summary>
        ///A test for  IsDataTypeBrowser and IsTagBrowser
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ClientDataServices_IsDataTypeBrowser_IsTagBrowser_Verify()
        {
            //ARRANGE
            TSObservableCollection<DataItemBase> dataItems = DIBUtility.GetTagViewList();
            Path path = new Path();
            target = new ClientDataServices(ref dataItems, path, DataServicesLoadComplete, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, DIBClientManagerForViewe.Instance);

            //ACT
            bool result = target.IsDataTypeBrowser();

            //Assert
            Assert.IsFalse(result);

            //ACT
            result = target.IsTagBrowser();

            //ASSERT
            Assert.IsTrue(result);

            //ARRANGE        
            target = new ClientDataServices(ref dataItems, path, DataServicesLoadComplete, DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser, DIBClientManagerForViewe.Instance);
        
            //ACT
            result = target.IsDataTypeBrowser();

            //ASSERT
            Assert.IsTrue(result);

            //ACT
            result = target.IsTagBrowser();

            //ASSERT
            Assert.IsFalse(result);

        }


        /// <summary>
        ///A test for Verifying pass through calls from CDS to DIBQueryCache
        /// this test is to verify that the architecture of the code is maintained and if 
        /// the tests fail they must be updated to reflect the new architecture changes that were
        /// purposefully made
        /// 
        /// There are unit tests for the DIBQueryCache in DIBQueryCacheTest that cover the logic of these method calls
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ClientDataServices_VerifyPassThroughs()
        {
            //ARRANGE
            TSObservableCollection<DataItemBase> dataItems = DIBUtility.GetTagViewList();
            Path path = new Path();

            target = new ClientDataServices(ref dataItems, path, DataServicesLoadComplete, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, DIBClientManagerForViewe.Instance);
            targetPrivate = new PrivateObject(target);
            MockDIBQueryCache mockDIBQueryCache = new MockDIBQueryCache(dataItems);

            targetPrivate.SetFieldOrProperty("_cache",mockDIBQueryCache);
           // targetPrivate._cache = mockDIBQueryCache;

            //ACT            
            ACrumb crumb = new TextCrumb(PathElementUtility.Instance().CreateDataLogPathElement("DataLog1"));
            List<DropArrowItem> listItems = target.GetChildrenOfCrumb(crumb, "DataLog");

            //Assert
            Assert.IsNotNull(listItems);
            Assert.IsTrue(mockDIBQueryCache.GetChildrenOfCrumbCalled);

            //ACT                        
            IObservableCollection<DataItemBase> dibCollection = target.GetCachedDevices();

            //Assert
            Assert.IsNotNull(dibCollection);
            Assert.IsTrue(mockDIBQueryCache.GetCachedDevicesCalled);

            //ACT 
            DataItemBase dib = target.GetDeviceItemByName("deviceName");

            //Assert
            Assert.IsNotNull(dib);
            Assert.IsTrue(mockDIBQueryCache.GetDeviceItemByNameCalled);

            //ACT
            DataItemBase dib1 = target.GetDataItemByName("itemName");

            //ASSERT
            Assert.IsNotNull(dib1);
            Assert.IsTrue(mockDIBQueryCache.GetDataItemByNameCalled);

            //ACT
            DataItemBase dib2 = target.GetDataTypeItemByLocation("datatype", "location");

            //ASSERT
            Assert.IsNotNull(dib2);
            Assert.IsTrue(mockDIBQueryCache.GetDataTypeItemByLocationCalled);
        }
    }
}
