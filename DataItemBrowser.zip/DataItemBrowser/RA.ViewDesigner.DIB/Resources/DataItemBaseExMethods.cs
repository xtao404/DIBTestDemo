﻿#region Copyright © 2011 Rockwell Automation Technologies, Inc. All Rights Reserved.

/**************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This software has been provided pursuant to a License Agreement containing 
   restrictions on its use. The  software contains valuable trade secrets and 
   proprietary information of Rockwell Automation and is protected by federal 
   copyright law. It may not be copied or distributed in any form or medium, 
   disclosed to third parties or used in any manner not provided for  in the 
   License Agreement except with prior written permission of Rockwell Automation.

 *************************************************************************************/

#endregion

using System;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.Client.Services.Query.AbstractItem
{
    /// <summary>
    /// <see cref="DataItemBase"/> extension methods implementation.
    /// </summary>
    /// <remarks>
    /// <para>
    /// These extension methods add extended functionality to a <see cref="DataItemBase"/> type in a way that 
    /// makes the methods appear as natrual <c>extension</c> to the <see cref="DataItemBase"/> type. 
    /// </para>
    /// <para>
    /// The <see cref="DataItemBase"/> class is located in the <c>ct_query_bt</c> package in the <see cref="QuerAPI"/>
    /// assembly. The <see cref="DataItemBase"/> class and the <see cref="DataItemBaseExMethods"/>
    /// class are located in different assemblies 
    /// </para>
    /// </remarks>
    /// <author>ViewE Common Tag Team</author>
    [Serializable]
    public static class DataItemBaseExMethods
    {

        /// <summary>
        /// Get ReplicationState
        /// </summary>
        public static string GetVieweReplicationState(this DataItemBase source)
        {
            return source.GetStringMapValue(DIBConstantsViewe.ReplicationState);
        }
        /// <summary>
        /// Set ReplicationState
        /// </summary>
        public static void SetVieweReplicationState(this DataItemBase source, String value)
        {
            source.SetStringMapValue(DIBConstantsViewe.ReplicationState, value);
        }


        /// <summary>
        /// Get ReplicationErrorMessage
        /// </summary>
        public static string GetVieweReplicationErrorMessage(this DataItemBase source)
        {
            return source.GetStringMapValue(DIBConstantsViewe.ReplicationErrorMessage);
        }
        /// <summary>
        /// Set ReplicationErrorMessage
        /// </summary>
        public static void SetVieweReplicationErrorMessage(this DataItemBase source, String value)
        {
            source.SetStringMapValue(DIBConstantsViewe.ReplicationErrorMessage, value); 
        }
    }
}