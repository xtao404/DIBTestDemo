﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Object;

namespace TagFilterControl.Controls.PreFilterManager.FilterInsatnce
{
    public class BaseFilter
    {
        private Config config = Config.GetInstance();
        public List<FilterUnitField> FieldFilters = new List<FilterUnitField>();
        public String Reason { get; set; }

        public void Initialize(FilterReturnBase filterOption)
        {
            string lastPolicy = string.Empty;
            foreach (FilterItemBase filterItem in filterOption.Conditions)
            {
                FilterUnitField fieldFilter = CreateOneFieldFilterUnit(filterItem);
                if (fieldFilter != null)
                {
                    FieldFilters.Add(fieldFilter);
                    lastPolicy = fieldFilter.Policy == AndOrValue.None ? string.Empty : fieldFilter.Policy.ToString();
                }
            }
            config.FieldFilters = this.FieldFilters;
        }

        private FilterUnitField CreateOneFieldFilterUnit(FilterItemBase filterItem)
        {
            FilterUnitField filterField = null;
            switch (filterItem.Value.MetadataType)
            {
                case RuleMetaDataType.String:
                case RuleMetaDataType.Enum:
                    filterField = new FilterUnitFieldText();
                    break;
                case RuleMetaDataType.Number:
                    break;
                default:
                    break;

            }
            if (filterField != null)
                filterField.Initialize(filterItem);

            return filterField;
        }

        protected object GetAttributeValueFilterInformation(TagObjects tag, FilterUnitField fFilter)
        {
            object fieldValue = null;
            switch (fFilter.RuleType)
            {
                case RuleType.Unknown:
                    break;
                case RuleType.TagName:
                    fieldValue = tag.Name;
                    break;
                case RuleType.TagType:
                    fieldValue = tag.TagType;
                    break;
                case RuleType.UserDefined:
                case RuleType.Strings:
                case RuleType.AddOnDefined:
                case RuleType.ModuleDefined:
                case RuleType.PreDefined:
                    fieldValue = tag.DataType;
                    break;
                case RuleType.TagOwner:
                    fieldValue = tag.Owners;
                    break;
                default:
                    break;
            }
            return fieldValue;
        }

        public virtual bool Apply(TagObjects tag)
        {
            return true;
        }

    }
}
