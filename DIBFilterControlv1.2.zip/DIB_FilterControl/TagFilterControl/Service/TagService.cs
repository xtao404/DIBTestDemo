﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using TagFilterControl.Controls.PreFilterManager.Common;
using TagFilterControl.Controls.PreFilterManager.FilterInsatnce;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Object;
using TagFilterControl.Tags;
using TagFilterControl.Utility;

namespace TagFilterControl.Service
{
    public class TagService : ITagService
    {
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private Config config = Config.GetInstance();

        #region LoadTree
        public TagTreeViewResult LoadSubItems(TagNode selectNode)
        {
            TagTreeViewResult result = new TagTreeViewResult();
            result.Children = new ObservableCollection<TagNode>();

            switch (selectNode.Name)
            {
                case "User-Defined":
                    GetDataTypes(xmlHelper.UserDefined, selectNode, result);
                    break;
                case "Strings":
                    GetDataTypes(xmlHelper.Strings, selectNode, result);
                    break;
                case "Add-On-Defined":
                    GetDataTypes(xmlHelper.AddOnDefined, selectNode, result);
                    break;
                case "PreDefined":
                    GetDataTypes(xmlHelper.PreDefined, selectNode, result);
                    break;
                case "Module-Defined":
                    GetDataTypes(xmlHelper.ModuleDefined, selectNode, result);
                    break;
                case "Usage":
                    GetTageUsage(xmlHelper.Usage, selectNode, result);
                    break;
                case "ACM":
                    GetCustomProperties(selectNode, result);
                    break;
                default:
                    break;
            }

            switch (selectNode.Type)
            {
                case Types.CatalogNumber:
                    GetCatalogNumbers(xmlHelper.Libs, selectNode, result);
                    break;
                case Types.Interface:
                    GetInterfaces(xmlHelper.Libs, selectNode, result);
                    break;
                case Types.DataMembers:
                    GetDataMembers(xmlHelper.Libs, selectNode, result);
                    break;
                case Types.Name:
                    break;
                case Types.KEYID:
                    break;

                default:
                    break;
            }
            return result;
        }

        private void GetCustomProperties(TagNode selectNode, TagTreeViewResult result)
        {
            TagNode tag = new TagNode();
            tag.Name = "Catalog Number";
            tag.IsChecked = selectNode.IsChecked;
            tag.Type = Types.CatalogNumber;
            tag.HasChild = true;

            TagNode itag = new TagNode();
            itag.Name = "Interface";
            itag.IsChecked = selectNode.IsChecked;
            itag.Type = Types.Interface;
            tag.HasChild = true;

            TagNode dtag = new TagNode();
            dtag.Name = "DataMembers";
            dtag.IsChecked = selectNode.IsChecked;
            dtag.Type = Types.DataMembers;
            tag.HasChild = true;

            result.Children.Add(tag);
            //result.Children.Add(itag);
            //result.Children.Add(dtag);
        }

        private void GetInterfaces(List<LibraryEntity> libs, TagNode selectNode, TagTreeViewResult result)
        {
            foreach (LibraryEntity lib in libs)
            {
                if (lib.InterfaceLink != null)
                {
                    foreach (Interface inter in lib.InterfaceLink.Interfaces)
                    {
                        TagNode tag = new TagNode();
                        tag.Name = inter.Name;
                        tag.IsChecked = selectNode.IsChecked;
                        tag.Type = Types.InterfaceSelf;
                        tag.HasChild = false;
                        result.Children.Add(tag);
                    }
                }
            }
        }

        private void GetDataMembers(List<LibraryEntity> libs, TagNode selectNode, TagTreeViewResult result)
        {
            foreach (LibraryEntity lib in libs)
            {
                if (lib.InterfaceLink != null)
                {
                    foreach (Interface inter in lib.InterfaceLink.Interfaces)
                    {
                        if (inter.Member != null)
                        {
                            foreach (Mem mem in inter.Member.Mems)
                            {
                                TagNode tag = new TagNode();
                                tag.Name = mem.Name;
                                tag.IsChecked = selectNode.IsChecked;
                                tag.Type = Types.DataMemberSelf;
                                tag.HasChild = false;
                                result.Children.Add(tag);
                            }
                        }
                    }
                }
            }
        }

        private void GetCatalogNumbers(List<LibraryEntity> libs, TagNode selectNode, TagTreeViewResult result)
        {
            if (libs.Count != 0)
            {
                foreach (LibraryEntity item in libs)
                {
                    TagNode tag = new TagNode();
                    tag.Guid = item.Guid;
                    tag.Name = item.CatalogNumber;
                    if (!selectNode.IsRefresh && config.ACMCustomPropertiesTagOwnersFilter.Keys.Contains(item.Guid))
                    {
                        tag.IsChecked = true;
                    }
                    else
                    {
                        tag.IsChecked = selectNode.IsChecked;
                    }
                    tag.Type = Types.CatalogNumberSelf;
                    tag.HasChild = false;
                    result.Children.Add(tag);
                }
            }
            else
            {
                foreach (KeyValuePair<string, string> item in xmlHelper.TagOwners)
                {
                    TagNode tag = new TagNode();
                    tag.Guid = item.Key;
                    tag.Name = item.Value;
                    if (!selectNode.IsRefresh && config.ACMCustomPropertiesTagOwnersFilter.Keys.Contains(item.Key))
                    {
                        tag.IsChecked = true;
                    }
                    else
                    {
                        tag.IsChecked = selectNode.IsChecked;
                    }
                    tag.Type = Types.CatalogNumberSelf;
                    tag.HasChild = false;
                    result.Children.Add(tag);
                }
            }

        }

        private void GetDataTypes(List<TagDataType> dataTypes, TagNode selectNode, TagTreeViewResult result)
        {
            foreach (TagDataType item in dataTypes)
            {
                TagNode tag = new TagNode();
                tag.Guid = Guid.NewGuid().ToString();
                tag.Name = item.Name;
                if (!selectNode.IsRefresh && config.IsCheckedTags.Keys.Contains(item.Name))
                {
                    tag.IsChecked = true;
                }
                else
                {
                    tag.IsChecked = selectNode.IsChecked;
                }
                tag.Type = Types.None;
                tag.HasChild = false;
                result.Children.Add(tag);
            }
        }

        private void GetTageUsage(List<TagObjects> tags, TagNode selectNode, TagTreeViewResult result)
        {
            foreach (TagObjects item in tags)
            {
                if (item.Usage == TagUsage.None)
                {
                    continue;
                }
                TagNode tag = new TagNode();
                tag.Guid = Guid.NewGuid().ToString();
                tag.Name = item.Usage.ToString();
                tag.IsChecked = selectNode.IsChecked;
                tag.Type = Types.None;
                tag.HasChild = false;
                result.Children.Add(tag);
            }
        }
        #endregion

        public object SaveFilterInfo(FilterProfile filterDto, OperationAction action)
        {
            switch (action)
            {
                case OperationAction.None:
                    break;
                case OperationAction.CreateNew:
                    config.FilterItem.Add(filterDto);
                    break;
                case OperationAction.Update:
                    for (int i = 0; i < config.FilterItem.Count; i++)
                    {
                        if (config.FilterItem[i].ID.Equals(filterDto.ID))
                        {
                            config.FilterItem[i] = filterDto;
                        }
                    }
                    break;
                default:
                    break;
            }

            return default(object);
        }

        public QueryListResult<FilterProfile> QueryFilterItems()
        {
            var result = new QueryListResult<FilterProfile>();
            try
            {
                result.QueryList = config.FilterItem;
                return result;
            }
            catch (Exception)
            {
                return result;
            }
        }


        public QueryListResult<FilterProfile> LoadFilterByIdAndInitializeFilterItem(FilterProfile dto, FilterManager filterManager)
        {
            var result = new QueryListResult<FilterProfile>();
            if (dto != null)
            {
                FilterProfile profile = config.FilterItem.Find(p => p.ID.Equals(dto.ID));

                if (profile != null)
                {
                    FilterOptionsSubProfileContent filterContent = profile.FilterContent;

                    if (filterContent != null)
                    {
                        filterManager.Initialize(filterContent);
                    }
                }
            }
            return result;
        }
    }
}
