﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region assembly references

using System.ComponentModel;
using System.Collections.Generic;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.Client.Services.Query.Common;

#endregion

namespace RockwellAutomation.UI
{
    #region DataTypePathElement Category Enumeration

    public enum DataTypePECategory
    {
        Product,
        Module,
        User
    }

    #endregion

    /// <summary>
    /// abstract base class implementation for path elements
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1012:AbstractTypesShouldNotHaveConstructors")]
    public abstract class PathElementBase : IPathElement, INotifyPropertyChanged
    {

        #region Constructor

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public PathElementBase(DataItemBase dataItem, string displayName)
        {
            if (displayName != null) this.DisplayName = displayName;
            if (dataItem != null) this.DataItem = dataItem;
        }

        #endregion

        #region IPathElement members

        /// <summary>
        /// Property to get or set the path element's display name.
        /// </summary>
        public abstract string DisplayName
        {
            get;
            set;
        }

        /// <summary>
        /// Property to get or set if the path element is a container.
        /// </summary>
        public abstract bool IsContainer
        {
            get;
        }

        /// <summary>
        /// Property to get or set if the path element has children.
        /// </summary>
        public abstract bool HasChildren
        {
            get;
        }

        /// <summary>
        /// Property to get or set if the path element is active.
        /// </summary>
        public abstract bool IsActive
        {
            get;
            set;
        }

		/// <summary>
		/// Property to get or set the unique id for the underlying component.
		/// </summary>
        public UUID ResourceId
        {
            get
            {
                return ResourceBase.GuidStringToId(DataItem.CommonID);
            }
            
        }

		/// <summary>
		/// Property to get or set the data item for the underlying component.
		/// </summary>
		virtual public DataItemBase DataItem
		{
			get;
			set;
		}

        #endregion

        #region INotifyPropertyChanged Members

        /// <summary>
        /// implements that INotifyPropertyChagned interface method NotifyPropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

    }
    
}
