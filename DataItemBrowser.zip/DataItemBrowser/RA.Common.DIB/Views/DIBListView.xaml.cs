﻿/*************************************************************************************
                                                                     
   ViewE DIBListView
   Copyright © 2009-2011 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.ViewModels;


namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Interaction logic for DIBListView.xaml
    /// </summary>
    public partial class DIBListView : ListView
    {
        // When grid is active and user presses an alphanumeric keyboard key, we select a row whose first column name matches what was typed (AutoSelection feature)
        // The list of characters is stored in currentAutoCompleteString
        private String currentAutoCompleteString { get; set; }
        //The last time a user types in a key
        private DateTime lastAutoCompleteKeyInputTime { get; set; }

        /// <summary>
        /// Accessor to this view's ViewModel
        /// </summary>
        /// <returns></returns>
        private DIBListViewModel ListViewModel
        {
            get { return (DIBListViewModel)this.DataContext; }
        }

        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {
            this.ListViewModel.Cleanup();
        }

        /// <summary>
        /// constructor
        /// </summary>
        public DIBListView()
        {
            InitializeComponent();
            this.ItemContainerStyle = this.FindResource("DeviceViewItemContainerStyle") as Style;
        }

        /// <summary>
        /// key down event in the device view control
        /// </summary>
        /// <param name="sender">not used</param>
        /// <param name="e"></param>
        private void DeviceViewControl_KeyDown(object sender, KeyEventArgs e)
        {
            // Dont even attempt this if we are not visible
            if (this.ListViewModel.Visible != Visibility.Visible)
                return;

            // Process DIB Item selection if needed
            if (e.Key == Key.Enter && this.ListViewModel.SelectedItem.DataItem != null)
            {
                e.Handled = true;
                this.ListViewModel.DoubleClickSelection(ListViewModel.SelectedItem.DataItem);
                return;
            }

            //Attempt to process Device View AutoSelection (Select row in device view with first column Name matching keyboard string user has entered during last 2 seconds)
            if (!KeyboardNavigation.IsValidGridAutoSelectionKey(e)) return;
            this.ProcessKeyboardAutoSelect(e);
        }

        /// <summary>
        /// Attempt to drill into currently selected Item and give keyboard focus afterwards
        /// </summary>
        public void ProcessKeyboardRequestDrillIn()
        {
            // Dont even attempt this if we are not visible
            if (this.ListViewModel.Visible != Visibility.Visible)
                return;
            DIBListViewItem itemObj = (DIBListViewItem)GenericListView.Items.CurrentItem;
            if (itemObj == null) return;
            if (!itemObj.DataItem.IsStructured) return; // These items should all be structued
            ListViewModel.DrillInCommand.Execute(itemObj);
        }

        /// <summary>
        /// Give Keyboard Focus to the Device View
        /// </summary>
        public void ProcessKeyboardRequestFocus()
        {
            // Dont even attempt this if we are not visible
            if (this.ListViewModel.Visible != Visibility.Visible)
                return;
            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, (Action)(() => this.PrimProcessKeyboardRequestFocus(this)));
        }

        /// <summary>
        /// Attempt to drill out from currently selected Item and give keyboard focus afterwards
        /// </summary>
        public void ProcessKeyboardRequestDrillOut()
        {
            // Dont even attempt this if we are not visible
            if (this.ListViewModel.Visible != Visibility.Visible)
                return;
            // If we are drilling out to DataSource view, then we don't want to force keyboard selection to the DataGrid
            // We know that we are drilling out to DataSource view as we are the Device View
            ListViewModel.DrillOutCommand.Execute(null);
        }

        /// <summary>
        /// Attempt to select and give keyboard focus to the item above the currently selected tiem
        /// </summary>
        public void ProcessKeyboardRequestSelectPrevious()
        {
            // Dont even attempt this if we are not visible
            if (this.ListViewModel.Visible != Visibility.Visible)
                return;
            this.ProcessKeyboardRequestFocus();
            if (this.SelectedItem == null) return;
            if (this.Items.CurrentPosition == 0) return; //Don't allow a move up if we already at the top
            this.Items.MoveCurrentToPrevious();
        }

        /// <summary>
        /// Attempt to select and give keyboard focus to the item below the currently selected item
        /// </summary>
        public void ProcessKeyboardRequestSelectNext()
        {
            // Dont even attempt this if we are not visible
            if (this.ListViewModel.Visible != Visibility.Visible)
                return;
            this.ProcessKeyboardRequestFocus();
            if (this.SelectedItem == null) return;
            if (this.Items.CurrentPosition == this.Items.Count - 1) return; //Don't allow a move down if we already at the bottom
            this.Items.MoveCurrentToNext();
        }

        /// <summary>
        /// Give Keyboard Focus
        /// </summary>
        /// <param name="iElement"></param>
        private void PrimProcessKeyboardRequestFocus(IInputElement iElement)
        {
            if (iElement == null) return;
            Keyboard.Focus(iElement);

            ListViewItem item = ItemContainerGenerator.ContainerFromItem(this.SelectedItem) as ListViewItem;

            // Item will be null if we have switched from a different device as the SelectedItem does not exist
            // in the current collection
            if (item != null)
                item.Focus();
        }

        
        /// <summary>
        /// Whether the user selects that name of the folder or its button the folder should be selected.
        /// User's last highlighted item will not be changed as this is the device view and only folders are currently visible.
        /// </summary>
        /// <param name="sender">unused</param>
        /// <param name="e">Standard event args from the framework</param>
        private void DeviceView_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (GenericListView != null)
            {
                ListViewItem lvi = sender as ListViewItem;
                DIBListViewItem selectedItem = lvi.Content as DIBListViewItem;
                selectedItem.IsSelected = true;
                SelectedItem = selectedItem;
            }
        }

        /// <summary>
        /// Attempt to autoselect a row in the grid based on user keyboard input
        /// </summary>
        private void ProcessKeyboardAutoSelect(KeyEventArgs e)
        {
            this.AddToCurrentAutoCompleteString(e);
            string input = this.currentAutoCompleteString;
            int count = this.Items.Count;
            if (count < 1) return;
            //Look for autocomplete selection string
            for (int i = 0; i != count; i = i + 1)
            {
                DIBListViewItem lvi = this.Items[i] as DIBListViewItem;
                if (lvi == null) continue;
                String tName = lvi.Name.Trim().ToLower();
                if (tName.StartsWith(input))
                {
                    this.SelectedItem = lvi;
                    this.ProcessKeyboardRequestFocus();
                    e.Handled = true;
                    return;
                }
            }

            //if we have only one character in the currentAutoCompleteString and we didn't find any selection, empty out currentAutoCompleteString
            if (this.currentAutoCompleteString.Length == 1) currentAutoCompleteString = String.Empty;
        }

        /// <summary>
        /// Add the key contained in "e" to the auto complete string
        /// </summary>
        /// <param name="e">Contains the key to add</param>
        private void AddToCurrentAutoCompleteString(KeyEventArgs e)
        {
            if (this.lastAutoCompleteKeyInputTime == null) this.lastAutoCompleteKeyInputTime = DateTime.Now;
            //if its been over 2 seconds since the last keypress, then reset the currentAutoComplete string
            if (DateTime.Now.Subtract(lastAutoCompleteKeyInputTime) >= TimeSpan.FromSeconds(2)) this.currentAutoCompleteString = String.Empty;
            currentAutoCompleteString = currentAutoCompleteString + KeyboardNavigation.stringValueOfKey(e);
            this.lastAutoCompleteKeyInputTime = DateTime.Now;
        }

        /// <summary>
        /// SelectedItem has changed, either programmatically or by the user navigating
        /// </summary>
        /// <param name="sender">ListViewItem which is not used</param>
        /// <param name="e">Not used</param>
        private void DeviceViewControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Keep the current item in sync with the selected item
            // IsSynchronizedWithCurrentItem keeps CurrentItem synched with SelectedItem
            DIBListViewItem selectedItem = SelectedItem as DIBListViewItem;

            if (selectedItem != null)
            {
                // Create the appropriate PathElement (Tags and Properties, Programs, DataLogs, ...)
                IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(selectedItem.DataItem);

                ListViewModel.Path.HighlightedElement = pathElement;

                //If we are on the latest grid in the navigation path (meaning no
                // forward breadcrumbs), save the name of the selected item
                // such that we can restore it during navigation
                if (ListViewModel.Path.Forward == null)
                {
                    ListViewModel.Path.SavedHighlightedElement = pathElement;
                }
            }
            else
            {
                ListViewModel.Path.HighlightedElement = null;
            }

            EnsureSelectedItemIsVisible();
        }

        /// <summary>
        /// Called by the framework when the DataGridControl gets focus
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void DeviceViewControl_GotFocus(object sender, RoutedEventArgs e)
        {
            // Manually make sure the focus is set to the previously selected row
            if (this.Visibility != Visibility.Visible) return;
            EnsureSelectedItemIsVisible();
        }

        /// <summary>
        /// Device View control has completed loading
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeviceViewControl_Loaded(object sender, RoutedEventArgs e)
        {
           // This method's functionality will come into play when column's are supported (AOG) - later story
        }

        /// <summary>
        /// Helper to make sure the selected item of the device view is scrolled into view and focused
        /// </summary>
        private void EnsureSelectedItemIsVisible()
        {
            if (this.SelectedItem != null)
            {
                this.ScrollIntoView(this.SelectedItem);
                

                //DON'T do a "this.Focus" here as this needs to be left up to those
                // changing the selected item of the grid (via navigate or other
                // means).  If we were to do this here, someone trying to set
                // explicit focus may be ignored because this happens on a different
                // thread.  An example of this is the ClearSearchCommand on the DIB
                // which sets focus back to the search filter textbox after
                // executing the filter command (which refreshes the view and thus
                // the selected item in the grid).
            }
        }

        private void Device_ListView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            DIBListViewItem selectedItem = SelectedItem as DIBListViewItem;

            if (selectedItem != null && selectedItem.DataItem != null)
            {
                this.ListViewModel.DoubleClickSelection(selectedItem.DataItem);
            }
        }

    }
}
