﻿/*************************************************************************************     
   Copyright © 2012-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using System.ComponentModel;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.ObjectModel;
using RockwellAutomation.Client.Services.Query;
using System.Collections.Generic;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.DIBQuery
{
    /// <summary>
    /// IClientDataServices interface definition.
    /// </summary>
    public interface IClientDataServices
    {
        #region properties

        /// <summary>
        /// Represents which view the GUI is currently displaying
        /// </summary>      
        /// <returns>IDIBDataViewType</returns>
        IDIBDataViewType DataView { get; set; }

        /// <summary>
        /// Represents what columns the GUI should display given the current context
        /// </summary>
        /// <returns>The list of columns</returns>
        List<ColumnConfigMapItem> Columns{get;}

        /// <summary>
        /// DIBQueryCache holds the data collection and cached results
        /// </summary>  
        DIBQueryCache QueryCache
        {
            get;
        }
                
        /// <summary>
        /// DIBClientManager
        /// </summary>  
        DIBClientManager DibClientManager
        {
            get;
            set;
        }

        /// <summary>
        /// Browser context
        /// </summary>
        DataContext DataContext
        {
            get;
        }

        #endregion properties

        #region events
        
        /// <summary>
        /// Property changed event 
        /// </summary>
        event PropertyChangedEventHandler PropertyChanged;

        #endregion events

        /// <summary>
        /// Browser perspective
        /// </summary>
        /// <returns>Current perspective</returns>
        DIBViewItemBase.VisualPerspectiveEnum CurrentBrowserPerspective();

        /// <summary>
        /// List of cached devices
        /// </summary>
        /// <returns>ObservableCollection<DataItemBase> representing the Devices</returns>
        IObservableCollection<DataItemBase> GetCachedDevices();

        /// <summary>
        /// Current DataItemBase we are trying to drill into
        /// </summary>
        /// <returns>DataItemBase</returns>
        DataItemBase CurrentParentDataItem();

        /// <summary>
        /// Called when the query services have finished obtaining data for us
        /// </summary>
        /// <param name="qResponse">QueryResponse</param>
        void PerformQuery_DataLoadComplete(QueryResponse qResponse);       

        /// <summary>
        /// Initialize the navigation state (query service, etc).
        /// This method can throw a QueryException from the query initialization.
        /// </summary>      
        /// <param name="context">data item browser context</param>
        /// <param name="initCallback">callback Method to be invoked when the QSP complete data loading</param>       
        void Initialize(DataItemBrowserContext context, InitializationComplete initCallback);

        /// <summary>
        /// Generate a column config to use in query requests
        /// </summary>
        /// <returns>RockwellAutomation.Client.Services.Query.ColumnConfig</returns>
        RockwellAutomation.Client.Services.Query.ColumnConfig GenerateColumnConfig();
        
        /// <summary>
        /// Check if the browser type is a tag browser.
        /// </summary>
        /// <returns>true if tag browser, otherwise false</returns>
        bool IsTagBrowser();

        /// <summary>
        /// Check if the browsing HMI device.
        /// </summary>
        /// <returns>true if browsing HMI device, otherwise false</returns>
        bool IsBrowsingHMIDevice();

        /// <summary>
        /// Check if the meta data should be displayed
        /// </summary>
        /// <returns>true to display meta data, otherwise false</returns>
        bool ShouldDisplayMetaData();

        /// <summary>
        /// Check if query is executing
        /// </summary>
        /// <returns>true if active query, otherwise false</returns>
        bool IsExecutingQueryCommand();

        /// <summary>
        /// Check if the current browser type is a property browser.
        /// </summary>
        /// <returns>true if property browser, otherwise false</returns>
        bool IsAOGPropertyBrowser();

        /// <summary>
        /// Helper to set the problem info members based on the passed problem type.  This method will handle
        /// setting the strings/helpids based on the category of problem
        /// </summary>
        /// <param name="probType">Type of problem we encountered</param>
        /// <returns>Error string</returns>
        string SetProblemInfo(ProblemInfoType probType);

        /// <summary>
        /// Used to set the problem and help id variables that should be set by client data services
        /// if a problem occurs during navigation or execution
        /// </summary>
        /// <param name="textRef"></param>
        /// <param name="helpRef"></param>
        void SetProblemCallback(ProblemSetFunc probDelegate);

        /// <summary>
        /// Helper to obtain the data item for the passed name (using the current DataItems)
        /// </summary>
        /// <param name="itemName">Name of the item to search for</param>
        /// <param name="location">Path of the dataItem or where it is located</param>
        /// <returns>Data item matching the passed name or null if not found</returns>
        DataItemBase GetDataItemByName(string itemName, string location = null);

        /// <summary>
        /// Helper to obtain the dataitem for the datatype found in device "location" (using the current collection of DataItems)
        /// </summary>
        /// <param name="datatype">Name of the datatype to search for</param>
        /// <param name="location">Location associated with the datatype</param>
        /// <returns>Data item matching the passed name and location or null if not found</returns>
        DataItemBase GetDataTypeItemByLocation(string datatype, string location);

        /// <summary>
		/// Helper to obtain the data item for a device given a string name
		/// </summary>
		/// <param name="deviceName">Name of the device to search for</param>
		/// <returns>Data item matching the passed device name or null if not found</returns>
        DataItemBase GetDeviceItemByName(string deviceName);

        /// <summary>
        /// This method performs a  single update to the Column Configuration based on the provided parameters.
        /// </summary>
        /// <param name="columnAttribute">The attribute to be update (Width, visibility, etc)</param>
        /// <param name="columnName">the column name used to generate an key to the correct location</param>
        /// <param name="columnValue">The column Value to set</param>
        void UpdateColumnConfig(ColumnAttribute columnAttribute, string columnName, object columnValue);

        /// <summary>
        /// Persist the user config to disk
        /// </summary>
        void SaveColumnConfig();

        /// <summary>
        /// Performs a drill in to the passed data item, if a query is in process, the query will be cancelled and the 
        /// new drill in performed
        /// </summary>
        /// <param name="dataItem">Parent item to drill in to</param>
        /// <returns>True if we performed a query request as a result of this call</returns>
        bool DrillIn(DataItemBase dataItem);

        /// <summary>
        /// Performs a drill in to the passed data item only if necessary (will return the cached
        /// data if available)
        /// </summary>
        /// <param name="dataItem">Parent item to drill in to</param>
        /// <param name="callback">Callback to execute after drill in is complete</param>
        /// <returns>True if we performed a query request as a result of this call</returns>
        bool DrillIn(DataItemBase dataItem, DataLoadComplete callback);

         /// <summary>
        /// Performs a search/filter, if the QSP is in busy then cancel the current query and submit this one 
        /// </summary>
        /// <param name="dataItem">Parent item to drill in to</param>
        /// <param name="filterConfig">Structure containing the filter items the client specified.</param>
        /// <returns>True if we performed a query request as a result of this call</returns>
        bool Search(DataItemBase dataItem, SearchFilterConfig filterConfig);

        /// <summary>
        /// Close this instance of CDS, but leave the DIBQueryConnection open for caching and performance reasons
        /// </summary>
        void Close();

        /// <summary>
		/// Returns the children of the passed crumb.  Determined based on the cached
		/// result set from a previously executed query
		/// </summary>
		/// <param name="crumb">Crumb to obtain the children for</param>
		/// <param name="nextName">Name of the next crumb in the path (used for bold text setting)</param>
		/// <returns>List of DropArrowItem representing the children of the passed crumb</returns>
        List<DropArrowItem> GetChildrenOfCrumb(ACrumb crumb, string nextName);

    }

    /// <summary>
    /// Delegate used to performs a search/filter
    /// </summary>
    public delegate void ProcessSearch();

    /// <summary>
    /// Delegate used when when query command has finished obtaining data.
    /// </summary>
    /// <param name="error">string with error or empty if no error occurred</param>
    public delegate void DataLoadComplete(string error);

    /// <summary>
    /// Delegate used after the completion of the initialize the navigation state. 
    /// </summary>
    /// <param name="dataContext">Browser context</param>
    /// <param name="error">string with error or empty if no error occurred</param>
    public delegate void InitializationComplete(DataContext dataContext, string error);

    /// <summary>
    /// Delegate used if a problem is encountered during navigation or query command execution
    /// </summary>
    /// <param name="probText">problem description</param>
    /// <param name="probHelpId">number that could be used to find help</param>
    /// <param name="disableSearch"></param>
    /// <param name="disableCrumbs"></param>
    public delegate void ProblemSetFunc(string probText, string probHelpId = "", bool disableSearch = false, bool disableCrumbs = false);

    /// <summary>
    /// Enumeration representing the problem type
    /// </summary>
    public enum ProblemInfoType
    {
        NoProblem,
        InvalidContextGuid,
        InitializationError,
        ResourceServiceDown,
        ResourceServiceTimeout,
        ResourceServiceError
    }
}
