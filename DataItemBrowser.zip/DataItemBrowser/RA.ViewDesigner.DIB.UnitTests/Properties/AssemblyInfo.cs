﻿/* ****************************************************************************
*
*  Copyright 2014 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/
/*
	This is intended for use with .NET C# binaries.
*/

using System;
using System.Runtime;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security.Permissions;
using System.Globalization;
using System.Resources;

/*
	Instructions on use:
	1) Replace the entire contents of the original AssemblyInfo.cs with the contents of this file.
		It MUST keep the name AssemblyInfo.cs.

	2) Add the file dotnet_CommonAssemblyVersionInfo.cs to each component's project.
		DO NOT RENAME cs_ProductVersionInfo.cs. It must remain that name.
	
	3) Modify this file to customize it for your component.

Your component build MUST automatically modify these attributes during each build:
	AssemblyFileVersion (located in dnet_ProductVersionInfo.cs)

	NOTE: You can use this command to modify it:
	sed -i s/AssemblyFileVersion(".*")/AssemblyFileVersion("%VERSION%")/g dnet_ProductVersionInfo.cs
	
	
You MUST manually modify attributes at least once:
	AssemblyTitle
	AssemblyDescription
	
Optional attributes you can set or change from the defaults provided:
	ComVisible
	CLSCompliant
	FileIOPermission
	
*/


// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.


// REQUIRED: All components MUST set these attributes to the correct value.
// These are not expected to change once set
[assembly: AssemblyTitle("Data Item Browser Unit Tests")]
[assembly: AssemblyDescription("Data Item Browser Common Component Unit Tests")]


//  REQUIRED: Internal ASSEMBLY VERSION - do NOT change
// The version that is in the assembly's manifest. This is used by the dotnet runtime 
// for binding purposes - it is not directly visible to the user.
// By RA policy the assembly version is locked at this version and may be changed
// when a breaking change has occurred. It is the responsibility of the component owner
// to update this when needed. By default this value never changes - this has the effect
// of avoiding problems with dotnet binding when using strong names.
[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]


[assembly: ComVisible(false)]
[assembly: CLSCompliant(false)]
// OPTIONAL: security permissions your component needs
// uncomment this and put the correct permission as needed.
//	[assembly: FileIOPermission(SecurityAction.RequestMinimum)]
