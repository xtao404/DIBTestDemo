﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI;

namespace DataItemBrowserUT
{
    /// <summary>
    /// Summary description for ConverterTest
    /// </summary>
    [TestClass]
    public class ConverterTests
    {
        public ConverterTests()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestRemoveCarrriageReturnsConverter()
        {
            DataCellValueConverter converter = new DataCellValueConverter();
            string value = "string with carriage return\r\nbefore this.";
            string expectedResult = "string with carriage return before this.";
            string newvalue;
            newvalue = (string)converter.Convert(value, /*targetType*/ null, /*param*/ null, /*culture*/ null);
            Assert.AreEqual(expectedResult, newvalue);

            newvalue = (string)converter.Convert(null, /*targetType*/ null, /*param*/ null, /*culture*/ null);
            Assert.IsNull(newvalue);
            try
            {
                converter.ConvertBack(value, null, null, null);
            }
            catch (NotSupportedException exception)
            {
                Assert.AreEqual("Not supported", exception.Message);
            }
        }
        [TestMethod]
        public void TestOverflowArrowVisbilityConverter()
        {
            OverflowArrowVisbilityConverter converter = new OverflowArrowVisbilityConverter();
            object enumResult;
            object enumVisable = System.Windows.Visibility.Visible;
            object enumCollapsed = System.Windows.Visibility.Collapsed;
            // pass in true
            enumResult = converter.Convert(true, /*targetType*/ null, /*param*/ null, /*culture*/ null);
            Assert.AreEqual(enumResult, enumVisable);
            // pass in false
            enumResult = converter.Convert(false, /*targetType*/ null, /*param*/ null, /*culture*/ null);
            Assert.AreEqual(enumResult, enumCollapsed);
            try
            {
                converter.ConvertBack(null, null, null, null);
            }
            catch (NotSupportedException exception)
            {
                Assert.AreEqual("Not supported", exception.Message);
            }
        }
    }
}
