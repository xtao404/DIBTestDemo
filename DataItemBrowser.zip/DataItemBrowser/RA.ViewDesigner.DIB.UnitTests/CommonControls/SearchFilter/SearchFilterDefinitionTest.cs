﻿using RockwellAutomation.UI.CommonControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using System.Collections;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for SearchFilterDefinitionTest and is intended
    ///to contain all SearchFilterDefinitionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SearchFilterDefinitionTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion
        /// <summary>
        /// filter types used by parse method
        /// </summary>
        private ObservableCollection<FilterType> _filterTypes = null;
        /// <summary>
        /// private method to generate the valid filter types
        /// </summary>
        private void GenerateFilterTypes()
        {
            _filterTypes = new ObservableCollection<FilterType>
                               {
                                   new FilterType(DIBConstants.Common.Name,true,false),
                                   new FilterType(DIBConstants.Common.DataType,false,false),
                                   new FilterType(DIBConstants.Common.Description,true,false)
                               };
        }

        // Delegate for IsMatch and ApplyFilter
        public static string ReturnFieldValue(string fieldName, object item)
        {
            return ((DataItemBase)item).GetStringMapValue(fieldName);
        }
      

        /// <summary>
        ///A test for Add with search statement
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_AddTest_SearchStatement()
        {
            string value = "hello";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);
            SearchStatement statement = new SearchStatement(value, true, SearchFilterDefinition.StatementLogic.AND);
            target.Add(statement);
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");

            SearchStatement statementResult = ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements"))[0] as SearchStatement;
            Assert.AreEqual(value, statementResult.SearchValue.Value, "The search values should match");
            Assert.IsTrue(statementResult.SearchValue.ExactMatch, "Exact match should be set");
            Assert.AreEqual("AND", statementResult.OperatorToken.Value, "Operator does not match");
        }

        /// <summary>
        ///A test for Add with filter statement
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_AddTest_FilterStatement()
        {
            string type = "dt:";
            string value = "hello";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);
            FilterStatement statement = new FilterStatement(type,value, false, SearchFilterDefinition.StatementLogic.AND);
            target.Add(statement);

            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");

            FilterStatement statementResult = ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements"))[0] as FilterStatement;
            Assert.AreEqual(value, statementResult.FilterValues[0].Value, "The fitler values should match");
            Assert.IsFalse(statementResult.FilterValues[0].ExactMatch, "Exact match should be set");
            Assert.AreEqual("AND", statementResult.OperatorToken.Value, "Operator does not match");
        
        }

        /// <summary>
        ///A test for AddFilter
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_AddFilterTest()
        {
            string type = "dt:";
            string value = "yes";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);
 
            bool success = target.AddFilter(type, value, true,SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(success, "Filter was not added.");
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");

            FilterStatement statementResult = ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements"))[0] as FilterStatement;

            Assert.AreEqual(value, statementResult.FilterValues[0].Value, "The fitler values should match");
            Assert.IsTrue(statementResult.FilterValues[0].ExactMatch, "Exact match should be set");
            Assert.AreEqual("AND", statementResult.OperatorToken.Value, "Operator does not match");
            Assert.AreEqual(SearchFilterDefinition.FilterSearchStateEnum.UseFilter, (SearchFilterDefinition.FilterSearchStateEnum)targetPrivate.GetFieldOrProperty("FilterSearchState"));
            Assert.IsTrue(target.IsActive);
            Assert.IsTrue(target.HasNonEmptySearchValue);
            Assert.IsFalse(target.HasError);
        }

       

 

     

        /// <summary>
        ///A test for ApplyViewFilter
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_ApplyViewFilterSuccessTest()
        {
            GenerateFilterTypes();
            PrivateType privateSearchFilterDef = new PrivateType(typeof(SearchFilterDefinition));
            privateSearchFilterDef.SetStaticProperty("FilterTypes",_filterTypes);
            
            string type = "name:";
            string value = "youBet";
            ObservableCollection<FilterType> filters = DIBClientManagerForViewe.GetFilterTypes(true);
            //expose all filter types for testing
            foreach (FilterType ft in filters)
                ft.IsLaunchFilter = true;
            SearchFilterDefinition target = new SearchFilterDefinition(filters);
            PrivateObject targetPrivate = new PrivateObject(target);

            bool success = target.AddFilter(type, value, true, SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(success, "Filter was not added.");
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");
            Assert.IsTrue(target.IsActive);
            Assert.IsTrue(target.HasNonEmptySearchValue);
            Assert.IsFalse(target.HasError);

            bool IsMatch = target.ApplyViewFilter(PathElementUtility.Instance().CreateDataItemBase(value), ReturnFieldValue);
            Assert.IsTrue(IsMatch,"the dataitembase did not match");
        }

        /// <summary>
        ///A test for ApplyViewFilter
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_ApplyViewFilterFailTest()
        {
            string type = "name:";
            string value = "youBet";
            ObservableCollection<FilterType> filters = DIBClientManagerForViewe.GetFilterTypes(true);
            //expose all filter types for testing
            foreach (FilterType ft in filters)
                ft.IsLaunchFilter = true; 
            
            SearchFilterDefinition target = new SearchFilterDefinition(filters);
            PrivateObject targetPrivate = new PrivateObject(target);

            bool success = target.AddFilter(type, value, true, SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(success, "Filter was not added.");
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");
            Assert.IsTrue(target.IsActive);
            Assert.IsTrue(target.HasNonEmptySearchValue);
            Assert.IsFalse(target.HasError);

            bool IsMatch = target.ApplyViewFilter(PathElementUtility.Instance().CreateDataItemBase("notMe"), ReturnFieldValue);
            Assert.IsFalse(IsMatch, "the dataitembase did not match");
        }
        /// <summary>
        ///A test for ClearSearch
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_ClearSearchTest()
        {
            string type = "dt:";
            string value = "clearMe";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            bool success = target.AddFilter(type, value, true, SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(success, "Filter was not added.");
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");
            Assert.IsTrue(target.IsActive);
            Assert.IsTrue(target.HasNonEmptySearchValue);
            Assert.IsFalse(target.HasError);

            target.ClearSearch();
            Assert.AreEqual(0, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be no statements after ClearSearch.");
            Assert.IsFalse(target.IsActive, "Search should not be active");
            Assert.IsFalse(target.HasNonEmptySearchValue);
            Assert.IsFalse(target.HasError);
        }

        /// <summary>
        ///A test for GetFilterConfig
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_GetFilterConfigTest()
        {
            string type = "dt:";
            string value = "clearMe";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            bool success = target.AddFilter(type, value, false, SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(success, "Filter was not added.");
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");
            Assert.IsTrue(target.IsActive);
            Assert.IsTrue(target.HasNonEmptySearchValue);
            Assert.IsFalse(target.HasError); 

            SearchFilterConfig config = target.GetFilterConfig();
            Assert.AreEqual(1, config.GetFilterItems.Count, "There should be one filter item");
            Assert.AreEqual(0, config.GetFilterItems[0].GetNestedItems.Count, "There should be no nested filter item");
            Assert.AreEqual(SearchFilterDefinition.DataTypeIdentifier, config.GetFilterItems[0].GetIdentifier, "Filter type does not match");
            Assert.AreEqual(value, config.GetFilterItems[0].GetValue, "Filter value does not match");
            Assert.IsFalse(config.GetFilterItems[0].IsExactMatch, "Exact match is not false");
        }

        /// <summary>
        ///A test for FilterConfig.ToString
        /// verify the ToString can handle nested filter items also
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_SearchFilterConfig_ToString_Success()
        {
            //ARRANGE
            string type = "dt:";
            string value = "DINT";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));

            bool success = target.AddFilter(type, value, false, SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(success, "Filter was not added.");
          
            SearchFilterConfig config = target.GetFilterConfig();

            //ACT
            string output1 = config.ToString();

            //ASSERT
            Assert.IsTrue(output1.Contains("Identifier") && output1.Contains("AlternateIdentifier") 
                && output1.Contains("Value") && output1.Contains("IsExactMatch") && output1.Contains("IsIdentifierColumnConfigKey") && output1.Contains("GetLogicOperator"));          

        }

		/// <summary>
		///A test for GetFilterConfig
		///</summary>
		[TestMethod()]
		public void SearchFilterDefinition_GetFilterConfigTestExact()
		{
			string type = "dt:";
			string value = "clearMe";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

			bool success = target.AddFilter(type, value, true, SearchFilterDefinition.StatementLogic.AND);
			Assert.IsTrue(success, "Filter was not added.");
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");
			Assert.IsTrue(target.IsActive);
			Assert.IsTrue(target.HasNonEmptySearchValue);
			Assert.IsFalse(target.HasError);

			SearchFilterConfig config = target.GetFilterConfig();
            Assert.AreEqual(1, config.GetFilterItems.Count, "There should be one filter item");
            Assert.AreEqual(0, config.GetFilterItems[0].GetNestedItems.Count, "There should be no nested filter items");
            Assert.AreEqual(DIBConstants.Common.DataType, config.GetFilterItems[0].GetIdentifier, "Filter type does not match");
            Assert.AreEqual(value, config.GetFilterItems[0].GetValue, "Filter value does not match");
            Assert.IsTrue(config.GetFilterItems[0].IsExactMatch, "Exact match is not true");
		}

		/// <summary>
		///A test for GetFilterConfig
		///</summary>
		[TestMethod()]
		public void SearchFilterDefinition_GetFilterConfigTestArray()
		{
			string type = "dt:";
			string value = "clearMe[0]";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

			bool success = target.AddFilter(type, value, false, SearchFilterDefinition.StatementLogic.AND);
			Assert.IsTrue(success, "Filter was not added.");
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");
			Assert.IsTrue(target.IsActive);
			Assert.IsTrue(target.HasNonEmptySearchValue);
			Assert.IsFalse(target.HasError);

			SearchFilterConfig config = target.GetFilterConfig();
            Assert.AreEqual(1, config.GetFilterItems.Count, "There should be one fitler item");
            Assert.AreEqual(0, config.GetFilterItems[0].GetNestedItems.Count, "There should be no nested items");
            Assert.AreEqual(DIBConstants.Common.DataType, config.GetFilterItems[0].GetIdentifier, "Filter type does not match");
            Assert.AreEqual(value, config.GetFilterItems[0].GetValue, "Filter value does not match");
            Assert.IsFalse(config.GetFilterItems[0].IsExactMatch, "Exact match is not false");
		}

        /// <summary>
        ///A test for GetSearchString
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_GetSearchStringTest()
        {
            string type = "dt:";
            string value = "clearMe";
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            bool success = target.AddFilter(type, value, true, SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(success, "Filter was not added.");
            Assert.AreEqual(1, ((IList)targetPrivate.GetFieldOrProperty("_searchFilterStatements")).Count, "There should be one statement");
            Assert.IsTrue(target.IsActive, "Search should be active");
            string search = target.SearchString;
            Assert.AreEqual(search, "dt:\"clearMe\"", "Search text does not match");
           
        }

        /// <summary>
        ///A test for ReportErrorState
        ///</summary>
        [TestMethod()]
        public void SearchFilterDefinition_ReportErrorStateTest()
        {
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));
            PrivateObject targetPrivate = new PrivateObject(target);

            string value = "IamWrong";
            ParserToken errorToken = new ParserToken("ValueGroup", value, 3, false);
            target.ReportErrorState(true, errorToken);
            Assert.IsFalse(target.IsActive);
            Assert.IsFalse(target.HasNonEmptySearchValue);
            Assert.IsTrue(target.HasError);
            Assert.AreEqual(target.ErrorToken.Value, value, "Error value is wrong");
            Assert.AreEqual(SearchFilterDefinition.FilterSearchStateEnum.AlwaysSucceed, (SearchFilterDefinition.FilterSearchStateEnum)targetPrivate.GetFieldOrProperty("FilterSearchState"));
        }

        /// <summary>
        ///A test for FilterTypes
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterDefinition_FilterTypesTest()
        {
            SearchFilterDefinition target = new SearchFilterDefinition(DIBClientManagerForViewe.GetFilterTypes(true));

            ObservableCollection<FilterType> expectedResults = DIBClientManagerForViewe.GetFilterTypes(true);
            int i=0;
            foreach (FilterType ft in SearchFilterDefinition.FilterTypes)
            {
                Assert.AreEqual(expectedResults[i++].DisplayName,ft.DisplayName);
            }
        }

       

    
    }
}
