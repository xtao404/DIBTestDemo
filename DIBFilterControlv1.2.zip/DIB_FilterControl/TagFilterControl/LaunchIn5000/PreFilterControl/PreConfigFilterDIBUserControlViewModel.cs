﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Common;
using TagFilterControl.Common.Controls;
using TagFilterControl.Controls;
using TagFilterControl.Controls.PreFilterManager.Common;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Service;

namespace TagFilterControl.LaunchIn5000.PreFilterControl
{
    public class PreConfigFilterDIBUserControlViewModel : BaseViewModel
    {
        private Config config = Config.GetInstance();

        public PreConfigFilterDIBUserControlViewModel(FilterProfile profile)
        {
            if (profile != null)
            {
                this.PageTitle = "FilterManager>Edit";
                this.profile = profile;
                this.Name = string.IsNullOrEmpty(this.profile.Name) ? "" : this.profile.Name.Trim();
                this.action = OperationAction.Update;
                this.SetFilterData(profile);
                this.SetFilterDataAction.Execute();
                this.SetFilterDataAction = null;
            }
            else
            {
                this.PageTitle = "FilterManager>Create";
            }

            config.SaveCommandAction = () =>
            {
                this.SaveCommand.Execute(null);
            };
        }

        private Action SetFilterDataAction;

        private void SetFilterData(FilterProfile profile)
        {
            SetFilterDataAction = () =>
            {
                var replySource = FilterModuleUtil.ConvertProfileContentToFilterFoundation(profile);
                this.ReplayItemsSource = replySource;
                InitItem();
            };
        }

        public FilterPolicyCommonModel FilterModuleUtil
        {
            get
            {
                return FilterPolicyManager.GetDestFilterUtil();
            }
        }

        public ConditionFilterBaseModel _ConditionFilterBaseModel
        {
            get;
            set;
        }

        private ObservableCollection<object> mAndOrItemsSource = new ObservableCollection<object>()
            {
                new conAndOrItemBase(){ DisplayValue= "And", AndOrType=AndOr.And},
                new conAndOrItemBase(){ DisplayValue="Or", AndOrType=AndOr.Or}
            };

        private int OrderIndex = 0;
        private ConditionFilterBaseModel addNewItem;

        private bool isValidation = false;
        public bool IsValidation
        {
            get { return isValidation; }
            set { isValidation = value; }
        }

        private void Valid()
        {
            if (ValuesExistError())
            {
                this.IsValidation = true;
            }
            else
            {
                this.IsValidation = false;

                ConditionFilterBaseModel model = FilterModuleUtil.GetNewFilterData(this.filterItemsSource);
                if (model != null && model.ConditionFilterBase != null && model.ConditionFilterBase.Value != null)
                {
                    model.ConditionFilterBase.Value = new ValueItemForDisplay(model.ConditionFilterBase.Value);
                }
                this._ConditionFilterBaseModel = addNewItem = model;
            }
        }

        bool ValuesExistError()
        {
            foreach (var filter in this.FilterItemsSource)
            {
                if (!ValueIsValid(filter))
                {
                    return true;
                }
            }

            return false;
        }

        private string ERROR_MSG = "Please input a value";
        private string ERROR_NMSG = "Please input a name";
        bool ValueIsValid(ConditionFilterBaseModel filter)
        {
            if (filter == null || filter.ConditionFilterBase == null || filter.ConditionFilterBase.Value == null)
            {
                return false;
            }

            FilterRuleType rule = GetRuleType(filter.ConditionFilterBase.Rule);
            ValueItemForDisplay item = filter.ConditionFilterBase.Value as ValueItemForDisplay;
            if (item == null)
            {
                return false;
            }

            if (rule != FilterRuleType.TagName)
            {
                if (string.IsNullOrEmpty(item.RangeType.ToString().Trim()))
                {
                    item.HasError = true;
                    item.ErrorMsg = ERROR_MSG;
                    return false;
                }
            }
            else if (!item.HasDisplayValue || string.IsNullOrEmpty(item.DisplayValue.Trim()))
            {
                item.HasError = true;
                item.ErrorMsg = ERROR_MSG;
                return false;
            }
            return true;
        }

        FilterConditionType GetConditionType(object condition)
        {
            ConditionItemForDisplay item = condition as ConditionItemForDisplay;
            if (item != null)
            {
                return item.ConConditionType;
            }

            return FilterConditionType.None;
        }

        FilterRuleType GetRuleType(object rule)
        {
            RuleItemForDisplay item = rule as RuleItemForDisplay;
            if (item != null)
            {
                return (FilterRuleType)item.FilterRuleType;
            }

            return FilterRuleType.Unknown;
        }

        private OperationAction action = OperationAction.CreateNew;
        private FilterProfile profile;

        private CustomCommand saveCommand;
        public CustomCommand SaveCommand
        {
            get
            {
                return this.saveCommand ?? (this.saveCommand = new CustomCommand(() =>
                    {
                        config.ValidFlag = true;
                        if (string.IsNullOrEmpty(this.Name))
                        {
                            this.InValidInfo = ERROR_NMSG;
                            config.ValidFlag = false;
                            return;
                        }
                        if (ValidFilterData())
                        {
                            var filterProfile = this.FilterProfile;

                            var dto = new FilterProfile
                            {
                                Name = this.Name,
                                ID = this.profile == null ? Guid.NewGuid().ToString() : this.profile.ID,
                                Content = filterProfile.Content,
                                OperationActionType = this.action,
                                FilterContent = filterProfile.FilterContent
                            };

                            ServiceInvoker<ITagService>
                           .Invoke(s => s.SaveFilterInfo(dto, this.action))
                           .Callback(result =>
                           {
                               config.ConvertDIBManagerPageAction();
                           })
                           .Finally(() => { })
                           .Execute();
                        }
                        else
                            config.ValidFlag = false;
                    }));
            }
        }

        private CustomCommand addItemCommand;
        public CustomCommand AddItemCommand
        {
            get
            {
                return addItemCommand ?? (this.addItemCommand = new CustomCommand(() =>
                {
                    Valid();

                    if (!IsValidation)
                    {
                        OrderIndex++;
                        int OrderTemp = 0;
                        if (this.FilterItemsSource.Count > 0)
                        {
                            if (OrderTemp != 0)
                            {
                                _ConditionFilterBaseModel.Order = OrderTemp;
                                this.FilterItemsSource.Insert(OrderTemp - 1, _ConditionFilterBaseModel);
                            }
                            else
                            {
                                _ConditionFilterBaseModel.Order = OrderIndex;
                                this.FilterItemsSource.Insert(OrderIndex - 1, _ConditionFilterBaseModel);
                            }
                            if (OrderTemp != OrderIndex)
                            {
                                foreach (ConditionFilterBaseModel aa in this.FilterItemsSource)
                                {
                                    if (_ConditionFilterBaseModel != aa && OrderTemp != 0 && aa.Order >= OrderTemp)
                                    {
                                        aa.Order = aa.Order + 1;
                                    }
                                }
                            }

                            ObservableCollection<int> OrderItemsSourceTemp;
                            foreach (ConditionFilterBaseModel temp in this.FilterItemsSource)
                            {
                                OrderItemsSourceTemp = new ObservableCollection<int>();
                                temp.OrderItemsSource = OrderItemsSourceTemp;
                            }
                        }
                        else
                        {
                            _ConditionFilterBaseModel.Order = OrderIndex;
                            _ConditionFilterBaseModel.OrderItemsSource = new ObservableCollection<int>();
                            _ConditionFilterBaseModel.OrderItemsSource.Add(_ConditionFilterBaseModel.Order);
                            this.FilterItemsSource.Add(_ConditionFilterBaseModel);
                        }
                        this.FilterItemsSource.Last().ConditionFilterBase.IsCheckedChanged += (@checked) =>
                        {
                            this.RaiseIsCheckedAll(!@checked);
                        };
                        _ConditionFilterBaseModel.ConditionFilterBase.AndOrValueItemsSource = mAndOrItemsSource;
                        _ConditionFilterBaseModel.ConditionFilterBase.AndOrValue = mAndOrItemsSource[0];
                        InitItem();
                    }
                }));
            }
        }

        private CustomCommand deleteItemCommand;
        public CustomCommand DeleteItemCommand
        {
            get
            {
                return this.deleteItemCommand ?? (this.deleteItemCommand = new CustomCommand(() =>
                {
                    try
                    {
                        ConditionFilterBaseModel selectItem = this.CurrentSelectItem;
                        if (selectItem == null)
                        {
                            selectItem = this.FilterItemsSource.FirstOrDefault();
                        }

                        this.FilterItemsSource.Remove(selectItem);

                        foreach (ConditionFilterBaseModel temp in this.FilterItemsSource)
                        {
                            if (temp.Order > selectItem.Order)
                            {
                                temp.Order = temp.Order - 1;
                            }
                        }
                        OrderIndex--;
                        foreach (ConditionFilterBaseModel temp in this.FilterItemsSource)
                        {
                            temp.OrderItemsSource.Clear();
                        }
                        InitItem();
                    }
                    catch (Exception)
                    {
                    }
                }));
            }
        }

        public bool ValidFilterData()
        {
            bool valid = true;
            foreach (var item in this.FilterItemsSource)
            {
                if (!ValueIsValid(item))
                {
                    valid = false;
                    break;
                }
            }
            return valid;
        }

        public FilterProfile FilterProfile
        {
            get
            {
                var dto = new FilterProfile();
                this.FilterModuleUtil.ConvertConditionFilterToProfile(this.FilterItemsSource, ref dto);
                return dto;
            }
        }

        private void InitItem()
        {
            var items = this.FilterItemsSource;
            if (items != null)
            {
                for (int c = 0; c < items.Count; c++)
                {
                    var filterRule = (ConditionFilterBaseModel)items[c];
                    if (c == items.Count - 1)
                    {
                        filterRule.ConditionFilterBase.AndOrValue = new conAndOrItemBase()
                        {
                            AndOrType = AndOr.None,
                            DisplayValue = string.Empty
                        };
                    }
                    else
                    {
                        var lastItemAndOrValue = filterRule.ConditionFilterBase.AndOrValue as IAndOrItemBase;
                        if (lastItemAndOrValue.AndOrType == AndOr.None || string.IsNullOrEmpty(lastItemAndOrValue.DisplayValue))
                        {
                            filterRule.ConditionFilterBase.AndOrValue = mAndOrItemsSource[0];
                        }
                    }
                }
            }
        }

        private string pageTitle;
        public string PageTitle
        {
            get { return this.pageTitle; }
            set
            {
                this.pageTitle = value;
                this.RaisePropertyChangedEvent(() => this.PageTitle);
            }
        }

        private string inValidInfo;
        public string InValidInfo
        {
            get { return this.inValidInfo; }
            set
            {
                this.inValidInfo = value;
                this.RaisePropertyChangedEvent(() => this.InValidInfo);
            }
        }

        private string name;
        public string Name
        {
            get { return this.name; }
            set
            {
                this.name = value;
                this.RaisePropertyChangedEvent(() => this.Name);
            }
        }

        private bool isCheckedAll;
        public bool IsCheckedAll
        {
            get { return this.isCheckedAll; }
            set
            {
                this.isCheckedAll = value;
                foreach (var item in this.FilterItemsSource)
                {
                    item.ConditionFilterBase.IsChecked = value;
                }
                this.RaisePropertyChangedEvent(() => this.IsCheckedAll);
            }
        }

        protected void RaiseIsCheckedAll(bool uncheck)
        {
            if (uncheck)
            {
                this.isCheckedAll = false;
            }
            else
            {
                this.isCheckedAll = this.FilterItemsSource.All(i => i.ConditionFilterBase.IsChecked);
            }
            this.RaisePropertyChangedEvent(() => IsCheckedAll);
        }

        protected void RegisterItemCheckEvent()
        {
            foreach (var item in this.FilterItemsSource)
            {
                item.ConditionFilterBase.IsCheckedChanged += (@checked) =>
                {
                    this.RaiseIsCheckedAll(!@checked);
                };
            }
        }

        private ObservableCollection<ConditionFilterBaseModel> filterItemsSource = new ObservableCollection<ConditionFilterBaseModel>();
        public ObservableCollection<ConditionFilterBaseModel> FilterItemsSource
        {
            get { return this.filterItemsSource; }
            set
            {
                this.filterItemsSource = value;
                this.RaisePropertyChangedEvent(() => this.FilterItemsSource);
            }
        }

        private ObservableCollection<ConditionFilterBaseModel> _replayItemsSource = new ObservableCollection<ConditionFilterBaseModel>();
        public ObservableCollection<ConditionFilterBaseModel> ReplayItemsSource
        {
            get
            {
                _replayItemsSource.Clear();
                foreach (ConditionFilterBaseModel item in this.FilterItemsSource)
                {
                    _replayItemsSource.Add(item);
                }
                return _replayItemsSource;
            }
            set
            {
                _replayItemsSource = value;
                OrderIndex = 0;
                foreach (var item in _replayItemsSource)
                {
                    OrderIndex = item.Order;
                    this.FilterItemsSource.Add(item);
                }
            }
        }

        private ConditionFilterBaseModel currentSelectItem;
        public ConditionFilterBaseModel CurrentSelectItem
        {
            get { return this.currentSelectItem; }
            set
            {
                this.currentSelectItem = value;
                this.RaisePropertyChangedEvent(() => this.CurrentSelectItem);
            }
        }
    }
}
