﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query;

namespace RockwellAutomation.UI.DIBQuery
{
    class DIBQueryCommandForModuleDataTypes : DIBQueryCommandForViewe
    {

        #region "Creation/Init"

        public DIBQueryCommandForModuleDataTypes(QueryRequest.CreateBuilder queryRequestBuilder)
            : base(queryRequestBuilder) { }
 
        #endregion

        #region "Base Overides"
        
        public override PredefinedQueryType QueryType()
        {
            return PredefinedQueryType.Module_DataTypes;
        }

        #endregion
    }
}
