﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query.AbstractItem;


namespace RockwellAutomation.UI
{

    /// <summary>
    /// Controller PathElement
    /// </summary>
    public class HMIDevicePathElement : ActiveContrainerWithChildrenPathElement
    {
       
        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public HMIDevicePathElement(DataItemBase dataItem, string displayName)
                :base(dataItem, displayName)
        {
        }

        #endregion

    }

}
