﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace RockwellAutomation.UI.CommonControls.Models
{
   public class MruListObservableCollection : ObservableCollection<string>
    {
       /// <summary>
       /// base constructor
       /// </summary>
       public MruListObservableCollection() { }

      
       //only allow there to be 10 mru items in the list
       private const int _maxSize = 10;
       /// <summary>
       /// override the Add method, so we can add items that an mru list would want
       ///    limit the number of items
       ///    add the latest item at the front of the collection
       ///    do not allow for duplicate entries
       /// </summary>
       /// <param name="mruItem"></param>
       public new void Add(string mruItem)
       {
           //do not add an empty string
           if (mruItem.Trim().Length == 0)
               return;
           //see if this item already exists
           int i = FindMruItem(mruItem.Trim());
           //already first in the list then nothing to do
           if (i == 0)
               return;
            //if it does exist then remove it
           if (i > 0)
           {
               //remomve it, we will add it back 
               this.RemoveAt(i);
           }

           //limit the number of items to maxSize
           if (this.Count >= _maxSize)
               this.RemoveAt(_maxSize - 1);
           //add the MRU item to the front of the list
           this.Insert(0, mruItem.Trim());
       }
       /// <summary>
       /// finds the mru item index
       /// </summary>
       /// <param name="mruItem">the mru item we want to find</param>
       /// <returns></returns>
       private int FindMruItem(string mruItem)
       {
			//Make sure we convert 'OR' and 'AND' into tokens or otherwise
			// they would be converted to lowercase in the comparison and
			// may match with an 'or' or 'and' that was part of an actual
			// search string
			mruItem = mruItem.Replace(" OR ", "|").Replace(" AND ", "&");
			for (int i = 0; i < this.Count(); i++)
			{
				//does this match, not case sensitive
				string CurItem = this[i].Replace(" OR ", "|").Replace(" AND ", "&");
				if (CurItem.ToLower().Equals(mruItem.ToLower()))
					return i;
			}
			//didn't find it
			return -1;
       }
    }
}
