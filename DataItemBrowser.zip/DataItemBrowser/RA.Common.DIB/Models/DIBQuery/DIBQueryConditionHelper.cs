﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.UI.CommonControls;

namespace RockwellAutomation.UI.DIBQuery
{ 
    /// <summary>
    /// Builds Query Conditions to be processed by QSP. This class is used by CDS
    /// </summary>
    public static class DIBQueryConditionHelper
    {        

        /// <summary>
        /// Convert from a SearchFilterItem to a QueryConditionItem. These classes contain similar members and methods.
        /// </summary>
        /// <param name="filterItem">SearchFilterItem to convert</param>
        /// <returns>QueryConditionItem</returns>
        public static QueryConditionItem BuildQueryConditionItemFor(SearchFilterItem filterItem)
        {
            LogicOperatorType logicOperator = (filterItem.GetLogicOperator == SearchFilterDefinition.StatementLogic.OR
                                          ? LogicOperatorType.OR
                                          : LogicOperatorType.AND);
            QueryConditionItem.CreateBuilder currentConditionItem = new QueryConditionItem.CreateBuilder()
                .SetIdentifier(filterItem.GetIdentifier)
                .SetAlternateIdentifier(filterItem.GetAlternateIdentifier)
                .SetValue(filterItem.GetValue)
                .SetIsExactMatch(filterItem.IsExactMatch)
                .SetIsIdentifierColumnConfigKey(filterItem.IsIdentifierColumnConfigKey)
                .SetLogicOperator(logicOperator);
            foreach (SearchFilterItem nestedFilterItem in filterItem.GetNestedItems)
            {
                //Recursively call BuildQueryConditionItemFor is needed for nested items
                currentConditionItem.AddConditionItem(BuildQueryConditionItemFor(nestedFilterItem));
            }
            return currentConditionItem.Build();
        }
    }
    
}
