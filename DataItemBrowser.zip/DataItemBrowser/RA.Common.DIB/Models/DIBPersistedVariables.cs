﻿
namespace RockwellAutomation.UI.ViewModels
{
    ///
    /// This static class contains data that is persisted between invocations of the DIB.
    /// If the machine or the host application (i.e. DTC or PopUpTestHost) is shutdown then this information is no longer available.
    /// Stored in the Application space.
    /// 
    public static class DIBPersistedVariables
    {
        public static string TagBrowser_LastHighLightedItem = string.Empty;
        public static string DataTypeBrowser_LastHighLightedItem = string.Empty;

        public static ServiceFramework.DataTypes.UUID LastPackageContext = null;
        public static ServiceFramework.DataTypes.UUID LastProjectContext = null;

    }
}
