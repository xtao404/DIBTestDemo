﻿/* ****************************************************************************
*
*  Copyright 2015 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using RockwellAutomation.UI.Models;
using System.Collections.ObjectModel;

namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Interaction logic for BreadCrumbsGrid.xaml
    /// </summary>
    public class BreadCrumbsGrid : Grid
    {
        /// <summary>
        /// The width available to this control
        /// </summary>
        public object AvailableWidth
        {
            get { return (object)GetValue(AvailableWidthProperty); }
            set { SetValue(AvailableWidthProperty, value); }
        }

        /// <summary>
        /// The width available to this control (DependencyProperty)
        /// </summary>
        public static readonly DependencyProperty AvailableWidthProperty =
            DependencyProperty.Register("AvailableWidth", typeof(object), typeof(BreadCrumbsGrid), new UIPropertyMetadata(null));

        private double _MinCrumbWidth = 0;
        private Dictionary<string, object> _CachedFontInfo = new Dictionary<string, object>();

        private double _LastSizingWindowWidth = 0;

        /// <summary>
        /// Constructor
        /// </summary>
        public BreadCrumbsGrid()
        {
            // Fill in defaults for the cached font information
            TextBlock NewTextBlock = new TextBlock();
            _CachedFontInfo["FontFamily"] = NewTextBlock.FontFamily;
            _CachedFontInfo["FontStyle"] = NewTextBlock.FontStyle;
            _CachedFontInfo["FontWeight"] = NewTextBlock.FontWeight;
            _CachedFontInfo["FontStretch"] = NewTextBlock.FontStretch;
            _CachedFontInfo["FontSize"] = NewTextBlock.FontSize;
        }

        private ObservableCollection<DropArrowItem> _backwardCrumbsMenuChildren = new ObservableCollection<DropArrowItem>();
        
        /// <summary>
        /// Left overflow menu crumb children collection
        /// </summary>
        public ObservableCollection<DropArrowItem> BackwardCrumbsMenuChildren
        {
            get { return _backwardCrumbsMenuChildren; }
            internal set
            {
                _backwardCrumbsMenuChildren = value;
            }
        }

        /// <summary>
        /// Updates the display of the breadcrumbs based on the window width
        /// </summary>
        /// <param name="displayContentChanged">True if the display content has changed</param>
        public void UpdateCrumbSizing(bool displayContentChanged)
        {           
            // If AvailableWidth has not been set yet, it is too early in the loading
            // process to perform the crumb sizing so return immediately.
            if (AvailableWidth == null)
            {
                return;
            }

            double availWidth = (double)AvailableWidth;

            if (!displayContentChanged &&
                availWidth == _LastSizingWindowWidth)
            {
                // If the display data has not changed and the available
                // width is the same as the last time we calculated sizes
                // we need to exit to avoid an infinite resize loop
                // when SizeToContent is in effect
                return;
            }

            HomeCrumb homeCrumb = null;
            LMenuCrumb lMenuCrumb = null;
            SearchCrumb searchCrumb = null;

            // First, determine the width that would be needed to display all the crumbs				
            double neededWidth = CalculateNeededWidth(ref homeCrumb, ref lMenuCrumb, ref searchCrumb);

            // Determine if we need to shrink / overflow any crumbs
            double amountOver = neededWidth - availWidth;

            BackwardCrumbsMenuChildren.Clear();
            if (homeCrumb != null)
                homeCrumb.BeforeLeftOverflowCrumbs = false;
            if (lMenuCrumb != null)
                lMenuCrumb.HasChildren = false;

            if (amountOver <= 0)
            {
                return;
            }

            int CurIndex = 0;
            foreach (UIElement CurElement in Children)
            {
                if (CurElement == null)
                    continue;

                ACrumb crumb = (CurElement as FrameworkElement).DataContext as ACrumb;

                TextCrumb textCrumb = crumb as TextCrumb;
                if (textCrumb != null && textCrumb.IsActive)
                {
                    ColumnDefinition CurColDef = ColumnDefinitions[CurIndex];

                    // If the crumb we're looking at in this loop iteration
                    // is wider than the amount we are over, shrinking it will
                    // be enough to fit all the crumbs in the window
                    if (CurColDef.ActualWidth - _MinCrumbWidth > amountOver)
                    {                        
                        CurColDef.Width = new GridLength(1, GridUnitType.Star);
                        break;
                    }
                    // Otherwise we need to hide it entirely and mark it be
                    // added to the left overflow menu
                    else
                    {
                        if (lMenuCrumb != null)
                            lMenuCrumb.HasChildren = true;

                        if (homeCrumb != null)
                            homeCrumb.BeforeLeftOverflowCrumbs = true;

                        amountOver -= CurColDef.ActualWidth;
                        CurElement.Visibility = Visibility.Collapsed;

                        DropArrowItem NewDropItem = new DropArrowItem();
                        NewDropItem.DisplayName = textCrumb.DisplayName;
                        NewDropItem.IsContainer = textCrumb.IsContainer;
                        NewDropItem.HostCrumb = textCrumb;
                        NewDropItem.IsBold = false;

                        BackwardCrumbsMenuChildren.Insert(0, NewDropItem);
                    }
                }

                CurIndex += 1;
            }

            _LastSizingWindowWidth = availWidth;
        }

        /// <summary>
        /// Helper to determine the needed width to display all crumbs
        /// </summary>
        /// <param name="homeCrumb">HomeCrumb ref to be set by this method once HomeCrumb
        /// is found while iterating through the crumbs</param>
        /// <param name="lMenuCrumb">LMenuCrumb ref to be set by this method once LMenuCrumb
        /// is found while iterating through the crumbs</param>
        /// <param name="searchCrumb">SearchCrumb ref to be set by this method once SearchCrumb
        /// is found while iterating through the crumbs</param>
        /// <returns>The width needed for all crumbs</returns>
        private double CalculateNeededWidth(ref HomeCrumb homeCrumb, ref LMenuCrumb lMenuCrumb, ref SearchCrumb searchCrumb)
        {
            double NeededWidth = 0;

            //If we don't have a minimum crumb width, compute it now
            if (_MinCrumbWidth == 0)
            {
                //Obtain the font that is currently in use by the crumbs of this grid
                Typeface typeface = new Typeface((FontFamily)_CachedFontInfo["FontFamily"],
                                                 (FontStyle)_CachedFontInfo["FontStyle"],
                                                 (FontWeight)_CachedFontInfo["FontWeight"],
                                                 (FontStretch)_CachedFontInfo["FontStretch"]);

                double fontSize = (double)_CachedFontInfo["FontSize"];

                //Get the size of the widest char ("W") plus an ellipsis ("...")
                FormattedText TestText = new FormattedText("W...",
                    System.Threading.Thread.CurrentThread.CurrentCulture,
                    FlowDirection.LeftToRight,
                    typeface,
                    fontSize,
                    Brushes.Black);

                //Store the minimum crumb width (which is the text computation above
                // plus the width of a path arrow)
                _MinCrumbWidth = TestText.Width + 13;
            }

            UpdateColumnDefs();
            //At one point it seemed we needed this to ensure ActualWidth was filled in
            // correctly but now it appears with the order of messages that come in, we
            // aways get a final update where we correctly compute the widths below.
            UpdateLayout();

            int CurIndex = 0;

            foreach (UIElement CurElement in Children)
            {
                if (CurElement == null)
                    continue;

                ACrumb crumb = (CurElement as FrameworkElement).DataContext as ACrumb;
                ColumnDefinition CurColDef = ColumnDefinitions[CurIndex];

                if (lMenuCrumb == null)
                    lMenuCrumb = crumb as LMenuCrumb;

                //Change text crumb to visible and auto sized to result in the widest
                // possible crumb trail
                TextCrumb textCrumb = crumb as TextCrumb;
                if (textCrumb != null)
                {
                    //Only include active since they are the only ones displayed
                    // (forward crumbs show up in a drop down)
                    if (textCrumb.IsActive)
                    {
                        CurElement.SetValue(FrameworkElement.VisibilityProperty, Visibility.Visible);

                        CurColDef.Width = new GridLength(1, GridUnitType.Auto);
                        UpdateLayout();

                        NeededWidth += CurColDef.ActualWidth;

                        CurElement.ClearValue(FrameworkElement.VisibilityProperty);
                    }
                }
                else
                {
                    //Add space for the home crumb
                    if (crumb as HomeCrumb != null)
                    {
                        homeCrumb = crumb as HomeCrumb;
                        NeededWidth += CurColDef.ActualWidth;
                    }
                    //Add space for the search crumb
                    else if (crumb as SearchCrumb != null)
                    {
                        searchCrumb = crumb as SearchCrumb;
                        NeededWidth += CurColDef.ActualWidth;
                    }
                    else
                    {
                        //Add space for a menu crumb (if it is visible)
                        MenuCrumb MenuCrumb = crumb as MenuCrumb;
                        if (MenuCrumb != null)
                        {
                            //Special case: If this is the left menu crumb and the window is
                            // growing and there is only one crumb in the overflow menu,
                            // don't add the space of the menu crumb since there may be enough
                            // room to display the crumb that has fallen into the overflow menu
                            bool IsLMenuCrumb = (crumb as LMenuCrumb != null);
                            bool IsWindowGrowing = _LastSizingWindowWidth < (double)AvailableWidth;
                            bool IsOneOverflow = BackwardCrumbsMenuChildren.Count == 1;
                            bool ExcludeMenuCrumb = IsLMenuCrumb && IsWindowGrowing && IsOneOverflow;
                            double ArrowDelta = ExcludeMenuCrumb ? (CurColDef.ActualWidth - 12) : 0;
                            NeededWidth += MenuCrumb.HasChildren ? (CurColDef.ActualWidth - ArrowDelta) : 0;
                        }
                    }
                }

                CurIndex += 1;
            }

            return NeededWidth;
        }

        /// <summary>
        /// Clears all column definitions and creates new ones based on the
        /// current children of this grid
        /// </summary>
        private void UpdateColumnDefs()
        {
            ColumnDefinitions.Clear();

            int CurIndex = 0;
            foreach (UIElement CurElement in Children)
            {
                if (CurElement == null)
                    continue;

                //Create a column definition for this crumb
                ColumnDefinition NewColDef = new ColumnDefinition();
                NewColDef.Width = new GridLength(1, GridUnitType.Auto);
                ColumnDefinitions.Add(NewColDef);

                //Set the column number for this crumb
                CurElement.SetValue(Grid.ColumnProperty, CurIndex);

                CurIndex += 1;
            }
        }

        /// <summary>
        /// Called by the framework in response to a property changing
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);

            //AvailableWidth is bound to the maximum width the client has allocated for this
            // grid to consume.  Update the crumb sizing when this changes.
            if (e.Property.Name == "AvailableWidth")
            {
                UpdateCrumbSizing(false);
            }
            //If anything font related changes, make sure we update the crumb sizing
            // as well as recompute the minimum width for the crumb
            else if (e.Property.Name == "FontFamily" ||
                    e.Property.Name == "FontStyle" ||
                    e.Property.Name == "FontWeight" ||
                    e.Property.Name == "FontStretch" ||
                    e.Property.Name == "FontSize")
            {
                _CachedFontInfo[e.Property.Name] = e.NewValue;
                _MinCrumbWidth = 0;
                UpdateCrumbSizing(true);
            }
        }
    }
}
