﻿using System.Configuration;

namespace RockwellAutomation.UI.UserConfiguration
{
    // Define the "Columns" section that contains a collection of "column
    public class ColumnsSection : ConfigurationSection
    {
        // Create a configuration section.
        public ColumnsSection()
        { }

        // Set or get the name of the ColumnsElement. 
        [ConfigurationProperty("Columns")]
        public ColumnsElementCollection ColumnsElement
        {
            get
            {
                return ((ColumnsElementCollection)this["Columns"]);
            }
           
        }
    }
}
