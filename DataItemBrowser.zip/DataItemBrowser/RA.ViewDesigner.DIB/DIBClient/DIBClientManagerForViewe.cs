﻿/* ****************************************************************************
*
*  Copyright 2016 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using RockwellAutomation.UI.ViewModels;
using System.Collections.Generic;
using RockwellAutomation.UI.Models;
using System.Reflection;
using RockwellAutomation.UI.Views;
using System.Text;
using System.Collections.ObjectModel;
using System;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;
using RockwellAutomation.CommonServices.TypeSchemas.Devices;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.Resources;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    public class DIBClientManagerForViewe : DIBClientManager
    {

        #region Singleton implementation

        private static DIBClientManagerForViewe _instance = null;
        /// <summary>
        /// Hold onto DIBClientManager as a singleton.
        /// </summary>
        public static DIBClientManagerForViewe Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, null, null);
                }
                return _instance;
            }
            set
            {
                if (_instance == value) return;
                _instance = value;
            }
        }
        #endregion

        #region viewe properties

        public ServiceFramework.DataTypes.UUID PackageContext { get; private set; }
        public ServiceFramework.DataTypes.UUID ProjectContext { get; private set; }

        // The interface we use to communicate with QSP. This static is persisted across DIB invocations
        private static IDIBQueryConnection _dibQueryConnection = null;

        
        /// <summary>
        /// Gets the Name of the AOG, returns an empty string if not using an AOG
        /// </summary>
        public string AOGScreenName { get; private set; }

        /// <summary>
        /// Gets the list of Aog Properties of the AOG, returns an empty list if not using an AOG
        /// </summary>
        public List<RockwellAutomation.UI.Models.DIBQuery.AOGItem> AOGItemList { get; private set; }

        private DIBViewItemBase.VisualPerspectiveEnum _browserPerspective;

        /// <summary>
        /// converts a string representing a browser perspective into a 
        /// <see cref="ViewModel.DIBTreeViewItem.VisualPerspectiveEnum"/> value
        /// </summary>
        /// <returns>VisualPerspectiveEnum value</returns>
        public DIBViewItemBase.VisualPerspectiveEnum BrowserPerspective
        {
            get {return _browserPerspective;}  
            set {_browserPerspective = value;}
        }

        /// <summary>
        /// Get if the DIB type is currently a AOG property browser
        /// </summary>
        /// <returns>true if AOG property browser, otherwise false</returns>
        public bool IsAOGPropertyBrowser()
        {
            return BrowserPerspective == DIBViewItemBase.VisualPerspectiveEnum.AOGPropertiesBrowser;
        }

        /// <summary>
        /// Get if the DIB is currently a tag type browser
        /// </summary>
        /// <returns>true if a tag browser, otherwise false</returns>
        public bool IsTagBrowser()
        {
            return BrowserPerspective == DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
        }

        #endregion

        #region SearchFilterControl

        /// <summary>
        /// Collection of values used for search filter control
        /// </summary>
        override public ObservableCollection<CommonControls.FilterType> GetFilterTypes()
        {
            return GetFilterTypes(this.IsTagBrowser());
        }
        
        /// <summary>
        /// Collection of values used for search filter control
        /// </summary>
        /// <param name="isTagBrowser">true if browsing tags</param>
        public static ObservableCollection<CommonControls.FilterType> GetFilterTypes(bool isTagBrowser)
        {
            ObservableCollection<CommonControls.FilterType> filterTypes = new ObservableCollection<CommonControls.FilterType>();
            filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.Name, true, false));
            //B-12775: don't show the data type filter for the Data Type Brower
            if (isTagBrowser)
            {
                filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.DataType, false, true));
            }
            else
            //We want the data type browser to be able to filter on Location
            {
                filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.Location, false, false));
            }
            filterTypes.Add(new CommonControls.FilterType(DIBConstants.Common.Description, true, false));
            return filterTypes;
        }

        /// <summary>
        /// Determine if a local or QSP search should be performed
        /// </summary>
        /// <param name="path">item to search for</param>
        /// <returns>true for QSP search, otherwise false</returns>
        public override bool ShouldSearchViaQuery(Path path)
        {
            //Determine if we should search via a query
            bool searchViaQuery = false;

            //If we are at home, we need to check what home is defined as
            if (path.ActiveElement is HomePathElement)
            {
                //If home is null, we are showing a device list
                if (path.ActiveElement.DataItem == null)
                {
                    searchViaQuery = true;
                }
                //If home is not null, we need to check the type of component
                else
                {
                    UUID itemType = path.ActiveElement.DataItem.GetResourceTypeAsUUID();
                    searchViaQuery = ResourceBase.IsEqual(itemType, TypeIdentifiers.getResourceType_Controller()) ||
                                     ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_HMIDevice);
                }
            }
            //If we're not at home...
            else
            {
                //Search is only done via query for devices (controller and HMI)
                searchViaQuery = path.ActiveElement is ControllerPathElement ||
                                 path.ActiveElement is HMIDevicePathElement;
            }
            return searchViaQuery;
        }


        #endregion

        #region Startup/Shutdown

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="browserType">Type of Browser (Tag or DataType)</param>
        public DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum browserType, UUID packageContext, UUID projectContext)
            : base()
        {
            if (AOGItemList != null)
            {
                AOGItemList.Clear();
            }
            this.AOGScreenName = string.Empty;
            this.BrowserPerspective = browserType;
            this.ProjectContext = projectContext;
            this.PackageContext = packageContext;
            CompositeDataItem.ProjectContextUUID = this.ProjectContext;
        }

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="browserType">browser prospective</param>
        /// <param name="packageContext"></param>
        /// <param name="projectContext"></param>
        /// <param name="AOGItemList">list of properties</param>
        /// <param name="AOGScreenName">screen name</param>
        public DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum browserType, UUID packageContext, UUID projectContext, List<Models.DIBQuery.AOGItem> AOGItemList, string AOGScreenName)
            : base()
        {
            DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem = string.Empty;
            DIBPersistedVariables.TagBrowser_LastHighLightedItem = string.Empty;

            this.BrowserPerspective = browserType;
            this.ProjectContext = projectContext;
            this.PackageContext = packageContext;
            CompositeDataItem.ProjectContextUUID = this.ProjectContext;
            this.AOGItemList = AOGItemList;
            this.AOGScreenName = AOGScreenName;
        }

        /// <summary>
        /// Perform any initialization work needed when the DIB control is being launched
        /// </summary>
        /// <param name="dataItemBrowserControl"></param>
        /// <param name="logger"></param>
        override public void InitializeDIBControlOnStartup(DataItemBrowser dataItemBrowserControl, StringBuilder logger)
        {
            //Set our singleton instance of ClientManagerForViewe
            DIBClientManagerForViewe.Instance = this;

            //Set or update any variables on Browser Control if needed before launching DIB Window
            if (dataItemBrowserControl != null)
            {
                if (this.BrowserPerspective == DIBViewItemBase.VisualPerspectiveEnum.AOGPropertiesBrowser)
                {
                    dataItemBrowserControl.BrowserType = DIResource.DI_COMMON_RESOURCETYPE_AOGS;
                    dataItemBrowserControl.CurrentScreenName = AOGScreenName;
                }
                else if (this.BrowserPerspective == DIBViewItemBase.VisualPerspectiveEnum.TagBrowser)
                {
                    dataItemBrowserControl.BrowserType = DIResource.DI_COMMON_RESOURCETYPE_TAG;
                    dataItemBrowserControl.CurrentScreenName = string.Empty;
                }
                else
                {
                    dataItemBrowserControl.BrowserType = DIResource.DI_COMMON_RESOURCETYPE_DATATYPE;
                    dataItemBrowserControl.CurrentScreenName = string.Empty;
                }
            }
            if (logger != null)
            {
                logger
                    .AppendLine("DIB Client Manager Type: DIBClientManagerForViewe")
                    .AppendLine("\t(BrowserType=" + DIBViewItemBase.VisualPerspectiveEnum.TagBrowser.ToString() + ")")
                    .AppendLine("\t(ProjectContext=" + (ProjectContext != null ? ("[hi:" + ProjectContext.Hi.ToString() + " lo:" + ProjectContext.Lo.ToString()) : "null") + "])")
                    .AppendLine("\t(PackageContext=" + (PackageContext != null ? ("[hi:" + PackageContext.Hi.ToString() + " lo:" + PackageContext.Lo.ToString()) : "null") + "])");
            }
            InitializeVieweSpecificClasses();
        }

        /// <summary>
        /// MRU (Most Recently Used) list history is the list of previous searches that have been performed on the DIB.
        /// When the DIB is relaunched without being cleared (That is call Close() instead of Shutdown()) the MRU list 
        /// is persisted by defualt between DIB invocations if this method returns a false value.
        /// </summary>
        override public bool ShouldClearMRUListHistoryOnStartup()
        {
            // Has the package / project changed.  If so clean out the last highlighted items / search MRU
            if (!ResourceBase.IsEqual(this.PackageContext, DIBPersistedVariables.LastPackageContext) &&
                !ResourceBase.IsEqual(this.ProjectContext, DIBPersistedVariables.LastProjectContext))
            {
                DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem = string.Empty;
                DIBPersistedVariables.TagBrowser_LastHighLightedItem = string.Empty;
                DIBPersistedVariables.LastPackageContext = this.PackageContext;
                DIBPersistedVariables.LastProjectContext = this.ProjectContext;
                return true;
            }
            return false;
        }

        /// <summary>
        /// Perform ViewE specific init
        /// </summary>
        public static void InitializeVieweSpecificClasses()
        {
            InitializeDeviceImagePresenter();
            PathElementFactory.SetInstance(new PathElementFactoryForViewe());
        }

        private static void InitializeDeviceImagePresenter()
        { 
            DeviceImagePresenter.SetReplicationStateValues(
                Enum_ReplicationStateType.UNINITIATED.ToString(),
                Enum_ReplicationStateType.EXTRACTING.ToString(),
                Enum_ReplicationStateType.SYNCHED.ToString(),
                Enum_ReplicationStateType.DETECTINGCHANGES.ToString(),
                Enum_ReplicationStateType.NEEDSUPDATING.ToString(),
                Enum_ReplicationStateType.UPDATING.ToString(),
                Enum_ReplicationStateType.SYNCHLOST.ToString(),
                Enum_ReplicationStateType.INDETERMINATE.ToString(),
                Enum_ReplicationStateType.RESYNCHRONIZING.ToString(),
                Enum_ReplicationStateType.EROA_UNINITIATED.ToString(),
                Enum_ReplicationStateType.EROA_DATA.ToString());
        }


        /// <summary>
        /// We can expect Close() to be called when a project is closed
        /// </summary>
        public override void Close()
        {
            base.Close();
            if (DIBClientManagerForViewe._dibQueryConnection == null) return;
            DIBClientManagerForViewe._dibQueryConnection.UnRegisterForEvents();
        }

        /// <summary>
        /// We can expect Shutdown() to be called when the Logix Designer is closed.
        /// The expected sequence of events is Close() and then Shutdown() but are not guaranteed that
        /// sequence so we clear the browser type during both events
        /// </summary>
        public override void Shutdown()
        {
            base.Shutdown();
            if (DIBClientManagerForViewe._dibQueryConnection == null) return;
            DIBClientManagerForViewe._dibQueryConnection.Shutdown();
        }

        /// <summary>
        /// This is code that runs during the creation of a GUI item that will be used to display data
        /// </summary>
        /// <param name="dataItem"></param>
        /// <param name="type"></param>
        /// <param name="visualBase"></param>
        public override void InitializeGUIViewItem(DataItemBase dataItem, VisualType type, DIBTreeViewItem visualBase)
        {
            if (dataItem == null) return;

            if (dataItem == DIResource.DIB_ModuleDefined ||
                    dataItem == DIResource.DIB_PreDefined ||
                    dataItem == DIResource.DIB_UserDefined)
            {
                // we don't need the replicationState for DTB types  
                visualBase.ReplicationState = DeviceImagePresenter.ReplicationStateType.INDETERMINATE;
                visualBase.ReplicationError = null;
            }
            else if (type == UI.VisualType.vtGenericType)
            {
                visualBase.ReplicationState = DeviceImagePresenter.ReplicationStateType.UNINITIATED;
                visualBase.ReplicationError = String.Empty;
            }
            else
            {
                visualBase.ReplicationState = DIBClientManagerForViewe.GetReplicationStateType(dataItem.GetVieweReplicationState());
                visualBase.ReplicationError = dataItem.GetVieweReplicationErrorMessage();
            }
        }

        /// <summary>
        /// Convert a string value into a DeviceImagePresenter.ReplicationStateType enumeration value
        /// </summary>
        /// <param name="state">The string to convert</param>
        private static DeviceImagePresenter.ReplicationStateType GetReplicationStateType(string state)
        {
            if (string.IsNullOrEmpty(state) || state.Equals("cannot resolve field [ReplicationState] in the resource."))
            {
                LogWrapper.LogException("Replication State is empty or cannot be determined.", new Exception("State = " + state));
                return DeviceImagePresenter.ReplicationStateType.INDETERMINATE;
            }

            return DeviceImagePresenter.ReplicationStateType.FromString(state);
        }

        #endregion

        #region Overrides

        /// <summary>
        /// Ready for drill-in requests
        /// </summary>
        override public bool IsReadyForNavigationRequests()
        {
            return this.QueryConnection.isQueryInitialized();
        }

        /// <summary>
        /// Is the DIB a generic or ViewE DIB
        /// </summary>
        override public bool IsGenericDIBBrowser()
        {
            return false;
        }

        /// <summary>
        /// Convert a Path (a List of DataItemBase instances) to a string.
        /// </summary>
        /// <param name="fullPath">list of DataItemBase items</param>
        /// <param name="nameToSelect">Item to select</param>
        /// <param name="browserPerspective">perspective</param>
        override public string PathToString(List<IPathElement> fullPath, string nameToSelect, DIBViewItemBase.VisualPerspectiveEnum browserPerspective)
        {
            return Path.PathToString(fullPath, nameToSelect, browserPerspective);
        }

        /// <summary>
        /// Get the stream with what columns to show in the grid view
        /// </summary>
        override public System.IO.Stream GetGridColumnMetaData()
        {
            System.IO.Stream xmlStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("RA.ViewDesigner.DIB.ColumnsInfo.xml");
            return xmlStream;
        }

        /// <summary>
        /// Retrieve a unique string from the provided DataItemBase that represents a cache key we use
        /// to store breadcrumb history. The returned string is used to allow breadcrumbs to show alternate values for 
        /// previous levels of drill ins. 
        /// </summary>
        /// <param name="dataItem"></param>
        /// <returns></returns>
        override public string GetBreadCrumbCacheKeyFor(DataItemBase dataItem)
        {
            return GetResourceTypeString(dataItem);
        }

        /// <summary>
        /// What column(s) to use for the current view.
        /// </summary>
        /// <param name="dataItem"></param>
        override public string GetResourceTypeString(DataItemBase dataItem)
        {
            return DIResource.GetResourceTypeString(dataItem, IsTagBrowser());
        }

        /// <summary>
        /// Determine the DataView member based on the passed resource type (representing the "parent"
        /// component being displayed in the current browser view)
        /// </summary>
        /// <param name="resourceType"></param>
        /// <returns></returns>
        override public IDIBDataViewType GetDataViewTypeFor(string resourceType)
        {
            if (resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER))
                return new DIBDataViewTypeController();
            else if (resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE))
                return new DIBDataViewTypeHMIDevice();
            else if (resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS))
                return new DIBDataViewTypeProgramsGrid();
            else if (resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_DATALOGS))
                return new DIBDataViewTypeDataLogsGrid();
            else if (resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_PROGRAM) ||
                resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_DATALOG) ||
                resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_SCREENS) ||
                resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_TAG) ||
                resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGS) ||
                resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_AOGS) ||
                resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_DATATYPEMEMBER))
                return new DIBDataViewTypeDataGrid();
            else if (resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_DATATYPE))
                return new DIBDataViewTypeDataType();
            else if (resourceType.Equals(ClientDataServices.SearchTags))
                return new DIBDataViewTypeSearchGrid();
            else if (resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_WEB))
                return new DIBDataViewTypeWebView();
            else
                return new DIBDataViewTypeTreeView();
        }

        /// <summary>
        /// Overide normal command creation and use a custom command. 
        /// This gives DIBCLientManagerForViewe more flexibiliy during command execution
        /// </summary>
        /// <param name="queryBuilder"></param>
        /// <param name="isDIBSearching"></param>
        /// <returns></returns>
        override public IDIBQueryCommand createQueryCommandFor(QueryRequest.CreateBuilder queryBuilder, bool isDIBSearching = false)       
        {
            return DIBQueryCommandForViewe.CreateFor(queryBuilder, isDIBSearching);
        }

        /// <summary>
        /// Stud Method DrillInFor
        /// </summary>
        /// <param name="dataItemToDrillInto"></param>
        /// <param name="queryCache"></param>
        override public void DrillInFor(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            //Do nothing
            //Since we create our own custom instance of QueryCommand, this method will not be called 
        }

        #endregion

        #region ViewModel Creation

        /// <summary>
        /// Create the viewe specific Devices View model as our List View Model
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        override public DIBListViewModel createDIBListViewModel(DataItemBrowserViewModel dibVM)
        {
            return new VieweDevicesListViewModel(dibVM);
        }

        /// <summary>
        /// Create the viewe specific DataSources Vide Model as our Tree View Model
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        override public DIBTreeViewModel createDIBTreeViewModel(DataItemBrowserViewModel dibVM)
        {
            return new VieweDataSourcesTreeViewModel(dibVM);
        }

        /// <summary>
        /// Create the viewe specific DIB Grid View model as our Grid View Model
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        override public DIBGridViewModel createDIBGridViewModel(DataItemBrowserViewModel dibVM)
        {
            return new VieweTagGridViewModel(dibVM);
        }


        #endregion

        #region DIBQueryConnection

        /// <summary>
        /// QSP and OSGI Query Connection property
        /// </summary>
        public IDIBQueryConnection QueryConnection
        {
            get { return DIBClientManagerForViewe._dibQueryConnection; }
            set { DIBClientManagerForViewe._dibQueryConnection = value; }
        }

        /// <summary>
        /// Init the QSP and OSGI query processing connection
        /// </summary>
        public override bool InitializeDIBQueryConnection(IClientDataServices cds, ref String initializeErrorString, bool IsReinit)
        {
            if (this.QueryConnection == null)
            {
                this.QueryConnection = new DIBQueryConnection();
            }

            this.QueryConnection.SetPackageAndProjectContext(this.PackageContext, this.ProjectContext);

            if (!this.QueryConnection.HasValidPackageAndProjectContext())
            {
                //Without valid context GUIDs, we won't be able to load data, so simply check and return in this case
                LogWrapper.DibStartUpLog.Error(" DataItemBrowserViewModel.Initialize Error: no package/project context provided");
                string problemText = cds.SetProblemInfo(ProblemInfoType.InvalidContextGuid);
                initializeErrorString = problemText;
                return false;
            }
            //Create and initialize a query so we can talk to data via the query service provider
            try
            {
                _dibQueryConnection.CreateConnection();
            }
            catch (Exception e)
            {
                LogWrapper.LogException(MethodBase.GetCurrentMethod().ToString(), e);
                initializeErrorString = this.QueryConnection.ProcessExceptionErrorResponse(e, cds);
            }
            finally
            {
                //We expose this as a way to simulate an error so GUI can be tested (there is a strong need
                // for consistency standpoint that the logic in the catch match the logic in the conditional)
                if (!IsReinit && String.IsNullOrEmpty(initializeErrorString) && ClientDataServices._forcedProblemType != ProblemInfoType.NoProblem)
                {
                    initializeErrorString = cds.SetProblemInfo(ClientDataServices._forcedProblemType);
                }
            }

            if (String.IsNullOrEmpty(initializeErrorString))
            {             
                // Do the registration for the data load here instead of the block above because we could be using a cached _query but a new 
                // instance of ClientDataServices
                _dibQueryConnection.RegisterForEvents(cds);}
            else
            {
                _dibQueryConnection.Shutdown();
            }

            return true;
        }

        #endregion


        #region "Error Handling"

        /// <summary>
        /// We want to look at the exception and any inner exceptions to determine what category to label the error which determines what error string to display to user
        /// This is used for QSP/ROA errors from Initialize, Shutdown, and execute Query.
        /// </summary>      
        /// <param name="exception">The error string used in the GUI for the passed exception</param>
        public override string ProcessExceptionErrorResponse(Exception exception, IClientDataServices cds)
        {
            String errorString = String.Empty;
            if (exception != null)
            { 
                errorString = this.QueryConnection.ProcessExceptionErrorResponse(exception, cds);
            }
            if (this.QueryConnection != null) this.QueryConnection.Shutdown();
            return errorString;
        }

        #endregion

    }
}
