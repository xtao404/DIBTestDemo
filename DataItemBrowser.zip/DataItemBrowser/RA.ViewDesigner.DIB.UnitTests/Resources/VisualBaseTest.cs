﻿/*************************************************************************************
                                                                     
   ViewE VisualBaseTest Class
   Copyright © 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;
using RockwellAutomation.CommonServices.TypeSchemas.Devices;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace DataItemBrowserUT
{
    /// <summary>
    /// This unit test exercises the DeviceImage control by creating VisualBase objects 
    /// which implement IVisualBase : IDeviceStatus, various VisualBase objects are
    /// created with different ReplicationStates and ReplicationError settings and the 
    /// imageState, ReplicationError and Tooltip are verified
    /// </summary>
    [TestClass]
    public class VisualBaseTest
    {
        #region Additional test attributes

        // Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void ClientDataServicesTestInit()
        {
            DIBClientManagerForViewe.Instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, 
                DIBQueryCommandTest.SamplePackageContextUUID, 
                DIBQueryCommandTest.SampleProjectContextUUID);
            DIBClientManagerForViewe.InitializeVieweSpecificClasses();
        }

        //
        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void ClientDataServicesTestCleanup()
        {
            DIBClientManagerForViewe.Instance.Shutdown();
        }

        #endregion


        /// <summary>
        /// verify imageState is syched for the corresponding  ReplicationStates
        /// </summary>
        [TestMethod]
        public void VisualBaseWithSyncedController()
        {
            ValidateControllerReplicationState(Enum_ReplicationStateType.SYNCHED.ToString(),EnumImageState.SYNCHED);
            ValidateControllerReplicationState(Enum_ReplicationStateType.DETECTINGCHANGES.ToString(), EnumImageState.SYNCHED);            
        }

       

        /// <summary>
        /// verify imageState is synchronizing for the corresponding  ReplicationStates
        /// </summary>
        [TestMethod]
        public void VisualBaseWithSynchronizingController()
        {            
            ValidateControllerReplicationState(Enum_ReplicationStateType.EXTRACTING.ToString(), EnumImageState.SYNCHING);
            ValidateControllerReplicationState(Enum_ReplicationStateType.UPDATING.ToString(), EnumImageState.SYNCHING);
            ValidateControllerReplicationState(Enum_ReplicationStateType.RESYNCHRONIZING.ToString(), EnumImageState.SYNCHING);
            ValidateControllerReplicationState(Enum_ReplicationStateType.EROA_DATA.ToString(), EnumImageState.SYNCHING);
            
        }
        /// <summary>
        /// verify imageState is out-of-sync for the corresponding  ReplicationStates
        /// </summary>
        [TestMethod]
        public void VisualBaseWithOutOfSyncController()
        {                        
            ValidateControllerReplicationState(Enum_ReplicationStateType.UNINITIATED.ToString(), EnumImageState.OUTOFSYNCH);
            ValidateControllerReplicationState(Enum_ReplicationStateType.NEEDSUPDATING.ToString(), EnumImageState.OUTOFSYNCH);
            ValidateControllerReplicationState(Enum_ReplicationStateType.EROA_UNINITIATED.ToString(), EnumImageState.OUTOFSYNCH);

        }
        /// <summary>
        /// verify imageState is lost sync for the corresponding  ReplicationStates
        /// </summary>
        [TestMethod]
        public void VisualBaseWithLostSyncController()
        {
            ValidateControllerReplicationState(Enum_ReplicationStateType.SYNCHLOST.ToString(), EnumImageState.OUTOFSYNCH);
            ValidateControllerReplicationState(Enum_ReplicationStateType.INDETERMINATE.ToString(), EnumImageState.OUTOFSYNCH);
        }
        /// <summary>
        /// verify imageState is invalid ACD for the corresponding  ReplicationStates
        /// </summary>
        [TestMethod]
        public void VisualBaseWithInvalidController()
        {   
            //both ReplicationState and ReplicationError set, the error should take precedence
            ValidateControllerReplicationError(Enum_ReplicationStateType.INDETERMINATE.ToString(), "\\@\\Devices::C1:Internal Device Error has occurred" ,EnumImageState.WARNING);

            //only ReplicationError set
            ValidateControllerReplicationError(string.Empty, "Synchronization error: CONTROLLERNAME.  FILENAME.acd is not the correct version.  Use Logix Designer to convert the project file to v21 or greater." ,EnumImageState.WARNING);
        }
       

        #region private methods

        private void ValidateControllerReplicationError(string replicationState,string replicationError,EnumImageState imageState)
        {
 	        const VisualType vType = VisualType.vtController;

            //create the VisualBase with the ReplicationState
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("C1");
            DataItemBase dataItem = pe.DataItem;
            dataItem.SetVieweReplicationState(replicationState);
            dataItem.SetVieweReplicationErrorMessage(replicationError);
            DIBTreeViewItem visualBase = new DIBTreeViewItem(dataItem, "C1", vType, null, DIBClientManagerForViewe.Instance);

            //check VisualBase.ImagePresenter for the ImageState
            //check VisualBase.ImagePresenter for the ReplicationErrormessage and tooltip
            Assert.AreEqual(imageState, visualBase.ImagePresenter.ImageState, imageState.ToString() + " icon expected");
            Assert.AreEqual(replicationError,visualBase.ImagePresenter.ReplicationError,"ReplicationError does not equal "+ replicationError );
            Assert.AreEqual(replicationError,visualBase.ImagePresenter.Tooltip,"Tooltip does not equal "+ replicationError);
            Assert.AreEqual(true,visualBase.ImagePresenter.TooltipEnabled, "Tooltip should be enabled");
            Assert.AreEqual("Synchronization Error", visualBase.ImagePresenter.TooltipHeader, "Tooltip Header is " + visualBase.ImagePresenter.TooltipHeader + " expected 'Synchronization Error'");
        }       
        
        private void ValidateControllerReplicationState(string replicationState, EnumImageState imageState)
        {
            const VisualType vType = VisualType.vtController;

            //create the VisualBase with the ReplicationState
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("C1");
            DataItemBase dataItem = pe.DataItem;
            dataItem.SetVieweReplicationState(replicationState);
            DIBTreeViewItem visualBase = new DIBTreeViewItem(dataItem, "C1", vType, null, DIBClientManagerForViewe.Instance);

            //check VisualBase.ImagePresenter for the ImageState
            Assert.AreEqual(imageState, visualBase.ImagePresenter.ImageState, imageState.ToString() + " icon expected");
            if (EnumImageState.OUTOFSYNCH == imageState || EnumImageState.SYNCHING == imageState)
            {
                Assert.AreEqual(true, visualBase.ImagePresenter.TooltipEnabled, "Tooltip should be disabled");
                Assert.AreEqual("Out of Sync", visualBase.ImagePresenter.TooltipHeader, "Tooltip Header is " + visualBase.ImagePresenter.TooltipHeader + " expected empty string");
            }
            else
            {
                Assert.AreEqual(false, visualBase.ImagePresenter.TooltipEnabled, "Tooltip should be disabled");
                Assert.AreEqual(string.Empty, visualBase.ImagePresenter.TooltipHeader, "Tooltip Header is " + visualBase.ImagePresenter.TooltipHeader + " expected empty string");    
            }
            
            Assert.AreEqual(true,visualBase.SupportsDrillIn,"SupportsDrillIn expected true");
            Assert.AreEqual(false, visualBase.IsExpanded, "IsExpanded expected false");
            Assert.AreEqual(false, visualBase.IsSelected, "IsSelected expected false");
        }

        #endregion private methods
    }
}
