﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Launch_TagFilterControl.CustomWindow;
using TagFilterControl.Controls;
using TagFilterControl.DIBClientManagers;

namespace Launch_TagFilterControl
{
    /// <summary>
    /// Interaction logic for DIB_Window.xaml
    /// </summary>
    public partial class DIB_Window : WindowBase
    {
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();
        private Config config = Config.GetInstance();
        public DIB_Window()
        {
            InitializeComponent();
            this.Loaded += DIB_Window_Loaded;
        }

        void DIB_Window_Loaded(object sender, RoutedEventArgs e)
        {
            Point p = Mouse.GetPosition(e.Source as FrameworkElement);
            p = (e.Source as FrameworkElement).PointToScreen(p);
        }

        void DIB_Window_Closed(object sender, EventArgs e)
        {
            filterDIBIn.DIBClientManager = null;
            config.IsCheckedTags.Clear();
            config.ACMCustomPropertiesTagOwnersFilter.Clear();
        }
    }
}
