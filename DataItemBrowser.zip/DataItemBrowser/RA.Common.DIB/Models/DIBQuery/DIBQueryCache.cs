/*************************************************************************************     
   Copyright � 2012-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using RockwellAutomation.UI.Models;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.ObjectModel;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query;

namespace RockwellAutomation.UI.DIBQuery
{ 
    /// <summary>
    /// DIBQueryCache. This class wraps the observable collection that receives data 
    /// from QSP and also caches certain results in cache dictionary
    /// This class is used by DIBQueryCommand, DIBQueryConnection, and ClientDataServices
    /// </summary>
   public class DIBQueryCache
    {
        #region "Variables"
        #endregion

        #region "Constructor"

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItems">Ref to the collection storing the current data items</param>
        public DIBQueryCache(IObservableCollection<DataItemBase> dataItems)
        {
            DataItems = dataItems;
            CachedChildren = new Dictionary<string, IObservableCollection<DataItemBase>>();
        }

        #endregion

        #region "Accessors"

        /// <summary>
        /// Represents the Data Items
        /// 
        /// The current DataItems represents query results. This collection is 
        /// populated by QSP and bound in our DIB GUI
        /// </summary>
        public IObservableCollection<DataItemBase> DataItems { get; private set; }       

        /// <summary>
        /// Represents the CachedChildren, a dictionary for access to previous query results
        /// </summary>
        public Dictionary<string, IObservableCollection<DataItemBase>> CachedChildren { get; internal set; }

        #endregion

        #region "Add/Remove/Clear"

        public virtual void ClearDataItems()
        {
            DataItems.Clear();
        }

        public int DataItemsCount()
        {
            return DataItems.Count();
        }

        public void AddDataItems(List<DataItemBase> items)
        {
            DataItems.AddRange(items);
        }

        public void AddDataItem(DataItemBase item)
        {
            DataItems.Add(item);
        }

        /// <summary>
        /// Add a cached item to cached children dictionary
        /// </summary>
        /// <param name="cacheKeyString">The cache key string to use</param>
        /// <param name="items">The items to add to the cache</param>
        public void AddCachedItem(string cacheKeyString, IObservableCollection<DataItemBase> items)
        {
            CachedChildren[cacheKeyString] = items;
        }

        #endregion

        #region "Lookup"


        /// <summary>
        /// Returns the children of the passed crumb.  Determined based on the cached
        /// result set from a previously executed query
        /// </summary>
        /// <param name="crumb">Crumb to obtain the children for</param>
        /// <param name="nextName">Name of the next crumb in the path (used for bold text setting)</param>
        /// <returns>List of DropArrowItem representing the children of the passed crumb</returns>
        public virtual List<DropArrowItem> GetChildrenOfCrumb(ACrumb crumb, string nextName, DataContext dataContext, IClientDataServices cds)
        {
            // null check on crumb. No reason to continue checking if we are searching for children of undefined crumb
            if (crumb == null) return new List<DropArrowItem>();

            //Get the key to look up the cached children (from previous query)
            ACrumbWithPathElement pathElementCrumb = crumb as ACrumbWithPathElement;
            if (pathElementCrumb == null) return new List<DropArrowItem>();

            String resourceType = cds.DibClientManager.GetBreadCrumbCacheKeyFor(pathElementCrumb.PathElement.DataItem);

            if (cds.DibClientManager.IsGenericDIBBrowser())
            {
                return GetChildrenOfCrumbForGenericDIB(crumb, nextName, resourceType);
            }

            return GetChildrenOfCrumbForVieweDIB(crumb, nextName, resourceType, dataContext, cds);
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="crumb"></param>
       /// <param name="nextName"></param>
       /// <param name="resourceType"></param>
       /// <param name="dataContext"></param>
       /// <param name="cds"></param>
       /// <returns></returns>
       private List<DropArrowItem> GetChildrenOfCrumbForVieweDIB(ACrumb crumb, string nextName, String resourceType, DataContext dataContext, IClientDataServices cds)
        {
            List<DropArrowItem> ChildrenItemList = new List<DropArrowItem>();

            // If the resourceType is Controller or HMIDevice, verify that children exist.
            if ((!CachedChildren.ContainsKey(resourceType)) &&
                ((resourceType == DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER) || (resourceType == DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE)))
            {
                // In the case of a controller or HMIDevice resourceType, the children may not have been previously loaded (which occurs when a user
                // opens the DIB, perform a search in the DSV, and then drillin to the returned collection).  In this case, add the controller or HMI Device
                // children to the _cachedChildren dictionary if not excluded.

                // Dont use DataItems as they are currently displayed in the grid.
                TSObservableCollection<DataItemBase> dataItemsForCache = new TSObservableCollection<DataItemBase>();

                if (resourceType == DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER)
                {
                    bool bExcludeControllerChildren = dataContext.ExcludeAllChildrenOfType == DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller;

                    // Add non excluded children
                    if (!bExcludeControllerChildren)
                    {
                        dataItemsForCache.Add(DIResource.DIB_TagsAndProps);
                        dataItemsForCache.Add(DIResource.DIB_Programs);
                    }

                    // if controller children are not excluded or datalogs have been included and datalogs are not excluded then show datalog folder
                    if ((!bExcludeControllerChildren || dataContext.IncludeAllOfType == DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs) &&
                        (dataContext.ExcludeAllOfType != DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs) &&
                        dataContext.IsDataLogTypeIncluded())
                        dataItemsForCache.Add(DIResource.DIB_DataLogs);
                }
                else
                {
                    // Add HMIDevice children.
                    dataItemsForCache.Add(DIResource.DIB_TagsAndProps);
                }

                //  Add the Controller or HMI Device children to the Dictionary.
                if (dataItemsForCache.Count > 0)
                    AddCachedItem(resourceType, new TSObservableCollection<DataItemBase>(dataItemsForCache));

            }

            if (!CachedChildren.ContainsKey(resourceType))
            {
                return ChildrenItemList;
            }

            var queryForChildren = from item in CachedChildren[resourceType]
                                   select new DropArrowItem()
                                   {
                                       DisplayName = item.ToString(),
                                       HostCrumb = crumb,
                                       IsContainer = isDropArrowItemContainer(item),
                                       IsBold = item.ToString() == nextName,
                                       DataItem = item,
                                       ResourceId = ResourceBase.GuidStringToId(item.CommonID)
                                   };


            if (cds.IsAOGPropertyBrowser())
            {
                return queryForChildren.ToList<DropArrowItem>();
            }
            else if (!cds.IsTagBrowser()) // DataType Browser
            {
                return queryForChildren.ToList<DropArrowItem>();
            }

            //Obtain the list of children (local var used to assist in debugging)  
            List<DropArrowItem> ControllerList = new List<DropArrowItem>();
            if (resourceType == DIBQueryCache.KeyForCachedDevices())
            {
                //// Controllers and HMI Devices - Controllers follow HMI Devices with a Separator dividing them
                //// Group the devices by their Resource Type
                var dsTypes = from dropArrowItem in queryForChildren
                              orderby dropArrowItem.DisplayName ascending
                              group dropArrowItem by new { ResourceType = dropArrowItem.DataItem.CommonResourceType } into diGroup
                              select new { ResourceType = diGroup.Key.ResourceType, Children = diGroup.ToList() };

                // Order the DrowArrowItems by HMI Device and then Controllers, separated by a Separator
                foreach (var device in dsTypes)
                    if (ResourceBase.IsEqual(ResourceBase.GuidStringToId(device.ResourceType), TypeIdentifiers.getResourceType_Controller()))
                        // Controllers
                        ControllerList.AddRange(device.Children);
                    else
                        // HMI Devices
                        ChildrenItemList.AddRange(device.Children);

                // If there are HMI Devices and Controllers add a separator
                if (ChildrenItemList.Count > 0 && ControllerList.Count > 0)
                {
                    // Add Separator DropArrowItem
                    DropArrowItem dai = new DropArrowItem { IsSelectable = false };
                    ChildrenItemList.Add(dai);
                }
                // Append Controllers
                ChildrenItemList.AddRange(ControllerList);
            }
            else if (resourceType == DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER ||
                      resourceType == DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE)
            {
                //Device children show a folder list which we don't want sorted so return that here
                ChildrenItemList = queryForChildren.ToList<DropArrowItem>();
            }
            else if (resourceType == DIResource.DI_COMMON_RESOURCETYPE_DATALOGS)
            {
                // For now we don't want to return any children as we can't drill into datalogs.  This may be done later for R1
                // or post R1.  When we can drill into a datalog, we will want to return the alphabetical list of datalogs. The
                // functionality found in the else clause
            }
            else
            {
                // Sort Programs and Phases
                ChildrenItemList = queryForChildren.OrderBy(w => w.DisplayName, new AlphanumComparator()).ToList<DropArrowItem>();
            }
            return ChildrenItemList;
        }

       /// <summary>
       /// 
       /// </summary>
       /// <param name="crumb"></param>
       /// <param name="nextName"></param>
       /// <param name="resourceType"></param>
       /// <returns></returns>
       private List<DropArrowItem> GetChildrenOfCrumbForGenericDIB(ACrumb crumb, string nextName, String resourceType)
        {
            List<DropArrowItem> ChildrenItemList = new List<DropArrowItem>();

            if (!CachedChildren.ContainsKey(resourceType))
            {
                return ChildrenItemList;
            }

            var queryForChildren = from item in CachedChildren[resourceType]
                                   where Convert.ToBoolean(item.GUISupportsDrillIn)
                                   select new DropArrowItem()
                                   {
                                       DisplayName = item.ToString(),
                                       HostCrumb = crumb,
                                       IsContainer = isDropArrowItemContainer(item),
                                       IsBold = item.ToString() == nextName,
                                       DataItem = item,
                                       ResourceId = ResourceBase.GuidStringToId(item.CommonID)
                                   };

            // Add seperators between items of different parents
            var dsTypes = from dropArrowItem in queryForChildren
                          orderby dropArrowItem.DataItem.CommonDataType, dropArrowItem.DisplayName ascending
                          group dropArrowItem by new { ResourceType = dropArrowItem.DataItem.CommonDataType } into diGroup
                          select new { ResourceType = diGroup.Key.ResourceType, Children = diGroup.ToList()};

            foreach (var itemGroup in dsTypes)
            {
                if (ChildrenItemList.Count > 0)
                {
                    // Add Separator DropArrowItem
                    DropArrowItem dai = new DropArrowItem { IsSelectable = false };
                    ChildrenItemList.Add(dai);
                }
                ChildrenItemList.AddRange(itemGroup.Children);
            }
            return ChildrenItemList;
        }

        /// <summary>
        /// Get the list of cached devices
        /// </summary>
        /// <param name="item">A data iem</param>
        /// <returns>Whether or not the provided parameter should is a container for a DropArrow instance</returns>
        private static bool isDropArrowItemContainer(DataItemBase item)
        {
            if (item.ToString().Equals(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGSPROPERTIES, StringComparison.OrdinalIgnoreCase)) return false;
            if (item.ToString().Equals(DIResource.DI_COMMON_RESOURCETYPE_HMITAGSPROPERTIES, StringComparison.OrdinalIgnoreCase)) return false;
            return true;
        }

        /// <summary>
        /// Get the list of cached devices
        /// </summary>
        /// <returns>ObservableCollection<DataItemBase> representing the Devices</returns>
        public virtual IObservableCollection<DataItemBase> GetCachedDevices()
        {
            IObservableCollection<DataItemBase> result = null;
            CachedChildren.TryGetValue(DIBQueryCache.KeyForCachedDevices(), out result);           
            return result;
        }

        /// <summary>
        /// Helper to obtain the data item for a device given a string name
        /// </summary>
        /// <param name="deviceName">Name of the device to search for</param>
        /// <returns>Data item matching the passed device name or null if not found</returns>
        public virtual DataItemBase GetDeviceItemByName(string deviceName)
        {
            DataItemBase item = null;

            //Look through the cached devices (stored as a result of the initialization query for all devices)
            item = GetItemByName(deviceName, CachedChildren[DIBQueryCache.KeyForCachedDevices()]);
            return item;
        }

        /// <summary>
        /// Helper to obtain the data item for the passed name (using the current DataItems)
        /// </summary>
        /// <param name="itemName">Name of the item to search for</param>
        /// <param name="location">Path of the dataItem or where it is located</param>
        /// <returns>Data item matching the passed name or null if not found</returns>
        public virtual DataItemBase GetDataItemByName(string itemName, string location = null)
        {
            return string.IsNullOrEmpty(location) ? GetItemByName(itemName, DataItems) : GetItemByFullPath(itemName, location, DataItems);
        }

        /// <summary>
        /// Helper to obtain the dataitem for the datatype found in device "location" (using the current collection of DataItems)
        /// </summary>
        /// <param name="datatype">Name of the datatype to search for</param>
        /// <param name="location">Location associated with the datatype</param>
        /// <returns>Data item matching the passed name and location or null if not found</returns>
        public virtual DataItemBase GetDataTypeItemByLocation(string datatype, string location)
        {
            location = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + location;

            return DataItems
                .Where(curItem => string.Equals(curItem.CommonName, datatype, StringComparison.CurrentCultureIgnoreCase))
                .FirstOrDefault(curItem => string.Equals(curItem.CommonLocation, location, StringComparison.CurrentCultureIgnoreCase));
        }

        /// <summary>
        /// Helper for the GetDeviceItemByName and GetDataItemByName methods
        /// </summary>
        /// <param name="name">Name of the datatype to search for</param>
        /// <param name="location">path of where the item is located</param>
        /// <param name="collection">collection to search within</param>
        /// <returns>Data item matching the name from the supplied collection</returns>
        public static DataItemBase GetItemByFullPath(string name, string location, IObservableCollection<DataItemBase> collection)
        {
            return collection
                .FirstOrDefault(curItem =>
                    string.Equals(curItem.CommonName, name, StringComparison.CurrentCultureIgnoreCase) && 
                    string.Equals(curItem.CommonLocation, location, StringComparison.CurrentCultureIgnoreCase));
        }

        /// <summary>
        /// Helper for the GetDeviceItemByName and GetDataItemByName methods
        /// </summary>
        /// <param name="name">Name of the datatype to search for</param>
        /// <param name="collection">collection to search within</param>
        /// <returns>Data item matching the name from the supplied collection</returns>
        public static DataItemBase GetItemByName(string name, IObservableCollection<DataItemBase> collection)
        {
            return collection.FirstOrDefault(curItem => string.Equals(curItem.CommonName, name, StringComparison.CurrentCultureIgnoreCase));
        }

        /// <summary>
        /// Returns the key used to look up devices in the cache
        /// </summary>
        private static string KeyForCachedDevices()
        {
            return DIResource.DI_COMMON_RESOURCETYPE_NONE;
        }

        #endregion

    }
    
}
