﻿/*************************************************************************************     
   Copyright © 2016 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using System;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI.Models;
using RockwellAutomation.Logging;
using System.Reflection;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query.Common;


namespace RockwellAutomation.UI.DIBQuery
{    
    /// <summary>
    /// DIBQueryCommandForViewe allows request to QSP to be represented as an object.
    /// Sublcasses specialize the differnet types of commands that can be sent to QSP.
    /// The main purpose of a DIBQueryCommandForViewe is to generate a QueryRequest object that is sent to QSP in the QSP Request.
    /// Note that QueryRequest implementes the builder pattern, and the builder is stored in _queryRequestBuilder.
    /// </summary>
    public abstract class DIBQueryCommandForViewe : DIBQueryCommand
    {

        #region "Creation/Init"

        
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="queryRequestBuilder">The builder to use to generate the QueryRequest</param>
        protected DIBQueryCommandForViewe(QueryRequest.CreateBuilder queryRequestBuilder)
            :base(queryRequestBuilder)
        {
        }


        /// <summary>
        /// Provide ability to create a specific command based on requested type
        /// </summary>
        /// <param name="browserPerspective"></param>
        /// <param name="parentResourceTypeId">The Resource Type of the parent, even if no parent is specified</param>
        /// <param name="parentItem">The DataItemBase that represents the parent. This can be null if there is no parent</param>
        /// <param name="queryCondition"></param>
        static new public IDIBQueryCommand CreateFor(QueryRequest.CreateBuilder queryRequestBuilder, bool isForDIBSearch = false)
        {
            // If We are searching in the DIB its going to be in TAG browser. DataTypeBrowser search is not enabled yet
            if (isForDIBSearch)
            {
                if (queryRequestBuilder.GetParentDataItemBase() != null)
                {
                    //For an HMI device, we use a Tags query since currently the AllTags is only available in QSP for controllers.  
                    // We can do this because currently we are not yet showing any children of HMI Devices such as screens and AOGs.  When the HMI device search does need to search
                    // other children than the "system tags", we will need to change this back to AllTags (or a different query type specific for HMI devices and have new support in QSP for it).
                    UUID itemType = queryRequestBuilder.GetParentDataItemBase().GetResourceTypeAsUUID();
                    if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_HMIDevice))
                        return new DIBQueryCommandForTags(queryRequestBuilder);
                }
                return new DIBQueryCommandForAllTags(queryRequestBuilder);
            }
            return TypeFor(queryRequestBuilder);
        }

        /// <summary>
        /// Helper to obtain which command type should be used when drilling in to the
        /// passed data item
        /// </summary>
        /// <param name="dataItem"></param>
        /// <param name="browserPerspective"></param>
        /// <param name="queryRequestBuilder"></param>
        /// <returns>one of the available predefined query type values </returns>
        static public IDIBQueryCommand TypeFor(QueryRequest.CreateBuilder queryRequestBuilder)
        {
            DataItemBase parentItem = queryRequestBuilder.GetParentDataItemBase();
            // If the Parent Dataitem is null, we are dealing with the first screen of TAG or DataType Browser
            if (parentItem == null)
            {
                if ((DIBClientManagerForViewe.Instance).IsTagBrowser() || (DIBClientManagerForViewe.Instance).IsAOGPropertyBrowser())
                    return new DIBQueryCommandForDevices(queryRequestBuilder);
                else
                    return new DIBQueryCommandForDataTypes(queryRequestBuilder);
            }

            // First check for the flavors that would apply to the data type browser
            if (parentItem.CommonDataType == DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE)
                return new DIBQueryCommandForModuleDataTypes(queryRequestBuilder);
            if (parentItem.CommonDataType == DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE)
                return new DIBQueryCommandForProductDataTypes(queryRequestBuilder);
            if (parentItem.CommonDataType == DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE)
                return new DIBQueryCommandForUserDataTypes(queryRequestBuilder);
            // Then check for the other types by looking at the resource type of the data item base
            else
            {
                UUID itemType = parentItem.GetResourceTypeAsUUID();
                if (ResourceBase.IsEqual(itemType, TypeIdentifiers.getResourceType_Controller()) ||
                    ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Device))
                    return new DIBQueryCommandForController(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Program))
                    return new DIBQueryCommandForTags(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Tag))
                    return new DIBQueryCommandForDataTypeMembers(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_DataTypeMember))
                    return new DIBQueryCommandForDataTypeMembers(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_DataType))
                    return new DIBQueryCommandForDataTypes(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_TagsAndProperties))
                    return new DIBQueryCommandForTags(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Programs))
                    return new DIBQueryCommandForPrograms(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_DataLogs))
                    return new DIBQueryCommandForDataLogs(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_HMIDevice))
                    return new DIBQueryCommandForHMIDevice(queryRequestBuilder);
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_AOG))
                    return new DIBQueryCommandForAOGProperties(queryRequestBuilder);
            }

            return new DIBQueryCommandForUndefined(queryRequestBuilder);
        }

        /// <summary>
        /// We need to now whether or not to display metadata.
        /// This determines whether QSP will create elements as structured (allow elements to be drillable) and also if we should display metadata rows
        /// There is a performance optimization to set SetDisplayMetaDataForBitsAndProperties = true in QSP
        /// </summary>
        public virtual bool ShouldDisplayMetaDataForBitsAndProperties(IClientDataServices cds, DataContext dataContext)
        {
            // Set whether we want to display metadata. 
            if (cds.IsBrowsingHMIDevice())
                return false;
            else
                return dataContext.DisplayMetaData;
        }


        /// <summary>
        /// Set all chunk load settings. Future considerations might be to allow sublcasses to specify optimized chunk setting 
        /// </summary>
        public virtual void GenerateChunkLoadSetings(IDIBQueryConnection queryConnection)
        {
            // Set 'Intitial Chunk Loading' related properties. The first 'SetInitialLoadTotalItemSize' items will be loaded in 'SetInitialLoadChunkSize' chunk sizes by having QSP call the callback delegate 'CallbackLoadInitialItems' on each chunk
            // This will allow us to control how the GUI responds to updates in our Observable Collection
            // These values can be further exposed as properties in PopUpTestHost to have people see how changes are reflected in GUI. Current settings where thought of as being optimal for now.
            this.QueryRequestBuilder.SetInitialLoadCallback(queryConnection.CallbackLoadInitialItems);
            this.QueryRequestBuilder.SetInitialLoadChunkSize(10);
            this.QueryRequestBuilder.SetInitialLoadTotalItemSize(50);

            // Set 'Final Chunk Load' variables. After 'Intitial Chunk Loading', QSP load items in chunks of size 'SetFinalLoadChunkSize' untill there are no more items by calling the delegate defined in 'SetFinalLoadCallback' on each chunk.
            // The reason we decided to have 'Initial' and 'Final' chunk loading was that the 'Initial' chunks should represent rows visible by customers who would see items load in an organized order as before it was undeterministic how many 
            // would load at any opint in time.
            // The "Final" loading is intended for loading items that are more than likely not visible on the screen, so the chunk size should be larger for 'Final' loading as opposed to 'Initial' loading
            // The purpose of having two delegates instead of one is to give CDS an opportunity to handle the updates in different priority.
            this.QueryRequestBuilder.SetFinalLoadCallback(queryConnection.CallbackLoadFinalItems);
            this.QueryRequestBuilder.SetFinalLoadChunkSize(1000);
        }


        #endregion

        #region IDIBQueryCommand Implementation

        /// <summary>
        /// Execute a Query to back end using the specified DIBQueryConnection and ClientDataService
        /// </summary>
        /// <param name="cds"></param>
        /// <param name="queryConnection"></param>
        public override void Execute(IClientDataServices cds)
        {
            IDIBQueryConnection queryConnection = (cds.DibClientManager as DIBClientManagerForViewe).QueryConnection;
            this.Execute(cds, queryConnection);
        }

        /// <summary>
        /// Execute a Query to back end using the specified DIBQueryConnection and ClientDataService
        /// </summary>
        /// <param name="cds"></param>
        /// <param name="queryConnection"></param>
        public virtual void Execute(IClientDataServices cds, IDIBQueryConnection queryConnection)
        {
            DataContext dataContext = cds.DataContext;
            DIBQueryCache queryCache = cds.QueryCache;

            // Generate the column config
            this.SetColumnConfigIfNeeded(cds);

            // Generate the condition config
            this.SetConditionConfigIfNeeded(cds);

            // Set DB ID if needed
            this.SetDataBaseIDIfNeeded();

            // Generate Chunk Load settings
            this.GenerateChunkLoadSetings(queryConnection);

            // Set whether to display metadata or not
            this.QueryRequestBuilder.SetDisplayMetaDataForBitsAndProperties(this.ShouldDisplayMetaDataForBitsAndProperties(cds, dataContext));

            // Set the Query Type
            this.QueryRequestBuilder.SetPredefinedQuery(this.QueryType());

            this.CurrentQueryRequest = this.QueryRequestBuilder.Build();

            try
            {
                queryConnection.Execute(this, queryCache);
            }
            catch (Exception ex)
            {
                LogWrapper.LogException(MethodBase.GetCurrentMethod().ToString(), ex);
                queryConnection.ProcessExceptionErrorResponse(ex, cds);
            }
        }

        /// <summary>
        /// Some query commmands can execute without needing to go to QSP as we have all the data we need to fulfill the command..
        /// CDS will be unaware of whether we executed ths command in QSP or not.
        /// </summary>
        /// <param name="queryConnection"></param>
        /// <param name="queryCache"></param>
        protected void ExecuteNonDBQueryResponse(IDIBQueryConnection queryConnection, DIBQueryCache queryCache)
        {
            this.QueryRequestBuilder.SetColumnConfig(DIBQueryCommand.NonDBQueryColumnConfig());
            this.CurrentQueryRequest = this.QueryRequestBuilder.Build();

            // Generate a Query Response the same way QSP would
            QueryResponse.CreateBuilder queryResponseBuilder = new QueryResponse.CreateBuilder();

            queryResponseBuilder
                .SetQueryRequest(this.CurrentQueryRequest)
                .SetTotalItemCount(queryCache.DataItemsCount());

            // Call Query_DataLoadComplete in queryConnection the same way that QSP signals a response
            this.ExecuteNonDBQueryResponse(queryConnection, queryResponseBuilder.Build());
        }

        /// <param name="queryConnection"></param>
        /// <param name="queryResponse"></param>
        protected virtual void ExecuteNonDBQueryResponse(IDIBQueryConnection queryConnection, QueryResponse queryResponse)
        {
            // Call Query_DataLoadComplete in queryConnection the same way that QSP signals a response
            queryConnection.Query_DataLoadComplete(queryResponse, null);
        }

        #endregion


        #region "Private/Protected"

        /// <summary>
        /// If our Parent Data Item is located in a difernet DB, we need to specify that in our Query Request
        /// </summary>
        protected void SetDataBaseIDIfNeeded()
        {
            if (this.ParentDataItem() != null && this.ParentDataItem().CommonRefTargetDBId != null)
            {
                String uidString = this.ParentDataItem().CommonRefTargetDBId;
                UUID dbID = ResourceBase.GuidStringToId(uidString);
                this.QueryRequestBuilder.SetDataBaseID(dbID);
            }
        }

        #endregion
    }
}
