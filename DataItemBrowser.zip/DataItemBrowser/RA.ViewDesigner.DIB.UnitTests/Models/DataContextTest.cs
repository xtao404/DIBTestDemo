﻿using RockwellAutomation.UI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for DataContextTest and is intended
    ///to contain all DataContextTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DataContextTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        private PrivateObject _dataContextPrivate = null;
        private DataContext _dataContext = null;
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
          
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
            
        //}
        //
        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            _dataContext = new DataContext();
            _dataContextPrivate = new PrivateObject(_dataContext);
        }
        
        //Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {
            _dataContext = null;
            _dataContextPrivate = null;
        }
        
        #endregion


        

        /// <summary>
        ///A test for CopyPathItems Success
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataContext_CopyPathItemsTest_Success()
        {
            string controllerName = "Controller1";
            List<string> strRootPath = new List<string>();
            strRootPath.Add(controllerName);
            List<DataItemBase> includePathItems = new List<DataItemBase>();
            includePathItems.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));
            includePathItems.Add(PathElementUtility.Instance().CreateDataItemBase("Program1"));
            List<DataItemBase> rootPathItems = new List<DataItemBase>();
            int index = 0;
            PrivateType dataContextStatic = new PrivateType(_dataContext.GetType());
            index = (int)dataContextStatic.InvokeStatic("CopyPathItems", new object[] { strRootPath, includePathItems, rootPathItems, index });
            Assert.AreEqual(1, index,"it should only copy one dataItem");
            Assert.AreEqual(1, rootPathItems.Count, "rootPathItems should have only one dataItem");
            Assert.AreEqual(controllerName, rootPathItems[0].CommonName, "and it should be the controller name");
        }

        /// <summary>
        ///A test for CopyPathItems Fail
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataContext_CopyPathItemsTest_Fail()
        {
            string controllerName = "Controller1";
            List<string> strRootPath = new List<string>();
            strRootPath.Add("Fred");
            List<DataItemBase> includePathItems = new List<DataItemBase>();
            includePathItems.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));
            includePathItems.Add(PathElementUtility.Instance().CreateDataItemBase("Program1"));
            List<DataItemBase> rootPathItems = new List<DataItemBase>();
            int index = 0;
            PrivateType dataContextStatic = new PrivateType(_dataContext.GetType());
            index = (int)dataContextStatic.InvokeStatic("CopyPathItems", new object[]{strRootPath, includePathItems, rootPathItems, index});
            Assert.AreEqual(0, index, "nothing copied");
            Assert.AreEqual(0, rootPathItems.Count, "rootPathItems should not have any dataItems");
        }

        /// <summary>
        ///A test for CopyToExclude
        ///</summary>
        [TestMethod()]
        public void DataContext_CopyToExcludeTest()
        {
            string controllerName = "Controller1";
            List<string> strExcludePath = new List<string>();
            strExcludePath.Add(controllerName);
            List<DataItemBase> includePathItems = new List<DataItemBase>();
            _dataContext.IncludePath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));
            _dataContext.IncludePath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase("Program1"));
            int index = 0;
            _dataContext.CopyToExclude(strExcludePath, ref index);
            Assert.AreEqual(1, index, "it should only copy one dataItem");
            Assert.AreEqual(1, _dataContext.ExcludeAllChildrenFromPath.DataItemList.Count, "ExcludeAllChildrenFromPath should have only one dataItem");
            Assert.AreEqual(controllerName, _dataContext.ExcludeAllChildrenFromPath.DataItemList[0].CommonName, "and it should be the controller name");
           
        }

        /// <summary>
        ///A test for CopyToRoot
        ///</summary>
        [TestMethod()]
        public void DataContext_CopyToRootTest()
        {
            string controllerName = "Controller1";
            List<string> strRootPath = new List<string>();
            strRootPath.Add(controllerName);
             _dataContext.IncludePath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));
            _dataContext.IncludePath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase("Program1"));
           
            int index = 0;
            _dataContext.CopyToRoot(strRootPath, ref index);
            Assert.AreEqual(1, index, "it should only copy one dataItem");
            Assert.AreEqual(1, _dataContext.RootPath.DataItemList.Count, "rootPathItems should have only one dataItem");
            Assert.AreEqual(controllerName, _dataContext.RootPath.DataItemList[0].CommonName, "and it should be the controller name");
           
            
            
        }

        /// <summary>
        ///A test for HasExcludeAllChildren
        ///has ExcludeAllChildrenFrom dataitems
        ///</summary>
        [TestMethod()]
        public void DataContext_HasExcludeAllChildrenPathTest_True()
        {
            string controllerName = "Controller1";
           //add one exclude dataitem
            _dataContext.ExcludeAllChildrenFromPath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));



            Assert.IsTrue(_dataContext.HasExcludeAllChildrenPath(), "it should show that it has excludes");
           
        }

        /// <summary>
        ///A test for HasExcludeAllChildren true 2
        ///has ExcludeAllChildrenFromRoot
        ///</summary>
        [TestMethod()]
        public void DataContext_HasExcludeAllChildrenPathTest_True2()
        {
            _dataContext.ExcludeAllChildrenFromRoot = true;


            Assert.IsTrue(_dataContext.HasExcludeAllChildrenPath(), "it should show that it has excludes");

        }
        /// <summary>
        ///A test for HasInclude false
        ///</summary>
        [TestMethod()]
        public void DataContext_HasExcludeAllChildrenPathTest_False()
        {

            //do not add any exclude children items

            Assert.IsFalse(_dataContext.HasExcludeAllChildrenPath(), "it should show that it has a root");
        }
        /// <summary>
        ///A test for HasInclude true
        ///</summary>
        [TestMethod()]
        public void DataContext_HasIncludeTest_True()
        {
            string controllerName = "Controller1";
            List<string> strExcludePath = new List<string>();
            strExcludePath.Add(controllerName);
            _dataContext.IncludePath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));
            _dataContext.IncludePath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase("Program1"));

          
            Assert.IsTrue(_dataContext.HasInclude(), "it should show that it has includes");

        }

        /// <summary>
        ///A test for HasInclude false
        ///</summary>
        [TestMethod()]
        public void DataContext_HasIncludeTest_False()
        {

            //do not add any include  items

            Assert.IsFalse(_dataContext.HasInclude(), "it should show that it has a root");
        }

        /// <summary>
        ///A test for HasRoot true
        ///</summary>
        [TestMethod()]
        public void DataContext_HasRootTest_True()
        {
            //add a dataitem to the root
            string controllerName = "Controller1";
            _dataContext.RootPath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));
 

            Assert.IsTrue(_dataContext.HasRoot(), "it should show that it has a root");
        }

        /// <summary>
        ///A test for HasRoot false
        ///</summary>
        [TestMethod()]
        public void DataContext_HasRootTest_False()
        {
    
            //do not add any root items

            Assert.IsFalse(_dataContext.HasRoot(), "it should show that it has a root");
        }
       

        /// <summary>
        ///A test for ExcludeAllChildrenFromRoot
        ///</summary>
        [TestMethod()]
        public void DataContext_ExcludeAllChildernFromRootTest()
        {
  
            _dataContext.ExcludeAllChildrenFromRoot = true;

            Assert.IsTrue(_dataContext.ExcludeAllChildrenFromRoot, "should have exclude from root true");
         }

        /// <summary>
        ///A test for ExcludeAllChildrenFromPath
        ///</summary>
        [TestMethod()]
        public void DataContext_ExcludeAllChildrenFromPathTest()
        {
            string controllerName = "Controller1";
            _dataContext.ExcludeAllChildrenFromPath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));

            Assert.AreEqual(1, _dataContext.ExcludeAllChildrenFromPath.DataItemList.Count, "exclude path items should have only one dataItem");
            Assert.AreEqual(controllerName, _dataContext.ExcludeAllChildrenFromPath.DataItemList[0].CommonName, "and it should be the controller name");
   
        }

        /// <summary>
        ///A test for IncludePath
        ///</summary>
        [TestMethod()]
        public void DataContext_IncludePathTest()
        {
            string controllerName = "Controller1";
            string programName = "Program1";
            _dataContext.IncludePath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));
            _dataContext.IncludePath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(programName));

             Assert.AreEqual(2, _dataContext.IncludePath.DataItemList.Count, "incldue path should have 2 dataItem");
             Assert.AreEqual(controllerName, _dataContext.IncludePath.DataItemList[0].CommonName, "and it should be the controller name");
             Assert.AreEqual(programName, _dataContext.IncludePath.DataItemList[1].CommonName, "and it should be the controller name");

        }

        /// <summary>
        ///A test for RootNavIntoFolder
        ///</summary>
        [TestMethod()]
        public void DataContext_RootNavIntoFolderTest()
        {
            string controllerName = "Controller1";
             _dataContext.RootPath.DataItemList.Add(PathElementUtility.Instance().CreateDataItemBase(controllerName));

             Assert.AreEqual(1, _dataContext.RootPath.DataItemList.Count, "exclude path items should have only one dataItem");
             Assert.AreEqual(controllerName, _dataContext.RootPath.DataItemList[0].CommonName, "and it should be the controller name");

        }

        /// <summary>
        ///A test for RootPath
        ///</summary>
        [TestMethod()]
        public void DataContext_RootPathTest()
        {
            DataContext target = new DataContext(); 
            ContextPath expected = null;
            ContextPath actual;
            target.RootPath = expected;
            actual = target.RootPath;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// Is DataLog Type Include True
        ///</summary>
        [TestMethod()]
        public void DataContext_IsDataLogTypeIncludeTrueTest()
        {
            DataContext target = new DataContext();
            target.ExcludeAllChildrenOfType = DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller;
            target.IncludeAllOfType = DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs;
            Assert.IsFalse(target.IsDataLogTypeIncluded()); //Change this back after R1 to true as the requirements specify that we want to display DataLgos after R1
        }
        /// <summary>
        /// Is DataLog Type Include False
        ///</summary>
        [TestMethod()]
        public void DataContext_IsDataLogTypeIncludeFalseTest()
        {
            DataContext target = new DataContext();
            target.ExcludeAllOfType = DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs;
             Assert.IsFalse(target.IsDataLogTypeIncluded());
        }
        /// <summary>
        /// Is HMI Device Type Include true, default should be true
        ///</summary>
        [TestMethod()]
        public void DataContext_IsHMIDeviceTypeIncludeTrueTest()
        {
            DataContext target = new DataContext();
            Assert.IsTrue(target.IsHMIDeviceTypeIncluded());
        }
        ///// <summary>
        ///// Is  HMI Device Type Include False
        /////</summary>
        //[TestMethod()]
        //public void DataContext_IsHMIDeviceTypeIncludeFalseTest()
        //{
        //    DataContext target = new DataContext();
        //    target.ExcludeAllOfType = DataItemBrowserContext.ExcludeAllOfTypeEnum.HMIDevice;
        //    //the _isHMIDeviceTypeIncluded is updated at the end of the ProcessDataContext call, this requires a stub for CDS or DibQuery ****THIS TEST IS COMMENTED OUT UNTIL A STUB IS CREATED****
        //    Assert.IsFalse(target.IsHMIDeviceTypeIncluded());
        //}

        /// <summary>
        /// Is Program Type Include True
        ///</summary>
        [TestMethod()]
        public void DataContext_IsProgramTypeIncludeTrueTest()
        {
            DataContext target = new DataContext();
            target.ExcludeAllChildrenOfType = DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.None;
            Assert.IsTrue(target.IsProgramTypeIncluded());
        }

        /// <summary>
        /// Is Program Type Include False
        ///</summary>
        [TestMethod()]
        public void DataContext_IsProgramTypeIncludeFalseTest()
        {
            DataContext target = new DataContext();
            target.ExcludeAllChildrenOfType = DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller;
            target.IncludeAllOfType = DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs;
            Assert.IsFalse(target.IsProgramTypeIncluded());
        }

        /// <summary>
        /// Is Program Path Include True
        ///</summary>
        [TestMethod()]
        public void DataContext_IsProgramPathIncludeFalseTest()
        {
            DataContext target = new DataContext();
            List<DataItemBase> items = new List<DataItemBase>();
            //create root path for ::Controller1
            IPathElement controllerPE = PathElementUtility.Instance().CreateControllerPathElement("Controller1");
            items.Add(controllerPE.DataItem);
            target.RootPath = new ContextPath(items);

            //create include path for ::Controller1\Program1
            IPathElement programsPE = PathElementUtility.Instance().CreateProgramsPathElement();
            IPathElement mainProgramPE = PathElementUtility.Instance().CreateProgramPathElement("Program1");
           
            List<DataItemBase> includeItems = new List<DataItemBase>();
            includeItems.Add(controllerPE.DataItem);
            includeItems.Add(programsPE.DataItem);
            includeItems.Add(mainProgramPE.DataItem);

            target.IncludePath = new ContextPath(includeItems);
            target.ExcludeAllChildrenFromRoot = true;
            //test for MainProgram
            Assert.IsFalse(target.IsProgramPathIncluded(new Path(),"MainProgram"));
        }

        /// <summary>
        /// Is Program path Include False
        ///</summary>
        [TestMethod()]
        public void DataContext_IsProgramPathIncludeTrueTest()
        {
            string progName = "MainProgram";

            DataContext target = new DataContext();
            //create root path for ::Controller1
            List<DataItemBase> items = new List<DataItemBase>();
            items.Add(PathElementUtility.Instance().CreateControllerPathElement("Controller1").DataItem);
            target.RootPath = new ContextPath(items);
            target.ExcludeAllChildrenFromPath = new ContextPath(items);
            //create include path for ::Controller1\MainProgram
            List<DataItemBase> includeItems = new List<DataItemBase>();
            IPathElement controllerPE = PathElementUtility.Instance().CreateControllerPathElement("Controller1");
            IPathElement programsPE = PathElementUtility.Instance().CreateProgramsPathElement();
            IPathElement mainProgramPE = PathElementUtility.Instance().CreateProgramPathElement(progName);
            includeItems.Add(controllerPE.DataItem);
            includeItems.Add(programsPE.DataItem);
            includeItems.Add(mainProgramPE.DataItem);
            target.IncludePath = new ContextPath(includeItems);
            target.ExcludeAllChildrenFromRoot = true;
            Path path = new Path();
            path.Items.Add(controllerPE);
            path.Items.Add(programsPE);
            //test for MainProgram
            Assert.IsTrue(target.IsProgramPathIncluded(path,progName));
        }
    }
}
