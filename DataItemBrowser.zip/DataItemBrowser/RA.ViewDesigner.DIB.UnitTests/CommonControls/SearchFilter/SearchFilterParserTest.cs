using System.Linq;
using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
	/// <summary>
	///This is a test class for SearchFilterParserTest and is intended
	///to contain all SearchFilterParserTest Unit Tests
	///</summary>
	[TestClass()]
	public class SearchFilterParserTest
	{
        //These constants should match the strings in the CommonControls Resources.resx file 
        public const string ERROR_SEARCH_CANNOT_START_WITH_SPACE = "A filter search containing only blank spaces must be surrounded with quotation marks.";	
        public const string ERROR_SEARCH_BLANK_SPACE_MISSING = "Blank space missing for:";
        public const string ERROR_SEARCH_CLOSE_PARENTHESIS_MISSING = "Close parenthesis missing for:";
        public const string ERROR_SEARCH_DELETE_BLANK_SPACES = "Delete blank spaces for:";
        public const string ERROR_SEARCH_EXPECTED_OPERATOR = "Expected an operator:";
        public const string ERROR_SEARCH_FILTER_STATEMENT_MISSING = "Filter statement missing after operator for:";
        public const string ERROR_SEARCH_FILTER_VALUE_MISSING = "Filter value missing for:";
        public const string ERROR_SEARCH_KEYWORD_INCORRECTLY_USED = "Keyword AND/OR should be used between 2 statements.";
        public const string ERROR_SEARCH_OPEN_PARENTHESIS_MISSING = "Open parenthesis missing for:";
        public const string ERROR_SEARCH_PARENTHESES_CANNOT_BE_NESTED = "Parentheses cannot be nested.";
        public const string ERROR_SEARCH_PARENTHESES_MUST_SURROUND_FILTER_VALUES = "Parentheses must surround only filter values.";
        public const string ERROR_SEARCH_QUOTATION_MARK_MISSING = "Quotation mark missing for:";
        public const string ERROR_SEARCH_QUOTATION_MARKS_INCORRECT = "Quotation marks must surround only search and filter statements.";
        public const string ERROR_SEARCH_SEARCHING_NOT_SUPPORTED = "Searching is not supported:";
        public const string ERROR_SEARCH_UNEXPECTED_WHITESPACE = "Unexpected whitespace following:";

		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes
		// 
		//You can use the following additional attributes as you write your tests:
		//
		//Use ClassInitialize to run code before running the first test in the class
		//[ClassInitialize()]
		//public static void MyClassInitialize(TestContext testContext)
		//{
        //}
		//
		//Use ClassCleanup to run code after all tests in a class have run
		//[ClassCleanup()]
		//public static void MyClassCleanup()
		//{
		//}
		//

        /// <summary>
        /// Helper to set the locale of the current thread.
        /// </summary>
        static void SetLocaleToEnglish()
        {
            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = new System.Globalization.CultureInfo("en-US");
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = new System.Globalization.CultureInfo("en-US");
        }

        private SearchFilterParser _parser = null;
        PrivateObject privateSearchFilterParser = null;
		//Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            SetLocaleToEnglish();
            SearchFilterControl target = new SearchFilterControl();
            _parser = new SearchFilterParser();
            privateSearchFilterParser = new PrivateObject(_parser);
            ClearLocale();
        }
        
        /// <summary>
        /// Use TestCleanup to run code after each test has run
        /// </summary>
        [TestCleanup()]
        public void MyTestCleanup()
        {
            ClearLocale();
        }


        static void ClearLocale()
        {
            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = null;
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = null;
        }
		#endregion

        // Delegate for IsMatch and ApplyFilter
        public static string ReturnFieldValue(string fieldName, object item)
        {
            return ((DataItemBase)item).GetStringMapValue(fieldName);
        }

		/// <summary>
		/// filter types used by parse method
		/// </summary>
		private ObservableCollection<FilterType> _filterTypes = null;

		/// <summary>
		/// private method to generate the valid filter types
		/// </summary>
		private void GenerateFilterTypes()
		{
			_filterTypes = new ObservableCollection<FilterType>();
            _filterTypes.Add(new FilterType(DIBConstants.Common.Name, true, false));
            _filterTypes.Add(new FilterType(DIBConstants.Common.DataType, false, false));
            _filterTypes.Add(new FilterType(DIBConstants.Common.Description, true, false));
		}

		#region Valid filter strings

		/// <summary>
		///A test for Parse valid string with parens filtertypes- Datatype and Name
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_ValidName_Datatype_OR_Parens()
		{
			string searchFilter = "datatype:(\"DINT\" OR \"INT\") name:state";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "dt:(\"DINT\" OR \"INT\") n:state";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "dt:(\"DINT\" OR \"INT\") name:state";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "datatype:(\"DINT\" OR \"INT\") n:state";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for Parse valid string with parens filtertype-Datatype
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_Datatype_Parens()
		{
			string searchFilter = "datatype:(\"DINT\" OR \"SINT\")";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

			searchFilter = "dt:(\"DINT\" OR \"SINT\")";
            actual = this._parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);
		}

        /// <summary>
        ///A test for Parse valid exact match string filtertype-default
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Valid_Exact_Match()
        {
           	string searchFilter = "\"TestSearchItemName\""; 
            GenerateFilterTypes();
			bool actual = this._parser.Parse(searchFilter, _filterTypes, true);
			Assert.IsTrue(actual);

            searchFilter = "\"val you\"";
            actual = this._parser.Parse(searchFilter, _filterTypes, true);
            Assert.IsTrue(actual);

            searchFilter = "\" \"";
            actual = this._parser.Parse(searchFilter, _filterTypes, true);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for Parse valid string with parens filtertype- DataType, Name
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_Dattype_OR_Name()
		{
			string searchFilter = "datatype:\"DINT\" OR name:Tag";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "dt:\"DINT\" OR n:Tag";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "dt:\"DINT\" OR name:Tag";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "datatype:\"DINT\" OR n:Tag";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            //space is a valid exact match even if it won't return anything
            searchFilter = "datatype:\" \" OR n:Tag";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for Parse valid string with parens filterType-Name
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_Name_OR_Name()
		{
			string searchFilter = "name:auto OR name:Tag";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "n:auto OR n:Tag";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "n:auto OR name:Tag";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            //exact match a space should not error, but will come up empty if executed
            searchFilter = "n:\" \"";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for Parse valid string for data type and name
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_Datatype_AND_Name()
		{
			string searchFilter = "datatype:\"DINT\" name:descrip";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "dt:\"DINT\" n:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "dt:\"DINT\" name:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "datatype:\"DINT\" n:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for Parse valid string with all filter types
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_AllFilters()
		{
			string searchFilter = "datatype:\"DINT\" description:test name:descrip";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "dt:\"DINT\" d:test n:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "dt:\"DINT\" d:test name:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "dt:\"DINT\" description:test n:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "datatype:\"DINT\" d:test n:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "datatype:\"DINT\" description:test n:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "datatype:\"DINT\" d:test name:descrip";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for Parse valid string with an implicit AND between 2 filter values
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_Implicit_And_2FilterValues()
		{
			string searchFilter = "name:(boo hoo)";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "n:(boo hoo)";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for Parse valid string with an implicit AND between 2 filters
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_Implicit_And_2Filters()
		{
			string searchFilter = "name:boo name:hoo";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "n:boo name:hoo";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "name:boo n:hoo";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for Parse valid string with invalid characters hidden in an exact match
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_InvalidCharacters_Hidden_In_ExactMatch()
		{
			string searchFilter = "name:\"(jadsfj;a:ggg name: \"";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "n:\"(jadsfj;a:ggg name:AND \"";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "name:\"(OR jadsfj;a:ggg n: \"";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		///A test for Parse valid string with leading whitespace
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_LeadingWhiteSpace()
		{
			string searchFilter = " datatype:bool";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = " dt:bool";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

        ///A test for Parse valid string with trailing whitespace in filter value
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Valid_FilterValueWithLeadingWhiteSpace()
        {
            string searchFilter = "Description:( udt OR bool)";
            GenerateFilterTypes();
            bool actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "D:( udt OR bool)";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

        ///A test for Parse valid string with trailing whitespace in filter value
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Valid_FilterValueWithMultipleWhiteSpace()
        {
            string searchFilter = "Description:(  udt OR   bool    )";
            GenerateFilterTypes();
            bool actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "D:(  udt OR   bool    )";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

        ///A test for Parse valid string with trailing whitespace in filter value
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Valid_FilterValueWithTrailingWhiteSpace()
        {
            string searchFilter = "Description:(udt OR bool )";
            GenerateFilterTypes();
            bool actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            searchFilter = "D:(udt OR bool )";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		///A test for Parse valid string with quoted description
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_QuotedDescription()
		{
			string searchFilter = "description:\"testdesc\"";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "d:\"testdesc\"";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		///A test for Parse valid string with quoted description with spaces
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_QuotedDescription_Spaces()
		{
			string searchFilter = "description:\"test desc \"";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "d:\"test desc \"";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

            //a space should work for the description filter
            searchFilter = "d:\" \"";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);

        }

		///A test for Parse valid string with quoted parenthesized description
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_QuotedParenDescription()
		{
			string searchFilter = "description:(\"test desc \")";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "d:(\"test desc \")";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		///A test for Parse valid string with two descriptions
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_TwoDescriptions()
		{
			string searchFilter = "description:(\"test desc \" another)";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "d:(\"test desc \" another)";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		///A test for Parse valid string with two descriptions with an OR
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_TwoDescriptions_With_OR()
		{
			string searchFilter = "description:(\"test desc \" OR another)";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);
            
            searchFilter = "d:(\"test desc \" OR another)";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

		///A test for Parse valid string with two descriptions with an AND
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_TwoDescriptions_With_AND()
		{
			string searchFilter = "description:(\"test desc \" AND another)";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(actual);

            searchFilter = "d:(\"test desc \" AND another)";
            actual = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(actual);
        }

        /// <summary>
        ///A test for Parse valid string with valid filter operator as value
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Valid_Use_FilterOperator_As_Value()
        {
            string[] searchFilters = { 
                                    "name:name:",  
                                    "n:n:",
                                    "name:n:", 
                                    "n:name:",
                                    "dt:dt:dt:",
                                    "dt:dt:dt: d:d:a",
                                    "d:name:dt:d:n:",
                                    "d:name:somestring",
                                    "dt:n: d:morestuff",
                                    "d:(name: dt:)",
                                    "d:(name: open)",
                                    "d:(tank d: d:)",
                                    "d:(tank d:)",
                                    "d:(d: d: d:)"
                                      };
           
            GenerateFilterTypes();
            foreach (bool actual in searchFilters.Select(searchFilter => _parser.Parse(searchFilter, _filterTypes, false)))
            {
                Assert.IsTrue(actual);
            }
        }

        ///A test for Parse filter operators used as values
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Valid_FilterValue_Operator()
        {           
            string[] searchFilters = { 
                                       "datatype:(d:)",
                                       "dt:(name:)",
                                       "description:(dt:)",
                                       "d:(n:)",
                                       "n:(d: OR N:)",
                                       "d:(name: AND bool)",
                                       "D:\"n:\""
                                      };
            GenerateFilterTypes();
            foreach (string searchFilter in searchFilters)
            {
                bool actual = _parser.Parse(searchFilter, _filterTypes, false);
                Assert.IsTrue(actual, searchFilter);                
            }
        }

        ///A test for Parse filter operators used as values with a mixture of filter operators and values in the filter string
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Valid_FilterValue_OperatorWithValues()
        {
            string[] searchFilters = { 
                                       "datatype:(someStuff d:)",
                                       "datatype:(d: someStuff)",
                                       "dt:(name: someStuff)",
                                       "dt:(someStuff name:)",
                                       "description:(dt: someStuff d: dt: someStuff)",
                                       "description:(someStuff dt: d: dt:)",
                                       "d:(n: someStuff d: dt: n:)",
                                       "d:(someStuff d: dt: n:)",
                                       "d:(d: d: d: d: dt: n:)",
                                       "d:(someStudff d: d:)",
                                       "d:(someStudff d: d: d:)",
                                       "d:(someStudff d: d: d: d:)",
                                       "d:(d: d: someStudff)",
                                       "d:(d: n: dt: d: d: someStudff)"
                                      };
            GenerateFilterTypes();
            foreach (string searchFilter in searchFilters)
            {
                bool actual = _parser.Parse(searchFilter, _filterTypes, false);
                Assert.IsTrue(actual);
            }
        }

        ///<summary>
        ///A test for Parse filter operators used as values 
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Valid_FilterValue_MultipleFiltersWithOperators()
        {
            string[] searchFilters = { 
                                       "datatype:(someStuff d:) dt:(someStuff name:)",
                                       "dt:(someStuff name:) datatype:(d: someStuff)",
                                       "dt:(name: someStuff) d:(someStudff d: d:)",
                                       "d:(someStudff d: d:) dt:(someStuff name:)",
                                       "dt:(someStuff n:) description:(dt: someStuff)",
                                       "description:(someStuff dt:) dt:(someStuff name:)",
                                       "dt:(someStuff n:) d:(n: someStuff)",
                                       "d:(someStuff n:) dt:(someStuff n:)",
                                       "dt:(someStuff n:) d:(someStuff d:)",
                                       "d:(d: d: d:) dt:(someStuff n:)",
                                       "dt:(someStuff n:) d:(someStudff d: d:)",
                                       "d:(d: d: someStudff) dt:(someStuff n: d: d: d: dt:) n:(some d: dt: d:) d:(some stuff here and more dt: d:)"
                                      };
            GenerateFilterTypes();
            foreach (string searchFilter in searchFilters)
            {
                bool actual = _parser.Parse(searchFilter, _filterTypes, false);
                Assert.IsTrue(actual, searchFilter);
            }
        }
		#endregion filter strings

		#region invalid filter strings

        private class InvalidFilter
        {
            /// <summary>
            /// Create an invalid filter object to support error validation in the unit tests
            /// </summary>
            /// <param name="infilter">The filter being tested</param>
            /// <param name="intoken">The invalid value</param>
            /// <param name="instart">The invalid value's start index</param>
            /// <param name="inlength">The length of the invalid value</param>
            public InvalidFilter(string infilter, string intoken, int instart, int inlength)
            {
                Filter = infilter;
                Token = intoken;
                Start = instart;
                Length = inlength;
            }
            private string _filter = string.Empty;
            public string Filter
            {
                get { return _filter; }
                internal set { _filter = value; }
            }
            private string _token = string.Empty;
            public string Token
            {
                get { return _token; }
                internal set { _token = value; }
            }
            private int _start = 0;
            public int Start
            {
                get { return _start; }
                internal set { _start = value; }
            }
            private int _len = 0;
            public int Length
            {
                get { return _len; }
                internal set { _len = value; }
            }
        }

		/// <summary>
		///A test for Parse invalid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Missing_RPAREN()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:(\"DINT\" OR \"SINT\" ", "(", 9, 1), 
                    new InvalidFilter("dt:(\"DINT\" OR \"SINT\" ", "(", 3, 1)
                                      };

            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_CLOSE_PARENTHESIS_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse invalid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Missing_LPAREN()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:\"DINT\" OR \"SINT\") ", ")", 25, 1), 
                    new InvalidFilter("dt:\"DINT\" OR \"SINT\") ", ")", 19, 1)
                                      };

            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value, "Unexpected token for: " + current.Filter);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex, "Unexpected starting index for: " + current.Filter);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length, "Unexpected length for: " + current.Filter);
                Assert.AreEqual(ERROR_SEARCH_OPEN_PARENTHESIS_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Dangling_OR()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:(\"DINT\" OR )", "OR", 17, 2), 
                    new InvalidFilter("dt:(\"DINT\" OR )", "OR", 11, 2)
                                      };

            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_FILTER_VALUE_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Dangling_OR2()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:(\"DINT\" OR)", "OR", 17, 2), 
                    new InvalidFilter("dt:(\"DINT\" OR)", "OR", 11, 2)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_FILTER_VALUE_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Search2()
		{
			string searchFilter = "DINT";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsFalse(actual);
            Assert.AreEqual(searchFilter, _parser.FilterDefinition.ErrorToken.Value);
            Assert.AreEqual(0, _parser.FilterDefinition.ErrorToken.StartingIndex);
            Assert.AreEqual(4, _parser.FilterDefinition.ErrorToken.Length);
            Assert.AreEqual(ERROR_SEARCH_SEARCHING_NOT_SUPPORTED, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
		}

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Missing_FilterValue()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:", "datatype:", 0, 9), 
                    new InvalidFilter("dt:", "dt:", 0, 3),
                    new InvalidFilter("name:", "name:", 0, 5),
                    new InvalidFilter("n:", "n:", 0, 2),
                    new InvalidFilter("description:", "description:", 0, 12),
                    new InvalidFilter("d:", "d:", 0, 2),
                    new InvalidFilter("N:AND", "N:", 0, 2),
                    new InvalidFilter("N:a OR dt:", "dt:", 7, 3),
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_FILTER_VALUE_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Missing_RPAREN2()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:(kdkdkd", "(", 9, 1), 
                    new InvalidFilter("dt:(wxy", "(", 3, 1), 
                    new InvalidFilter("name:(abcde", "(", 5, 1), 
                    new InvalidFilter("n:(foobar", "(", 2, 1), 
                    new InvalidFilter("description:(junkyjunk", "(", 12, 1), 
                    new InvalidFilter("d:(mayday", "(", 2, 1)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_CLOSE_PARENTHESIS_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Missing_LPAREN2()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:klad;jf OR dkdkd)", ")", 25, 1), 
                    new InvalidFilter("dt:klad;jf OR dkdkd)", ")", 19, 1), 
                    new InvalidFilter("name:klad;jf OR dkdkd)", ")", 21, 1), 
                    new InvalidFilter("n:klad;jf OR dkdkd)", ")", 18, 1), 
                    new InvalidFilter("description:klad;jf OR dkdkd)", ")", 28, 1), 
                    new InvalidFilter("d:klad;jf OR dkdkd)", ")", 18, 1),
                    new InvalidFilter("d:)", ")", 2, 1),
                    new InvalidFilter("D:\" \" OR dt)", ")", 11, 1),
                    new InvalidFilter("N:array OR n:)", ")", 13, 1)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value, "Unexpected token for: " + current.Filter);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex, "Unexpected starting index for: " + current.Filter);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length, "Unexpected length for: " + current.Filter);
                Assert.AreEqual(ERROR_SEARCH_OPEN_PARENTHESIS_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Missing_QUOTE()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("d\" \"", "d\"", 0, 2),
                    new InvalidFilter("d\"", "d\"", 0, 2),
					new InvalidFilter("valu\"e", "valu\"e", 0, 6),
                    new InvalidFilter("flag\"", "flag\"", 0, 5),
                    new InvalidFilter("D:\"star\"flag\"", "flag\"", 8, 5),
                    new InvalidFilter("datatype:\"DINT", "\"DINT", 9, 5),
                    new InvalidFilter("dt:\"REAL", "\"REAL", 3, 5),
                    new InvalidFilter("name:\"ALARM", "\"ALARM", 5, 6),
                    new InvalidFilter("n:\"PHASE", "\"PHASE", 2, 6),
                    new InvalidFilter("description:\"DINT", "\"DINT", 12, 5),
                    new InvalidFilter("d:\"DINT", "\"DINT", 2, 5)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_QUOTATION_MARK_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

        /// <summary>
        ///A test for Parse invalid string with misplaced quotes
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_QuotesOnlyInSearchORFilterStatements()
        {
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype\"DINT\"", "datatype\"DINT\"", 0, 14), 
                    new InvalidFilter("dt\"DINT\"", "dt\"DINT\"", 0, 8),
                    new InvalidFilter("d\"\"", "d\"\"", 0, 3),                                        
                    new InvalidFilter("d:a\"\"a","a\"\"a",2,4),
                    new InvalidFilter("d:a\"\"","a\"\"",2,3),
                    new InvalidFilter("d:a\"a\"","a\"a\"",2,4),
                    new InvalidFilter("dt:(\"a\" OR \"\"array\"","",11,0)                      
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters)
            {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Token.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_QUOTATION_MARKS_INCORRECT, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage,"Error message = " + _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage + " for " + current.Filter);
            }
        }

        /// <summary>
        ///A test for Parse invalid string with empty quotes
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_InvalidQuotes()
        {
            InvalidFilter[] filters = { 
                    new InvalidFilter("\"\"", "\"\"", 0, 2), 
                    new InvalidFilter("d:\"\"", "\"\"", 2, 2),
                    new InvalidFilter("d:(\"\")", "\"\"", 3, 2),
                    new InvalidFilter("N:\"\" AND dt:OR", "\"\"", 2, 2),
                    new InvalidFilter("n:(\"\") AND dt::", "\"\"", 3, 2)                    
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters)
            {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(string.Empty, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex,"Error Start Index wrong");
                Assert.AreEqual(0, _parser.FilterDefinition.ErrorToken.Length,"Error length wrong");
                Assert.AreEqual(ERROR_SEARCH_QUOTATION_MARKS_INCORRECT, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
        }

        /// <summary>
        ///A test for Parse invalid string with only whitespace
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_OnlyWhitespace()
        {
            InvalidFilter[] filters = { 
                    new InvalidFilter(" ", " ", 0, 1), 
                    new InvalidFilter("    ", "    ", 0, 4),                     
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters)
            {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(string.Empty, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(0, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_CANNOT_START_WITH_SPACE, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
        }

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Missing_LQUOTE()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:DINT\"", "DINT\"", 9, 5),
                    new InvalidFilter("dt:REAL\"", "REAL\"", 3, 5),
                    new InvalidFilter("name:ALARM\"", "ALARM\"", 5, 6),
                    new InvalidFilter("n:PHASE\"", "PHASE\"", 2, 6),
                    new InvalidFilter("description:DINT\"", "DINT\"", 12, 5),
                    new InvalidFilter("d:DINT\"", "DINT\"", 2, 5)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_QUOTATION_MARK_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Missing_NameValue()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:\"DINT\" name:", "name:", 16, 5),
                    new InvalidFilter("datatype:\"REAL\" n:", "n:", 16, 2),
                    new InvalidFilter("dt:\"SINT\" name:", "name:", 10, 5),
                    new InvalidFilter("dt:\"DINT\" n:", "n:", 10, 2)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_FILTER_VALUE_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		///A test for Parse valid string with parens
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_SearchStatement()
		{
			string searchFilter = "booggie=woogie";
			GenerateFilterTypes();
			bool actual = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsFalse(actual);
            Assert.AreEqual("booggie=woogie", _parser.FilterDefinition.ErrorToken.Value);
            Assert.AreEqual(0, _parser.FilterDefinition.ErrorToken.StartingIndex);
            Assert.AreEqual(14, _parser.FilterDefinition.ErrorToken.Length);
            Assert.AreEqual(ERROR_SEARCH_SEARCHING_NOT_SUPPORTED, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
		}

		/// <summary>
		/// Parse_Invalid_Dangling_OR3
		/// </summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Dangling_OR3()
		{
            InvalidFilter[] filters = { 
                                new InvalidFilter("front AND", "AND", 6, 3),
                                new InvalidFilter("name:dddd OR", "OR", 10, 2),
                                new InvalidFilter("n:ddddeee OR", "OR", 10, 2)
                                      };
            GenerateFilterTypes();            
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, true);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_FILTER_STATEMENT_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		/// Parse_Invalid_Leading_OR
		/// </summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Leading_OR()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("OR name:ggggg", "OR", 0, 2),
                    new InvalidFilter("OR n:abc", "OR", 0, 2)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(string.Empty, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(0, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_KEYWORD_INCORRECTLY_USED, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		/// Parse_Invalid_Leading_OR_Value
		/// </summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Leading_OR_Value()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("name:(OR ggggg)", "OR", 6, 2),
                    new InvalidFilter("n:(OR ggggg)", "OR", 3, 2)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(string.Empty, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(0, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_KEYWORD_INCORRECTLY_USED, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}
        /// <summary>
        /// Parse_Invalid_Exact Match with only a logic operator
        /// </summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Invalid_OR_AND_Value()
        {
            InvalidFilter[] filters = { 
                    new InvalidFilter("OR", "OR", 0, 2),
                    new InvalidFilter("AND", "AND", 0, 3),
                    new InvalidFilter("AND bool", "AND", 0, 3)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters)
            {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(string.Empty, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(0, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_KEYWORD_INCORRECTLY_USED, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
        }
		/// <summary>
		/// Parse_Invalid_Outer_Parens
		/// </summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_Outer_Parens()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("(datatype:DINT)", "(", 0, 1),
                    new InvalidFilter("(dt:ALARM)", "(", 0, 1),
                    new InvalidFilter("(name:foobar)", "(", 0, 1),
                    new InvalidFilter("(n:junkyjunk)", "(", 0, 1),
                    new InvalidFilter("(description:mystuff)", "(", 0, 1),
                    new InvalidFilter("(d:otherstuff)", "(", 0, 1),
                    new InvalidFilter("()", "(", 0, 1),
                    new InvalidFilter("d()", "(", 1, 1),
                    new InvalidFilter("d(", "(", 1, 1),
                    new InvalidFilter("d)", ")", 1, 1),
                    new InvalidFilter("text(", "(", 4, 1),
                    new InvalidFilter("text)", ")", 4, 1),
                    new InvalidFilter("d )", ")", 2, 1),
                    new InvalidFilter(")", ")", 0, 1),
                    new InvalidFilter("(", "(", 0, 1),
                    new InvalidFilter("D:string()", "(", 8, 1),
                    new InvalidFilter("D:string(", "(", 8, 1),
                    new InvalidFilter("D:\" \" OR dt(", "(", 11, 1)                    
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(string.Empty, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(0, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_PARENTHESES_MUST_SURROUND_FILTER_VALUES, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		/// Parse_Valid_lowercase_or
		/// </summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Valid_lowercase_or()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:(\"DINT\" or \"SINT\")", "", 0, 0),
                    new InvalidFilter("dt:(\"ALARM\" or \"PHASE\")", "", 0, 0),
                    new InvalidFilter("name:(\"foo\" or \"bar\")", "", 0, 0),
                    new InvalidFilter("n:(\"junk\" or \"trash\")", "", 0, 0)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsTrue(actual);
            }
		}

		/// <summary>
		/// A test for Parse invalid string &
		/// </summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_ampersand()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("name:Boundary_Test & datatype:Level", "&", 19, 1),
                    new InvalidFilter("name:Boundary_Test & dt:Level", "&", 19, 1),
                    new InvalidFilter("n:Boundary_Test & datatype:Level", "&", 16, 1)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_SEARCHING_NOT_SUPPORTED, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse invalid string whitespace
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_WhiteSpace()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:                        bool", "datatype:", 0, 9),
                    new InvalidFilter("dt:                        bool", "dt:", 0, 3),
                    new InvalidFilter("name:                        bool", "name:", 0, 5),
                    new InvalidFilter("n:                        bool", "n:", 0, 2),
                    new InvalidFilter("d: ", "d:", 0, 2)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_DELETE_BLANK_SPACES, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

		/// <summary>
		///A test for Parse invalid string whitespace
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_Parse_Invalid_WhiteSpace2()
		{
            InvalidFilter[] filters = { 
                    new InvalidFilter("datatype:bo ol", "ol", 12, 2),
                    new InvalidFilter("dt:ph ase", "ase", 6, 3),
                    new InvalidFilter("name:foobar me", "me", 12, 2),
                    new InvalidFilter("n:junk er", "er", 7, 2)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_SEARCHING_NOT_SUPPORTED, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
		}

        /// <summary>
        ///A test for Parse invalid string missing blank space
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Invalid_Miss_BlankSpace()
        {
            InvalidFilter[] filters = { 
                    new InvalidFilter("N:(\"aoi\"\"array\")", "array", 8, 5),         
                    new InvalidFilter("Dt:(\"aoi\"OR\"array\")", "OR\"array\"", 9, 9),
                    new InvalidFilter("Dt:(\"aoi\"OR \"array\")", "OR", 9, 2),
                    new InvalidFilter("Dt:(\"aoi\" OR\"array\")", "OR\"array\"", 10, 9)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters)
            {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_BLANK_SPACE_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
        }

        ///<summary>
        ///A test for open and close parens with no value inside
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_Invalid_Parens_NoValue()
        {
            InvalidFilter[] filters = {  
                    new InvalidFilter("name:()", "name:", 0, 5),
                    new InvalidFilter("dt:(  ) n:foo", "dt:", 0, 3),
                    new InvalidFilter("name:foo d:()", "d:", 9, 2),
                    new InvalidFilter("name:bar dt:(  )", "dt:", 9, 3)
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters) {
                bool actual = _parser.Parse(current.Filter, _filterTypes, false);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_FILTER_VALUE_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
        }

        ///<summary>
        ///A test for white space missing
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_BlankSpaceMissing_NoValue()
        {
            InvalidFilter[] filters = {  
                    new InvalidFilter("n:(\"test\"AND )", "AND", 9, 3),
                    new InvalidFilter("dt:INT OR\"BOOL\"", "OR\"BOOL\"", 7, 8),
                    new InvalidFilter("d:(\"a\"c)", "c", 6, 1),
                    new InvalidFilter("\"a\"c", "c", 3, 1),
                    new InvalidFilter("\"a\"\"c\"", "c", 3, 1),
                    new InvalidFilter("\"a\" OR\"c\"", "OR\"c\"", 4, 5),
                    new InvalidFilter("n:\"a\"OR\"b\"","OR\"b\"",5,5), 
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters)
            {
                bool actual = _parser.Parse(current.Filter, _filterTypes, true);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_BLANK_SPACE_MISSING, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
        }

        ///<summary>
        ///A test for nested parenthesis
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_Parse_NestedParantheses_NoValue()
        {
            InvalidFilter[] filters = {  
                    new InvalidFilter("d:((a OR b) and (c OR d))", string.Empty, 2, 0),
                    new InvalidFilter("description:((a OR b) and (c OR d))",string.Empty,12 , 0),
                    new InvalidFilter("dt:((INT) OR (BOOL))", string.Empty, 3, 0)                    
                                      };
            GenerateFilterTypes();
            foreach (InvalidFilter current in filters)
            {
                bool actual = _parser.Parse(current.Filter, _filterTypes, true);
                Assert.IsFalse(actual);
                Assert.AreEqual(current.Token, _parser.FilterDefinition.ErrorToken.Value);
                Assert.AreEqual(current.Start, _parser.FilterDefinition.ErrorToken.StartingIndex);
                Assert.AreEqual(current.Length, _parser.FilterDefinition.ErrorToken.Length);
                Assert.AreEqual(ERROR_SEARCH_PARENTHESES_CANNOT_BE_NESTED, _parser.FilterDefinition.ErrorToken.SyntaxErrorMessage);
            }
        }
        #endregion invalid filter strings

		#region Apply Filter
		/// <summary>
		///A test for ApplyFilterTest with blank filter
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Blank()
		{
			//parse search string
			string searchFilter = "";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "counter", CommonDataType = "SINT"};
            bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);
		}

		/// <summary>
		///A test for ApplyFilterTest filter with a name and two DataTypes
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Name_2DataTypes()
		{
			//parse search string
			string searchFilter = "datatype:(\"DINT\" OR \"INT\") name:auto";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "auto_state", CommonDataType = "DINT" };
            bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            searchFilter = "dt:(\"DINT\" OR \"INT\") n:auto";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);

            //Do the same test for arrayed data type of DINT
            dataItem.CommonDataType = "DINT[33]";
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            //Do the same test for arrayed data type of INT
            dataItem.CommonDataType = "INT[2, 44, 77]";
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);

        }

		/// <summary>
		///A test for ApplyFilterTest filter with just a name
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Name()
		{
			//parse search string
			string searchFilter = "name:fred";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "fred", CommonDataType = "REAL" };
            bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            searchFilter = "n:FrEd";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with one datatype
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_DataType()
		{
			//parse search string
			string searchFilter = "datatype:\"BOOL\"";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "done", CommonDataType = "BOOL" };
            bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            searchFilter = "dt:\"bool\"";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);

            // Do same test for arrayed tag
            dataItem.CommonDataType = "BOOL[44, 33]";
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with just 2 data types
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_2_DataTypes()
		{
			//parse search string
			string searchFilter = "datatype:(\"DINT\" OR \"SINT\")";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "counter", CommonDataType = "SINT" };
            bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            // test scalar tag
            searchFilter = "dt:(\"DINT\" OR \"sint\")";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);

            // test arrayed tag
            dataItem.CommonDataType = "SINT[44, 33]";
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with Name OR DataType
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Name_OR_DataType()
		{
			//parse search string
			string searchFilter = "datatype:\"DINT\" OR name:Tag";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "myTag", CommonDataType = "BOOL" };
            bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "anything:", CommonDataType = "DINT" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsTrue(actual);

            // test for scalar ag results
            searchFilter = "dt:\"DINT\" OR name:Tag";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);
            searchFilter = "datatype:\"DINT\" OR n:Tag";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);
            searchFilter = "dt:\"DINT\" OR n:Tag";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);

            // test for arrayed tag results
            dataItem.CommonDataType = "BOOL[33]";
            dataItem2.CommonDataType = "DINT[44,66,88]";
            searchFilter = "dt:\"DINT\" OR n:Tag";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with digits
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_digits()
		{
			//parse search string
			string searchFilter = "name:9";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with with the space added to the digit for sorting
            DataItemBase dataItem = new DataItemBase() { CommonName = " 9", CommonDataType = "BOOL" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            searchFilter = "n:9";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with digits
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_digits_ExactMatch()
		{
			//parse search string
			string searchFilter = "name:\"9\"";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with the space added to the digit for sorting
            DataItemBase dataItem = new DataItemBase() { CommonName = " 9", CommonDataType = "BOOL" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            searchFilter = "n:\"9\"";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
        }
		
		/// <summary>
		///A test for ApplyFilterTest filter name with 2 matchs and one fail
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Name_2Matches_1Fail()
		{
			//parse search string
			string searchFilter = "name:B";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "bee", CommonDataType = "BOOL" };
            bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "anyB:", CommonDataType = "BOOL" };
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem3 = new DataItemBase() { CommonName = "notMe:", CommonDataType = "DINT" };
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
			Assert.IsFalse(actual);

            searchFilter = "n:b";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
            Assert.IsFalse(actual);
        }


		/// <summary>
		///A test for ApplyFilterTest filter name and datatype filter with no matchs 
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Name_DataType_AND_NoMatches()
		{
			//parse search string
			string searchFilter = "name:c, datatype:BOOL";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "bee", CommonDataType = "BOOL" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "anyB:", CommonDataType = "DINT" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem3 = new DataItemBase() { CommonName = "notMe:", CommonDataType = "DINT" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
			Assert.IsFalse(actual);

            searchFilter = "n:c, dt:bool";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
            Assert.IsFalse(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter name and datatype filter with 2 matches 
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Name_DataType_OR_2Matches()
		{
			//parse search string
			string searchFilter = "name:c, datatype:BOOL";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "free", CommonDataType = "BOOL" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "anyC:", CommonDataType = "DINT" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem3 = new DataItemBase() { CommonName = "notMe:", CommonDataType = "DINT" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
			Assert.IsFalse(actual);

            searchFilter = "n:c dt:bool";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
            Assert.IsFalse(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with two word description
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Desc_TwoWords()
		{
			//parse search string
			string searchFilter = "description:\"some desc\"";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "This is my description" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "This is some description"};
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem3 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "This is some de" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem4 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "This is the description of something" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem4, ReturnFieldValue);
			Assert.IsFalse(actual);

            searchFilter = "d:\"some desc\"";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem4, ReturnFieldValue);
            Assert.IsFalse(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with two different descriptions
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Desc_BothWords()
		{
			//parse search string
			string searchFilter = "description:(\"some\" \"desc\")";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "This is my description" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "This is a description of something" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsTrue(actual);

            searchFilter = "d:(\"some\" \"desc\")";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with quotes in searched descriptions
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Desc_Quotes()
		{
			//parse search string
			string searchFilter = "description:(\"this tag is awesome\")";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "this tag is awesome" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "this tag is \"really\" awesome" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem3 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "this \"tag\" is awesome" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem4 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "this 'tag' is awesome" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem4, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem5 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "this \"tag\" is really awesome" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem5, ReturnFieldValue);
			Assert.IsFalse(actual);

            searchFilter = "d:(\"this tag is awesome\")";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem4, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem5, ReturnFieldValue);
            Assert.IsFalse(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with quotes in searched descriptions
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Desc_TrailingSpaces()
		{
			//parse search string
			string searchFilter = "description:\"test desc \"";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "test desc  " };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "test desc " };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem3 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "test desc" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem4 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "test desc" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem4, ReturnFieldValue);
			Assert.IsFalse(actual);

            searchFilter = "d:\"test desc \"";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem4, ReturnFieldValue);
            Assert.IsFalse(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with quotes in searched descriptions
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Desc_LeadingSpaces()
		{
			//parse search string
			string searchFilter = "description:(\" test desc\")";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "  test desc" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = " test desc" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem3 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "test desc" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
			Assert.IsFalse(actual);

            searchFilter = "d:(\" test desc\")";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
            Assert.IsFalse(actual);
        }

		/// <summary>
		///A test for ApplyFilterTest filter with quotes in search string
		///</summary>
		[TestMethod()]
		public void SearchFilterParser_ApplyFilterTest_Desc_SearchQuotes()
		{
			//parse search string
			string searchFilter = "description:\"the 'phone' is ringing\"";
			GenerateFilterTypes();
			//parser should not fail
			bool result = _parser.Parse(searchFilter, _filterTypes, false);
			Assert.IsTrue(result);

            //create dataitems to compare with
            DataItemBase dataItem = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "the 'phone' is ringing" };
			bool actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
			Assert.IsTrue(actual);

            //create dataitems to compare with
            DataItemBase dataItem2 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "the phone is ringing" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
			Assert.IsFalse(actual);

            //create dataitems to compare with
            DataItemBase dataItem3 = new DataItemBase() { CommonName = "TagName", CommonDataType = "DINT", CommonDescription = "the phone is not ringing" };
			actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
			Assert.IsFalse(actual);

            searchFilter = "d:\"the 'phone' is ringing\"";
            result = _parser.Parse(searchFilter, _filterTypes, false);
            Assert.IsTrue(result);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem, ReturnFieldValue);
            Assert.IsTrue(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem2, ReturnFieldValue);
            Assert.IsFalse(actual);
            actual = _parser.FilterDefinition.ApplyViewFilter(dataItem3, ReturnFieldValue);
            Assert.IsFalse(actual);
        }
		#endregion Apply Filter

        #region ValidateFiltervalueTests

        ///<summary>
        ///A test for ValidateFilterValue this logic is not expected to be reached since the string will be modified to avoid this error
        /// before this method is called.
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ValidateFilterValue_EmptyQuotes()
        {
            //ARRANGE
            GenerateFilterTypes();    
            SearchFilterParser target = new SearchFilterParser();
            PrivateObject targetPrivate = new PrivateObject(target);

            target.FilterDefinition = new SearchFilterDefinition(_filterTypes);
            //target.FilterDefinition.FilterSearchState = SearchFilterDefinition.FilterSearchStateEnum.UseFilter;
            target.TokenCollection.Clear();

            string searchText = "datatype:(\"\")";
            targetPrivate.Invoke("ParseStringIntoTokens", searchText);
            //index of TokenCollection for the value that we want to validate
            int valuegroup = 2; //This is token \"\"
            
            //ACT
            bool result = (bool)targetPrivate.Invoke("ValidateFilterValues", valuegroup);

            //ASSERT
            Assert.IsFalse(result);            
            Assert.IsTrue(target.FilterDefinition.ErrorToken.SyntaxErrorMessage == ERROR_SEARCH_QUOTATION_MARKS_INCORRECT);
        }

        ///<summary>
        ///A test for ValidateFilterValue this logic is not expected to be reached since the string will be modified to avoid this error
        /// before this method is called.
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ValidateFilterValue_FilterOperatorGroup_ChangedtoValueGroup()
        {
            //ARRANGE
            GenerateFilterTypes();
            SearchFilterParser target = new SearchFilterParser();
            PrivateObject targetPrivate = new PrivateObject(target);

            target.FilterDefinition = new SearchFilterDefinition(_filterTypes);
            //target.FilterDefinition.FilterSearchState = SearchFilterDefinition.FilterSearchStateEnum.UseFilter;
            target.TokenCollection.Clear();

            string searchText = "decription:(n:)";
            targetPrivate.Invoke("ParseStringIntoTokens", searchText);
            //index of TokenCollection for the value that we want to validate
            int valuegroup = 2; //This is token n:

            //ACT
            bool result = (bool)targetPrivate.Invoke("ValidateFilterValues", valuegroup);

            //ASSERT
            Assert.IsTrue(result);
            Assert.IsTrue(target.TokenCollection[2].ParseGroup == SearchFilterParser.ValueGroup);            
        }

        ///<summary>
        ///A test for ValidateFilterValue this logic is not expected to be reached since the string will be modified to avoid this error
        /// before this method is called.
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ValidateFilterValue_FilterOperatorGroupThroughStateMachine_ChangedtoValueGroup()
        {
            //ARRANGE
            GenerateFilterTypes();
            SearchFilterParser target = new SearchFilterParser();
            PrivateObject targetPrivate = new PrivateObject(target);

            target.FilterDefinition = new SearchFilterDefinition(_filterTypes);
            //target.FilterDefinition.FilterSearchState = SearchFilterDefinition.FilterSearchStateEnum.UseFilter;
            target.TokenCollection.Clear();

            string searchText = "decription:(n:)";
            targetPrivate.Invoke("ParseStringIntoTokens", searchText);
            //index of TokenCollection for the value that we want to validate
            int valuegroup = 1; //This is token (, allows the search text to go through the state machine

            //ACT
            bool result = (bool)targetPrivate.Invoke("ValidateFilterValues", valuegroup);

            //ASSERT
            Assert.IsTrue(result);
            Assert.IsTrue(target.TokenCollection[2].ParseGroup == SearchFilterParser.ValueGroup);
        }

        ///<summary>
        ///A test for ValidateFilterValue this logic is not expected to be reached since the string will be modified to avoid this error
        /// before this method is called.
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ValidateFilterValue_BaseOperatorGroup_Error()
        {
            //ARRANGE
            GenerateFilterTypes();
            SearchFilterParser target = new SearchFilterParser();
            PrivateObject targetPrivate = new PrivateObject(target);

            target.FilterDefinition = new SearchFilterDefinition(_filterTypes);
            //target.FilterDefinition.FilterSearchState = SearchFilterDefinition.FilterSearchStateEnum.UseFilter;
            target.TokenCollection.Clear();

            string searchText = "decription:(tank AND)";
            targetPrivate.Invoke("ParseStringIntoTokens", searchText);
            //index of TokenCollection for the value that we want to validate
            int valuegroup = 4; //This is token AND

            //ACT
            bool result = (bool)targetPrivate.Invoke("ValidateFilterValues", valuegroup);

            //ASSERT
            Assert.IsFalse(result);
            Assert.IsTrue(target.FilterDefinition.ErrorToken.SyntaxErrorMessage == ERROR_SEARCH_FILTER_VALUE_MISSING);
        }

        ///<summary>
        ///A test for ValidateFilterValue, this logic is not expected to be reached since the string will be modified to avoid this error
        /// before this method is called.
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ValidateFilterValue_BaseOperatorGroupNotFound_Error()
        {
            //ARRANGE
            GenerateFilterTypes();
            SearchFilterParser target = new SearchFilterParser();
            PrivateObject targetPrivate = new PrivateObject(target);

            target.FilterDefinition = new SearchFilterDefinition(_filterTypes);
            //target.FilterDefinition.FilterSearchState = SearchFilterDefinition.FilterSearchStateEnum.UseFilter;
            target.TokenCollection.Clear();

            string searchText = "decription:(tank full)";
            targetPrivate.Invoke("ParseStringIntoTokens", searchText);
            //index of TokenCollection for the value that we want to validate
            int valuegroup = 1; //This is token (, this will allow the tokens to go through the state machine

            //ACT
            bool result = (bool)targetPrivate.Invoke("ValidateFilterValues", valuegroup);

            //ASSERT
            Assert.IsFalse(result);
            Assert.IsTrue(target.FilterDefinition.ErrorToken.SyntaxErrorMessage == ERROR_SEARCH_EXPECTED_OPERATOR);
        }
	    #endregion ValidateFiltervalueTests
	}
}
