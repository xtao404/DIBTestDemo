/*************************************************************************************
                                                                     
   ViewE DIBQueryConditionBuilderTest Class
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.UI.DIBQuery;

#endregion

namespace DataItemBrowserUT
{

    /// <summary>
    /// Summary description for DIBQueryConditionBuilderTest
    /// </summary>
    [TestClass]
    public class DIBQueryConditionHelperTest
    {

        #region BuildQueryConditionItem

        public static readonly string NameIdentifier = "DisplayName";
        public static readonly string DataTypeIdentifier = "Definition.DisplayName";
        public static readonly string DescriptionIdentifier = "Description";
        public static readonly string AlternateDescriptionIdentifier = "Definition.Description";

        /// <summary>
        /// Convert from a SearchFilterItem to a QueryConditionItem.
        /// Validate the QueryConditionItem
        /// simple filter statement n:tag
        /// </summary>
        [TestMethod]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void BuildQueryConditionItemFor_FilterStatement_SimpleTest()
        {
            SearchFilterDefinition.StatementLogic statementLogic = SearchFilterDefinition.StatementLogic.NONE;
            string identifier = NameIdentifier;

            // If we are searching for Description, we want to add an "alternate identifier" here. 
            // If the "identifier" resolves to an empty string, resolve the value using "alternate identifier". 
            // Per B-24397, the DIB business rule we want to observe here is that if we are searching on Description and the tag does not have an user explicit description set on it, 
            // use the data type description (pass through description)
            string alternateIdentifier = String.Empty;
            bool isExactMatch = false;
            string valueNoQuotes = "tag";
            //Special case for data types if an array qualifier is part of the search text or exact match,
            // we need to set the identifier to the column name since the QSP formats array datatypes special
            bool isIdentifierColumnConfigKey = false;

            RockwellAutomation.UI.CommonControls.SearchFilter.SearchFilterItem newSearchFilterItem = new SearchFilterItem.CreateBuilder()
                .SetIdentifier(identifier)
                .SetAlternateIdentifier(alternateIdentifier)
                .SetIsExactMatch(isExactMatch)
                .SetLogicOperator(statementLogic)
                .SetValue(valueNoQuotes)
                .SetIsIdentifierColumnConfigKey(isIdentifierColumnConfigKey)
                .Build();

            QueryConditionItem queryConditionItem = DIBQueryConditionHelper.BuildQueryConditionItemFor(newSearchFilterItem);
            ValidateQueryConditionItemCreation(newSearchFilterItem, queryConditionItem);
        }

        private void ValidateQueryConditionItemCreation(SearchFilterItem newSearchFilterItem, QueryConditionItem queryConditionItem)
        {
            Assert.IsTrue(queryConditionItem.GetAlternateIdentifier == newSearchFilterItem.GetAlternateIdentifier);
            Assert.IsTrue(queryConditionItem.GetIdentifier == newSearchFilterItem.GetIdentifier);
            Assert.IsTrue(queryConditionItem.GetLogicOperator == LogicOperatorType(newSearchFilterItem.GetLogicOperator));
            Assert.IsTrue(queryConditionItem.GetValue == newSearchFilterItem.GetValue);
            Assert.IsTrue(queryConditionItem.IsExactMatch == newSearchFilterItem.IsExactMatch);
            Assert.IsTrue(queryConditionItem.IsIdentifierColumnConfigKey == newSearchFilterItem.IsIdentifierColumnConfigKey);
        }

        private LogicOperatorType LogicOperatorType(SearchFilterDefinition.StatementLogic statementLogic)
        {
            LogicOperatorType logic = (statementLogic == SearchFilterDefinition.StatementLogic.OR ? RockwellAutomation.Client.Services.Query.LogicOperatorType.OR : RockwellAutomation.Client.Services.Query.LogicOperatorType.AND);
            return logic;
        }

        /// <summary>
        /// Convert from a SearchFilterItem to a QueryConditionItem.
        /// Validate the QueryConditionItem
        ///  description case, d:tank
        /// </summary>
        [TestMethod]
        public void BuildQueryConditionItemFor_FilterStatement_DescriptionTest()
        {
            SearchFilterDefinition.StatementLogic statementLogic = SearchFilterDefinition.StatementLogic.NONE;
            string identifier = DescriptionIdentifier;
            // If we are searching for Description, we want to add an "alternate identifier" here. 
            // If the "identifier" resolves to an empty string, resolve the value using "alternate identifier". 
            // Per B-24397, the DIB business rule we want to observe here is that if we are searching on Description and the tag does not have an user explicit description set on it, 
            // use the data type description (pass through description)
            string alternateIdentifier = SearchFilterDefinition.AlternateDescriptionIdentifier;
            bool isExactMatch = false;
            string valueNoQuotes = "tank";

            //Special case for data types if an array qualifier is part of the search text or exact match,
            // we need to set the identifier to the column name since the QSP formats array datatypes special
            bool isIdentifierColumnConfigKey = false;

            RockwellAutomation.UI.CommonControls.SearchFilter.SearchFilterItem newSearchFilterItem = new SearchFilterItem.CreateBuilder()
                .SetIdentifier(identifier)
                .SetAlternateIdentifier(alternateIdentifier)
                .SetIsExactMatch(isExactMatch)
                .SetLogicOperator(statementLogic)
                .SetValue(valueNoQuotes)
                .SetIsIdentifierColumnConfigKey(isIdentifierColumnConfigKey)
                .Build();

            QueryConditionItem queryConditionItem = DIBQueryConditionHelper.BuildQueryConditionItemFor(newSearchFilterItem);
            ValidateQueryConditionItemCreation(newSearchFilterItem, queryConditionItem);
        }

        /// <summary>
        /// Convert from a SearchFilterItem to a QueryConditionItem.
        /// Validate the QueryConditionItem
        ///  datatype case, dt:bool
        /// </summary>
        [TestMethod]
        public void BuildQueryConditionItemFor_FilterStatement_DatatypeTest()
        {
            SearchFilterDefinition.StatementLogic statementLogic = SearchFilterDefinition.StatementLogic.NONE;
            string identifier = DataTypeIdentifier;
            // If we are searching for Description, we want to add an "alternate identifier" here. 
            // If the "identifier" resolves to an empty string, resolve the value using "alternate identifier". 
            // Per B-24397, the DIB business rule we want to observe here is that if we are searching on Description and the tag does not have an user explicit description set on it, 
            // use the data type description (pass through description)
            string alternateIdentifier = string.Empty;
            bool isExactMatch = false;
            string valueNoQuotes = "bool";

            //Special case for data types if an array qualifier is part of the search text or exact match,
            // we need to set the identifier to the column name since the QSP formats array datatypes special
            bool isIdentifierColumnConfigKey = false;

            RockwellAutomation.UI.CommonControls.SearchFilter.SearchFilterItem newSearchFilterItem = new SearchFilterItem.CreateBuilder()
                .SetIdentifier(identifier)
                .SetAlternateIdentifier(alternateIdentifier)
                .SetIsExactMatch(isExactMatch)
                .SetLogicOperator(statementLogic)
                .SetValue(valueNoQuotes)
                .SetIsIdentifierColumnConfigKey(isIdentifierColumnConfigKey)
                .Build();

            QueryConditionItem queryConditionItem = DIBQueryConditionHelper.BuildQueryConditionItemFor(newSearchFilterItem);
            ValidateQueryConditionItemCreation(newSearchFilterItem, queryConditionItem);
        }

        /// <summary>
        /// Convert from a SearchFilterItem to a QueryConditionItem.
        /// Validate the QueryConditionItem
        ///  datatype case, dt:[30]
        /// </summary>
        [TestMethod]
        public void BuildQueryConditionItemFor_FilterStatement_DatatypeWithArrayQualifierTest()
        {
            SearchFilterDefinition.StatementLogic statementLogic = SearchFilterDefinition.StatementLogic.NONE;
            string identifier = DataTypeIdentifier;
            // If we are searching for Description, we want to add an "alternate identifier" here. 
            // If the "identifier" resolves to an empty string, resolve the value using "alternate identifier". 
            // Per B-24397, the DIB business rule we want to observe here is that if we are searching on Description and the tag does not have an user explicit description set on it, 
            // use the data type description (pass through description)
            string alternateIdentifier = string.Empty;
            bool isExactMatch = false;
            string valueNoQuotes = "[30]";

            //Special case for data types if an array qualifier is part of the search text or exact match,
            // we need to set the identifier to the column name since the QSP formats array datatypes special
            bool isIdentifierColumnConfigKey = true;

            RockwellAutomation.UI.CommonControls.SearchFilter.SearchFilterItem newSearchFilterItem = new SearchFilterItem.CreateBuilder()
                .SetIdentifier(identifier)
                .SetAlternateIdentifier(alternateIdentifier)
                .SetIsExactMatch(isExactMatch)
                .SetLogicOperator(statementLogic)
                .SetValue(valueNoQuotes)
                .SetIsIdentifierColumnConfigKey(isIdentifierColumnConfigKey)
                .Build();

            QueryConditionItem queryConditionItem = DIBQueryConditionHelper.BuildQueryConditionItemFor(newSearchFilterItem);
            ValidateQueryConditionItemCreation(newSearchFilterItem, queryConditionItem);
        }

        /// <summary>
        /// Convert from a SearchFilterItem to a QueryConditionItem.
        /// Validate the QueryConditionItem
        /// n:tag OR d:tag
        /// </summary>
        [TestMethod]
        public void BuildQueryConditionItemFor_FilterStatement_NestedFilterTest()
        {
            SearchFilterDefinition.StatementLogic statementLogic = SearchFilterDefinition.StatementLogic.NONE;
            string identifier = null;
            // If we are searching for Description, we want to add an "alternate identifier" here. 
            // If the "identifier" resolves to an empty string, resolve the value using "alternate identifier". 
            // Per B-24397, the DIB business rule we want to observe here is that if we are searching on Description and the tag does not have an user explicit description set on it, 
            // use the data type description (pass through description)
            string alternateIdentifier = null;
            bool isExactMatch = false;
            string valueNoQuotes = null;

            //Special case for data types if an array qualifier is part of the search text or exact match,
            // we need to set the identifier to the column name since the QSP formats array datatypes special
            bool isIdentifierColumnConfigKey = false;

            SearchFilterItem.CreateBuilder newSearchFilterItem = new SearchFilterItem.CreateBuilder();
            newSearchFilterItem.SetIdentifier(identifier)
            .SetAlternateIdentifier(alternateIdentifier)
            .SetIsExactMatch(isExactMatch)
            .SetLogicOperator(statementLogic)
            .SetValue(valueNoQuotes)
            .SetIsIdentifierColumnConfigKey(isIdentifierColumnConfigKey);


            //nested filteritem[0]
            statementLogic = SearchFilterDefinition.StatementLogic.NONE;
            identifier = NameIdentifier;
            alternateIdentifier = string.Empty;
            isExactMatch = false;
            valueNoQuotes = "tag";
            isIdentifierColumnConfigKey = false;
            SearchFilterItem firstSearchFilterItem = new SearchFilterItem.CreateBuilder()
               .SetIdentifier(identifier)
               .SetAlternateIdentifier(alternateIdentifier)
               .SetIsExactMatch(isExactMatch)
               .SetLogicOperator(statementLogic)
               .SetValue(valueNoQuotes)
               .SetIsIdentifierColumnConfigKey(isIdentifierColumnConfigKey)
               .Build();
            newSearchFilterItem.AddItem(firstSearchFilterItem);

            //nested filteritem[1]
            statementLogic = SearchFilterDefinition.StatementLogic.OR;
            identifier = DescriptionIdentifier;
            alternateIdentifier = AlternateDescriptionIdentifier;
            isExactMatch = false;
            valueNoQuotes = "tag";
            isIdentifierColumnConfigKey = false;
            SearchFilterItem secondSearchFilterItem = new SearchFilterItem.CreateBuilder()
               .SetIdentifier(identifier)
               .SetAlternateIdentifier(alternateIdentifier)
               .SetIsExactMatch(isExactMatch)
               .SetLogicOperator(statementLogic)
               .SetValue(valueNoQuotes)
               .SetIsIdentifierColumnConfigKey(isIdentifierColumnConfigKey)
               .Build();
            newSearchFilterItem.AddItem(secondSearchFilterItem);

            SearchFilterItem searchFilterItem = newSearchFilterItem.Build();
            QueryConditionItem queryConditionItem = DIBQueryConditionHelper.BuildQueryConditionItemFor(searchFilterItem);
            ValidateQueryConditionItemCreation(searchFilterItem, queryConditionItem);
        }

        #endregion BuildQueryConditionItem
    }
}
