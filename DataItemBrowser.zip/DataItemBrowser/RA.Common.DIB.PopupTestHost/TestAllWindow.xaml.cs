using System;
using System.ComponentModel;
using System.Reflection;
using System.Windows;
using System.Windows.Data;
using RockwellAutomation.UI.DIBQuery;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using System.Collections.Generic;
using RockwellAutomation.UI.Windows;
using System.Globalization;

namespace RockwellAutomation.DesignTimeClient.PopUpGenericTestHost
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window, INotifyPropertyChanged
    {

        const string _NOT_AVAILABLE_LITERAL = "<Not available>";

        #region Constructor/Initialize

        public Window1()
        {
            this.DataContext = this;
        }

        /// <summary>
        /// window loaded 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.txLastHighLightedItem.Text = _NOT_AVAILABLE_LITERAL;
        }

        /// <summary>
        /// Check to see if there is an open DIB window whenever the whenever the popup test host window activates
        /// so we can set various variables that control the state of gui elements (for instance the property
        /// editor buttons should be disabled if a DIB window is currently open).  We also show an extra context
        /// menu item to show the open DIB window which might have gotten hidden behind other windows which can 
        /// happen and is a common annoyance when using the persist window and switching between windows/debugging)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Activated(object sender, EventArgs e)
        {
            Focus();
        }

        #endregion

        #region Properties/Variables/Dependency Properties

        private string _highLightedItem = string.Empty;
        public string HighlightedItem
        {
            get { return _highLightedItem; }
            set
            {
                if (_highLightedItem == value)
                    return;

                _highLightedItem = value;
                NotifyPropertyChanged("HighLightedItem");
            }
        }

        #endregion

        #region Closing

        /// <summary>
		/// Window closing
		/// </summary>
		/// <param name="e"></param>
		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);
            foreach (DIBContainerWindow dibWindow in this.GetAllOpenDibContainerWindows())
            {
                dibWindow.DIBClientManager.Shutdown();
                dibWindow.Close();
            }
            DIBWindow dibPersistedWindow = this.GetOpenDibWindowPersisted();
            if (dibPersistedWindow != null) dibPersistedWindow.DIBClientManager.Shutdown();
		}

        #endregion

        #region Events


        /// <summary>
        /// Handle the HighlightedItemChanged event from the PropertyEditorWithTagBrowser controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void DIBBrowser_HighlightedItemChanged(object sender, RoutedEventArgs e)
        {
            PropertyEditorWithTagBrowser propertyEditor = sender as PropertyEditorWithTagBrowser;
            if (propertyEditor != null)
            {
                HighlightedItem = propertyEditor.HighlightedItem;
                return;
            }

            RockwellAutomation.UI.Views.DataItemBrowser dib = sender as RockwellAutomation.UI.Views.DataItemBrowser;
            if (dib != null)
            {
                HighlightedItem = dib.HighlightedItem;
                return;
            }
        }

        #endregion

        private void Hyperlink_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            System.Diagnostics.Process.Start("http://usmkeviewedt02/arch/Generic_DIB");
        }

        private void Hyperlink_RequestDIBLaunch(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {

            Binding fontSizeBinding = new Binding("DesiredFontSize");
            Binding fontFamilyBinding = new Binding("DesiredFontFamily");

            fontSizeBinding.Source = this;
            fontFamilyBinding.Source = this;

            // Set the DIB Client Manager
            RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager viewManager;
            viewManager = RockwellAutomation.DesignTimeClient.PopUpGenericTestHost.Window1.GetDIBClientManagerFor(this.DIBClientManagerNames.SelectedItem.ToString());
            viewManager.InitialLaunchString = String.Empty;

            Boolean shouldPersistDIB = (bool)this.PersistWindowFromHyperLink.IsChecked;
            DIBWindow _browser = new DIBWindow(this.PersistWindowFromHyperLink, viewManager) { PersistWindow = shouldPersistDIB };

            // set the binding for the Font size and family
            _browser.SetBinding(DIBWindow.FontSizeProperty, fontSizeBinding);
            _browser.SetBinding(DIBWindow.FontFamilyProperty, fontFamilyBinding);

            _browser.HighlightedItemChangedEventHandler += new RoutedEventHandler(this.Browser_HighlightedItemChangedEventHandlerFromHyperLink);
            _browser.HighlightedItem = this.HighlightedItem;

            _browser.Initialize(viewManager.InitialLaunchString);
            if (shouldPersistDIB)
                _browser.ShowDialog();
            else
                _browser.Show();
        }
     
        /// <summary>
        /// Event Handler which responds to the browser's change in a HighLightedIem
        /// </summary>
        /// <param name="sender">Browser</param>
        /// <param name="e">Not used</param>
        void Browser_HighlightedItemChangedEventHandlerFromHyperLink(object sender, RoutedEventArgs e)
        {
            DIBWindow browser = (DIBWindow)sender;
            this.HighlightedItem = string.Format(CultureInfo.InvariantCulture, "{0}", browser.HighlightedItem);
        }


        /// <summary>
        /// Attempts to locate an open DIB window and returns that window if found
        /// </summary>
        /// <returns>Window to the open DIB window</returns>
        private DIBWindow GetOpenDibWindowPersisted()
        {
            DIBWindow openDib = null;

            foreach (Window win in Application.Current.Windows)
            {
                if (win != this && win is DIBWindow)
                {
                    if ((win as DIBWindow).PersistWindow)
                        openDib = win.IsVisible ? win as DIBWindow : null;
                    break; //since we know there's only one
                }
            }

            return openDib;
        }

        /// <summary>
        /// Attempts to locate an open DIB window and returns that window if found
        /// </summary>
        /// <returns>Window to the open DIB window</returns>
        private List<DIBContainerWindow> GetAllOpenDibContainerWindows()
        {
            List<DIBContainerWindow> openDIBS = new List<DIBContainerWindow>();
            foreach (Window win in Application.Current.Windows)
            {
                if (win != this && win is DIBContainerWindow)
                {
                    openDIBS.Add(win as DIBContainerWindow);
                }
            }
            return openDIBS;
        }


      
        #region INotifyPropertyChanged Members
        /// <summary>
        /// implements that INotifyPropertyChanged inteface method NotifyPropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        private void LaunchInContainerWindow_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new RockwellAutomation.UI.WindowsControl.DIBClient.DIBContainerWindow(
                this.DIBClientManagerNames.SelectedItem.ToString(), 
                txLaunchStringContainerWindow.Text);

            // Bind Font Size
            newWindow.SetBinding(
                RockwellAutomation.UI.WindowsControl.DIBClient.DIBContainerWindow.FontSizeProperty,
                new Binding("Value") { Source = this.FontSizeSlider });

            // Bind Font Family
            newWindow.SetBinding(
                RockwellAutomation.UI.WindowsControl.DIBClient.DIBContainerWindow.FontFamilyProperty,
                new Binding("SelectedItem") { Source = this.FontFamilyComboBox });

            // Get Highlighted item changed behavior
            newWindow.dib.HighlightedItemChanged += new RoutedEventHandler(DIBBrowser_HighlightedItemChanged);
            newWindow.dib.ItemSelected += new RoutedEventHandler(DIBBrowser_ContainerWindow_ItemSelected);

            newWindow.Show();
        }

        private void LaunchInContainerWindowSizeToContent_Click(object sender, RoutedEventArgs e)
        {
            var newWindow = new RockwellAutomation.UI.WindowsControl.DIBClient.DIBContainerWindowSizeToContent(
                this.DIBClientManagerNames.SelectedItem.ToString(),
                txLaunchStringContainerWindowSizeToContent.Text);

            // Bind Font Size
            newWindow.SetBinding(
                RockwellAutomation.UI.WindowsControl.DIBClient.DIBContainerWindow.FontSizeProperty,
                new Binding("Value") { Source = this.FontSizeSlider });

            // Bind Font Family
            newWindow.SetBinding(
                RockwellAutomation.UI.WindowsControl.DIBClient.DIBContainerWindow.FontFamilyProperty,
                new Binding("SelectedItem") { Source = this.FontFamilyComboBox });

            // Get Highlighted item changed behavior
            newWindow.dib.HighlightedItemChanged += new RoutedEventHandler(DIBBrowser_HighlightedItemChanged);
            newWindow.dib.ItemSelected += new RoutedEventHandler(DIBBrowser_ContainerWindow_ItemSelected);

            newWindow.Show();
        }

        private void DIBBrowser_ContainerWindow_ItemSelected(object sender, RoutedEventArgs e)
        {
            RockwellAutomation.UI.Views.DataItemBrowser dib = sender as RockwellAutomation.UI.Views.DataItemBrowser;
            if (dib == null) return;
            txLaunchStringContainerWindow.Text = dib.SelectedItem;
        }

        public static DIBClientManager GetDIBClientManagerFor(String dibClientManagerName)
        {
            if (dibClientManagerName.Contains("1. Tree View Simple"))
                return new RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager_1_TreeViewSimple();
            else if (dibClientManagerName.Contains("2. Tree View multi level"))
                return new RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager_2_TreeViewMultiSubChildren();
            else if (dibClientManagerName.Contains("3. Tree View File System Browser"))
                return new RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager_3_TreeViewFileSystemBrowser();
            else if (dibClientManagerName.Contains("4. Tree View To List View People Browser"))
                return new RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager_4_TreeViewToListView();
            else if (dibClientManagerName.Contains("5. List View XML File Browser"))
                return new RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager_5_ListView();
            else if (dibClientManagerName.Contains("6. Grid View File System Browser"))
                return new RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager_6_GridView();
            else
                return new RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager_6_GridView();
        }

        private void LocaleSelection_Selected(object sender, RoutedEventArgs e)
        {
            ComboBox box = (ComboBox)sender;
            ComboBoxItem item = (ComboBoxItem) box.SelectedValue;
            string localeId = item.Name;
            localeId = localeId.Replace("_", "-");
            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = new System.Globalization.CultureInfo(localeId);
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = new System.Globalization.CultureInfo(localeId);
        }
    }
}
