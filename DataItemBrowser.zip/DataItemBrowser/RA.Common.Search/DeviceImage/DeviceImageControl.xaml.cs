﻿/* ****************************************************************************
*
*  Copyright 2012 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System.Windows;
using System.Windows.Controls;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;

namespace RockwellAutomation.UI.CommonControls
{
    
    /// <summary>
    /// Interaction logic for DeviceImageControl.xaml
    /// </summary>
    public partial class DeviceImageControl : UserControl
    {
        
        #region private members
        /// <summary>
        /// presenter class
        /// </summary>
        private DeviceImagePresenter _presenter = null;
        #endregion private properties

        #region constructor

        /// <summary>
        /// constructor 
        /// </summary>
        public DeviceImageControl()
        {
            InitializeComponent();

         }
        #endregion constructor

 
        #region public dependency properties

        /// <summary>
        /// the factor to scale the entire image (default value = 1.0)
        /// </summary>
        public static DependencyProperty ScaleFactorProperty = DependencyProperty.Register("ScaleFactor",
                                typeof(double), typeof(DeviceImageControl), new PropertyMetadata(1.0d));
        /// <summary>
        /// scale factor property
        /// </summary>
        public double ScaleFactor
        {
            get { return (double)GetValue(DeviceImageControl.ScaleFactorProperty); }
            set { SetValue(DeviceImageControl.ScaleFactorProperty, value);}
        }


        

        /// <summary>
        /// hide controller (default value false)
        /// </summary>
        public static DependencyProperty HideDeviceProperty = DependencyProperty.Register("HideController",
                                typeof(bool), typeof(DeviceImageControl), new PropertyMetadata(false));
       
        /// <summary>
        /// property used to hide the controller section which displays larger icons with a controller in the 
        /// background 
        /// </summary>
        public bool HideController
        {
            get { return (bool)GetValue(DeviceImageControl.HideDeviceProperty); }
            set { SetValue(DeviceImageControl.HideDeviceProperty, value); }
        }

        #endregion  public dependency properties


        #region control events

              /// <summary>
        /// controller image presenter properties have changed
        /// </summary>
        /// <param name="sender">Controller Image presenter</param>
        /// <param name="e">property changed argument</param>
        void DeviceImagePresenter_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "TooltipEnabled")
            {
                //this is needed to interface with TooltipBehavior used in the DTC
                ToolTipService.SetIsEnabled(this, this._presenter.TooltipEnabled);
            }
        }
         /// <summary>
        /// DataContext changed handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DeviceImage_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            //remove any previous event listeners
            if (_presenter != null)
                _presenter.PropertyChanged -= new System.ComponentModel.PropertyChangedEventHandler(DeviceImagePresenter_PropertyChanged);

            _presenter = (this.DataContext as DeviceImagePresenter);
            //check if this is the DeviceImagePresenter. At initial load the datacontext will be Controller object until the 
            //the datacontext binding runs
            if (_presenter != null)
            {
                _presenter.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(DeviceImagePresenter_PropertyChanged);
            }
        }
 
      
        #endregion control events

    

        

    }
}
