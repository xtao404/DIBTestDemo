/* ****************************************************************************
*
*  Copyright 2009-2015 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System;
using System.Linq;
using System.Windows.Data;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Media;
using RockwellAutomation.UI.Models;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.Views;
using System.Globalization;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// Determine desired GridLength based on whether 
    /// SizeToContent is in effect
    /// </summary>
    [ValueConversion(typeof(bool), typeof(GridLength))]
    public class SizeToContentGridLength : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool sizeToContent = (bool)value;
            if (sizeToContent)
            {
                return GridLength.Auto;
            }
            else
            {
                return new GridLength(1, GridUnitType.Star);
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // We never intend to call this
            return null;
        }
    }

    /// <summary>
    /// Determine the desired HorizontalAlignment based on whether 
    /// SizeToContent is in effect
    /// </summary>
    [ValueConversion(typeof(bool), typeof(HorizontalAlignment))]
    public class SizeToContentHorizontalAlignment : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool sizeToContent = (bool)value;
            if (sizeToContent)
            {
                return HorizontalAlignment.Left;
            }
            else
            {
                return HorizontalAlignment.Stretch;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // We never intend to call this
            return null;
        }
    }

    /// <summary>
    /// On account of the behavior of the listbox (I believe because it's tied to an itemtemplate without design-time
    /// concrete data), which would like to expand its width to infinity in the design environment, we constrain
    /// it to '400' at design time, and 'Auto' at run-time.
    /// </summary>
    [ValueConversion(typeof(string), typeof(string))]
    public class UserControlWidthWhileDesigning : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool isInDesign = DesignerProperties.GetIsInDesignMode(new DependencyObject());
            if (isInDesign == true)
                return "400";

            return "Auto";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // We never intend to call this
            return null;
        }
    }

    /// <summary>
    /// this class adjust colors helper class 
    /// </summary>
    public static class ColorAdjuster
    {
        /// <summary>
        /// this method will lighten/darken any system color (RGBA), based on the weighting and opcaity
        /// </summary>
        /// <param name="startColor">original color (RGBA)</param>
        /// <param name="weight">weighting of lighten or darken each color part</param>
        /// <param name="opacity">opacity applied to each color</param>
        /// <returns></returns>
        public static Color AdjustColor(Color startColor, double weight, double opacity)
        {
            byte intensity = startColor.A;
            //when you are brightening a color tone down the opacity
            intensity = (byte)(255 * opacity);
            int iRed = (int)(startColor.R * weight);
            if (iRed > 255)
                iRed = 255;
            int iGreen = (int)(startColor.G * weight);
            if (iGreen > 255)
                iGreen = 255;
            int iBlue = (int)(startColor.B * weight);
            if (iBlue > 255)
                iBlue = 255;

            Color newColor = Color.FromArgb(intensity,
                (byte)(iRed),
                (byte)(iGreen),
                (byte)(iBlue));
            return newColor;
        }
    }

    /// <summary>
    /// color lightening converter class
    /// </summary>
    [ValueConversion(typeof(Color), typeof(Color))]
    public class LighteningColorConverter :IValueConverter
    {
        //default weighting used
        static double lWeight = 1.25;
        /// <summary>
        /// Convert method 
        /// </summary>
        /// <param name="value">unused</param>
        /// <param name="targetType"></param>
        /// <param name="parameter">opacity factor</param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            const double EPSILON = .001;
            double weight = lWeight;
            //the parameter is the opacity
            double opacity = System.Convert.ToDouble(parameter);
            //if the opacity is zero, go full intensity
            if (Math.Abs(opacity - 0.0) < EPSILON)
            {
                weight = 1.0F;
                opacity = 1.0F;
            }
            SolidColorBrush highlightBrush = SystemColors.HighlightBrush;
            //adjust the highlightBrush color based on the weight and opacity
            return ColorAdjuster.AdjustColor(highlightBrush.Color, weight, opacity);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }

    /// <summary>
    /// color lightening converter class
    /// </summary>
    [ValueConversion(typeof(Color), typeof(Color))]
    public class DarkeningColorConverter : IValueConverter
    {
        //default weighting used
        static double dWeight = .75;
        /// <summary>
        /// Convert method 
        /// </summary>
        /// <param name="value">not used</param>
        /// <param name="targetType"></param>
        /// <param name="parameter">opacity</param>
        /// <param name="culture"></param>
        /// <returns></returns>
       public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            const double EPSILON = .001;
            double weight = dWeight;
            //the parameter is the opacity
            double opacity = System.Convert.ToDouble(parameter);
            //if the opacity is zero, go full intensity
            if (Math.Abs(opacity - 0.0) < EPSILON)
            {
                weight = 1.0F;
                opacity = 1.0F;
            }
            SolidColorBrush highlightBrush = SystemColors.HighlightBrush;
            //adjust the highlightBrush color based on the weight and opacity
            return ColorAdjuster.AdjustColor(highlightBrush.Color, weight, opacity);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }
	
    /// <summary>
    /// Determines whether a bread crumb dropdown arrow is visible based on two parameters: whether it's
    /// part of the last crumb in a path, and whether the component backing the crumb has children that
    /// we'll show in a quick select menu.
    /// </summary>
    public class ArrowVisbilityConverter : IMultiValueConverter
    {
        /// <summary>
        /// Convert method
        /// </summary>
        /// <param name="values">value[0]=crumb, value[1]=isLast, value[2]=supportsDropArrow</param>
        /// <param name="targetType"></param>
        /// <param name="parameter">not used</param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            // In WPF 4 removing an item from an Observable Collection causes each item container 
            // to receive a DataContextChanged with a NewValue of {DisconnectedItem}.
            // The type of this object is Microsoft.Internal.NamedObject. The following lines
            // check for this type so we don't get an exception when casting the value.
            // The following link describes the problem:
            //http://social.msdn.microsoft.com/Forums/en-US/wpf/thread/e6643abc-4457-44aa-a3ee-dd389c88bd86/?prof=required
            if (values != null && values[0] != null && values[0].GetType().Name.Equals("NamedObject"))
                return (Visibility.Hidden);

            // Verify that the input argument matches what we expect
            if (values == null || values.Count() < 3)
                return (Visibility.Hidden);

            HomeCrumb homeCrumb = values[0] as HomeCrumb;

            //get the values
            bool isLast = (bool)values[1];
            bool supportsDropArrow = (bool)values[2];
            
            //if it is the last crumb and it does not support a
            // drop arrow then hide the drop arrow
            //also if the home crumb is before a forward or overflow crumb then hide the drop arrow
            //this home crumb case is important for having the home crumb being a program, it will
            //start with home not having an arrow, but will add the arrow when it is not last crumb
            if ((isLast && !supportsDropArrow) ||
                (homeCrumb!= null && (homeCrumb.BeforeLeftOverflowCrumbs || homeCrumb.BeforeOnlyForwardCrumbs))) 
                return Visibility.Collapsed;
            //otherwise show the drop arrow.
            return Visibility.Visible;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            // We never intend to call this
            return null;
        }
    }
	
    /// <summary>
    /// converts a boolean into a Visibility (Collapsed,Visible)
    /// </summary>
    [ValueConversion(typeof(bool), typeof(Visibility))]
    public class BooleanToVisibilityConverter : IValueConverter
    {
        /// <summary>
        /// convert method
        /// </summary>
        /// <param name="value">isVisible</param>
        /// <param name="targetType"></param>
        /// <param name="param">not used</param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            //get isVisible
            bool isVisible = (bool)value;
            //if it is visible return visible
            if (isVisible)
                return Visibility.Visible;
            //otherwise return collapsed
            return Visibility.Collapsed;

        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }


    /// <summary>
    /// Converts a Visiblity property and a boolean into Visibility (Collapsed,Visible).
    /// Used in determining when the DataSourceView or the DataGridView should be displayed, and
    /// the influence of drilling into a new level of the grid.
    /// </summary>
    public class VisibleAndBooleanToVisibilityConverter : IMultiValueConverter
    {
        /// <summary>
        /// convert method
        /// </summary>
        /// <param name="values">Visible value, and ShowDataValue</param>
        /// <param name="targetType"></param>
        /// <param name="parameter">not used</param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            // Ignore the indeterminate values
            if ((values[0] == DependencyProperty.UnsetValue) || (values[0] == null))
                return Visibility.Collapsed;

            Visibility Visible = (Visibility)values[0];
            bool ShowDataView = (bool)values[1];

            // If it is Collapsed return Collapsed
            if (Visible == Visibility.Collapsed)
                return Visibility.Collapsed;

            // If it is Visible and ShowDataView is true return Visible
            if ((Visible == Visibility.Visible) && ShowDataView )
                return Visibility.Visible;

            //otherwise return collapsed
            return Visibility.Collapsed;

        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            return null;
        }
    }

    /// <summary>
    /// Allow "post processing" for grid data cells (remove carriage returns from description strings, etc)
    /// </summary>
    [ValueConversion(typeof(string), typeof(string))]
    public class DataCellValueConverter : IValueConverter
    {
        /// <summary>
        /// convert method
        /// </summary>
        /// <param name="value">text string</param>
        /// <param name="targetType"></param>
        /// <param name="param">not used</param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string text = value as string;
            if (text == null)
                return text;
            //remove any carriage return\linefeed characters
            return text.Replace("\r\n", " ");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // We never intend to call this
            return null;
        }
    }

    /// <summary>
    /// some text crumbs do not display the full DisplayName (i.e. array crumbs like "array[0]"
    /// are displayed in the crumb as "[0]".  This converter handles this exception
    /// </summary>
    [ValueConversion(typeof(string), typeof(string))]
    public class CrumbDisplayNameConverter : IValueConverter
    {
        /// <summary>
        /// convert method
        /// </summary>
        /// <param name="value">DisplayName</param>
        /// <param name="targetType"></param>
        /// <param name="parameter">not used</param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string displayName = value as string;
            int iArray = displayName.IndexOf("[");
            if (iArray >= 0)
                displayName = displayName.Substring(iArray,displayName.Length-(iArray));
            return displayName;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            // We never intend to call this
            return null;
        }
    }
	/// <summary>
	/// Determines whether an dropdown arrow for a menu crumb is visible based
	/// on the supports drop arrow property
	/// </summary>
	[ValueConversion(typeof(bool), typeof(Visibility))]
	public class OverflowArrowVisbilityConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			bool SupportsDropArrow = (bool)value;
			return SupportsDropArrow ? Visibility.Visible : Visibility.Collapsed;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			// We never intend to call this
            return null;
		}
	}

    
 	/// <summary>
	/// Determines whether the error indicator is visible based the error messaage
    /// if the string is empty then collapse the indicator
	/// </summary>
	[ValueConversion(typeof(string), typeof(Visibility))]
    public class StringToVisbilityConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
            //message is empty then hide control
			string message = (string)value;
            if (message.Length ==0)
                return Visibility.Hidden;
            string hideText = (string)parameter;
            if (hideText != null && hideText.Length >= 0)
            {
                //or if the hideText is equal to the message then hide control
                if (hideText.Equals(message))
                    return Visibility.Hidden;
            }
            return Visibility.Visible;

		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			// We never intend to call this
            return null;
		}
	}

    /// <summary>
	/// If the breadcrumb represents a data type that is ambiguous, show the list of
    /// controllers that are associated with this particular crumb.
	/// </summary>
	[ValueConversion(typeof(string), typeof(ToolTip))]
    public class CrumbDuplicateToolTipConverter : IValueConverter
	{
        /// <summary>
        /// Convert override method 
        /// </summary>
        /// <param name="value">The object (passed as a DataContext) containing the PathElement which contains the PathList to be displayed.</param>
        /// <param name="targetType">unused</param>
        /// <param name="parameter">unused</param>
        /// <param name="culture">unused</param>
        /// <returns>The a Tooltip object</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			IPathElement pe = null;
            // If the value (passed as DataContext) is a TextCrumb, we are
            // in the visible crumb list and can obtain the path element
            // directly.
			TextCrumb TheCrumb = value as TextCrumb;
			if(TheCrumb!=null)
			{
				pe = TheCrumb.PathElement;
			}
			else if (TheCrumb == null)
            {
				// Otherwise value will be the drop arrow item which the crumb
				// is shown in and we need to use the host crumb to obtain the
				// path element.
				DropArrowItem TheMenuItem = value as DropArrowItem;
				if (TheMenuItem != null)
				{
					pe = (TheMenuItem.HostCrumb as TextCrumb).PathElement;
				}
            }
            
            ToolTip tip = new ToolTip();
            string msg = pe.DisplayName + " exists in:";

            // Add the list of controllers
            foreach (string s in ((DataItemPathElement)pe).PathList)
            {
                msg += Environment.NewLine + s;
            }
            tip.Content = msg;

            return tip;

		}

        /// <summary>
        /// ConvertBack override method - If used an exception is thrown
        /// </summary>
        /// <param name="value">unused</param>
        /// <param name="targetType">unused</param>
        /// <param name="parameter">unused</param>
        /// <param name="culture">unused</param>
 		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			// We never intend to call this
            return null;
		}
	}

    /// <summary>
    /// Converter to subtract the size of the drill in arrow column as well as the resize mouse
    /// pointer so that the column never becomes wider than the total width of the grid.
    /// </summary>
    public class NameColumnMaxWidthValueConverter : IValueConverter
    {
        #region IValueConverter Members

        /// <summary>
        /// Converts the viewport width of the grid in which the name column lies to the max width
        /// that should be taken by the name column
        /// </summary>
        /// <param name="value">The viewport width of the grid (i.e. width minus any scrollbar if present)</param>
        /// <param name="targetType">Standard framework argument (double will be returned)</param>
        /// <param name="parameter">Column object respresenting the drill in arrow</param>
        /// <param name="culture">Standard framework argument</param>
        /// <returns>Max width that the name column should be allowed to resize up to</returns>
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            double width = (double)value;

            //Subtract the width of the drill in column and half the width of the resize mouse cursor
            if (width > 0 && parameter != null)
            {
                Xceed.Wpf.DataGrid.Column drillInCol = parameter as Xceed.Wpf.DataGrid.Column;
                width -= (drillInCol.ActualWidth + System.Windows.Forms.Cursors.SizeWE.HotSpot.X / 2);
            }
            return width;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return 0;
        }

        #endregion
    }
}
