﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using System.ComponentModel;
using RockwellAutomation.Logging;
using System;
using System.Windows.Threading;

namespace RockwellAutomation.UI.DIBQuery
{    
    /// <summary>
    /// This command is used for executing Command when Generic DIB clients want to be responsible for drilling in, drilling out, and search related commands
    /// </summary>
    class DIBQueryCommandForClientExecutedQuery : DIBQueryCommand
    {
        #region private

        private BackgroundWorker BgWorkerExecuteQuery;
        private IClientDataServices _cds;
        private bool shouldExecuteAsynch = true;
        // Represents the current Gui dispatcher. This is used later by callbacks to CDS update our GUI in real time
        private Dispatcher _dispatcher = null;

        #endregion

        #region "Creation/Init"

        public DIBQueryCommandForClientExecutedQuery(QueryRequest.CreateBuilder queryRequestBuilder)
            : base(queryRequestBuilder)
        {
        }

        #endregion

        #region "Base Overides" 


        public override PredefinedQueryType QueryType()
        {
            return PredefinedQueryType.Undefined;
        }

        public override void Execute(IClientDataServices cds)
        {
            // set the Dispatcher of the UI (DIB) thread. 
            // Note: This is needed after performing an Asynchronous operation to allow us to get back to the UI thread 
            // and will be used in notifying CDS 
            _dispatcher = Dispatcher.CurrentDispatcher;
            _cds = cds;

            if (this.shouldExecuteAsynch)
                ExecuteAsynch();
            else
                ExecuteSynch();

        }

        private void ExecuteAsynch()
        {
            if (BgWorkerExecuteQuery == null)
            {
                BgWorkerExecuteQuery = new BackgroundWorker {/*WorkerReportsProgress = true,*/ WorkerSupportsCancellation = true };
                BgWorkerExecuteQuery.DoWork += BkWorkerDoWork;
                BgWorkerExecuteQuery.RunWorkerCompleted += BkWorkerCompleted;
            }

            this.CacheQueryResults = true;
            BgWorkerExecuteQuery.RunWorkerAsync();
        }

        private void ExecuteSynch()
        {
            this.CacheQueryResults = true;
            if (this.QueryRequestBuilder.GetCondition() == null)
            {
                LogWrapper.DibInterfaceLog.Debug("Background worker executing Drill in for DIBQueryCommandForClientExecutedQuery. DataItem: " + this.ParentDataItem());
                _cds.DibClientManager.DrillInFor(this.ParentDataItem(), _cds.QueryCache);
                DetermineCachingMode();
            }
            else
            {
                LogWrapper.DibInterfaceLog.Debug("Background worker executing Search for DIBQueryCommandForClientExecutedQuery");
                _cds.DibClientManager.SearchFor(this.QueryRequestBuilder.GetCondition(), _cds.QueryCache);
            }
            ExecuteResponse();
            return;
        }

        /// <summary>
        /// This method is called asynchronously by the background worked to do its work once it is invoked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BkWorkerDoWork(object sender, DoWorkEventArgs e)
        {
            if (BgWorkerExecuteQuery.CancellationPending)
            {
                e.Cancel = true;
                return;
            }

            if (this.QueryRequestBuilder.GetCondition() == null)
            {
                LogWrapper.DibInterfaceLog.Debug("Background worker executing Drill in for DIBQueryCommandForClientExecutedQuery. DataItem: " + this.ParentDataItem());
                _cds.DibClientManager.DrillInFor(this.ParentDataItem(), _cds.QueryCache);
                DetermineCachingMode();
            }
            else
            {
                LogWrapper.DibInterfaceLog.Debug("Background worker executing Search for DIBQueryCommandForClientExecutedQuery");
                _cds.DibClientManager.SearchFor(this.QueryRequestBuilder.GetCondition(), _cds.QueryCache);
            }

            ExecuteResponse();
        }

        private void DetermineCachingMode()
        {
            // Decide wether or not to cache results based on drill in item.
            // This allows client to decide at runtime whether or not to show breadcrumb alternate values for a drill in
            if (this.ParentDataItem() == null)
            {
                this.CacheQueryResults = true;
            }
            else
            {
                this.CacheQueryResults = DIBViewItemBase.BooleanValueFrom(this.ParentDataItem().GUIShowChildrenInBreadCrumbTrail);
            }
        }


        /// <summary>
        /// This method is called asynchronously by the background worked to signal that it has finished.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BkWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            LogWrapper.DibInterfaceLog.Debug("Background worker completed for DIBQueryCommandForClientExecutedQuery.");

            _cds = null;
            _dispatcher = null;
            BgWorkerExecuteQuery.Dispose();
        }

        private void ExecuteResponse()
        {
            this.QueryRequestBuilder.SetColumnConfig(DIBQueryCommand.NonDBQueryColumnConfig());
            this.CurrentQueryRequest = this.QueryRequestBuilder.Build();

            // Generate a Query Response the same way QSP would
            QueryResponse.CreateBuilder queryResponseBuilder = new QueryResponse.CreateBuilder();

            queryResponseBuilder
                .SetQueryRequest(this.CurrentQueryRequest)
                .SetTotalItemCount(_cds.QueryCache.DataItemsCount());

            // Call Query_DataLoadComplete in queryConnection the same way that QSP signals a response
            _dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Send, (Action)(() =>
            {
                _cds.PerformQuery_DataLoadComplete(queryResponseBuilder.Build());
            }));
        }
        #endregion

    }
}
