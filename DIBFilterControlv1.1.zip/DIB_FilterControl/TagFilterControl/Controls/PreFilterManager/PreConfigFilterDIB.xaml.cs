﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TagFilterControl.Common;
using TagFilterControl.Controls.PreFilterManager.Common;

namespace TagFilterControl.Controls
{
    /// <summary>
    /// Interaction logic for PreConfigFilterDIB.xaml
    /// </summary>
    public partial class PreConfigFilterDIB : Page
    {
        public PreConfigFilterDIB(FilterProfile Profile)
        {
            InitializeComponent();
            this.PreCinfigFilterDIBVM = new PreConfigFilterDIBViewModel(Profile);
            this.DataContext = this.PreCinfigFilterDIBVM;
        }

        public PreConfigFilterDIBViewModel PreCinfigFilterDIBVM { get; set; }

        private void EditValueTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox box = sender as TextBox;
            if (box != null)
            {
                ConditionFilterBaseModel model = box.DataContext as ConditionFilterBaseModel;
                if (model != null && model.ConditionFilterBase != null && model.ConditionFilterBase.Value != null)
                {
                    ValueItemForDisplay item = model.ConditionFilterBase.Value as ValueItemForDisplay;
                    if (!string.IsNullOrEmpty(box.Text.Trim()))
                    {
                        item.HasError = false;
                        item.HasDisplayValue = true;
                    }
                    else
                    {
                        item.HasDisplayValue = false;
                    }
                }
            }
        }

        private void EditValueTB_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox box = sender as TextBox;
            if (box != null)
            {
                ConditionFilterBaseModel model = box.DataContext as ConditionFilterBaseModel;
                if (model != null && model.ConditionFilterBase != null && model.ConditionFilterBase.Value != null)
                {
                    ValueItemForDisplay item = model.ConditionFilterBase.Value as ValueItemForDisplay;
                    if (!item.HasDisplayValue)
                    {
                        item.DisplayValue = string.Empty;
                    }
                }
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(this.PreCinfigFilterDIBVM.Name))
            {
                this.PreCinfigFilterDIBVM.InValidInfo = string.Empty;
            }
        }
    }
}
