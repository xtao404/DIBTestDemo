﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Windows;
using RockwellAutomation.UI.Models;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for ArrowVisbilityConverterTest and is intended
    ///to contain all ArrowVisbilityConverterTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ArrowVisbilityConverterTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for ConvertBack
        ///</summary>
        [TestMethod()]
        public void ArrowVisbilityConverter_ConvertBackTest()
        {
            ArrowVisbilityConverter target = new ArrowVisbilityConverter();
            object value = false;

            try
            {
                object actual = target.ConvertBack(value, null, null, null);
            }
            catch (NotSupportedException exception)
            {
                Assert.AreEqual("Not supported", exception.Message);
            }
        }

        /// <summary>
        ///A test for Convert
        ///</summary>
        [TestMethod()]
        public void ArrowVisbilityConverter_ConvertTest_Collapsed_IsLastTrue()
        {
            bool isLast = true;
            bool supportsDropArrow = false;

            TextCrumb textCrumb = new TextCrumb(PathElementUtility.Instance().CreateDataItemPathElement("testTag", "", true));
            Visibility expected = Visibility.Collapsed;

            object[] values = new object[] { textCrumb as ACrumb, isLast as object, supportsDropArrow as object };
            ArrowVisbilityConverter target = new ArrowVisbilityConverter();

            object actual = target.Convert(values, null, null, null);
            Assert.AreEqual(expected, (Visibility)actual);
        }

        /// <summary>
        ///A test for Convert
        ///</summary>
        [TestMethod()]
        public void ArrowVisbilityConverter_ConvertTest_Visible_IsLastTrue()
        {
            bool isLast = true;
            bool supportsDropArrow = true;
            TextCrumb textCrumb = new TextCrumb(PathElementUtility.Instance().CreateDataItemPathElement("testTag", "", true));
            Visibility expected = Visibility.Visible;

            object[] values = new object[] {textCrumb as ACrumb, isLast as object, supportsDropArrow as object };
            ArrowVisbilityConverter target = new ArrowVisbilityConverter();

            object actual = target.Convert(values, null, null, null);
            Assert.AreEqual(expected, (Visibility)actual);
        }

        /// <summary>
        ///A test for Convert
        ///</summary>
        [TestMethod()]
        public void ArrowVisbilityConverter_ConvertTest_Visible_IsLastFalse_SDAFalse()
        {
            bool isLast = false;
            bool supportsDropArrow = false;
            TextCrumb textCrumb = new TextCrumb(PathElementUtility.Instance().CreateDataItemPathElement("testTag", "", true));
            Visibility expected = Visibility.Visible;

            object[] values = new object[] {textCrumb as ACrumb, isLast as object, supportsDropArrow as object };
            ArrowVisbilityConverter target = new ArrowVisbilityConverter();

            object actual = target.Convert(values, null, null, null);
            Assert.AreEqual(expected, (Visibility)actual);
        }

        /// <summary>
        ///A test for Convert
        ///</summary>
        [TestMethod()]
        public void ArrowVisbilityConverter_ConvertTest_Visible_IsLastFalse_SDATrue()
        {
            bool isLast = false;
            bool supportsDropArrow = true;
            TextCrumb textCrumb = new TextCrumb(PathElementUtility.Instance().CreateDataItemPathElement("testTag", "", true));
            Visibility expected = Visibility.Visible;

            object[] values = new object[] { textCrumb as ACrumb, isLast as object, supportsDropArrow as object };
            ArrowVisbilityConverter target = new ArrowVisbilityConverter();

            object actual = target.Convert(values, null, null, null);
            Assert.AreEqual(expected, (Visibility)actual);
        }
    
    }
}
