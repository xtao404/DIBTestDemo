
namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// MenuCrumb class
    /// Crumb which represents the dropdown used for the backward
	/// and forward overflow menus
    /// </summary>
    public class MenuCrumb : ACrumb
    {
        /// <summary>
        /// constructor
        /// </summary>
		public MenuCrumb()
		{
			HasChildren = false;
		}

		/// <summary>
		/// Does this crumb support drop arrow navigation property.
		/// </summary>
		public override bool SupportsDropArrow
		{
			get { return HasChildren; }
		}

		/// <summary>
		/// Is this a menu crumb for the forward crumbs
		/// (or backward crumbs)
		/// </summary>
		private bool _isForward = false;
		public bool IsForward
		{
			get { return _isForward; }
			set { _isForward = value; }
		}
		public bool IsBackward
		{
			get { return !_isForward; }
			set { _isForward = !value; }
		}

		private bool _hasChildren = false;
		public bool HasChildren
		{
			get { return _hasChildren; }
			set
			{
				_hasChildren = value;
				NotifyPropertyChanged("SupportsDropArrow");
			}
		}
    }

	/// <summary>
	/// Represents a left menu crumb (double left arrow button shown in 
	/// the crumb trail that shows a dropdown menu containing items early
	/// in the crumb trail that do not fit on the window given the
	/// available window width)
	/// </summary>
	public class LMenuCrumb : MenuCrumb
    {
		/// <summary>
        /// constructor
        /// </summary>
		public LMenuCrumb()
		{
			this.IsForward = false;
		}
    }

	/// <summary>
	/// Represents a right menu crumb (double right arrow button shown in
	/// the crumb trail that shows a dropdown menu containing forward 
	/// breadcrumb items)
	/// </summary>
	public class RMenuCrumb : MenuCrumb
	{
		/// <summary>
        /// constructor
        /// </summary>
		public RMenuCrumb()
		{
			this.IsForward = true;
		}
	}
}
