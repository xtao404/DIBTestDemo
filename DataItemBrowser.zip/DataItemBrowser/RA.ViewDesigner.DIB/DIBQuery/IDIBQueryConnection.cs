﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.ServiceFramework.DataTypes;
using System;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.Generic;

namespace RockwellAutomation.UI.DIBQuery
{
    /// <summary>
    /// IDIBQueryConnection encapsulates all communication with our data provider which is currently QSP
    /// </summary>
    public interface IDIBQueryConnection
    {
        /// <summary>
        /// Represents whether the connection is ready ready to have commands executed
        /// </summary>
        /// <returns>Whether the query connection is initialized</returns>
        bool isQueryInitialized();

        /// <summary>
        /// Open the connection
        /// </summary>
        void CreateConnection();

        /// <summary>
        /// Set the packageID and projectID. This should be called before CreateConnection
        /// </summary>
        /// <param name="packageContext"></param>
        /// <param name="projectContext"></param>
        void SetPackageAndProjectContext(UUID packageContext, UUID projectContext);

        /// <summary>
        /// Wether or not this query connection has a valid Package and Project context
        /// </summary>
        bool HasValidPackageAndProjectContext();

        /// <summary>
        /// Registers the provided IClientDataServices instance for asynch notification from the data provider on query results
        /// </summary>
        /// <param name="packageContext">cds</param>
        void RegisterForEvents(IClientDataServices cds);

        /// <summary>
        /// Unregisters for event info
        /// </summary>
        void UnRegisterForEvents();

        /// <summary>
        /// Inform the data provider that we not execute any more queries on this DIB instance
        /// </summary>
        void Shutdown();

        /// <summary>
        /// Execute a IDIBQueryCommand on the QueryConnection using the provided cache
        /// </summary>
        /// <param name="queryCommand"></param>
        /// <param name="queryCache"></param>
        void Execute(IDIBQueryCommand queryCommand, DIBQueryCache queryCache);

        /// <summary>
        /// Process errors
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="cds"></param>
        /// <returns>error string to display to user</returns>
        string ProcessExceptionErrorResponse(Exception exception, IClientDataServices cds);

        /// <summary>
        /// The method that the data provider calls during initial chunk load.
        /// </summary>
        /// <param name="items"></param>
        /// <param name="count"></param>
        void CallbackLoadInitialItems(List<DataItemBase> items, int count);

        /// <summary>
        /// The method that the data provider calls during final chunk load
        /// </summary>
        /// <param name="items"></param>
        /// <param name="count"></param>
        void CallbackLoadFinalItems(List<DataItemBase> items, int count);

        /// <summary>
        /// The method that the data provider calls during query completion
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Query_DataLoadComplete(object sender, System.ComponentModel.PropertyChangedEventArgs e);
    }
}
