﻿/*************************************************************************************
                                                                     
   ViewE PopupBehaviorCloseOnOutsideInput 
   Copyright © 2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using RockwellAutomation.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace RockwellAutomation.UI.CommonControls.Behavior
{
    /// <summary>
    /// Behavior used to help a Popup close if input (keyboard, mouse) is 
    /// detected outside of the Popup. 
    /// 
    /// Since a Popup is not a window it does not receive focus directly.  We 
    /// must look at the input detected by the parent container. WPF is supposed
    /// to handle closing the Popup due to outside input but does not work properly 
    /// when one Popup appears within another. 
    /// 
    /// Normally a behavior is attached via a dependency property.  However, this 
    /// behavior needs to be attached after the target Popup has been loaded so 
    /// that it can properly walk up the visual tree. 
    /// </summary>
    public class PopupBehaviorCloseOnOutsideInput
    {
        /// <summary>
        /// Map of associations that have been made between the popup and the top
        /// level container that is receiving input events
        /// </summary>
        private static Dictionary<Popup, PopupTopLevelContext> _topLevelPopupAssociations = 
            new Dictionary<Popup, PopupTopLevelContext>();      

        /// <summary>
        /// Attach this behavior to the given popup
        /// 
        /// Note: The Popup should be loaded first
        /// </summary>
        /// <param name="popup"></param>
        public static void AttachToPopup(Popup popup)
        {
            AddAssociation(popup);
        }
      
        /// <summary>
        /// Add an association between the supplied popup and the context
        /// that will track popup visibility
        /// </summary>
        /// <param name="popup"></param>
        private static void AddAssociation(Popup popup)
        {
            PopupTopLevelContext cp = null;
            if (!_topLevelPopupAssociations.TryGetValue(popup, out cp))
            {
                // No mapping exists, obtain the top level element 
                var topLevelElement = FindTopLevelElement(popup);
                if (topLevelElement != null)
                {
                    cp = new PopupTopLevelContext(popup, topLevelElement);

                    // Associate the popup with the context object
                    _topLevelPopupAssociations[popup] = cp;

                    popup.Unloaded += Popup_Unloaded;
                }
                else
                {
                    LogWrapper.DibGeneralLog.Error(
                        "PopupBehaviorCloseOnOutsideInput.AddAssociation No top-level element found");
                }
            }                 
        }

        /// <summary>
        /// Remove the association between the supplied popup and the context
        /// that tracks popup visibility
        /// </summary>
        /// <param name="popup"></param>
        private static void RemoveAssociation(Popup popup)
        {
            PopupTopLevelContext cp = null;
            if (_topLevelPopupAssociations.TryGetValue(popup, out cp))
            {
                cp.Release();               
                _topLevelPopupAssociations.Remove(popup);
            }
        }

        /// <summary>
        /// Remove association with the popup if it becomes unloaded
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void Popup_Unloaded(object sender, RoutedEventArgs e)
        {
            Popup popup = (Popup)sender;

            RemoveAssociation(popup);
        }     

        /// <summary>
        /// Find the top-level FrameWorkElement starting from the given
        /// element.  
        /// 
        /// This method should be invoked after the provided element has
        /// been loaded so that the visual tree can be navigated
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private static FrameworkElement FindTopLevelElement(FrameworkElement element)
        {
            FrameworkElement iterator;
            FrameworkElement nextUp = element;
            do
            {
                iterator = nextUp;
                DependencyObject dObj = VisualTreeHelper.GetParent(iterator);
                nextUp = dObj as FrameworkElement;
            } while (nextUp != null);
            return iterator;
        }
       
        /// <summary>
        /// Maintain a relationship between a popup and the top level
        /// parent framework element that is receiving input events. 
        /// </summary>
        private class PopupTopLevelContext
        {
            private Popup _popup;
            private FrameworkElement _topLevelElement;

            /// <summary>
            /// Constructor
            /// 
            /// Will attach context to the supplied popup
            /// </summary>
            /// <param name="Popup"></param>
            /// <param name="TopLevelElement"></param>
            public PopupTopLevelContext(
                Popup Popup, 
                FrameworkElement TopLevelElement)
            {
                _popup = Popup;
                _topLevelElement = TopLevelElement;

                Attach();
            }

            /// <summary>
            /// Attach to the popup
            /// </summary>
            public void Attach()
            {    
                // Need to listen to the down event.  If we listen to the up
                // event then will force a close after the user releases the key
                // or mouse button
                _topLevelElement.PreviewKeyDown += Popup_PreviewKeyDown;
                _topLevelElement.PreviewMouseDown += Popup_PreviewMouseDown;                        
            }

            /// <summary>
            /// Release from the popup
            /// </summary>
            public void Release()
            {
                _topLevelElement.PreviewKeyDown -= Popup_PreviewKeyDown;
                _topLevelElement.PreviewMouseDown -= Popup_PreviewMouseDown;
            }

            /// <summary>
            /// Close the popup if the keyboard input event is outside the popup
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void Popup_PreviewKeyDown(object sender, KeyEventArgs e)
            {
                if (!_popup.IsOpen)
                {
                    return;
                }              

                UIElement source = e.OriginalSource as UIElement;
                if (source != null)
                {
                    // Retrieve the coordinate of the original event source
                    // relative to the popup child
                    Point pt = source.TranslatePoint(new Point(0, 0), _popup.Child);
                    IInputElement child = _popup.Child.InputHitTest(pt);

                    if (child == null)
                    {
                        _popup.IsOpen = false;
                    }
                }
            }

            /// <summary>
            /// Close the popup if the mouse input event is outside the popup
            /// </summary>
            /// <param name="sender"></param>
            /// <param name="e"></param>
            private void Popup_PreviewMouseDown(object sender, MouseButtonEventArgs e)
            {
                if (!_popup.IsOpen)
                {
                    return;
                }
                
                // Retrieve the coordinate of the mouse position
                // relative to the popup child
                Point pt = e.GetPosition((UIElement)_popup.Child);
                IInputElement child = _popup.Child.InputHitTest(pt);
                
                if (child == null)
                {
                    _popup.IsOpen = false;
                }
            }            
        }
    }
}
