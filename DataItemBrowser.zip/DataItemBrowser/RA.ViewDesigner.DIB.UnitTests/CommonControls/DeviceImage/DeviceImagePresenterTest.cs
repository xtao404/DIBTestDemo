﻿using RockwellAutomation.CommonServices.TypeSchemas.Devices;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.ComponentModel;
using RockwellAutomation.UI.CommonControls.DeviceImage;
using System.Windows.Threading;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for DeviceImagePresenterTest and is intended
    ///to contain all DeviceImagePresenterTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DeviceImagePresenterTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Controller_PropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void Controller_PropertyChangedTest()
        {
            //ARRANGE
            DeviceImagePresenter target = new DeviceImagePresenter();
            DeviceImagePresenter.SetReplicationStateValues(Enum_ReplicationStateType.UNINITIATED.ToString(),
                                                           Enum_ReplicationStateType.EXTRACTING.ToString(),
                                                           Enum_ReplicationStateType.SYNCHED.ToString(),
                                                           Enum_ReplicationStateType.DETECTINGCHANGES.ToString(),
                                                           Enum_ReplicationStateType.NEEDSUPDATING.ToString(),
                                                           Enum_ReplicationStateType.UPDATING.ToString(),
                                                           Enum_ReplicationStateType.SYNCHLOST.ToString(),
                                                           Enum_ReplicationStateType.INDETERMINATE.ToString(),
                                                           Enum_ReplicationStateType.RESYNCHRONIZING.ToString(),
                                                           Enum_ReplicationStateType.EROA_UNINITIATED.ToString(),
                                                           Enum_ReplicationStateType.EROA_DATA.ToString());
            PrivateObject targetPrivate = new PrivateObject(target);
            TestDeviceStatus testDeviceStatus = new TestDeviceStatus();
            testDeviceStatus.ReplicationError = string.Empty;
            testDeviceStatus.ReplicationState = DeviceImagePresenter.ReplicationStateType.UNINITIATED;
            target.Initialize(testDeviceStatus);

            testDeviceStatus.ReplicationError = "My Error on synchronization of this controller.";
            testDeviceStatus.ReplicationState = DeviceImagePresenter.ReplicationStateType.SYNCHLOST;
            object sender = testDeviceStatus;
            PropertyChangedEventArgs e = new PropertyChangedEventArgs("ReplicationError");

            //ACT
            Dispatcher.CurrentDispatcher.Invoke((Action)delegate
            {
                targetPrivate.Invoke("Controller_PropertyChanged", new object[] { sender, e });
            });

            //ASSERT
            Assert.IsTrue(target.ReplicationError == testDeviceStatus.ReplicationError);
            Assert.IsTrue(target.ReplicationState == DeviceImagePresenter.ReplicationStateType.UNINITIATED);

            //ACT
            e = new PropertyChangedEventArgs("ReplicationState");
            Dispatcher.CurrentDispatcher.Invoke((Action)delegate
            {
                targetPrivate.Invoke("Controller_PropertyChanged", new object[] { sender, e });
            });

            //ASSERT
            Assert.IsTrue(target.ReplicationError == testDeviceStatus.ReplicationError);
            Assert.IsTrue(target.ReplicationState == testDeviceStatus.ReplicationState);

        }

        /// <summary>
        ///A test for Initialize
        ///</summary>
        [TestMethod()]
        public void InitializeTest()
        {
            DeviceImagePresenter target = new DeviceImagePresenter();
            DeviceImagePresenter.SetReplicationStateValues(Enum_ReplicationStateType.UNINITIATED.ToString(),
                                                           Enum_ReplicationStateType.EXTRACTING.ToString(),
                                                           Enum_ReplicationStateType.SYNCHED.ToString(),
                                                           Enum_ReplicationStateType.DETECTINGCHANGES.ToString(),
                                                           Enum_ReplicationStateType.NEEDSUPDATING.ToString(),
                                                           Enum_ReplicationStateType.UPDATING.ToString(),
                                                           Enum_ReplicationStateType.SYNCHLOST.ToString(),
                                                           Enum_ReplicationStateType.INDETERMINATE.ToString(),
                                                           Enum_ReplicationStateType.RESYNCHRONIZING.ToString(),
                                                           Enum_ReplicationStateType.EROA_UNINITIATED.ToString(),
                                                           Enum_ReplicationStateType.EROA_DATA.ToString());
            TestDeviceStatus testDeviceStatus = new TestDeviceStatus();
            testDeviceStatus.ReplicationError = string.Empty;
            testDeviceStatus.ReplicationState = DeviceImagePresenter.ReplicationStateType.UNINITIATED;
            target.Initialize(testDeviceStatus);
            Assert.IsTrue(target.ReplicationError == testDeviceStatus.ReplicationError);
            Assert.IsTrue(target.ReplicationState == testDeviceStatus.ReplicationState);
        }
    }

    class TestDeviceStatus : IDeviceStatus
    {

        #region IDeviceStatus Members

        private DeviceImagePresenter.ReplicationStateType _replicationState;
        public DeviceImagePresenter.ReplicationStateType ReplicationState
        {
            get { return _replicationState; }
            set { _replicationState = value; }
        }

        private string _replicationError;
        public string ReplicationError
        {
            get { return _replicationError; }
            set { _replicationError = value; }
        }

        #endregion

        public TestDeviceStatus()
        {
            if (PropertyChanged != null)
            {
                PropertyChanged.Invoke((object)this, (PropertyChangedEventArgs)PropertyChangedEventArgs.Empty);
            }
        }
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }
}
