﻿
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.DIBQuery;
using System;
using System.IO;
using RockwellAutomation.UI.Views;
using System.Text;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    public class DIBClientManager_4_TreeViewToListView : DIBClientManager
    {
        #region local variables"

        private string baseAssemblyLocation;
        private string baseAssemblyLocationURIString;
        public const string DATATYPE_MANAGER = "Manager";
        public const string DATATYPE_DEVELOPER = "Developer";
        public const string DATATYPE_INFODEV = "Info Dev";
        public const string DATATYPE_PERSONDETAILS = "Person Details";
        public const string LIST_VIEW = "GenericDIBItemView";
        public const string TREE_VIEW = "none";

        #endregion

        #region Startup/Shutdown


        override public void InitializeDIBControlOnStartup(DataItemBrowser dataItemBrowserControl, StringBuilder logger)
        {
            baseAssemblyLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            baseAssemblyLocationURIString = "file:\\\\" + baseAssemblyLocation;
        }


        override public DIBListViewModel createDIBListViewModel(DataItemBrowserViewModel dibVM)
        {
            return new DIBListViewModel_4_TreeViewToListView(dibVM);
        }

        #endregion

        #region Navigation overrides

        override public string GetResourceTypeString(DataItemBase dataItem)
        {
            if (dataItem == null) return TREE_VIEW;
            if (dataItem.GetStringMapValue("PeopleAtRockwell.ViewType") == "TreeView1") return TREE_VIEW;
            if (dataItem.GetStringMapValue("PeopleAtRockwell.ViewType") == "TreeView2") return LIST_VIEW;
            return TREE_VIEW;
        }

        override public IDIBDataViewType GetDataViewTypeFor(string resourceType)
        {
            if (resourceType == LIST_VIEW) return new DIBDataViewTypeListView();
            if (resourceType == ClientDataServices.SearchTags) return new DIBDataViewTypeSearchGrid();
            return new DIBDataViewTypeTreeView();
        }

        override public void DrillInFor(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            // If dataItemToDrillInto is null, we are browsing the initial view or
            // the user has clicked on home brumb
            if (dataItemToDrillInto == null)
            { 
                DrillntoFirstTreeView(queryCache);
                return;
            }

            if (dataItemToDrillInto.GetStringMapValue("PeopleAtRockwell.ViewType") == "TreeView1")
            { 
                this.DrillIntoSecondTreeView(dataItemToDrillInto, queryCache);
                return;
            }

            if (dataItemToDrillInto.GetStringMapValue("PeopleAtRockwell.ViewType") == "TreeView2")
            {
                this.DrillIntoFirstListView(dataItemToDrillInto, queryCache);
                return;
            }

        }

        #endregion

        #region Data Generation

        /// <summary>
        /// Helper method to create instance of DataItemBase
        /// </summary>
        private DataItemBase CreateDataItemBase(
            String name,
            String datatype,
            String viewType,
            String treeViewId,
            String treeViewParentId,
            String tooltip,
            String automationId,
            String automationName,
            String imagePath,
            String supportsDrillIn,
            String isExpanded,
            String isInitHighlighted,
            String fontWeight,
            String supportsSelection,
            String description = "")
        {
            DataItemBase dataItem = new DataItemBase();
            if (!String.IsNullOrWhiteSpace(name)) dataItem.CommonName = name;
            if (!String.IsNullOrWhiteSpace(description)) dataItem.CommonDescription = description;
            if (!String.IsNullOrWhiteSpace(datatype)) dataItem.CommonDataType = datatype;
            if (!String.IsNullOrWhiteSpace(viewType)) dataItem.SetStringMapValue("PeopleAtRockwell.ViewType" ,viewType);
            if (!String.IsNullOrWhiteSpace(treeViewId)) dataItem.GUITreeViewID = treeViewId;
            if (!String.IsNullOrWhiteSpace(treeViewParentId)) dataItem.GUITreeViewParentID = treeViewParentId;
            if (!String.IsNullOrWhiteSpace(tooltip)) dataItem.GUIToolTip = tooltip;
            if (!String.IsNullOrWhiteSpace(automationId)) dataItem.GUIAutomationID = automationId;
            if (!String.IsNullOrWhiteSpace(automationName)) dataItem.GUIAutomationName = automationName;
            if (!String.IsNullOrWhiteSpace(imagePath)) dataItem.GUISmallImagePath = imagePath;
            if (!String.IsNullOrWhiteSpace(supportsDrillIn)) dataItem.GUISupportsDrillIn = supportsDrillIn;
            if (!String.IsNullOrWhiteSpace(isExpanded)) dataItem.GUIIsExpanded = isExpanded;
            if (!String.IsNullOrWhiteSpace(isInitHighlighted)) dataItem.GUIIsInitiallyHighlighted = isInitHighlighted;
            if (!String.IsNullOrWhiteSpace(fontWeight)) dataItem.GUITextFontWeight = fontWeight;
            if (!String.IsNullOrWhiteSpace(supportsSelection)) dataItem.GUISupportsSelection = supportsSelection;
            return dataItem;
        }


        private void DrillntoFirstTreeView(DIBQueryCache queryCache)
        {
            DataItemBase managerTreeNode = this.CreateDataItemBase(
                    name: "Managers",
                    datatype: DATATYPE_MANAGER,
                    viewType: "TreeView1",
                    treeViewId: "1",
                    treeViewParentId: string.Empty,
                    tooltip: "This is the Managers Folder. You can't navigate to this item",
                    automationId: "Managers_Node",
                    automationName: "Managers_Node",
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserManager.png",
                    supportsDrillIn: "False",
                    isExpanded: "false",
                    isInitHighlighted: "false",
                    fontWeight: "Bold",
                    supportsSelection: "false");

            queryCache.AddDataItem(managerTreeNode);
            
            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "David Kebbekus",
                    datatype: DATATYPE_MANAGER,
                    viewType: "TreeView1",
                    treeViewId: "2",
                    treeViewParentId: managerTreeNode.GUITreeViewID,
                    tooltip: "This is a sample tooltip for David Kebbekus",
                    automationId: "David_Kebekaus",
                    automationName: "David_Kebekaus",
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserManager.png",
                    supportsDrillIn: "True",
                    isExpanded: "True",
                    isInitHighlighted: "false",
                    fontWeight: "Medium",
                    supportsSelection: "true"));
            
            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Will Klemovage",
                    datatype: DATATYPE_MANAGER,
                    viewType: "TreeView1",
                    treeViewId: "3",
                    treeViewParentId: managerTreeNode.GUITreeViewID,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserManager.png",
                    supportsDrillIn: "False",
                    isExpanded: "False",
                    isInitHighlighted: "True",
                    fontWeight: "Heavy",
                    supportsSelection: "true"));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "John Adams",
                    datatype: DATATYPE_MANAGER,
                    viewType: "TreeView1",
                    treeViewId: "4",
                    treeViewParentId: managerTreeNode.GUITreeViewID,
                    tooltip: "The image here came from an embedded resource from the calling app....not a file on a drive",
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserManager.png",
                    supportsDrillIn: "False",
                    isExpanded: "False",
                    isInitHighlighted: "True",
                    fontWeight: string.Empty,
                    supportsSelection: "true"));
            
            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Sarah MiddleName LastNameLong",
                    datatype: DATATYPE_MANAGER,
                    viewType: "TreeView1",
                    treeViewId: "5",
                    treeViewParentId: managerTreeNode.GUITreeViewID,
                    tooltip: "The image here came from an embedded resource from the calling app....not a file on a drive",
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserManager.png",
                    supportsDrillIn: "True",
                    isExpanded: "False",
                    isInitHighlighted: "True",
                    fontWeight: string.Empty,
                    supportsSelection: "true"));
            
            DataItemBase devTreeRootNode = this.CreateDataItemBase(
                    name: "Developers",
                    datatype: DATATYPE_DEVELOPER,
                    viewType: "TreeView1",
                    treeViewId: "6",
                    treeViewParentId: string.Empty,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserDev.png",
                    supportsDrillIn: "False",
                    isExpanded: "True",
                    isInitHighlighted: "False",
                    fontWeight: "Heavy",
                    supportsSelection: "true");

            queryCache.AddDataItem(devTreeRootNode);
            
            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Adrian Pantea",
                    datatype: DATATYPE_DEVELOPER,
                    viewType: "TreeView1",
                    treeViewId: "7",
                    treeViewParentId: devTreeRootNode.GUITreeViewID,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserDev.png",
                    supportsDrillIn: "True",
                    isExpanded: "True",
                    isInitHighlighted: "False",
                    fontWeight: string.Empty,
                    supportsSelection: "true"));
            
            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Adam Patrick",
                    datatype: DATATYPE_DEVELOPER,
                    viewType: "TreeView1",
                    treeViewId: "8",
                    treeViewParentId: devTreeRootNode.GUITreeViewID,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserDev.png",
                    supportsDrillIn: "True",
                    isExpanded: "False",
                    isInitHighlighted: "True",
                    fontWeight: string.Empty,
                    supportsSelection: "True"));
            
            
            DataItemBase infoDevRootNode = this.CreateDataItemBase(
                    name: "Info Devs",
                    datatype: DATATYPE_INFODEV,
                    viewType: "TreeView1",
                    treeViewId: "9",
                    treeViewParentId: string.Empty,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserInfoDev.png",
                    supportsDrillIn: "False",
                    isExpanded: "True",
                    isInitHighlighted: "True",
                    fontWeight: "Heavy",
                    supportsSelection: "True");

            queryCache.AddDataItem(infoDevRootNode);
            
            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Shelly Duncan",
                    datatype: DATATYPE_INFODEV,
                    viewType: "TreeView1",
                    treeViewId: "10",
                    treeViewParentId: infoDevRootNode.GUITreeViewID,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserInfoDev.png",
                    supportsDrillIn: "True",
                    isExpanded: "False",
                    isInitHighlighted: "False",
                    fontWeight: string.Empty,
                    supportsSelection: "True"));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Debra Lewis",
                    datatype: DATATYPE_INFODEV,
                    viewType: "TreeView1",
                    treeViewId: "11",
                    treeViewParentId: infoDevRootNode.GUITreeViewID,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\UserInfoDev.png",
                    supportsDrillIn: "True",
                    isExpanded: "False",
                    isInitHighlighted: "False",
                    fontWeight: string.Empty,
                    supportsSelection: "True"));
        }

        private void DrillIntoSecondTreeView(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {

            DataItemBase rootTreeNode = this.CreateDataItemBase(
                    name: dataItemToDrillInto.CommonName + " Details",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "TreeView2",
                    treeViewId: "9",
                    treeViewParentId: string.Empty,
                    tooltip: "This is the Managers Folder. You can't navigate to this item",
                    automationId: "Managers_Node",
                    automationName: "Managers_Node",
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\User.png",
                    supportsDrillIn: "False",
                    isExpanded: "True",
                    isInitHighlighted: "false",
                    fontWeight: "Heavy",
                    supportsSelection: "false");

            queryCache.AddDataItem(rootTreeNode);


            Random rndKids = new Random();
            string numKidsString = rndKids.Next(1, 20) + " kid(s)";
            if (dataItemToDrillInto.CommonName == "Adam Patrick") numKidsString = "Unkown number of kids.";

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: numKidsString,
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "TreeView2",
                    treeViewId: "10",
                    treeViewParentId: rootTreeNode.GUITreeViewID,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\48by48\\comment.png",
                    supportsDrillIn: "false",
                    isExpanded: "True",
                    isInitHighlighted: "false",
                    fontWeight: string.Empty,
                    supportsSelection: "true"));


            Random rndCars = new Random();
            string numCarsString = rndCars.Next(1, 4) + " car(s)";

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: numCarsString,
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "TreeView2",
                    treeViewId: "11",
                    treeViewParentId: rootTreeNode.GUITreeViewID,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\48by48\\comment.png",
                    supportsDrillIn: "false",
                    isExpanded: "True",
                    isInitHighlighted: "false",
                    fontWeight: string.Empty,
                    supportsSelection: "true"));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "PADR Goals",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "TreeView2",
                    treeViewId: "12",
                    treeViewParentId: rootTreeNode.GUITreeViewID,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\target.png",
                    supportsDrillIn: "True",
                    isExpanded: "True",
                    isInitHighlighted: "false",
                    fontWeight: string.Empty,
                    supportsSelection: "true"));

        }

        private void DrillIntoFirstListView(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Goal #1",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: "This is the Managers Folder. You can't navigate to this item",
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\target.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: string.Empty,
                    description: "Increase Industrial knowledge in Development organization..."));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Goal #1",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: "This is the Managers Folder. You can't navigate to this item",
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\target.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: "True",
                    description: "Reduce the skills gap by 30% by Q4"));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Goal #3",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: "This is the Managers Folder. You can't navigate to this item",
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\target.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: "True",
                    description: "Improve the cyber security capability of software organization in design, implementation, and infastructre"));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Goal #4",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\target.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: "True",
                    description: "Improve the out of the box features and align features to our customer"));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Goal #5",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\target.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: "True",
                    description: "Deploy consistent use of static analysis tools..."));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Goal #6",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\target.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: "True",
                    description: "Stretch goal. Have stable and ship ready product at end of sprint ..."));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Goal #7",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\target.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: "True",
                    description: "Support/Contribute to strategy behind Studio 5000"));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Dev Goal #1",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\check1_16.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: "True",
                    description: "... my dev goal #1 details .... Web tech skills"));

            queryCache.AddDataItem(
                this.CreateDataItemBase(
                    name: "Dev Goal #2",
                    datatype: DATATYPE_PERSONDETAILS,
                    viewType: "ListView1",
                    treeViewId: string.Empty,
                    treeViewParentId: string.Empty,
                    tooltip: string.Empty,
                    automationId: string.Empty,
                    automationName: string.Empty,
                    imagePath: this.baseAssemblyLocationURIString + "\\Images\\16by16\\check1_16.png",
                    supportsDrillIn: "False",
                    isExpanded: string.Empty,
                    isInitHighlighted: string.Empty,
                    fontWeight: string.Empty,
                    supportsSelection: "True",
                    description: "... my dev goal #2 details .... Read book on ..."));
        }

        #endregion
    }
}
