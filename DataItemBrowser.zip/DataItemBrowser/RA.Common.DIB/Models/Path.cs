/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// This class wraps all the functionality that of the PathElementsObservableCollection.
    /// When a PathElement is added, replaced or modified it should be done through this class
    /// and not directly to the Items property.
    /// </summary>
    public class Path: INotifyPropertyChanged
    {
        private PathElementObservableCollection _items = new PathElementObservableCollection();
        /// <summary>
        /// Items in this collection property, DO NOT USE FOR MODIFYING THE COLLECTION
        /// </summary>
        public PathElementObservableCollection Items
        {
            get { return _items; }
        }
        
        /// <summary>
        /// this is the last item highlighted in the datagrid view, it is only updated if 
        /// there are no forward breadcrumbs and the user single clicks on an item
        /// </summary>
        private IPathElement _savedHighlightedElement = null;
        public IPathElement SavedHighlightedElement
        {
            get { return _savedHighlightedElement; }
            set 
            {
                if (_savedHighlightedElement != value)
                {
                    _savedHighlightedElement = value;
                    NotifyPropertyChanged("SavedHighlightedElement");
                }
            }
        }
        /// <summary>
        /// this is the currently highlighted item in the datagrid view
        /// </summary>
        private IPathElement _highlightedElement = null;
        public IPathElement HighlightedElement
        {
            get { return _highlightedElement; }
            set
            {
                if (_highlightedElement != value)
                {
                    _highlightedElement = value;
                    NotifyPropertyChanged("HighlightedElement");
                }
            }
        }
        /// <summary>
        /// clone the path object
        /// </summary>
        /// <returns></returns>
        public Path Clone()
        {
            Path clonedPath = new Path();
            foreach (IPathElement pathElement in Items)
            {
                clonedPath.Items.Add(pathElement);
            }
            clonedPath.HighlightedElement = this.HighlightedElement;
            clonedPath.SavedHighlightedElement = this.SavedHighlightedElement;
            return clonedPath;
        }
        /// <summary>
        /// replace the path object
        /// </summary>
        /// <param name="path">new path</param>
        public void Replace(Path path)
        {
            Items.ClearPreserveHome();
            foreach (IPathElement pathElement in path.Items)
            {
                this.Items.Add(pathElement);
            }
            //do not restore the highlighted path or saved highlighted path because
            //they may have been updated since the clone
        }

        
        /// <summary>
        /// this method will find the last active container element in the collection, this can
        /// be either a controller or a program if included in the collection.  The container must
        /// be active to be considered in the collection.
        ///
        /// </summary>
        public IPathElement LastContainerElement
        {
            get
            {
                IPathElement container = null;
                foreach (IPathElement pe in Items)
                {
                    if (pe.IsContainer && pe.IsActive)
                        container = pe;
                    else
                        break;
                }
                return container;
            }
        
        }
        /// <summary>
        /// this wires up event handling to the PathElementsObservableCollection
        /// </summary>
        /// <param name="eventHandler"></param>
        public void AddActivePathChangedEventHandler(PropertyChangedEventHandler eventHandler)
        {
            Items.ActivePathChanged += eventHandler;
        }

        /// <summary>
        /// this removes event handler to the PathElementsObservableCollection
        /// </summary>
        /// <param name="eventHandler"></param>
        public void RemoveActivePathChangedEventHandler(PropertyChangedEventHandler eventHandler)
        {
            Items.ActivePathChanged -= eventHandler;
        }

        /// <summary>
        /// this method will get the pathelement immediately after this datasource element
        /// </summary>
        /// <param name="DataSource"></param>
        /// <returns></returns>
        public IPathElement GetPathElementAfterThisDataSource(string DataSource)
        {
            //no path elements
            if (Items.Count <= 1)
                return null;
            //no datasource
            if (DataSource.Length == 0)
                return Items[1];
            //search for matching datasource
            int i = 0;
            for(i = 0; i < this.Items.Count; i++)
            {
                if ((this.Items[i].DisplayName.Equals(DataSource, StringComparison.CurrentCultureIgnoreCase)) && (this.Items[i].IsContainer))
                {
                    //add one to get to the next pathelement
                    i++;
                    break;
                }
            }
            //return pathelement past datasource
            if (i < Items.Count)
                return Items[i];
            //datasource not found
            return null;
        }

        /// <summary>
        /// the selected or active path property
        /// </summary>
     
        public List<IPathElement> SelectedPath
        {           
           // Returns the bread crumb path up to the first inactive crumb           
            get
            {
                List<IPathElement> peActiveList = new List<IPathElement>();

                foreach (IPathElement pe in Items)
                {
                    if (pe.IsActive)
                    {
                        peActiveList.Add(pe);
                    }
                    else
                        break;
                }

                return peActiveList;
            }
        }

        private List<IPathElement>_userSetHighlightedPath = null;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly",Justification = "Setter is used by the TAF plugin")]
        public List<IPathElement> UserSetHighlightedPath 
        {
            get
            {
                return _userSetHighlightedPath;
            }

            set //TAF Actor uses this
            {
                _userSetHighlightedPath = value;               
            } 
        }

        //used for unit tests
        private IPathElement fowardPathElement = null;
        /// <summary>
        /// gets the path element in front of active element, this does not change the active 
        ///state of the collection
        /// </summary> 
        public IPathElement Forward
        {
            get
            {
                if (fowardPathElement != null)
                    return fowardPathElement;

                int forward = getActiveIndex() + 1;
                if (forward < 0)
                    return null;
                if (forward < Items.Count)
                    return Items[forward];
                return null;
            }
            set //used in unit tests
            {
                fowardPathElement = value;
            }
        }
        /// <summary>
        /// gets the path element behind of active element, this does not change the active 
        ///state of the collection
        /// </summary>
        public IPathElement Back
        {
            get
            {
                int back = getActiveIndex() - 1;
                if (back < 0)
                    return null;
                return Items[back];
            }
        }
        /// <summary>
        /// Indicates whether the current active element exists and is initialized
        /// </summary>
        public bool HasActiveElement()
        {
            IPathElement currentActive = this.ActiveElement;
            if (currentActive == null) return false;
            if (currentActive.DataItem == null) return false;
            return true;
        }
        /// <summary>
        /// gets the active path element in the collection
        /// </summary>
        public IPathElement ActiveElement
        {
            get
            {
                if (getActiveIndex() < 0)
                    return null;
                return Items[getActiveIndex()];
            }
        }
        /// <summary>
        /// sets the active path element in the collection
        /// </summary>
        /// <param name="element"></param>
        public void SetActive(IPathElement element)
        {
            //if the active crumb is home (element == null) than none of the other crumbs are active
            bool active = true;
            if (element == null)
                active = false;

            foreach (IPathElement pe in Items)
            {
                pe.IsActive = active;
                if (pe == element)
                    active = false;
            }
        }

        /// <summary>
        /// gets the index in the collection of the active pathelement
        /// </summary>
        /// <returns></returns>
        private int getActiveIndex()
        {
            if (Items.Count == 0)
                return -1;
            int active = 0;
            for (active = 0; active < Items.Count; active++)
            {
                if (!Items[active].IsActive)
                {
                    break;
                }
            }
            return active - 1;
        }
        /// <summary>
        /// removes all inactive or forward pathelements
        /// </summary>
        public void RemoveInactiveElements()
        {
            // Determine if any forward crumbs are actually removed.
            bool fwdCrumbRemoved = false;
            for (int i = Items.Count - 1; i >= 0; i--)
            {
                if (Items[i].IsActive == false)
                {
                    Items.Remove(Items[i]);
                    fwdCrumbRemoved = true;
                }
            }

            // If forward crumbs removed clear the SavedHighlightedItem
            if (fwdCrumbRemoved)
                this._savedHighlightedElement = null;
        }
        /// <summary>
        /// this will change the active pathelement to the one in front of the currently active 
        /// pathelement
        /// </summary>
        public void NavigateForward()
        {
            int forward = getActiveIndex() + 1;
            if (forward <= 0)
                return;
            if (forward < Items.Count)
                this.SetActive(Items[forward]);
        }
        /// <summary>
        /// this will change the active pathelement to the one behind the currently active 
        /// pathelement
        /// </summary>
        public void NavigateBack()
        {
            int back = getActiveIndex() - 1;
            if (back < 0)
            {
                this.SetActive(null);
                return;
            }
            this.SetActive(Items[back]);
        }
        /// <summary>
        /// this method will replace the pathelement that matches the "pathElement" parameter and
        /// will replace it with a pathelement defined by the other parameters passed in.  This method
        /// will also remove any pathelements after the one that is replaced.  This will be used when
        /// we are doing droparrow navigation from the breadcrumbs
        /// </summary>
        /// <param name="pathElement">the path element we are replacing</param>
        /// <param name="newPathElement">the new path element </param>
        /// <returns></returns>
        public bool ReplaceElement(IPathElement pathElement, IPathElement newPathElement)
        {
            List<IPathElement> savedPathElements = new List<IPathElement>();
            
            // a null pathelement means you are at the front of the path
            if (pathElement != null)
            {
                //save the current last element
                foreach (IPathElement pe in Items)
                {
                    if (pe == pathElement)
                        break;
                    //do not save the home pe it is never deleted
                    if (!(pe is HomePathElement))
                        savedPathElements.Add(pe);

                }
            }

            // Determine if elements did get removed.
            if (savedPathElements.Count != Items.Count)
                // clear out the SavedHighlighted Item also.
                SavedHighlightedElement = null;

            Items.ClearPreserveHome();
            //restore the pathelements not removed
            foreach (IPathElement pe in savedPathElements)
            {
                Items.Add(pe);
            }
            //add the next pathelement
            Add(newPathElement);
            return true;
  
        }
        /// <summary>
        /// find the path element associated with this drop arrow item
        /// </summary>
        /// <param name="dropArrowItem">drop arrow item</param>
        /// <returns>IPathElement if found, null otherwise</returns>
        public IPathElement FindElement(DropArrowItem dropArrowItem)
        {
            for (int i = 0; i<Items.Count(); i++)
            {
                //make sure the display name and is container match
                if (Items[i].DisplayName.Equals(dropArrowItem.DisplayName, StringComparison.CurrentCultureIgnoreCase) &&
                    Items[i].IsContainer == dropArrowItem.IsContainer)
                {
                    return Items[i];
                }
            }
            return null;
        }

        /// <summary>
        /// add this path element to the end of the collection.  If this collection has forward
        /// elements and adding this element may cause the forward elements to be deleted.
        /// </summary>
        /// <param name="pathElement">IPathElement object</param>
        /// <returns>true</returns>
        public bool Add(IPathElement pathElement)
        {
            if (this.Forward != null)
            {
                if ((this.Forward.DisplayName.Equals(pathElement.DisplayName, StringComparison.CurrentCultureIgnoreCase)) && 
                    (this.Forward.IsContainer == pathElement.IsContainer)) 
                {
                    SetActive(this.Forward);
                    return true;
                }
            }
            else
            {
                //Since there are no forward pathelements we want to clear SavedHighlightedElement to nothing
                this.SavedHighlightedElement = null;
            }

            //remove any forward pathelements that do not work with this new path
            RemoveInactiveElements();
            Items.Add(pathElement);
            return true;
        }
 
        /// <summary>
        /// clears the pathelements observable collection
        /// </summary>
        public void Clear()
        {
            Items.Clear();
        }

       
        /// <summary>
        /// return the last element in the collection
        /// </summary>
        public IPathElement Last
        {
            get {
                return Items.Count > 0 ? Items[Items.Count - 1] : null;
            }
        }

        /// <summary>
        /// returns whether or not the current path is inside an HMI Device.
        /// </summary>
        /// <returns>Boolean representing whether or not the current path is inside an HMI Device.</returns>
        public bool isBrowsingHMIDevice()
        {
            if (Items.Count < 2) return false;
            IPathElement baseItem = Items[1];
            if (baseItem == null || baseItem.DataItem == null) return false;
            if (!baseItem.IsActive) return false;
            return DIResource.IsResourceTypeHMIDevice(baseItem.DataItem); 
        }

        #region INotifyPropertyChanged Members

        /// <summary>
        /// implements that INotifyPropertyChagned inteface method NotifyPropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;
        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion

        #region PathToString 


        /// <summary>
        /// converts a <see cref="List<IPathElement>"/> and optional NameToSelect into a full path specified as a string
        /// </summary>
        /// <param name="fullPath">list of IPathElement objects</param>
        /// <param name="NameToSelect">the selected item component of a full Path</param>
        /// <param name="browserType">the browser type</param>
        /// <returns>string representing the full connection path</returns>
        public static string PathToString(List<IPathElement> fullPath, string nameToSelect, DIBViewItemBase.VisualPerspectiveEnum browserType)
        {
            string returnPath = String.Empty;
            string deviceToTrim = string.Empty;         // used only for module and product data types to save the device
            bool fixUpReturnPath = false;               // used only for module and product data types to remove the device 
            // portion of the return path.
            if (fullPath.Count <= 1)
            {
                if (null != nameToSelect)
                    returnPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + nameToSelect;

                return returnPath;
            }

            if (browserType.Equals(DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser))
            {
                //skip the home path element for the data type browser, so start at path element 1
                // resolve device portion of the context string based on the "type" of data type.
                IPathElement pathElement = fullPath[1];

                if (pathElement is DataTypePathElement &&
                   ((pathElement as DataTypePathElement).ResourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE)))
                {
                    // in this case we are dealing with user-defined datatypes, we want to dislpay the device context 
                    // (i.e. the ::<devicetype>)
                    if (fullPath.Count < 3)
                    {
                        returnPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER;
                    }
                    else
                    {
                        DataItemBase item = fullPath[2].DataItem;
                        returnPath = item != null ? item.CommonLocation : DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER;
                    }
                }

                else if (pathElement is DataTypePathElement &&
                        (((pathElement as DataTypePathElement).ResourceType == DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE) ||
                        (((pathElement as DataTypePathElement).ResourceType == DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE))))
                {
                    // in this case we are dealing with predefined or module-defined, and of course we have some
                    // special handling conditions here as well.  When we 'return' path to the client, we need to 
                    // remove the device context (i.e. the ::<devicetype>) from the string, since this is the value
                    // that gets, displayed to the user in the UI.  This satisfies the "rule" that for predefined and 
                    // module-defined that the device is not shown.
                    returnPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + fullPath[1].DisplayName;
                    deviceToTrim = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + fullPath[1].DisplayName;
                    fixUpReturnPath = true;
                }
                else
                    returnPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + fullPath[1].DisplayName;
            }
            else
            {  // Tag Browser
         
                //process the home path element
                HomePathElement homePathElement = fullPath[0] as HomePathElement;
                
                if (homePathElement != null && homePathElement.DataItem != null)
                {
                    returnPath = HomeDataItemsToString(homePathElement.DataItemList);
                 }
            }

            // Process Remaining Elements
            if (fullPath.Count > 1)
            {
                for (int index = 1; index < fullPath.Count; index++)
                {
                    //the datatype item was handled above do not process again
                    if (fullPath[index] is DataTypePathElement)
                        continue;
                    //if it is a controller follow with device delimeter
                    if (fullPath[index] is ControllerPathElement)
                        // add controller pathdelimiter before the controller name.
                        returnPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + fullPath[index].DisplayName.Trim();
                    //if it is a HMIDevice follow with device delimeter
                    else if (fullPath[index] is HMIDevicePathElement)
                        // add controller pathdelimiter before the HMI device name.
                        returnPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + fullPath[index].DisplayName.Trim();
                    else if (fullPath[index] is ProgramPathElement)
                        // add the program's name preceded by its delimiter
                        returnPath += DIResource.DI_COMMON_RESOURCETYPE_PATH_DELIMITER + fullPath[index].DisplayName.Trim();
                    else if (fullPath[index] is DataLogPathElement)
                        // add the datalog's name preceded by "\@DataLogs\
                        returnPath += DIResource.DI_COMMON_RESOURCETYPE_SYSTEM_DEFINED_PATH_DELIMITER + DIResource.DI_COMMON_RESOURCETYPE_DATALOGS + DIResource.DI_COMMON_RESOURCETYPE_PATH_DELIMITER + fullPath[index].DisplayName.Trim();
                    else if (fullPath[index] is TagsPropertiesPathElement)
                        // Don't add Tags and Properties
                        continue;
                    else if (fullPath[index] is ProgramsPathElement)
                        // Don't add Programs folder nor its delimiter 
                        continue;
                    else if (fullPath[index] is DataLogsPathElement)
                        // Don't add Datalogs folder nor its delimiter
                        continue;
                    else
                    {
                        string name = fullPath[index].DisplayName.Trim();
                        int iArray = name.IndexOf(DIResource.DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER);

                        //is it an array remove all but array components.
                        if (iArray >= 0)
                            name = name.Substring(iArray, name.Length - iArray);

                        if (iArray < 0)
                        {
                            if (!String.IsNullOrEmpty(returnPath))
                                returnPath += DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER + name;
                            else
                                returnPath = name;
                        }
                        else
                            returnPath += name;
                    }
                }
            }

            // If a NameToSelect exists add it to the end of the returnPath
            if (null != nameToSelect)
            {
                // Add Delimiter if not an array
                int iArray = nameToSelect.IndexOf(DIResource.DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER);
                if (iArray < 0)
                    returnPath += DIResource.DI_COMMON_RESOURCETYPE_DATAITEM_DELIMITER + nameToSelect;
                else
                    returnPath += nameToSelect;
            }

            // special case when we are running as the DT Browser, and we are
            // dealing with a module or product data type.  We want to make
            // sure to strip any of the "device" information from the return 
            // path "::DeviceName\\".
            if (fixUpReturnPath)
            {
                // make sure we have a value for both the return path as-well-as
                // the device to trim.  If not just return what we have.
                if ((!string.IsNullOrEmpty(returnPath) && !string.IsNullOrEmpty(deviceToTrim)))
                {
                    if (returnPath.Contains(deviceToTrim))
                    {
                        if (((fullPath.Count > 2) || ((fullPath.Count == 1) && (null != nameToSelect))) &&
                            returnPath.Length >= deviceToTrim.Length+1)
                            returnPath = returnPath.Remove(0, deviceToTrim.Length + 1);
                        else
                            returnPath = returnPath.Remove(0, deviceToTrim.Length);
                    }
                }
            }
            //make sure we do not return just "::", this can happen for UserDefined types when clicking in the DSV
            if (returnPath == DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER)
                returnPath = string.Empty;
            return returnPath;
        }

        public static string HomeDataItemsToString(List<DataItemBase> dataItemList)
        {
            string returnPath = string.Empty;
            //process all the dataitems in the home path elemenet
            foreach (DataItemBase dataItem in dataItemList)
            {
                UUID itemType = dataItem.GetResourceTypeAsUUID();
                if (ResourceBase.IsEqual(itemType, TypeIdentifiers.getResourceType_Controller()))
                    returnPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + dataItem.CommonName;
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_HMIDevice))
                    returnPath = DIResource.DI_COMMON_RESOURCETYPE_DEVICE_DELIMITER + dataItem.CommonName;
                else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Program))
                    returnPath += DIResource.DI_COMMON_RESOURCETYPE_PATH_DELIMITER + dataItem.CommonName;
                else if (!ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_TagsAndProperties)&&
                         !ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Programs)&&
                         !ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_DataLogs))
                    returnPath += dataItem.CommonName;
            }
            return returnPath;
  
        }
        #endregion

       
    }

   
}
