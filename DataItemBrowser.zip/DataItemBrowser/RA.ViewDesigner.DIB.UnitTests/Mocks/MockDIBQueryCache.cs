﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Models;
using RockwellAutomation.Client.Services.Query;

namespace DataItemBrowserUT.Mocks
{
    class MockDIBQueryCache : DIBQueryCache
    {
        TSObservableCollection<DataItemBase> _dataItems;
        public bool GetChildrenOfCrumbCalled = false;
        public bool GetCachedDevicesCalled = false;
        public bool GetDeviceItemByNameCalled = false;
        public bool GetDataItemByNameCalled = false;
        public bool GetDataTypeItemByLocationCalled = false;
        public bool ClearDataItemsCalled = false;
        
        public MockDIBQueryCache(TSObservableCollection<DataItemBase> dataItems) : base(dataItems)
        {
            _dataItems = dataItems;
        }

        public override List<DropArrowItem> GetChildrenOfCrumb(ACrumb crumb, string nextName, DataContext dataContext, IClientDataServices cds)
        {
            GetChildrenOfCrumbCalled = true;
            List<DropArrowItem> itemList = new List<DropArrowItem>();
            return itemList;
        }

        public TSObservableCollection<DataItemBase> cachedDevices = new TSObservableCollection<DataItemBase>();
        public override IObservableCollection<DataItemBase> GetCachedDevices()
        {
            GetCachedDevicesCalled = true;
            return cachedDevices;
        }

        public override DataItemBase GetDeviceItemByName(string deviceName)
         {
             GetDeviceItemByNameCalled = true;
             DataItemBase dib = new DataItemBase();
             return dib;
         }

        public override DataItemBase GetDataItemByName(string itemName, string location = null)
        {
            GetDataItemByNameCalled = true;
            DataItemBase dib = new DataItemBase();
            return dib;
        }

        public override DataItemBase GetDataTypeItemByLocation(string datatype, string location)
        {
            GetDataTypeItemByLocationCalled = true;
            DataItemBase dib = new DataItemBase();
            return dib;
        }
        public override void ClearDataItems()
        {
            ClearDataItemsCalled = true;
        }
    }
}
