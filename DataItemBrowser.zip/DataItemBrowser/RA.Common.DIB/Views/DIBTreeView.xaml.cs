using System.Windows.Controls;
using RockwellAutomation.UI.ViewModels;
using System.Windows.Input;
using System.Collections.Generic;
using RockwellAutomation.UI.Models;
using System.Windows;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System;


namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Interaction logic for DIBTreeView.xaml
    /// </summary>
    public partial class DIBTreeView : TreeView
    {
        
        #region Constructor

        public DIBTreeView()
        {
            InitializeComponent();
        }

        #endregion

        #region Variables/Properties

        // When grid is active and user presses an alphanumeric keyboard key, we select a row whose first column name matches what was typed (AutoSelection feature)
        // The list of characters is stored in currentAutoCompleteString
        private String currentAutoCompleteString { get; set; }
        //The last time a user types in a key
        private DateTime lastAutoCompleteKeyInputTime { get; set; }

        private DIBTreeViewModel _treeViewModel = null;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        private DIBTreeViewModel TreeViewModel
        {
            get {
                if (_treeViewModel == null) InitializeTreeViewModel();
                return _treeViewModel; 
                }
            set { _treeViewModel = value; }
        }

        /// <summary>
        /// </summary>
        /// <returns></returns>
        private DIBTreeViewItem SelectedItemAsDIBTreeViewItem()
        {
            return this.SelectedItem as DIBTreeViewItem;
        }

        #endregion

        #region Init/Cleanup

        private void InitializeTreeViewModel()
        {
            _treeViewModel = (DataContext as DIBTreeViewModel);
        }
        
        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {
            this.TreeViewModel.Cleanup();
        }

        #endregion

        #region Events
        /// <summary>
        /// Handle shift-tab in OnPreviewKeyDown
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            //The default tree view behavior is to handle the shift-tab move focus / traversal request in
            // the standard key down handler (as opposed to the preview event).  We need to handle it here
            // to support the bread crumb auto shown menu functionality (which won't work when using a
            // shift-tab from this tree to the crumbs without this code).
            if (e.Key == Key.Tab && (Keyboard.Modifiers & ModifierKeys.Shift) != 0)
            {
                this.MoveFocus(new TraversalRequest(FocusNavigationDirection.Previous));
                e.Handled = true;
            }
            else if (e.Key == Key.Enter)
            {
                DIBTreeViewItem itemSelected = this.SelectedItemAsDIBTreeViewItem();
                if (itemSelected != null && itemSelected.DataItem != null)
                {
                    e.Handled = true;
                    this.TreeViewModel.DoubleClickSelection(itemSelected.DataItem);
                    return;
                }
            }
            base.OnPreviewKeyDown(e);
        }

        public void ProcessKeyboardRequestDrillIn()
        {
            // Dont even attempt this if we are not visible
            if (this.TreeViewModel.Visible != Visibility.Visible)
                return;
            this.ProcessKeyboardRequestFocus();
            DIBTreeViewItem ItemObj = this.SelectedItemAsDIBTreeViewItem();
            if (ItemObj == null) return;
            
            if (!ItemObj.SupportsDrillIn)
            {
                // This is not a drillable item. We want to now select the first child
                if (ItemObj.Children.Count < 1) return;
                ItemObj.Children[0].IsSelected = true;
                UserChangedHighlightedItem();
                return;
            }

            this.TreeViewModel.DrillInCommand.Execute(ItemObj);
        }

        public void ProcessKeyboardRequestDrillOut()
        {
            // Dont even attempt this if we are not visible
            if (this.TreeViewModel.Visible != Visibility.Visible)
                return;

            this.ProcessKeyboardRequestFocus();

            if (this.TreeViewModel.Path.ActiveElement is HomePathElement)
            {
                //We are already at Home crumb select the parent of current item
                DIBTreeViewItem ItemObj = this.SelectedItemAsDIBTreeViewItem();
                if (ItemObj == null) return;
                if (ItemObj.Parent == null)
                {
                    // If there is no parent, then collapse the children
                    ItemObj.IsExpanded = false;
                    return;
                }
                ItemObj.Parent.IsSelected = true;
                UserChangedHighlightedItem();
                return;
            }
            this.TreeViewModel.DrillOutCommand.Execute(this.SelectedItemAsDIBTreeViewItem());
        }

        public void ProcessKeyboardRequestSelectPrevious()
        {
            // Dont even attempt this if we are not visible
            if (this.TreeViewModel.Visible != Visibility.Visible)
                return;
            DIBTreeViewItem ItemObj = this.SelectedItemAsDIBTreeViewItem();
            if (ItemObj == null) return;
            this.ProcessKeyboardRequestFocus();

            this.TreeViewModel.HighLightPreviousTreeNodeCommand.Execute(ItemObj);
            UserChangedHighlightedItem();
        }

        public void ProcessKeyboardRequestSelectNext()
        {
            // Dont even attempt this if we are not visible
            if (this.TreeViewModel.Visible != Visibility.Visible)
                return;
            DIBTreeViewItem ItemObj = this.SelectedItemAsDIBTreeViewItem();
            if (ItemObj == null) return;
            this.ProcessKeyboardRequestFocus();

            this.TreeViewModel.HighLightNextTreeNodeCommand.Execute(ItemObj);
            UserChangedHighlightedItem();
        }

        public void ProcessKeyboardRequestFocus()
        {
            // Dont even attempt this if we are not visible
            if (this.TreeViewModel.Visible != Visibility.Visible)
                return;
            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, (Action)(() => PrimProcessKeyboardRequestFocus(this)));
        }

        /// <summary>
        /// Give Keyboard Focus
        /// </summary>
        /// <param name="iElement"></param>
        private static void PrimProcessKeyboardRequestFocus(IInputElement iElement)
        {
            if (iElement == null) return;
            Keyboard.Focus(iElement);
        }

        /// <summary>
        /// We're interested in whether the user's selected a row (not drilling in) -- if they
        /// have, we fire an event.
        /// </summary>
        /// <param name="sender">unused</param>
        /// <param name="e">Standard event args from the framework</param>
        private void DataSourcesViewItem_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (this.TreeViewModel != null) this.UserChangedHighlightedItem();
        }

        /// <summary>
        /// We're interested in whether the user's selected a row (not drilling in) -- if they
        /// have, we fire an event.
        /// </summary>
        /// <param name="sender">unused</param>
        /// <param name="e">Standard event args from the framework</param>
        private void DataSourcesViewItem_PreviewKeyUp(object sender, KeyEventArgs e)
        {
            if (this.TreeViewModel == null) return;

            //There is a scenario where the view gains focus while a keyboard key is down somewhere else in
            // the DIB (such as the search control) - and we get in this code immediately before the selected
            // item has been set.  To avoid any issue, simply return if we don't yet have a selection.
            DIBTreeViewItem itemSelected = this.SelectedItemAsDIBTreeViewItem();
            if (itemSelected == null) return;

            switch (e.Key)
            {
                case Key.Up:
                case Key.Down:
                case Key.PageUp:
                case Key.PageDown:
                case Key.Home:
                case Key.End:
                case Key.Left:
                case Key.Right:
                    {
                        UserChangedHighlightedItem();
                        break;
                    }
                default:
                    break;
            }        
        }

        /// <summary>
        /// The user may have changed the highlighted item -- we'll figure out if the
        /// highlighted item truly has changed and notify the user accordingly.
        /// </summary>
        private void UserChangedHighlightedItem()
        {
            DIBTreeViewItem itemSelected = this.SelectedItemAsDIBTreeViewItem();
            if (itemSelected == null) return;

            if (itemSelected.DataItem == null)
                    this.TreeViewModel.Path.HighlightedElement = null;
            this.TreeViewModel.ProcessUserSetHighlightedItem(itemSelected.DataItem);
                   
        }

        private void DataSourcesView_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            this.InitializeTreeViewModel();
        }

        private void DataSourcesTreeView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            TreeViewItem senderItem = sender as TreeViewItem;
            if (senderItem == null || !senderItem.IsSelected) return;

            DIBTreeViewItem node = this.SelectedItemAsDIBTreeViewItem();
            if (node == null) return;
            if (node.DataItem == null) return;
            this.TreeViewModel.DoubleClickSelection(node.DataItem);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataSourcesTreeViewItem_KeyUp(object sender, KeyEventArgs e)
        {
            // Dont even attempt this if we are not visible
            if (this.TreeViewModel.Visible != Visibility.Visible)
                return;

            //Attempt to process Device View AutoSelection (Select row in device view with first column Name matching keyboard string user has entered during last 2 seconds)
            if (!KeyboardNavigation.IsValidGridAutoSelectionKey(e)) return;
            this.ProcessKeyboardAutoSelect(e);
        }


        /// <summary>
        /// Attempt to autoselect a row in the grid based on user keyboard input
        /// </summary>
        private void ProcessKeyboardAutoSelect(KeyEventArgs e)
        {
            this.AddToCurrentAutoCompleteString(e);
            string input = this.currentAutoCompleteString;

            DIBTreeViewItem selectedItem = this.SelectedItemAsDIBTreeViewItem();
            DIBTreeViewItem parent = selectedItem.Parent as DIBTreeViewItem;
            if (parent == null) parent = selectedItem;
            
            //Look for autocomplete selection string
            foreach(IVisualBase item in parent.Children)
            {
                if (item == null) continue;
                String tName = item.VisualName.Trim().ToLower();
                if (tName.StartsWith(input))
                {
                    item.IsSelected = true;
                    this.UserChangedHighlightedItem();
                    e.Handled = true;
                    return;
                }
            }

            //if we have only one character in the currentAutoCompleteString and we didn't find any selection, empty out currentAutoCompleteString
            if (this.currentAutoCompleteString.Length == 1) currentAutoCompleteString = String.Empty;
        }

        /// <summary>
        /// Add the key contained in "e" to the auto complete string
        /// </summary>
        /// <param name="e">Contains the key to add</param>
        private void AddToCurrentAutoCompleteString(KeyEventArgs e)
        {
            if (this.lastAutoCompleteKeyInputTime == null) this.lastAutoCompleteKeyInputTime = DateTime.Now;
            //if its been over 2 seconds since the last keypress, then reset the currentAutoComplete string
            if (DateTime.Now.Subtract(lastAutoCompleteKeyInputTime) >= TimeSpan.FromSeconds(2)) this.currentAutoCompleteString = String.Empty;
            currentAutoCompleteString = currentAutoCompleteString + KeyboardNavigation.stringValueOfKey(e);
            this.lastAutoCompleteKeyInputTime = DateTime.Now;
        }

        #endregion

    }

}
