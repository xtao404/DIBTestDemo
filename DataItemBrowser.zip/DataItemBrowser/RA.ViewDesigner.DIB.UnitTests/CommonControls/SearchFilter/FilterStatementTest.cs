﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.CommonControls;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for FilterStatementTest and is intended
    ///to contain all FilterStatementTest Unit Tests
    ///</summary>
    [TestClass()]
    public class FilterStatementTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for OperatorToken
        ///</summary>
        [TestMethod()]
        public void FilterStatement_OperatorTokenTest()
        {
            FilterStatement target = new FilterStatement();
            ParserToken expected = new ParserToken(SearchFilterParser.BaseOperatorGroup,"OR", 0, false);
            target.OperatorToken = expected;
            ParserToken actual = target.OperatorToken;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for FilterValues
        ///</summary>
        [TestMethod()]
        public void FilterStatement_FilterValuesTest()
        {
            FilterStatement target = new FilterStatement();
            Collection<ParserToken> expected = new Collection<ParserToken>();
            expected.Add(new ParserToken(SearchFilterParser.ValueGroup,"myValue", 3, false));
            expected.Add(new ParserToken(SearchFilterParser.ValueGroup,"DINT", 7, true));
            target.FilterValues = expected;
            Collection<ParserToken> actual = target.FilterValues;
            Assert.AreEqual(expected[0], actual[0]);
            Assert.AreEqual(expected[1], actual[1]);
        }

        /// <summary>
        ///A test for FilterType
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void FilterStatement_FilterTypeTest()
        {
            FilterStatement target = new FilterStatement();
            PrivateObject targetPrivate = new PrivateObject(target);
            ParserToken expected = new ParserToken(SearchFilterParser.FilterOperatorGroup, "datatype=", 9, false);
            
            targetPrivate.SetFieldOrProperty("FilterType", expected);
            ParserToken actual = target.FilterType;
            Assert.AreEqual(expected, actual);
        }


        /// <summary>
        ///A test for FullStatementTest
        ///</summary>
        [TestMethod()]
        public void FilterStatement_FullStatementTest()
        {
            string expectedType = "datatype=";
            int startingTypeIndex = 100;
            bool typeExactMatch=false;
            string expectedOperator = "AND";
            int startingOperatorIndex = 100;
            bool operatorExactMatch=false;

            string[] expectedValues = {"specialUDT","BOOL"};
            int[] startingValueIndices = {28, 68};
            bool[] valuesExactMatch = {true, false};

            FilterStatement target = new FilterStatement();
            PrivateObject targetPrivate = new PrivateObject(target);
            Collection<ParserToken> values = new Collection<ParserToken>();
            targetPrivate.SetFieldOrProperty("FilterType", new ParserToken(SearchFilterParser.FilterOperatorGroup,expectedType, startingTypeIndex, typeExactMatch));
            target.OperatorToken = new ParserToken(SearchFilterParser.BaseOperatorGroup, expectedOperator, startingOperatorIndex, operatorExactMatch);
            values.Add(new ParserToken(SearchFilterParser.ValueGroup, expectedValues[0], startingValueIndices[0], valuesExactMatch[0]));
            values.Add(new ParserToken(SearchFilterParser.ValueGroup, expectedValues[1], startingValueIndices[1], valuesExactMatch[1]));
            target.FilterValues = values;
            FilterStatement actual = target;

            //test filter type
            Assert.AreEqual(actual.FilterType.Value, expectedType);
            Assert.AreEqual(actual.FilterType.StartingIndex, startingTypeIndex);
            Assert.AreEqual(actual.FilterType.ExactMatch, typeExactMatch);

            //test operator
            Assert.AreEqual(actual.OperatorToken.Value, expectedOperator);
            Assert.AreEqual(actual.OperatorToken.StartingIndex, startingOperatorIndex);
            Assert.AreEqual(actual.OperatorToken.ExactMatch, operatorExactMatch);

            //test first value
            Assert.AreEqual(actual.FilterValues[0].Value, expectedValues[0]);
            Assert.AreEqual(actual.FilterValues[0].StartingIndex, startingValueIndices[0]);
            Assert.AreEqual(actual.FilterValues[0].ExactMatch, valuesExactMatch[0]);

            //test second value
            Assert.AreEqual(actual.FilterValues[1].Value, expectedValues[1]);
            Assert.AreEqual(actual.FilterValues[1].StartingIndex, startingValueIndices[1]);
            Assert.AreEqual(actual.FilterValues[1].ExactMatch, valuesExactMatch[1]);
        }

        /// <summary>
        ///Get the search string for the filter statement
        ///</summary>
        [TestMethod()]
        public void FilterStatement_GetSearchString()
        {
            string expectedType = "datatype=";
            int startingTypeIndex = 100;
            bool typeExactMatch = false;
            string expectedOperator = "AND";
            int startingOperatorIndex = 100;
            bool operatorExactMatch = false;

            string[] expectedValues = {"specialUDT", "BOOL"};
            int[] startingValueIndices = {28, 68};
            bool[] valuesExactMatch = {true, false};

            FilterStatement target = new FilterStatement();
            PrivateObject targetPrivate = new PrivateObject(target);
            Collection<ParserToken> values = new Collection<ParserToken>();
            targetPrivate.SetFieldOrProperty("FilterType", new ParserToken(SearchFilterParser.FilterOperatorGroup, expectedType, startingTypeIndex, typeExactMatch));
            target.OperatorToken = new ParserToken(SearchFilterParser.BaseOperatorGroup, expectedOperator, startingOperatorIndex, operatorExactMatch);
            values.Add(new ParserToken(SearchFilterParser.ValueGroup, expectedValues[0], startingValueIndices[0], valuesExactMatch[0]));
            values.Add(new ParserToken(SearchFilterParser.ValueGroup, expectedValues[1], startingValueIndices[1], valuesExactMatch[1]));
            target.FilterValues = values;          

            string value = target.GetSearchString();

            Assert.IsTrue(value.Contains(expectedOperator) && value.Contains(expectedValues[0]) && value.Contains(expectedValues[1]));
        }

         /// <summary>
        ///A test for toString
        ///</summary>
        [TestMethod()]
        public void FilterStatement_ToString()
         {
             FilterStatement target = new FilterStatement("name:","myValue",false,SearchFilterDefinition.StatementLogic.AND);
             target.FilterValues.Add(new ParserToken(SearchFilterParser.ValueGroup, "DINT", 7, true));
             string result = target.ToString();

            Assert.IsTrue(result.Contains("myValue") && result.Contains("DINT"));
         }
    }
}
