using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using RockwellAutomation.UI.Windows;
using System.Globalization;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace PopupTestHost
{
    /// <summary>
    /// Interaction logic for PropertyEditorWithTagBrowser.xaml
    /// </summary>
    public partial class PropertyEditorWithTagBrowser : UserControl
    {
        #region private data
        /// <summary>
        /// property for tag browser window 
        /// </summary>
        private DIBWindow _browser;

        #endregion //private data

        /////////////////////////////////////////////////////////////////////////////////////////////////////

        #region properties
        /// <summary>
        /// TagName dependency property - path to tag name
        /// </summary>
        public readonly static DependencyProperty TagNameProperty = DependencyProperty.Register("TagName", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));
 

        /// <summary>
        /// Tag Name property
        /// </summary>
        public string TagName
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.TagNameProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.TagNameProperty, value);
            }
        }


        /// <summary>
        /// Whether or not to use a data context object when inititializing the DIB
        /// </summary>
        public bool UseDataContext
        {
            get { return (bool)GetValue(UseDataContextProperty); }
            set { SetValue(UseDataContextProperty, value); }
        }

        /// <summary>
        /// Enable or disable the use of the data context object for DIB initialization
        /// </summary>
        public static readonly DependencyProperty UseDataContextProperty =
            DependencyProperty.Register("UseDataContext", typeof(bool), typeof(PropertyEditorWithTagBrowser), new UIPropertyMetadata(false));

        
        /// <summary>
        /// Root dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty RootProperty = DependencyProperty.Register("Root", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// Root property
        /// </summary>
        public string Root
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.RootProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.RootProperty, value);
            }
        }


        /// <summary>
        /// Include dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty IncludeProperty = DependencyProperty.Register("Include", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));
        /// <summary>
        /// Include property
        /// </summary>
        public string Include
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.IncludeProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.IncludeProperty, value);
            }
        }
        /// <summary>
        /// ExcludeAllChildrenFrom dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty ExcludeAllChildrenFromProperty = DependencyProperty.Register("ExcludeAllChildrenFrom", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));
        /// <summary>
        /// ExcludeAllChildrenFrom property
        /// </summary>
        public string ExcludeAllChildrenFrom
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.ExcludeAllChildrenFromProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.ExcludeAllChildrenFromProperty, value);
            }
        }

        /// <summary>
        /// ExcludeAllChildrenFromRootProperty dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty ExcludeAllChildrenFromRootProperty = DependencyProperty.Register("ExcludeAllChildrenFromRoot", typeof(bool), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(false));
        /// <summary>
        /// ExcludeAllChildrenFromRoot property
        /// </summary>
        public bool ExcludeAllChildrenFromRoot
        {
            get
            {
                return ((bool)(base.GetValue(PropertyEditorWithTagBrowser.ExcludeAllChildrenFromRootProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.ExcludeAllChildrenFromRootProperty, value);
            }
        }

        /// <summary>
        /// DisplayMetaDataProperty dependency property - specifies if we want to display metaData
        /// </summary>
        public readonly static DependencyProperty DisplayMetaDataProperty = DependencyProperty.Register("DisplayMetaData", typeof(bool), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(true));

        /// <summary>
        /// DisplayMetaData property - Do we want to show metadata?
        /// </summary>
        public bool DisplayMetaData
        {
            get
            {
                return ((bool)(base.GetValue(PropertyEditorWithTagBrowser.DisplayMetaDataProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.DisplayMetaDataProperty, value);
            }
        }
        
        /// <summary>
        /// Root view dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty RootNavIntoFolderProperty = DependencyProperty.Register("RootNavIntoFolder", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// RootNavIntoFolder property
        /// </summary>
        public string RootNavIntoFolder
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.RootNavIntoFolderProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.RootNavIntoFolderProperty, value);
            }
        }

        /// <summary>
        /// Context FilterType dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty ContextFilterTypeProperty = DependencyProperty.Register("ContextFilterType", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// ContextFilterType property
        /// </summary>
        public string ContextFilterType
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.ContextFilterTypeProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.ContextFilterTypeProperty, value);
            }
        }

        /// <summary>
        /// Context FilterValue dependency property -
        /// </summary>
        public readonly static DependencyProperty ContextFilterValueProperty = DependencyProperty.Register("ContextFilterValue", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// Context FilterValue property
        /// </summary>
        public string ContextFilterValue
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.ContextFilterValueProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.ContextFilterValueProperty, value);
            }
        }

        /// <summary>
        /// Context Filter Exact match dependency property 
        /// </summary>
        public readonly static DependencyProperty ContextFilterExactMatchProperty = DependencyProperty.Register("ContextFilterExactMatch", typeof(bool), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(false));

        /// <summary>
        /// Context Filter is exact match property
        /// </summary>
        public bool ContextFilterExactMatch
        {
            get
            {
                return ((bool)(base.GetValue(PropertyEditorWithTagBrowser.ContextFilterExactMatchProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.ContextFilterExactMatchProperty, value);
            }
        }


        /// <summary>
        /// ExcludeAllChildrenOfType dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty ExcludeAllChildrenOfTypeProperty = DependencyProperty.Register("ExcludeAllChildrenOfType", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));
        /// <summary>
        /// ExcludeAllChildrenOfType property
        /// </summary>
        public string ExcludeAllChildrenOfType
        {
            get
            {
                return (string)(base.GetValue(PropertyEditorWithTagBrowser.ExcludeAllChildrenOfTypeProperty));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.ExcludeAllChildrenOfTypeProperty, value);
            }
        }

        /// <summary>
        /// ExcludeAllOfType dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty ExcludeAllOfTypeTypeProperty = DependencyProperty.Register("ExcludeAllOfType", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));
        /// <summary>
        /// ExcludeAllOfType property
        /// </summary>
        public string ExcludeAllOfType
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.ExcludeAllOfTypeTypeProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.ExcludeAllOfTypeTypeProperty, value);
            }
        }

        /// <summary>
        /// IncludeAllOfType dependency property - data context root
        /// </summary>
        public readonly static DependencyProperty IncludeAllOfTypeProperty = DependencyProperty.Register("IncludeAllOfType", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));
        /// <summary>
        /// IncludeAllOfType property
        /// </summary>
        public string IncludeAllOfType
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.IncludeAllOfTypeProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.IncludeAllOfTypeProperty, value);
            }
        }
        /// <summary>
        /// SelectedItemResourceID dependency property - path to tag name
        /// </summary>
        public readonly static DependencyProperty SelectedItemResourceIDProperty = DependencyProperty.Register("SelectedItemResourceID", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// SelectedItemResourceID property
        /// </summary>
        public string SelectedItemResourceID
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.SelectedItemResourceIDProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.SelectedItemResourceIDProperty, value);
            }
        }

        /// <summary>
        /// HighlightedItem dependency property
        /// </summary>
        public readonly static DependencyProperty HighlightedItemProperty = DependencyProperty.Register("HighlightedItem", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// HighlightedItem property
        /// </summary>
        public string HighlightedItem
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.HighlightedItemProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.HighlightedItemProperty, value);
            }
        }

        /// <summary>
        /// UserSetHighlightedItem dependency property
        /// </summary>
        public readonly static DependencyProperty UserSetHighlightedItemProperty = DependencyProperty.Register("UserSetHighlightedItem", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// UserSetHighlightedItem property
        /// </summary>
        public string UserSetHighlightedItem
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.UserSetHighlightedItemProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.UserSetHighlightedItemProperty, value);
            }
        }

        /// <summary>
        /// UserSetHighlightedItemResourceIDProperty dependency property
        /// </summary>
        public static DependencyProperty UserSetHighlightedItemResourceIDProperty = DependencyProperty.Register("UserSetHighlightedItemResourceID",
                                typeof(string), typeof(PropertyEditorWithTagBrowser), new PropertyMetadata(null));
        public string UserSetHighlightedItemResourceID
        {
            get { return (string)GetValue(PropertyEditorWithTagBrowser.UserSetHighlightedItemResourceIDProperty); }
            set { SetValue(PropertyEditorWithTagBrowser.UserSetHighlightedItemResourceIDProperty, value); }
        }

        /// <summary>
        /// Data Provider dependency property
        /// </summary>
        public readonly static DependencyProperty DataProviderProperty = DependencyProperty.Register("DataProvider", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// DataProvider property
        /// </summary>
        public string DataProvider 
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.DataProviderProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.DataProviderProperty, value);
            }
        }

        /// <summary>
        /// BrowserType dependency property - specifies either which type of data item browser should be launched
        /// </summary>
        public readonly static DependencyProperty BrowserTypeProperty = DependencyProperty.Register("BrowserType", typeof(string), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(""));

        /// <summary>
        /// BrowserType property - should the Tag or DataType browser be shown?
        /// </summary>
        public string BrowserType
        {
            get
            {
                return ((string)(base.GetValue(PropertyEditorWithTagBrowser.BrowserTypeProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.BrowserTypeProperty, value);
            }
        }

        /// <summary>
        /// PresistWindow dependency property - specifies either which type of data item browser should be launched
        /// </summary>
        public readonly static DependencyProperty PersistWindowProperty = DependencyProperty.Register("PersistWindow", typeof(bool), typeof(PropertyEditorWithTagBrowser),
                                        new PropertyMetadata(false));

        /// <summary>
        /// PersistWindow property 
        /// </summary>
        public bool PersistWindow
        {
            get
            {
                return ((bool)(base.GetValue(PropertyEditorWithTagBrowser.PersistWindowProperty)));
            }
            set
            {
                base.SetValue(PropertyEditorWithTagBrowser.PersistWindowProperty, value);
            }
        }

        #endregion Properties

        #region Constructor
        /// <summary>
        /// constructor
        /// </summary>
        public PropertyEditorWithTagBrowser()
        {
            InitializeComponent();

            this.DataContext = this;

        }
        #endregion Constructor

        public  double DesiredFontSize
        {
            get { return (double)GetValue(DesiredFontSizeProperty); }
            set { SetValue(DesiredFontSizeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DesiredFontSize.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DesiredFontSizeProperty =
            DependencyProperty.Register("DesiredFontSize", typeof(double), typeof(PropertyEditorWithTagBrowser), new UIPropertyMetadata(0.0));

        public FontFamily DesiredFontFamily
        {
            get { return (FontFamily)GetValue(DesiredFontFamilyProperty); }
            set { SetValue(DesiredFontFamilyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DesiredFontFamily.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DesiredFontFamilyProperty =
            DependencyProperty.Register("DesiredFontFamily", typeof(FontFamily), typeof(PropertyEditorWithTagBrowser), new UIPropertyMetadata(null));
   

        #region Events

        #region HighlightedItem
        /// <summary>
        /// Event routing triggered when the user single-clicks (selects) an item
        /// </summary>
        public static readonly RoutedEvent HighlightedItemChangedEvent =
            EventManager.RegisterRoutedEvent("HighlightedItemChanged", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(PropertyEditorWithTagBrowser));

        /// <summary>
        /// Provide CLR accessors for the UserSetHighlightedItemChanged event
        /// </summary>
        public event RoutedEventHandler HighlightedItemChanged
        {
            add { AddHandler(HighlightedItemChangedEvent, value); }
            remove { RemoveHandler(HighlightedItemChangedEvent, value); }
        }

        /// <summary>
        /// Raises the UserHighlightedItemChanged event
        /// </summary>
        private void RaiseHighlightedItemChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(HighlightedItemChangedEvent));
        }

        /// <summary>
        /// Event Handler which responds to the browser's change in a HighLightedIem
        /// </summary>
        /// <param name="sender">Browser</param>
        /// <param name="e">Not used</param>
        void _browser_HighlightedItemChangedEventHandler(object sender, RoutedEventArgs e)
        {
            DIBWindow browser = (DIBWindow)sender;
            DataItemBrowserWindowViewModel tbPresenter = (DataItemBrowserWindowViewModel)browser.DataContext;
            this.HighlightedItem = string.Format(CultureInfo.InvariantCulture, "{0}", browser.HighlightedItem);
            RaiseHighlightedItemChangedEvent();
            // ROAQ DataProvider = ViewModel.providerName;
        }

        #endregion HighlightedItem

        #region UserSetHighlightedItem
        /// <summary>
        /// Event routing triggered when the user single-clicks (selects) an item
        /// </summary>
        public static readonly RoutedEvent UserSetHighlightedItemChangedEvent =
            EventManager.RegisterRoutedEvent("UserSetHighlightedItemChanged", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(PropertyEditorWithTagBrowser));

        /// <summary>
        /// Provide CLR accessors for the UserSetHighlightedItemChanged event
        /// </summary>
        public event RoutedEventHandler UserSetHighlightedItemChanged
        {
            add { AddHandler(UserSetHighlightedItemChangedEvent, value); }
            remove { RemoveHandler(UserSetHighlightedItemChangedEvent, value); }
        }

        /// <summary>
        /// Raises the UserSetHighlightedItemChanged event
        /// </summary>
        private void RaiseUserSetHighlightedItemChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(UserSetHighlightedItemChangedEvent));
        }

        /// <summary>
        /// Event Handler which responds to the browser's change in a UserSetHighLightedIem
        /// </summary>
        /// <param name="sender">Browser</param>
        /// <param name="e">Not used</param>
        void _browser_UserSetHighlightedItemChangedEventHandler(object sender, RoutedEventArgs e)
        {
            DIBWindow browser = (DIBWindow)sender;
            DataItemBrowserWindowViewModel tbPresenter = (DataItemBrowserWindowViewModel)browser.DataContext;
            this.UserSetHighlightedItem = string.Format(CultureInfo.InvariantCulture, "{0}", browser.UserSetHighlightedItem);            
            if (browser.UserSetHighlightedItemResourceID != null)
                this.UserSetHighlightedItemResourceID = browser.UserSetHighlightedItemResourceID.ToString(); 

            RaiseUserSetHighlightedItemChangedEvent();
        }
        #endregion UserSetHighlightedItem

        #region Browser
        /// <summary>
        /// Occurs when the show tag browser button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void OnClickShowTagBrowser(object sender, RoutedEventArgs e)
        {
            Binding fontSizeBinding = new Binding("DesiredFontSize");
            Binding fontFamilyBinding = new Binding("DesiredFontFamily");

            fontSizeBinding.Source = this;
            fontFamilyBinding.Source = this;

            DIBViewItemBase.VisualPerspectiveEnum _browserPerspective;
            if (this.BrowserType.Equals(DIResource.DI_COMMON_RESOURCETYPE_TAG, StringComparison.OrdinalIgnoreCase)) 
                _browserPerspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
            else
                _browserPerspective = DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;

            DIBClientManager dibClientManager = new DIBClientManagerForViewe(_browserPerspective, this.PackageContext, this.ProjectContext);
            _browser = new DIBWindow(PropertyText, dibClientManager) { PersistWindow = this.PersistWindow };

            // set the binding for the Font size and family
            _browser.SetBinding(DIBWindow.FontSizeProperty, fontSizeBinding);
            _browser.SetBinding(DIBWindow.FontFamilyProperty, fontFamilyBinding);

            _browser.Closed += new EventHandler(BrowserClosed);

            //listen for the item selected event
            _browser.ItemSelectedEventHandler += new RoutedEventHandler(BrowserItemSelected);

            //listen for the highlighted item changed event
            _browser.HighlightedItemChangedEventHandler += new RoutedEventHandler(_browser_HighlightedItemChangedEventHandler);
            _browser.UserSetHighlightedItemChangedEventHandler += new RoutedEventHandler(_browser_UserSetHighlightedItemChangedEventHandler);

            // Setting the BrowserType must preceed all other assignments to the _browser
            _browser.HighlightedItem = this.HighlightedItem;
            _browser.UserSetHighlightedItem = this.UserSetHighlightedItem;

            string navIntoFoldertxt = this.RootNavIntoFolder;
            if (string.IsNullOrEmpty(navIntoFoldertxt))
                navIntoFoldertxt = DataItemBrowserContext.NavToFolderEnum.Nav_NoAction.ToString();
            string exclueAllChildrenOfTypetxt = this.ExcludeAllChildrenOfType;
            if (string.IsNullOrEmpty(exclueAllChildrenOfTypetxt))
                exclueAllChildrenOfTypetxt = DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.None.ToString();
            string exclueAllOfTypetxt = this.ExcludeAllOfType;
            if (string.IsNullOrEmpty(exclueAllOfTypetxt))
                exclueAllOfTypetxt = DataItemBrowserContext.ExcludeAllOfTypeEnum.None.ToString();
            string inclueAllOfTypetxt = this.IncludeAllOfType;
            if (string.IsNullOrEmpty(inclueAllOfTypetxt))
                inclueAllOfTypetxt = DataItemBrowserContext.IncludeAllOfTypeEnum.None.ToString();
            //do dataitem browser context
            if (navIntoFoldertxt.Equals("Nav_IntoTags")) navIntoFoldertxt = "Nav_IntoTagsProps";
            DataItemBrowserContext.NavToFolderEnum navIntoFolder = (DataItemBrowserContext.NavToFolderEnum)Enum.Parse(typeof(DataItemBrowserContext.NavToFolderEnum), navIntoFoldertxt);
            DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum excludeAllChildrenOfType = (DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum)Enum.Parse(typeof(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum),exclueAllChildrenOfTypetxt);
            DataItemBrowserContext.ExcludeAllOfTypeEnum excludeAllOfType = (DataItemBrowserContext.ExcludeAllOfTypeEnum)Enum.Parse(typeof(DataItemBrowserContext.ExcludeAllOfTypeEnum), exclueAllOfTypetxt);
            DataItemBrowserContext.IncludeAllOfTypeEnum includeAllOfType = (DataItemBrowserContext.IncludeAllOfTypeEnum)Enum.Parse(typeof(DataItemBrowserContext.IncludeAllOfTypeEnum), inclueAllOfTypetxt);

            DataItemBrowserContext.CreateBuilder contextBuilder = new DataItemBrowserContext.CreateBuilder(dibClientManager);
            contextBuilder.Root(this.Root, navIntoFolder)
                             .ExcludeAllChildrenFrom(ExcludeAllChildrenFrom)
                             .Include(this.Include);

            if (this.ExcludeAllChildrenFromRoot)
            {
                contextBuilder.ExcludeAllChildrenFromRoot();
            }
         
            contextBuilder.DisplayMetaData(this.DisplayMetaData);
            contextBuilder.ExcludeAllChildrenOfType(excludeAllChildrenOfType);
            contextBuilder.ExcludeAllOfType(excludeAllOfType);
            contextBuilder.IncludeAllOfType(includeAllOfType);

            if (!string.IsNullOrEmpty(this.ContextFilterType) && !string.IsNullOrEmpty(this.ContextFilterValue))
            {
                contextBuilder.AddFilter(this.ContextFilterType, this.ContextFilterValue, this.ContextFilterExactMatch);
            }

            _browser.Initialize(UseDataContext ? contextBuilder.Build() : null, this.TagName);  
            _browser.Show();
        }
        private void BrowserClosed(object sender, EventArgs e)
        {
            if (_browser != null)
            {
                _browser.ItemSelectedEventHandler -= new RoutedEventHandler(BrowserItemSelected);
                _browser.HighlightedItemChangedEventHandler -= new RoutedEventHandler(_browser_HighlightedItemChangedEventHandler);
                _browser.UserSetHighlightedItemChangedEventHandler -= new RoutedEventHandler(_browser_UserSetHighlightedItemChangedEventHandler);
                _browser.Closed -= BrowserClosed;
                //Note: don't set _browser to null so that ClearSearchMRUListHistory and ClearLastHighlightedItemInfo
                // continue to work after a DIB window is closed
            }

        }

        #endregion Browser

        public RockwellAutomation.ServiceFramework.DataTypes.UUID PackageContext { get; set; }
        public RockwellAutomation.ServiceFramework.DataTypes.UUID ProjectContext { get; set; }

        /// <summary>
        ///Item is selected in the data item browser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BrowserItemSelected(object sender, RoutedEventArgs e)
        {
            DIBWindow browser = (DIBWindow)sender;
            DataItemBrowserWindowViewModel tbPresenter = (DataItemBrowserWindowViewModel)browser.DataContext;
            this.TagName = string.Format(CultureInfo.InvariantCulture, "{0}", browser.SelectedItem);
            if (browser.SelectedItemResourceID != null)
                this.SelectedItemResourceID = browser.SelectedItemResourceID.ToString();            
        }       
        #endregion Events

        //Clears last highlighted info
        public void ClearLastHighlightedItemInfo()
        {
            if (_browser != null)
            {
                _browser.ClearLastHighlightedItemInfo();
                this.HighlightedItem = "";
            }
        }

        //Clears MRU list info
        public void ClearSearchMRUListHistory()
        {
            if (_browser != null)
            {
                _browser.ClearSearchMRUListHistory();
            }
        }
    }
}
