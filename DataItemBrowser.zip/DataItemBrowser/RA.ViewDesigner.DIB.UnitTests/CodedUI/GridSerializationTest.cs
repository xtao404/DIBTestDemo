﻿using System;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapClasses;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Threading;

namespace DataItemBrowserUT.CodedUI
{
    /// <summary>
    /// Tests the grid content serialization
    /// </summary>
    [CodedUITest]
    public class GridSerializationTest : CodedUITestBase
    {
       
        public GridSerializationTest() 
        {
            //USE ONE OF THE CALLS TO SetProjectFile

            //Use this to call the Mock to avoid requiring the ROA stack to be running for the tests to run. This must be used to 
            //run the tests as part of the build process
            SetProjectFile(new Tuple<string, string, string>("Controller1", "StructuresArraysBits_filter_V21", "Controller"));

            //Use this if you just want to have the tests run by development but do not want to have it run as part of the 
            //build process. All the methods must have [TestCategory("ExcludeOnAutoBuild")] so they are not run as part of the build.
            //SetProjectFile("DataItemBrowserUT.CodedUI.Projects.Project12.VPD");
        }

        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void TestGridSerialization_NoSerialization()
        {
            //Remove the grid serialization file, this should prevent any grid serialization
            if (File.Exists(_serializationFilePath))
                File.Delete(_serializationFilePath);

            //Open tag browser
            this.UIMap.PTH_ClickTagBrowserButton();
            this.UIMap.PTH_EnterDotInReadTagTextBox();
            this.UIMap.PTH_ClickReadTagElipsisButton();

            //Drill into controller 1
            this.UIMap.DIB_DataSources_ClickController1();

            //Make sure we aren't serializing
            Assert.IsFalse(File.Exists(_serializationFilePath), "Grid serialization file should not exist");

            //Drillin to tags and properties
            this.UIMap.DIB_DeviceView_ClickTagsAndProperties();

            //Wait for drill in to complete
            DIB_WaitForSpinnerStop();

            //Make sure we aren't serializing
            Assert.IsFalse(File.Exists(_serializationFilePath), "Grid serialization file should not exist");

            //Close the DIB
            this.DIB_HitESC();

            if (File.Exists(_serializationFilePath))
                File.Delete(_serializationFilePath);
        }

        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void TestGridSerialization_SerializationFromTheStart()
        {
            //Create the grid serialization file to enable grid serialization
            if (!File.Exists(_serializationFilePath))
            {
                FileStream NewFileStream = File.Create(_serializationFilePath);
                NewFileStream.Close();
                Thread.Sleep(500); //pause so the last write time obtained below is correct (otherwise it appears we capture the time of a "first pass" write)
            }
            else
                File.WriteAllText(_serializationFilePath, String.Empty);

            //Open tag browser
            this.UIMap.PTH_ClickTagBrowserButton();
            this.UIMap.PTH_EnterDotInReadTagTextBox();
            this.UIMap.PTH_ClickReadTagElipsisButton();

            //Drill into controller 1
            this.UIMap.DIB_DataSources_ClickController1();

            //Drillin to tags and properties
            this.UIMap.DIB_DeviceView_ClickTagsAndProperties();

            //Drill into first tag
            this.UIMap.DIB_DrillinFirstControllerTag();

            //Wait for drill in to complete
            DIB_WaitForSpinnerStop();

            string error = "Unexpected serialization result";

            //Make sure we got the expected serialization results
            string[] FileLines = File.ReadAllLines(_serializationFilePath);
            Assert.IsTrue(FileLines.Length == 24, error);
            Assert.IsTrue(FileLines[1].Contains("Alarm_PreDefArray1[0]"), error);

            DateTime lastWriteTime = File.GetLastWriteTime(_serializationFilePath);

            //Click back to the device view
            this.UIMap.DIB_ClickBreadcrumbController1();

            //Wait for navigate to complete
            DIB_WaitForSpinnerStop();

            DateTime verifyWriteTime = File.GetLastWriteTime(_serializationFilePath);

            //Make sure we got the expected serialization results (going to the device view
            // should not change the previous serialization results)
            Assert.AreEqual(lastWriteTime, verifyWriteTime, "Serialization file was unexpectedly written to");

            //Close the DIB
            this.DIB_HitESC();

            if (File.Exists(_serializationFilePath))
                File.Delete(_serializationFilePath);
        }

        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void TestGridSerialization_SerializationStartingInMiddle()
        {
            //Remove the grid serialization file, this should prevent any grid serialization
            if (File.Exists(_serializationFilePath))
                File.Delete(_serializationFilePath);

            //Open tag browser
            this.UIMap.PTH_ClickTagBrowserButton();
            this.UIMap.PTH_EnterDotInReadTagTextBox();
            this.UIMap.PTH_ClickReadTagElipsisButton();

            //Drill into controller 1
            this.UIMap.DIB_DataSources_ClickController1();

            //Make sure we aren't serializing
            Assert.IsFalse(File.Exists(_serializationFilePath), "Grid serialization file should not exist");

            //Drillin to tags and properties
            this.UIMap.DIB_DeviceView_ClickTagsAndProperties();

            //Wait for drill in to complete
            DIB_WaitForSpinnerStop();

            //Make sure we still aren't serializing
            Assert.IsFalse(File.Exists(_serializationFilePath), "Grid serialization file should not exist");

            string error = "Unexpected serialization result";

            //Create the grid serialization file to enable grid serialization
            if (!File.Exists(_serializationFilePath))
            {
                FileStream NewFileStream = File.Create(_serializationFilePath);
                NewFileStream.Close();
                Thread.Sleep(500); //pause so the last write time obtained below is correct (otherwise it appears we capture the time of a "first pass" write)
            }

            //Drill into first tag
            this.UIMap.DIB_DrillinFirstControllerTag();

            //Wait for drill in to complete
            DIB_WaitForSpinnerStop();

            //Needed to give the file a chance to write itself
            Thread.Sleep(500);

            //Make sure we got the expected serialization results
            string[] FileLines = File.ReadAllLines(_serializationFilePath);
            Assert.IsTrue(FileLines.Length == 24, error);
            Assert.IsTrue(FileLines[1].Contains("Alarm_PreDefArray1[0]"), error);

            //Close the DIB
            this.DIB_HitESC();

            if (File.Exists(_serializationFilePath))
                File.Delete(_serializationFilePath);
        }

        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void TestGridSerialization_SerializationStopInMiddle()
        {
            //Create the grid serialization file to enable grid serialization
            if (!File.Exists(_serializationFilePath))
            {
                FileStream NewFileStream = File.Create(_serializationFilePath);
                NewFileStream.Close();
                Thread.Sleep(500); //pause so the last write time obtained below is correct (otherwise it appears we capture the time of a "first pass" write)
            }
            else
                File.WriteAllText(_serializationFilePath, String.Empty);

            //Open tag browser
            this.UIMap.PTH_ClickTagBrowserButton();
            this.UIMap.PTH_EnterDotInReadTagTextBox();
            this.UIMap.PTH_ClickReadTagElipsisButton();

            //Drill into controller 1
            this.UIMap.DIB_DataSources_ClickController1();

            //Drillin to tags nad properties
            this.UIMap.DIB_DeviceView_ClickTagsAndProperties();

            //Wait for drill in to complete
            DIB_WaitForSpinnerStop();

            string error = "Unexpected serialization result";

            //Make sure we got the expected serialization results
            string[] FileLines = File.ReadAllLines(_serializationFilePath);
            Assert.IsTrue(FileLines.Length == 131, error);
            Assert.IsTrue(FileLines[1].Contains("Alarm_PreDefArray1"), error);

            //Turn off serialization by deleting the file
            File.Delete(_serializationFilePath);

            //Drill into first tag
            this.UIMap.DIB_DrillinFirstControllerTag();

            //Wait for drill in to complete
            DIB_WaitForSpinnerStop();

            //Verify we are not serializing
            Assert.IsFalse(File.Exists(_serializationFilePath));

            //Close the DIB
            this.DIB_HitESC();
        }

        #region Additional test attributes

        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            CodedUITestBase.BaseClassInitialize(testContext);
        }

        [ClassCleanup]
        public static void MyClassCleanup()
        {
            CodedUITestBase.BaseClassCleanup();
        }

        //Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void MyTestInitialize()
        {
        }

        ////Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {        
        }

        #endregion

        public UIMap UIMap
        {
            get
            {
                if ((this.map == null))
                {
                    this.map = new UIMap();
                }

                return this.map;
            }
        }

        private UIMap map;
    }
}
