/* ****************************************************************************
*
*  Copyright 2009-2015 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

#region references

using System;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;

using Xceed.Wpf.DataGrid;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;
using QueryResource = RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.Models;

#endregion

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// View model supporting the <c>DIBGridView</c>
    /// </summary>
    public class DIBGridViewModel : DIBViewModel
    {
        #region Properties/Variables

        #region Enums

        /// <summary>
        /// What kind of grid is being displayed 
        /// </summary>
        public enum GridDisplayEnum
        {
            ControllerViewGrid = 0,
            CommonGrid = 1,
            DataTypeGrid = 3
        }

        /// <summary>
        /// Which way the grid should search for the selected item
        /// </summary>
        public enum MatchMode
        {
            ByName,
            ByObject
        }

        #endregion

        // Whether we have viewed data in the grid at least once
        private bool _hasDisplayedGridData = false;

        private DataItemBase _selectedItem;

        private DataGridCollectionView _itemsSource = new DataGridCollectionView(new TSObservableCollection<DataItemBase>());

		// Tracks if we are (from code) clearing the sorted columns so that we know not
		// to call to persist this clearing in the user config
		private bool _isCodeChangingSort = false;

        // Tracks when we are explicitly setting the item source of the grid
        private bool _isItemsSourceChanging = false;

        //Tracks the item which will be set to the selected item in the event we are changing the item source
        private DataItemBase _pendingItemToSelect = null;

        /// <summary>
        /// The current and visible column config
        /// </summary>
        public List<QueryResource.ColumnConfigMapItem> Columns
        {
            get { return _dibViewModel.Columns;}
        }

        public bool SearchHasError
        {
            get { return this._dibViewModel.SearchFilterControlVM.HasError;}
        }

        // Using a DependencyProperty as the backing store for ItemSelectionMode.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ItemSelectionModeProperty =
            DependencyProperty.RegisterAttached("ItemSelectionMode", typeof(MatchMode), typeof(DIBGridViewModel), new UIPropertyMetadata(MatchMode.ByObject));

        /// <summary>
        /// What type of Grid is being displayed.
        /// </summary>
        GridDisplayEnum _gridDisplay = GridDisplayEnum.ControllerViewGrid;
        public GridDisplayEnum GridDisplay 
        {
            get { return _gridDisplay; }
            set { _gridDisplay = value; }
        }

        /// <summary>
        /// Selected DataItemBase item property
        /// </summary>
        public DataItemBase SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                if (_selectedItem != value)
                {
                    _selectedItem = value;
                    NotifyPropertyChanged("SelectedItem");
                }
            }
        }

        /// <summary>
        /// ItemsSource property that is bound to the DIBGridView
        /// </summary>
        public DataGridCollectionView ItemsSource
        {
            get
            {
                return _itemsSource;
            }
            internal set
            {
                if (_itemsSource != value)
                {
                    _itemsSource = value;
                    NotifyPropertyChanged("ItemsSource");
                }
            }
        }

        override public bool isActive()
        {
            return _dibViewModel.DataView.IsGridView();
        }

        #endregion

        #region Constructor

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">reference to the DataItemBrowser view model</param>
        public DIBGridViewModel(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {           
            //listen for the DataGrid observable collection and column changed events
            _dibViewModel.DataGridOCChanged += new PropertyChangedEventHandler(DataItemBrowserViewModel_DataGridOCChanged);
			_dibViewModel.DataGridColsChanged += new PropertyChangedEventHandler(DataItemBrowserViewModel_DataGridColsChanged);
        }

        #endregion

        #region Event Handlers

        /// <summary>
        /// Notification that the data view has changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        override protected void DataItemBrowserViewModel_DataViewChanged(object sender, EventArgs e)
        {
            if (this.isActive())
            {
                Visible = Visibility.Visible;

                if (!this._hasDisplayedGridData)
                {
                    this._hasDisplayedGridData = true;
                }
                else if (this.ItemsSource.SourceCollection != _dibViewModel.DataItems)
                {
                    // We are not bound to DibViewModel data items. Bind it now.
                    // This will allow us to see grid data as it is being generated (chunk load)
                    // instead of waiting until all the grid data has been generated to see the grid items
                    this.UpdateItemsSource(null);
                }
                //When the data view changes, the columns need to refresh
                NotifyColumnConfigurationChanged();
            }
            else
            {
                Visible = Visibility.Collapsed;
                // Since the user has just changed views and is NOT viewing the grid anymore, unbind the grid from 
                // its data source (all views share the same data source).
                // This will prevent us from binding the grid to data that is not intended for the data grid.
                // EX. If the user goes from grid view to main view (data sources view), we do not want to waste time
                // binding the grid to data intended for main view. 
                this.UnbindItemsSource();
            }

        }

        /// <summary>
        /// Handler for DataGrid columns changing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DataItemBrowserViewModel_DataGridColsChanged(object sender, PropertyChangedEventArgs e)
        {
            //The grid will take care of clearing this but if running from viewmodel automation, no one
            // would clear this value which should be cleared when navigation occurs (i.e. columns change)
            this.SelectedItem = null;

            //clear the sort while the columns are in flux.  this prevents the grid from trying to
            // sort an empty collection (which it considers an exception)
            _isCodeChangingSort = true;
            DataGridCollectionView curCollectionView = ItemsSource as DataGridCollectionView;
            curCollectionView.SortDescriptions.Clear();
            _isCodeChangingSort = false;

            //set the sort here so the rows do not move after the final retreival from ROA
            //make sure we are in a grid view before setting sort, user config needs to be set
            if (Visible != null && Visible.Value == Visibility.Visible)
            {
                SetSortComparers(curCollectionView);
                SetSortDirections(curCollectionView);
            }
		}

        /// <summary>
        /// Handler for DataGrid <see cref="System.Collections.ObjectModel.ObservableCollection"/>
        /// changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">DataGrid Property Changed Event</param>        
        void DataItemBrowserViewModel_DataGridOCChanged(object sender, PropertyChangedEventArgs e)
        {
            //If this.SelectedItem is not null, the user has explicitly highlighted a row in the grid
            // so in this case, it is okay to ignore the item that would otherwise be highlighted as
            // passed in the event args to this handler
            DataItemBase itemToSelect = this.SelectedItem;
            if (this.SelectedItem == null)
            {
                DGOCPropertyChangedEventArgs DSOCArgs = e as DGOCPropertyChangedEventArgs;
                itemToSelect = DSOCArgs.ItemToSelect;
            }

            this.UpdatePropertiesOnDataItemBaseIfNeeded();

            this.UpdateItemsSource(itemToSelect);

            // Update the selected item - must come after setting the ItemsSource as
            // Xceed's grid will set the selected item to the first item in the collection
            // when updating the item source
            this.UpdateSelectedItem(this.ItemsSource, itemToSelect);

            //Make necessary changes to the path
            this.HandleSelectionChange(this.SelectedItem);

            this.NotifyGridDataLoadComplete();
        }


        /// <summary>
        /// handler for adding or removing the search crumb
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        override protected void DataItemBrowserViewModel_SearchBreadCrumbChanged(object sender, PropertyChangedEventArgs e)
        {
            SearchBreadCrumbPropertyChangedEventArgs arg = e as SearchBreadCrumbPropertyChangedEventArgs;

            if (arg != null && arg.Add)
            {
                // If we are adding the search crumb then a search is in progress 
                // and we want the GridView to be displayed
                this.Visible = Visibility.Visible;
            }           
            else
            {
                // Need to re-establish correct visibility because the user 
                // may be adjusting the search query and this does not 
                // cause the re-evaluation of the active view
                this.Visible = this.isActive() ? 
                    Visibility.Visible :
                    Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Updates this.Path after a grid selection changes
        /// </summary>
        /// <param name="selectedItem"></param>
        public void HandleSelectionChange(DataItemBase selectedItem)
        {
            if (selectedItem != null)
            {
                // When the item source is updated on the grid, it's built in behavior is to select the first item.  In this case,
                // if we detect that the item we ultimately want to select (set into PendingItemToSelect) differs from the first
                // item, we return immediately since we'll get here again when we explicitly select the pending item.
                if (_isItemsSourceChanging)
                {
                    if (_pendingItemToSelect != null && !selectedItem.Equals(_pendingItemToSelect, selectedItem))
                        return;
                }

                // Create the appropriate PathElement (Data Item, ...
                IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(selectedItem);

                if (this.Path.ActiveElement is DataItemPathElement)
                {
                    string elementParent = selectedItem.CommonOwner;
                    DataItemPathElement itemAsDIPathElement = pathElement as DataItemPathElement;
                    if (itemAsDIPathElement != null)
                        itemAsDIPathElement.PathList.Add(elementParent);
                }

                this.Path.HighlightedElement = pathElement;

                //If we are on the latest grid in the navigation path (meaning no
                // forward breadcrumbs), save the name of the selected item
                // such that we can restore it during navigation
                if (this.Path.Forward == null)
                {
                    // Create the appropriate PathElement (Program, Tags & Properties, or Data Item.
                    this.Path.SavedHighlightedElement = pathElement;
                }
            }
            else
            {
                this.Path.HighlightedElement = null;
            }

            DIBGridViewModel.SetItemSelectionMode(_dibViewModel, MatchMode.ByObject);
        }

        #endregion  //event handlers

        #region Item Selection/ Item Selection Mode

        public static MatchMode GetItemSelectionMode(IDataItemBrowserViewModel viewModel)
        {
            DependencyObject obj = viewModel as DependencyObject;
            return (MatchMode)obj.GetValue(ItemSelectionModeProperty);
        }

        public static void SetItemSelectionMode(IDataItemBrowserViewModel viewModel, MatchMode value)
        {
            DependencyObject obj = viewModel as DependencyObject;
            obj.SetValue(ItemSelectionModeProperty, value);
        }

        /// <summary>
        /// Update selected item in the grid
        /// </summary>
        /// <param name="curCollectionView">DataGridCollectionView to use in updating</param>   
        /// <param name="itemToSelect">DataItemBase to select</param>   
        private void UpdateSelectedItem(DataGridCollectionView curCollectionView, DataItemBase itemToSelect)
        {
            // If we aren't explicitly selecting an item, make sure we select the
            // first one in the grid.  The grid will select the first one in the
            // unsorted items and as a result, won't select the "top" item if a
            // sort is applied.
            if (itemToSelect == null)
            {
                if (curCollectionView.Count > 0)
                    this.SelectedItem = this.getDefaultItemToSelectFrom(curCollectionView);
            }
            else
            {
                //If the VM is set to match selected item by object, use LINQ to query based on DataItemBase
                if (DIBGridViewModel.GetItemSelectionMode(_dibViewModel) == MatchMode.ByObject)
                {
                    UpdateSelectedItemByObject(curCollectionView, itemToSelect);
                }
                //Otherwise we are set to match by name in which case use a name (i.e. ToString) compare
                else
                {
                    UpdateSelectedItemByName(curCollectionView, itemToSelect.ToString());
                }

                //Select the first item if we could not find the item to select via the above code
                if (this.SelectedItem == null && curCollectionView.Count > 0)
                    this.SelectedItem = this.getDefaultItemToSelectFrom(curCollectionView);
            }
        }

        protected virtual DataItemBase getDefaultItemToSelectFrom(DataGridCollectionView curCollectionView)
        {
            try
            {
                return (from DataItemBase dib in curCollectionView.SourceCollection.AsQueryable()
                        where "true".Equals(dib.GUIIsInitiallyHighlighted, StringComparison.InvariantCultureIgnoreCase)
                        select dib).First();
            }
            catch (InvalidOperationException)
            {
                // No items are set to be initially highlighted; just highlight the first.
                return curCollectionView.GetItemAt(0) as DataItemBase;
            }
        }

        /// <summary>
        /// Helper to set this.SelectedItem (by Object lookup)
        /// </summary>
        /// <param name="curCollectionView">DataGridCollectionView to use in updating</param>   
        /// <param name="itemToSelect">DataItemBase to select</param>   
        private void UpdateSelectedItemByObject(DataGridCollectionView curCollectionView, DataItemBase itemToSelect)
        {
            // Try to select the item 
            try
            {
                this.SelectedItem = (from DataItemBase dib in curCollectionView.SourceCollection.AsQueryable()
                                     where dib.IsEquivalentTo(itemToSelect)
                                     select dib).FirstOrDefault();
            }
            catch (InvalidOperationException ioEx)
            {
                //this exception occurs when the ItemToSelect is not in the curCollectionView
                LogWrapper.LogException("Setting SelectedItem in the Grid, setting the top item to be selected", ioEx);
            }
        }

        /// <summary>
        /// Helper to set this.SelectedItem (by Name/string lookup)
        /// </summary>
        /// <param name="curCollectionView">DataGridCollectionView to use in updating</param>   
        /// <param name="nameToSelect">Name of data element to select</param>   
        private void UpdateSelectedItemByName(DataGridCollectionView curCollectionView, string nameToSelect)
        {
            for (int i = 0; i < curCollectionView.Count; i++)
            {
                DataItemBase dib = curCollectionView.GetItemAt(i) as DataItemBase;
                if (nameToSelect == dib.ToString())
                {
                    this.SelectedItem = dib;
                    break;
                }
            }
        }

        #endregion

        #region Item Sorting

        /// <summary>
        /// Specify the IComparer for a given column
        /// </summary>
        /// <param name="columnName"></param>
        /// <returns>Compare method to use. Null if the default compare method should be used</returns>
        protected virtual IComparer GetComparerForColumn(String columnName)
        {
            return null;
        }

        /// <summary>
        /// The order that the SortDescriptions are added to the view determines their column's SortIndex.
        /// 0 = 1st column, 1 = 2nd column, ...
        /// not set = not sorted (SortIndex will be -1)
        /// </summary>
        /// <param name="view"></param>
        private void SetSortDirections(DataGridCollectionView view)
        {
			_isCodeChangingSort = true;

            view.SortDescriptions.Clear();

            //order the column collection by the SortIndex
            var columnConfigs = from cc in _dibViewModel.Columns
                                orderby (cc.GetSortIndex) ascending
                                select cc;

            foreach (QueryResource.ColumnConfigMapItem cc in columnConfigs)
            {
                if (cc.GetSortIndex == -1)
                    continue;

                view.SortDescriptions.Add(cc.GetSortDirection == QueryResource.SortDirection.Ascending
                                              ? new SortDescription(cc.GetColumn, ListSortDirection.Ascending)
                                              : new SortDescription(cc.GetColumn, ListSortDirection.Descending));
            }

            _isCodeChangingSort = false;
        }

        /// <summary>
        /// Set the custom sort comparers for the passed view
        /// </summary>
        /// <param name="view">View on which the custom sort comparers should be set</param>
        protected void SetSortComparers(DataGridCollectionView view)
        {
            foreach (DataGridItemProperty gridItemProperty in view.ItemProperties)
            {
                IComparer compareMethod = GetComparerForColumn(gridItemProperty.Name);
                if (compareMethod != null)
                {
                    gridItemProperty.SortComparer = compareMethod;
                }
            }
        }     

        #endregion

        #region Item Binding/Unbinding

        /// <summary>
        /// Set the Items source with proper sorting and filtering properties. 
        /// This method lazy initializes ItemsSource and will reuse the same instance
        /// </summary>
        /// <param name="itemToSelect">DataItemBase to select</param>     
        private void UpdateItemsSource(DataItemBase itemToSelect)
        {
            DataGridCollectionView curCollectionView;

            curCollectionView = new DataGridCollectionView(_dibViewModel.DataItems);

            // The ItemsSource is ready to be updated.
            // Start the sorting based on the user's configuration information in SetSortDirections
            // Make sure to first set the sort comparers before
            // altering the actual sort descriptions or otherwise the custom comparer would not
            // be applied on the initial sort
            curCollectionView.Filter = new Predicate<object>(FilterDataItem);
            SetSortComparers(curCollectionView);
            SetSortDirections(curCollectionView);

            //The order of the following statements should not be altered (i.e. _isItemsSourceChanging/_pendingItemToSelect
            // should wrap the line that sets ItemsSource
            _isItemsSourceChanging = true;

            _pendingItemToSelect = itemToSelect;
            this.ItemsSource = curCollectionView;
            _pendingItemToSelect = null;

            _isItemsSourceChanging = false;
        }

        /// <summary>
        /// Set the items source to an empty collection so that we are not updating the grid view 
        /// when _dibViewModel.DataItems changes
        /// </summary>
        private void UnbindItemsSource()
        {
            _isItemsSourceChanging = true;

            _pendingItemToSelect = null;
            this.ItemsSource = new DataGridCollectionView(new TSObservableCollection<DataItemBase>());
            _pendingItemToSelect = null;

            _isItemsSourceChanging = false;
        }

        // If there are fields missing or not correctly created, do that here
        protected virtual void UpdatePropertiesOnDataItemBaseIfNeeded()
        {
            foreach (DataItemBase item in _dibViewModel.DataItems)
            {
                UpdatePropertiesOnDataItemBaseIfNeeded(item);
            }
        }

        private static void UpdatePropertiesOnDataItemBaseIfNeeded(DataItemBase item)
        {
            //if DataItemBase does not already have a UUID on it, set it now
            //We force all instances of DataItemBase to have a UUID as its ID. The client itself can use its won ID but needs to have different property key
            if (String.IsNullOrWhiteSpace(item.CommonID))   
                item.CommonID = ResourceBase.generateRandomUUIDString();

            if (Convert.ToBoolean(item.GUISupportsDrillIn))
                item.IsStructured = true;
            else
                item.IsStructured = false;
        }

        #endregion

        #region Drill in/Drill out

        /// <summary>
        /// Do we want to allow this view to have drill in functionality?
        /// If true, we still look at individual DataItemBase instances to see whether they allow drillins
        /// TO DO: Add this ability to turn off drillins in views for ListView and TreeView as well
        /// </summary>
        /// <returns>Wether we should allow drillins for this view</returns>
        public virtual bool AllowItemDrillIns
        {
            get 
            {
                // Let sublclasses override. Here we assume all grid views want to allow drill ins
                return true; 
            }

        }

        /// <summary>
        /// Drill in Command
        /// </summary>
        public override SimpleCommand CreateDrillInCommand()
        {
            return new SimpleCommand()
            {
                ExecuteDelegate = x =>
                {
                    DataItemBase item = x as DataItemBase;

                    //If we're drilling in from a query based search view, we need to add breadcrumbs based on what's clicked
                    if (IsQueryBasedSearchActive)
                    {
                        //if the callback was not used then navigate to the item
                        if (DrillInFromSearchViewUsingCallback(item))
                            return;
                    }

                    //Now proceed with the "normal" drill in logic for the passed data item
                    //If the item we are drilling into is already a forward crumb, set that as active and navigate to it
                    if (item != null && ((_dibViewModel.Path.Forward != null) &&
                                            (_dibViewModel.Path.Forward.DisplayName == item.CommonName)))
                    {
                        _dibViewModel.Path.SetActive(_dibViewModel.Path.Forward);
                        _dibViewModel.Navigate(item);
                        return;
                    }

                    IPathElement newPE = PathElementFactory.Instance().CreatePathElement(item);
                    DataItemPathElement dataItemPE = newPE as DataItemPathElement;
                    if (dataItemPE != null && IsNextDrillInItemOfRootType())
                    {
                        dataItemPE.IsRootType = true;
                    }

                    if (IsDuplicateDrillIn(newPE))
                    {
                        return;
                    } 

                    _dibViewModel.Path.Add(newPE);
                    _dibViewModel.Navigate(item);            
                }
            };
        }

        protected virtual bool IsNextDrillInItemOfRootType()
        {
            // Determine if the request is to drill into a Root Type (ex. a Tag in viewe).
            int count = _dibViewModel.Path.SelectedPath.Count;
            if (count > 0) return true;
            return false;
        }

        ///<summary>
        ///there is a case where we can be drilling into a DataItembase and while the spinner is going the user can select 
        /// the same DataItembase again
        ///if this occurs we do not want it added to the breadcrumbs
        ///</summary>
        /// <param name="newPE"></param>
        protected virtual bool IsDuplicateDrillIn(IPathElement newPE)
        {
            IPathElement existingPE = _dibViewModel.Path.SelectedPath.Last();
            if (existingPE == newPE) return true;
            if (existingPE.DataItem == null) return false;
            if (ResourceBase.IsEqual(existingPE.ResourceId,newPE.ResourceId))
                return true;

            return false;
        }

        #endregion

        #region Search Related

        ///<summary>
        /// This is the drillIn performed from the search view
        /// If we're drilling in from a query based search view, we need to add breadcrumbs based on what's clicked
        ///</summary>
        ///<param name="item"></param>
        ///<returns>return true if callback used </returns>
        private bool DrillInFromSearchViewUsingCallback(DataItemBase item)
        {
            _dibViewModel.IsQueryBasedSearchActive = false;
            //If the callback is being used, return since we'll run the actual drill in command
            // from the callback itself
            bool usedCallback = _dibViewModel.PopulatePathFromDataItemPath(item, (error) =>
            {
                if (String.IsNullOrEmpty(error))
                {
                    this.DrillInCommand.Execute(item);
                }
            });

            return usedCallback;
        }

        /// <summary>
        /// Xceed datagrild filtering callback
        /// </summary>
        /// <param name="item">dataitem</param>
        /// <returns>true if matches filter, false otherwise</returns>
        private bool FilterDataItem(object item)
        {
            bool matchesFilter = true;

            //Only perform this "view level filtering" if we have not filtered our list of data items
            // via a query based search
            if (!IsQueryBasedSearchActive)
            {
                //Also only perform if we have a non-empty search value
                if (this._dibViewModel.SearchFilterControlVM.HasNonEmptySearchValue)
                {
                    DataItemBase dataItem = (DataItemBase)item;
                    matchesFilter = dataItem != null && this._dibViewModel.SearchFilterControlVM.ApplyViewFilter(dataItem, ReturnFieldValue);
                }
            }

            return matchesFilter;
        }

        /// <summary>
        /// Delegate for returning the value of a field in a DataItem
        /// </summary>
        /// <param name="fieldName">The name of the attribute that we need to return</param>
        /// <param name="item">DataItemBase that was passed to the SearchFilterParser from within FilterDataItem</param>
        /// <returns>The value of the fieldName for the passed item</returns>
        public static string ReturnFieldValue(string fieldName, object item)
        {
            return ((DataItemBase)item).GetStringMapValue(fieldName);
        }

        #endregion

        #region Startup - Shutdown

        /// <summary>
        /// Remove event handlers and save column configuration
        /// </summary>
        override public void Cleanup()
        {
            // Save configuration information
			_dibViewModel.SaveColumnConfig();

            // Cleanup Event Subscriptions
            _dibViewModel.DataGridOCChanged -= new PropertyChangedEventHandler(DataItemBrowserViewModel_DataGridOCChanged);
            _dibViewModel.DataGridColsChanged -= new PropertyChangedEventHandler(DataItemBrowserViewModel_DataGridColsChanged); //de-regestering from an event that it registered for in DataItemBrowserViewModel (fix for TAF hang issue).

            base.Cleanup();
        }

        #endregion

        #region Column Config

        /// <summary>
        /// Update the Visible property in the current column configuraiton
        /// and the user's column configuration
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="visible"></param>
        public void UpdateColumnConfig_Visible( string fieldName, bool visible)
        {
            if (!this.isActive()) return;
			_dibViewModel.UpdateColumnConfig(ColumnAttribute.Visible, fieldName, visible);
        }

        /// <summary>
        /// Update the VisiblePosition property in persisted column configuration
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="visibleposition"></param>
        public void UpdateColumnConfig_VisiblePosition(string fieldName, int visibleposition)
        {
            if (!this.isActive()) return;
			_dibViewModel.UpdateColumnConfig(ColumnAttribute.VisiblePosition, fieldName, visibleposition);
        }

        /// <summary>
		/// Update the CurrentWidth property in persisted column configuration
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="currentwidth"></param>
        public void UpdateColumnConfig_CurrentWidth(string fieldName, double currentwidth)
        {
            if (!this.isActive()) return;
            _dibViewModel.UpdateColumnConfig(ColumnAttribute.Width, fieldName, currentwidth);
        }

        /// <summary>
		/// Update the SortIndex property in persisted column configuration
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="sortindex"></param>
        public void UpdateColumnConfig_SortIndex(string fieldName, int sortindex)
        {
            if (!this.isActive()) return;
			if (!_isCodeChangingSort && !_isItemsSourceChanging)
				_dibViewModel.UpdateColumnConfig(ColumnAttribute.SortIndex, fieldName, sortindex);
        }

        /// <summary>
		/// Update the SortDirection property in persisted column configuration
        /// </summary>
        /// <param name="fieldName"></param>
        /// <param name="sortdirection"></param>
        public void UpdateColumnConfig_SortDirection(string fieldName, Xceed.Wpf.DataGrid.SortDirection sortdirection)
        {
            if (!this.isActive()) return;
			if (!_isCodeChangingSort && !_isItemsSourceChanging)
				_dibViewModel.UpdateColumnConfig(ColumnAttribute.SortDirection, fieldName, (QueryResource.SortDirection)sortdirection);
        }

        #endregion

        #region INotifyPropertyChanged Members

        /// <summary>
        /// Event routing triggered when the grids columns have changed
        /// </summary>
        public event PropertyChangedEventHandler ColumnConfigurationChanged;

        /// <summary>
        /// Event listeners when the grids columns have changed
        /// </summary>
        protected void NotifyColumnConfigurationChanged()
        {
            if (ColumnConfigurationChanged != null)
                ColumnConfigurationChanged(this, new PropertyChangedEventArgs(String.Empty));
        }

        public event PropertyChangedEventHandler GridDataLoadComplete;
        protected void NotifyGridDataLoadComplete()
        {
            if (GridDataLoadComplete != null)
                GridDataLoadComplete(this, new PropertyChangedEventArgs(String.Empty));
        }

        #endregion

    }
}
