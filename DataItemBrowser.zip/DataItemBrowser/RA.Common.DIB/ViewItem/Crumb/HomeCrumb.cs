
namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// HomeCrumb class
    /// Used solely to represent the breadcrumb's home image
    /// </summary>
    public class HomeCrumb: ACrumbWithPathElement
    {
        /// <summary>
        /// constructor
        /// </summary>
        public HomeCrumb(IPathElement pathElement):base(pathElement) { }

        /// <summary>
        /// Does this crumb support drop arrow navigation property.
        /// </summary>
        public override bool SupportsDropArrow
        {
            //home crumb supports drop arrow navigation if it is not before
            // a left overflow crumb and not before only forward crumbs and 
            // if the pathElement has children to display
            get { return this.PathElement.HasChildren && !BeforeLeftOverflowCrumbs && !BeforeOnlyForwardCrumbs; }
        }

        /// <summary>
        /// Is the home crumb active with only forward crumbs after it
        /// </summary>
        bool _beforeOnlyForwardCrumbs = false;
        public bool BeforeOnlyForwardCrumbs
        {
            get { return _beforeOnlyForwardCrumbs; }
            set
            {
                _beforeOnlyForwardCrumbs = value;
                NotifyPropertyChanged("BeforeOnlyForwardCrumbs");
                NotifyPropertyChanged("SupportsDropArrow");
            }
        }

        /// <summary>
        /// Is the home crumb before a left overflow menu crumb
        /// </summary>
        bool _beforeLeftOverflowCrumbs = false;
        public bool BeforeLeftOverflowCrumbs
        {
            get { return _beforeLeftOverflowCrumbs; }
            set
            {
                _beforeLeftOverflowCrumbs = value;
                NotifyPropertyChanged("BeforeLeftOverflowCrumbs");
                NotifyPropertyChanged("SupportsDropArrow");
            }
        }
    }
}
