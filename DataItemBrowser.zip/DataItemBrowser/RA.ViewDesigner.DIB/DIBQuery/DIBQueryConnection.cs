﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using System;
using System.Windows.Threading;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Logging;
using System.Reflection;


namespace RockwellAutomation.UI.DIBQuery
{ 
    /// <summary>
    /// DIBQuery represents a wrapper to QSP and OSGI query processing. This class is persisted across DIB invokations by CDS
    /// </summary>
    public class DIBQueryConnection: IDIBQueryConnection
    {
        #region "Instance Variables"

        /// <summary>
        /// The interface we use to communicate with QSP
        /// </summary>
        private IQuery _query = null;

        /// <summary>
        /// The current instnace of ClientDataServices to use to notify of query events. 
        /// This instance can change between DIB invocations
        /// </summary>
        protected IClientDataServices _cds;
        protected IClientDataServices CDS
        {
            set
            {
                // We want to set the instance of CDS and dispatcher at the same time here
                // so we never get in the situation betwen DIB invocations where we have an instance
                // of CDS and an instance of a dispatcher from different DIB invocations
                _cds = value;
                // set the Dispatcher of the UI (DIB) thread. 
                // Note: This is needed after performing an Asynchronous operation to allow us to get back to the UI thread 
                // and will be used in notifying CDS 
                _dispatcher = Dispatcher.CurrentDispatcher;
            }
        }
        // Represents the current Gui dispatcher. This is used later by callbacks to CDS update our GUI in real time
        protected Dispatcher _dispatcher = null;

        #endregion

        #region "Static Variables"

        /// <summary>
        /// The package id of the file containing the project database
        /// </summary>
        static public UUID PackageContext { get; set; }

        /// <summary>
        /// The database id of the project containing the controllers
        /// </summary>
        static public UUID ProjectContext { get; set; }

        /// <summary>
        /// Represents the local to use for our queries. For R1, only the English-American locale is supported.
        /// </summary>
        static public string QueryLocale = "en-US";

        #endregion

        #region "Constructor"

        /// <summary>
        /// Constructor
        /// </summary>
        public DIBQueryConnection()
        {
        }

        #endregion

        #region "Init/Release"

        public bool isQueryInitialized()
        {
            return (this._query != null);
        }

        /// <summary>
        //  Create and initialize a query so we can talk to data via the query service provider
        /// </summary>
        public void CreateConnection()
        {
            if (this.isQueryInitialized()) return;
            QueryProviderFactory factory = QueryProviderFactory.Instance();
            _query = factory.Create();
            _query.Initialize(PackageContext, ProjectContext, QueryLocale);
        }

        /// <summary>
        /// Used to set a new package and project context for the query service provider to use.
        /// If the package and project context have changed, we want to shutdown the query service provider
        /// </summary>
        /// <param name="packageContext"></param>
        /// <param name="projectContext"></param>
        public void SetPackageAndProjectContext(UUID packageContext, UUID projectContext)
        {
            bool hasChangedPackageOrProjectContext = (!ResourceBase.IsEqual(PackageContext, packageContext) || !(ResourceBase.IsEqual(ProjectContext, projectContext)));

            PackageContext = packageContext;
            ProjectContext = projectContext;

            // If the query service provider is null, there is nothing to shutdown
            if (_query == null) return;
            // If we havent changed out context, there is no need to shutdown the query service provider
            if (!hasChangedPackageOrProjectContext) return;
            // We changed the project or package context. This means the query service provider will need to 
            // shutdown and then restart to re-establish new query and edit sessions.
            // A new query service provider will be created during Initialize
            Shutdown();
        }

        /// <summary>
        /// Shutdown query service provider completely along with any open connections
        /// </summary>
        public void Shutdown()
        {
            LogWrapper.DibStartUpLog.Debug("Received OnCloseProject");
            try
            {
                UnRegisterForEvents();
                //End the query service provider
                if (this._query != null)
                {
                    _query.Shutdown();
                    _query = null;
                }

                CDS = null;
                _dispatcher = null;
            }
            catch (Exception ex)
            {
                LogWrapper.LogException(MethodBase.GetCurrentMethod().ToString(), ex);
            }
        }

        /// <summary>
        /// Register for Data Load complete Event
        /// Need to be carefull here because we could be using a cached _query but a new 
        /// instance of cds, so we make sure to reset the instance of CDS we are using
        /// </summary>
        public void RegisterForEvents(IClientDataServices cds)
        {
            UnRegisterForEvents();
            CDS = cds;

            if (!this.isQueryInitialized()) return;
            _query.DataLoadComplete += Query_DataLoadComplete;
        }

        /// <summary>
        /// Unregister for Data Load complete Event, but leave the current query service provider available to be used in the future for performance caching reasons
        /// </summary>
        public void UnRegisterForEvents()
        {
            if (!this.isQueryInitialized()) return;
            _query.DataLoadComplete -= Query_DataLoadComplete;
            // In case there is a long running query, cancel it now since we dont need its results anyways
            _query.Cancel();
        }

        public bool HasValidPackageAndProjectContext()
        {
            return (ProjectContext != null && PackageContext != null);
        }


        /// <summary>
        /// Called to set which resource service type to use by the QSP
        /// <param name="UseMock">indicator to select the mock services, by default, it is set to false.</param>
        /// </summary>
        public static void SetResourceServiceType(bool UseMock = false)
        {
            QueryProviderFactory factory = QueryProviderFactory.Instance();
            factory.SetType(UseMock ? ResourceServiceType.MOCK_ROA : ResourceServiceType.REAL);
        }

        #endregion

        #region "Execute"

        /// <summary>
        /// Cancel the current query request
        /// </summary>        
        public bool Cancel()
        {
            return _query.Cancel();
        }

        /// <summary>
        /// Called to run the query 
        /// </summary>        
        /// <param name="qRequest">QueryRequest</param>
        /// <param name="queryCache">DIBQueryCache</param>
        public void Execute(IDIBQueryCommand queryCommand, DIBQueryCache queryCache)
        {
            _query.Execute(queryCommand.CurrentQueryRequest, queryCache.DataItems);
        }

        /// <summary>
        /// Callback used by QSP to enable DIB to "Initial Chunk Load" items in the Grid
        /// </summary>
        /// <param name="item">The item to add to our collection</param>
        /// <param name="count">The count of items added so far</param>
        public void CallbackLoadInitialItems(List<DataItemBase> items, int count)
        {
            // Do the actual adding in the dispatcher. The GUI will be responsive and the rendering will perform slower but provide a better user experience
            // Note that this is executed synchronously (because use of Invoke, not BeginInvoke) so this forces us to wait for the render to complete
            _dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.SystemIdle, (Action)(() =>
            {
                _cds.QueryCache.AddDataItems(items);
            }));
        }

        /// <summary>
        /// Callback used by QSP to enable DIB to "Final Chunk Load" items in the Grid
        /// </summary>
        /// <param name="items">The list of items to add to our collection</param>
        /// <param name="count">The count of items added so far</param>
        public void CallbackLoadFinalItems(List<DataItemBase> items, int count)
        {
            // Currently, we do the same thing here as we do when loading initial items. Future considerations could be to optimize for better
            // performance by executing in a higher priority in the dispather
            CallbackLoadInitialItems(items, count);
        }

        /// <summary>
        /// Called when the query services have finished obtaining data for us
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void Query_DataLoadComplete(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            QueryResponse qResponse = sender as QueryResponse;

            // Add metaData rows to the end of the collection
            MetaDataHelper.CreateMetaDataFor(qResponse, _cds);

            _dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Send, (Action)(() =>
            {
                _cds.PerformQuery_DataLoadComplete(qResponse);
            }));
        }

        #endregion

        #region "Error Handling"

        /// <summary>
        /// We want to look at the exception and any inner exceptions to determine what category to label the error which determines what error string to display to user
        /// This is used for QSP/ROA errors from Initialize, Shutdown, and execute Query.
        /// </summary>      
        /// <param name="exception">The error string used in the GUI for the passed exception</param>
        public string ProcessExceptionErrorResponse(Exception exception, IClientDataServices cds)
        {
            string ErrorText = String.Empty;

            // If this was an error returned from QSP, we want to determine the error category and display an appropriate error message in GUI 
            if (exception as QueryException != null)
            {
                QueryException currentException = exception as QueryException;
                while (currentException != null)
                {
                    if (currentException.InnerException == null || !(currentException.InnerException is QueryException))
                    {
                        if (currentException.Message.ToLower().Contains("failed to connect to roa session manager service"))
                            ErrorText = cds.SetProblemInfo(ProblemInfoType.ResourceServiceDown);
                        else if (currentException.Message.ToLower().Contains("failed validation") && currentException.Message.ToLower().Contains("database uuid refers to an unknown database uuid"))
                            ErrorText = cds.SetProblemInfo(ProblemInfoType.InvalidContextGuid);
                        else
                            ErrorText = cds.SetProblemInfo(ProblemInfoTypeFromQueryExceptionType(currentException.ErrorInfoCode));

                        break;
                    }

                    currentException = currentException.InnerException as QueryException;
                }
            }
            else if (exception != null)
            {
                //Comparing by string will eventually change once a common system exception definition is created
                if (exception.Message.ToLower().Contains("session no longer valid"))
                {
                    ErrorText = cds.SetProblemInfo(ProblemInfoType.ResourceServiceDown);
                }
                else
                {
                    //We can assume that a generic Exception (i.e. not QueryException) is an initialize error since
                    // the callers of this code are all executing on QSP calls.  The likely way we get here is if
                    // there are wrong/missing versions of the QSP dlls.
                    ErrorText = cds.SetProblemInfo(ProblemInfoType.InitializationError);
                }
            }

            //We should be able to associate an error string for all exceptions encountered
            if (String.IsNullOrEmpty(ErrorText))
                throw new ArgumentOutOfRangeException("Unable to determine suitable DIB error Code for DIBQueryException: " + exception);

            return ErrorText;
        }

        /// <summary>
        /// Convert from QueryException.ErroInfoType enumeration to ProblemInfoType enumaration usable in the DIB
        /// </summary>      
        /// <param name="queryExceptionErrorInfo">An QueryException.ErrorInfoType enumeration value</param>
        private static ProblemInfoType ProblemInfoTypeFromQueryExceptionType(QueryException.ErrorInfoType queryExceptionErrorInfo)
        {
            switch (queryExceptionErrorInfo)
            {
                case QueryException.ErrorInfoType.InternalQSPError:
                    return ProblemInfoType.ResourceServiceError;
                case QueryException.ErrorInfoType.QueryInitializationError:
                    return ProblemInfoType.InitializationError;
                case QueryException.ErrorInfoType.QueryInitializeValidationError:
                    return ProblemInfoType.InitializationError;
                case QueryException.ErrorInfoType.QueryRequestValidationError:
                    return ProblemInfoType.InitializationError;
                case QueryException.ErrorInfoType.QueryShutdownError:
                    return ProblemInfoType.ResourceServiceError;
                case QueryException.ErrorInfoType.ResourceServiceCommunicationError:
                    return ProblemInfoType.ResourceServiceError;
                case QueryException.ErrorInfoType.ResourceServiceResponseError:
                    return ProblemInfoType.ResourceServiceError;
                case QueryException.ErrorInfoType.ResourceServiceTimeout:
                    return ProblemInfoType.ResourceServiceTimeout;
                default:
                    return ProblemInfoType.ResourceServiceError;
            }
        }

        #endregion
    }
    
}
