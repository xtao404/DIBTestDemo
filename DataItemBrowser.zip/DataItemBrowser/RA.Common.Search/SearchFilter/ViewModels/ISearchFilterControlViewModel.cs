﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using RockwellAutomation.UI.CommonControls.Models;
using RockwellAutomation.UI.CommonControls.ViewModels;

namespace RockwellAutomation.UI.CommonControls.SearchFilter.ViewModels
{
    /// <summary>
    /// Created to support Unit testing, methods needed to test other classes are added here
    /// as they are needed to complete testing
    /// Not all methods in SearchFilterControlViewModel are listed here.
    /// </summary>
    public interface ISearchFilterControlViewModel
    {
#region Properties

        /// <summary>
        /// Returns the starting index of the error
        /// </summary>
        int ErrorStartIndex {get; set; }

        /// <summary>
        /// Returns the length of the error
        /// </summary>
        int ErrorLength{get; set;}

        /// <summary>
        /// Returns true if there was a parse error
        /// </summary>
        bool HasError{get; set;}

         //TODO:FILTER remove when colorize the syntax for the search/filter text
        /// <summary>
        /// Search/Filter error indicator message
        /// </summary>
        string SearchErrorIndicatorMessage { get; set; }

         /// <summary>
        /// Search/Filter text 
        /// bound to the search/filter text box
        /// </summary>        
        string SearchFilterText { get; set; }

        /// <summary>
        /// Returns true if some search/filter is currently applied
        /// </summary>
        bool IsActive { get; set; }

        /// <summary>
        /// Whether or not the current search text is getting cleared
        /// </summary>
        bool IsClearingSearch();

        /// <summary>
        /// The current state of the SearchFilterControl
        /// </summary>
        SearchFilterControlViewModel.FilterState CurrentState { get; set; }

        /// <summary>
        /// Will be true if the last search was automatically performed (as a result of a timer
        /// firing).  False if the user explicitly invoked search (enter, MRU, etc).
        /// </summary>
        bool AutoSearched { get; set; }

        /// <summary>
        /// Returns true if these results contain any non-empty search/filter values
        /// </summary>
        bool HasNonEmptySearchValue { get; set; }

        /// <summary>
        /// Allows client to set the delay before a search is automatically performed
        /// </summary>
        TimeSpan AutoSearchTimerDelay { get; set; }

        ICommand ExecuteFilterCommand { get; }

        MruListObservableCollection SearchMruList { get; }

        bool SearchMruListHasItems { get; set; }

        ObservableCollection<FilterType> FilterTypes { get; }

        /// <summary>
        /// Allows client to turn on or off the ability to search on free form text
        /// </summary>
        bool SearchModeEnabled { get; set; }

        

#endregion Properties

        /// <summary>
        /// Clear search 
        /// </summary>
        void ClearSearch();

        /// <summary>
        /// Clears all items in the MRU list (use one of the static ClearMruListContext(s) instead if using named MRU list contexts)
        /// </summary>
        void ClearMruList();

        /// <summary>
        /// get the QueryCondition used for the query request condition in the CDS
        /// </summary>
        /// <returns>SearchFilterConfig</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate")]
        SearchFilterConfig GetFilterConfig();

        /// <summary>
        /// apply the view filtering on the item supplied
        /// </summary>
        /// <param name="item">item to be filtered</param>
        /// <param name="getFieldValue">delegate to get field value</param>
        /// <returns></returns>
        bool ApplyViewFilter(Object item, GetFieldValue getFieldValue);
        
        /// <summary>
        /// initialize with a filterdefinition 
        /// </summary>       
        /// <param name="filterDefinition"></param>
        void Initialize(SearchFilterDefinition filterDefinition);

        /// <summary>
        /// initialize with a filterdefinition and mruListContextName
        /// </summary>       
        /// <param name="filterDefinition"></param>
        /// <param name="mruListContextName"></param>
        void Initialize(SearchFilterDefinition filterDefinition, string mruListContextName = null);       
    }
}
