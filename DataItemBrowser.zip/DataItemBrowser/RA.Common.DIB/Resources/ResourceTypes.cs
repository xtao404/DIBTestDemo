﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using RockwellAutomation.ServiceFramework.DataTypes;

#endregion

namespace RockwellAutomation.UI
{
    /// <summary>
    /// B-10364: Build with ROA Stack Branch (aka Remove dependencies on "old" Resource Service)
    /// When not using the Resource Service, the UniversalIdentifier is used in lookup tables and
    /// and other identification scenarios.  We leveraged parts of the implementation from the
    /// Common Service's code to minimize the ripple effect in the Provider and View Model code.
    /// </summary>
    public class UniversalIdentifier
    {
        /// <summary>
        /// One and only instance of the global context identifier.
        /// </summary>
        private static UniversalIdentifier _globalContext = new UniversalIdentifier(0xc668ae005de64e87UL, 0x8f9d71855fb36a82UL);
        /// <summary>
        /// Readonly global context property.
        /// </summary>
        public static UniversalIdentifier globalContext
        {
            get { return _globalContext; }
        }

        /// <summary>
        /// Gets the uuid 
        /// </summary>
        /// <value>The uuid.</value>
        public UUID _uuid { get; private set; }

        /// <summary>
        /// Constructs a UniversalIdentifier given the hi and lo.
        /// </summary>
        public UniversalIdentifier(ulong hi, ulong lo)
        {
            _uuid = UUID.CreateBuilder().SetHi(hi).SetLo(lo).Build();
        }

        /// <summary>
        /// Constructs a UniversalIdentifier given a Guid.
        /// </summary>
        public UniversalIdentifier(System.Guid uuid)
        {
            byte[] byteArray = uuid.ToByteArray();

            ulong hi = ((ulong)byteArray[3] << 56) | ((ulong)byteArray[2] << 48) | ((ulong)byteArray[1] << 40) | ((ulong)byteArray[0] << 32) |
                       ((ulong)byteArray[5] << 24) | ((ulong)byteArray[4] << 16) | ((ulong)byteArray[7] << 8) | ((ulong)byteArray[6]);
            ulong lo = ((ulong)byteArray[8] << 56) | ((ulong)byteArray[9] << 48) | ((ulong)byteArray[10] << 40) | ((ulong)byteArray[11] << 32) |
                       ((ulong)byteArray[12] << 24) | ((ulong)byteArray[13] << 16) | ((ulong)byteArray[14] << 8) | ((ulong)byteArray[15]);

            _uuid = UUID.CreateBuilder()
                            .SetHi(hi)
                            .SetLo(lo)
                            .Build();
        }

        /// <summary>
        /// generates a new context.
        /// </summary>
        /// <value>The uuid.</value>
        static public UniversalIdentifier GenerateNewValue()
        {
            // We are counting on the service framework to include a platform-independent means
            // of generating a UUID. Until we get that, however, we will have to do it ourselves.
            System.Guid uuid = System.Guid.NewGuid();

            return new UniversalIdentifier(uuid);
        }
    }
}
