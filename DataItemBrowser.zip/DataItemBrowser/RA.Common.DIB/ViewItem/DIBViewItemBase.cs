/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System;
using System.ComponentModel;
using System.Collections.ObjectModel;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;
using RockwellAutomation.Logging;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// VisualBaseAbstract is a abstract class and represents a View object that is a wrapper around the DataModel (DataItemBase).
    /// Each instance of this class will represent a row in a GUI heirarchical tree.
    /// Everynode in the DIBTreeViewItem tree will either be represented by this class or interact with an instance of this class.
    /// </summary>
    public class DIBViewItemBase : IDisposable
    {

        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public DIBViewItemBase(DataItemBase dataItem)
        {
			DataItem = dataItem;

            if (this.HasDataItem)
            {
                this.Name = DIBViewItemBase.StringValueFrom(this.DataItem.CommonName, String.Empty);
                this.Description = DIBViewItemBase.StringValueFrom(this.DataItem.CommonDescription, String.Empty);
                this.IsSelected = DIBViewItemBase.BooleanValueFrom(DataItem.GUIIsInitiallyHighlighted);
                this.SupportsDrillIn = DIBViewItemBase.BooleanValueFrom(this.DataItem.GUISupportsDrillIn, this.DataItem.IsStructured);
                this.ImagePath = DIBViewItemBase.StringValueFrom(this.DataItem.GUISmallImagePath, null);
                this.ImageWidth = DIBViewItemBase.IntegerValueFrom(this.DataItem.GUISmallImageWidth, 16);
                this.ImageHeight = DIBViewItemBase.IntegerValueFrom(this.DataItem.GUISmallImageHeight, 16);
                this.AutomationID = DIBViewItemBase.StringValueFrom(this.DataItem.GUIAutomationID, this.Name);
                this.AutomationName = DIBViewItemBase.StringValueFrom(this.DataItem.GUIAutomationName, this.Name);
                this.ToolTip = DIBViewItemBase.StringValueFrom(this.DataItem.GUIToolTip, String.Empty);
                this.TextFontWeight = DIBViewItemBase.FontWeightFrom(this.DataItem.GUITextFontWeight, FontWeights.Normal);
            }
        }

        #endregion

        #region Variables/Properties

        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// DataModel item associated with this viewModel 
        /// </summary>
        public DataItemBase DataItem { get; set; }

        public bool HasDataItem
        {
            get { return this.DataItem != null; }
        }

        private string _name = String.Empty;
        /// <summary>
        /// The name to use to identify this GUI item
        /// </summary>
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        private string _description = String.Empty;
        /// <summary>
        /// The description to use to identify this GUI item
        /// </summary>
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
        protected bool _isSelected = false;
        /// <summary>
        /// Should the node in the visual tree be selected?
        /// </summary>
        public virtual bool IsSelected
        {
            get { return _isSelected; }
            set { _isSelected = value; }
        }

        /// <summary>
        /// Computed property to determine if we want to display an image for this ViewModel item
        /// </summary>
        public bool ShouldDisplayImage
        {
            get
            {
                if (!String.IsNullOrWhiteSpace(this.ImagePath)) return true;
                if (this.HasDataItem && !String.IsNullOrWhiteSpace(this.DataItem.GUISmallImageByteArraySource)) return true;
                return false;
            }
        }

        /// <summary>
        /// The visibility this item image should receive
        /// </summary>
        public Visibility ImageVisibility
        {
            get
            {
                if (this.ShouldDisplayImage)
                    return Visibility.Visible;
                else
                    return Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Computed property to determine if this viewModel item should display a tooltip
        /// </summary>
        public bool ToolTipIsEnabled
        {
            get
            {
                if (!String.IsNullOrWhiteSpace(this.ToolTip)) return true;
                return false;
            }
        }


        private bool _supportsDrillIn = false;
        /// <summary>
        /// Should the GUI element support a drill in arrow
        /// </summary>
        virtual public bool SupportsDrillIn
        {
            get { return _supportsDrillIn; }
            set { _supportsDrillIn = value; }
        }

        private string _imagePath;
        /// <summary>
        /// A path to where an image is located
        /// </summary>
        public string ImagePath
        {
            get { return _imagePath; }
            set { _imagePath = value; }
        }

        private ImageSource _imageSource;
        /// <summary>
        /// A byte array representation of an associated image
        /// </summary>
        public ImageSource ImageSource
        {
            get
            {
                if (_imageSource == null)
                { 
                    if (!String.IsNullOrWhiteSpace(this.ImagePath))
                    {
                        Uri uriSource = new Uri(this.ImagePath);
                        BitmapImage newSource = new BitmapImage(uriSource);
                        _imageSource = newSource;
                        return _imageSource;
                    }
                    // If the client is specifying the image source as a byte array unpack that here
                    if (this.HasDataItem && 
                        !String.IsNullOrWhiteSpace(this.DataItem.GUISmallImageByteArraySource))
                    {
                        byte[] imageByteArray = Convert.FromBase64String(this.DataItem.GUISmallImageByteArraySource);
                        ImageSource src = DIBByteImageConverter.ByteToImage(imageByteArray);
                        _imageSource = src;
                        return _imageSource;
                    }
                }
                return _imageSource;
            }
        }

        private int _imageWidth = 16;
        public int ImageWidth
        {
            get { return _imageWidth;  }
            set { _imageWidth = value; }
        }

        private int _imageHeight = 16;
        public int ImageHeight
        {
            get { return _imageHeight; }
            set { _imageHeight = value; }
        }

        private string _automationID = String.Empty;
        public string AutomationID
        {
            get { return _automationID; }
            set { _automationID = value; }
        }

        private string _automationName = String.Empty;
        public string AutomationName
        {
            get { return _automationName; }
            set { _automationName = value; }
        }

        private string _tooltip = String.Empty;
        public string ToolTip
        {
            get { return _tooltip; }
            set { _tooltip = value; } 
        }

        private FontWeight _textFontWeight = FontWeights.Normal;
        public FontWeight TextFontWeight
        {
            get { return _textFontWeight; }
            set { _textFontWeight = value; } 
        }

        #endregion

        #region INotifyPropertyChanged

        protected virtual void NotifyPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #region "GC"

        /// <summary>
        /// Property for the Disposable Pattern implementation
        /// </summary>
        protected bool IsDisposed
        {
            get;
            private set;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (IsDisposed)
                return;

            if (disposing)
            {
                this.PerformDispose();
            }
            else
            {
                LogWrapper.DibGeneralLog.Debug(this.GetType().Name + " " + this.Name + " Dispose(false) called by Finalizer. This object was never properly cleaned up.");
            }

            IsDisposed = true;
        }

        protected virtual void PerformDispose()
        {
            PropertyChanged = null;
        }

        /// <summary>
        /// Destructor
        /// </summary>
        ~DIBViewItemBase()
        {
            Dispose(false);   
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Helper method to safely convert a string value to a boolean value
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool BooleanValueFrom(String value, bool defaultValue = false)
        {
            bool semanticValue;
            if (Boolean.TryParse(value, out semanticValue))
                return semanticValue;
            else
                return defaultValue;
        }

        /// <summary>
        /// Helper method to safely convert a string value to an integer value
        /// </summary>
        /// <param name="value"></param>
        /// <param name="defaultVaue"></param>
        /// <returns></returns>
        public static int IntegerValueFrom(String value, int defaultValue = 0)
        {
            int semanticValue;
            if (int.TryParse(value, out semanticValue))
                return semanticValue;
            else
                return defaultValue;
        }

        /// <summary>
        /// Helper method to safely convert a string value to an integer value
        /// </summary>
        /// <param name="value"></param>
        /// <param name="defaultVaue"></param>
        /// <returns></returns>
        public static string StringValueFrom(string value, string defaultValue)
        {
            if (!String.IsNullOrWhiteSpace(value))
                return value;
            return defaultValue;
        }

        /// <summary>
        /// Helper method to safely convert a string value into a FontWeight
        /// </summary>
        /// <param name="value"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static FontWeight FontWeightFrom(string value, FontWeight defaultValue)
        {
            if (!String.IsNullOrWhiteSpace(value))
            {
                try
                {
                    FontWeightConverter converter = new FontWeightConverter();
                    return (FontWeight)converter.ConvertFromString(value);
                }
                catch (Exception e)
                {
                    LogWrapper.DibGeneralLog.Debug("**** Unable to Convert FontWeight:" + e.ToString());
                    return defaultValue;
                }
            }
            return defaultValue;
        }
        #endregion

        #region enumeration

        /// <summary>
        /// Enumeration identifies the supported visual
        /// perspectives that can be created
        /// </summary>
        public enum VisualPerspectiveEnum
        {
            TagBrowser,
            DataTypeBrowser,
            GenericDataBrowser,
            AOGPropertiesBrowser
        }

        #endregion
    }
}

