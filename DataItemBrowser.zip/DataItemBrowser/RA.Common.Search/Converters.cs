//////////////////////////////////////////////////////////////////////////////////
// Converters.cs
// Copyright 2011 Rockwell Automation Technologies, Inc.
//////////////////////////////////////////////////////////////////////////////////

using System;
using System.Globalization;
using System.Linq;
using System.Windows.Data;
using System.Windows;

namespace RockwellAutomation.UI.CommonControls
{
    /// <summary>
    /// Determines the width of the edit field (within the aggregate search control) and its distance from
    /// the search button
    /// </summary>
    public class FilterEditFieldWidth : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            double buttonsWidth=0;

            if (values != null)
            {
                double filterSPWidth = System.Convert.ToInt32(values[0],culture);

                for( int i = 1; i<values.Count(); i++)
                {
                    buttonsWidth += System.Convert.ToDouble(values[i],culture);
                }
   
                if ((filterSPWidth - buttonsWidth) < 0.0)
                    return 0.0;

                return filterSPWidth - buttonsWidth; // allowing for button that might end up on far end of search field
            }
            return null;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            return null;
        }
    }

    /// <summary>
    /// Determines the width of the mru popup window field (within the aggregate search control) and its distance from
    /// the filter button
    /// </summary>
    public class MruPopupWidthConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (values != null)
            {
                double filterSPWidth = System.Convert.ToInt32(values[0],culture);

                double buttonWidth = System.Convert.ToInt32(values[1],culture);

                if ((filterSPWidth - buttonWidth) < 0.0)
                    return 0.0;

                return filterSPWidth - buttonWidth; // allowing for button that might end up on far end of search field
            }
            return null;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {
            return null;
        }
    }

   

	/// <summary>
	/// Converts a whitespace string into null or otherwise (if a non-whitespace string is passed) returns the string
	/// </summary>
	[ValueConversion(typeof(string), typeof(Visibility))]
	public class StringToTooltipConverter : IValueConverter
	{
		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			string stringValue = (string)value;
			return string.IsNullOrWhiteSpace(stringValue) ? null : stringValue;
		}

		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			// We never intend to call this
		    return null;
		}
	}
}
