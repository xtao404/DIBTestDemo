﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region assembly references

using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.AbstractItem;


#endregion

namespace RockwellAutomation.UI
{
    /// <summary>
    /// Home PathElement
    /// </summary>
    public class HomePathElement : PathElementBase
    {
        #region private members

        private string _displayName = string.Empty;
        private bool _isActive = true;
        private List<DataItemBase> _dataItemList = new List<DataItemBase>();

        #endregion

        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public HomePathElement(DataItemBase dataItem, string displayName)
                :base(dataItem, displayName)
        {
        }

        #endregion


        #region PathElementBase overrides

        /// <summary>
        /// Property to get or set the path element's display name.
        /// </summary>
        public override string DisplayName
        {
            get { return _displayName; }
            set
            {
                if (_displayName == value)
                    return;
                _displayName = value;
                // notify listeners
                NotifyPropertyChanged("DisplayName");
            }
        }

        /// <summary>
        /// Property to get or set if the path element has children.
        /// </summary>
        public override bool HasChildren
        {
            //Set tagbrowser parameter to true to test for controller type, this test doesn't make sense for dtb
            get { return DataItem == null || DIResource.IsResourceTypeController(this.DataItem); }
        }

        /// <summary>
        /// Property to get or set if the path element is active.
        /// </summary>
        public override bool IsActive
        {
            get { return _isActive; }
            set
            {
                if (_isActive == value)
                    return;
                _isActive = value;
                //notify listeners
                NotifyPropertyChanged("IsActive");
            }
        }

        /// <summary>
        /// Property to get or set if the path element is a container.
        /// </summary>
        public override bool IsContainer
        {
            //Set tagbrowser parameter to true to test for controller type, this test doesn't make sense for dtb
            get { return DataItem == null || DIResource.IsResourceTypeController(this.DataItem); }
        }

        /// <summary>
        /// Property to get or set the list of data items that are chidren of the underlying component.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly", Justification = "Set by the HomePathElement")]
        public List<DataItemBase> DataItemList
        {
            get { return _dataItemList; }
            set { _dataItemList = value; }
        }

        /// <summary>
        /// Property to get or set the data item for the underlying component.
        /// </summary>
        public override DataItemBase DataItem
        {
            get
            {
                if (_dataItemList.Count == 0)
                    return null;
                return this._dataItemList[_dataItemList.Count - 1];
            }

        }

        /// <summary>
        /// Property to get or set the parent data item for the underlying component.
        /// </summary>
        public DataItemBase ParentDataItem
        {
            get
            {
                if (_dataItemList.Count <= 1)
                    return null;
                return this._dataItemList[_dataItemList.Count - 2];
            }

        }
        #endregion
    }
}
