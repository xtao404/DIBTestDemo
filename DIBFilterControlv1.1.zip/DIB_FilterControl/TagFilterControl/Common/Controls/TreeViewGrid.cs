﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using TagFilterControl.Tags;

namespace TagFilterControl.Common.Controls
{
    public class TreeViewGrid : Grid
    {
        public TreeViewGrid()
        {
            this.Loaded += (sender, args) =>
            {
                if (this.RefreshRightClickMenuVisible)
                {
                    var refreshItem = new MenuItem
                    {
                        Command = this.RefreshCommand,
                        Header = "Refresh",
                    };

                    refreshItem.Click += (s, e) =>
                    {
                        if (RefreshClick != null)
                        {
                            var viewModel = this.DataContext as TagNode;
                            viewModel.IsLoaded = false;
                            viewModel.IsRefresh = true;
                            if (viewModel != null)
                            {
                                viewModel.Children.Clear();
                            }
                            RefreshClick(viewModel, new RoutedEventArgs());
                        }
                    };
                    this.ContextMenu = new ContextMenu();
                    this.ContextMenu.Items.Add(refreshItem);
                }

                this.MouseLeftButtonDown += (s, e) =>
                {
                    if (RefreshClick != null)
                    {
                        RefreshClick(this.DataContext as TagNode, new RoutedEventArgs());
                    }
                    if (this.RefreshCommand != null)
                    {
                        this.RefreshCommand.Execute(this.DataContext as TagNode);
                    }
                };
            };
        }

        public static readonly DependencyProperty RefreshRightClickMenuVisibleProperty =
            DependencyProperty.Register("RefreshRightClickMenuVisible",
            typeof(bool),
            typeof(TreeViewGrid),
            new PropertyMetadata(true, (d, e) =>
            {
                if (d != null)
                {
                    var self = d as TreeViewGrid;
                    self.RefreshRightClickMenuVisible = (bool)e.NewValue;
                }
            }));
        public bool RefreshRightClickMenuVisible
        {
            get { return (bool)GetValue(RefreshRightClickMenuVisibleProperty); }
            set { SetValue(RefreshRightClickMenuVisibleProperty, value); }
        }

        public static readonly DependencyProperty RefreshCommandProperty = DependencyProperty.Register("RefreshCommand", typeof(CustomCommand<TreeViewGrid>), typeof(TreeViewGrid));
        public CustomCommand<TreeViewGrid> RefreshCommand
        {
            get { return GetValue(RefreshCommandProperty) as CustomCommand<TreeViewGrid>; }
            set { SetValue(RefreshCommandProperty, value); }
        }

        public event RoutedEventHandler RefreshClick;
    }
}
