﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for DarkeningColorConverterTest and is intended
    ///to contain all DarkeningColorConverterTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DarkeningColorConverterTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        //not supported
        ///// <summary>
        /////A test for ConvertBack
        /////</summary>
        //[TestMethod()]
        //public void ConvertBackTest()
        //{
        //    DarkeningColorConverter target = new DarkeningColorConverter(); 
        //    object value = null; 
        //    Type targetTypes = null; 
        //    object param = null; 
        //    CultureInfo culture = null; 
        //    object expected = null; 
        //    object actual;
        //    actual = target.ConvertBack(value, targetTypes, param, culture);
        //    Assert.AreEqual(expected, actual);
        //    Assert.Inconclusive("Verify the correctness of this test method.");
        //}

        /// <summary>
        ///</summary>
        [TestMethod()]
        public void DarkenColor_ConvertTest()
        {
            DarkeningColorConverter converter = new DarkeningColorConverter();
        ///A test for Convert
        ///         THIS TEST HAS BEEN OBVIATED BECAUSE THE SystemColor.HighlightBrush used in the Convert method
        ///         CAN VARY DEPENDING ON THE OPERATING SYSTEM ON WHICH IT IS BEING EXECUTED.
        ///         THIS DARKENING COLOR TEST WILL NOW BE TESTED VIA A COLORADJUSTER TEST (AdjustColorTest_DarkeningColor())
        //    object value = new Color(); 
        //    Type targetType = typeof(Color); 
        //    object param = 1.0; 
        //    CultureInfo culture = null; 
        //    Color expected = new Color(); 
        //    expected.A = 255;
        //    expected.R = 38;
        //    expected.G = 114;
        //    expected.B = 191;
        //    object actual = target.Convert(value, targetType, param, culture);
        //    Color actualColor = (Color)actual;
        //    Assert.AreEqual(expected, actualColor);
            // test for ConvertBack
            try
            {
                converter.ConvertBack(null, null, null, null);
            }
            catch (NotSupportedException exception)
            {
                Assert.AreEqual("Not supported", exception.Message);
            }
        }

        /// <summary>
        ///A test for DarkeningColorConverter Constructor
        ///</summary>
        [TestMethod()]
        public void DarkeningColorConverterConstructorTest()
        {
            DarkeningColorConverter target = new DarkeningColorConverter();
            Assert.AreNotEqual(target, null);
        }
    }
}
