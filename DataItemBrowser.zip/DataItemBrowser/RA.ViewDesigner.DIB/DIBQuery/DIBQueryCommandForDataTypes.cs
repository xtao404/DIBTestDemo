﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query;

namespace RockwellAutomation.UI.DIBQuery
{
    class DIBQueryCommandForDataTypes : DIBQueryCommandForViewe
    {

        #region "Creation/Init"

        public DIBQueryCommandForDataTypes(QueryRequest.CreateBuilder queryRequestBuilder)
            : base(queryRequestBuilder)
        {
            CacheQueryResults = true;
        }

        #endregion

        #region "Base Overides"

        public override PredefinedQueryType QueryType()
        {
            return PredefinedQueryType.DataTypes;
        }

        public override void Execute(IClientDataServices cds, IDIBQueryConnection queryConnection)
        {

            // If we are attempting to display the initial screen of the Data Type Browser, we dont need to go to QSP.
            if (this.ParentDataItem() == null)
            {
                //Create the elements for Data Type Browser
                cds.QueryCache.AddDataItem(DIResource.DIB_UserDefined);
                cds.QueryCache.AddDataItem(DIResource.DIB_PreDefined);
                cds.QueryCache.AddDataItem(DIResource.DIB_ModuleDefined);

                ExecuteNonDBQueryResponse(queryConnection, cds.QueryCache);
                return;
            }
            base.Execute(cds, queryConnection);
        }

        #endregion
    }
}
