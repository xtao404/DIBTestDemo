﻿/*************************************************************************************
                                                                     
   ViewE                                                                      
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/



using System;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI;

namespace DataItemBrowserUT
{
    public class DIBUtility
    {
	   
        //private static DIBUtility _DIBUtilityInstance = null;

        ///// <summary>
        ///// gets the instance of the DIBUtility
        ///// </summary>
        ///// <returns></returns>
        //[MethodImpl(MethodImplOptions.Synchronized)]
        //public static DIBUtility Instance()
        //{
        //    if (_DIBUtilityInstance == null)
        //    {
        //        _DIBUtilityInstance = new DIBUtility();
        //    }
        //    return _DIBUtilityInstance;
        //}


        public static TSObservableCollection<DataItemBase> GetControllerViewList()
        {
            TSObservableCollection<DataItemBase> dataItems = new TSObservableCollection<DataItemBase>();
            DataItemBase dib2 = PathElementUtility.Instance().CreateDataItemBase(DIResource.DI_COMMON_RESOURCETYPE_TAGSPROPERTIES);
            dib2.CommonResourceType = TypeIdentifiers.ResourceType_TagsAndProperties.ToString();
            dataItems.Add(dib2);
            DataItemBase dib = PathElementUtility.Instance().CreateDataItemBase(DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS);
            dib.CommonResourceType = TypeIdentifiers.ResourceType_Programs.ToString();
            dataItems.Add(dib);
            DataItemBase dib1 = PathElementUtility.Instance().CreateDataItemBase(DIResource.DI_COMMON_RESOURCETYPE_DATALOGS);
            dib1.CommonResourceType = TypeIdentifiers.ResourceType_DataLogs.ToString();
            dataItems.Add(dib1);

            return dataItems;
        }

        public static TSObservableCollection<DataItemBase> GetDeviceViewList(string excludeItem = null)
        {
            TSObservableCollection<DataItemBase> dataItems = new TSObservableCollection<DataItemBase>();
            if (excludeItem == null || !excludeItem.Equals(DIResource.DI_COMMON_RESOURCETYPE_DEVICE))
                dataItems.Add(PathElementUtility.Instance().CreateDataItemBase("Local:HMIDevice"));

            DataItemBase dib = PathElementUtility.Instance().CreateDataItemBase("c1");
            dib.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();
            dataItems.Add(dib);
            DataItemBase dib1 = PathElementUtility.Instance().CreateDataItemBase("c2");
            dib1.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();
            dataItems.Add(dib1);
            DataItemBase dib2 = PathElementUtility.Instance().CreateDataItemBase("c2");
            dib2.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();
            dataItems.Add(dib2);

            return dataItems;
        }

        public static TSObservableCollection<DataItemBase> GetProgramList()
        {
            TSObservableCollection<DataItemBase> dataItems = new TSObservableCollection<DataItemBase>();
            DataItemBase dib = PathElementUtility.Instance().CreateDataItemBase(DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS);
            dib.CommonResourceType = TypeIdentifiers.ResourceType_Programs.ToString();
            dataItems.Add(dib);
            return dataItems;
        }

        public static TSObservableCollection<DataItemBase> GetTagViewList()
        {
            TSObservableCollection<DataItemBase> dataItems = new TSObservableCollection<DataItemBase>();

            DataItemBase dib2 = PathElementUtility.Instance().CreateDataItemBase("MyTag1");
            dib2.CommonLocation = "::c1\\Program1";
            dataItems.Add(dib2);

            DataItemBase dib = PathElementUtility.Instance().CreateDataItemBase("MyTag");
            dib.CommonLocation = "::c1";
            dataItems.Add(dib);

            DataItemBase dib1 = PathElementUtility.Instance().CreateDataItemBase("MyTag");
            dib1.CommonLocation = "::c1\\Program1";
            dataItems.Add(dib1);

            return dataItems;
        }

        public static TSObservableCollection<DataItemBase> GetDataTypeList()
        {
            TSObservableCollection<DataItemBase> dataItems = new TSObservableCollection<DataItemBase>();

            DataItemBase dib2 = PathElementUtility.Instance().CreateDataItemBase("Level01");
            dib2.CommonLocation = "::c1";
            dataItems.Add(dib2);

            DataItemBase dib = PathElementUtility.Instance().CreateDataItemBase("Level02");
            dib.CommonLocation = "::c1";
            dataItems.Add(dib);

            DataItemBase dib1 = PathElementUtility.Instance().CreateDataItemBase("Level04");
            dib1.CommonLocation = "::c1";
            dataItems.Add(dib1);

            return dataItems;
        }

        public static DataItemBase GetControllerDataItemBase()
        {
            DataItemBase dib = PathElementUtility.Instance().CreateDataItemBase("c1");
            dib.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();
            return dib;
        }
    }
}