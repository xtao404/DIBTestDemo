﻿/* ****************************************************************************
*
*  Copyright 2012-2015 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/
using System.Collections.ObjectModel;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI.CommonControls.DeviceImage;
using RockwellAutomation.Client.Services.Query;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// IVisualBase interface definition.
    /// </summary>
    public interface IVisualBase : IDeviceStatus
    {
        /// <summary>
        /// Property to get or set the name used for visualization
        /// </summary>
        string VisualName 
        { 
            get; 
            set; 
        }
        
        /// <summary>
        /// Property to get or set the visualization type
        /// </summary>
        VisualType VisualType 
        { 
            get; 
            set; 
        }

        /// <summary>
        /// Property to get or set the if the visualization object is selected
        /// </summary>
        bool IsSelected 
        { 
            get; 
            set; 
        }
        
        /// <summary>
        /// Property to get or set if the visualization object is expanded
        /// </summary>
        bool IsExpanded 
        { 
            get; 
            set;         
        }

        /// <summary>
        /// Property to get or set this DIBTreeViewItem object's parent
        /// </summary>
        IVisualBase Parent 
        { 
            get; 
            set; 
        }
        
        /// <summary>
        /// Property to get this DIBTreeViewItem object's children
        /// </summary>
        IObservableCollection<IVisualBase> Children 
        { 
            get; 
        }

        /// <summary>
        /// Property to get whether this DIBTreeViewItem object supports drilling in
        /// </summary>
        bool SupportsDrillIn 
        { 
            get; 
        }
       

		/// <summary>
		/// Unique Id the visual represents
		/// </summary>
		UUID ResourceId
		{
			get;
			set;
		}
    }

    #region Declaration of VisualTypes enumeration

    /// <summary>
    /// Enumeration containing the valid types of visual types.
    /// The visual type of a node can determine if it is drillable (see SupportsDrillIn) or
    /// the type of icon that will be displayed with it.
    /// </summary>
    public enum VisualType
    {
        vtNoIcon = 0,                   // Indicates VisualType which does not have an icon
        vtControllers,                  // The Tag Browser's root
        vtController,                   // One of the DataSourceViewModels
        vtDataTypes,                    // The DataType browser's root
        vtUserDefined,                  // Container for User-Defined data types
        vtPredefined,                   // Container for Predefined data types
        vtModuleDefined,                // Container for Module-Defined data types
        vtHMIDevice,                    // Container for a HMI Device
        vtHMIDevices,                   // The root of the HMI Devices
        vtTagsAndProperties,            // TagsAndProperties folder within the Controller Device View
        vtPrograms,                     // Programs folder within the Controller Device View
        vtDataLogs,                     // DataLogs folder within the Controller Device View
        vtScreens,                      // Screens folder within the HMIDevice Device View
        vtGenericType             // This is a non-viewe visual type that a generic DIB client can use
    };

    #endregion
}
