/*************************************************************************************
                                                                     
   ViewE DIBClientManagerTest Class
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System.Collections.Generic;
using FakeItEasy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using System;
using RockwellAutomation.Client.Services.Query;

#endregion

namespace DataItemBrowserUT
{

    /// <summary>
    /// This class is a test for the abstract class DIBClientManager.
    /// </summary>
    [TestClass]
    public class DIBClientManagerTest
    {
        DIBClientManager clientManager;

        #region test Initialize / Cleanup

        [TestInitialize()]
        public void DIBClientManagerTestInit()
        {
            if ((clientManager == null))
            {
                clientManager = new UninitializedDIBClientManager();
            }
        }
        //
        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void DIBClientManagerTestCleanup()
        {
            if (clientManager == null) return;
            clientManager.Close();
            clientManager.Shutdown();
            clientManager = null;
        }

        #endregion

        /// <summary>
        /// A test for default settings in DIBClientManager
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DefaultSettingsTest()
        {
            Assert.IsTrue(clientManager.IsGenericDIBBrowser());

            Assert.IsTrue(clientManager.ShouldCloseOnSelect());
            Assert.IsFalse(clientManager.ShouldSearchViaQuery(null));
            Assert.IsTrue(String.IsNullOrEmpty(clientManager.InitialLaunchString));
            Assert.IsNull(clientManager.GetGridColumnMetaData());
        }

        /// <summary>
        /// A test for Search Related Functionality 
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void SearchRelatedFunctionalityTest()
        {
            Assert.IsFalse(clientManager.ShouldSearchViaQuery(null));

            ObservableCollection<RockwellAutomation.UI.CommonControls.FilterType> filterTypes = clientManager.GetFilterTypes();
            Assert.IsTrue(filterTypes.Count == 2);
            Assert.AreSame(filterTypes[0].Name, DIBConstants.Common.Name);
            Assert.AreSame(filterTypes[1].Name, DIBConstants.Common.Description);
  
        }

        /// <summary>
        /// A test for DrillIn
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DrillInTest()
        {
            DataItemBase dataItemToDrillInTo = DIResource.DIB_TagsAndProps;
            TSObservableCollection<DataItemBase> dataItems = new TSObservableCollection<DataItemBase>();
            DIBQueryCache queryCache = new DIBQueryCache(dataItems);

            Assert.AreEqual(queryCache.DataItemsCount(), 0, "Query cache should be empty. We just initialized it");
            clientManager.DrillInFor(dataItemToDrillInTo, queryCache);
            Assert.AreEqual(queryCache.DataItemsCount(), 0, "Query cache should be empty. Drill in on DIBClientManager base class should not add to cache");


            Assert.AreEqual(clientManager.GetResourceTypeString(dataItemToDrillInTo), DIResource.DI_COMMON_RESOURCETYPE_NONE, "Default Resource Type String should be DIResource.DI_COMMON_RESOURCETYPE_NONE");
            Assert.IsTrue(clientManager.GetDataViewTypeFor(String.Empty).IsTreeView(), "Default Data View Type is DIBDataViewTypeDataSources");
        }

        /// <summary>
        /// A test for Path related base functionality
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void PathTest()
        {
            DIBClientManagerForViewe.InitializeVieweSpecificClasses();
            List<IPathElement> pathElements = new List<IPathElement>();

            Assert.AreEqual(clientManager.PathToString(pathElements, string.Empty, DIBViewItemBase.VisualPerspectiveEnum.GenericDataBrowser), @"\", @"Default path to string should prepend with \");

            pathElements.Add(PathElementFactory.Instance().CreatePathElement(PathElementUtility.Instance().CreateHomeDataItem("home")));
            Assert.AreEqual(clientManager.PathToString(pathElements, string.Empty, DIBViewItemBase.VisualPerspectiveEnum.GenericDataBrowser), @"\\home", @"Default path to string should prepend with \");

            pathElements.Add(PathElementFactory.Instance().CreatePathElement(DIResource.DIB_TagsAndProps));
            Assert.AreEqual(clientManager.PathToString(pathElements, string.Empty, DIBViewItemBase.VisualPerspectiveEnum.GenericDataBrowser), @"\\home\Controller Tags", @"Default path to string should prepend with \");

        }
      
    }
}
