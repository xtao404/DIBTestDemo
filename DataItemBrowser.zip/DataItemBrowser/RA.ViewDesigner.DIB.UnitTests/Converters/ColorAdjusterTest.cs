﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Windows.Media;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for ColorAdjusterTest and is intended
    ///to contain all ColorAdjusterTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ColorAdjusterTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for AdjustColor
        ///</summary>
        [TestMethod()]
        public void AdjustColorTest()
        {
            Color startColor = new Color();
            startColor.A = 255;
            startColor.R = 125;
            startColor.G = 125;
            startColor.B = 255;

            double weight = 1.25F; 
            double opacity = 0.5F; 
            Color expected = new Color(); 
            Color actual;
            expected.A = 127;
            expected.R = 156;
            expected.G = 156;
            expected.B = 255;
            actual = ColorAdjuster.AdjustColor(startColor, weight, opacity);
            Assert.AreEqual(expected, actual);

            startColor = new Color();
            startColor.A = 255;
            startColor.R = 125;
            startColor.G = 125;
            startColor.B = 255;

            weight = 0.75F; 
            opacity = 1.0F; 
            expected = new Color(); 
            expected.A = 255;
            expected.R = 93;
            expected.G = 93;
            expected.B = 191;
            actual = ColorAdjuster.AdjustColor(startColor, weight, opacity);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void AdjustColorTest_DarkeningColor()
        {
            Color startColor = new Color();
            double weight = .75F;           // darkening weight
            double opacity = 1.0F;          
            Color actual;

            // VISTA SystemColor.HighlightBrush   (xFF3399FF)            
            startColor.A = 255;
            startColor.R = 51;      // hex 33
            startColor.G = 153;     // hex 99
            startColor.B = 255;     // hex FF

            Color expected_Vista = new Color(); // (xFF2672BF)
            expected_Vista.A = 255;
            expected_Vista.R = 38;
            expected_Vista.G = 114;
            expected_Vista.B = 191;
            actual = ColorAdjuster.AdjustColor(startColor, weight, opacity);
            Assert.AreEqual(expected_Vista, actual);

            // XP SystemColor.HighlightBrush    (xFF0A246A)            
            startColor.A = 255;
            startColor.R = 10;      // hex 0A
            startColor.G = 36;      // hex 24
            startColor.B = 106;     // hex 6A

            Color expected_XP = new Color();    // (xFF071B4F)
            expected_XP.A = 255;
            expected_XP.R = 7;      // hex 07
            expected_XP.G = 27;     // hex 1B
            expected_XP.B = 79;     // hex 4F
            actual = ColorAdjuster.AdjustColor(startColor, weight, opacity);
            Assert.AreEqual(expected_XP, actual);
        }

        [TestMethod()]
        public void AdjustColorTest_LighteningColor()
        {
            Color startColor = new Color();
            double weight = 1.25F;              // Lightening weight
            double opacity = .75F;              // Lightening opacity
            Color actual;

            // VISTA SystemColor.HighlightBrush   (xFF3399FF)         
            startColor.A = 255;
            startColor.R = 51;      // hex 33
            startColor.G = 153;     // hex 99
            startColor.B = 255;     // hex FF

            Color expected_Vista = new Color(); // (xBF3FBFFF)
            expected_Vista.A = 191;     // hex BF
            expected_Vista.R = 63;      // hex 3F
            expected_Vista.G = 191;     // hex BF
            expected_Vista.B = 255;     // hex FF
            actual = ColorAdjuster.AdjustColor(startColor, weight, opacity);
            Assert.AreEqual(expected_Vista, actual);
            
            
            // XP SystemColor.HighlightBrush    (xFF0A246A)
            startColor.A = 255;
            startColor.R = 10;      // hex 0A
            startColor.G = 36;      // hex 24
            startColor.B = 106;     // hex 6A

            Color expected_XP = new Color();    // (xBF0C2D84)
            expected_XP.A = 191;    // hex BF
            expected_XP.R = 12;     // hex 0C
            expected_XP.G = 45;     // hex 2D
            expected_XP.B = 132;    // hex 84
            actual = ColorAdjuster.AdjustColor(startColor, weight, opacity);
            Assert.AreEqual(expected_XP, actual);

            // SystemColor.HighlightBrush   (xFFFFFFFF)         
            startColor.A = 255;     // hex FF
            startColor.R = 255;     // hex FF
            startColor.G = 255;     // hex FF
            startColor.B = 255;     // hex FF
            
            Color expected_adj = new Color();    // (xBFFFFFFF)
            expected_adj.A = 191;    // hex BF
            expected_adj.R = 255;    // hex FF
            expected_adj.G = 255;    // hex FF
            expected_adj.B = 255;    // hex FF
            actual = ColorAdjuster.AdjustColor(startColor, weight, opacity);
            Assert.AreEqual(expected_adj, actual);
        }

       
    }
}
