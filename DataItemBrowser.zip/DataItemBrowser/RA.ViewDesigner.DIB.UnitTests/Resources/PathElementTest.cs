﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for PathElementTest and is intended
    ///to contain all PathElementTest Unit Tests
    ///</summary>
    [TestClass()]
    public class PathElementTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for IsDataSource
        ///</summary>
        [TestMethod()]
        public void IPathElement_IsContainerTest_True()
        {
            IPathElement target = PathElementUtility.Instance().CreateProgramPathElement("container");
            bool expected = true;
            bool actual;
            actual = target.IsContainer;
            Assert.AreEqual(expected,actual);
        }
   
        /// <summary>
        ///A test for IsDataSource
        ///</summary>
        [TestMethod()]
        public void IPathElement_IsContainerTest_False()
        {
            IPathElement target = PathElementUtility.Instance().CreateDataItemPathElement("notContainer", "", true);
            bool expected = false;
            bool actual;
            actual = target.IsContainer;
            Assert.AreEqual(expected, actual);
        }
        /// <summary>
        ///A test for IsActive
        ///</summary>
        [TestMethod()]
        public void IPathElement_IsActiveTest()
        {
            IPathElement target = PathElementUtility.Instance().CreateDataItemPathElement("isActive", "", true); 
            bool expected = true; 
            bool actual;
            target.IsActive = expected;
            actual = target.IsActive;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for HasChildren
        ///</summary>
        [TestMethod()]
        public void IPathElement_HasChildrenTest()
        {
            IPathElement target = PathElementUtility.Instance().CreateControllerPathElement("hasChildren"); 
            bool expected = true; 
            bool actual;
            actual = target.HasChildren;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for HasChildren
        ///</summary>
        [TestMethod()]
        public void IPathElement_HasChildrenTest_HMIDevice()
        {
            IPathElement target = PathElementUtility.Instance().CreateHMIDevicePathElement("hasChildren");
            bool expected = true;
            bool actual;
            actual = target.HasChildren;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for DisplayName
        ///</summary>
        [TestMethod()]
        public void IPathElement_DisplayNameTest()
        {
            string expected = "happyName";
            IPathElement target = PathElementUtility.Instance().CreateProgramPathElement(expected); 
            string actual;
            actual = target.DisplayName;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for NotifyPropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void IPathElement_NotifyPropertyChangedTest()
        {
            HMIDevicePathElement target = PathElementUtility.Instance().CreateHMIDevicePathElement("oldName") as HMIDevicePathElement;
            string propertyName = "DisplayName";

            target.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(local_PropertyChanged);
            target.DisplayName = "newName";
            Assert.AreEqual(propertyName, _propertyName);
            //Assert.Inconclusive("adding tghe propertychanged event throws an exception not sure why");
        }

        /// <summary>
        /// support the PathElement_NotifyPropertyChangedTest
        /// </summary>
        private string _propertyName = string.Empty;
       /// <summary>
        /// support the PathElement_NotifyPropertyChangedTest
        /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
        void local_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            _propertyName = e.PropertyName;
        }

        
    }
}
