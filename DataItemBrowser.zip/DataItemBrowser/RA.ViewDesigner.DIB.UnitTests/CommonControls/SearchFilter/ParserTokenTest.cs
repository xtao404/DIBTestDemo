﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    
    /// <summary>
    ///This is a test class for ParserTokenTest and is intended
    ///to contain all ParserTokenTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ParserTokenTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Value
        ///</summary>
        [TestMethod()]
        public void ParserToken_ValueTest()
        {
            ParserToken target = new ParserToken();
            PrivateObject targetPrivate = new PrivateObject(target);
            string expected = "ffff";

            targetPrivate.SetFieldOrProperty("Value", expected);
            string actual = target.Value;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for StartingIndex
        ///</summary>
        [TestMethod()]
        public void ParserToken_StartingIndexTest()
        {
            ParserToken target = new ParserToken();
            PrivateObject targetPrivate = new PrivateObject(target);
            int expected = 6;
            targetPrivate.SetFieldOrProperty("_startingIndex", expected);
            int actual = target.StartingIndex;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for ExactMatch
        ///</summary>
        [TestMethod()]
        public void ParserToken_ExactMatchTest()
        {
            ParserToken target = new ParserToken();
            PrivateObject targetPrivate = new PrivateObject(target);
            targetPrivate.SetFieldOrProperty("ExactMatch", true);
            bool actual = target.ExactMatch;
            Assert.AreEqual(true, actual);
        }

        /// <summary>
        ///A test for IsValueMatchTestContainsDataType
        ///</summary>
        [TestMethod()]
        public void ParserToken_IsValueMatchTestContainsDataType()
        {
            string fieldValue = "DINT";
            ParserToken target = new ParserToken(SearchFilterParser.ValueGroup, DIResource.DI_COMMON_RESOURCETYPE_INT, 4, false);            
            bool actual = target.IsValueMatch(fieldValue, DIBConstants.Common.DataType);
            Assert.AreEqual(true, actual);
        }

        /// <summary>
        ///A test for IsValueMatchTestExactDataType
        ///</summary>
        [TestMethod()]
        public void ParserToken_IsValueMatchTestExactDataType()
        {
            string fieldValue = "DINT";
            ParserToken target = new ParserToken(SearchFilterParser.ValueGroup,"DINT", 4, true);            
            bool actual = target.IsValueMatch(fieldValue, DIBConstants.Common.DataType);
            Assert.AreEqual(true, actual);
        }

        /// <summary>
        ///A test for ParserToken_IsValueMatchTestExactDataTypeWithArray
        ///</summary>
        [TestMethod()]
        public void ParserToken_IsValueMatchTestExactDataTypeWithArray()
        {
            string fieldValue = "DINT[23]";
            ParserToken target = new ParserToken(SearchFilterParser.ValueGroup, "DINT", 4, true);
            bool actual = target.IsValueMatch(fieldValue, DIBConstants.Common.DataType);
            Assert.AreEqual(true, actual);
        }

        /// <summary>
        ///A test for ParserToken_IsValueMatchTestExactDataTypeWithArrayAndArrayCharacterInSearch
        ///</summary>
        [TestMethod()]
        public void ParserToken_IsValueMatchTestExactDataTypeWithArrayAndArrayCharacterInSearch()
        {
            string fieldValue = "DINT[2]";
            // If the user enters the string "DINT[" (a search string that has the array start character)
            // then we do NOT want to consider this a match on an array type
            ParserToken target = new ParserToken(SearchFilterParser.ValueGroup, "DINT[", 4, true);
            bool actual = target.IsValueMatch(fieldValue, DIBConstants.Common.DataType);
            Assert.AreEqual(false, actual);
        }

        /// <summary>
        ///A test for ParserToken_IsValueMatchTestExactDataTypeWithMultiDimArray
        ///</summary>
        [TestMethod()]
        public void ParserToken_IsValueMatchTestExactDataTypeWithMultiDimArray()
        {
            string fieldValue = "DINT[2, 2, 4]";
            ParserToken target = new ParserToken(SearchFilterParser.ValueGroup, "DINT", 4, true);
            bool actual = target.IsValueMatch(fieldValue, DIBConstants.Common.DataType);
            Assert.AreEqual(true, actual);
        }

        /// <summary>
        ///A test for IsValueMatchTestContainsName
        ///</summary>
        [TestMethod()]
        public void ParserToken_IsValueMatchTestContainsName()
        {
            string fieldValue = "Mike";
            ParserToken target = new ParserToken(SearchFilterParser.ValueGroup,"i", 4, false);
            bool actual = target.IsValueMatch(fieldValue, DIBConstants.Common.Name);
            Assert.AreEqual(true, actual);

            fieldValue = "Predefined Data Type Alarm3";
            target = new ParserToken(SearchFilterParser.ValueGroup, "def", 4, false);
            actual = target.IsValueMatch(fieldValue, DIBConstants.Common.Name);
            Assert.AreEqual(true, actual);
        }

        /// <summary>
        ///A test for IsValueMatchTestExactName
        ///</summary>
        [TestMethod()]
        public void ParserToken_IsValueMatchTestExactName()
        {
            string fieldValue = "Mike";
            ParserToken target = new ParserToken(SearchFilterParser.ValueGroup,"Mike", 4, true);
            bool actual = target.IsValueMatch(fieldValue, DIBConstants.Common.Name);
            Assert.AreEqual(true, actual);
        }

         
    }
}
