﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using RSLogix5000RevisionDirectoryLib;

namespace TagFilterControl.DIBClientManagers.DataGridViewSimple.LogixServices
{
    public class LogixService
    {
        private static LogixService instance = new LogixService();
        private LogixService() { }

        public static LogixService GetInstance()
        {
            if (instance == null)
            {
                instance = new LogixService();
            }
            return instance;
        }

        private static Dictionary<string, object> logixServicesCollection = new Dictionary<string, object>();
        private Task initialiseTask;

        public void InitialiseInstance()
        {
            logixServicesCollection = new Dictionary<string, object>();
            string latestAvailableRev = string.Empty;
            try
            {
                RevisionDirectory revisionDirectory = new RevisionDirectory();
                revisionDirectory.Initialize();
                latestAvailableRev = revisionDirectory.LatestAvailableRevision.MajorRev.ToString();
            }
            catch (Exception)
            {
                return;
            }

            initialiseTask = Task.Factory.StartNew(() => Initialise(latestAvailableRev));
        }

        public string GetACDSupportedRevision(string fullProjectFileName)
        {
            try
            {
                RevisionDirectory revisionDirectory = new RevisionDirectory();
                if (revisionDirectory == null)
                {
                    return null;
                }

                revisionDirectory.Initialize();
                Revision rev = revisionDirectory.GetRevisionFromProjectFile(fullProjectFileName);
                if (rev == null)
                {
                    return null;
                }

                if (rev.IsAvailable != 1)
                {
                    return null;
                }

                return rev.MajorRev.ToString();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public object GetInstance(string version)
        {
            lock (logixServicesCollection)
            {
                if (logixServicesCollection == null)
                {
                    logixServicesCollection = new Dictionary<string, object>();
                }

                if (initialiseTask != null && !initialiseTask.IsCompleted)
                {
                    initialiseTask.Wait();
                }

                if (!logixServicesCollection.ContainsKey(version) || logixServicesCollection[version] == null)
                {
                    if (!Initialise(version))
                    {
                        return null;
                    }
                }

                return logixServicesCollection[version];
            }
        }

        private bool Initialise(string version)
        {
            lock (logixServicesCollection)
            {
                if (!IsVersionSupported(version))
                {
                    return false;
                }

                Type lgxServicesType = Type.GetTypeFromProgID("RSLogix5000Services.LogixServices." + version + ".00", true);
                object logixservices = Activator.CreateInstance(lgxServicesType);
                if (!Marshal.IsComObject(logixservices))
                {
                    return false;
                }

                decimal getResult = (decimal)logixservices.GetType().InvokeMember("GetType", BindingFlags.InvokeMethod, null, logixservices, new object[] { });
                getResult = getResult * 267421 + 3971;
                logixservices.GetType().InvokeMember("SetType", BindingFlags.InvokeMethod, null, logixservices, new object[1] { getResult });
                logixServicesCollection[version] = logixservices;
                return true;
            }
        }

        private bool IsVersionSupported(string version)
        {
            try
            {
                int majorRev = -1;
                if (!int.TryParse(version, out majorRev))
                {
                    return false;
                }

                RevisionDirectory revisionDirectory = new RevisionDirectory();
                if (revisionDirectory == null)
                {
                    return false;
                }

                revisionDirectory.Initialize();
                Revision rev = revisionDirectory.GetRevisionFromMajorRev(majorRev);
                if (rev == null)
                {
                    return false;
                }

                if (rev.IsAvailable != 1)
                {
                    return false;
                }
            }
            catch (Exception)
            {
                return false;
            }

            return true;
        }
    }
}
