﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Common;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public class ConditionFilterBase : BaseViewModel
    {
        private bool isChecked;
        public bool IsChecked
        {
            get
            {
                return this.isChecked;
            }
            set
            {
                this.isChecked = value;
                this.IsCheckedChanged.Execute(value);
                this.RaisePropertyChangedEvent(() => this.IsChecked);
            }
        }
        public event Action<bool> IsCheckedChanged;

        private CustomCommand<bool> checkCommand;
        public CustomCommand<bool> CheckCommand
        {
            get
            {
                return this.checkCommand ?? (this.checkCommand = new CustomCommand<bool>(isChecked =>
                {
                    IsChecked = isChecked;
                }));
            }
        }

        private object _value;
        public object Value
        {
            get { return _value; }
            set
            {
                _value = value;
                this.RaisePropertyChangedEvent(() => this.Value);
            }
        }

        private ObservableCollection<object> ruleItemsSource = new ObservableCollection<object>();
        public ObservableCollection<object> RuleItemsSource
        {
            get { return this.ruleItemsSource; }
            set
            {
                this.ruleItemsSource = value;
                this.RaisePropertyChangedEvent(() => this.RuleItemsSource);
            }
        }

        private object _rule;
        public object Rule
        {
            get { return _rule; }
            set
            {
                this._rule = value;

                var currentRuleItem = value as RuleItemForDisplay;
                var util = FilterPolicyManager.GetDestFilterUtil();
                ConditionItemsSource = new ObservableCollection<object>(FilterPolicyCommonUtil.GetConditionItemsByRule(currentRuleItem));
                Condition = FilterPolicyCommonUtil.GetConditionByRule(currentRuleItem);
                Value = new ValueItemForDisplay(util.GetValue(currentRuleItem.FilterRuleType));
                CustomisedRule = "";
                this.RaisePropertyChangedEvent(() => this.Rule);
            }
        }

        private ObservableCollection<object> _conditionItemsSource;
        public ObservableCollection<object> ConditionItemsSource
        {
            get { return _conditionItemsSource; }
            set
            {
                _conditionItemsSource = value;
                this.RaisePropertyChangedEvent(() => this.ConditionItemsSource);
            }
        }

        private string _customisedRule;
        public string CustomisedRule
        {
            get { return _customisedRule; }
            set
            {
                _customisedRule = value;
                this.RaisePropertyChangedEvent(() => this.CustomisedRule);
            }
        }

        private object _condition;
        public object Condition
        {
            get { return _condition; }
            set
            {
                _condition = value;
                this.RaisePropertyChangedEvent(() => this.Condition);
            }
        }

        private object _andOrValue;
        public object AndOrValue
        {
            get { return _andOrValue; }
            set
            {
                _andOrValue = value;
                this.RaisePropertyChangedEvent(() => this.AndOrValue);
            }
        }

        private ObservableCollection<object> _andOrValueItemsSource;
        public ObservableCollection<object> AndOrValueItemsSource
        {
            get { return _andOrValueItemsSource; }
            set
            {
                _andOrValueItemsSource = value;
                this.RaisePropertyChangedEvent(() => this.AndOrValueItemsSource);
            }
        }
    }

    public enum ItemSources
    {
        TagName,
        TagType,
        DataType
    }

    public interface IAndOrItemBase
    {
        AndOr AndOrType
        {
            get;
            set;
        }
        string DisplayValue
        {
            get;
            set;
        }
    }

    public class conAndOrItemBase : IAndOrItemBase
    {
        private string _displayValue;

        public AndOr AndOrType
        {
            get;
            set;
        }

        /// <summary>
        /// Rule 的display value 
        /// </summary>
        public string DisplayValue
        {
            get { return _displayValue; }
            set
            {
                _displayValue = value;
                OnPropertyChanged(new PropertyChangedEventArgs("DisplayValue"));
            }
        }

        public override string ToString()
        {
            if (string.IsNullOrEmpty(DisplayValue))
            {
                return "";
            }
            return this.DisplayValue;
        }
        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }
    }
}
