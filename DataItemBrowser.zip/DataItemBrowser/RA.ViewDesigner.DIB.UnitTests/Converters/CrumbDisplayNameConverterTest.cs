﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for CrumbDisplayNameConverterTest and is intended
    ///to contain all CrumbDisplayNameConverterTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CrumbDisplayNameConverterTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for ConvertBack
        ///</summary>
        [TestMethod()]
		public void CrumbDisplayNameConverter_ConvertBack()
        {			
			CrumbDisplayNameConverter NameConverter = new CrumbDisplayNameConverter();
            object value = "initial";
		
			value = NameConverter.ConvertBack("[1,2,3]", typeof(string), null, null);
		
            Assert.IsNull(value);			
        }

        /// <summary>
        ///Conversion of a normal tag name
        ///</summary>
        [TestMethod()]
        public void CrumbDisplayNameConverter_TagName()
        {
			CrumbDisplayNameConverter NameConverter = new CrumbDisplayNameConverter();
			string Actual = NameConverter.Convert("TagName", typeof(string), null, null) as string;
			Assert.AreEqual(Actual, "TagName");
        }

		/// <summary>
		///Conversion of a 1 dim array
		///</summary>
		[TestMethod()]
		public void CrumbDisplayNameConverter_1DimArray()
        {
			CrumbDisplayNameConverter NameConverter = new CrumbDisplayNameConverter();
			string Actual = NameConverter.Convert("ArrayName[0]", typeof(string), null, null) as string;
			Assert.AreEqual("[0]", Actual);
        }

		/// <summary>
		///Conversion of a 2 dim array
		///</summary>
		[TestMethod()]
		public void CrumbDisplayNameConverter_2DimArray()
		{
			CrumbDisplayNameConverter NameConverter = new CrumbDisplayNameConverter();
			string Actual = NameConverter.Convert("ArrayName[1,2]", typeof(string), null, null) as string;
			Assert.AreEqual("[1,2]", Actual);
		}

		/// <summary>
		///Conversion of a 3 dim array
		///</summary>
		[TestMethod()]
		public void CrumbDisplayNameConverter_3DimArray()
		{
			CrumbDisplayNameConverter NameConverter = new CrumbDisplayNameConverter();
			string Actual = NameConverter.Convert("ArrayName[3,4,5]", typeof(string), null, null) as string;
			Assert.AreEqual("[3,4,5]", Actual);
		}
    }
}
