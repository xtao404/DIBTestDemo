﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Object;
using TagFilterControl.Tags;
using TagFilterControl.Utility;

namespace TagFilterControl.Controls.PreFilterManager.FilterInsatnce
{
    class FilterUnitFieldText : FilterUnitField
    {
        private Config config = Config.GetInstance();
        private XMLHelper xmlHelper = XMLHelper.GetInstance();

        public String Criteria { get; set; }

        public FilterUnitFieldText() { }

        protected override bool DoApply(object fieldValue, TagObjects tag)
        {
            String strValue = (fieldValue == null) ? String.Empty : fieldValue.ToString();

            Boolean filterResult = true, valueEmpty = String.IsNullOrEmpty(strValue);
            if (RuleType == RuleType.TagType)
            {
                if (this.Criteria.Equals("All", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
                else if (this.Criteria.Equals("Unused", StringComparison.OrdinalIgnoreCase))
                {
                    if (xmlHelper.UsedTags.Contains(tag.Name))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }

            switch (Condition)
            {
                case ConditionType.Equal:
                    filterResult = !valueEmpty && strValue.Equals(this.Criteria);
                    break;
                case ConditionType.UnEqual:
                    filterResult = valueEmpty || !strValue.Equals(this.Criteria);
                    break;
                case ConditionType.Contain:
                    filterResult = !valueEmpty && strValue.ToUpper(CultureInfo.InvariantCulture).Contains(this.Criteria.ToUpper(CultureInfo.InvariantCulture));
                    break;
                case ConditionType.Except:
                    filterResult = valueEmpty || !strValue.ToUpper(CultureInfo.InvariantCulture).Contains(this.Criteria.ToUpper(CultureInfo.InvariantCulture));
                    break;
            }
            return filterResult;
        }

        public override void Initialize(FilterItemBase filterItem)
        {
            base.Initialize(filterItem);
            this.Criteria = filterItem.Value.Value.ToString();

            if (config.DefaultTopNodes.Contains(this.FieldName))
            {
                if (!string.IsNullOrEmpty(this.Criteria))
                {
                    config.IsCheckedTags[this.Criteria] = new TagNode() { ParentName = this.FieldName };
                }
            }
            else if (this.FieldName.Equals("TagType"))
            {
                config.Usage = this.Criteria;
            }
        }
    }
}
