using System.ComponentModel;


namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// crumb that has text content, derived from ACrumb
    /// </summary>
    public class TextCrumb : ACrumbWithPathElement
    {
 

        /// <summary>
        /// Is the text crumb before a forward crumb
        /// </summary>
        bool _beforeForwardCrumb = false;
        public bool BeforeForwardCrumb
        {
            get { return _beforeForwardCrumb; }
            set
            {
                _beforeForwardCrumb = value;
                NotifyPropertyChanged("BeforeForwardCrumb");
                NotifyPropertyChanged("SupportsDropArrow");
            }
        }
        /// <summary>
        /// does this crumb support droparrow navigation
        /// </summary>
        public override bool SupportsDropArrow
        {
            get { return this.PathElement.HasChildren && !BeforeForwardCrumb; }
        }
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="pe">reference to its path element</param>
        public TextCrumb(IPathElement pe):base(pe) 
        {
            //_pathElement = pe;

        }

 
    }
}
