﻿using System.ComponentModel;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// IPathElement interface definition.
    /// </summary>
    public interface IPathElement: INotifyPropertyChanged
    {
        /// <summary>
        /// Property to get or set the path element's display name.
        /// </summary>
        string DisplayName
        {
            get;
            set;
        }

        /// <summary>
        /// Property to get or set if the path element is a container.
        /// </summary>
        bool IsContainer
        {
            get;
        }

        /// <summary>
        /// Property to get or set if the path element has children.
        /// </summary>
        bool HasChildren
        {
            get;
        }

        /// <summary>
        /// Property to get or set if the path element is active.
        /// </summary>
        bool IsActive
        {
            get;
            set;
        }

		/// <summary>
		/// Property to get or set the unique id for the underlying component.
		/// </summary>
        UUID ResourceId
        {
            get;            
        }

		/// <summary>
		/// Property to get or set the data item for the underlying component.
		/// </summary>
		DataItemBase DataItem
		{
			get;
			set;
		}
    }

}
