﻿namespace TagFilterControl.Common.Controls
{
    using System;
    using System.Windows.Controls;
    using System.Windows;
    using TagFilterControl.Common.Controls;

    public interface IPopupController
    {
        void Open<T>(params object[] args) where T : Page;

        void ResetTitle(string title);

        void Close();
    }

    public class PopupController
    {
        static ChildWindow instance;

        public static ChildWindow Instance
        {
            get { return instance ?? (instance = new ChildWindow()); }
        }

        public static void Open<T>(params object[] args) where T : Page
        {
            var page = Activator.CreateInstance(typeof(T), args) as Page;
            if (Instance.CloseButton != null)
            {
                Instance.CloseButton.ToolTip = "Close";
            }
            Instance.HeaderVisibility = Visibility.Visible;
            Instance.CloseButtonVisibility = Visibility.Hidden;
            Instance.Caption = page.Title ?? resetTitle;
            Instance.Content = new Frame { IsTabStop = false, Content = page };
            Instance.Show();
            resetTitle = null;
        }

        public static void Open<T>(bool showHeader, params object[] args) where T : Page
        {
            var page = Activator.CreateInstance(typeof(T), args) as Page;
            if (Instance.CloseButton != null)
            {
                Instance.CloseButton.ToolTip = "Close";
            }
            if (!showHeader)
            {
                Instance.HeaderVisibility = Visibility.Collapsed;
                Instance.CloseButtonVisibility = Visibility.Collapsed;
            }
            Instance.Caption = page.Title ?? resetTitle;
            Instance.Content = new Frame { IsTabStop = false, Content = page };
            Instance.Show();
            resetTitle = null;
        }

        static string resetTitle;

        public static void ResetTitle(string title)
        {
            resetTitle = title;
        }

        public static void Close()
        {
            Instance.Close();
            instance = null;
        }
    }
}