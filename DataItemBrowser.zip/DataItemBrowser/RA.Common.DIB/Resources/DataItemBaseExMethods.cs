﻿#region Copyright © 2011 Rockwell Automation Technologies, Inc. All Rights Reserved.

/**************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This software has been provided pursuant to a License Agreement containing 
   restrictions on its use. The  software contains valuable trade secrets and 
   proprietary information of Rockwell Automation and is protected by federal 
   copyright law. It may not be copied or distributed in any form or medium, 
   disclosed to third parties or used in any manner not provided for  in the 
   License Agreement except with prior written permission of Rockwell Automation.

 *************************************************************************************/

#endregion

using System;
using System.Collections.Generic;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// <see cref="DataItemBase"/> extension methods implementation.
    /// </summary>
    /// <remarks>
    /// <para>
    /// These extension methods add extended functionality to a <see cref="DataItemBase"/> type in a way that 
    /// makes the methods appear as natrual <c>extension</c> to the <see cref="DataItemBase"/> type. 
    /// </para>
    /// <para>
    /// The <see cref="DataItemBase"/> class is located in the <c>ct_query_bt</c> package in the <see cref="QuerAPI"/>
    /// assembly. The <see cref="DataItemBase"/> class and the <see cref="DataItemBaseExMethods"/>
    /// class are located in different assemblies 
    /// </para>
    /// </remarks>
    /// <author>ViewE Common Tag Team</author>
    [Serializable]
    public static class DataItemBaseExMethods
    {
        /// <summary>
        /// Provide the resource type UUID and cache the value in Object Dictionary so we dont have to keep converting from string to UUID
        /// </summary>
        /// <param name="source"></param>
        /// <returns></returns>
        public static UUID GetResourceTypeAsUUID(this DataItemBase source)
        {
            UUID existingID = source.GetObjectMapValue(DIBConstants.Common.ResourceType) as UUID;
            if (existingID != null) return existingID;

            UUID newId = ResourceBase.GuidStringToId(source.CommonResourceType);
            source.SetObjectMapValue(DIBConstants.Common.ResourceType, newId);

            return newId;
        }

        /// <summary>
        /// Returns true if two data items are equivalent.  The name and path property values
        /// are considered in the check, where names much match and locations will only need
        /// to match if they exist in both data items.
        /// </summary>
        /// <param name="thisItem">First DataItemBase to compare</param>
        /// <param name="otherItem">Second DataItemBase to compare</param>
        /// <returns>True if the dataItems match by name and location</returns>
        public static bool IsEquivalentTo(this DataItemBase thisItem, DataItemBase otherItem)
        {
            if (thisItem.ToString() == otherItem.ToString()) // Are names equal?
            {
                //Check for data item paths being equal (true if path is not set on at least one data item)
                string thisPath = thisItem.CommonLocation;
                string otherPath = otherItem.CommonLocation;
                return thisPath == null || otherPath == null || thisPath == otherPath;
            }

            return false;
        }


        ///// <summary>
        ///// Provide the common UUID and cache the value in Object Dictionary so we dont have to keep converting from string to UUID
        ///// </summary>
        ///// <param name="source"></param>
        ///// <returns></returns>
        //public static UUID GetCommonIDAsUUID(this DataItemBase source)
        //{
        //    UUID existingUUID = source.GetObjectMapValue(DIBConstants.Common.ID) as UUID;
        //    if (existingUUID != null) return existingUUID;

        //    UUID newId = ResourceBase.GuidStringToId(source.CommonID);
        //    source.SetObjectMapValue(DIBConstants.Common.ID, newId);

        //    return newId;
        //}
    }
}