/*************************************************************************************
                                                                     
   ViewE SearchStatements contains ISearchStatement, FilterStatement and SearchStatemnt classes                                                                     
   Copyright � 2009-2016 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace RockwellAutomation.UI.CommonControls
{



    /// <summary>
    /// statement interface for searching and filtering
    /// </summary>
    public interface ISearchStatement
    {

        /// <summary>
        /// operator property
        /// </summary>
        ParserToken OperatorToken
        {
            get;
            set;
        }

        /// <summary>
        /// does this dataitem successfully meet the criteria of this statement?
        /// </summary>        
        /// <param name="item"> </param>
        /// <param name="getFieldValue"> </param>
        /// <returns></returns>
        bool IsMatch(Object item, GetFieldValue getFieldValue);



        /// <summary>
        /// gets the string representation of this statement
        /// </summary>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate")]
        string GetSearchString();

    }


    /// <summary>
    /// This class represents one filter statement which will be followed by an operator for example
    ///    name:auto  - find all items which have text auto in its name and no operator
    ///    or datatype:INT name:auto - in this case there are 2 statemnets the first one will find all 
    ///    items where the datatype contains INT and its operator is AND and the second statement 
    ///    will find all items where the name contains auto, operator is null
    /// </summary>
    public class FilterStatement : ISearchStatement
    {
        public FilterStatement()
        {
            OperatorToken = null;
        }

        /// <summary>
        /// constructor
        /// </summary>        
        /// <param name="name">The name of the filter statement. Ex. "dt:" </param>
        /// <param name="value">The string value of the search statement</param>
        /// <param name="isExactMatch">Whether or not the value should be an exact match</param>
        /// <param name="logic">The stetement operator logic Ex. AND</param>
        public FilterStatement(string name, string value, bool isExactMatch, SearchFilterDefinition.StatementLogic logic)
        {
            this.FilterType = new ParserToken(SearchFilterParser.FilterOperatorGroup, name, 0, false);
            this.FilterValues.Add(new ParserToken(SearchFilterParser.ValueGroup, value, 0, isExactMatch));
            string sLogic = string.Empty;
            if (logic != SearchFilterDefinition.StatementLogic.NONE)
                sLogic = logic.ToString();
            this.OperatorToken = new ParserToken(SearchFilterParser.BaseOperatorGroup, sLogic, 0, false);
        }

        /// <summary>
        /// filter type property (string followed by "=")
        /// </summary>
        private ParserToken _filterType = null;
        public ParserToken FilterType
        {
            get { return _filterType; }
            internal set { _filterType = value; }
        }
        /// <summary>
        /// the fitler values for a filter type collection property
        /// </summary>
        private Collection<ParserToken> _filterValues = new Collection<ParserToken>();

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly",Justification = "SearchFilterParser sets the value")]
        public Collection<ParserToken> FilterValues
        {
            get { return _filterValues; }
            set { _filterValues = value; }
        }

        public ParserToken OperatorToken { get; set; }

        /// <summary>
        /// does this dataitem successfully meet the criteria of this statement?
        /// </summary>        
        /// <param name="item"> the item to match</param>
        /// <param name="getFieldValue">callback method to get the value </param>
        /// <returns>true if it is a match, false otherwise</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:Validate arguments of public methods", MessageId = "1",Justification="getFieldValue is validated")]
        public bool IsMatch(Object item, GetFieldValue getFieldValue)
        {
            //find the fieldName for this filter
            string fieldName = String.Empty;
            foreach (FilterType filterType in SearchFilterDefinition.FilterTypes)
            {
                if (string.Equals(this.FilterType.Value, filterType.Operator, StringComparison.CurrentCultureIgnoreCase) ||
                    string.Equals(this.FilterType.Value, filterType.Shortcut, StringComparison.CurrentCultureIgnoreCase)) //B-12775: also check shortcuts
                {
                    fieldName = filterType.Name;
                    break;
                }
            }

            //check validity of the value
            object value = getFieldValue(fieldName, item);
            if ((value == null) || (value == DBNull.Value))
                return false;

            string fieldValue = (string)value;
            bool result = false;
            //always initialize this to OR operation so first value is initialized correctly
            bool andOperation = false;
            //processed the first value
            bool firstValue = false;
            //compare the value with each filter value in this statement
            foreach (ParserToken filterValue in this.FilterValues)
            {
                if (filterValue.ParseGroup == SearchFilterParser.BaseOperatorGroup)
                {
                    //determine if the next value match should be ANDed or ORed with the previous value match
                    if (filterValue.Value.Equals(SearchFilterParser.AndOperator))
                        andOperation = true;
                    else
                        andOperation = false;
                }
                //Skip whitespace tokens
                else if (filterValue.ParseGroup != SearchFilterParser.WhiteSpaceGroup)
                {
                    //if this is the first value just set the result
                    if (firstValue)
                    {
                        result = filterValue.IsValueMatch(fieldValue, fieldName);
                        firstValue = false;
                    }
                    //otherwise combine it with the previous value
                    else
                    {
                        //check if this value matches the dataitem value
                        if (andOperation)
                            result &= filterValue.IsValueMatch(fieldValue, fieldName);
                        else
                            result |= filterValue.IsValueMatch(fieldValue, fieldName);
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// get the search string for this search statement
        /// </summary>
        /// <returns></returns>
        public string GetSearchString()
        {

            string sLogic = string.Empty;


            string values = string.Empty;
            if (this.FilterValues.Count > 1)
            {
                if (this.OperatorToken != null)
                {
                    sLogic = this.OperatorToken.Value.ToString();

                }

                values = "(";
                foreach (ParserToken sValue in this.FilterValues)
                {
                    string finalValue = sValue.Value;
                    if (sValue.ExactMatch)
                        finalValue = "\"" + finalValue + "\"";
                    values += finalValue + SearchFilterParser.OrOperator;
                }
            }
            else
            {
                values = this.FilterValues[0].Value;
                if (this.FilterValues[0].ExactMatch)
                    values = "\"" + values + "\"";
            }

            return this.FilterType.Value + values + sLogic;
        }

        public override String ToString()
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine("\t\t FilterStatement: ");
            strBuilder.AppendLine("\t\t\t OperatorToken: " + OperatorToken);
            strBuilder.AppendLine("\t\t\t FilterType: " + FilterType);
            strBuilder.AppendLine("\t\t\t FilterValues: ");
            foreach (ParserToken tItem in FilterValues)
            {
                strBuilder.Append("\t\t\t " + tItem.ToString());
            }
            return strBuilder.ToString();
        }

    }

    /// <summary>
    /// This class represents one search statement which is followed by an operator for example
    ///    auto  - find all items which have text auto in any field and no operator
    ///    or INT auto - in this case there are 2 statemnets the first one will find all 
    ///    items where one of the fields containing INT and its operator is AND and the second statement 
    ///    will find all items where one of the fields contain auto, operator is null
    /// </summary>
    public class SearchStatement : ISearchStatement
    {
        public SearchStatement()
        {
            OperatorToken = null;
            SearchValue = null;
        }

        public SearchStatement(string value, bool isExactMatch, SearchFilterDefinition.StatementLogic logic)
        {
            this.SearchValue = new ParserToken(SearchFilterParser.ValueGroup, value, 0, isExactMatch);
            string sLogic = string.Empty;
            if (logic != SearchFilterDefinition.StatementLogic.NONE)
                sLogic = logic.ToString();
            this.OperatorToken = new ParserToken(SearchFilterParser.BaseOperatorGroup, sLogic, 0, false);
        }

        public ParserToken SearchValue { get; set; }

        public ParserToken OperatorToken { get; set; }

        /// <summary>
        /// does this dataitem successfully meet the criteria of this statement?
        /// </summary>
        /// <param name="obj">dataitem</param>
        /// <param name="getFieldValue"></param>
        /// <returns>true if it is a match, false otherwise</returns>
        public bool IsMatch(Object item, GetFieldValue getFieldValue)
        {
            string fieldName = String.Empty;
            bool result = false;
            //check with all available filter types (all columns avaiable)
            foreach (FilterType filterType in SearchFilterDefinition.FilterTypes)
            {
                //only check filter type if it is searchable
                if (filterType.Searchable == false)
                    continue;

                fieldName = filterType.Name;
                //check validity of the value
                object value = getFieldValue(fieldName, item);
                if ((value == null) || (value == DBNull.Value))
                    return false;
                string fieldValue = (string)value;
                if (this.SearchValue.IsValueMatch(fieldValue, fieldName))
                {
                    result = true;
                    break;
                }

            }
            return result;
        }

        /// <summary>
        /// get the search string for this search statement
        /// </summary>
        /// <returns></returns>
        public string GetSearchString()
        {

            string sLogic = string.Empty;
            if (this.OperatorToken != null)
            {
                sLogic = this.OperatorToken.Value.ToString();

            }

            string value = this.SearchValue.Value;
            if (this.SearchValue.ExactMatch)
                value = "\"" + value + "\"";
            return value + sLogic;
        }

        public override String ToString()
        {
            StringBuilder strBuilder = new StringBuilder();
            strBuilder.AppendLine("\t\t SearchStatement");
            strBuilder.AppendLine("\t\t\t SearchValue: '" + SearchValue);
            strBuilder.AppendLine("\t\t\t OperatorToken: '" + OperatorToken);
            return strBuilder.ToString();
        }

    }

}


