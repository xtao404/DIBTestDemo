﻿/* ****************************************************************************
*
*  Copyright 2011 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/
using System;
using System.Windows.Data;
using System.Windows;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;

namespace RockwellAutomation.UI.CommonControls.DeviceImage
{

    /// <summary>
    /// Determines whether the state image is visible based on the image and the state of the controller
    /// if the string is empty then collapse the indicator
    /// </summary>
    [ValueConversion(typeof(string), typeof(Visibility))]
    public class ImageNameToVisibilityConverter : IValueConverter
    {
        /// <summary>
        /// Converter convert method
        /// </summary>
        /// <param name="value">Enum_ImageState</param>
        /// <param name="targetType">string</param>
        /// <param name="parameter">Image Name</param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //value or param is empty then collapse  image
            if (string.IsNullOrEmpty(value.ToString()) || string.IsNullOrEmpty(parameter.ToString()))
                return Visibility.Collapsed;

            EnumImageState state = (EnumImageState)Enum.Parse(typeof(EnumImageState), value.ToString());
            EnumImageState image = (EnumImageState)Enum.Parse(typeof(EnumImageState), parameter.ToString());
            //if the image matches the state then it should be visible
            if (image == state)
                return Visibility.Visible;

            return Visibility.Collapsed;


        }

        /// <summary>
        /// converter convert back method (not implemented)
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            // We never intend to call this
            return null;
        }
    }

    /// <summary>
    /// Determines whether the controller is visible based on the HideController property and the state of the controller
    /// if the string is empty then collapse the indicator
    /// </summary>
    [ValueConversion(typeof(bool), typeof(Visibility))]
    public class hideControllerVisibilityConverter : IValueConverter
    {
        /// <summary>
        /// Converter convert method
        /// </summary>
        /// <param name="value">HideControler property</param>
        /// <param name="targetType">bool</param>
        /// <param name="parameter">Image Name</param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            bool hideController = (bool)value;

            DisplayTypeEnum displayType = (DisplayTypeEnum)Enum.Parse(typeof(DisplayTypeEnum), parameter.ToString());
           
            //is it controller and status element
            if (displayType == DisplayTypeEnum.ControllerAndStatus)
            {
                //if we are hiding the controller, then hide this element
                if (hideController)
                    return Visibility.Collapsed;
                
                return Visibility.Visible;
            }
            //is it the display status only element
            else if (displayType == DisplayTypeEnum.StatusOnly)
            {
                //if we are hiding the controller, then show this element
                if (hideController)
                    return Visibility.Visible;
                return Visibility.Collapsed ;
            }
            //default
            return Visibility.Collapsed;


        }

        /// <summary>
        /// converter convert back method (not implemented)
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            // We never intend to call this
            return null;
        }
    }

}
