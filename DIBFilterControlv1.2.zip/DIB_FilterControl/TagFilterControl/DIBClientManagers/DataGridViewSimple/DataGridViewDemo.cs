﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;
using System.Xml;
using TagFilterControl.Object;
using TagFilterControl.Utility;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.Views;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using TagFilterControl.Controls;
using TagFilterControl.Controls.PreFilterManager.FilterInsatnce;
using TagFilterControl.Common;
using TagFilterControl.Service;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using System.Globalization;

namespace TagFilterControl.DIBClientManagers.DataGridViewSimple
{
    public class DataGridViewDemo : DIBClientManager
    {
        private string baseAssemblyLocation = string.Empty;
        private string baseAssemblyURIString = string.Empty;
        public const string TagObject = "TagObject";
        public const string DataViewType = "DataViewType";
        public const string DataGrid_VIEW = "GenericDIBItemView";
        public const string TREE_VIEW = "none";
        public const string DATATYPE_Controller = "Controller";
        public const string DATATYPE_Programs = "Programs";
        public const string DATATYPE_Program = "Program";
        public const string DATATYPE_ProgramTags = "ProgramTags";
        public const string DATATYPE_ControllerTags = "ControllerTags";
        public const string DATATYPE_Tag = "Tag";
        private object objLock = new object();

        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private ACDHelper acdHelper = ACDHelper.GetInstance();
        private Config config = Config.GetInstance();
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();

        public DataItemBase ParentDataItemBase { get; set; }
        private FilterManager filterManager;

        public DataGridViewDemo()
        {
            config.FilterManager = filterManager = new FilterManager();
            ServiceInvoker<ITagService>
               .Invoke(s => s.LoadFilterByIdAndInitializeFilterItem(config.SelectFilterProfile, filterManager))
               .Callback(result => { })
               .Finally(() => { })
               .Execute();
        }

        public override void InitializeDIBControlOnStartup(DataItemBrowser dataItemBrowserControl, StringBuilder logger)
        {
            baseAssemblyLocation = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            baseAssemblyURIString = "file:\\\\" + baseAssemblyLocation;
        }

        public DataGridViewModel GridVM { get; set; }

        override public bool ShouldCloseOnSelect()
        {
            return false;
        }

        override public string GetBreadCrumbCacheKeyFor(DataItemBase dataItem)
        {
            if (dataItem == null) return DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW;
            return dataItem.CommonLocation;
        }

        public override DIBGridViewModel createDIBGridViewModel(DataItemBrowserViewModel dibVM)
        {
            GridVM = new DataGridViewModel(dibVM);
            return GridVM;

        }

        public override Stream GetGridColumnMetaData()
        {
            string fileName = "GridColumnsInfo.xml";
            string path = string.Format("{0}\\DIBClientManagers\\DataGridViewSimple\\{1}", Environment.CurrentDirectory, fileName);
            Stream xmlStream = File.OpenRead(path);
            return xmlStream;
        }

        public override ObservableCollection<FilterType> GetFilterTypes()
        {
            ObservableCollection<FilterType> filterTypes = base.GetFilterTypes();
            filterTypes.Add(new FilterType("HWT", false));
            return filterTypes;
        }

        public override bool ShouldSearchViaQuery(RockwellAutomation.UI.Models.Path path)
        {
            if (path == null || path.Items.Count < 1) return false;
            if (path.Last.DataItem != null && path.Last.DataItem.GetStringMapValue("HWT").ToLower().Equals("controllertags")) return true;
            return false;
        }

        public override void SearchFor(QueryConditionConfig queryConditionConfig, DIBQueryCache dibQueryCache)
        {
            if (queryConditionConfig.GetQueryConditionItems.Count == 1 && queryConditionConfig.GetQueryConditionItems[0].GetIdentifier == "DisplayName")
            {
                string searchString = queryConditionConfig.GetQueryConditionItems[0].GetValue;
                GetFilterControllerTags(dibQueryCache, "ControllerTags", searchString);
                return;
            }
        }

        public override string GetResourceTypeString(DataItemBase dataItem)
        {
            if (dataItem == null)
            {
                return TREE_VIEW;
            }

            if (dataItem.GetStringMapValue("PeopleAtRockwell.ViewType").Equals(TREE_VIEW))
            {
                return TREE_VIEW;
            }

            if (dataItem.GetStringMapValue("PeopleAtRockwell.ViewType").Equals(DataGrid_VIEW))
            {
                return DataGrid_VIEW;
            }
            return TREE_VIEW;
        }

        public override IDIBDataViewType GetDataViewTypeFor(string resourceType)
        {
            if (resourceType == DataGrid_VIEW) return new DIBDataViewTypeDataGrid();
            if (resourceType == ClientDataServices.SearchTags) return new DIBDataViewTypeSearchGrid();
            return new DIBDataViewTypeTreeView();
        }

        public override void DrillInFor(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            lock (this.objLock)
            {
                queryCache.DataItems.Clear();
                this.ParentDataItemBase = dataItemToDrillInto;
                if (dataItemToDrillInto == null)
                {
                    DrillIntoFirstTreeView(queryCache);
                    return;
                }

                switch (dataItemToDrillInto.GetStringMapValue("HWT"))
                {
                    case DATATYPE_ControllerTags:
                        DrillIntoTagsListView(dataItemToDrillInto, queryCache);
                        break;
                    case DATATYPE_Programs:
                        DrillIntoProgramsTreeView(dataItemToDrillInto, queryCache);
                        break;
                    case DATATYPE_Program:
                        DrillIntoProTagsListView(dataItemToDrillInto, queryCache);
                        break;
                    case DATATYPE_Tag:
                        DrillIntoTagListView(dataItemToDrillInto, queryCache);
                        break;
                    default:
                        break;
                }
            }
        }

        private DataItemBase CreateItemBase(
            String name,
            String datatype,
            String viewType,
            String treeViewId,
            String treeViewParentId,
            String tooltip,
            String automationId,
            String automationName,
            String imagePath,
            String supportsDrillIn,
            String isExpanded,
            String isInitHighlighted,
            String fontWeight,
            String supportsSelection,
            String description = "",
            String hengweitao = "",
            String tagType = "",
            TagObjects tempTag = null,
            String dataViewType = "")
        {
            DataItemBase dataItem = new DataItemBase();
            if (!String.IsNullOrWhiteSpace(name)) dataItem.CommonName = name;
            if (!String.IsNullOrWhiteSpace(description)) dataItem.CommonDescription = description;
            if (!String.IsNullOrWhiteSpace(datatype)) dataItem.CommonDataType = datatype;
            if (!String.IsNullOrWhiteSpace(viewType)) dataItem.SetStringMapValue("PeopleAtRockwell.ViewType", viewType);
            if (!String.IsNullOrWhiteSpace(treeViewId)) dataItem.GUITreeViewID = treeViewId;
            if (!String.IsNullOrWhiteSpace(treeViewParentId)) dataItem.GUITreeViewParentID = treeViewParentId;
            if (!String.IsNullOrWhiteSpace(tooltip)) dataItem.GUIToolTip = tooltip;
            if (!String.IsNullOrWhiteSpace(automationId)) dataItem.GUIAutomationID = automationId;
            if (!String.IsNullOrWhiteSpace(automationName)) dataItem.GUIAutomationName = automationName;
            if (!String.IsNullOrWhiteSpace(imagePath)) dataItem.GUISmallImagePath = imagePath;
            if (!String.IsNullOrWhiteSpace(supportsDrillIn)) dataItem.GUISupportsDrillIn = supportsDrillIn;
            if (!String.IsNullOrWhiteSpace(isExpanded)) dataItem.GUIIsExpanded = isExpanded;
            if (!String.IsNullOrWhiteSpace(isInitHighlighted)) dataItem.GUIIsInitiallyHighlighted = isInitHighlighted;
            if (!String.IsNullOrWhiteSpace(fontWeight)) dataItem.GUITextFontWeight = fontWeight;
            if (!String.IsNullOrWhiteSpace(supportsSelection)) dataItem.GUISupportsSelection = supportsSelection;
            if (!String.IsNullOrWhiteSpace(hengweitao)) dataItem.SetStringMapValue("HWT", hengweitao);
            if (!String.IsNullOrWhiteSpace(tagType)) dataItem.SetStringMapValue("TagType", tagType);
            if (tempTag != null)
            {
                dataItem.SetObjectMapValue(TagObject, tempTag);
            }
            if (!String.IsNullOrWhiteSpace(dataViewType)) dataItem.SetStringMapValue(DataViewType, dataViewType);
            return dataItem;
        }

        private void DrillIntoFirstTreeView(DIBQueryCache queryCache)
        {
            if (!string.IsNullOrEmpty(xmlHelper.ControllerName))
            {
                bool isCheckControllerTags = xmlHelper.ControllerSubChildrensKeyValuePair[xmlHelper.ControllerName][0].IsCheckedControlTags;
                bool isCheckProTags = xmlHelper.ControllerSubChildrensKeyValuePair[xmlHelper.ControllerName][1].IsCheckedProTags;

                if (isCheckControllerTags && isCheckProTags)
                {
                    foreach (BaseAttribute item in xmlHelper.ControllerSubChildrensKeyValuePair[xmlHelper.ControllerName])
                    {
                        GetSubChildren(item, queryCache);
                    }
                }
                else if (isCheckControllerTags)
                {
                    BaseAttribute item = xmlHelper.ControllerSubChildrensKeyValuePair[xmlHelper.ControllerName][0];
                    GetSubChildren(item, queryCache);
                }
                else if (isCheckProTags)
                {
                    BaseAttribute item = xmlHelper.ControllerSubChildrensKeyValuePair[xmlHelper.ControllerName][1];
                    GetSubChildren(item, queryCache);
                }
                else
                {
                    //nothing
                }
            }
        }

        private void GetSubChildren(BaseAttribute item, DIBQueryCache queryCache)
        {
            DataItemBase dataItem = this.CreateItemBase(
                  name: item.Name,
                  datatype: item.Name.Equals("ControllerTags") ? DATATYPE_ControllerTags : DATATYPE_Programs,
                  viewType: item.Name.Equals("ControllerTags") ? DataGrid_VIEW : TREE_VIEW,
                  treeViewId: Guid.NewGuid().ToString(),
                  treeViewParentId: string.Empty,
                  tooltip: string.Format("This is {0}", item.Name),
                  automationId: string.Format("{0}_Node", item.Name),
                  automationName: string.Format("{0}_Node", item.Name),
                  imagePath: this.baseAssemblyURIString + (item.Name.Equals("ControllerTags") ? "\\Images\\16by16\\TagsAndProps.png" : "\\Images\\16by16\\Programs.png"),
                  supportsDrillIn: "True",
                  isExpanded: "True",
                  isInitHighlighted: "True",
                  fontWeight: "Bold",
                  supportsSelection: "true",
                  description: "",
                  hengweitao: item.Name.Equals("ControllerTags") ? DATATYPE_ControllerTags : DATATYPE_Programs,
                  tagType: "",
                  tempTag: null,
                  dataViewType: DataViewTypes.TreeView.ToString());

            if (queryCache != null)
            {
                queryCache.AddDataItem(dataItem);
            }
        }

        private void DrillIntoProgramsTreeView(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            DataItemBase programs = this.CreateItemBase(
               name: "Programs",
               datatype: DATATYPE_ProgramTags,
               viewType: TREE_VIEW,
               treeViewId: Guid.NewGuid().ToString(),
               treeViewParentId: string.Empty,
               tooltip: "This is programs",
               automationId: "programs_Node",
               automationName: "programs_Node",
               imagePath: this.baseAssemblyURIString + "\\Images\\16by16\\Programs.png",
               supportsDrillIn: "False",
               isExpanded: "True",
               isInitHighlighted: "True",
               fontWeight: "Bold",
               supportsSelection: "false",
               description: "",
               hengweitao: DATATYPE_ProgramTags,
               tagType: "",
               tempTag: null,
               dataViewType: DataViewTypes.TreeView.ToString());
            queryCache.AddDataItem(programs);

            foreach (string program in xmlHelper.ProgramTagsKeyValuePair.Keys)
            {
                DataItemBase dataItem = this.CreateItemBase(
                      name: program,
                      datatype: DATATYPE_Program,
                      viewType: DataGrid_VIEW,
                      treeViewId: Guid.NewGuid().ToString(),
                      treeViewParentId: programs.GUITreeViewID,
                      tooltip: string.Format("This is {0}", program),
                      automationId: string.Format("{0}_Node", program),
                      automationName: string.Format("{0}_Node", program),
                      imagePath: this.baseAssemblyURIString + "\\Images\\16by16\\Programs.png",
                      supportsDrillIn: "True",
                      isExpanded: "True",
                      isInitHighlighted: "True",
                      fontWeight: "Bold",
                      supportsSelection: "true",
                      description: "",
                      hengweitao: DATATYPE_Program,
                      tagType: "",
                      tempTag: null,
                      dataViewType: DataViewTypes.TreeView.ToString());
                queryCache.AddDataItem(dataItem);
            }
        }

        private FilterResult ApplyFilter(TagObjects tag, FilterManager filterManager)
        {
            bool result = filterManager.ApplyFilters(tag);
            return new FilterResult() { IsFiltered = !result, Reason = filterManager.Reason };
        }

        private void DrillIntoTagsListView(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            foreach (TagObjects tag in xmlHelper.ControllerTags)
            {
                FilterResult filterResult = ApplyFilter(tag, filterManager);
                if (filterResult.IsFiltered)
                {
                    continue;
                }

                if (!config.IsFirstToFilterDIBControl)
                {
                    if (FilterTag(tag))
                    {
                        continue;
                    }
                }

                string guid = string.Empty;
                bool drillIn = tag.DataValueMembers.Count > 0;
                DataItemBase dataItem = this.CreateItemBase(
                      name: tag.Name,
                      datatype: tag.DataType.ToString(),
                      viewType: DataGrid_VIEW,
                      treeViewId: guid = Guid.NewGuid().ToString(),
                      treeViewParentId: string.Empty,
                      tooltip: string.Format("This is {0}", tag.Name),
                      automationId: string.Format("{0}_Node", tag.Name),
                      automationName: string.Format("{0}_Node", tag.Name),
                      imagePath: string.Empty,
                      supportsDrillIn: drillIn.ToString(),
                      isExpanded: "True",
                      isInitHighlighted: string.Empty,
                      fontWeight: string.Empty,
                      supportsSelection: "True",
                      description: string.Format("This is {0}", tag.Name),
                      hengweitao: DATATYPE_Tag,
                      tagType: tag.TagType.ToString(),
                      tempTag: tag,
                      dataViewType: DataViewTypes.GridView.ToString());
                queryCache.AddDataItem(dataItem);
            }
            config.IsFirstToFilterDIBControl = false;
        }

        private void DrillIntoProTagsListView(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            foreach (string program in xmlHelper.ProgramTagsKeyValuePair.Keys)
            {
                foreach (TagObjects tag in xmlHelper.ProgramTagsKeyValuePair[program])
                {
                    FilterResult filterResult = ApplyFilter(tag, filterManager);
                    if (filterResult.IsFiltered)
                    {
                        continue;
                    }

                    if (!config.IsFirstToFilterDIBControl)
                    {
                        if (FilterTag(tag))
                        {
                            continue;
                        }
                    }

                    string guid = string.Empty;
                    bool drillIn = tag.DataValueMembers.Count > 0;
                    DataItemBase dataItem = this.CreateItemBase(
                      name: tag.Name,
                      datatype: tag.DataType.ToString(),
                      viewType: DataGrid_VIEW,
                      treeViewId: guid = Guid.NewGuid().ToString(),
                      treeViewParentId: string.Empty,
                      tooltip: string.Format("This is {0}", tag.Name),
                      automationId: string.Format("{0}_Node", tag.Name),
                      automationName: string.Format("{0}_Node", tag.Name),
                      imagePath: string.Empty,
                      supportsDrillIn: drillIn.ToString(),
                      isExpanded: string.Empty,
                      isInitHighlighted: string.Empty,
                      fontWeight: string.Empty,
                      supportsSelection: "true",
                      description: string.Format("This is {0}", tag.Name),
                      hengweitao: DATATYPE_Tag,
                      tagType: tag.TagType.ToString(),
                      tempTag: tag,
                      dataViewType: DataViewTypes.GridView.ToString());
                    queryCache.AddDataItem(dataItem);
                }
            }
            config.IsFirstToFilterDIBControl = false;
        }

        private void GetFilterControllerTags(DIBQueryCache queryCache, string controllerTags, string searchString)
        {
            foreach (TagObjects tag in xmlHelper.ControllerTags)
            {
                if (!string.IsNullOrEmpty(searchString) && (tag.Name.Contains(searchString.ToLower()) || tag.Name.Contains(searchString.ToUpper())))
                {
                    FilterResult filterResult = ApplyFilter(tag, filterManager);
                    if (filterResult.IsFiltered)
                    {
                        continue;
                    }

                    if (!config.IsFirstToFilterDIBControl)
                    {
                        if (FilterTag(tag))
                        {
                            continue;
                        }
                    }

                    string guid = string.Empty;
                    bool drillIn = tag.DataValueMembers.Count > 0;
                    DataItemBase dataItem = this.CreateItemBase(
                                        name: tag.Name,
                                        datatype: tag.DataType.ToString(),
                                        viewType: DataGrid_VIEW,
                                        treeViewId: guid = Guid.NewGuid().ToString(),
                                        treeViewParentId: string.Empty,
                                        tooltip: string.Format("This is {0}", tag.Name),
                                        automationId: string.Format("{0}_Node", tag.Name),
                                        automationName: string.Format("{0}_Node", tag.Name),
                                        imagePath: string.Empty,
                                        supportsDrillIn: drillIn.ToString(),
                                        isExpanded: string.Empty,
                                        isInitHighlighted: string.Empty,
                                        fontWeight: string.Empty,
                                        supportsSelection: "true",
                                        description: string.Format("This is {0}", tag.Name),
                                        hengweitao: DATATYPE_Tag,
                                        tagType: tag.TagType.ToString(),
                                        tempTag: tag,
                                        dataViewType: DataViewTypes.GridView.ToString());
                    queryCache.AddDataItem(dataItem);
                }
            }
        }

        private void DrillIntoTagListView(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            TagObjects tag = dataItemToDrillInto.GetObjectMapValue(TagObject) as TagObjects;
            if (tag != null && tag.DataValueMembers.Count > 0)
            {
                foreach (DataValueMember item in tag.DataValueMembers)
                {
                    FilterResult filterResult = ApplyFilter(tag, filterManager);
                    if (filterResult.IsFiltered)
                    {
                        continue;
                    }

                    if (!config.IsFirstToFilterDIBControl)
                    {
                        if (FilterTag(tag))
                        {
                            continue;
                        }
                    }

                    DataItemBase subDataItem = this.CreateItemBase(
                         name: string.Format("{0}.{1}", tag.Name, item.Name),
                         datatype: item.DataType.ToString(),
                         viewType: DataGrid_VIEW,
                         treeViewId: Guid.NewGuid().ToString(),
                         treeViewParentId: string.Empty,
                         tooltip: string.Format("This is {0}", string.Format("{0}.{1}", tag.Name, item.Name)),
                         automationId: string.Format("{0}_Node", string.Format("{0}.{1}", tag.Name, item.Name)),
                         automationName: string.Format("{0}_Node", string.Format("{0}.{1}", tag.Name, item.Name)),
                         imagePath: string.Empty,
                         supportsDrillIn: "False",
                         isExpanded: "True",
                         isInitHighlighted: string.Empty,
                         fontWeight: string.Empty,
                         supportsSelection: "True",
                         description: string.Format("This is {0}", string.Format("{0}.{1}", tag.Name, item.Name)),
                         hengweitao: "SubTag",
                         tagType: item.TagType.ToString(),
                         tempTag: null,
                         dataViewType: DataViewTypes.GridView.ToString());
                    queryCache.AddDataItem(subDataItem);
                }
            }
        }

        private bool FilterTag(TagObjects tag)
        {
            if (!string.IsNullOrEmpty(config.Usage))
            {
                if (config.Usage.Equals(TagType.all.ToString(), StringComparison.OrdinalIgnoreCase)) { }
                else if (config.Usage.Equals(TagType.Unused.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    if (xmlHelper.UsedTags.Contains(tag.Name))
                    {
                        return true;
                    }
                }
                else if (!tag.TagType.ToString().Equals(config.Usage))
                {
                    return true;
                }
            }

            if (config.IsCheckedTags.Count > 0)
            {
                if (!config.IsCheckedTags.Keys.Contains(tag.DataType.ToString()))
                {
                    return true;
                }
            }

            if (config.ACMCustomPropertiesTagOwnersFilter.Count > 0)
            {
                if (tag.Owners.Count > 0)
                {
                    bool flag = true;
                    foreach (string id in tag.Owners.Keys)
                    {
                        if (config.ACMCustomPropertiesTagOwnersFilter.Keys.Contains(id))
                        {
                            flag = false;
                        }
                    }
                    return flag;
                }
                else
                {
                    return true;
                }
            }
            return false;
        }
    }

    public enum DataViewTypes
    {
        TreeView,
        ListView,
        GridView
    }
}
