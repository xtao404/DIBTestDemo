﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using RockwellAutomation.Client.Services.Query.AbstractItem;


namespace RockwellAutomation.UI
{
    /// <summary>
    /// Folder of Programs PathElement
    /// </summary>
    public class ProgramsPathElement : ActiveContrainerWithChildrenPathElement
    {
        
        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public ProgramsPathElement(DataItemBase dataItem, string displayName)
                :base(dataItem, displayName)
        {
        }

        #endregion

    }
}
