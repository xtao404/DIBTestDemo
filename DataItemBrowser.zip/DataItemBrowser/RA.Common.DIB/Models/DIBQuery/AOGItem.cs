﻿/* ****************************************************************************
*
*  Copyright © 2016 Rockwell Automation Technologies, Inc. All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RockwellAutomation.UI.Models.DIBQuery
{
    /// <summary>
    /// Represents an AOG property
    /// </summary>
    public class AOGItem
    {
        /// <summary>
        /// Gets or sets the PropertyName
        /// </summary>
        public string ItemName
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Property Discription
        /// </summary>
        public string Description
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the Datatype for the property
        /// </summary>

        public string DataType
        {
            get;
            set;
        }
    }
}
