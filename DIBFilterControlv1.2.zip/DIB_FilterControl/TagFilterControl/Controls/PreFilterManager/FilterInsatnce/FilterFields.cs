﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Object;
using TagFilterControl.Tags;
using TagFilterControl.Utility;

namespace TagFilterControl.Controls.PreFilterManager.FilterInsatnce
{
    class FilterUnitFieldText : FilterUnitField
    {
        private Config config = Config.GetInstance();
        private XMLHelper xmlHelper = XMLHelper.GetInstance();

        public String Criteria { get; set; }

        public FilterUnitFieldText() { }

        protected override bool DoApply(object fieldValue, TagObjects tag)
        {
            String strValue = (fieldValue == null) ? String.Empty : fieldValue.ToString();

            Boolean filterResult = true, valueEmpty = String.IsNullOrEmpty(strValue);
            if (RuleType == RuleType.TagType)
            {
                bool flag = true;
                switch (Condition)
                {
                    case ConditionType.Equal:
                        if (this.Criteria.Equals("All", StringComparison.OrdinalIgnoreCase))
                        {
                            flag = true;
                        }
                        else if (this.Criteria.Equals("Unused", StringComparison.OrdinalIgnoreCase))
                        {
                            if (xmlHelper.UsedTags.Contains(tag.Name))
                            {
                                flag = false;
                            }
                            else
                            {
                                flag = true;
                            }
                        }
                        break;
                    case ConditionType.UnEqual:
                        if (this.Criteria.Equals("All", StringComparison.OrdinalIgnoreCase))
                        {
                            flag = false;
                        }
                        else if (this.Criteria.Equals("Unused", StringComparison.OrdinalIgnoreCase))
                        {
                            if (xmlHelper.UsedTags.Contains(tag.Name))
                            {
                                flag = true;
                            }
                            else
                            {
                                flag = false;
                            }
                        }
                        break;
                    default:
                        break;
                }
                return flag;
            }
            else if (RuleType == RuleType.TagOwner)
            {
                bool flag = true;
                LibraryEntity entity = xmlHelper.Libs.Find(lib => lib.CatalogNumber.Equals(this.Criteria, StringComparison.OrdinalIgnoreCase));
                switch (Condition)
                {
                    case ConditionType.Equal:
                        if (entity != null)
                        {
                            if (tag.Owners.Keys.Contains(entity.Guid))
                            {
                                flag = true;
                            }
                            else
                            {
                                flag = false;
                            }
                        }
                        else
                        {
                            flag = false;
                        }
                        break;
                    case ConditionType.UnEqual:
                        if (entity != null)
                        {
                            if (tag.Owners.Keys.Contains(entity.Guid))
                            {
                                flag = false;
                            }
                            else
                            {
                                flag = true;
                            }
                        }
                        else
                        {
                            flag = false;
                        }
                        break;
                    default:
                        break;
                }
                return flag;
            }

            switch (Condition)
            {
                case ConditionType.Equal:
                    filterResult = !valueEmpty && strValue.Equals(this.Criteria);
                    break;
                case ConditionType.UnEqual:
                    filterResult = valueEmpty || !strValue.Equals(this.Criteria);
                    break;
                case ConditionType.Contain:
                    filterResult = !valueEmpty && strValue.ToUpper(CultureInfo.InvariantCulture).Contains(this.Criteria.ToUpper(CultureInfo.InvariantCulture));
                    break;
                case ConditionType.Except:
                    filterResult = valueEmpty || !strValue.ToUpper(CultureInfo.InvariantCulture).Contains(this.Criteria.ToUpper(CultureInfo.InvariantCulture));
                    break;
            }
            return filterResult;
        }

        public override void Initialize(FilterItemBase filterItem)
        {
            base.Initialize(filterItem);
            this.Criteria = filterItem.Value.Value.ToString();

            if (this.Condition.ToString().Equals("Equal", StringComparison.OrdinalIgnoreCase) || this.Condition.ToString().Equals("Contain", StringComparison.OrdinalIgnoreCase))
            {
                if (config.DefaultTopNodes.Contains(this.FieldName))
                {
                    if (!string.IsNullOrEmpty(this.Criteria))
                    {
                        config.IsCheckedTags[this.Criteria] = new TagNode() { ParentName = this.FieldName };
                    }
                }
                else if (this.FieldName.Equals("TagType"))
                {
                    config.Usage = this.Criteria;
                }
                else if (this.FieldName.Equals("TagOwner"))
                {
                    LibraryEntity entity = xmlHelper.Libs.Find(lib => lib.CatalogNumber.Equals(this.Criteria, StringComparison.OrdinalIgnoreCase));
                    if (entity != null)
                    {
                        config.ACMCustomPropertiesTagOwnersFilter[entity.Guid] = new TagNode() { ParentName = "ACM" };
                    }
                }
            }
        }
    }
}
