﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.AbstractItem;


namespace RockwellAutomation.UI
{

    /// <summary>
    /// concrete implementation of a 'DataType' Path Element.
    /// </summary>
    public class DataTypePathElement : ActiveContrainerWithChildrenPathElement
    {
        #region private members

        private DataTypePECategory _category;
        private string _resourceType;
        private List<string> _pathList = null;

        #endregion private members

        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public DataTypePathElement(DataItemBase dataItem, string displayName, DataTypePECategory category)
                :base(dataItem, displayName)
        {
            this.Category = category;
            this._hasChildren = false;
        }

        #endregion

        #region DataTypePathElement specific properties

        /// <summary>
        /// PathList contains the names of the controllers associated with this path element
        /// </summary>
        public List<string> PathList
        {
            get
            {
                if (_pathList == null)
                {
                    // Create the list
                    _pathList = new List<string>();
                }
                return _pathList;
            }

        }

        public DataTypePECategory Category
        {
            get { return _category; }

            set
            {
                _category = value;
                switch (_category)
                {
                    case (DataTypePECategory.Module):
                        ResourceType = DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE;
                        break;
                    case (DataTypePECategory.Product):
                        ResourceType = DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE;
                        break;
                    case (DataTypePECategory.User):
                        ResourceType = DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE;
                        break;
                }
            }
        }

        public string ResourceType
        {
            get { return _resourceType; }
            internal set { _resourceType = value; }
        }

        /// <summary>
        /// If true this is the Predefined DataType
        /// </summary>
        public bool IsProductDefined
        {
            get { return Category == DataTypePECategory.Product; }
        }
        /// <summary>
        /// If true this is the ModuleDefined DataType
        /// </summary>
        public bool IsModuleDefined
        {
            get { return Category == DataTypePECategory.Module; }
        }
        /// <summary>
        /// If true this is the UserDefined DataType
        /// </summary>
        public bool IsUserDefined
        {
            get { return Category == DataTypePECategory.User; }
        }

        #endregion Properties
    }
}
