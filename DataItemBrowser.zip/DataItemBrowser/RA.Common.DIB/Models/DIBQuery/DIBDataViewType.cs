﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

namespace RockwellAutomation.UI.DIBQuery
{ 
    /// <summary>
    /// DIBDataViewType. Represents the current View that the DIB is using
    /// </summary>
    public class DIBDataViewType : IDIBDataViewType
    {
        #region "Interface Implementation"

        public virtual bool IsListView()
        {
            return false;
        }

        public virtual bool IsGridView()
        {
            return false;
        }

        public virtual bool IsControllerView()
        {
            return false;
        }
                
        public virtual bool IsUnknownView()
        {
            return false;
        } 
        public virtual bool IsTreeView()
        {
            return false;
        }
        public virtual bool IsWebView()
        {
            return false;
        }

        /// <summary>
        /// Obtains prefix for a column's name in the key field stored in the user.config file
        /// The views identified in ColumnsInfo.xml that are to use the same prefixes in the user.config file
        /// must have the same number of columns with the same name.
        /// </summary>
        /// <returns>the stored Prefix for a current DataView.</returns>
        public virtual string GetUserConfigPrefix()
        {
            return "cmn_";
        }

        #endregion
    }
    
}
