/* ****************************************************************************
*
*  Copyright 2016 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System.Collections.Generic;
using System.ComponentModel;
using RockwellAutomation.UI.CommonControls.SearchFilter.ViewModels;
using RockwellAutomation.UI.Models;
using System.Windows.Input;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.CommonControls;
using System;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// interface for the DataItem Browser View Model, allows use to Mock this view model for testing
    /// </summary>
    public interface IDataItemBrowserViewModel
    {
        /// <summary>
        /// Initialize the view model
        /// </summary>
        /// <param name="homeContext">The resource ID to use for the home screen (use null to start at a device listing)</param>
        /// <param name="connectString">String that represents the item the browser should highlight when invoked</param>
        void Initialize(DataItemBrowserContext homeContext,
            string connectString);

        /// <summary>
        /// Close the view model
        /// </summary>
        void Close();

        /// <summary>
        /// Executes a navigate to the children of the passed data item
        /// </summary>
        /// <param name="dataItem">The data item to show the children of (drill in to)</param>
        /// <param name="clearSearch">Whether the search should be cleared as a result of the call</param>
        /// <param name="fromUserSearch">Whether the navigate was called as a result of a search operation</param>
        void Navigate(DataItemBase dataItem, bool clearSearch = true, bool fromUserSearch = false);

        /// <summary>
        /// Navigate without updating the GUI
        /// </summary>
        /// <param name="dataItem">dataitem to navigate to</param>
        /// <param name="callback">method to callback when the navigation is complete</param>
        void NavigateNoGui(DataItemBase dataItem, DataLoadComplete callback);

        /// <summary>
        /// Returns true if personality of browser is the AOG property Browser
        /// </summary>
        bool IsAOGPropertyBrowser();

        /// <summary>
        /// Returns true if personality of browser is the Tag Browser
        /// </summary>
        bool IsTagBrowser();

        string PathToString(List<IPathElement> fullPath, string nameToSelect);

        /// <summary>
        /// Compares the container Path Items against the passed in current path items to determine if the container path elements match
        /// </summary>
        /// <param name="currentPath">Path object containing the current path.</param>
        bool IsNavigateOnCurrentPath(Path currentPath);

        /// <summary>
        /// Fills in the Path member of this view model from the path of the passed data item
        /// </summary>
        /// <param name="dataItem">Data Item to construct the path for</param>
        /// <param name="callback">Callback to use if this method needs to perform a call to navigate</param>
        /// <returns>True if the call to this method will result in the provided callback being used</returns>
        bool PopulatePathFromDataItemPath(DataItemBase dataItem, DataLoadComplete callback);

        /// <summary>
        /// Is the current view displayed in the grid?
        /// </summary>
        /// <returns>True if the view is displayed in the grid</returns>
        bool IsGridView();

        /// <summary>
        /// Is the current view a list view?
        /// </summary>
        /// <returns>True if the view is displayed in the list view</returns>
        bool IsListView();

        bool IsWebView();

        event PropertyChangedEventHandler WebViewOCChanged;

        /// <summary>
        /// event fired when the DataGrid observable collection has changed
        /// </summary>
        event PropertyChangedEventHandler DataGridOCChanged;

        /// <summary>
        /// event fired when the DataSource observable collection has changed
        /// </summary>
        event PropertyChangedEventHandler TreeViewOCChanged;

        /// <summary>
        /// event fired when the DataGrid columns have changed
        /// </summary>
        event PropertyChangedEventHandler DataGridColsChanged;

        /// <summary>
        /// event fired when the DIBListView collection changes
        /// </summary>
        event PropertyChangedEventHandler ListViewOCChanged;

        /// <summary>
        /// Event routing triggered when we want to add or remove the search bread crumb
        /// </summary>
        event PropertyChangedEventHandler SearchBreadCrumbChanged;

        /// <summary>
        /// Event routing triggered when navigate complete function is called
        /// </summary>
        event PropertyChangedEventHandler NavigateComplete;

        /// <summary>
        /// Event routing triggered when DataView changes
        /// </summary>
        event EventHandler DataViewChanged;

        /// <summary>
        /// the Path property
        /// </summary>
        RockwellAutomation.UI.Models.Path Path
        {
            get;
        }

        /// <summary>
        /// columns to be shown
        /// </summary>
        List<ColumnConfigMapItem> Columns
        {
            get;
        }

        /// <summary>
        /// DataItemBase for the Tags and Properties
        /// </summary>
        DataItemBase TagsAndPropsItem
        {
            get;
        }

        /// <summary>
        /// Tracks whether a search is currently applied (either view filtering or via query services)
        /// </summary>
        bool IsSearchActive
        {
            get;
            set;
        }

        IDIBDataViewType DataView
        {
            get;
        }

        /// <summary>
        /// Tracks whether we are currently searching via a special query call (will be false
        /// if we are searching only by using the view filtering provided by data grid collection view)
        /// </summary>
        bool IsQueryBasedSearchActive
        {
            get;
            set;
        }

        /// <summary>
        /// This method performs a  single update to the Column Configuration based on the provided parameters.
        /// </summary>
        /// <param name="columnAttribute">The attribute to be update (Width, visibility, etc)</param>
        /// <param name="columnName">the column name used to generate an key to the correct location</param>
        /// <param name="columnValue">The column Value to set</param>
        void UpdateColumnConfig(ColumnAttribute columnAttribute, string columnName, object columnValue);

        /// <summary>
        /// Persist the user config to disk.
        /// </summary>
        void SaveColumnConfig();

        /// <summary>
        /// get the datasource children for droparrow navigation
        /// </summary>
        /// <param name="dataSourceName">datasource name, can be empty string</param>
        /// <returns>list of droparrow items</returns>
        List<DropArrowItem> getChildren(string dataSourceName, ACrumb hostCrumb);

        /// <summary>
        ///  item selection (highlighted) changed command
        /// </summary>
        ICommand ItemSelectionChangedCommand
        {
            get;
        }

        /// <summary>
        /// item selected (double-click selection) command
        /// </summary>
        ICommand SelectedItemCommand
        {
            get;
        }

        /// <summary>
        /// user driven highlighted item changed command
        /// </summary>
        ICommand UserSetHighlightedItemCommand
        {
            get;
        }

        /// <summary>
        /// The last item explicitly highlighted by the user (i.e. via mouse click or keyboard)
        /// </summary>        
        string LastUserHighlightedItem { get; set; }

        ISearchFilterControlViewModel SearchFilterControlVM
        {
            get;
        }

        /// <summary>
        /// apply view filter to this item
        /// </summary>
        bool ApplyViewFilter(DataItemBase dataItem, GetFieldValue getFieldValue);

        /// <summary>
        /// Data items provided to us as result of various queries
        /// </summary>
        IObservableCollection<DataItemBase> DataItems { get; }

        DataItemBase GetDeviceItemByName(string deviceName);
        DataItemBase GetDataItemByName(string itemName);

        /// <summary>
        /// Get the list of cached devices
        /// </summary>
        /// <returns>ICollection<DataItemBase> representing the Devices</returns>
        ICollection<DataItemBase> GetCachedDevices();
    }
}

