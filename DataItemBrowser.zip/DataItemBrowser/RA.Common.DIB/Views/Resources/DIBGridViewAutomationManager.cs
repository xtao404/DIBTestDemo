﻿/**************************************************************************************
                                                                     
   ViewE DIBGridViewAutomationManager
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System.Collections.Generic;
using System.Windows.Automation.Peers;
using System.Linq;
using System;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Windows.Data;
using System.Globalization;
using System.Windows;
using System.IO;
using RockwellAutomation.Logging;



#endregion

namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Class to expose Automation related activities for Grid View
    /// </summary>
    public class DIBGridViewAutomationManager
    {

        #region Properties/Variables

        //Location of file we write grid data to for UI automation clients
        private static string GridRowDataFilePath = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "Rockwell Automation", "DIBdata.txt");

        //Converters used by the write grid data method for correct formatting of the data cell values
        private DataCellValueConverter _dataCellConvertor = new DataCellValueConverter();

        public static bool HasInitializedStaticData = false;
        private static bool _shouldSerializeGridData = false;

        #endregion

        #region Constructor

        /// <summary>
        /// Constructor is reponsible for setting state of this object
        /// We do not initialize _gridAutomationPeer here and wait to lazy initialize once we get an action from the grid
        /// as we need the grid fully initialized to set _gridAutomationPeer
        /// </summary>
        /// <param name="grid"></param>
        public DIBGridViewAutomationManager()
        {
            // If we already initialized our state, don't need to do anything else.
            // We want our state to persist across DIB invocations until we end up getting a clsoe project
            if (DIBGridViewAutomationManager.HasInitializedStaticData) return;

            DIBGridViewAutomationManager.HasInitializedStaticData = true;
            if (!System.IO.File.Exists(GridRowDataFilePath))
            {
                DIBGridViewAutomationManager._shouldSerializeGridData = false;
                return;
            }

            DIBGridViewAutomationManager._shouldSerializeGridData = true;
            FileInfo file = new FileInfo(GridRowDataFilePath);
            // If the serialization file is older than 1 day, discard it.
            if (file.CreationTime < DateTime.Now.AddDays(-1))
            {
                try
                {   
                    file.Delete();
                }
                catch (Exception e)
                {
                    LogWrapper.DibGeneralLog.Error("Unable to delete older grid serialization file: " + e.Message);
                }
                finally
                {
                    DIBGridViewAutomationManager._shouldSerializeGridData = false;
                }
            }
            file = null;
        }

        #endregion

        #region Grid Events/Actions

        public void GridDataLoadComplete(DIBGridView grid)
        {
            // This is the only place where we want to call the windows API to get current Automation peer and then cache it 
            // and stop asking for Automation Peer for the duration of this DIB instance
            if (!ShouldSerializeGridDataFor(grid, true)) return;
            this.WriteGridDataToFile(grid);
        }

        public void ColumnVisiblePositionChanged(DIBGridView grid)
        {
            if (!ShouldSerializeGridDataFor(grid, false)) return;
            this.WriteGridDataToFile(grid);
        }

        public void ColumnSortIndexChanged(DIBGridView grid)
        {
            if (!ShouldSerializeGridDataFor(grid, false)) return;
            this.WriteGridDataToFile(grid);
        }

        public void ColumnSortDirectionChanged(DIBGridView grid)
        {
            if (!ShouldSerializeGridDataFor(grid, false)) return;
            this.WriteGridDataToFile(grid);
        }
  
        public void ColumnVisibleChanged(DIBGridView grid)
        {
            if (!ShouldSerializeGridDataFor(grid, false)) return;
            this.WriteGridDataToFile(grid);
        }

        #endregion

        #region Operations/Private


        /// <summary>
        /// Determine wether we should serialize grid data for the provided grid
        /// </summary>
        /// <param name="grid"></param>
        /// <returns></returns>
        private bool ShouldSerializeGridDataFor(DIBGridView grid, bool shouldStopResetingAutomationPeer)
        {
            if (!_shouldSerializeGridData) return false;
            if (grid == null || !grid.IsVisible) return false;
            return true;
        }

        /// <summary>
        /// Method to serialize the current grid data to a file
        /// </summary>
        /// <param name="_gridAutomationPeer">A preobtained copy of the grid automation peer.  If this is passed, it will
        /// be used, otherwise it will be looked up via a call to GetGridAutomationPeer</param>
        private void WriteGridDataToFile(DIBGridView grid, AutomationPeer gridAutomationPeer = null)
        {
            //If UI automation is active, persist a file representing the data grid row data.  This assists test since the
            // corresponding UI automation code to get each grid row data is very slow.  Also only write the file if the
            // file exists.  This allows UI automation to run without the logging if we want to run in that way.
                
            //Copy the data to a new array since we may get an update of the items when we are already in this method
            List<string> gridData = new List<string>();
            object[] RowArray = new object[grid.Items.Count];
            grid.Items.CopyTo(RowArray, 0);
            if (RowArray.Count() > 0)
            {
                //Determine visible columns
                var orderedVisibleCols = from column in grid.Columns
                                            orderby (column.VisiblePosition) ascending
                                            where column.Visible && !string.IsNullOrWhiteSpace(column.Title as string)
                                            select column.FieldName;

                //First row is the list of column names
                gridData.Add(string.Join(",", orderedVisibleCols.Select(c => "%" + c)));

                //Add the row string to the list of lines to write to the file
                int rowNum = 0;
                foreach (object gridItem in RowArray)
                {
                    string rowString = String.Empty;
                    string sep = String.Empty;
                    foreach (string colName in orderedVisibleCols)
                    {
                        DataItemBase gridDataItem = gridItem as DataItemBase;
                        string cellValue = gridDataItem.GetStringMapValue(colName);

                        if (cellValue != null)
                        {
                            IValueConverter conv = _dataCellConvertor as IValueConverter;
                            string convertedCellValue = conv.Convert(cellValue, typeof(string), null, CultureInfo.CurrentCulture) as string;

                            //Quotes in CSV file have to be doubled to be interpreted correctly
                            convertedCellValue = convertedCellValue.Replace("\"", "\"\"");

                            rowString += string.Format("{0}\"{1}\"", sep, convertedCellValue);
                            sep = ",";
                        }
                    }

                    gridData.Add(rowString);
                    rowNum += 1;
                }
            }

            //Write the lines to the file
            System.IO.File.WriteAllLines(GridRowDataFilePath, gridData);
        }
        #endregion
    }
}