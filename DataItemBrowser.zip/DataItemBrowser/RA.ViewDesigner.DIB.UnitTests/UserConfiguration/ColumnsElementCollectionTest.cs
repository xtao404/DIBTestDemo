﻿using RockwellAutomation.UI.UserConfiguration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Configuration;
using RockwellAutomation.UI;

namespace DataItemBrowserUT
{
    
    /// <summary>
    ///This is a test class for ColumnsElementCollectionTest and is intended
    ///to contain all ColumnsElementCollectionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ColumnsElementCollectionTest
    {

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        private ColumnElement CreateElement()
        {
            // structured like this so breakpoints can be set on returned value
            ColumnElement ce = new ColumnElement("cmn_Name", "Name", true, 0, 120, RockwellAutomation.Client.Services.Query.SortDirection.Ascending, 0);
            return ce;

        }

        /// <summary>
        ///A test for Item
        ///</summary>
        [TestMethod()]
        public void ColumnsElementCollectionTest1()
        {
            ColumnsElementCollection target = new ColumnsElementCollection();
            target.Add(CreateElement());
            Assert.AreEqual(1, target.Count, "ColumnsElementCollectionTest1 failed - count is not 1");
            ColumnElement actual;
            actual = target["cmn_Name"];
            Assert.AreEqual(actual, CreateElement(), "ColumnsElementCollectionTest1 failed - Accessing an element by named failed");
        }

        /// <summary>
        ///A test for Item
        ///</summary>
        [TestMethod()]
        public void CE_ItemTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection();
            target.Add(CreateElement());
            int index = 0;
            ColumnElement expected = CreateElement(); 
            ColumnElement actual;
            target[index] = expected;
            actual = target[index];
            Assert.AreEqual(expected, actual, "ItemTest failed - Accessing an element by index failed");
        }

        /// <summary>
        ///A test for ElementName
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ElementNameTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection(); // TODO: Initialize to an appropriate value
            PrivateObject targetPrivate = new PrivateObject(target);
            string actual;
            actual = (string)targetPrivate.GetFieldOrProperty("ElementName");
            Assert.AreEqual("Column", actual, "ElementNameTest failed - The name of elements in the collection is not Column");
        }

        /// <summary>
        ///A test for CollectionType
        ///</summary>
        [TestMethod()]
        public void CollectionTypeTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection();
            ConfigurationElementCollectionType actual;
            actual = target.CollectionType;
            Assert.AreEqual(actual, ConfigurationElementCollectionType.BasicMap, "CollectionTypeTest failed - ConfigurationElementCollectionType.BasicMap not returned");
        }

        /// <summary>
        ///A test for RemoveAt
        ///</summary>
        [TestMethod()]
        public void RemoveAtTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection();
            target.Add(CreateElement());
            int index = 0;
            target.RemoveAt(index);
            Assert.AreEqual(0, target.Count, "RemoveAtTest failed - count is not 0");
        }

        /// <summary>
        ///A test for Remove
        ///</summary>
        [TestMethod()]
        public void RemoveTest1()
        {
            ColumnsElementCollection target = new ColumnsElementCollection();
            ColumnElement thing = CreateElement();
            target.Remove(thing);
            Assert.AreEqual(0, target.Count, "RemoveTest1 failed - count is not 0");
        }

        /// <summary>
        ///A test for Remove
        ///</summary>
        [TestMethod()]
        public void RemoveTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection(); // TODO: Initialize to an appropriate value
            target.Add(CreateElement());
            target.Remove("cmn_Name");
            Assert.AreEqual(0, target.Count, "RemoveTest failed - count is not 0");
        }

        /// <summary>
        ///A test for GetKey
        ///</summary>
        [TestMethod()]
        public void GetKeyTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection(); // TODO: Initialize to an appropriate value
            target.Add(CreateElement());
            int index = 0;
            string expected = "cmn_Name";
            string actual;
            actual = target.GetKey(index);
            Assert.AreEqual(expected, actual, "GetKeyTest failed - names didn't match");
        }

        /// <summary>
        ///A test for GetElementKey
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void GetElementKeyTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection();
            PrivateObject targetPrivate = new PrivateObject(target);
            target.Add(CreateElement());
            ConfigurationElement element = CreateElement();
            object expected = "cmn_Name";
            object actual;
            actual = targetPrivate.Invoke("GetElementKey", element);
            Assert.AreEqual(expected, actual, "GetElementKeyTest failed - they are not equal");
        }

        /// <summary>
        ///A test for CreateNewElement
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void CreateNewElementTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection();
            PrivateObject targetPrivate = new PrivateObject(target);
            ConfigurationElement expected = null; 
            ConfigurationElement actual;
            actual = (ConfigurationElement)targetPrivate.Invoke("CreateNewElement");
            Assert.AreNotEqual(expected, actual, "CreateNewElementTest failed - new element was not created");
        }

        /// <summary>
        ///A test for Clear
        ///</summary>
        [TestMethod()]
        public void ClearTest()
        {
            ColumnsElementCollection target = new ColumnsElementCollection();
            target.Add(CreateElement());
            Assert.AreEqual(1, target.Count, "ClearTest failed - count is not 1");
            target.Clear();
            Assert.AreEqual(0, target.Count, "ClearTest failed - count is not 0");
        }
    }
}
