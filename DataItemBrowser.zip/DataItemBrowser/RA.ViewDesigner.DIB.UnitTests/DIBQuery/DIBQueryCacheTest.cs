/*************************************************************************************
                                                                     
   ViewE DIBQueryCacheTest Class
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System.Collections.Generic;
using FakeItEasy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query;

#endregion

namespace DataItemBrowserUT
{

    /// <summary>
    /// Summary description for DIBQueryCacheTest.
    /// </summary>
    [TestClass]
    public class DIBQueryCacheTest
    {
        #region Additional test attributes

        /// <summary>
        /// Use TestInitialize to run code before running each test 
        /// </summary>
        [TestInitialize()]
        public void DIBQueryCacheTestInit()
        {
            DIBClientManagerForViewe.Instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, 
                DIBQueryCommandTest.SamplePackageContextUUID, DIBQueryCommandTest.SampleProjectContextUUID);
            DIBClientManagerForViewe.InitializeVieweSpecificClasses();
        }

        /// <summary>
        /// Use TestCleanup to run code after each test has run
        /// </summary>
        [TestCleanup()]
        public void DIBQueryCacheTestCleanup()
        {
            DIBClientManagerForViewe.Instance.Shutdown();
        }

        #endregion

        /// <summary>
        ///A test for GetItemByName. 
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void GetItemByNameTest()
        {
            TSObservableCollection<DataItemBase> collection = new TSObservableCollection<DataItemBase>();

            DataItemBase dataItem1 = new DataItemBase();
            dataItem1.CommonName = "something1";
            DataItemBase dataItem2 = new DataItemBase();
            dataItem2.CommonName = "something2";
            collection.Add(dataItem1);
            collection.Add(dataItem2);

            Assert.IsTrue(DIBQueryCache.GetItemByName("something3", collection) == null);
            Assert.IsTrue(DIBQueryCache.GetItemByName("something1", collection).CommonName == "something1");
            Assert.IsTrue(DIBQueryCache.GetItemByName("something2", collection).CommonName == "something2");
        }

        /// <summary>
        ///A test for GetChildrenOfCrumb
        /// Returns the children of the passed crumb
        /// Simulate Selecting/hovering the HomeCrumb
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DIBQueryCache_GetChildrenOfCrumb_HomeCrumb_VerifyChildren()
        {
            //ARRANGE
            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.IsTagBrowser()).Returns(true);
            A.CallTo(() => fakeClientDataServices.DibClientManager).Returns(DIBClientManagerForViewe.Instance);

            TSObservableCollection<DataItemBase> dataItems = DIBUtility.GetDeviceViewList();

            //create the class under test
            DIBQueryCache target = new DIBQueryCache(dataItems);

            Dictionary<string, IObservableCollection<DataItemBase>> _cache = new Dictionary<string, IObservableCollection<DataItemBase>>();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_NONE,dataItems);
            PrivateObject privateQueryCache = new PrivateObject(target);
            privateQueryCache.SetFieldOrProperty("CachedChildren", _cache);
            

            //set up parameters for the method under test
            DataContext _dataContext = new DataContext();
            List<DataItemBase> dataItemList = new List<DataItemBase>();
            dataItemList.Add(null);
            IPathElement pathElement = PathElementFactory.Instance().CreateHomePathElement(dataItemList);
            ACrumb crumb = new HomeCrumb(pathElement);
            string nextName = string.Empty;

            //ACT
            List<DropArrowItem> childrenList = target.GetChildrenOfCrumb(crumb, nextName, _dataContext, fakeClientDataServices);


            //ASSERT
            //verify the returned list is correct
            Assert.AreEqual(5,childrenList.Count);
            VerifyAllDataItems(childrenList,dataItems);

        }

        private void VerifyAllDataItems(List<DropArrowItem> dropArrowItems, IObservableCollection<DataItemBase> dataItems)
        {
            bool found = false;
            foreach (var dataItemBase in dataItems)
            {
                foreach (var dropArrowItem in dropArrowItems)
                {
                    if (dropArrowItem.DisplayName == dataItemBase.CommonName)
                    {
                        found = true;
                        break;
                    }
                }
            }

            Assert.IsTrue(found,"All dataItems expected in dropArrowItems, but one not found");
        }

        /// <summary>
        ///A test for GetChildrenOfCrumb
        /// Returns the children of the passed crumb
        /// Simulate Selecting/hovering the ControllerCrumb
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DIBQueryCache_GetChildrenOfCrumb_ControllerCrumb_VerifyChildren()
        {
            //ARRANGE
            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.IsTagBrowser()).Returns(true);
            A.CallTo(() => fakeClientDataServices.DibClientManager).Returns(DIBClientManagerForViewe.Instance);

            TSObservableCollection<DataItemBase> dataItems = DIBUtility.GetDeviceViewList();

            //create the class under test
            DIBQueryCache target = new DIBQueryCache(dataItems);

            Dictionary<string, IObservableCollection<DataItemBase>> _cache = new Dictionary<string, IObservableCollection<DataItemBase>>();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_NONE, dataItems);
            IObservableCollection<DataItemBase> controllerItems = DIBUtility.GetControllerViewList();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER, controllerItems);
            PrivateObject privateQueryCache = new PrivateObject(target);
            privateQueryCache.SetFieldOrProperty("CachedChildren", _cache);

            //set up parameters for the method under test
            DataContext _dataContext = new DataContext();
            DataItemBase controllerDib = PathElementUtility.Instance().CreateDataItemBase("c1");
            controllerDib.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(controllerDib);
            ACrumb crumb = new TextCrumb(pathElement);
            string nextName = DIResource.DI_COMMON_RESOURCETYPE_TAGSPROPERTIES;

            //ACT
            List<DropArrowItem> childrenList = target.GetChildrenOfCrumb(crumb, nextName, _dataContext, fakeClientDataServices);


            //ASSERT
            //verify the returned list is correct
            Assert.AreEqual(3, childrenList.Count);
            VerifyAllDataItems(childrenList, controllerItems);

        }


        /// <summary>
        ///A test for GetChildrenOfCrumb
        /// Returns the children of the passed crumb
        /// Simulate Selecting/hovering the ControllerCrumb after drilling into a searchItem
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DIBQueryCache_GetChildrenOfCrumb_ControllerCrumb_SearchItemSelected_VerifyChildren()
        {
            //ARRANGE
            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.IsTagBrowser()).Returns(true);
            A.CallTo(() => fakeClientDataServices.DibClientManager).Returns(DIBClientManagerForViewe.Instance);

            //create DeviceView without HMIDEVICE
            TSObservableCollection<DataItemBase> dataItems = DIBUtility.GetDeviceViewList(DIResource.DI_COMMON_RESOURCETYPE_DEVICE);

            //create the class under test
            DIBQueryCache target = new DIBQueryCache(dataItems);

            Dictionary<string, IObservableCollection<DataItemBase>> _cache = new Dictionary<string, IObservableCollection<DataItemBase>>();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_NONE, dataItems);
            IObservableCollection<DataItemBase> programItems = DIBUtility.GetProgramList();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS, programItems);
            PrivateObject privateQueryCache = new PrivateObject(target);
            privateQueryCache.SetFieldOrProperty("CachedChildren", _cache);

            //set up parameters for the method under test
            DataContext _dataContext = new DataContext();
            DataItemBase controllerDib = PathElementUtility.Instance().CreateDataItemBase("c1");
            controllerDib.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(controllerDib);
            ACrumb crumb = new TextCrumb(pathElement);
            string nextName = DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS;

            //ACT
            List<DropArrowItem> childrenList = target.GetChildrenOfCrumb(crumb, nextName, _dataContext, fakeClientDataServices);


            //ASSERT
            //verify the returned list is correct
            Assert.AreEqual(2, childrenList.Count);
            VerifyAllDataItems(childrenList, programItems);

        }
       
        
         /// <summary>
        ///A test for GetDeviceItemByName
        /// Returns the DataItemBase for the given string
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DIBQueryCache_GetChildrenOfCrumb_GetDeviceItemByName_VerifyDataItem()
        {
            //ARRANGE
            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.IsTagBrowser()).Returns(true);
            A.CallTo(() => fakeClientDataServices.DibClientManager).Returns(DIBClientManagerForViewe.Instance);

            TSObservableCollection<DataItemBase> dataItems = DIBUtility.GetDeviceViewList();

            //create the class under test
            DIBQueryCache target = new DIBQueryCache(dataItems);

            //set up the target's cached children
            Dictionary<string, IObservableCollection<DataItemBase>> _cache = new Dictionary<string, IObservableCollection<DataItemBase>>();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_NONE, dataItems);
            IObservableCollection<DataItemBase> controllerItems = DIBUtility.GetControllerViewList();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER, controllerItems);
            PrivateObject privateQueryCache = new PrivateObject(target);
            privateQueryCache.SetFieldOrProperty("CachedChildren", _cache);

            //set up parameters for the method under test           
            string deviceName = "Local:HMIDevice";

            //ACT
            DataItemBase dibDevice = target.GetDeviceItemByName(deviceName);

            //ASSERT            
            Assert.AreEqual(deviceName, dibDevice.ToString());
        }

        /// <summary>
        ///A test for GetDataItemByName
        /// Returns the DataItemBase for the given string
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DIBQueryCache_GetChildrenOfCrumb_GetDataItemByName_VerifyDataItem()
        {
            //ARRANGE
            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.IsTagBrowser()).Returns(true);
            A.CallTo(() => fakeClientDataServices.DibClientManager).Returns(DIBClientManagerForViewe.Instance);

            TSObservableCollection<DataItemBase> dataItems = DIBUtility.GetTagViewList();

            //create the class under test
            DIBQueryCache target = new DIBQueryCache(dataItems);

            //set up the target's cached children
            Dictionary<string, IObservableCollection<DataItemBase>> _cache = new Dictionary<string, IObservableCollection<DataItemBase>>();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_NONE, dataItems);
            IObservableCollection<DataItemBase> controllerItems = DIBUtility.GetControllerViewList();
            _cache.Add(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER, controllerItems);
            PrivateObject privateQueryCache = new PrivateObject(target);
            privateQueryCache.SetFieldOrProperty("CachedChildren", _cache);

            //set up parameters for the method under test           
            string dataItemName = "MyTag";
            string location = "::c1";

            //ACT
            DataItemBase dibDevice = target.GetDataItemByName(dataItemName,location);

            //ASSERT    
            //should find item
            Assert.AreEqual(dataItemName, dibDevice.ToString());
            Assert.AreEqual(location,dibDevice.CommonLocation);

            //set up parameters for another test that should not find the item
            dataItemName = "MyTag1";
            location = "::c1";

            //ACT
            dibDevice = target.GetDataItemByName(dataItemName, location);

            //ASSERT    
            //should find item
            Assert.IsNull(dibDevice);            
        }

      

        /// <summary>
        ///A test for GetDataItemByName
        /// Returns the DataItemBase for the given string
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DIBQueryCache_GetChildrenOfCrumb_GetDataTypeItemByLocation_VerifyDataItem()
        {
            //ARRANGE
            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.IsTagBrowser()).Returns(true);
            A.CallTo(() => fakeClientDataServices.DibClientManager).Returns(DIBClientManagerForViewe.Instance);

            TSObservableCollection<DataItemBase> dataItems = DIBUtility.GetDataTypeList();

            //create the class under test
            DIBQueryCache target = new DIBQueryCache(dataItems);

            //set up the target's cached children
            Dictionary<string, IObservableCollection<DataItemBase>> _cache = new Dictionary<string, IObservableCollection<DataItemBase>>();
            _cache.Add(DIBConstants.Common.DataType, dataItems);
            PrivateObject privateQueryCache = new PrivateObject(target);
            privateQueryCache.SetFieldOrProperty("CachedChildren", _cache);

            //set up parameters for the method under test           
            string dataItemName = "Level04";
            string location = "c1"; //Not prefixed by '::'

            //ACT
            DataItemBase dibDevice = target.GetDataTypeItemByLocation(dataItemName, location);

            //ASSERT            
            Assert.AreEqual(dataItemName, dibDevice.ToString());
            Assert.AreEqual("::"+location, dibDevice.CommonLocation);

            //set up parameters for the method under test           
            dataItemName = "Level04";
            location = "c2"; //Not prefixed by '::'

            //ACT
            dibDevice = target.GetDataTypeItemByLocation(dataItemName, location);

            //ASSERT            
            Assert.IsNull(dibDevice);            
        }
      
    }
}
