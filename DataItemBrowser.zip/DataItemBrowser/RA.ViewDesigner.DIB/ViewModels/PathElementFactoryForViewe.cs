/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2016 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System;
using System.Reflection;
using System.Collections.Specialized;
using System.Runtime.CompilerServices;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.Generic;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.WindowsControl.DIBClient;

#endregion

namespace RockwellAutomation.UI
{
    /// <summary>
    /// PathElementFactoryForViewe
    /// </summary>
    public class PathElementFactoryForViewe: PathElementFactory
    {
        /// <summary>
        /// PathElementFactoryForViewe constructor
        /// </summary>
        public PathElementFactoryForViewe()
        {
        }

        #region Public Methods

        /// <summary>
        /// Creates a path element for the passed data item, this method should be used instead of the 
        /// specific methods (like CreateProgramPathElement), but this does not apply for HomePathElements
        /// since they may have one or more dataitems
        /// </summary>
        /// <param name="dataItem">Data Item representing the element to create a path element for</param>
        /// <returns>The newly created path element</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public override IPathElement CreatePathElement(DataItemBase dataItem)
        {
            IPathElement newPathElement = null;

            if (dataItem == null) return newPathElement;

            //Create the correct flavor of path element
            UUID itemType = dataItem.GetResourceTypeAsUUID();
            if (ResourceBase.IsEqual(itemType, TypeIdentifiers.getResourceType_Controller()))
            {
                newPathElement = new ControllerPathElement(dataItem, GetValidDisplayName(dataItem));
                DIResource.UpdateTagsAndPropertiesItem(TypeIdentifiers.getResourceType_Controller());
                return newPathElement;
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_HMIDevice))
            {
                newPathElement = new HMIDevicePathElement(dataItem, GetValidDisplayName(dataItem));
                DIResource.UpdateTagsAndPropertiesItem(TypeIdentifiers.ResourceType_HMIDevice);
                return newPathElement;
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Programs))
            {
                return new ProgramsPathElement(dataItem, GetValidDisplayName(dataItem));
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Program))
            {
                return new ProgramPathElement(dataItem, GetValidDisplayName(dataItem));
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_DataLogs))
            {
                return new DataLogsPathElement(dataItem, GetValidDisplayName(dataItem));
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_DataLog))
            {
                return new DataLogPathElement(dataItem, GetValidDisplayName(dataItem));
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_TagsAndProperties))
            {
                return new TagsPropertiesPathElement(dataItem, GetValidDisplayName(dataItem));
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_Tag))
            {
                return new DataItemPathElement(dataItem, GetValidDisplayName(dataItem));
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_DataTypeMember))
            {
                return new DataItemPathElement(dataItem, GetValidDisplayName(dataItem));
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_AOG))
            {
                return new AOGScreenPathElement(dataItem, GetValidDisplayName(dataItem));
            }
            else if (ResourceBase.IsEqual(itemType, TypeIdentifiers.ResourceType_DataType))
            {
                DataTypePECategory cat = new DataTypePECategory();
                bool bFoundType = false;
                switch (dataItem.CommonDataType) 
                {
                    case "Predefined": // DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE
                        cat = DataTypePECategory.Product;
                        bFoundType = true;
                        break;
                    case "User-Defined": // DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE
                        cat = DataTypePECategory.User;
                        bFoundType = true;
                        break;
                    case "Module-Defined": // DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE
                        cat = DataTypePECategory.Module;
                        bFoundType = true;
                        break;
                }
                //if it is not the data type category then create a data item path element
                if (bFoundType)
                    return new DataTypePathElement(dataItem, dataItem.CommonName, cat);
                else
                    return new DataItemPathElement(dataItem, GetValidDisplayName(dataItem));
            }     
            else // Path element for Bits
            {
                return new DataItemPathElement(dataItem, GetValidDisplayName(dataItem));
            }
        }

        /// <summary>
        /// creates/returns an instance of a <c>DataTypePathElement</c> path element with its default properties
        /// set and adds the <c>displayName</c> to the instance.
        /// set and adds the <c>category</c> to the instance
        /// </summary>
        /// <param name="dataItemBase">object containing the name to apply to the <c>DisplayName</c> property</param>
        /// <param name="category">type (module, product or user) to apply to the <c>Category</c> property</param>
        /// <returns>instance of a DataTypePathElement</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public override IPathElement CreateDataTypePathElement(DataItemBase dataItemBase, DataTypePECategory category)
        {
            return new DataTypePathElement(dataItemBase, dataItemBase.CommonName, category);
        }

        #endregion Public Methods

    }
}
