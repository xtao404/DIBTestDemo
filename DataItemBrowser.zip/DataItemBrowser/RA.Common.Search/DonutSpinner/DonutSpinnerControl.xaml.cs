﻿/* ****************************************************************************
*
*  Copyright 2012 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Media.Animation;


namespace RockwellAutomation.UI.CommonControls
{
    /// <summary>
    /// Interaction logic for DonutSpinnerControl.xaml
    /// </summary>
    public partial class DonutSpinnerControl : UserControl
    {
        public DonutSpinnerControl()
        {
            InitializeComponent();
        }

        #region public dependency properties

        /// <summary>
        /// the factor to scale the entire image (default value = 1.0)
        /// </summary>
        public static DependencyProperty ScaleFactorProperty = DependencyProperty.Register("ScaleFactor",
                                typeof(double), typeof(DonutSpinnerControl), new PropertyMetadata(1.0d));
        /// <summary>
        /// scale factor property
        /// </summary>
        public double ScaleFactor
        {
            get { return (double)GetValue(DonutSpinnerControl.ScaleFactorProperty); }
            set { SetValue(DonutSpinnerControl.ScaleFactorProperty, value); }
        }
        #endregion public dependency properties

        #region events
        /// <summary>
        /// has the visibility of this user control changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DonutSpinnerControl_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            bool isVisible = (bool)e.NewValue;
            //find the animation storyboard
            Storyboard board = (Storyboard)this.FindResource("spinDot");
            if (board != null)
            {
                //start and stop the animation based on the visibility
                if (isVisible)
                    board.Begin();
                else
                    board.Stop();
            }
        }
        #endregion events
    }
}
