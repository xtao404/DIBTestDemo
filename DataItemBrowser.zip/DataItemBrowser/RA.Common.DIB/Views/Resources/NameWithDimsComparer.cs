﻿/* ****************************************************************************
*
*  Copyright 2015 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System;
using System.Collections;
using System.Runtime.InteropServices;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// Classed used to return compare results for items which
    /// contain a name followed by array dimensions, for instance
    /// TagName[2,5,9] or DataType[9,8,2]
    /// </summary>
    public class NameWithDimsComparer : IComparer
    {
        static NameWithDimsComparer _Instance = null;
        static char[] Delims = { DIResource.DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER, DIResource.DI_COMMON_RESOURCETYPE_ARRAY_DIMENSIONS_SEPERATOR, DIResource.DI_COMMON_RESOURCETYPE_ARRAY_END_DELIMITER };

        //Each array dimension is split into a string and padded
        // to the number of characters set in _PadCount
        const int _PadCount = 8;

        /// <summary>
        /// Private constructor.  Use Instance to get the
        /// single instance of the comparer class
        /// </summary>
        private NameWithDimsComparer()
        {
        }

        /// <summary>
        /// Returns the instance of the comparer class
        /// </summary>
        static public NameWithDimsComparer Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new NameWithDimsComparer();
                }

                return _Instance;
            }
        }

        #region IComparer Members

        /// <summary>
        /// Custom sort compare function used to compare names
        /// which may also have array dimensions on the end
        /// </summary>
        /// <param name="x">Item1 to compare</param>
        /// <param name="y">Item2 to compare</param>
        /// <returns>Compare result based on CompareTo call between the
        /// items passed to this function</returns>
        public int Compare(object x, object y)
        {
            if (x == null && y == null)
                return 0;
            //Get the items to compare into strings            
            string Item1 = x as string ?? string.Empty;
            string Item2 = y as string ?? string.Empty;

            int CompareResult = 0;
            bool isItem1NullOrEmpty = String.IsNullOrEmpty(Item1);
            bool isItem2NullOrEmpty = String.IsNullOrEmpty(Item2);

            if (isItem1NullOrEmpty && isItem2NullOrEmpty) return CompareResult;     

            //Split up the strings into parts based on the array delimiters
            string[] Item1Parts = Item1.Split(Delims, StringSplitOptions.RemoveEmptyEntries);
            string[] Item2Parts = Item2.Split(Delims, StringSplitOptions.RemoveEmptyEntries);


            //If the first part of the items (which will be the name) are
            // identical, then we need to proceed to look at array dims
            if (!isItem1NullOrEmpty && !isItem2NullOrEmpty && Item1Parts[0] == Item2Parts[0])
            {
                //Arrays of fewer dimensions should show before those with more
                // dimensions so check this first
                int Item1PartsCount = Item1Parts.Length;
                int Item2PartsCount = Item2Parts.Length;
                CompareResult = Item1PartsCount.CompareTo(Item2PartsCount);

                //If the arrays have the same number of dimensions, compare
                // each one
                if (CompareResult == 0)
                {
                    //Create a string which contains each dimension of the
                    // array with the same amount of characters
                    string Item1Key = string.Empty;
                    string Item2Key = string.Empty;
                    if (Item1PartsCount > 1) //same as Item2PartsCount
                    {
                        Item1Key = Item1Parts[1].PadLeft(_PadCount, '0');
                        Item2Key = Item2Parts[1].PadLeft(_PadCount, '0');
                        if (Item1PartsCount > 2) //same as Item2PartsCount
                        {
                            Item1Key += Item1Parts[2].PadLeft(_PadCount, '0');
                            Item2Key += Item2Parts[2].PadLeft(_PadCount, '0');
                            if (Item1PartsCount > 3) //same as Item2PartsCount
                            {
                                Item1Key += Item1Parts[3].PadLeft(_PadCount, '0');
                                Item2Key += Item2Parts[3].PadLeft(_PadCount, '0');
                            }
                        }
                    }

                    // Perform the actual compare, using the keys generated above
                    // Using strings seems to be more performant than converting
                    // each array dimension into an integer using int.Parse or the
                    // Convert class
                    CompareResult = Item1Key.CompareTo(Item2Key);
                }
            }
            else
            {
                // Remove any leading spaces in the name so we have a fair numeric comparison
                if (!isItem1NullOrEmpty && Char.IsWhiteSpace(Item1[0])) Item1 = Item1.TrimStart();
                if (!isItem2NullOrEmpty && Char.IsWhiteSpace(Item2[0])) Item2 = Item2.TrimStart();

                // if Item1 is metadata and Item2 is not, we want Item1 to be displayed AFTER Item2 (Metadata rows displayed last)
                if (MetaDataHelper.isMetaDataName(Item1) && !MetaDataHelper.isMetaDataName(Item2))
                {
                    return 1;
                }
                // if Item1 is not metadata and Item2 is, we want Item1 to be displayed BEFORE Item2 (Metadata rows displayed last)
                if (!MetaDataHelper.isMetaDataName(Item1) && MetaDataHelper.isMetaDataName(Item2))
                {
                    return -1;
                }

                // If the names of the items are not the same, do a natural numeric sort
                CompareResult = SafeNativeMethods.StrCmpLogicalW(Item1, Item2);
            }

            return CompareResult;
        }

        #endregion
    }

    // "shlwapi.dll" contains the StrCmpLogicalW function which compares two strings using a Natural Numeric Sort.
    // A natural numeric sort would order the three strings: T1.txt, T10.txt, and T3.txt (the alphabetical sort) into 
    // T1.txt, T3.txt, and T10.txt

    // The SuppressUnmanagedCodeSecurity attribute can be applied to methods that want to call into native code 
    // without incurring the performance loss of a run-time security check when doing so. 
    // The stack walk performed when calling unmanaged code is omitted at run time, 
    // resulting in substantial performance savings. Using this attribute in a class applies it to all contained methods.
    [System.Security.SuppressUnmanagedCodeSecurity]
    internal static class SafeNativeMethods
    {
        [DllImport("shlwapi.dll", CharSet = CharSet.Unicode)]
        public static extern int StrCmpLogicalW(string psz1, string psz2);
    }

}
