﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

namespace RockwellAutomation.UI.DIBQuery
{
    public class DIBDataViewTypeListView : DIBDataViewType
    {

        #region " Overides"

        public override bool IsListView()
        {
            return true;
        }

        #endregion
    }
    
}
