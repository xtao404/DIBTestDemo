﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Common
{
    public static class UIDispatcher
    {
        public static System.Windows.Threading.Dispatcher _Dispatcher { get; set; }
    }
}
