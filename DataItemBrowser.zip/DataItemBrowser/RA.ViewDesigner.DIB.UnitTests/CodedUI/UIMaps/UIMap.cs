﻿
using System;
using System.Windows;

namespace DataItemBrowserUT.CodedUI.UIMaps.UIMapClasses    
{
    using System.CodeDom.Compiler;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using System.Drawing;
    using Microsoft.VisualStudio.TestTools.UITesting.WpfControls;
    using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;

    public partial class UIMap
    {

        /// <summary>
        /// ClickHomeCrumbButton
        /// </summary>
        public void ClickHomeCrumbButton()
        {
            #region Variable Declarations
            //WpfButton uIHomeCrumbUnderlinedButton = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIHomeCrumbUnderlinedButton;
            WpfButton mUIHomeCrumbButton = new WpfButton(this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom);
            mUIHomeCrumbButton.SearchProperties[WpfButton.PropertyNames.AutomationId] = "HomeCrumb";
            mUIHomeCrumbButton.WindowTitles.Add("DataItemBrowser Host Window");

            #endregion

            // Click 'HomeCrumbUnderlined' button
            Mouse.Click(mUIHomeCrumbButton, new Point(9, 8));
        }

        /// <summary>
        /// DIB_PackageCloseButton_Exists - Use 'DIB_Assert_PackageCloseButton_ExistsExpectedValues' to pass parameters into this method.
        /// <returns>bool: true - the package close button exists, false - it does not exist</returns>
        /// </summary>
        public bool DIB_PackageCloseButton_Exists()
        {
            #region Variable Declarations
            WpfButton uICloseButton = this.UICommonTagPopupTestHoWindow.UICloseButton;
            #endregion
            //WpfButton.Exists or WpfButton.Enabled is always true, most likely because the button Visibility property is Visiblity.Hidden instead of Visibility.Collapsed
            //So this is a workaround to try to set the focus and if it cannot be set then it is assumed that the button is hidden 
            if (uICloseButton == null || !uICloseButton.Exists || !uICloseButton.Enabled) return false;
           
            try
            {
                uICloseButton.SetFocus();
            }
            catch (Exception)
            {
                return false;
            }

            bool focus = uICloseButton.HasFocus;

            return focus;            
        }

        public virtual DIB_Assert_PackageCloseButton_ExistsExpectedValues DIB_Assert_PackageCloseButton_ExistsExpectedValues
        {
            get
            {
                if ((this.mDIB_Assert_PackageCloseButton_ExistsExpectedValues == null))
                {
                    this.mDIB_Assert_PackageCloseButton_ExistsExpectedValues = new DIB_Assert_PackageCloseButton_ExistsExpectedValues();
                }
                return this.mDIB_Assert_PackageCloseButton_ExistsExpectedValues;
            }
        }

        private DIB_Assert_PackageCloseButton_ExistsExpectedValues mDIB_Assert_PackageCloseButton_ExistsExpectedValues;
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_Assert_PackageCloseButton_Exists'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_Assert_PackageCloseButton_ExistsExpectedValues
    {

        #region Fields
        /// <summary>
        /// Verify that 'Close' button's property 'Exists' equals 'True'
        /// </summary>
        public bool UICloseButtonExists = true;
        #endregion
}
}
