using RockwellAutomation.UI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for PathTest and is intended
    ///to contain all PathTest Unit Tests
    ///</summary>
    [TestClass()]
    public class PathTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SelectedPath
        ///</summary>
        [TestMethod()]
        public void Path_SelectedPathTest()
        {
            List<IPathElement> expected = new List<IPathElement>();
            expected.Add(PathElementUtility.Instance().CreateControllerPathElement("bigController"));
            expected.Add(PathElementUtility.Instance().CreateDataItemPathElement("bigTag", "", true));
            expected.Add(PathElementUtility.Instance().CreateDataItemPathElement("bigMember", "", true));
            expected.Add(PathElementUtility.Instance().CreateDataItemPathElement("bigMemberMember", "", true));

            Path target = new Path(); 
            foreach(IPathElement element in expected)
            {
                target.Add(element);
            }
            List<IPathElement> actual;
            actual = target.SelectedPath;
            int i=0;
            foreach (IPathElement pathElement in actual)
            {
                Assert.AreEqual(pathElement.DisplayName, expected[i++].DisplayName);
            }
        }

        /// <summary>
        ///A test for SelectedPath
        ///</summary>
        [TestMethod()]
        public void Path_SelectedPathTest_HMIDevice()
        {
            List<IPathElement> expected = new List<IPathElement>();
            expected.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("bigController"));
            expected.Add(PathElementUtility.Instance().CreateDataItemPathElement("bigTag", "", true));
            expected.Add(PathElementUtility.Instance().CreateDataItemPathElement("bigMember", "", true));
            expected.Add(PathElementUtility.Instance().CreateDataItemPathElement("bigMemberMember", "", true));

            Path target = new Path();
            foreach (IPathElement element in expected)
            {
                target.Add(element);
            }
            List<IPathElement> actual;
            actual = target.SelectedPath;
            int i = 0;
            foreach (IPathElement pathElement in actual)
            {
                Assert.AreEqual(pathElement.DisplayName, expected[i++].DisplayName);
            }
        }

        /// <summary>
        ///A test for Items
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Path_ItemsTest()
        {
            Path target = new Path(); 
            List<string> expected = new List<string>();
            expected.Add("item1");
            expected.Add("item2");
            expected.Add("item3");
            expected.Add("item4");

            foreach (string name in expected)
            {
                target.Add(PathElementUtility.Instance().CreateDataItemPathElement(name, "", true));
            } 
            PathElementObservableCollection actual = target.Items;
            Assert.AreEqual(expected.Count, actual.Count);
            int i = 0;
            foreach (IPathElement pe in actual)
            {
                Assert.AreEqual(pe.DisplayName,expected[i]);
                Assert.AreEqual(pe.HasChildren, false);
                Assert.AreEqual(pe.IsContainer, false);
                i++;

            }
        }

        /// <summary>
        ///A test for Forward
        ///</summary>
        [TestMethod()]
        public void Path_ForwardTest()
        {
            Path target = new Path();
            string expectedCurrent = "current";
            string expectedForward = "forward";
            target.Add(PathElementUtility.Instance().CreateControllerPathElement(expectedCurrent));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(expectedForward, "", true));
            //make the first element a forward element
            target.NavigateBack();

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);
            actual = target.Forward;
            Assert.AreEqual(actual.DisplayName, expectedForward);

        }

        /// <summary>
        ///A test for Forward
        ///</summary>
        [TestMethod()]
        public void Path_ForwardTest_HMIDevice()
        {
            Path target = new Path();
            string expectedCurrent = "current";
            string expectedForward = "forward";
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(expectedCurrent));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(expectedForward, "", true));
            //make the first element a forward element
            target.NavigateBack();

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);
            actual = target.Forward;
            Assert.AreEqual(actual.DisplayName, expectedForward);

        }

        /// <summary>
        ///A test for DataSourceElement
        ///</summary>
        [TestMethod()]
        public void Path_DataSourceElementTest()
        {
            Path target = new Path(); 
            string controller = "myController";
            string program = "myProgram";
            target.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            target.Add(PathElementUtility.Instance().CreateProgramPathElement(program));
            IPathElement actual = target.LastContainerElement;
            Assert.AreEqual(actual.DisplayName, program);
        }

        /// <summary>
        ///A test for Back
        ///</summary>
        [TestMethod()]
        public void Path_BackTest()
        {
            Path target = new Path();
            string expectedCurrent = "current";
            string expectedBack = "back";
            target.Add(PathElementUtility.Instance().CreateControllerPathElement(expectedBack));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(expectedCurrent, "", true));

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);
            actual = target.Back;
            Assert.AreEqual(actual.DisplayName, expectedBack);

        }

        /// <summary>
        ///A test for Back
        ///</summary>
        [TestMethod()]
        public void Path_BackTest_HMIDevice()
        {
            Path target = new Path();
            string expectedCurrent = "current";
            string expectedBack = "back";
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(expectedBack));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(expectedCurrent, "", true));

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);
            actual = target.Back;
            Assert.AreEqual(actual.DisplayName, expectedBack);
        }

        /// <summary>
        ///A test for ActiveElement
        ///</summary>
        [TestMethod()]
        public void Path_ActiveElementTest()
        {
            Path target = new Path();
            IPathElement expected = PathElementUtility.Instance().CreateProgramPathElement("I_am_active");

            target.Add(PathElementUtility.Instance().CreateProgramPathElement(expected.DisplayName));

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName,expected.DisplayName);
            Assert.AreEqual(actual.HasChildren, expected.HasChildren);
            Assert.AreEqual(actual.IsContainer, expected.IsContainer);
            Assert.AreEqual(actual.IsActive,expected.IsActive);
        }

        /// <summary>
        ///A test for SetActive
        ///</summary>
        [TestMethod()]
        public void Path_SetActiveTest()
        {
            Path target = new Path();
            IPathElement expected = PathElementUtility.Instance().CreateProgramPathElement("I_am_active");
            expected.IsActive = false;
            target.Add(expected);

            target.SetActive(expected);
            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expected.DisplayName);
            Assert.AreEqual(actual.HasChildren, expected.HasChildren);
            Assert.AreEqual(actual.IsContainer, expected.IsContainer);
            //active flag is set
            Assert.AreEqual(actual.IsActive, true);
        }

        /// <summary>
        ///A test for Replace
        ///</summary>
        [TestMethod()]
        public void Path_ReplaceTest()
        {
            Path target = new Path();

            target.Add(PathElementUtility.Instance().CreateControllerPathElement(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER));
            IPathElement controller = target.ActiveElement;
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(DIResource.DI_COMMON_RESOURCETYPE_TAG, "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1a", "", true));

            string displayName = "replacedController";
            bool result = target.ReplaceElement(controller, PathElementUtility.Instance().CreateControllerPathElement(displayName));

            Assert.AreEqual(result, true);
            List<IPathElement> selectedList = target.SelectedPath;
            Assert.AreEqual(selectedList.Count, 1);
            Assert.AreEqual(selectedList[0].DisplayName, displayName);
        }

        /// <summary>
        ///A test for Replace
        ///</summary>
        [TestMethod()]
        public void Path_ReplaceTest_HMIDevice()
        {
            Path target = new Path();

            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE));
            IPathElement controller = target.ActiveElement;
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(DIResource.DI_COMMON_RESOURCETYPE_TAG, "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1a", "", true));

            string displayName = "replacedController";
            bool result = target.ReplaceElement(controller, PathElementUtility.Instance().CreateControllerPathElement(displayName));

            Assert.AreEqual(result, true);
            List<IPathElement> selectedList = target.SelectedPath;
            Assert.AreEqual(selectedList.Count, 1);
            Assert.AreEqual(selectedList[0].DisplayName, displayName);
        }

        /// <summary>
        ///A test for RemoveInactiveElements
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Path_RemoveInactiveElementsTest()
        {
            Path target = new Path();
            target.Add(PathElementUtility.Instance().CreateControllerPathElement(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(DIResource.DI_COMMON_RESOURCETYPE_TAG, "", true));
            IPathElement tagElement = target.ActiveElement;
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1a", "", true));
            
            Assert.AreEqual(target.Items.Count, 5);
            Assert.AreEqual(target.ActiveElement.DisplayName, target.ActiveElement.DisplayName);
            target.SetActive(tagElement);
            target.RemoveInactiveElements();
            Assert.AreEqual(target.Items.Count, 2);
            Assert.AreEqual(target.ActiveElement.DisplayName, tagElement.DisplayName);

        }

        /// <summary>
        ///A test for RemoveInactiveElements
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Path_RemoveInactiveElementsTest_HMIDevice()
        {
            Path target = new Path();
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(DIResource.DI_COMMON_RESOURCETYPE_HMIDEVICE));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(DIResource.DI_COMMON_RESOURCETYPE_TAG, "", true));
            IPathElement tagElement = target.ActiveElement;
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1a", "", true));

            Assert.AreEqual(target.Items.Count, 5);
            Assert.AreEqual(target.ActiveElement.DisplayName, target.ActiveElement.DisplayName);
            target.SetActive(tagElement);
            target.RemoveInactiveElements();
            Assert.AreEqual(target.Items.Count, 2);
            Assert.AreEqual(target.ActiveElement.DisplayName, tagElement.DisplayName);

        }

        /// <summary>
        ///A test for NavigateForward
        ///</summary>
        [TestMethod()]
        public void Path_NavigateForwardTest()
        {
            Path target = new Path(); 
            string expectedCurrent = "current";
            string expectedBack = "back";
            target.Add(PathElementUtility.Instance().CreateControllerPathElement(expectedBack));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(expectedCurrent, "", true));

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);
            target.NavigateBack();
            actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedBack);
            target.NavigateForward();
            actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);

        }

        /// <summary>
        ///A test for NavigateForward
        ///</summary>
        [TestMethod()]
        public void Path_NavigateForwardTest_HMIDevice()
        {
            Path target = new Path();
            string expectedCurrent = "current";
            string expectedBack = "back";
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(expectedBack));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(expectedCurrent, "", true));

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);
            target.NavigateBack();
            actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedBack);
            target.NavigateForward();
            actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);

        }

        /// <summary>
        ///A test for NavigateBack
        ///</summary>
        [TestMethod()]
        public void Path_NavigateBackTest()
        {
            Path target = new Path(); 
            string expectedCurrent = "current";
            string expectedBack = "back";
            target.Add(PathElementUtility.Instance().CreateControllerPathElement(expectedBack));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(expectedCurrent, "", true));

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);
            target.NavigateBack();
            actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedBack);
        }

        /// <summary>
        ///A test for NavigateBack
        ///</summary>
        [TestMethod()]
        public void Path_NavigateBackTest_HMIDevice()
        {
            Path target = new Path();
            string expectedCurrent = "current";
            string expectedBack = "back";
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(expectedBack));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(expectedCurrent, "", true));

            IPathElement actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedCurrent);
            target.NavigateBack();
            actual = target.ActiveElement;
            Assert.AreEqual(actual.DisplayName, expectedBack);
        }

        /// <summary>
        ///A test for GetPathElementAfterThisDataSource
        ///</summary>
        [TestMethod()]
        public void Path_GetPathElementAfterThisDataSourceTest()
        {
            Path target = new Path(); 
            string dataSource = "program1";
            string tagName = "myTag";
            target.Add(PathElementUtility.Instance().CreateControllerPathElement(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLER));
            target.Add(PathElementUtility.Instance().CreateProgramPathElement(dataSource));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1", "", true));
            IPathElement actual = target.GetPathElementAfterThisDataSource(dataSource);
            Assert.AreEqual(tagName, actual.DisplayName);
        }

        /// <summary>
        ///A test for GetPathElementAfterThisDataSource
        ///</summary>
        [TestMethod()]
        public void Path_GetPathElementAfterThisDataSourceTest_HMIDevice()
        {
            Path target = new Path();
            string dataSource = "MyHMIDevice";
            string tagName = "myTag";
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(dataSource));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("fielda1", "", true));
            IPathElement actual = target.GetPathElementAfterThisDataSource(dataSource);
            Assert.AreEqual(tagName, actual.DisplayName);
        }

        /// <summary>
        ///A test for getActiveIndex
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Path_getActiveIndexTest()
        {
            Path target = new Path();
            PrivateObject targetPrivate = new PrivateObject(target);
            int expected = 1;
            target.Add(PathElementUtility.Instance().CreateControllerPathElement("activeAgain"));
            target.Add(PathElementUtility.Instance().CreateProgramPathElement("activeNext"));
            int actual = (int)targetPrivate.Invoke("getActiveIndex");
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for getActiveIndex
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void Path_getActiveIndexTest_HMIDevice()
        {
            Path target = new Path();
            PrivateObject targetPrivate = new PrivateObject(target);
            int expected = 1;
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("activeAgain"));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("activeNext", "", false));
            int actual = (int)targetPrivate.Invoke("getActiveIndex");
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for Clear
        ///</summary>
        [TestMethod()]
        public void Path_ClearTest()
        {
            Path target = new Path();
            target.Add(PathElementUtility.Instance().CreateControllerPathElement("tempController"));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("tempTag", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("tempFielda", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("tempFielda1", "", true));
            //now they are here
            Assert.AreEqual(target.Items.Count, 4);
            target.Clear();
            //and then they are gone
            Assert.AreEqual(target.Items.Count, 0);
        }

        /// <summary>
        ///A test for Clear
        ///</summary>
        [TestMethod()]
        public void Path_ClearTest_HMIDevice()
        {
            Path target = new Path();
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("tempController"));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("tempTag", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("tempFielda", "", true));
            target.Add(PathElementUtility.Instance().CreateDataItemPathElement("tempFielda1", "", true));
            //now they are here
            Assert.AreEqual(target.Items.Count, 4);
            target.Clear();
            //and then they are gone
            Assert.AreEqual(target.Items.Count, 0);
        }

        /// <summary>
        ///A test for AddActivePathChangedEventHandler
        ///</summary>
        [TestMethod()]
        public void Path_AddActivePathChangedEventHandlerTest()
        {
            _hasActiveElements = false;
            Path target = new Path();
            target.AddActivePathChangedEventHandler(new System.ComponentModel.PropertyChangedEventHandler(Test_ActivePathChanged));
            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(homeDataItem);
            target.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Add(PathElementUtility.Instance().CreateControllerPathElement("newActive"));
            //see if the event handler was called
            Assert.AreEqual(true,_hasActiveElements);
        }

        /// <summary>
        ///A test for AddActivePathChangedEventHandler
        ///</summary>
        [TestMethod()]
        public void Path_AddActivePathChangedEventHandlerTest_HMIDevice()
        {
            _hasActiveElements = false;
            Path target = new Path();
            target.AddActivePathChangedEventHandler(new System.ComponentModel.PropertyChangedEventHandler(Test_ActivePathChanged));
            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(homeDataItem);
            target.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("newActive"));
            //see if the event handler was called
            Assert.AreEqual(true, _hasActiveElements);
        }

        bool _hasActiveElements = false;
        /// <summary>
        /// method to support PathOC_pe_PropertyChangedTest
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Test_ActivePathChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            ActivePathChangedEventArgs activeArgs = e as ActivePathChangedEventArgs;
            _hasActiveElements = activeArgs.HasActiveElements;
        }

        /// <summary>
        ///A test for Add
        ///</summary>
        [TestMethod()]
        public void Path_AddTest()
        {
            Path target = new Path(); 
            string displayName = "addTest"; 
            bool hasChildren = true;
            bool isContainer = true;
            bool result = target.Add(PathElementUtility.Instance().CreateControllerPathElement(displayName));
            Assert.AreEqual(result, true);

            Assert.AreEqual(displayName, target.ActiveElement.DisplayName);
            Assert.AreEqual(hasChildren, target.ActiveElement.HasChildren);
            Assert.AreEqual(isContainer, target.ActiveElement.IsContainer);
            Assert.AreEqual(true, target.ActiveElement.IsActive);
        }

        /// <summary>
        ///A test for Add
        ///</summary>
        [TestMethod()]
        public void Path_AddTest_HMIDevice()
        {
            Path target = new Path();
            string displayName = "addTest";
            bool hasChildren = true;
            bool isContainer = true;
            bool result = target.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(displayName));
            Assert.AreEqual(result, true);

            Assert.AreEqual(displayName, target.ActiveElement.DisplayName);
            Assert.AreEqual(hasChildren, target.ActiveElement.HasChildren);
            Assert.AreEqual(isContainer, target.ActiveElement.IsContainer);
            Assert.AreEqual(true, target.ActiveElement.IsActive);
        }

     
    }
}
