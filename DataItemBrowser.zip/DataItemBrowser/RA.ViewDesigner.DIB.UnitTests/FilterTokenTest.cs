﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace DataItemBrowserUT
{
    
    
    ///// <summary>
    /////This is a test class for FilterTokenTest and is intended
    /////to contain all FilterTokenTest Unit Tests
    /////</summary>
    //[TestClass()]
    //public class FilterTokenTest
    //{


    //    private TestContext testContextInstance;

    //    /// <summary>
    //    ///Gets or sets the test context which provides
    //    ///information about and functionality for the current test run.
    //    ///</summary>
    //    public TestContext TestContext
    //    {
    //        get
    //        {
    //            return testContextInstance;
    //        }
    //        set
    //        {
    //            testContextInstance = value;
    //        }
    //    }

    //    #region Additional test attributes
    //    // 
    //    //You can use the following additional attributes as you write your tests:
    //    //
    //    //Use ClassInitialize to run code before running the first test in the class
    //    //[ClassInitialize()]
    //    //public static void MyClassInitialize(TestContext testContext)
    //    //{
    //    //}
    //    //
    //    //Use ClassCleanup to run code after all tests in a class have run
    //    //[ClassCleanup()]
    //    //public static void MyClassCleanup()
    //    //{
    //    //}
    //    //
    //    //Use TestInitialize to run code before running each test
    //    //[TestInitialize()]
    //    //public void MyTestInitialize()
    //    //{
    //    //}
    //    //
    //    //Use TestCleanup to run code after each test has run
    //    //[TestCleanup()]
    //    //public void MyTestCleanup()
    //    //{
    //    //}
    //    //
    //    #endregion


    //    /// <summary>
    //    ///A test for Value
    //    ///</summary>
    //    [TestMethod()]
    //    public void FilterToken_ValueTest()
    //    {
    //        ParserToken target = new ParserToken();
    //        string expected = "ffff";
            
    //        target.Value = expected;
    //        string actual = target.Value;
    //        Assert.AreEqual(expected, actual);
    //    }

    //    /// <summary>
    //    ///A test for StartingIndex
    //    ///</summary>
    //    [TestMethod()]
    //    public void FilterToken_StartingIndexTest()
    //    {
    //        ParserToken target = new ParserToken(); 
    //        int expected = 6; 
    //        target.StartingIndex = expected;
    //        int actual = target.StartingIndex;
    //        Assert.AreEqual(expected, actual);
    //    }

    //    /// <summary>
    //    ///A test for ExactMatchValue
    //    ///</summary>
    //    [TestMethod()]
    //    public void FilterToken_ExactMatchValueTest()
    //    {
    //        ParserToken target = new ParserToken();
    //        bool expected = true;
            
    //        target.ExactMatchValue = expected;
    //        bool actual = target.ExactMatchValue;
    //        Assert.AreEqual(expected, actual);
    //    }

    //    /// <summary>
    //    ///A test for IsValueMatchTestContainsDataType
    //    ///</summary>
    //    [TestMethod()]
    //    public void FilterToken_IsValueMatchTestContainsDataType()
    //    {
    //        string fieldValue = "DINT";
    //        ParserToken target = new ParserToken("INT", 4, false);
    //        bool expected = true; 
    //        bool actual;
    //        actual = target.IsValueMatch(fieldValue);
    //        Assert.AreEqual(expected, actual);
    //    }

    //    /// <summary>
    //    ///A test for IsValueMatchTestExactDataType
    //    ///</summary>
    //    [TestMethod()]
    //    public void FilterToken_IsValueMatchTestExactDataType()
    //    {
    //        string fieldValue = "DINT";
    //        ParserToken target = new ParserToken("\"DINT\"", 4, true);
    //        bool expected = true;
    //        bool actual;
    //        actual = target.IsValueMatch(fieldValue);
    //        Assert.AreEqual(expected, actual);
    //    }

    //    /// <summary>
    //    ///A test for IsValueMatchTestContainsName
    //    ///</summary>
    //    [TestMethod()]
    //    public void FilterToken_IsValueMatchTestContainsName()
    //    {
    //        string fieldValue = "Mike";
    //        ParserToken target = new ParserToken("i", 4, false);
    //        bool expected = true;
    //        bool actual;
    //        actual = target.IsValueMatch(fieldValue);
    //        Assert.AreEqual(expected, actual);
    //    }

    //    /// <summary>
    //    ///A test for IsValueMatchTestExactName
    //    ///</summary>
    //    [TestMethod()]
    //    public void FilterToken_IsValueMatchTestExactName()
    //    {
    //        string fieldValue = "Mike";
    //        ParserToken target = new ParserToken("\"Mike\"", 4, true);
    //        bool expected = true;
    //        bool actual;
    //        actual = target.IsValueMatch(fieldValue);
    //        Assert.AreEqual(expected, actual);
    //    }
    //}
}
