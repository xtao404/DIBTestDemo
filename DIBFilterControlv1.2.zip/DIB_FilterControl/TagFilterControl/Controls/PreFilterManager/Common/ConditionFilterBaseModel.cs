﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public class ConditionFilterBaseModel : INotifyPropertyChanged
    {
        private ConditionFilterBase _conditionFilterBase;
        public ConditionFilterBase ConditionFilterBase
        {
            get { return _conditionFilterBase; }
            set
            {
                _conditionFilterBase = value;
                OnPropertyChanged(new PropertyChangedEventArgs("ConditionFilterBase"));
            }
        }

        private int _order;
        public int Order
        {
            get { return _order; }
            set
            {
                _order = value;
                OnPropertyChanged(new PropertyChangedEventArgs("Order"));
            }

        }

        private ObservableCollection<int> _orderItemsSource;
        public ObservableCollection<int> OrderItemsSource
        {
            get { return _orderItemsSource; }
            set
            {
                _orderItemsSource = value;
                OnPropertyChanged(new PropertyChangedEventArgs("OrderItemsSource"));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, e);
            }
        }
    }
}
