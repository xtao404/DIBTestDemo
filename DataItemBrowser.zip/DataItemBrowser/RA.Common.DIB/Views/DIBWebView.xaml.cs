﻿/*************************************************************************************
                                                                     
   ViewE DIBListView
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.ViewModels;
using System.ComponentModel;
using RockwellAutomation.Client.Services.Query.Common;


namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// A WPF Web Browser hosts and navigates between HTML documents. Enables interoperability between WPF managed code and HTML script.
    /// Lets see how much of that we can use.....
    /// Adrian notes: I dont like that WegBrowser is a subclass of ActiveXHost
    /// </summary>
    public partial class DIBWebView : UserControl
    {
        #region Properties/Variables

        private DIBWebViewModel _webViewModel = null;
        private DIBWebViewModel WebViewModel
        {
            get { return (DIBWebViewModel)this.DataContext; }
        }

        #endregion

        #region Startup/Shutdown

        /// <summary>
        /// constructor
        /// </summary>
        public DIBWebView()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {
            this.WebViewModel.PropertyChanged -= new PropertyChangedEventHandler(WebViewModel_PropertyChanged);
            this.WebViewModel.Cleanup();
        }

        private void DIBWebView_Loaded(object sender, RoutedEventArgs e)
        {
            _webViewModel = (DataContext as DIBWebViewModel);
        }

        #endregion

        #region Keyboard/Mouse Events


        private void DIBWebView_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //This doesnt work. Cant seem to get the mouse double click to fire....
            //_isDoubleClickActive = true;
        }

        /// <summary>
        /// Attempt to drill into currently selected Item and give keyboard focus afterwards
        /// </summary>
        public void ProcessKeyboardRequestDrillIn()
        {
            //In the other views, there is already something highlighted (a row in the grid or item in List View).
            //We dont have that here in the Web View as a web view is associated with one DataItemBase representing the current URI.
            //But, we can allow a drill into an forward crumb that we have at this point.

            if (this._webViewModel.Visible != Visibility.Visible)
                return;
            //Find forward crumb and allow drill into it if it exists
            IPathElement forwardDIB = this._webViewModel.Path.Forward;
            if (forwardDIB == null) return;
            DataItemBase targetDIB = forwardDIB.DataItem;
            if (targetDIB == null) return;
            if (!targetDIB.IsStructured) return;
            this._webViewModel.DrillInCommand.Execute(targetDIB);
        }

        /// <summary>
        /// Give Keyboard Focus to the Device View
        /// </summary>
        public void ProcessKeyboardRequestFocus()
        {
            // Dont even attempt this if we are not visible
            if (this.WebViewModel.Visible != Visibility.Visible)
                return;
            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, (Action)(() => this.PrimProcessKeyboardRequestFocus(this)));
        }

        /// <summary>
        /// Attempt to drill out from currently selected Item and give keyboard focus afterwards
        /// </summary>
        public void ProcessKeyboardRequestDrillOut()
        {
            if (this.WebViewModel.Visible != Visibility.Visible) return;
            this.WebViewModel.DrillOutCommand.Execute(null);
        }


        /// <summary>
        /// Give Keyboard Focus
        /// </summary>
        /// <param name="iElement"></param>
        private void PrimProcessKeyboardRequestFocus(IInputElement iElement)
        {
            if (iElement == null) return;
            Keyboard.Focus(iElement);

            this.WebBrowser.Focus();
        }


        private void DIBWebView_GotFocus(object sender, RoutedEventArgs e)
        {
            //if (this.Visibility != Visibility.Visible) return;
            // Do we need to do anything here
        }

        #endregion

        #region Navigation

        private void WebBrowser_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {
            this.WebViewModel.Navigated(e);
        }

        private void WebBrowser_Navigating(object sender, System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            //Ask our view model permission to drill into this URL
            if (!this.WebViewModel.AllowDrillInTo(e))
            {
                e.Cancel = true;
                return;
            }
        }

        private void DIBWebViewUserControl_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (this.DataContext is DIBWebViewModel)
            {
                // This will get called once in dataItemBrowser.xaml.cs>>Initialize 
                this.WebViewModel.PropertyChanged += new PropertyChangedEventHandler(WebViewModel_PropertyChanged);
            }
        }

        //When selected item changes in our view model, we then navigate to that item here
        void WebViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName != "SelectedItem") return;
            DIBListViewItem selectedItem = this.WebViewModel.SelectedItem;
            if (this.WebViewModel.SelectedItem == null) return;

            this.WebBrowser.Navigate(selectedItem.DataItem.CommonLocation);
        }

        #endregion

        private void DIBWebViewUserControl_KeyDown(object sender, KeyEventArgs e)
        {   
            // We need to process ENTER here in PreviewKeyDown since eXced grid doesn't fire the ENTER keypress from KeyDown event
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                this.WebViewModel.DoubleClickSelection();
            }
        }

    }
}
