﻿/* ****************************************************************************
*
*  Copyright 2015 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.DIBQuery;
using System.IO;
using System;
using System.Text;
using System.Collections.Generic;
using System.Reflection;
using System.Windows;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.Views;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    public class DIBClientManager_6_GridView : DIBClientManager
    {
        private DIBWebViewModelForVieweWebBrowsing _webViewModel;
        private string baseAssemblyLocationURIString;       

        #region Startup/Shutdown

        override public void InitializeDIBControlOnStartup(DataItemBrowser dataItemBrowserControl, StringBuilder logger)
        {
            baseAssemblyLocationURIString = "file:\\\\" + Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location); ;
        }
        #endregion

        #region Search

        /// <summary>
        /// Indicate which columns can be used as a filter
        /// </summary>
        /// <returns></returns>
        override public ObservableCollection<CommonControls.FilterType> GetFilterTypes()
        {
            ObservableCollection<CommonControls.FilterType> filterTypes = base.GetFilterTypes();
            filterTypes.Add(new CommonControls.FilterType("RandomNumber", true));
            filterTypes.Add(new CommonControls.FilterType("CreationTime", false)); 
            return filterTypes;
        }

        /// <summary>
        /// Indicate how the search should be performed for a given path
        /// Can either search the data already in the view or perform 
        /// a server side search
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        override public bool ShouldSearchViaQuery(RockwellAutomation.UI.Models.Path path)
        {
            //We want to do server side search only if we are located at c:\Temp
            if (path == null || path.Items.Count < 1) return false;
            if (path.Last.DataItem != null && path.Last.DataItem.CommonLocation.ToLower().Contains("c:\\temp")) return true;
            return false;
        }

        /// <summary>
        /// Perform a server side search
        /// </summary>
        /// <param name="queryConditionConfig"></param>
        /// <param name="dibQueryCache"></param>
        override public void SearchFor(Client.Services.Query.QueryConditionConfig queryConditionConfig, DIBQueryCache dibQueryCache)
        {
            // If the user typed in a search with the name search filter predicate (ex. n:someString) and only has one search filter predicate the search string then recursively 
            //display all the files and folders underneath this "C:\Temp" directory that match the search string.
            if (queryConditionConfig.GetQueryConditionItems[0].GetIdentifier == "DisplayName" && queryConditionConfig.GetQueryConditionItems[0].GetQueryConditionItems.Count == 0)
            {
                string searchstring = queryConditionConfig.GetQueryConditionItems[0].GetValue;
                GetFoldersAndFilesRecursive(dibQueryCache, @"C:\Temp", searchstring);
                return;
            }

            // create a data item displaying to the user what they searched.
            String displayString = String.Empty;
            foreach(RockwellAutomation.Client.Services.Query.QueryConditionItem item in queryConditionConfig.GetQueryConditionItems)
            {
                foreach (RockwellAutomation.Client.Services.Query.QueryConditionItem itemSub in item.GetQueryConditionItems)
                {
                    if (itemSub.GetIdentifier != null && itemSub.GetIdentifier.Trim() != String.Empty)
                        displayString += "(Identifier: " + itemSub.GetIdentifier + " value: " + itemSub.GetValue + " OP: " + itemSub.GetLogicOperator + ") ";
                }
                if (item.GetIdentifier != null && item.GetIdentifier.Trim() != String.Empty)
                    displayString += "(Identifier: " + item.GetIdentifier + " value: " + item.GetValue + " OP: " + item.GetLogicOperator + ") ";
            }

            DataItemBase newDIB = new DataItemBase()
                {
                    CommonName = "You did a server side search: ",
                    CommonDataType = "Some datatype",
                    CommonDescription = displayString,
                    CommonLocation = "Somewhere over the rainbow",
                    CommonRefTargetId = "0",
                    GUITreeViewID = displayString,
                    GUITreeViewParentID = string.Empty,
                    GUISmallImagePath = "C:\\Temp\\Delete\\IconsForMyGenricDIB\\16by16\\folder.png",
                    GUISupportsDrillIn = "false",
                    GUISupportsSelection = "True"
                };
            newDIB.SetStringMapValue("CreationTime", DateTime.Now.ToString());
            dibQueryCache.AddDataItem(newDIB);
        }

        private void GetFoldersAndFilesRecursive(DIBQueryCache dibQueryCache, string dirToBrowse, string searchstring)
        {

            GetFoldersAndFiles(dibQueryCache, dirToBrowse, searchstring, null);

            DirectoryInfo taskDirectory;
            DirectoryInfo[] taskDirectories;

            try
            {
                taskDirectory = new DirectoryInfo(dirToBrowse);
                taskDirectories = taskDirectory.GetDirectories();
            }
            catch (Exception e)
            {
                MessageBox.Show("Unable to browse: '" + dirToBrowse + "'. Reason: " + e.Message, "Error Encountered");
                return;
            }

            foreach (DirectoryInfo dir in taskDirectories)
            {
                GetFoldersAndFiles(dibQueryCache, dir.FullName, searchstring, null);
            }
        }

        #endregion

        #region Path Related Functionality

        /// <summary>
        /// Represent the selected item as a string provided a list of 
        /// DataItemBase instances representing a path
        /// </summary>
        /// <param name="fullPath"></param>
        /// <param name="nameToSelect"></param>
        /// <param name="browserPerspective"></param>
        /// <returns></returns>
        override public string PathToString(List<IPathElement> fullPath, string nameToSelect, DIBViewItemBase.VisualPerspectiveEnum browserPerspective)
        {
            StringBuilder stringBuilder = new StringBuilder();
            if (fullPath.Count > 1) stringBuilder.Append(fullPath[fullPath.Count - 1].DataItem.CommonLocation);
            return stringBuilder.ToString();
        }
        #endregion

        #region Web View Related
        
        /// <summary>
        /// Provide our own custom model for the WebView
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        public override DIBWebViewModel createDIBWebViewModel(DataItemBrowserViewModel dibVM)
        {
            _webViewModel = new DIBWebViewModelForVieweWebBrowsing(dibVM);
            return _webViewModel;
        }
        
        #endregion

        #region DataGridMetaData

        /// <summary>
        /// Provide stream of xml information describing columns
        /// </summary>
        /// <returns></returns>
        override public System.IO.Stream GetGridColumnMetaData()
        {
            System.IO.Stream xmlStream = File.OpenRead("DIBClientManagers/6_GridView/GridColumnsInfo.xml");
            return xmlStream;
        }

        #endregion

        #region Navigation overrides

        override public bool ShouldCloseOnSelect()
        {
            return false;
        }

        override public string GetBreadCrumbCacheKeyFor(DataItemBase dataItem)
        {
            if (dataItem == null) return DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW; 
            return dataItem.CommonLocation;
        }

        /// <summary>
        /// Return a key to the column configuration that should be used to display
        /// the supplied dataItem.  The column configuration is defined in the 
        /// XML column meta data. 
        /// </summary>
        /// <param name="dataItem"></param>
        /// <returns>Key to column configuration</returns>     
        override public string GetResourceTypeString(DataItemBase dataItem)
        {
            if (dataItem != null && dataItem.CommonName.EndsWith("workout-plans"))
                return DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW;
            if (dataItem != null && dataItem.CommonName.EndsWith("Picker"))
                return DIResource.DI_COMMON_RESOURCETYPE_WEB;
            if (dataItem != null && dataItem.CommonDataType == "URI")
                return DIResource.DI_COMMON_RESOURCETYPE_WEB;
            return DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW; 
        }

        /// <summary>
        /// Provide our own custom model for the GridView
        /// </summary>
        /// <param name="dibVM"></param>
        /// <returns></returns>
        override public DIBGridViewModel createDIBGridViewModel(DataItemBrowserViewModel dibVM)
        {
            return new DIBGridViewModelForGridView(dibVM);
        }

        /// <summary>
        /// Return the proper view based on the data that needs to be displayed
        /// </summary>
        /// <param name="resourceType"></param>
        /// <returns></returns>
        override public IDIBDataViewType GetDataViewTypeFor(string resourceType)
        {
            if (resourceType.Equals(DIResource.DI_COMMON_RESOURCETYPE_WEB)) return new DIBDataViewTypeWebView();
            if (resourceType.Equals(ClientDataServices.SearchTags)) return new DIBDataViewTypeSearchGrid();
            return new DIBDataViewTypeDataGrid();
        }

        /// <summary>
        /// Add data to the provided query cache based on the view that is being
        /// drilled into
        /// </summary>
        /// <param name="dataItemToDrillInto"></param>
        /// <param name="queryCache"></param>
        override public void DrillInFor(DataItemBase dataItemToDrillInto, DIBQueryCache queryCache)
        {
            String dirToBrowse;
            String fileToInitiallyHighlight = null;

            if (dataItemToDrillInto == null)
            {
                if (String.IsNullOrWhiteSpace(this.InitialLaunchString))
                    dirToBrowse = "C:\\";
                else
                {
                    dirToBrowse = this.InitialLaunchString;
                    InitialLaunchString = string.Empty;
                    DirectoryInfo testDirectory = new DirectoryInfo(dirToBrowse);
                    if (!testDirectory.Exists)
                    {
                        // The code below allows processing the proper directory when the "dirToBrowse" is actually a file
                        if (File.Exists(dirToBrowse))
                        {
                            string fileDir = Path.GetDirectoryName(dirToBrowse);

                            if (!String.IsNullOrEmpty(fileDir))
                            {
                                fileToInitiallyHighlight = Path.GetFileName(dirToBrowse);
                                dirToBrowse = fileDir;
                            }
                            else
                            {
                                dirToBrowse = "C:\\";
                            }
                        }
                        else
                        {
                            dirToBrowse = "C:\\";
                        }
                    }
                }
            }
            else if (dataItemToDrillInto != null && dataItemToDrillInto.CommonName.EndsWith("Picker"))
            {
                String fieldNameToDrillInto = dataItemToDrillInto.CommonName;
                String locationString = String.Empty;
                DataItemBase newDIB = new DataItemBase();
                newDIB.CommonName = "VIEWE";
                newDIB.CommonDataType = "URI";
                newDIB.CommonDescription = String.Empty;
                if (fieldNameToDrillInto == "ExercisePicker") locationString = "http://www.weighttraining.com/exercises/find"; 
                if (fieldNameToDrillInto == "RecipePicker") locationString = "http://www.calorieking.com/recipes/";
                if (fieldNameToDrillInto == "RockwellViewEJenkinsBuildPicker") locationString = "http://usmkevieweci.mke.ra.rockwell.com:8080/job/vieweimage_BuildFlow_dev_test_branch/";
                if (fieldNameToDrillInto == "RockwellViewESprintPicker") locationString = "http://sharepoint.ra.rockwell.com/AS/CVB/eng/VIEWE/default.aspx";
                newDIB.CommonLocation = locationString;
                newDIB.CommonRefTargetId = string.Empty;
                newDIB.GUITreeViewID = newDIB.CommonLocation;
                newDIB.GUITreeViewParentID = string.Empty;
                newDIB.GUIToolTip = "Drilling into this will open a Web View";
                newDIB.GUISupportsDrillIn = "True";
                newDIB.GUISupportsSelection = "True";

                queryCache.AddDataItem(newDIB);
                return;
            }
            else if (dataItemToDrillInto != null && dataItemToDrillInto.CommonName.EndsWith("workout-plans"))
            {
                GetFoldersAndFiles(queryCache, @"C:\WebViewSamples\ExercisePicker\WorkoutPlans", null, null);
                return;
            }
            else if (dataItemToDrillInto != null && dataItemToDrillInto.CommonDataType == "URI")
            {
                queryCache.AddDataItem(dataItemToDrillInto);
                return;
            }
            else
            {
                dirToBrowse = dataItemToDrillInto.CommonRefTargetId;
            }

            GetFoldersAndFiles(queryCache, dirToBrowse, null, fileToInitiallyHighlight);
        }
        

        private void GetFoldersAndFiles(DIBQueryCache queryCache, String dirToBrowse, String searchString, String fileToInitiallyHighlight)
        {
            DirectoryInfo taskDirectory;
            DirectoryInfo[] taskDirectories;

            try
            {
                taskDirectory = new DirectoryInfo(dirToBrowse);
                taskDirectories = taskDirectory.GetDirectories();
            }
            catch (Exception e)
            {
                MessageBox.Show("Unable to browse: '" + dirToBrowse + "'. Reason: " + e.Message, "Error Encountered");
                return;
            }

            Random rndNumGenerator = new Random();
            foreach (DirectoryInfo dir in taskDirectories)
            {
                if (dir.Name.StartsWith("$")) continue;
                if (searchString != null && !dir.Name.Contains(searchString)) continue;
                DataItemBase newDIB = new DataItemBase();
                newDIB.CommonName = dir.Name;
                newDIB.CommonDataType = "Directory";
                newDIB.CommonDescription = dir.Attributes.ToString();
                newDIB.CommonLocation = dir.FullName;
                newDIB.CommonRefTargetId = dir.FullName;
                newDIB.GUITreeViewID = dir.FullName;
                newDIB.GUITreeViewParentID = string.Empty;
                newDIB.GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\16by16\\folder.png";
                newDIB.GUIToolTip = "Full Path: " + dir.FullName + " Attributes: " + dir.Attributes.ToString();
                newDIB.GUISupportsDrillIn = "True";
                newDIB.GUISupportsSelection = "True";
                newDIB.SetStringMapValue("RandomNumber", rndNumGenerator.Next(1, 1000).ToString());
                newDIB.SetStringMapValue("CreationTime", dir.CreationTime.ToString());
                newDIB.IsStructured = true;
                queryCache.AddDataItem(newDIB);
            }

            FileInfo[] taskFiles = taskDirectory.GetFiles();
            foreach (FileInfo file in taskFiles)
            {
                DataItemBase newDIB = new DataItemBase();
                if (searchString != null && !file.Name.Contains(searchString)) continue;
                newDIB.CommonName = file.Name;
                newDIB.CommonDataType = "File";
                newDIB.CommonDescription = file.Attributes.ToString();
                newDIB.CommonLocation = file.FullName;
                newDIB.CommonRefTargetId = file.FullName;
                newDIB.GUITreeViewID = file.FullName;
                newDIB.GUITreeViewParentID = string.Empty;
                newDIB.GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\16by16\\detail.png";
                newDIB.GUIToolTip = "Full Path: " + file.FullName + " Attributes: " + file.Attributes.ToString();
                newDIB.GUISupportsDrillIn = "False";
                newDIB.GUISupportsSelection = "True";
                newDIB.SetStringMapValue("RandomNumber", rndNumGenerator.Next(1, 1000).ToString());
                newDIB.SetStringMapValue("CreationTime", file.CreationTime.ToString());

                if (fileToInitiallyHighlight != null && fileToInitiallyHighlight.Equals(file.Name, StringComparison.InvariantCultureIgnoreCase))
                {
                    newDIB.GUIIsInitiallyHighlighted = "True";
                }
                queryCache.AddDataItem(newDIB);
            }
        }

        #endregion

    }
}
