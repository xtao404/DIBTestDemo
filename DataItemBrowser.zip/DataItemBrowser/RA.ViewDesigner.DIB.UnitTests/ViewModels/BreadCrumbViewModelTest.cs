using RockwellAutomation.UI.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.Models;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.Views;
using System.Windows.Controls.Primitives;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for BreadCrumbViewModelTest and is intended
    ///to contain all BreadCrumbViewModelTest Unit Tests
    ///</summary>
    [TestClass()]
    public class BreadCrumbViewModelTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for NavigateCommand
        ///</summary>
        [TestMethod()]
        public void BCVM_NavigateCommandTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);

            string parent = "Controller1";
            string selectedItem = "myMember";
            string tag = "myTag";

            dibVM.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(parent));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement pe = dibVM.Path.ActiveElement;
            pe.DataItem = new DataItemBase() { CommonName = pe.DisplayName };

            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(selectedItem, "", true));

            TextCrumb tCrumb = new TextCrumb(pe);
            target.Crumbs.Add(tCrumb);
            target.NavigateCommand.Execute(tCrumb);

            Assert.AreEqual(dibVM.NavPathList[0].DisplayName, parent);
            Assert.AreEqual(dibVM.NavNameToSelect, selectedItem);
        }

        /// <summary>
        ///A test for NavigateCommand including HMIDevice
        ///</summary>
        [TestMethod()]
        public void BCVM_NavigateCommandTest_HMIDevice()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);

            string HMIDevice = "MyHMIDevice";
            string selectedItem = "myMember";
            string tag = "myTag";

            dibVM.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(HMIDevice));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement pe = dibVM.Path.ActiveElement;
            pe.DataItem = new DataItemBase() { CommonName = pe.DisplayName };

            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(selectedItem, "", true));

            TextCrumb tCrumb = new TextCrumb(pe);
            target.Crumbs.Add(tCrumb);
            target.NavigateCommand.Execute(tCrumb);

            Assert.AreEqual(dibVM.NavPathList[0].DisplayName, HMIDevice);
            Assert.AreEqual(dibVM.NavNameToSelect, selectedItem);
        }

        /// <summary>
        ///A test for GetChildrenCommand
        ///</summary>
        [TestMethod()]
        public void BCVM_GetChildrenCommandTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel(); ; 
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM); 

            //initialize the children collection
            string c1 = "Controller1";
            string c2 = "Controller2";

            List<DropArrowItem> children = new List<DropArrowItem>();
            DropArrowItem controller1 = new DropArrowItem();
            controller1.DisplayName = c1;
            controller1.IsBold = true;
            controller1.IsContainer = true;
            children.Add(controller1);

            DropArrowItem controller2 = new DropArrowItem();
            controller2.DisplayName = c2;
            controller2.IsBold = true;
            controller2.IsContainer = true;
            children.Add(controller2);

            dibVM.Children = children;

            //execute the commmand
            target.GetChildrenCommand.Execute(""); //home

            Assert.AreEqual(target.DropArrowChildren[0].DisplayName, c1);
            Assert.AreEqual(target.DropArrowChildren[1].DisplayName, c2);
        }

        /// <summary>
        ///A test for DropListNavigateCommand
        ///</summary>
        [TestMethod()]
        public void BCVM_DropListNavigateCommandTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            string parent = "ControllerA";
            string member = "MemberA";
            string tag = "TagA";

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem(parent);
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            dibVM.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            dibVM.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(parent));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement pe = dibVM.Path.ActiveElement;
            pe.DataItem = new DataItemBase() { CommonName = pe.DisplayName };

            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            DropArrowItem item = new DropArrowItem();
            item.DisplayName = parent;
            item.IsContainer = true;
            item.DataItem = new DataItemBase() { CommonName = pe.DisplayName };

            target.DropListNavigateCommand.Execute(item);

            Assert.AreEqual(dibVM.NavPathList[0].DisplayName, parent);
            Assert.AreEqual(dibVM.NavNameToSelect, "");
        }

        /// <summary>
        ///A test for DropListNavigateCommand including HMIDevice
        ///</summary>
        [TestMethod()]
        public void BCVM_DropListNavigateCommandTest_HMIDevice()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            string HMIDevice = "MyHMIDevice";
            string member = "MemberA";
            string tag = "TagA";

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem(HMIDevice);
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            dibVM.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            dibVM.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(HMIDevice));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement pe = dibVM.Path.ActiveElement;
            pe.DataItem = new DataItemBase() { CommonName = pe.DisplayName };

            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            DropArrowItem item = new DropArrowItem();
            item.DisplayName = HMIDevice;
            item.IsContainer = true;
            item.DataItem = new DataItemBase() { CommonName = pe.DisplayName };

            target.DropListNavigateCommand.Execute(item);

            Assert.AreEqual(dibVM.NavPathList[0].DisplayName, HMIDevice);
            Assert.AreEqual(dibVM.NavNameToSelect, "");
        }

        /// <summary>
        ///A test for DropArrowChildren
        ///</summary>
        [TestMethod()]
        public void BCVM_DropArrowChildrenTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
            ObservableCollection<DropArrowItem> expected = new ObservableCollection<DropArrowItem>();

            DropArrowItem item1 = new DropArrowItem();
            item1.DisplayName = "controllerA1";
            item1.IsContainer = true;
            expected.Add(item1);

            DropArrowItem item2 = new DropArrowItem();
            item1.DisplayName = "controllerA2";
            item1.IsContainer = true;
            expected.Add(item2);

            DropArrowItem item3 = new DropArrowItem();
            item1.DisplayName = "controllerA2";
            item1.IsContainer = true;
            expected.Add(item3);

            ObservableCollection<DropArrowItem> actual=null;
            targetPrivate.SetFieldOrProperty("_dropArrowChildren", expected);
            actual = target.DropArrowChildren;

            Assert.AreEqual(expected[0].DisplayName, actual[0].DisplayName);
            Assert.AreEqual(expected[1].DisplayName, actual[1].DisplayName);
            Assert.AreEqual(expected[2].DisplayName, actual[2].DisplayName);
        }

        /// <summary>
        ///A test for Crumbs
        ///</summary>
        [TestMethod()]
        public void BCVM_CrumbsTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            //prepopulate the path with path elements
            string parent = "ControllerZZ";
            string tag = "TagZZ";

            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
            CrumbsObservableCollection expected = new CrumbsObservableCollection(dibVM.Path);

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            dibVM.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            dibVM.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(parent));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", false));

            CrumbsObservableCollection actual=null;
            targetPrivate.SetFieldOrProperty("_crumbs", expected);
            actual = target.Crumbs;
            
            //first crumb should always be home
            Assert.IsNotNull(expected[0] as HomeCrumb);
            Assert.IsNotNull(expected[1] as MenuCrumb);
            Assert.AreEqual((expected[2] as TextCrumb).DisplayName, ((actual[2] as TextCrumb).DisplayName));
            Assert.AreEqual((expected[3] as TextCrumb).DisplayName, ((actual[3] as TextCrumb).DisplayName));
            Assert.IsNotNull(expected[4] as MenuCrumb);

            Assert.AreEqual(expected[0] as HomeCrumb, actual[0] as HomeCrumb);
            Assert.AreEqual(expected[1] as MenuCrumb, actual[1] as MenuCrumb);
            Assert.AreEqual(expected[2] as TextCrumb, actual[2] as TextCrumb);
            Assert.AreEqual(expected[3] as TextCrumb, actual[3] as TextCrumb);
            Assert.AreEqual(expected[4] as HomeCrumb, actual[4] as HomeCrumb);
        }

        /// <summary>
        ///A test for Crumbs with HMIDevice
        ///</summary>
        [TestMethod()]
        public void BCVM_CrumbsTest_HMIDevice()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            //prepopulate the path with path elements
            string HMIDevice = "MyHMIDevice";
            string tag = "TagZZ";

            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
            CrumbsObservableCollection expected = new CrumbsObservableCollection(dibVM.Path);

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            dibVM.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            dibVM.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(HMIDevice));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", false));

            CrumbsObservableCollection actual = null;
            targetPrivate.SetFieldOrProperty("_crumbs", expected);
            actual = target.Crumbs;

            //first crumb should always be home
            Assert.IsNotNull(expected[0] as HomeCrumb);
            Assert.IsNotNull(expected[1] as MenuCrumb);
            Assert.AreEqual((expected[2] as TextCrumb).DisplayName, ((actual[2] as TextCrumb).DisplayName));
            Assert.AreEqual((expected[3] as TextCrumb).DisplayName, ((actual[3] as TextCrumb).DisplayName));
            Assert.IsNotNull(expected[4] as MenuCrumb);

            Assert.AreEqual(expected[0] as HomeCrumb, actual[0] as HomeCrumb);
            Assert.AreEqual(expected[1] as MenuCrumb, actual[1] as MenuCrumb);
            Assert.AreEqual(expected[2] as TextCrumb, actual[2] as TextCrumb);
            Assert.AreEqual(expected[3] as TextCrumb, actual[3] as TextCrumb);
            Assert.AreEqual(expected[4] as HomeCrumb, actual[4] as HomeCrumb);
        }

        /// <summary>
        ///A test for NotifyPropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void BCVM_NotifyPropertyChangedTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
 
            string propertyName = "BooBoo";

            targetPrivate.Invoke("add_PropertyChanged", new System.ComponentModel.PropertyChangedEventHandler(CatchPropertyChanged));
            targetPrivate.Invoke("NotifyPropertyChanged", propertyName);

            Assert.AreEqual(propertyName, PropertyChangedName);
        }

        /// <summary>
        ///A test for BreadCrumbViewModel Constructor
        ///</summary>
        [TestMethod()]
        public void BCVM_BreadCrumbViewModelConstructorTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
            Assert.AreEqual(dibVM, targetPrivate.GetFieldOrProperty("_dibViewModel"));
        }

        /// <summary>
        ///A test for BreadCrumbViewModel Constructor
        ///</summary>
        [TestMethod()]
        public void BCVM_TestView_BreadCrumbGrid()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            
            ////prepopulate the path with path elements
            string parent = "ControllerZZ";
            string tag = "TagZZ";
            dibVM.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(parent));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
            CrumbsObservableCollection expected = new CrumbsObservableCollection(dibVM.Path);
            CrumbsObservableCollection actual = null;
            targetPrivate.SetFieldOrProperty("_crumbs", expected);
            actual = target.Crumbs;
            
            BreadCrumbsGrid bcGrid = new BreadCrumbsGrid();
            DropArrowItem daiItem = new DropArrowItem();
            BreadCrumbsView bcView = new BreadCrumbsView();

            //initialize the children collection
            string c1 = "Controller1";
            string c2 = "Controller2";

            List<DropArrowItem> children = new List<DropArrowItem>();
            DropArrowItem controller1 = new DropArrowItem();
            controller1.DisplayName = c1;
            controller1.IsBold = true;
            controller1.IsContainer = true;
            children.Add(controller1);

            DropArrowItem controller2 = new DropArrowItem();
            controller2.DisplayName = c2;
            controller2.IsBold = true;
            controller2.IsContainer = true;
            children.Add(controller2);

            dibVM.Children = children;

            BreadCrumbViewModel bcViewModel = new BreadCrumbViewModel(dibVM);
            
            daiItem.DisplayName = "DropArrowItem 1";
            bcGrid.BackwardCrumbsMenuChildren.Add(daiItem);
            daiItem.DisplayName = "DropArrowItem 2";
            bcGrid.BackwardCrumbsMenuChildren.Add(daiItem);
            Assert.AreEqual(2, bcGrid.BackwardCrumbsMenuChildren.Count);

            // calling this before the available width is set tests a null path for code coverage.
            bcGrid.UpdateCrumbSizing(false);
            bcGrid.AvailableWidth = 25.0;
            bcGrid.UpdateCrumbSizing(false);
            Assert.AreEqual(25.0, bcGrid.AvailableWidth);
        }

        /// <summary>
        ///A test for BreadCrumbViewModel Constructor with HMIDevice
        ///</summary>
        [TestMethod()]
        public void TestView_BreadCrumbGrid_HMIDevice()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();

            ////prepopulate the path with path elements
            string HMIDevice = "MyHMIDevice";
            string tag = "TagZZ";
            dibVM.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(HMIDevice));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
            CrumbsObservableCollection expected = new CrumbsObservableCollection(dibVM.Path);
            CrumbsObservableCollection actual = null;
            targetPrivate.SetFieldOrProperty("_crumbs", expected);
            actual = target.Crumbs;

            BreadCrumbsGrid bcGrid = new BreadCrumbsGrid();
            DropArrowItem daiItem = new DropArrowItem();
            BreadCrumbsView bcView = new BreadCrumbsView();

            //initialize the children collection
            string c1 = "Controller1";
            string c2 = "Controller2";

            List<DropArrowItem> children = new List<DropArrowItem>();
            DropArrowItem controller1 = new DropArrowItem();
            controller1.DisplayName = c1;
            controller1.IsBold = true;
            controller1.IsContainer = true;
            children.Add(controller1);

            DropArrowItem controller2 = new DropArrowItem();
            controller2.DisplayName = c2;
            controller2.IsBold = true;
            controller2.IsContainer = true;
            children.Add(controller2);

            dibVM.Children = children;

            BreadCrumbViewModel bcViewModel = new BreadCrumbViewModel(dibVM);

            daiItem.DisplayName = "DropArrowItem 1";
            bcGrid.BackwardCrumbsMenuChildren.Add(daiItem);
            daiItem.DisplayName = "DropArrowItem 2";
            bcGrid.BackwardCrumbsMenuChildren.Add(daiItem);
            Assert.AreEqual(2, bcGrid.BackwardCrumbsMenuChildren.Count);

            // calling this before the available width is set tests a null path for code coverage.
            bcGrid.UpdateCrumbSizing(false);
            bcGrid.AvailableWidth = 25.0;
            bcGrid.UpdateCrumbSizing(false);
            Assert.AreEqual(25.0, bcGrid.AvailableWidth);
        }

        /// <summary>
        /// Same as the BreadCrumbGridTest with a Controller
        /// </summary>
        [TestMethod()]
        public void BreadCrumbViewModelTest__BreadCrumbView_Controller_ContextMenuOpen()
        {
            //ARRANGE
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel(); 
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);

            string parent = "Controller1";
            string tag = "myTag";

            //set up Path and DropArrowItem in dibVM
            dibVM.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(parent));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", false));
            DropArrowItem item1 = new DropArrowItem { DisplayName = parent };
            DropArrowItem item2 = new DropArrowItem { DisplayName = tag };
            dibVM.Children.Add(item1);
            dibVM.Children.Add(item2);

            BreadCrumbsView mygrid = new BreadCrumbsView();
            mygrid.DataContext = target;
            ToggleButton myToggleButton = new ToggleButton();
            myToggleButton.ContextMenu = new System.Windows.Controls.ContextMenu();
            //datacontext of the togglebutton should be of type ACrumbWithPathElement
            HomeCrumb homeCrumb = new HomeCrumb(PathElementUtility.Instance().CreateHomePathElement(""));
            myToggleButton.DataContext = homeCrumb;
            myToggleButton.IsChecked = true;

            //ACT
            mygrid.ShowContextMenuCommand.Execute(myToggleButton);

            //ASSERT
            Assert.IsTrue((myToggleButton.ContextMenu.IsOpen));
        }

        /// <summary>
        /// Same as the BreadCrumbGridTest with an HMIDevice
        /// </summary>
        [TestMethod()]
        public void BreadCrumbViewModelTest__BreadCrumbView_HMIDevice_ContextMenuOpen()
        {
            //ARRANGE
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);

            string HMIDevice = "MyHMIDevice";
            string tag = "myTag";

            dibVM.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(HMIDevice));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", false));
            DropArrowItem item1 = new DropArrowItem { DisplayName = HMIDevice };
            DropArrowItem item2 = new DropArrowItem { DisplayName = tag };
            dibVM.Children.Add(item1);
            dibVM.Children.Add(item2);

            BreadCrumbsView mygrid = new BreadCrumbsView();
            mygrid.DataContext = target;
            ToggleButton myToggleButton = new ToggleButton();
            myToggleButton.ContextMenu = new System.Windows.Controls.ContextMenu();
            //datacontext of the togglebutton should be of type ACrumbWithPathElement
            HomeCrumb homeCrumb = new HomeCrumb(PathElementUtility.Instance().CreateHomePathElement(""));
            myToggleButton.DataContext = homeCrumb;            
            myToggleButton.IsChecked = true;

            //ACT
            mygrid.ShowContextMenuCommand.Execute(myToggleButton);

            //ASSERT
            Assert.IsTrue((myToggleButton.ContextMenu.IsOpen));

        }

        /// <summary>
        /// Edge case scenario
        /// When the DIB is opened in the DTC the HMIDevice type is excluded and 
        /// if the user has not configured any controller references for the project
        /// there will not be any controllers either. 
        /// In this scenario the DropArrowChildren should be zero.
        /// </summary>
        [TestMethod()]
        public void BreadCrumbViewModelTest_GetChildrenCommand_NoControllersNoHMIDevice_NoChildren()
        {
            
            //ARRANGE
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            BreadCrumbViewModel target = new BreadCrumbViewModel(dibVM);
            
            //datacontext of the togglebutton should be of type ACrumbWithPathElement
            HomeCrumb homeCrumb = new HomeCrumb(PathElementUtility.Instance().CreateHomePathElement(""));

            //ACT
            target.GetChildrenCommand.Execute(homeCrumb);

            //ASSERT
            Assert.IsTrue(target.DropArrowChildren.Count == 0, "There should not be any DropArrowChildren in the BreadCrumbViewModel.");

        }


        private string _propertyChangedName = string.Empty;
        public string PropertyChangedName
        {
            get { return _propertyChangedName; }
            internal set { _propertyChangedName = value; }
        }

        void CatchPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            PropertyChangedName = e.PropertyName;
        }
    }
}
