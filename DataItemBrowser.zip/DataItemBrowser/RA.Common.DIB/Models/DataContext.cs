﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System.Collections.Generic;
using System.Linq;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// This class takes a DataItemBrowserContext and processes into the object needed 
    /// for data context processing. These objects are a root, include and excludechildrenfrom paths.
    /// </summary>
    public class DataContext
    {
        /// <summary>
        /// processing complete
        /// </summary>
        /// <param name="error"></param>
        public delegate void ProcessDataContextComplete(string error);


        public static readonly string PROGRAMSFOLDERKEY = "_" + DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS;
        public static readonly string DATALOGSFOLDERKEY = DIResource.DI_COMMON_RESOURCETYPE_SYSTEM_DEFINED_FOLDER_DELIMITER + DIResource.DI_COMMON_RESOURCETYPE_DATALOGS;

        #region constructor
        /// <summary>
        /// constructor
        /// </summary>
        public DataContext() 
        {
            _rootPath = new ContextPath(new List<DataItemBase>());
            _includePath = new ContextPath(new List<DataItemBase>());
             _excludeAllChildrenFromPath = new ContextPath(new List<DataItemBase>());             
        }

        /// <summary>
        /// process the data item browser context to determine the root and if items are excluded
        /// </summary>
        /// <param name="dataServices">reference to the ClientDataServices object.</param>
        /// <param name="dibContext">data item browser context</param>
        /// <param name="callback"></param>
        public void ProcessDataContext(ClientDataServices dataServices, DataItemBrowserContext dibContext, ProcessDataContextComplete callback)
        {

            _dataServices = dataServices;
            DisplayMetaData = dibContext.DisplayMetaData;
            //exclude all children from root
            ExcludeAllChildrenFromRoot = dibContext.ExcludeAllChildrenFromRoot;
            //filter definition
            FilterDefinition = dibContext.FilterDefinition;

            ExcludeAllChildrenOfType = dibContext.ExcludeAllChildrenOfType;
            ExcludeAllOfType = dibContext.ExcludeAllOfType;
            IncludeAllOfType = dibContext.IncludeAllOfType;
            
            //process the include path first, it is most like the longest path and it will contain
            //part of the exclude path and maybe the root path too. 
            ProcessIncludePath(dibContext.IncludePath, (error) =>
            {
                if (error.Length > 0)
                    error = "ProcessIncludePath- " + error;
                ProcessExcludeAllChildrenFromPath(dibContext.ExcludeAllChildrenFromPath, (excludeError) =>
                {
                    if (excludeError.Length > 0)
                        error += "; ProcessExcludePath- " + excludeError;
                    ProcessRootPath(dibContext.RootPath, dibContext.RootNavIntoFolder, (rootError) =>
                    {
                        //set _isHMIDeviceTypeIncluded after processing the paths, because the queryCondition is affected
                        _isHMIDeviceTypeIncluded = ExcludeAllOfType != DataItemBrowserContext.ExcludeAllOfTypeEnum.HMIDevice;
                        if (rootError.Length > 0)
                            error += "ProcessRootPath- " + rootError;
                        if (callback != null)
                            callback(error);
                    });
                });
            });

        }
        #endregion constructor

        #region private members
        //DataContext members
        private bool _displayMetaData = true;
        private bool _excludeAllChildrenFromRoot = false;
        private ContextPath _rootPath = null;
        private DataItemBrowserContext.NavToFolderEnum _rootNavIntoFolder = DataItemBrowserContext.NavToFolderEnum.Nav_NoAction;
        private ContextPath _includePath = null;
        private ContextPath _excludeAllChildrenFromPath = null;
        private ClientDataServices _dataServices = null;
        private DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum _excludeAllChildrenOfType = DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.None;
        private DataItemBrowserContext.ExcludeAllOfTypeEnum _excludeAllOfType = DataItemBrowserContext.ExcludeAllOfTypeEnum.None;
        private DataItemBrowserContext.IncludeAllOfTypeEnum _includeAllOfType = DataItemBrowserContext.IncludeAllOfTypeEnum.None;

        //it is the saved error from recursive calls to GetPathItem
        private string _getPathItemsError = string.Empty;
        #endregion private members

        #region public  prooperties
        /// <summary>
        /// exclude all children from root property
        /// </summary>
        public bool ExcludeAllChildrenFromRoot
        {
            get { return _excludeAllChildrenFromRoot; }
            set { _excludeAllChildrenFromRoot = value; }
        }
               
        /// <summary>
        /// Display MetaData property
        /// </summary>
        public bool DisplayMetaData
        {
            get { return _displayMetaData; }
            set { _displayMetaData = value; }
        }
        
        /// <summary>
        /// root path dataitems
        /// </summary>
        /// <returns>ContextPath</returns>
        public ContextPath RootPath
        {
            get { return _rootPath; }
            set { _rootPath = value; }
        }
        /// <summary>
        /// navigate into root folder enumeration
        /// </summary>
        public DataItemBrowserContext.NavToFolderEnum RootNavIntoFolder
        {
            get { return _rootNavIntoFolder; }
            set { _rootNavIntoFolder = value; }
        }
        /// <summary>
        /// include path dataitems
        /// </summary>
        /// <returns>ContextPath</returns>
        public ContextPath IncludePath
        {
            get { return _includePath; }
            set { _includePath = value; }
        }
        /// <summary>
        /// exclude all children from path dataitems
        /// </summary>
        public  ContextPath ExcludeAllChildrenFromPath
        {
            get { return _excludeAllChildrenFromPath; }
            set { _excludeAllChildrenFromPath = value; }
        }

        /// <summary>
        /// exclude all children from path dataitems
        /// </summary>
        public SearchFilterDefinition FilterDefinition
        {
            get;
            set;
        }

        //type based properties
        /// <summary>
        /// exclude all children of type
        /// </summary>
        public DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum ExcludeAllChildrenOfType
        {
            get { return _excludeAllChildrenOfType; }
            set { _excludeAllChildrenOfType = value; }
        }

        /// <summary>
        /// exclude all of type
        /// </summary>
        public DataItemBrowserContext.ExcludeAllOfTypeEnum ExcludeAllOfType
        {
            get { return _excludeAllOfType; }
            set { _excludeAllOfType = value; }
        }

        /// <summary>
        /// include all of type
        /// </summary>
        public DataItemBrowserContext.IncludeAllOfTypeEnum IncludeAllOfType
        {
            get { return _includeAllOfType; }
            set { _includeAllOfType = value; }
        }
       
        #endregion public  prooperties
        #region public methods
        /// <summary>
        /// has a root path
        /// </summary>
        /// <returns>true if rootPath is set</returns>
        public bool HasRoot()
        {
            if (RootPath.DataItemList.Count > 0 && RootPath.DataItemList[0] != null)
                return true;
            return false;
        }
        /// <summary>
        /// has an include path
        /// </summary>
        /// <returns>true if an include path is set.</returns>
        public bool HasInclude()
        {
            if (IncludePath.DataItemList.Count > 0 && IncludePath.DataItemList[0] != null)
                return true;
            return false;
        }
        /// <summary>
        /// has an exlcude all children path
        /// </summary>
        /// <returns>true if exclude all children path is set</returns>
        public bool HasExcludeAllChildrenPath ()
        {
            if (ExcludeAllChildrenFromRoot || 
                (ExcludeAllChildrenFromPath.DataItemList.Count > 0 && 
                ExcludeAllChildrenFromPath.DataItemList[0] != null))
                return true;

            return false;
        }
        
        /// <summary>
        /// Is type dataLog included
        /// </summary>
        /// <returns>true if included all datalogs</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public bool IsDataLogTypeIncluded()
        {
            // Uncomment following lines after R1 releases
                //if (ExcludeAllOfType == DataItemBrowserContext.ExcludeAllOfTypeEnum.DataLogs ||
                //    (this.ExcludeAllChildrenOfType == DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller &&
                //    this.IncludeAllOfType != DataItemBrowserContext.IncludeAllOfTypeEnum.DataLogs))
                //    return false;

                //return true;

            // Untill R1, we do not want DataLogs to be displayed
            return false;
        }

        private bool _isHMIDeviceTypeIncluded = true;

        /// <summary>
        /// Is type HMI device included
        /// </summary>
        /// <returns>true if exclude all HMI Devices</returns>
        public virtual bool IsHMIDeviceTypeIncluded()
        {
            return _isHMIDeviceTypeIncluded;
        }

        /// <summary>
        /// is program type included
        /// </summary>
         /// <returns>all programs included</returns>
        public bool IsProgramTypeIncluded()
        {
            //since we cannot include program type if children of a controller are exclude there cannot be programs
            if (ExcludeAllChildrenOfType == DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                return false;
            return true;

        }

        /// <summary>
        /// is tags and properties type included
        /// </summary>
        /// <returns>all programs included</returns>
        public bool IsTagsAndPropertiesTypeIncluded()
        {
            //since we cannot include tags and properties type if children of a controller are exclude there cannot be tags and properties
            if (ExcludeAllChildrenOfType == DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.Controller)
                return false;
            return true;

        }
        /// <summary>
        /// is the program included
        /// </summary>
        /// <param name="name">name of the program</param>
        /// <returns>the program is included</returns>
        public bool IsProgramPathIncluded(Path path, string name)
        {
            //have the children been excluded with an include path?
            if (HasExcludeAllChildrenPath() && HasInclude())
            {
                //get the dataitems from the path
                List<DataItemBase> pathItems = new List<DataItemBase>();
                foreach (IPathElement pe in path.Items)
                {
                    HomePathElement homePE = pe as HomePathElement;
                    if (homePE != null)
                    {
                        if (homePE.DataItem != null)
                        {
                            //get all the dataitems in the home path
                            foreach (DataItemBase dib in homePE.DataItemList)
                                pathItems.Add(dib);
                        }
                    }
                    else
                        pathItems.Add(pe.DataItem);
                }

                //does the include path matches the path passed in
                if ((string.Compare(name, IncludePath.DataItemList.Last().CommonName) == 0) &&
                        IncludePath.DataItemList.Count == pathItems.Count+1)
                    return true;

                //does the path match the exclude path,  we can assume that the exclude path is
                //part of the include path becasue the DataItemBrowserContext ensure this is true.
                if (DoThePathsMatch(pathItems, this.ExcludeAllChildrenFromPath.DataItemList))
                    return false;
          
                
            }
            return true;
            

        }

        /// <summary>
        /// Does the path item collection equal the data context path
        /// </summary>
        /// <param name="pathItems">path items collection</param>
        /// <param name="contextItems">dataitem context list</param>
        /// <returns></returns>
        private static bool DoThePathsMatch(List<DataItemBase> pathItems, List<DataItemBase> contextItems)
        {
            //no path elements or is the context path one less than the path items
            if (pathItems.Count == 0 || pathItems.Count != contextItems.Count+1)
                return true;
     
            int index = 0;
            //iterate through the smaller list and compare names
            foreach (DataItemBase dib in contextItems)
            {
                if (string.Compare(dib.CommonName, pathItems[index].CommonName) != 0)
                        return false;                    
                index++;
            }
            return true;
     

        }
               
        /// <summary>
        /// copy items from include or exclude path items that match the root path
        /// </summary>
        /// <param name="rootPath"></param>
        /// <param name="index"></param>
        public void CopyToRoot(List<string> rootPath, ref int index)
        {
            
            //see if we can copy the include path items to root path items
            CopyPathItems(rootPath, _includePath.DataItemList, RootPath.DataItemList,ref index);
            //see if we can use the exclude path items to theroot path items
            if (index < rootPath.Count)
                CopyPathItems(rootPath, _excludeAllChildrenFromPath.DataItemList, RootPath.DataItemList,ref index);
            
        }
        /// <summary>
        /// copy items from include path items that match the exclude path
        /// </summary>
        /// <param name="strExcludePath"></param>
        /// <param name="index"></param>
        public void CopyToExclude(List<string> strExcludePath, ref int index)
        {
            //see if we can copy the include path items to exlcude path items
            CopyPathItems(strExcludePath, _includePath.DataItemList, _excludeAllChildrenFromPath.DataItemList, ref index);
        }
        #endregion public methods
        #region private methods

     
        /// <summary>
        /// this method will copy items from pathItems to finalPathItems if the names match
        /// </summary>
        /// <param name="strPath">list of path item names</param>
        /// <param name="pathItems">the copy from path items list</param>
        /// <param name="resultPathItems">the copy to path items</param>
        /// <param name="index">current index to strPath</param>
        /// <returns>same value as the index parameter</returns>
        private static int CopyPathItems(List<string> strPath, List<DataItemBase> pathItems, List<DataItemBase> resultPathItems, ref int index)
        {
            //process all items that have been already transfered
            while (index < strPath.Count)
            {
                //see if the string path is in path items and transfer it 
                if (pathItems.Count > index && pathItems[index] != null &&
                    strPath[index] == pathItems[index].CommonName)
                {
                    resultPathItems.Add(pathItems[index]);
                    index++;
                }
                else
                    break;
            }

            return index;
        }

        

        /// <summary>
        /// process the include path into an include context path
        /// </summary>
        /// <param name="strIncludePath">include path as a string array</param>
        /// <param name="callback">the callback after the query has completed</param>
        private void ProcessIncludePath(List<string> strIncludePath, DataLoadComplete callback)
        {            
            //process include path 
            GetPathItems(null, strIncludePath, IncludePath.DataItemList, 0, (error) =>
            {
                if (IncludePath.DataItemList.Count == 0)
                    IncludePath.DataItemList.Add(null);
                //Finish by calling the callback provided by the caller of this method
                if (callback != null)
                    callback(error);
            });

        }

        /// <summary>
        /// process exclude path string into exclude context path
        /// </summary>
        /// <param name="strExcludeAllChildrenFromPath">exclude path string array</param>
        /// <param name="callback">callback after the query has completed</param>
        private void ProcessExcludeAllChildrenFromPath(List<string> strExcludeAllChildrenFromPath, DataLoadComplete callback)
        {            
            int index = 0;
            CopyToExclude(strExcludeAllChildrenFromPath, ref index);
            
            //process remaining exclude items
            this._getPathItemsError = string.Empty;
            GetPathItems(null, strExcludeAllChildrenFromPath, ExcludeAllChildrenFromPath.DataItemList, index, (error) =>
            {                
                if (ExcludeAllChildrenFromPath.DataItemList.Count == 0)
                    ExcludeAllChildrenFromPath.DataItemList.Add(null);
                //Finish by calling the callback provided by the caller of this method
                if (callback != null)
                    callback(error);
            });


        }
        /// <summary>
        /// process the root path to get root context path
        /// </summary>
        /// <param name="strRootPath">root path string array </param>
        /// <param name="rootNavIntoFolder">enumeration defining whether we want to navigate into the tags and properties folder</param>
        /// <param name="callback">callback after the query has completed</param>
        private void ProcessRootPath(List<string> strRootPath, DataItemBrowserContext.NavToFolderEnum rootNavIntoFolder, DataLoadComplete callback)
        {
            RootNavIntoFolder = rootNavIntoFolder;            

            int index = 0;
            CopyToRoot(strRootPath, ref index);

            //process remaining root items
            this._getPathItemsError = string.Empty;
            GetPathItems(null, strRootPath, RootPath.DataItemList, index, (error) =>
            {
                //see if we need to add a tags an properties item
                UUID lastResourceId = null;
                

                //if we have root navigate into tags and properties folder and we have a root item
                if (rootNavIntoFolder == DataItemBrowserContext.NavToFolderEnum.Nav_IntoTagsProps &&
                    RootPath.DataItemList.Count > 0)
                {
                    lastResourceId = RootPath.DataItemList.Last().GetResourceTypeAsUUID();
                    //if the last rootitem is a controller or HMI device then add the tags and properties dataitem to the rootitems
                    if (DIResource.IsResourceTypeControllerOrHMIDevice(RootPath.DataItemList.Last()))
                        RootPath.DataItemList.Add(DIResource.DIB_TagsAndProps);
                  
                }
                //since we inject the programs folder it cannot be the last item, so remove it
                if (ResourceBase.IsEqual(lastResourceId, TypeIdentifiers.ResourceType_Programs))
                    RootPath.DataItemList.Remove(RootPath.DataItemList.Last());
                if (RootPath.DataItemList.Count == 0)
                    RootPath.DataItemList.Add(null);
                
                //Finish by calling the callback provided by the caller of this method
                if (callback != null)
                    callback(error);
            });

        }

        /// <summary>
        /// get the path DataItems associated with the item names list
        /// </summary>
        /// <param name="parentItem">parent data item</param>
        /// <param name="itemNames">list of item names</param>
        /// <param name="dataItems">returned data item list</param>
        /// <param name="ndx">current index int item names</param>
        /// <param name="callback">callback method</param>
        private void GetPathItems(DataItemBase parentItem,
                                    List<string> itemNames,
                                    List<DataItemBase> dataItems,
                                    int ndx,
                                    DataLoadComplete callback)
        {          
            //return when the last name is processed
            if (ndx >= itemNames.Count)
            {                
                //Finish by calling the callback provided by the caller of this method
                if (callback != null)
                    callback(_getPathItemsError);
            }
            else
            {
                _dataServices.DrillIn(parentItem, (error) =>
                {
                    if (error.Length == 0)
                    {
                        DataItemBase dib = null;
                        string name = itemNames[ndx];
                        //see if the current item is a Programs folder
                        if (string.Compare(name, PROGRAMSFOLDERKEY) == 0)
                        {
                            dib = DIResource.DIB_Programs.DeepCopy();
                            //give the folder the parent dataitem ID
                            dib.CommonID = dataItems.Last().CommonID;
                        }
                        else if (this.IsDataLogTypeIncluded() && string.Compare(name, DATALOGSFOLDERKEY) == 0)
                        {
                            dib = DIResource.DIB_DataLogs.DeepCopy();
                            dib.CommonID = parentItem.CommonID;
                            // Remove all other tokens after @DataLogs. We dont want to any other drilling here because you cannot currently drill into data logs anyway.
                            // In R2 drilling into Datalogs is scheduled be required fuctionality.
                            if (itemNames.Count > ndx + 1)
                                itemNames.RemoveRange(ndx + 1, itemNames.Count - (ndx + 1));
                        }
                        else
                            dib = ndx == 0 ? _dataServices.GetDeviceItemByName(name) : _dataServices.GetDataItemByName(name);
                        if (dib != null)
                        {
                            dataItems.Add(dib);

                            // Traverse to the next level
                            GetPathItems(dib, itemNames, dataItems, ++ndx, callback);
                        }
                        else
                        {
                            //this is not an error it is just that we did not find this path item in DibQuery
                            //_getPathItemsError = "Item not found: " + name;
                            ndx = itemNames.Count;
                            GetPathItems(null, itemNames, dataItems, ndx, callback);
                        }
                    }
                    else
                    {
                        //pass the error up and set the index so we will exit
                        _getPathItemsError = error;
                        ndx = itemNames.Count;
                        GetPathItems(null, itemNames, dataItems, ndx, callback);

                    }

                });
                

            }
    #endregion private methods
        }
        
    }
}
