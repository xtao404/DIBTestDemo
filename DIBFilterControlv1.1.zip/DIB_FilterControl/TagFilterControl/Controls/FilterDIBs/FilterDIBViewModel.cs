﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using TagFilterControl.Common;
using TagFilterControl.DIBClientManagers.DataGridViewSimple;
using TagFilterControl.UserControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace TagFilterControl.Controls
{
    public class FilterDIBViewModel : BaseViewModel
    {
        public FilterDIB _FilterDIB { get; set; }

        public FilterDIBViewModel(FilterDIB filterDIB)
        {
            this._FilterDIB = filterDIB;
        }

        private DataItemBase selectDataItemBase;
        public DataItemBase SelectDataItemBase
        {
            get { return selectDataItemBase; }
            set
            {
                selectDataItemBase = value;
                this.RaisePropertyChangedEvent(() => this.SelectDataItemBase);
            }
        }
    }
}
