/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references 

using System.Linq;
using System.Windows.Input;
using System.ComponentModel;
using System.Windows.Controls;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Windows;
using System;

#endregion

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// bread crumbs view model class, supports INotifyPropertyChanged
    /// </summary>
    public class BreadCrumbViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// holds a pointer to the data item browser view model
        /// </summary>
        private IDataItemBrowserViewModel _dibViewModel = null;

        /// <summary>
        /// crumbs observable collection property
        /// </summary>
        private CrumbsObservableCollection _crumbs = null;
        public CrumbsObservableCollection Crumbs
        {
            get { return _crumbs; }
            internal set { _crumbs = value; }
        }
        /// <summary>
        /// droparrow navigations children collection
        /// </summary>
        private ObservableCollection<DropArrowItem> _dropArrowChildren = new ObservableCollection<DropArrowItem>();
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",Justification = "called by XAML")]
        public ObservableCollection<DropArrowItem> DropArrowChildren
        {
            get { return _dropArrowChildren; }
            internal set 
            {
                _dropArrowChildren = value;
            }
        }
        /// <summary>
        /// Crumb navigation command
        /// </summary>
        private SimpleCommand _navigateCommand = null;
        public ICommand NavigateCommand
        {
            get
            {
                if (_navigateCommand == null)
                {
                    _navigateCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                            {
                                // We explicitly cast to a ACrumbWithPathElement
                                ACrumbWithPathElement crumb = x as ACrumbWithPathElement;
                           

                                //Ignore clicks on the last active crumb.  We can't disable the button
                                // in XAML since doing so prevents tooltips from appearing for that item
                                // Note we do allow clicks on the home crumb if there are no items after it
                                // so that the user has a way to refresh the view (to obtain updated
                                // replication error statuses)
                                if (crumb != null && crumb.IsLast && crumb.IsActive && !this._crumbs.HasSearchCrumb() && !(crumb is HomeCrumb))
									return;
									
                                //Use the host crumb if command came in from an overflow menu
                                if(!(crumb is HomeCrumb) && crumb==null)
                                {

									DropArrowItem MenuItem = x as DropArrowItem;
									if(MenuItem!=null)
									    crumb = MenuItem.HostCrumb as TextCrumb;
                                }

                                // If the user clicked a crumb that currently does not exist in the list of crumbs then
                                // the user was quicker than the GUI updates to our crumbs or had a drop down crumb menu open as we changed the contents of that menu.
                                // In either casse, we dont want to process this navigation since it does not represent a current available breadcrumb option
                                if (this._crumbs.IndexOf(crumb) < 0)
                                {
                                    return;
                                }

                                //TODO: this is ugly
                                //If you navigate into a UD, PD or MD collection and highlight an data type item,
                                //when you click on home crumb it will try to append the data type item after the 
                                //home path element, clearing the highlighted item avoids this issue.
                                if (!_dibViewModel.IsTagBrowser())
                                    _dibViewModel.Path.HighlightedElement = null;
                                //Make sure to set the active path element back to the crumb that was clicked
                                // so that any forward crumbs are handled correctly in navigate
                                _dibViewModel.Path.SetActive(crumb.PathElement);
                                
                                _dibViewModel.Navigate(crumb.PathElement.DataItem );
								return;
                            }
                    };
                }

                return _navigateCommand;
            }
        }

        /// <summary>
        /// drop list navigation command
        /// </summary>
        private SimpleCommand _dropListNavigateCommand = null;
        public ICommand DropListNavigateCommand
        {
            get
            {
                if (_dropListNavigateCommand == null)
                {
                    _dropListNavigateCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                            {
                                // get the drop arrow menu item 
                                DropArrowItem dropArrowItem = x as DropArrowItem;

                                //if we are selecting a path element that is already in the path then
                                //just update the active path
                                if (dropArrowItem.IsBold)
                                {
                                    //set this drop arrow item to be active
                                    _dibViewModel.Path.SetActive(_dibViewModel.Path.FindElement(dropArrowItem));
                                    
                                    //tell the data item browser view model to navigate to the selected path
                                    _dibViewModel.Navigate(dropArrowItem.DataItem);
                                    return;
                                }

                                IPathElement newPathElement = null;

                                // If we're a textcrumb, we have a backing pathelement
                                ACrumbWithPathElement peCrumb = dropArrowItem.HostCrumb as ACrumbWithPathElement;
                                if (peCrumb != null && !(peCrumb is HomeCrumb))
                                {
                                    newPathElement = PathElementFactory.Instance().CreatePathElement(dropArrowItem.DataItem);

                                     IPathElement nextPathElem = _dibViewModel.Path.GetPathElementAfterThisDataSource(peCrumb.DisplayName);
                                     if (nextPathElem == null)
                                         _dibViewModel.Path.Add(newPathElement);
                                     else
                                         _dibViewModel.Path.ReplaceElement(nextPathElem, newPathElement);

                                }
                                else
                                {
                                    // create the appropriate PathElement based on the the browsers perspective (Tag, DataType)
                                    // Note: This is a hack that is needed based on the bread crumb implementation, the bread crumbs
                                    //       seem to have no 1st class knowledge of the underlying viewmodel.  We need to look at this
                                    //       to see if there is a way we can get this type of state information without having to bully it
                                    if (dropArrowItem.DisplayName.Equals(DIResource.DI_COMMON_RESOURCETYPE_PREDEFINED_DATATYPE))
                                        newPathElement = PathElementFactory.Instance().CreateDataTypePathElement(dropArrowItem.DataItem, DataTypePECategory.Product);
                                    else if (dropArrowItem.DisplayName.Equals(DIResource.DI_COMMON_RESOURCETYPE_MODULE_DATATYPE))
                                        newPathElement = PathElementFactory.Instance().CreateDataTypePathElement(dropArrowItem.DataItem, DataTypePECategory.Module);
                                    else if (dropArrowItem.DisplayName.Equals(DIResource.DI_COMMON_RESOURCETYPE_USER_DATATYPE))
                                        newPathElement = PathElementFactory.Instance().CreateDataTypePathElement(dropArrowItem.DataItem, DataTypePECategory.User);
                                    else
                                    {
                                        newPathElement = PathElementFactory.Instance().CreatePathElement(dropArrowItem.DataItem);
                                    }


                                    IPathElement NextPathElem = _dibViewModel.Path.GetPathElementAfterThisDataSource(String.Empty);
                                    //TODO: this is ugly
                                    //If you navigate into a UD, PD or MD collection and highlight an data type item,
                                    //when you click on home crumb it will try to append the data type item after the 
                                    //home path element, clearing the highlighted item avoids this issue.
                                    if (!_dibViewModel.IsTagBrowser())
                                        _dibViewModel.Path.HighlightedElement = null;
                                    _dibViewModel.Path.ReplaceElement(NextPathElem, newPathElement);
                                }

                                //tell the data item browser view model to navigate to the parent
                                _dibViewModel.Navigate(dropArrowItem.DataItem);
                            }
 
                    };
                }

                return _dropListNavigateCommand;
            }
        }

        /// <summary>
        /// Get the children for the arrow following a textcrumb.
        /// Children may be forward crumbs or datasources.
        /// </summary>
        private SimpleCommand _getChildrenCommand = null;
        public ICommand GetChildrenCommand
        {
            get
            {
                if (_getChildrenCommand == null)
                {
                    _getChildrenCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                            {
								//get the crumb
								ACrumb crumb = x as ACrumb;
								
								// Clear the current drop arrow children collection
								DropArrowChildren.Clear();
                                
                                //If this is a menu crumb, populate the drop down children
                                // list showing either backward or forward crumbs
                                MenuCrumb menuCrumb = crumb as MenuCrumb;
                                if(menuCrumb != null)
                                {
									//For the forward crumb menu
									if(menuCrumb as RMenuCrumb != null)
									{
										//Obtain a list of forward text crumbs
										IEnumerable<DropArrowItem> forwardTextCrumbs =
											from c in this.Crumbs
											where (c as TextCrumb)!=null &&
												  (c as TextCrumb).IsActive==false
											select new DropArrowItem
												{ DisplayName=(c as TextCrumb).DisplayName,
												  IsContainer=(c as TextCrumb).IsContainer,
												  HostCrumb=c,
												  IsBold=false };
												  
										foreach(DropArrowItem forwardTextCrumb in forwardTextCrumbs)
											DropArrowChildren.Add(forwardTextCrumb);
									}
                                }
                                else
                                {
									string dataSourceName = String.Empty;
									
									// We only need the datasource name if we're a textcrumb - homecrumb's
									// will provide the default, an empty name
                                    ACrumbWithPathElement pathElementCrumb = crumb as ACrumbWithPathElement;
                                    if (pathElementCrumb != null)
                                        dataSourceName = pathElementCrumb.DisplayName;

									//populate the drop arrow children collection from DataItemBrowserViewModel
									List<DropArrowItem> items = _dibViewModel.getChildren(dataSourceName, crumb);
                                    if (items == null) return;
								    foreach (DropArrowItem item in items)
									{
								        DropArrowChildren.Add(item);
									}
                                }
                            }
                    };
                }

                return _getChildrenCommand;
            }
        }
        
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">reference to the view model</param>
        public BreadCrumbViewModel(IDataItemBrowserViewModel dibVM)
        {
            _dibViewModel = dibVM;

            //populate the crumb collection from the path elements
            Crumbs = new CrumbsObservableCollection(_dibViewModel.Path);

			//pass on the ActiveCrumbChanged from the crumbs
            Crumbs.ActiveCrumbChanged += new PropertyChangedEventHandler(Crumbs_ActiveCrumbChanged);
            _dibViewModel.SearchBreadCrumbChanged += new PropertyChangedEventHandler(_dibViewModel_SearchBreadCrumbChanged);
        }

        /// <summary>
        /// Notify that the active bread crumb has changed
        /// </summary>
        void Crumbs_ActiveCrumbChanged(object sender, PropertyChangedEventArgs e)
        {
            if (ActiveCrumbChanged != null)
                ActiveCrumbChanged(this, new PropertyChangedEventArgs(String.Empty));
        }

        /// <summary>
        /// Notify that the search bread crumb has changed
        /// </summary>
        void _dibViewModel_SearchBreadCrumbChanged(object sender, PropertyChangedEventArgs e)
        {
            SearchBreadCrumbPropertyChangedEventArgs searchCrumbEventArgs = e as SearchBreadCrumbPropertyChangedEventArgs;
            if (searchCrumbEventArgs.Add)
            {
                Crumbs.AddSearchCrumb();
            }
            else
            {
                Crumbs.RemoveSearchCrumb();
            }

        }

        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {

            Crumbs.CleanupEventSubscriptions();

            Crumbs.ActiveCrumbChanged -= new PropertyChangedEventHandler(Crumbs_ActiveCrumbChanged);

            _dibViewModel.SearchBreadCrumbChanged -= new PropertyChangedEventHandler(_dibViewModel_SearchBreadCrumbChanged);

        }

		public event PropertyChangedEventHandler ActiveCrumbChanged;
 
        #region INotifyPropertyChanged Members
        /// <summary>
        /// implements that INotifyPropertyChanged inteface method NotifyPropertyChanged
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;		

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
