﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media.Animation;
using AvalonUnitTesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.CommonControls;

namespace DataItemBrowserUT
{
    [TestClass]
    public class DonutSpinnerControlTest
    {
        /// <summary>
        /// DonutSpinnerControl UI data binding check.
        /// </summary>
        [TestMethod()]
        public void DonutSpinnerControl_DataBindingIsCorrectTest()
        {
            AvalonTestRunner.RunInSTA(delegate()
            {
                // Create the control using a delegate to ensure binding errors generated during
                // control creation are caught.
                Func<object> controlCreator = delegate()
                {
                    // what ever your control is called
                    DonutSpinnerControl control = new DonutSpinnerControl();
                    return control;
                };

                AvalonTestRunner.RunDataBindingTests(controlCreator);
            });
        }

     
    }
}
