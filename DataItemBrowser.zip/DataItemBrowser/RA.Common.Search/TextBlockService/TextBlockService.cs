﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Data;

// See link http://tranxcoder.wordpress.com/2008/10/12/customizing-lookful-wpf-controls-take-2/ for an explanation of this class
namespace RA.UI.TextBlockService
{
    /// <summary>
    /// Attached property provider which adds the read-only attached property
    /// <c>TextBlockService.IsTextTrimmed</c> to the framework's <see cref="TextBlock"/> control.
    /// The Padding property will invalidate the following computations, therefore do not use any Padding, but instead use Margin.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1724:TypeNamesShouldNotMatchNamespaces")]
    public class TextBlockService
    {
        static TextBlockService()
        {
            // Register for the SizeChanged event on all TextBlocks, even if the event was handled.
            EventManager.RegisterClassHandler(
                typeof( TextBlock ),
                FrameworkElement.SizeChangedEvent,
                new SizeChangedEventHandler( OnTextBlockSizeChanged ),
                true );

             // Register for the SizeChanged event on all TextBlocks, even if the event was handled.
            EventManager.RegisterClassHandler(
                typeof( TextBlock ),
                Binding.TargetUpdatedEvent,
                new EventHandler<DataTransferEventArgs>(OnTextBlockTargetUpdated),
                true );

            
        }

        #region Attached Property [TextBlockService.IsTextTrimmed]

        /// <summary>
        /// Key returned upon registering the read-only attached property <c>IsTextTrimmed</c>.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Security", "CA2104:DoNotDeclareReadOnlyMutableReferenceTypes")]
        public static readonly DependencyPropertyKey IsTextTrimmedKey = DependencyProperty.RegisterAttachedReadOnly(
            "IsTextTrimmed",
            typeof( bool ),
            typeof( TextBlockService ),
            new PropertyMetadata( false ) );    // defaults to false

        /// <summary>
        /// Identifier associated with the read-only attached property <c>IsTextTrimmed</c>.
        /// </summary>
        public static readonly DependencyProperty IsTextTrimmedProperty = IsTextTrimmedKey.DependencyProperty;

        /// <summary>
        /// Returns the current effective value of the IsTextTrimmed attached property.
        /// </summary>
        /// <remarks>Invoked automatically by the framework when databound.</remarks>
        /// <param name="target"><see cref="TextBlock"/> to evaluate</param>
        /// <returns>Effective value of the IsTextTrimmed attached property</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters"), AttachedPropertyBrowsableForType(typeof(TextBlock))]
        public static Boolean GetIsTextTrimmed( TextBlock target )
        {
            return (Boolean) target.GetValue( IsTextTrimmedProperty );
        }

        #endregion (Attached Property [TextBlockService.IsTextTrimmed])

        #region Attached Property [TextBlockService.AutomaticToolTipEnabled]

        /// <summary>
        /// Identifier associated with the attached property <c>AutomaticToolTipEnabled</c>.
        /// </summary>
        public static readonly DependencyProperty AutomaticToolTipEnabledProperty = DependencyProperty.RegisterAttached(
            "AutomaticToolTipEnabled",
            typeof( bool ),
            typeof( TextBlockService ),
            new FrameworkPropertyMetadata( true, FrameworkPropertyMetadataOptions.Inherits ) );    // defaults to true

        /// <summary>
        /// Gets the current effective value of the AutomaticToolTipEnabled attached property.
        /// </summary>
        /// <param name="target"><see cref="TextBlock"/> to evaluate</param>
        /// <returns>Effective value of the AutomaticToolTipEnabled attached property</returns>
        [AttachedPropertyBrowsableForType( typeof( DependencyObject ) )]
        public static Boolean GetAutomaticToolTipEnabled( DependencyObject element )
        {
            if ( null == element )
            {
                throw new ArgumentNullException( "element" );
            }
            return (bool) element.GetValue( AutomaticToolTipEnabledProperty );
        }

        /// <summary>
        /// Sets the current effective value of the AutomaticToolTipEnabled attached property.
        /// </summary>
        /// <param name="target"><see cref="TextBlock"/> to evaluate</param>
        /// <param name="value"><c>true</c> to enable the automatic ToolTip; otherwise <c>false</c></param>
        public static void SetAutomaticToolTipEnabled( DependencyObject element, bool value )
        {
            if ( null == element )
            {
                throw new ArgumentNullException( "element" );
            }
            element.SetValue( AutomaticToolTipEnabledProperty, value );
        }

        #endregion (Attached Property [TextBlockService.AutomaticToolTipEnabled])

        /// <summary>
        /// Event handler for TextBlock's SizeChanged routed event. Triggers evaluation of the
        /// IsTextTrimmed attached property.
        /// </summary>
        /// <param name="sender">Object where the event handler is attached</param>
        /// <param name="e">Event data</param>
        public static void OnTextBlockSizeChanged( object sender, SizeChangedEventArgs e )
        {
            var textBlock = sender as TextBlock;
            if ( null == textBlock )
            {
                return;
            }

            if ( TextTrimming.None == textBlock.TextTrimming )
            {
                SetIsTextTrimmed( textBlock, false );
            }
            else
            {
                SetIsTextTrimmed( textBlock, CalculateIsTextTrimmed( textBlock,false ) );
            }
        }

        
       /// <summary>
        /// Event handler for TextBlock's Target Updated routed event. Triggers evaluation of the
        /// IsTextTrimmed attached property.
        /// </summary>
        /// <param name="sender">Object where the event handler is attached</param>
        /// <param name="e">Event data</param>
        public static void OnTextBlockTargetUpdated(object sender, DataTransferEventArgs e)
        {
            var textBlock = sender as TextBlock;
            if ( null == textBlock )
            {
                return;
            }

            if ( TextTrimming.None == textBlock.TextTrimming )
            {
                SetIsTextTrimmed( textBlock, false );
            }
            else
            {
                SetIsTextTrimmed( textBlock, CalculateIsTextTrimmed( textBlock,true ) );
            }
        }
        /// <summary>
        /// Sets the instance value of read-only dependency property <see cref="IsTextTrimmed"/>.
        /// </summary>
        /// <param name="target">Associated <see cref="TextBlock"/> instance</param>
        /// <param name="value">New value for IsTextTrimmed</param>
        private static void SetIsTextTrimmed( TextBlock target, Boolean value )
        {
            target.SetValue( IsTextTrimmedKey, value );
        }

        /// <summary>
        /// Determines whether or not the text in <paramref name="textBlock"/> is currently being
        /// trimmed due to width or height constraints.
        /// 
        /// NOTE!!!!!!  The Padding property on a TextBlock will invalidate the following computations, therefore do not use any Padding, but instead use Margin.
        /// 
        /// </summary>
        /// <remarks>Does not work properly when TextWrapping is set to WrapWithOverflow.</remarks>
        /// <param name="textBlock"><see cref="TextBlock"/> to evaluate</param>
        /// <param name="textUpdateOnly">the text was updated and no size change</param>
        /// <returns><c>true</c> if the text is currently being trimmed; otherwise <c>false</c></returns>
        private static bool CalculateIsTextTrimmed(TextBlock textBlock, bool textUpdateOnly)
        {
            // IsArrangeValid gets a value indicating whether the computed size and position of child elements in this
            // element's layout are valid.  Ignore the IsArrangeValid if we are just updating the text.
            if (!textBlock.IsArrangeValid && !textUpdateOnly)
            {
                return GetIsTextTrimmed( textBlock );
            }

            // A TypeFace is a single variation of a font with the same font family.
            // Get the TypeFace being used by the TextBlock.
            Typeface typeface = new Typeface(
                textBlock.FontFamily,
                textBlock.FontStyle,
                textBlock.FontWeight,
                textBlock.FontStretch );

            // FormattedText is used to measure the whole width of the text held up by TextBlock container
            FormattedText formattedText = new FormattedText(
                textBlock.Text,
                System.Threading.Thread.CurrentThread.CurrentCulture,
                textBlock.FlowDirection,
                typeface,
                textBlock.FontSize,
                textBlock.Foreground );

            formattedText.MaxTextWidth = textBlock.ActualWidth;

            // The following causes the formattedText's height to increase if the content needs to wrap.  This supports long single words (e.g. tag names).
            formattedText.Trimming = TextTrimming.None;

            // When the maximum text width of the FormattedText instance is set to the actual
            // width of the textBlock, if the textBlock is being trimmed to fit then the formatted
            // text will report a larger height than the textBlock. Should work whether the
            // textBlock is single or multi-line.
            return ( formattedText.Height > textBlock.ActualHeight );
        }
    }
}
