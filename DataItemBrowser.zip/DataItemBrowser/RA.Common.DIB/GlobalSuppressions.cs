﻿// This file is used by Code Analysis to maintain SuppressMessage 
// attributes that are applied to this project.
// Project-level suppressions either have no target or are given 
// a specific target and scoped to a namespace, type, member, etc.
//
// To add a suppression to this file, right-click the message in the 
// Error List, point to "Suppress Message(s)", and click 
// "In Project Suppression File".
// You do not need to add suppressions to this file manually.

[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode", Scope = "member", Target = "RockwellAutomation.UI.Views.BreadCrumbsView.#CrumbsGrid_Loaded(System.Object,System.Windows.RoutedEventArgs)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Scope = "member", Target = "RockwellAutomation.UI.Models.Path.#PathToString(System.Collections.Generic.List`1<RockwellAutomation.UI.IPathElement>,System.String,RockwellAutomation.UI.DIBTreeViewItem+VisualPerspectiveEnum)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling", Scope = "member", Target = "RockwellAutomation.UI.Views.BreadCrumbsGrid.#CalculateNeededWidth(RockwellAutomation.UI.Models.HomeCrumb&,RockwellAutomation.UI.Models.LMenuCrumb&,RockwellAutomation.UI.Models.SearchCrumb&)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Scope = "member", Target = "RockwellAutomation.UI.DIBQuery.DIBQueryCache.#GetChildrenOfCrumb(RockwellAutomation.UI.Models.ACrumb,System.String,RockwellAutomation.UI.Models.DataContext,RockwellAutomation.UI.DIBQuery.IClientDataServices)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Scope = "member", Target = "RockwellAutomation.UI.DIBQuery.DIBQueryColumnConfigHelper.#LoadDefaultColumnConfigData()")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1506:AvoidExcessiveClassCoupling", Scope = "type", Target = "RockwellAutomation.UI.Views.DataGridView")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Scope = "member", Target = "RockwellAutomation.UI.ViewModels.ConnectStringProcessor.#ProcessNavigateTagBrowser(RockwellAutomation.Client.Services.Query.AbstractItem.DataItemBase,RockwellAutomation.UI.ViewModels.NavigateStringDelegate,System.String)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Scope = "member", Target = "RockwellAutomation.UI.ViewModels.ConnectStringProcessor.#ParseTagBrowserConnectString(System.String)")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Maintainability", "CA1502:AvoidExcessiveComplexity", Scope = "member", Target = "RockwellAutomation.UI.Resources.CompositeDataItem.#CreateDataItemResourceIDList(System.Collections.Generic.List`1<RockwellAutomation.UI.IPathElement>)")]
//Commented rules below supressed via the assembly RA.DIB.ruleset and should be periodically evaluated
//[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1024:UsePropertiesWhereAppropriate", Scope = "namespace", Target = "RockwellAutomation.UI", Justification = "We will address property versus method usage in the future")]
//[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures", Scope = "namespace", Target = "RockwellAutomation.UI", Justification = "We will address type nesting in the future")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA2210:AssembliesShouldHaveValidStrongNames", Justification = "Code will be signed in released builds")]
[assembly: System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic", Scope = "member", Target = "RockwellAutomation.UI.Windows.DIBWindow.#ChangeProjectContext(System.String)")]
