﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.Common;
namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for FilterTypeTest and is intended
    ///to contain all FilterTypeTest Unit Tests
    ///</summary>
    [TestClass()]
    public class FilterTypeTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for TypeOperator
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void FilterType_TypeOperatorTest()
        {
          {
            string type = DIBConstants.Common.DataType;
            string expected = "datatype:";
            string expectedShortcut = "dt:";
            FilterType target = new FilterType(type,false,false);
            string actual = target.Operator;
            Assert.AreEqual(expected, actual);
            actual = target.Shortcut;
            Assert.AreEqual(expectedShortcut, actual);
          }
          {
            string type = DIBConstants.Common.Name;
            string expected = "name:";
            string expectedShortcut = "n:";
            FilterType target = new FilterType(type, false, false);
            string actual = target.Operator;
            Assert.AreEqual(expected, actual);
            actual = target.Shortcut;
            Assert.AreEqual(expectedShortcut, actual);
          }
          {
            string type = DIBConstants.Common.Description;
            string expected = "description:";
            string expectedShortcut = "d:";
            FilterType target = new FilterType(type, false, false);
            string actual = target.Operator;
            Assert.AreEqual(expected, actual);
            actual = target.Shortcut;
            Assert.AreEqual(expectedShortcut, actual);
          }
        }

        /// <summary>
        ///A test for TypeName
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void FilterType_TypeNameTest()
        {
          {
            string expected = DIBConstants.Common.DataType;
            FilterType target = new FilterType(expected, false, false);
            string actual = target.Name;
            Assert.AreEqual(expected, actual);
          }
          {
            string expected = DIBConstants.Common.Name;
            FilterType target = new FilterType(expected, false, false);
            string actual = target.Name;
            Assert.AreEqual(expected, actual);
          }
          {
            string expected = DIBConstants.Common.Description;
            FilterType target = new FilterType(expected, false, false);
            string actual = target.Name;
            Assert.AreEqual(expected, actual);
          }
        }

     
    }
}
