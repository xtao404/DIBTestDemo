﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace TagFilterControl.Common
{
    public class CustomCommand : ICommand
    {
        private readonly Func<bool> _canExecute;

        private readonly Action _executeAction;

        public CustomCommand(Action executeAction)
            : this(executeAction, null)
        {
        }

        public CustomCommand(Action executeAction, Func<bool> canExecute)
        {
            if (executeAction == null)
            {
                throw new ArgumentNullException("executeAction");
            }

            this._executeAction = executeAction;
            this._canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged;

        public void RaiseCanExecuteChanged()
        {
            var handler = this.CanExecuteChanged;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }

        public bool CanExecute(object parameter)
        {
            return this._canExecute == null ? true : this._canExecute();
        }

        public void Execute(object parameter)
        {
            this._executeAction();
        }
    }

    public class CustomCommand<T> : ICommand
    {
        private readonly Predicate<T> _canExecute;

        private readonly Action<T> _executeAction;

        public CustomCommand(Action<T> executeAction)
            : this(executeAction, null)
        {
        }

        public CustomCommand(Action<T> executeAction, Predicate<T> canExecute)
        {
            if (executeAction == null)
            {
                throw new ArgumentNullException("executeAction");
            }

            this._executeAction = executeAction;
            this._canExecute = canExecute;
        }

        public event EventHandler CanExecuteChanged;

        public void RaiseCanExecuteChanged()
        {
            var handler = this.CanExecuteChanged;
            if (handler != null)
            {
                handler(this, EventArgs.Empty);
            }
        }

        public bool CanExecute(object parameter)
        {
            return this._canExecute == null ? true : this._canExecute((T)parameter);
        }

        public void Execute(object parameter)
        {
            if (this.CanExecute(parameter))
            {
                this._executeAction((T)parameter);
            }
        }
    }
}
