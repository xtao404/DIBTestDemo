﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using TagFilterControl.Controls;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.Utility;

namespace Launch_TagFilterControl
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ACDHelper acdHelper = ACDHelper.GetInstance();
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private Config config = Config.GetInstance();
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();

        public MainWindow()
        {
            InitializeComponent();
            this.MainWindowVM = new MainWindowViewModel();
            this.DataContext = this.MainWindowVM;
            this.Closed += DIBWindow_Closed;
        }

        void DIBWindow_Closed(object sender, EventArgs e)
        {
            Dispose();
        }

        private void Dispose()
        {
            xmlHelper.ControllerSubChildrensKeyValuePair.Clear();
            xmlHelper.ProgramTagsKeyValuePair.Clear();
            xmlHelper.DataTypes.Clear();
            xmlHelper.UserDefined.Clear();
            xmlHelper.Strings.Clear();
            xmlHelper.AddOnDefined.Clear();
            xmlHelper.PreDefined.Clear();
            xmlHelper.ModuleDefined.Clear();
            xmlHelper.Usage.Clear();
            xmlHelper.TempUsage.Clear();
            xmlHelper.ControllerTags.Clear();
            xmlHelper.UsedTags.Clear();
            xmlHelper.Libs.Clear();
            xmlHelper.TagOwners.Clear();
            config.IsCheckedTags.Clear();
            config.FilterItem.Clear();
        }

        public MainWindowViewModel MainWindowVM { get; set; }

        private void Popup_Closed(object sender, EventArgs e)
        {
            filterDIBIn.DIBClientManager = null;
            config.IsCheckedTags.Clear();
            config.ACMCustomPropertiesTagOwnersFilter.Clear();
        }
    }
}
