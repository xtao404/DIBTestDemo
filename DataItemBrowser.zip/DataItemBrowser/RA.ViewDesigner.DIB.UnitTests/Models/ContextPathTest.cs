﻿using RockwellAutomation.UI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Collections.Generic;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for ContextPathTest and is intended
    ///to contain all ContextPathTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ContextPathTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


    

        /// <summary>
        ///A test for DataItem
        ///</summary>
        [TestMethod()]
        public void ContextPath_DataItemTest()
        {
            string homeName = "home";
            string controllerName = "Controller1";
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(CreateDataItem(homeName));
           dataItems.Add(CreateDataItem(controllerName));

            ContextPath target = new ContextPath(dataItems);

            //should always be the last item
            Assert.AreEqual(controllerName, target.DataItem.CommonName, "dataitem name mismatch");
         }

        /// <summary>
        ///A test for DataItem
        ///</summary>
        [TestMethod()]
        public void ContextPath_DataItemTest_EmptyList()
        {
            List<DataItemBase> dataItems = new List<DataItemBase>();
 
            ContextPath target = new ContextPath(dataItems);

            //should always be the last item
            Assert.AreEqual(null, target.DataItem, "if ther are not items this should be null");
        }
        /// <summary>
        ///A test for DataItemList
        ///</summary>
        [TestMethod()]
        public void ContextPath_DataItemListTest()
        {
            string homeName = "home";
            string controllerName = "Controller1";
            string programName = "MainProgram";
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(CreateDataItem(homeName));
            dataItems.Add(CreateDataItem(controllerName));
            dataItems.Add(CreateDataItem(programName));

            ContextPath target = new ContextPath(dataItems);

            //first item should be home
            Assert.AreEqual(homeName, target.DataItemList[0].CommonName, "first item should be home");
            //second item be the controller item
            Assert.AreEqual(controllerName, target.DataItemList[1].CommonName, "second item should be controller");
            //last item be the program item
            Assert.AreEqual(programName, target.DataItemList[2].CommonName, "last item should be program");
        }

        /// <summary>
        ///A test for ParentDataItem
        ///</summary>
        [TestMethod()]
        public void ContextPath_ParentDataItemTest()
        {
            string homeName = "home";
            string controllerName = "Controller1";
            string programName = "MainProgram";
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(CreateDataItem(homeName));
            dataItems.Add(CreateDataItem(controllerName));
            dataItems.Add(CreateDataItem(programName));

            ContextPath target = new ContextPath(dataItems);

            //should be the last item
            Assert.AreEqual(programName, target.DataItem.CommonName, "dataitem should be controller");
            //should be the controller item
            Assert.AreEqual(controllerName, target.ParentDataItem.CommonName, "parent dataitem should be controller");
        }

        /// <summary>
        ///A test for ParentDataItem
        ///</summary>
        [TestMethod()]
        public void ContextPath_ParentDataItemTest_NoParent()
        {
            string homeName = "home";
       
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(CreateDataItem(homeName));
   
            ContextPath target = new ContextPath(dataItems);

            //should be the last item
            Assert.AreEqual(homeName, target.DataItem.CommonName, "dataitem should be home");
            //should be the controller item
            Assert.AreEqual(null, target.ParentDataItem, "parent dataitem should be null");
        }
        /// <summary>
        /// private method to create dataitems
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private DataItemBase CreateDataItem(string name)
        {
            DataItemBase dataItem = new DataItemBase() {
                CommonName = name,
                CommonDataType = String.Empty,
                CommonDescription = String.Empty,
                IsStructured = true};
            return dataItem;
        }
    }
}
