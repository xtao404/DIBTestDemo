﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using RockwellAutomation.Client.Services.Query;
using System.Xml.Linq;
using System.Reflection;
using System.IO;
using RockwellAutomation.UI.UserConfiguration;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.UI.CommonControls;


namespace RockwellAutomation.UI.DIBQuery
{ 
    /// <summary>
    /// Identifies the available attributes for Column Visualization that can be updated within the user configuration file.
    /// Also provides Column info for Query Requests
    /// </summary>
    public class DIBQueryColumnConfigHelper
    {
        #region "Variables"

        private System.Globalization.CultureInfo currentLocale = System.Globalization.CultureInfo.CurrentUICulture;
        private Dictionary<string, ColumnConfig> _UserConfigColumns = null;
        private Dictionary<string, ColumnConfigMapItem.CreateBuilder> _columns { get; set; }
        private Dictionary<string, Dictionary<string, ColumnConfigMapItem.CreateBuilder>> _resourceTypeToColumnConfigMap = new Dictionary<string, Dictionary<string, ColumnConfigMapItem.CreateBuilder>>();
        
        //Exposed primarily for unit test since dictionary lookups with private objects is complicated especially given the nested objects here
        public Dictionary<string, Dictionary<string, ColumnConfigMapItem.CreateBuilder>> ResourceTypeToColumnConfigMap { get { return _resourceTypeToColumnConfigMap;  } }

        #endregion

        #region "API"

        public void LoadUserAndColumnConfigData(DIBClientManager clientManager)
        {
            //Load our persisted size and column config data
            LoadDefaultColumnConfigData(clientManager);
            LoadPersistedUserConfigData();
        }

        public void SetColumns(String resourceType)
        {
                // Update the column list for the client based on the data item type
                // Important to do this before setting the data view so clients that see the data view change
                // notification have the right column data to act on (i.e. the data grid)
                _columns = _resourceTypeToColumnConfigMap[resourceType];
        }

        public RockwellAutomation.Client.Services.Query.ColumnConfig GenerateColumnConfig()
        {
            RockwellAutomation.Client.Services.Query.ColumnConfig.CreateBuilder columns = new RockwellAutomation.Client.Services.Query.ColumnConfig.CreateBuilder();
            foreach (ColumnConfigMapItem.CreateBuilder curCol in _columns.Values)
                columns.AddColumnMapItem(curCol.Build());
            return columns.Build();
        }

        /// <summary>
        /// Represents what columns the GUI should display given the current context
        /// </summary>
        public List<ColumnConfigMapItem> Columns(IDIBDataViewType dataViewType)
        {
            List<ColumnConfigMapItem> ColList = new List<ColumnConfigMapItem>();

            //Obtaining columns is only valid if we were previously given column data and our data view is not unknown
            if (this._columns!=null && !dataViewType.IsUnknownView())
            {
                //There are no persisted columns in the tree view or list view
                // so only load the persisted data if we are not showing those views
                if (!dataViewType.IsTreeView() && !dataViewType.IsListView())
                    this.UpdateColumnsWithPersistedData(dataViewType);

                foreach (ColumnConfigMapItem.CreateBuilder ColBuilder in this._columns.Values)
                {
                    ColList.Add(ColBuilder.Build());
                }
            }

            return ColList;
        }

        #endregion

        #region "Column Config"



        /// <summary>
        /// This method performs a single update to the Column Configuration based on the provided parameters.
        /// </summary>
        /// <param name="columnAttribute">The attribute to be update (Width, visibility, etc)</param>
        /// <param name="columnName">the column name used to generate an key to the correct location</param>
        /// <param name="columnValue">The column Value to set</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Rockwell.Design", "RA0010:ExceptionsDoNotUseANakedRethrow",Justification = "Made a decision to throw the exception for now.")]
        public void UpdateColumnConfig(IDIBDataViewType dataViewType, ColumnAttribute columnAttribute, string columnName, object columnValue)
        {
            try
            {
                UpdateColumnConfigFor(dataViewType, columnAttribute, columnName, columnValue);
            }
            catch (KeyNotFoundException e)
            {
                LogWrapper.LogException(MethodBase.GetCurrentMethod().ToString(), e);
                // Dont rethrow any exception here. Once the DIB is closed we will rewrite the config file with all updated values. 
            }
        }

        private void UpdateColumnConfigFor(IDIBDataViewType dataViewType, ColumnAttribute columnAttribute, string columnName, object columnValue)
        {
            string prefix = dataViewType.GetUserConfigPrefix();
            string userConfigKey = prefix + columnName;

            if (!_UserConfigColumns.ContainsKey(userConfigKey) && _columns.ContainsKey(columnName))
            {
                // Somehow the requested key does not already exist. Most likely this is caused by user 
                // maliciously modifying the config file manually 
                // Create the UserConfig column for the corresponding column now.
                ColumnConfigMapItem existingColumn = _columns[columnName].Build();
                _UserConfigColumns[userConfigKey] = new ColumnConfig()
                {
                    FieldName = existingColumn.GetColumn,
                    CurrentWidth = existingColumn.GetCurrentWidth,
                    Visible = existingColumn.GetVisible,
                    VisiblePosition = existingColumn.GetPosition,
                    SortDirection = existingColumn.GetSortDirection,
                    SortIndex = existingColumn.GetSortIndex
                };
            }

            if (columnAttribute == ColumnAttribute.Width)
            {
                _UserConfigColumns[userConfigKey].CurrentWidth = (double)columnValue;
            }
            else if (columnAttribute == ColumnAttribute.SortIndex)
            {
                _UserConfigColumns[userConfigKey].SortIndex = (int)columnValue;
            }
            else if (columnAttribute == ColumnAttribute.SortDirection)
            {
                _UserConfigColumns[userConfigKey].SortDirection = (SortDirection)columnValue;
            }
            else if (columnAttribute == ColumnAttribute.Visible)
            {
                _UserConfigColumns[userConfigKey].Visible = (bool)columnValue;
            }
            else if (columnAttribute == ColumnAttribute.VisiblePosition)
            {
                _UserConfigColumns[userConfigKey].VisiblePosition = (int)columnValue;
            }
        }

        /// <summary>
        /// Persist the user config to disk
        /// </summary>
        public void SaveColumnConfig()
        {
            UserConfigurationIO.SaveColumnConfiguration(_UserConfigColumns);
        }

        /// <summary>
        /// Loads the mapping of which columns are applicable for each resource type
        /// into the _resourceTypeToColumnConfigMap dictionary
        /// </summary>
        private void LoadDefaultColumnConfigData(DIBClientManager clientManager)
        {
            if (clientManager == null)
            {
                LogWrapper.DibStartUpLog.Error("DIBClientManager is not defined");
                return;
            };
            Stream xmlStream = clientManager.GetGridColumnMetaData();
            if (xmlStream == null)
            { 
                LogWrapper.DibStartUpLog.Error("Grid Column Meta Data is not defined. Creating default config");
                xmlStream = DefaultEmptyColumnConfigStream();
            }

            var xElem = XElement.Load(xmlStream);

            // We consider our default locale to be "en" or "en-US".
            // If the current local is not set to that, we will attempt to lookup localized strings in this XML stream
            // Otherwise, for performance considerations, dont bother even looking up localized strings 
            bool shouldProcessLocalizedStrings = false;
            if (!SearchFilterControl.IsDefaultLocale(currentLocale))
            {
                shouldProcessLocalizedStrings = true;
                RockwellAutomation.UI.CommonControls.Properties.Resources.Culture = currentLocale;
            }

            //Loop through each column resource from our XML data to store information about each type of column
            // we know about
            Dictionary<string, XElement> columnResourceDict = new Dictionary<string, XElement>();
            Dictionary<string, IEnumerable<FieldConfigItem>> columnFieldDict = new Dictionary<string, IEnumerable<FieldConfigItem>>();
            PopulateColumnInfoResources(xElem, columnResourceDict, columnFieldDict);

            //Loop through each view type (based on a particular context such as controller, tag, data type, etc)
            // to obtain a mapping of what columns should be displayed within each context
            var viewContexts = from view in xElem.Elements("View") select view;
            foreach (var curContext in viewContexts)
            {
                string attrContext = curContext.Attribute("Context").Value;

                Dictionary<string, ColumnConfigMapItem.CreateBuilder> columnConfigs = new Dictionary<string, ColumnConfigMapItem.CreateBuilder>();

                var columns = curContext.Descendants("ColumnResource");
                int nextPos = 0;
                foreach (var curColumn in columns)
                {
                    var xAttribute = curColumn.Attribute("KeyName");
                    if (xAttribute != null)
                    {
                        string attrKeyName = xAttribute.Value;
                        XElement curColumnResource = columnResourceDict[attrKeyName];

                        ColumnConfigMapItem.CreateBuilder newColumnConfig = new ColumnConfigMapItem.CreateBuilder();
                        //Set name
                        string attrName = curColumnResource.Attribute("Name") == null ? String.Empty : curColumnResource.Attribute("Name").Value;
                        // This represents the ID or name of the column
                        newColumnConfig.SetColumn(attrName); 
                        // This represents the column display name to use when displaying this column in a view
                        newColumnConfig.SetTitle(curColumnResource.Attribute("Title") == null ? attrName : curColumnResource.Attribute("Title").Value); 

                        if (shouldProcessLocalizedStrings)
                        {
                           // Our locale could be set to language only format or language and region format. eg. "en" or "en-CA"
                           // Search using complete locale name 
                           IEnumerable<XElement> titleNameLocales =
                                from el in curColumnResource.Descendants("Title")
                                where (string)el.Attribute("{http://www.w3.org/XML/1998/namespace}lang") == currentLocale.Name
                                select el;
                           // If XML contains language only format (no region) in the XML file, search for that.
                           // This is a situation where the current local is "en-CA" but the xml file contains locales for "en" only.
                           if (!titleNameLocales.Any())
                           {
                               titleNameLocales =
                                    from el in curColumnResource.Descendants("Title")
                                    where (string)el.Attribute("{http://www.w3.org/XML/1998/namespace}lang") == currentLocale.TwoLetterISOLanguageName
                                    select el;
                           }
                           if (titleNameLocales.Any())
                               newColumnConfig.SetTitle(titleNameLocales.First().Value);
                        }

                        //Set fields
                        foreach (FieldConfigItem field in columnFieldDict[attrKeyName])
                            newColumnConfig.AddFieldItem(field);

                        //Set position
                        newColumnConfig.SetPosition(nextPos);

                        //Set visible
                        bool attrVisible = curColumnResource.Attribute("Visible") != null ? curColumnResource.Attribute("Visible").Value == "true" : true;
                        newColumnConfig.SetVisible(attrVisible);

                        //Set can hide
                        bool attrCanHide = curColumnResource.Attribute("CanHide") != null ? curColumnResource.Attribute("CanHide").Value == "true" : true;
                        newColumnConfig.SetCanHide(attrCanHide);

                        //Set minimum width
                        double attrMinWidth = curColumnResource.Attribute("MinWidth") != null ? double.Parse(curColumnResource.Attribute("MinWidth").Value) : double.NaN;
                        newColumnConfig.SetMinWidth(attrMinWidth);

                        //Set current width
                        double attrCurWidth = curColumnResource.Attribute("CurrentWidth") != null ? double.Parse(curColumnResource.Attribute("CurrentWidth").Value) : 100.0;
                        newColumnConfig.SetCurrentWidth(attrCurWidth);

                        //Set can wrap
                        bool attrCanWrap = curColumnResource.Attribute("CanWrap") != null ? curColumnResource.Attribute("CanWrap").Value == "true" : false;
                        newColumnConfig.SetCanWrap(attrCanWrap);

                        //Set sort direction
                        SortDirection attrSortDir = SortDirection.None;
                        if (curColumnResource.Attribute("SortDirection") != null)
                            attrSortDir = curColumnResource.Attribute("SortDirection").Value == "1" ? SortDirection.Ascending : SortDirection.Descending;
                        newColumnConfig.SetSortDirection(attrSortDir);

                        //Set sort index
                        int attrSortIndex = curColumnResource.Attribute("SortIndex") != null ? int.Parse(curColumnResource.Attribute("SortIndex").Value) : -1;
                        newColumnConfig.SetSortIndex(attrSortIndex);

                        //Set post load
                        bool attrPostLoad = curColumnResource.Attribute("PostLoad") != null ? curColumnResource.Attribute("PostLoad").Value == "true" : false;
                        newColumnConfig.SetPostLoad(attrPostLoad);

                        columnConfigs[attrName] = newColumnConfig;
                    }

                    nextPos++;
                }

            _resourceTypeToColumnConfigMap[attrContext] = columnConfigs;
            }
            xElem = null;
        }

        private static void PopulateColumnInfoResources(XElement xElem, Dictionary<string, XElement> columnResourceDict, Dictionary<string, IEnumerable<FieldConfigItem>> columnFieldDict)
        {
            var columnResources = from resource in xElem.Elements("ColumnsInfo.Resources").Descendants("Column") select resource;
            foreach (XElement curResource in columnResources)
            {
                var xAttribute = curResource.Attribute("Key");
                if (xAttribute != null)
                {
                    string attrKey = xAttribute.Value;
                    columnResourceDict.Add(attrKey, curResource);

                    var columnFields = from field in curResource.Elements("Field") select field;
                    List<FieldConfigItem> curFieldConfigs = new List<FieldConfigItem>();
                    foreach (var curField in columnFields)
                    {
                        var attribute = curField.Attribute("Type");
                        if (attribute != null)
                        {
                            FieldType fieldType = GetColumnConfigFieldType(attribute.Value);
                            FieldConfigItem.CreateBuilder fieldItemBuilder = new FieldConfigItem.CreateBuilder().SetFieldType(fieldType).SetField(curField.Value);
                            if (curField.Attribute("Separator") != null)
                            {
                                var xAttribute1 = curField.Attribute("Separator");
                                if (xAttribute1 != null)
                                    fieldItemBuilder.SetSeparator(xAttribute1.Value);
                            }
                            if (curField.Attribute("AlternateValue") != null)
                            {
                                var xAttribute1 = curField.Attribute("AlternateValue");
                                if (xAttribute1 != null)
                                    fieldItemBuilder.SetAlternateField(xAttribute1.Value);
                            }
                            if (curField.Attribute("RegexPattern") != null)
                            {
                                var xAttribute1 = curField.Attribute("RegexPattern");
                                if (xAttribute1 != null)
                                    fieldItemBuilder.SetTransformationPattern(xAttribute1.Value);
                            }

                            curFieldConfigs.Add(fieldItemBuilder.Build());
                        }
                    }

                    columnFieldDict.Add(attrKey, curFieldConfigs);
                }
            }
        }


        /// <summary>
        /// Helper to go from an XML resource type string to the QSP Column Config field type
        /// </summary>
        /// <param name="fieldString">xml resource type</param>
        /// <returns>a QSP Column config field type</returns>
        private static FieldType GetColumnConfigFieldType(string fieldString)
        {
            FieldType fieldType = FieldType.Property;
            switch (fieldString)
            {
                case "const":
                    fieldType = FieldType.Const;
                    break;
                case "list":
                    fieldType = FieldType.List;
                    break;
            }

            return fieldType;
        }

        /// <summary>
        /// Loads the persisted settings from a previous session (column order, width, etc) from the 
        /// user configuration file
        /// </summary>
        private void LoadPersistedUserConfigData()
        {
            _UserConfigColumns = UserConfigurationIO.ReadColumnConfiguration();
        }


        /// <summary>
        /// Applies the information from the persisted column data and updates the values in the
        /// _resourceTypeToColumnConfigMap
        /// </summary>
        private void UpdateColumnsWithPersistedData(IDIBDataViewType dataViewType)
        {
            string prefix = dataViewType.GetUserConfigPrefix();

            //If the user config does not have this view persisted yet, we need to create the ColumnConfig
            // objects so that they exist
            if (_UserConfigColumns.Keys.Where(keyName => keyName.StartsWith(prefix)).Count() == 0)
            {
                foreach (ColumnConfigMapItem.CreateBuilder curColConfig in _columns.Values)
                {
                    ColumnConfigMapItem curMapItem = curColConfig.Build();
                    string curUserConfigName = prefix + curMapItem.GetColumn;
                    if (curMapItem.GetVisible)
                    {
                        _UserConfigColumns[curUserConfigName] = new ColumnConfig()
                        {
                            FieldName = curMapItem.GetColumn,
                            CurrentWidth = curMapItem.GetCurrentWidth,
                            Visible = curMapItem.GetVisible,
                            VisiblePosition = curMapItem.GetPosition,
                            SortDirection = curMapItem.GetSortDirection,
                            SortIndex = curMapItem.GetSortIndex,
                        };
                    }
                }
            }
            //If the user config does have persisted values, load them below
            else
            {
                foreach (KeyValuePair<string, ColumnConfig> curPersistedConfig in _UserConfigColumns)
                {
                    ColumnConfig curPersistedColConfig = curPersistedConfig.Value;

                    //If we are looking at a persisted column that applies to our current view
                    if (curPersistedConfig.Key.StartsWith(prefix))
                    {
                        //Get the name of the column (the string after the key prefix)
                        string curPersistedColName = curPersistedConfig.Key.Substring(prefix.Length);
                        //make sure the column exists in this map
                        if (_columns.ContainsKey(curPersistedColName))
                        {
                            //Obtain the current/defaults as loaded into our _columns data, and add update the
                            // fields from the user config data
                            ColumnConfigMapItem.CreateBuilder colConfig = _columns[curPersistedColName];                           
                            if (colConfig == null) throw new ArgumentNullException("colConfig");

                            ColumnConfigMapItem curMapItem = colConfig.Build();
                            // Validate that the current width is greater than or equal to its minimum width
                            // This can only happen if the user.config file were manually updated
                            if (curPersistedColConfig.CurrentWidth < curMapItem.GetMinWidth)
                                curPersistedColConfig.CurrentWidth = curMapItem.GetMinWidth;

                            colConfig.SetCurrentWidth(curPersistedColConfig.CurrentWidth);
                            colConfig.SetVisible(curPersistedColConfig.Visible);
                            colConfig.SetPosition(curPersistedColConfig.VisiblePosition);
                            colConfig.SetSortDirection(curPersistedColConfig.SortDirection);
                            colConfig.SetSortIndex(curPersistedColConfig.SortIndex);
                        }
                    }
                }
            }
        }

        #endregion

        static private Stream DefaultEmptyColumnConfigStream()
        {
            string str = @"<?xml version=""1.0"" encoding=""utf-8""?>
                        <ColumnsInfo>
                          <View Context=""GenericDIBItemView"">
                            <ColumnResource KeyName=""NameColumn""/>
                            <ColumnResource KeyName=""DatatypeColumn""/>
                            <ColumnResource KeyName=""DescriptionColumn""/>
                          </View>
                          <!-- Search View -->
                          <View Context=""searchtags"">
                            <ColumnResource KeyName=""NameColumn""/>
                            <ColumnResource KeyName=""PathColumn""/>
                            <ColumnResource KeyName=""DatatypeColumn""/>
                            <ColumnResource KeyName=""DescriptionColumn""/>
                          </View>
                          <!-- Tree View -->
                          <View Context=""none"">
                            <ColumnResource KeyName=""NameColumn""/>
                          </View>
                          <!-- Web View -->
                          <View Context=""Web"">
                            <ColumnResource KeyName=""NameColumn""/>
                          </View>
                          <ColumnsInfo.Resources>
                            <Column Key=""NameColumn"" Name=""Name"" CanHide=""false"" MinWidth=""120"" CurrentWidth=""120"" SortDirection=""1"" SortIndex=""0"">
                              <Title xml:lang=""en"">Name</Title>
                              <Title xml:lang=""en-CA"">Name ehh</Title>
                              <Title xml:lang=""de"">Naam</Title>
                              <Title xml:lang=""es"">Nombre</Title>
                              <Title xml:lang=""fr"">Nom</Title>
                              <Title xml:lang=""it"">nome</Title>
                              <Title xml:lang=""ja"">日本語</Title>
                              <Title xml:lang=""ko"">한국어</Title>
                              <Title xml:lang=""pt"">Nome</Title>
                              <Title xml:lang=""zh"">中文(简体)</Title>                              
                              <Field Type=""property"">Nothing</Field>
                            </Column>
                            <Column Key=""DescriptionColumn"" Name=""Description"" MinWidth=""120"" CurrentWidth=""120"">
                              <Title xml:lang=""en"">Description</Title>
                              <Title xml:lang=""en-CA"">Description ehh</Title>
                              <Title xml:lang=""de"">Beschrijving</Title>
                              <Title xml:lang=""es"">Descripción</Title>
                              <Title xml:lang=""fr"">Description</Title>
                              <Title xml:lang=""it"">Descrizione</Title>
                              <Title xml:lang=""ja"">説明</Title>
                              <Title xml:lang=""ko"">기술</Title>
                              <Title xml:lang=""pt"">Descrição</Title>
                              <Title xml:lang=""zh"">描述</Title>
                              <Field Type=""property"">Nothing</Field>
                            </Column>
                            <Column Key=""DatatypeColumn"" Name=""Data Type"" MinWidth=""80"" CurrentWidth=""80"">
                              <Title xml:lang=""en"">Data Type</Title>
                              <Title xml:lang=""en-CA"">Data Type ehh</Title>
                              <Title xml:lang=""de"">data Type</Title>
                              <Title xml:lang=""es"">Tipo de datos</Title>
                              <Title xml:lang=""fr"">Type de données</Title>
                              <Title xml:lang=""it"">Tipo di dati</Title>
                              <Title xml:lang=""ja"">データ型</Title>
                              <Title xml:lang=""ko"">데이터 형식</Title>
                              <Title xml:lang=""pt"">Tipo de dados</Title>
                              <Title xml:lang=""zh"">数据类型</Title>
                              <Field Type=""property"">Nothing</Field>
                            </Column>
		                    <Column Key=""PathColumn"" Name=""Location"" CanHide=""false"" MinWidth=""120"" CurrentWidth=""120"">
                              <Title xml:lang=""en"">Location</Title>
                              <Title xml:lang=""en-CA"">Location ehh</Title>
                              <Title xml:lang=""de"">Plaats</Title>
                              <Title xml:lang=""es"">Ubicación</Title>
                              <Title xml:lang=""fr"">Emplacement</Title>
                              <Title xml:lang=""it"">Posizione</Title>
                              <Title xml:lang=""ja"">場所</Title>
                              <Title xml:lang=""ko"">위치</Title>
                              <Title xml:lang=""pt"">Localização</Title>
                              <Title xml:lang=""zh"">位置</Title>
                              <Field Type=""property"">Nothing</Field>
                            </Column>
                          </ColumnsInfo.Resources>
                        </ColumnsInfo>";
            byte[] data = System.Text.Encoding.UTF8.GetBytes(str);
            return new MemoryStream(data, 0, data.Length);
        }
    }
    
    public enum ColumnAttribute
    {
        Width,
        SortIndex,
        SortDirection,
        Visible,
        VisiblePosition
    }
}
