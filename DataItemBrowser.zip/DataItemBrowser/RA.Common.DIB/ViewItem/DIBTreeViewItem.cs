/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using System.Collections.ObjectModel;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;
using System.Windows;
using RockwellAutomation.Client.Services.Query;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// DIBTreeViewItem is a concrete class.  Everynode in the DIBTreeViewItem tree will either be represented
    /// by this class or interact with an instance of this class.
    /// </summary>
    public class DIBTreeViewItem : DIBViewItemBase, IVisualBase
    {
        private const string NOIMAGEPROPERTYKEYVALUE = "NoImage";
        private const string HMIDEVICESKEYVALUE = "HMIDevices";
        private const string TAGSANDPROPKEYVALUE = "TagsAndProps";
        private const string HMIDEVICESIMAGEPATHVALUE = "/RA.Common.DIB;component/Bitmaps/HMIPanels.png";
        private const string TAGSANDPROPPATHVALUE = "/RA.Common.DIB;component/Bitmaps/controllers.png";

        #region Constructor/Initialize

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dataItem"></param>
        /// <param name="name"></param>
        /// <param name="type"></param>
        /// <param name="parent"></param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public DIBTreeViewItem(DataItemBase dataItem, string name, VisualType type, IVisualBase parent, DIBClientManager dibClientManager = null)
            : base(dataItem)
        {
            DataItem = dataItem;
            VisualType = type;
            this.Name = name;
            _parent = parent;
            _children = new TSObservableCollection<IVisualBase>();

            if (this.HasDataItem)
                InitializeTreeViewItemWithDataItem();
            else 
                InitializeTreeViewItemWithoutDataItem();

            if (dibClientManager == null)
                this.InitializeWithDefaultValues();
            else
                dibClientManager.InitializeGUIViewItem(dataItem, type, this);

            _imagePresenter = new DeviceImagePresenter();
            _imagePresenter.Initialize(this);
        }


        private void InitializeTreeViewItemWithDataItem()
        {
            ResourceId = ResourceBase.GuidStringToId(this.DataItem.CommonID);
            _isSelected = DIBViewItemBase.BooleanValueFrom(this.DataItem.GUIIsInitiallyHighlighted);
            _isExpanded = DIBViewItemBase.BooleanValueFrom(this.DataItem.GUIIsExpanded);
            this.SupportsDrillIn = DIBViewItemBase.BooleanValueFrom(this.DataItem.GUISupportsDrillIn, this.DataItem.IsStructured);
            this.ImagePath = DIBViewItemBase.StringValueFrom(this.DataItem.GUISmallImagePath, null);
            this.ImageWidth = DIBViewItemBase.IntegerValueFrom(this.DataItem.GUISmallImageWidth, 16);
            this.ImageHeight = DIBViewItemBase.IntegerValueFrom(this.DataItem.GUISmallImageHeight, 16);
            this.AutomationID = DIBViewItemBase.StringValueFrom(this.DataItem.GUIAutomationID, this.Name);
            this.AutomationName = DIBViewItemBase.StringValueFrom(this.DataItem.GUIAutomationName, this.Name);
            this.ToolTip = DIBViewItemBase.StringValueFrom(this.DataItem.GUIToolTip, String.Empty);
            this.TextFontWeight = DIBViewItemBase.FontWeightFrom(this.DataItem.GUITextFontWeight, FontWeights.Normal);
        }


        private void InitializeTreeViewItemWithoutDataItem()
        {
            _isSelected = false;
            _isExpanded = false;
            ResourceId = null;

            if (VisualType == UI.VisualType.vtModuleDefined ||
                VisualType == UI.VisualType.vtPredefined ||
                VisualType == UI.VisualType.vtUserDefined ||
                VisualType == UI.VisualType.vtHMIDevice ||
                VisualType == UI.VisualType.vtController)
            {
                this.AutomationID = NOIMAGEPROPERTYKEYVALUE;
                this.AutomationName = NOIMAGEPROPERTYKEYVALUE;
                this.SupportsDrillIn = true;
            }
            else if (VisualType == UI.VisualType.vtHMIDevices)
            {
                this.AutomationID = HMIDEVICESKEYVALUE;
                this.AutomationName = HMIDEVICESKEYVALUE;
                this.ImageHeight = 16;
                this.ImageWidth = 16;
                this.ImagePath = HMIDEVICESIMAGEPATHVALUE;
                this.SupportsDrillIn = false;
            }
            else if (VisualType == UI.VisualType.vtControllers)
            {
                this.AutomationID = TAGSANDPROPKEYVALUE;
                this.AutomationName = TAGSANDPROPKEYVALUE;
                this.ImageHeight = 16;
                this.ImageWidth = 16;
                this.ImagePath = TAGSANDPROPPATHVALUE;
                this.SupportsDrillIn = false;
            }
            else if (VisualType == UI.VisualType.vtDataTypes)
            {
                this.AutomationID = NOIMAGEPROPERTYKEYVALUE;
                this.AutomationName = NOIMAGEPROPERTYKEYVALUE;
                this.SupportsDrillIn = false;
            }
        }

        public void InitializeWithDefaultValues()
        {
            this.ReplicationState = DeviceImagePresenter.ReplicationStateType.SYNCHED;
            this.ReplicationError = String.Empty;
        }

        #endregion

        #region Properties/Variables


        /// <summary>
        /// Unique Id the visual represents
        /// </summary>
        public UUID ResourceId { get; set; }

        // The name of the Visual node
        public string VisualName
        {
            get { return this.Name; }
            set { this.Name = value; }
        }

        // The type of the Visual node
        public VisualType VisualType { get; set; }

        private IVisualBase _parent;
        /// <summary>
        /// The parent of the Visual node
        /// </summary>
        public IVisualBase Parent
        {
            get { return _parent; }
            set { _parent = value; }
        }


        private IObservableCollection<IVisualBase> _children;
        /// <summary>
        /// The children of the Visual node
        /// </summary>
        public IObservableCollection<IVisualBase> Children
        {
            get { return _children; }
        }


        private DeviceImagePresenter _imagePresenter = null;
        /// <summary>
        /// controller image presenter
        /// </summary>
        public DeviceImagePresenter ImagePresenter
        {
            get { return _imagePresenter; }

        }

        private DeviceImagePresenter.ReplicationStateType _replicationState = DeviceImagePresenter.ReplicationStateType.SYNCHED;
        /// <summary>
        /// Replication state of the controller
        /// </summary>
        public DeviceImagePresenter.ReplicationStateType ReplicationState
        {
            get { return _replicationState; }
            set { _replicationState = value; } 
        }

        private string _replicationError = null;
        /// <summary>
        /// the controller resource error property
        /// </summary>
        public string ReplicationError
        {
            get { return _replicationError; }
            set { _replicationError = value; }
        }


        /// <summary>
        /// Should the node in the visual tree be selected?
        /// </summary>
        public override bool IsSelected
        {
            get { return _isSelected; }
            set
            {
                if (value != _isSelected)
                {
                    _isSelected = value;
                    this.NotifyPropertyChanged("IsSelected");
                }
            }
        }

        private bool _isExpanded = false;
        /// <summary>
        /// Should the node in the visual tree be expanded?
        /// </summary>
        public bool IsExpanded
        {
            get { return _isExpanded; }
            set
            {
                if (value != _isExpanded)
                {
                    _isExpanded = value;
                    this.NotifyPropertyChanged("IsExpanded");
                }

                // Expand all the way up to the root.
                if (_isExpanded && _parent != null)
                    _parent.IsExpanded = true;
            }
        }

        #endregion

        #region GC

        protected override void PerformDispose()
        {
            if (_imagePresenter != null) _imagePresenter.Dispose();
            _imagePresenter = null;
            base.PerformDispose();
        } 

        #endregion
    }
}

