using RockwellAutomation.UI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace DataItemBrowserUT
{
    
    /// <summary>
    ///This is a test class for CrumbsObservableCollectionTest and is intended
    ///to contain all CrumbsObservableCollectionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CrumbsObservableCollectionTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Forward
        ///</summary>
        [TestMethod()]
        public void CrumbOC_ForwardTest()
        {
            Path path = new Path();
            string controller = "c1";
            string tag = "t1";
            string forward = "forward";

            path.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement activePE = path.ActiveElement;
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(forward, "", true));
            path.SetActive(activePE);

            IPathElement pe = path.Forward;

            Assert.AreEqual(forward, pe.DisplayName);
        }

        /// <summary>
        ///A test for Forward
        ///</summary>
        [TestMethod()]
        public void CrumbOC_ForwardTest_HMIDevice()
        {
            Path path = new Path();
            string controller = "c1";
            string tag = "t1";
            string forward = "forward";

            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement activePE = path.ActiveElement;
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(forward, "", true));
            path.SetActive(activePE);

            IPathElement pe = path.Forward;

            Assert.AreEqual(forward, pe.DisplayName);
        }


        /// <summary>
        ///A test for DataSourceElement
        ///</summary>
        [TestMethod()]
        public void CrumbOC_DataSourceElementTest()
        {
            Path path = new Path();
            string controller = "c1A";
            string tag = "t1A";
            string member = "m1A";

            path.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            IPathElement pe = path.LastContainerElement;

            Assert.AreEqual(controller, pe.DisplayName);
        }

        /// <summary>
        ///A test for DataSourceElement
        ///</summary>
        [TestMethod()]
        public void CrumbOC_DataSourceElementTest_HMIDevice()
        {
            Path path = new Path();
            string controller = "c1A";
            string tag = "t1A";
            string member = "m1A";

            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            IPathElement pe = path.LastContainerElement;

            Assert.AreEqual(controller, pe.DisplayName);
        }

        /// <summary>
        ///A test for Back
        ///</summary>
        [TestMethod()]
        public void CrumbOC_BackTest()
        {
            Path path = new Path();
            string controller = "c1B";
            string tag = "t1B";
            string member = "m1B";

            path.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            IPathElement pe = path.Back;

            Assert.AreEqual(tag, pe.DisplayName);
        }

        /// <summary>
        ///A test for Back
        ///</summary>
        [TestMethod()]
        public void CrumbOC_BackTest_HMIDevice()
        {
            Path path = new Path();
            string controller = "c1B";
            string tag = "t1B";
            string member = "m1B";

            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            IPathElement pe = path.Back;

            Assert.AreEqual(tag, pe.DisplayName);
        }

        /// <summary>
        ///A test for ActiveElement
        ///</summary>
        [TestMethod()]
        public void CrumbOC_ActiveElementTest()
        {
            Path path = new Path();
            string controller = "c1C";
            string tag = "t1C";
            string member = "m1C";

            path.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            IPathElement pe = path.Back;

            Assert.AreEqual(tag, pe.DisplayName);
        }

        /// <summary>
        ///A test for ActiveElement
        ///</summary>
        [TestMethod()]
        public void CrumbOC_ActiveElementTest_HMIDevice()
        {
            Path path = new Path();
            string controller = "c1C";
            string tag = "t1C";
            string member = "m1C";

            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            IPathElement pe = path.Back;

            Assert.AreEqual(tag, pe.DisplayName);
        }

        /// <summary>
        ///A test for SetActive
        ///</summary>
        [TestMethod()]
        public void CrumbOC_SetActiveTest()
        {
            Path path = new Path();
            string controller = "c1D";
            string tag = "t1D";
            string member = "m1D";

            path.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement activePE = path.ActiveElement;
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));
            path.SetActive(activePE);

            IPathElement pe = path.ActiveElement;

            Assert.AreEqual(tag, pe.DisplayName);
        }

        /// <summary>
        ///A test for SetActive
        ///</summary>
        [TestMethod()]
        public void CrumbOC_SetActiveTest_HMIDevice()
        {
            Path path = new Path();
            string controller = "c1D";
            string tag = "t1D";
            string member = "m1D";

            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement activePE = path.ActiveElement;
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));
            path.SetActive(activePE);

            IPathElement pe = path.ActiveElement;

            Assert.AreEqual(tag, pe.DisplayName);
        }


        /// <summary>
        ///A test for PathElements_CollectionChanged
        ///</summary>
        [TestMethod()]
        public void CrumbOC_PathElements_CollectionChangedTest()
        {
            Path path = new Path();
            List<IPathElement> deletes = new List<IPathElement>();
            List<IPathElement> adds = new List<IPathElement>();

            string controller = "c1D";
            string tag = "t1D";
            string member = "m1D";

            CrumbsObservableCollection target = new CrumbsObservableCollection(path);

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            path.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", false));

            //this will cause the delete notification to fire
            path.Items.RemoveAt(path.Items.Count - 1);
            Assert.AreEqual(target.ActiveElement.DisplayName, tag);
            path.Items.RemoveAt(path.Items.Count - 1);
            Assert.AreEqual(target.ActiveElement.DisplayName, controller);

            //this will cause the add notification to fire
            string add1 = "add1";
            string add2 = "add2";
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(add1, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(add2, "", true));
            Assert.AreEqual(target.ActiveElement.DisplayName, add2);
            Assert.AreEqual(target.Back.DisplayName, add1);
        }

        /// <summary>
        ///A test for PathElements_CollectionChanged
        ///</summary>
        [TestMethod()]
        public void CrumbOC_PathElements_CollectionChangedTest_HMIDevice()
        {
            Path path = new Path();
            List<IPathElement> deletes = new List<IPathElement>();
            List<IPathElement> adds = new List<IPathElement>();

            string controller = "c1D";
            string tag = "t1D";
            string member = "m1D";


            CrumbsObservableCollection target = new CrumbsObservableCollection(path);

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", false));

            //this will cause the delete notification to fire
            path.Items.RemoveAt(path.Items.Count - 1);
            Assert.AreEqual(target.ActiveElement.DisplayName, tag);
            path.Items.RemoveAt(path.Items.Count - 1);
            Assert.AreEqual(target.ActiveElement.DisplayName, controller);

            //this will cause the add notification to fire
            string add1 = "add1";
            string add2 = "add2";
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(add1, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(add2, "", true));
            Assert.AreEqual(target.ActiveElement.DisplayName, add2);
            Assert.AreEqual(target.Back.DisplayName, add1);
        }


        /// <summary>
        ///A test for NavigateForward
        ///</summary>
        [TestMethod()]
        public void CrumbOC_NavigateForwardTest()
        {
            Path path = new Path();
            string controller = "c1F";
            string tag = "t1F";
            string member = "m1F";

            path.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            IPathElement activePE = path.ActiveElement;
            path.SetActive(activePE);
            path.NavigateForward();

            IPathElement pe = path.ActiveElement;

            Assert.AreEqual(member, pe.DisplayName);
        }

        /// <summary>
        ///A test for NavigateForward
        ///</summary>
        [TestMethod()]
        public void CrumbOC_NavigateForwardTest_HMI_Device()
        {
            Path path = new Path();
            string controller = "c1F";
            string tag = "t1F";
            string member = "m1F";

            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));

            IPathElement activePE = path.ActiveElement;
            path.SetActive(activePE);
            path.NavigateForward();

            IPathElement pe = path.ActiveElement;

            Assert.AreEqual(member, pe.DisplayName);
        }

        /// <summary>
        ///A test for NavigateBack
        ///</summary>
        [TestMethod()]
        public void CrumbOC_NavigateBackTest()
        {
            Path path = new Path();
            string controller = "c1F";
            string tag = "t1F";
            string member = "m1F";

            path.Add(PathElementUtility.Instance().CreateControllerPathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement activePE = path.ActiveElement;
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));
            path.NavigateBack();

            IPathElement pe = path.ActiveElement;

            Assert.AreEqual(tag,pe.DisplayName);
        }

        /// <summary>
        ///A test for NavigateBack
        ///</summary>
        [TestMethod()]
        public void CrumbOC_NavigateBackTest_HMIDevice()
        {
            Path path = new Path();
            string controller = "c1F";
            string tag = "t1F";
            string member = "m1F";

            path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controller));
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tag, "", true));

            IPathElement activePE = path.ActiveElement;
            path.Add(PathElementUtility.Instance().CreateDataItemPathElement(member, "", true));
            path.NavigateBack();

            IPathElement pe = path.ActiveElement;

            Assert.AreEqual(tag, pe.DisplayName);
        }


        /// <summary>
        ///A test for AddSearchCrumbTest Constructor
        ///</summary>
        [TestMethod()]
        public void CrumbOC_AddSearchCrumbTest()
        {
            Path path = new Path();
            CrumbsObservableCollection CrumbsOC = new CrumbsObservableCollection(path);

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            path.Items.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            //by default the crumbs will create three crumbs not in the path elements:
            // 0=Home, 1=LMenu, 2=RMenu
            Assert.AreEqual(3, CrumbsOC.Count);

            //add search crumb
            CrumbsOC.AddSearchCrumb();
            //now 0=Home, 1=LMenu, 2-Search, 3=RMenu
            Assert.AreEqual(4, CrumbsOC.Count);
            Assert.IsInstanceOfType(CrumbsOC[0], typeof(HomeCrumb));
            Assert.IsInstanceOfType(CrumbsOC[1], typeof(LMenuCrumb));
            Assert.IsInstanceOfType(CrumbsOC[2], typeof(SearchCrumb));
            Assert.IsInstanceOfType(CrumbsOC[3], typeof(RMenuCrumb));

        }

        /// <summary>
        ///A test for RemoveSearchCrumbTest Constructor
        ///</summary>
        [TestMethod()]
        public void CrumbOC_RemoveSearchCrumbTest()
        {
            Path path = new Path();
            CrumbsObservableCollection CrumbsOC = new CrumbsObservableCollection(path);

            DataItemBase homeDataItem = PathElementUtility.Instance().CreateHomeDataItem("home");
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            path.Items.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            //by default the crumbs will create three crumbs not in the path elements:
            // 0=Home, 1=LMenu, 2=RMenu
            Assert.AreEqual(3, CrumbsOC.Count);

            //add search crumb
            CrumbsOC.AddSearchCrumb();
            //now 0=Home, 1=LMenu, 2-Search, 3=RMenu
            Assert.AreEqual(4, CrumbsOC.Count);
            Assert.IsInstanceOfType(CrumbsOC[0], typeof(HomeCrumb));
            Assert.IsInstanceOfType(CrumbsOC[1], typeof(LMenuCrumb));
            Assert.IsInstanceOfType(CrumbsOC[2], typeof(SearchCrumb));
            Assert.IsInstanceOfType(CrumbsOC[3], typeof(RMenuCrumb));

            //remove search crumb
            CrumbsOC.RemoveSearchCrumb();
            //back to the default
            Assert.AreEqual(3, CrumbsOC.Count);
            Assert.IsInstanceOfType(CrumbsOC[0], typeof(HomeCrumb));
            Assert.IsInstanceOfType(CrumbsOC[1], typeof(LMenuCrumb));
            Assert.IsInstanceOfType(CrumbsOC[2], typeof(RMenuCrumb));


        }
		/// <summary>
		///A test for CrumbsObservableCollection Constructor
		///</summary>
		[TestMethod()]
		public void CrumbOC_CrumbsObservableCollectionConstructorTest()
		{
			Path path = new Path();
			CrumbsObservableCollection CrumbsOC = new CrumbsObservableCollection(path);

			//crumbs do not get created until the first pathelement is added
			Assert.AreEqual(0, CrumbsOC.Count);
            	
		}
      
    }
}
