/* ****************************************************************************
*
*  Copyright 2015 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Controls.Primitives;
using RockwellAutomation.UI.ViewModels;
using System.ComponentModel;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.Models;

namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Interaction logic for BreadCrumbsView.xaml
    /// </summary>
    public partial class BreadCrumbsView : ItemsControl
    {
        private BreadCrumbsGrid _CrumbsGrid = null;
        private SimpleCommand _showContextMenu = null;
        public bool IsContextMenuOpen { get; set; }

        /// <summary>
        /// constructor
        /// </summary>
        public BreadCrumbsView()
        {
            InitializeComponent();

            IsContextMenuOpen = false;
        }

        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (e.Property.Name == "FontSize")
            {
                Height = FontSize*2;
            }
        }

        /// <summary>
        /// Handles the BreadCrumbsGrid Loaded event
        /// </summary>
        /// <param name="sender">BreadCrumbsGrid</param>
        /// <param name="e">Standard routed event args provided by framework</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode",Justification = "called by XAML")]
        private void CrumbsGrid_Loaded(object sender, RoutedEventArgs e)
        {
            //Cache the specialized grid used within this items control
            _CrumbsGrid = (BreadCrumbsGrid)sender;
            _CrumbsGrid.UpdateCrumbSizing(true);
        }

        /// <summary>
        /// Handles the ItemsControl Loaded event
        /// </summary>
        /// <param name="sender">ItemsControl</param>
        /// <param name="e">Standard routed event args provided by framework</param>
        void BreadCrumbsView_Loaded(object sender, RoutedEventArgs e)
        {
            //Hook up the ActiveCrumbChanged event on the BreadCrumbViewModel
            // to update the breadcrumbs sizing
            BreadCrumbViewModel bcvm = DataContext as BreadCrumbViewModel;
            if (bcvm != null)
                bcvm.ActiveCrumbChanged += new PropertyChangedEventHandler(bcvm_ActiveCrumbChanged);
        }

        void bcvm_ActiveCrumbChanged(object sender, PropertyChangedEventArgs e)
        {
            _CrumbsGrid.UpdateCrumbSizing(true);
        }

        /// <summary>
        /// Display the context menu
        /// </summary>
        public ICommand ShowContextMenuCommand
        {
            get
            {
                if (_showContextMenu == null)
                {
                    _showContextMenu = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {

                            //make sure the button is checked
                            ToggleButton tb = x as ToggleButton;

                            if (tb.IsChecked == true)
                            {
                                // Set the placement target
                                tb.ContextMenu.PlacementTarget = tb;

                                //make sure the font is inherited from the control
                                // and not the frameworks menu item style
                                tb.ContextMenu.FontFamily = tb.FontFamily;
                                tb.ContextMenu.FontSize = tb.FontSize;

                                //get the child items to fill the contextmenu
                                BreadCrumbViewModel bcvm = DataContext as BreadCrumbViewModel;
                                bcvm.GetChildrenCommand.Execute(tb.DataContext);

                                if ((tb.ContextMenu.HasItems) || (bcvm.DropArrowChildren.Count > 0))
                                {
                                    //open the contextmenu
                                    tb.ContextMenu.IsOpen = true;

                                    //track that the context menu is closed (for focus control)
                                    IsContextMenuOpen = true;
                                }
                                else
                                {
                                    //don't open the menu if the crumb menu has no items
                                    tb.IsChecked = false;   
                                }
                            }
                        }
                    };
                }

                return _showContextMenu;
            }
        }

        /// <summary>
        /// event handler that is called when the context menu closes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContextMenu_Closed(object sender, RoutedEventArgs e)
        {
            // this event handler was needed because contextmenu visual tree is not 
            // in the same visual tree as the button.  I could never get a datatrigger
            // that worked so we will do it with code behind
            ContextMenu cm = sender as ContextMenu;
            ToggleButton tb = cm.PlacementTarget as ToggleButton;

            tb.IsChecked = false;

            //track that the context menu is closed (for focus control)
            IsContextMenuOpen = false;
        }

        /// <summary>
        /// Multiple toggle buttons use this event.
        /// Typically Shift-Tab and Tab would navigate through the list of elements.  
        /// Tab functionality desired: close context menu and set the focus on next/previous item in list of crumbs.
        /// Esc key should just close the context menu.
        /// Enter key selects an item and closes the context menu.
        /// All other keys should be handled as usual.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ContextMenu_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            ContextMenu cm = sender as ContextMenu;
            if (cm == null) return;
            ToggleButton tb = cm.PlacementTarget as ToggleButton;
            if (tb == null) return;

            //Process moving to the next or previous control
            //If the user clicked left or right buttons we want them to act just like TAB and Shift TAB
            if (((Keyboard.Modifiers == ModifierKeys.Shift) && (e.Key == Key.Tab))
                || e.Key == Key.Tab
                || e.Key == Key.Right
                || e.Key == Key.Left)
            {
                // Close the popup
                tb.ContextMenu.IsOpen = false;
                tb.IsChecked = false;

                // Tab key - change focus to next element
                TraversalRequest request = null;
                // Gets the element with keyboard focus ( togglebutton )
                UIElement elementWithFocus = tb as UIElement;
                tb.Focus();
                if ((Keyboard.Modifiers == ModifierKeys.Shift) && (e.Key == Key.Tab) || (e.Key == Key.Left))
                    request = new TraversalRequest(FocusNavigationDirection.Previous);
                else
                    request = new TraversalRequest(FocusNavigationDirection.Next);
                // Change keyboard focus.
                elementWithFocus.MoveFocus(request);
                e.Handled = true;
                return;
            }
            //Clicking ENTER with nothing selected (i.e. no menu item) should act like ESC key
            if (e.Key == Key.Enter && !(e.OriginalSource is MenuItem))
            {
                tb.ContextMenu.IsOpen = false;
                e.Handled = true;
            }
            //We want the context menu to close whenever CTRL or ALT or ESC is pressed
            if ((Keyboard.Modifiers == ModifierKeys.Control) || (Keyboard.Modifiers == ModifierKeys.Alt) || (e.Key == Key.Escape))
            {
                tb.ContextMenu.IsOpen = false;
                tb.IsChecked = false;
                e.Handled = true;
            }
        }


        /// <summary>
        /// event handler this is called when an item in the context menu is clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CrumbButton_Click(object sender, RoutedEventArgs e)
        {
            //Explicitly close the context menu.  We need to do this because
            // buttons are used in the context menu crumbs and although they
            // are set to execute the correct commands to handle navigation,
            // they don't result in the closing of the context menu they
            // are contained in (set in XAML to the tag of the button)
            Button bu = sender as Button;
            ContextMenu cm = bu.Tag as ContextMenu;
            if (cm != null)
                cm.IsOpen = false;
        }

        /// <summary>
        /// Remove event handlers
        /// </summary>
        public void CleanupEventSubscriptions()
        {
            BreadCrumbViewModel bcvm = DataContext as BreadCrumbViewModel;
            bcvm.ActiveCrumbChanged -= new PropertyChangedEventHandler(bcvm_ActiveCrumbChanged);
            bcvm.CleanupEventSubscriptions();
        }


        /// <summary>
        /// User has navigated to a text crumb via a tab or shift-tab
        /// Idential functionality to ToggleButton_PreviewMouseLeftButtonDown which is used for click.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToggleButton_GotFocus(object sender, RoutedEventArgs e)
        {
            this.ToggleButton_Common_Functionality(sender as ToggleButton);
        }

        /// <summary>
        /// When user clicks on the control, show the context menu as is done in ToggleButton_GotFocus.
        /// Marking it handled prevents ToggleButton_GotFocus from being called.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToggleButton_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.ToggleButton_Common_Functionality(sender as ToggleButton);
            e.Handled = true;
        }

        private void ToggleButton_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            if ((e.Key == Key.Enter) || (e.Key == Key.Return) || (e.Key == Key.Space))
            {
                this.ToggleButton_Common_Functionality(sender as ToggleButton);
                e.Handled = true;
            }
        }
        
        /// <summary>
        /// When the mouse enters the frame of a toggle button, check for children so we properly
        /// enable/disable the button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ToggleButton_MouseEnter(object sender, MouseEventArgs e)
        {
            ToggleButton tb = sender as ToggleButton;
            BreadCrumbViewModel bcvm = DataContext as BreadCrumbViewModel;
            bcvm.GetChildrenCommand.Execute(tb.DataContext);
        }

        private void ToggleButton_Common_Functionality(ToggleButton tb)
        {
            // IsChecked causes a dotted rectangle around the arrow, and the arrow points downward.
            tb.IsChecked = true;
            ShowContextMenuCommand.Execute(tb);
        }

        /// <summary>
        /// Send help command up to the window to diplay help file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CommandBinding_HelpExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            RaiseEvent(e);
        }

        /// <summary>
        /// Give Keyboard Focus to the Breadcrumbs
        /// </summary>
        public void ProcessKeyboardRequestFocus()
        {
            this.Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.ApplicationIdle, new System.Threading.ThreadStart(() =>
            {
                if (_CrumbsGrid.Children.Count > 0)
                {
                    //Obtain the home button which will be a consistent element to set focus to
                    ContentPresenter firstCrumb = _CrumbsGrid.Children[0] as ContentPresenter;
                    DataTemplateKey homeDataTemplateKey = new DataTemplateKey(typeof(HomeCrumb));
                    DataTemplate homeDataTemplate = FindResource(homeDataTemplateKey) as DataTemplate;
                    Button homeButton = homeDataTemplate.FindName("HomeButton", firstCrumb) as Button;
                    PrimProcessKeyboardRequestFocus(homeButton);
                }
            }));
        }

        /// <summary>
        /// Give Keyboard Focus
        /// </summary>
        /// <param name="iElement"></param>
        private static void PrimProcessKeyboardRequestFocus(IInputElement iElement)
        {
            if (iElement == null) return;
            Keyboard.Focus(iElement);
        }
    }
}
