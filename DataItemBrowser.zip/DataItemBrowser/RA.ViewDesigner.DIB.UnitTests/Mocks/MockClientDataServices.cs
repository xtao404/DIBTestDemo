
using System;
using System.Collections.Generic;
using RockwellAutomation.ServiceFramework.DataTypes;

using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;

using System.Collections.ObjectModel;
using RockwellAutomation.UI.Models;
using System.ComponentModel;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.DIBQuery
{
    /// <summary>
    /// Mock of ClientDataService
    /// </summary>
    public class MockClientDataService : IClientDataServices, INotifyPropertyChanged
    {
        #region Variables/Properties

        public event PropertyChangedEventHandler PropertyChanged;
        private DataItemBrowserContext _lastInitializedDibContext = null; 

        public ProblemSetFunc _setProblemInfoDelegate = null;

        private DIBViewItemBase.VisualPerspectiveEnum _browserPerspective = DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;

        public DIBClientManager _DibClientManager = null;
        public DIBClientManager DibClientManager
        {
            get { return _DibClientManager; }
            set { _DibClientManager = value; }
        }

        private DataContext _dataContext = null;
        public DataContext DataContext
        {
            get { return _dataContext; }
            set { _dataContext = value; }
        }

        public List<ColumnConfigMapItem> Columns
        {
            get
            {
                return new List<ColumnConfigMapItem>();
            }
        }

        public MockClientDataService()
        {
            //Functionally does nothing, but just need to utilize these to avoid compiler warnings (about never using them)
            if (_lastInitializedDibContext != null && PropertyChanged!=null)
                PropertyChanged.Invoke((object)this, (PropertyChangedEventArgs)PropertyChangedEventArgs.Empty);
        }

        public bool IsBrowsingHMIDevice()
        {
            return false;
        }

        internal IDIBQueryCommand CurrentQueryCommand = null;

        /// <summary>
        /// This function returns whether or not we are curently executing a query command to QSP.
        /// </summary>
        /// <returns>Boolean representing whether or not a QSP query is in progress.</returns>
        public bool IsExecutingQueryCommand()
        {
            return this.CurrentQueryCommand != null;
        }

        // The current Query cache that holds onto the data collection and cached results
        private DIBQueryCache _cache;
        public DIBQueryCache QueryCache
        {
            get { return _cache; }
            set { _cache  = value; }
        }

        // Represents which view the GUI should display given the current context
        private IDIBDataViewType _dataView = new DIBDataViewTypeUnknown();
        public IDIBDataViewType DataView
        {
            get { return _dataView; }
            set { _dataView = value;}
        }

        #endregion

        public IObservableCollection<DataItemBase> GetCachedDevices()
        {
            IObservableCollection<DataItemBase> devices = _cache.GetCachedDevices() ?? new TSObservableCollection<DataItemBase>();
            return devices;
        }

        public DataItemBase CurrentParentDataItem()
        {
            return null;
        }

        public bool ShouldDisplayMetaData()
        {
            return _dataContext.DisplayMetaData;
        }

        public string SetProblemInfo(ProblemInfoType probType)
        {
            return String.Empty;
        }
        public void SetProblemCallback(ProblemSetFunc probDelegate)
        {
            _setProblemInfoDelegate = probDelegate;
        }

        public void PerformQuery_DataLoadComplete(QueryResponse qResponse)
        { }

        public void Initialize(DataItemBrowserContext context, InitializationComplete initCallback)
        {
            _dataContext = new DataContext();
            if (initCallback != null)
                initCallback(_dataContext, string.Empty);

        }

        public RockwellAutomation.Client.Services.Query.ColumnConfig GenerateColumnConfig()
        {
            RockwellAutomation.Client.Services.Query.ColumnConfig.CreateBuilder columns = new RockwellAutomation.Client.Services.Query.ColumnConfig.CreateBuilder();
            return columns.Build();
        }

        public DIBViewItemBase.VisualPerspectiveEnum CurrentBrowserPerspective()
        {
            return this._browserPerspective;
        }

        public bool IsTagBrowser()
        {
            return this.CurrentBrowserPerspective() == DIBViewItemBase.VisualPerspectiveEnum.TagBrowser;
        }

        public bool IsAOGPropertyBrowser()
        {
            return this.CurrentBrowserPerspective() == DIBViewItemBase.VisualPerspectiveEnum.AOGPropertiesBrowser;
        }

        public bool IsDataTypeBrowser()
        {
            return this.CurrentBrowserPerspective() == DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser;
        }

        public void SetPackageAndProjectContext(UUID packageContext, UUID projectContext)
        {}

        public DataItemBase GetDataItemByName(string itemName, string location = null)
        { return null; }

        public DataItemBase GetDataTypeItemByLocation(string datatype, string location)
        { return null; }

        public DataItemBase GetDeviceItemByName(string deviceName)
        {   return null; }

        public void UpdateColumnConfig(ColumnAttribute columnAttribute, string columnName, object columnValue)
        { }

        public void SaveColumnConfig()
        { }

        public bool DrillIn(DataItemBase dataItem)
        { return true;  }


        public bool DrillIn(DataItemBase dataItem, DataLoadComplete callback)
        { return true; }

        public bool Search(DataItemBase dataItem, SearchFilterConfig filterConfig)
        { return true; }

        public void Close()
        { }

        public List<DropArrowItem> GetChildrenOfCrumb(ACrumb crumb, string nextName)
        { return null; }
    }
}
