﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace RockwellAutomation.UI.Models
{

    /// <summary>
    /// the path used when  the DataItemBrowserContext(used for root, include and exclude paths
    /// </summary>
    public class ContextPath
    {
        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dataItems"></param>
        public ContextPath(List<DataItemBase> dataItems)
        {
            //create the list if it does not already exist
            if (dataItems == null)
                dataItems = new List<DataItemBase>();
            _dataItems = dataItems;
        }
        /// <summary>
        /// Get the dataitem that defines this path (i.e. the last item of the path)
        /// </summary>
        public DataItemBase DataItem
        {
            get 
            {
                if (_dataItems.Count ==0)
                    return null;
                return _dataItems.Last(); 
            }
        }
        /// <summary>
        /// get the parent to the baseitem
        /// </summary>
        public DataItemBase ParentDataItem
        {
            get 
            {
                
                //make sure there are at least 2 items
                if (_dataItems.Count >= 2)
                    //get the second to last item
                    return _dataItems[_dataItems.Count-2];
                return null;                
            }

        }

        /// <summary>
        /// get the device for the baseitem
        /// </summary>
        public DataItemBase DeviceDataItem
        {
            get
            {

                //make sure there are at least 1 item
                if (_dataItems.Count > 1)
                    //get the first item (it is the device)
                    return _dataItems[0];
                return null;
            }

        }
        /// <summary>
        /// get all the dataitems
        /// </summary>
        public List<DataItemBase> DataItemList
        {
            get { return _dataItems;  }
        }

       
        //private list of all dataitems in this path
        private List<DataItemBase> _dataItems = null;
    }
}
