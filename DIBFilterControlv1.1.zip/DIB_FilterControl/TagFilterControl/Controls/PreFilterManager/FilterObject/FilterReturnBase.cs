﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Controls.PreFilterManager.FilterObject
{
    public class FilterReturnBase
    {
        public List<FilterItemBase> Conditions { get; set; }
    }

    public class FilterItemBase
    {
        public int OrderSelectedItem { get; set; }

        public List<RuleItemBase> RuleItemsSource { get; set; }

        public RuleItemBase RuleSelectedItem { get; set; }

        public ConditionItemBase ConditionSelectedItem { get; set; }

        public ValueBase Value { get; set; }

        public AndOrValue AndOrValue { get; set; }
    }

    public class ValueBase
    {
        public RuleMetaDataType MetadataType { get; set; }

        public ConditionType ConditionType { get; set; }

        public RuleType RuleType { get; set; }

        public object Value { get; set; }
    }

    public enum AndOrValue
    {
        And = 0,

        Or = 1,

        None = 2
    }

    public class RuleItemBase
    {
        public string Id { get; set; }

        public RuleType RuleType { get; set; }

        public string ColumnName { get; set; }

        public string DisplayName { get; set; }

        public RuleMetaDataType MetaDataType { get; set; }
    }

    public enum RuleMetaDataType
    {
        Number = 0,

        String = 1,

        Enum =2,

        None = 3,
    }

    public enum RuleType
    {
        Unknown = 0,

        TagName = 1,

        TagType = 2,

        UserDefined = 3,

        Strings = 4,

        AddOnDefined = 5,

        ModuleDefined = 6,

        PreDefined = 7
    }

    public class ConditionItemBase
    {
        public string DisplayName { get; set; }

        public ConditionType ConditionType { get; set; }
    }

    public enum ConditionType
    {
        None = 0,

        Equal = 1,
        UnEqual = 2,
        Contain = 3,
        Except = 4,

        IsExactly = 5,

        LargerThan = 6,
        LessThan = 7
    }
}
