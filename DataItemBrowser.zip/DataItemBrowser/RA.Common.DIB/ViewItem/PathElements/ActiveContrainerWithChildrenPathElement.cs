﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using RockwellAutomation.Client.Services.Query.AbstractItem;


namespace RockwellAutomation.UI
{
    /// <summary>
    /// ActiveContrainerWithChildrenPathElement. PathElement
    /// </summary>
    public class ActiveContrainerWithChildrenPathElement : PathElementBase
    {
        #region private members

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
        protected string _displayName = string.Empty;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
        protected bool _hasChildren = true;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
        protected bool _isActive = true;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1051:DoNotDeclareVisibleInstanceFields")]
        protected bool _isContainer = true;

        #endregion

        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public ActiveContrainerWithChildrenPathElement(DataItemBase dataItem, string displayName)
                :base(dataItem, displayName)
        {
        }

        #endregion

        #region PathElementBase overrides

        /// <summary>
        /// Property to get or set the path element's display name.
        /// </summary>
        public override string DisplayName
        {
            get { return _displayName; }
            set
            {
                if (_displayName == value)
                    return;
                _displayName = value;
                // notify listeners
                NotifyPropertyChanged("DisplayName");
            }
        }

        /// <summary>
        /// Property to get or set if the path element has children.
        /// </summary>
        public override bool HasChildren
        {
            get { return _hasChildren; }
        }

        /// <summary>
        /// Property to get or set if the path element is active.
        /// </summary>
        public override bool IsActive
        {
            get { return _isActive; }
            set
            {
                if (_isActive == value)
                    return;
                _isActive = value;
                //notify listeners
                NotifyPropertyChanged("IsActive");
            }
        }

        /// <summary>
        /// Property to get or set if the path element is a container.
        /// </summary>
        public override bool IsContainer
        {
            get { return _isContainer; }
        }

        #endregion
    }
}
