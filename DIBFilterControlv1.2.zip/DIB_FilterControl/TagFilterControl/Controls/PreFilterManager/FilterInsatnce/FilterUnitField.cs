﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.Object;

namespace TagFilterControl.Controls.PreFilterManager.FilterInsatnce
{
    public class FilterUnitField
    {
        public String Reason { get; set; }
        public String FieldName { get; set; }
        public String FieldTitle { get; set; }
        public AndOrValue Policy { get; set; }
        public RuleType RuleType { get; set; }
        public ConditionType Condition { get; set; }
        public RuleMetaDataType FieldType { get; set; }

        public FilterUnitField()
        {
            Reason = string.Empty;
        }

        public virtual void Initialize(FilterItemBase filterItem)
        {
            this.Policy = filterItem.AndOrValue;
            this.RuleType = filterItem.RuleSelectedItem.RuleType;
            this.FieldType = filterItem.RuleSelectedItem.MetaDataType;
            this.Condition = filterItem.ConditionSelectedItem.ConditionType;
            if (String.IsNullOrEmpty(filterItem.RuleSelectedItem.ColumnName))
                this.FieldName = filterItem.RuleSelectedItem.DisplayName;
            else
            {
                this.FieldName = filterItem.RuleSelectedItem.ColumnName;
                this.FieldTitle = filterItem.RuleSelectedItem.DisplayName;
            }
        }

        public bool Apply(object value, TagObjects tag)
        {
            return DoApply(value, tag);
        }

        protected virtual bool DoApply(object fieldValue, TagObjects tag)
        {
            return true;
        }
    }
}
