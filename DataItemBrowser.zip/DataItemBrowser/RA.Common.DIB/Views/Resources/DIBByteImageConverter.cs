﻿using System;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// This class used to take a byte array representing an image and convert it to an image
    /// </summary>
    public abstract class DIBByteImageConverter
    {
        public static ImageSource ByteToImage(byte[] imageData)
        {
            BitmapImage biImg = new BitmapImage();
            biImg.BeginInit();
            biImg.StreamSource = new MemoryStream(imageData);
            biImg.EndInit();       

            ImageSource imgSrc = biImg as ImageSource;
            return imgSrc;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        public static string ImageToByte(FileStream fs)
        {
            byte[] imgBytes = new byte[fs.Length];
            fs.Read(imgBytes, 0, Convert.ToInt32(fs.Length));
            return Convert.ToBase64String(imgBytes, Base64FormattingOptions.InsertLineBreaks); //return encoded data
        }
    } 
}