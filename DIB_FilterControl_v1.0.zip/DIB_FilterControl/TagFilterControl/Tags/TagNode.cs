﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Common;
using TagFilterControl.Controls;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.DIBClientManagers.DataGridViewSimple;
using TagFilterControl.Utility;

namespace TagFilterControl.Tags
{
    public class TagNode : BaseNode
    {
        private Config config = Config.GetInstance();
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();

        public static List<string> DefaultTopNodes = new List<string>() { "User-Defined", "Strings", "Add-On-Defined", 
            "PreDefined", "Module-Defined", "Usage", "ACM", "Catalog Number", "Interface", "DataMembers"};

        private string name;
        public string Name
        {
            get { return this.name; }
            set
            {
                this.name = value;
                this.RaisePropertyChangedEvent(() => this.Name);
            }
        }

        private bool isChecked;
        public bool IsChecked
        {
            get { return this.isChecked; }
            set
            {
                this.isChecked = value;
                OnIsCheckedChanged(this);
                this.RaisePropertyChangedEvent(() => this.IsChecked);
            }
        }

        private bool isLastChild = false;
        public bool IsLastChild
        {
            get { return isLastChild; }
            set { isLastChild = value; }
        }

        private bool hasChild = false;
        public bool HasChild
        {
            get { return hasChild; }
            set { hasChild = value; }
        }

        private void OnIsCheckedChanged(TagNode currentNode)
        {
            bool flag = false;
            bool _flag = false;
            if (currentNode.IsChecked && !DefaultTopNodes.Contains(currentNode.Name))
            {
                if (xmlHelper.Mems.Contains(currentNode.Name) || xmlHelper.CatalogNumber.Keys.Contains(currentNode.Name)
                    || xmlHelper.Interface.Keys.Contains(currentNode.Name))
                {
                    if (xmlHelper.Mems.Contains(currentNode.Name) && !config.MemFilter.Keys.Contains(currentNode.Name))
                    {
                        config.MemFilter[currentNode.Name] = currentNode;
                    }

                    if (!config.ACMCustomPropertiesFilter.Keys.Contains(currentNode.Name))
                    {
                        config.ACMCustomPropertiesFilter[currentNode.Name] = currentNode;
                    }
                }
                else if (!config.IsCheckedTags.Keys.Contains(currentNode.Name))
                {
                    config.IsCheckedTags[currentNode.Name] = currentNode;
                }
            }
            else
            {
                if (config.ACMCustomPropertiesFilter.Keys.Contains(currentNode.Name))
                {
                    config.ACMCustomPropertiesFilter.Remove(currentNode.name);


                    if (config.MemFilter.Keys.Contains(currentNode.Name))
                    {
                        config.MemFilter.Remove(currentNode.name);
                    }
                }
                else if (config.IsCheckedTags.Keys.Contains(currentNode.Name))
                {
                    config.IsCheckedTags.Remove(currentNode.Name);
                }
            }

            if (currentNode.ParentNode != null)
            {
                foreach (var item in currentNode.ParentNode.Children)
                {
                    if (item.IsChecked)
                    {
                        flag = true;
                    }
                    else
                    {
                        _flag = true;
                    }
                }

                if (!flag)
                {
                    if (currentNode.ParentNode.IsChecked)
                    {
                        currentNode.ParentNode.IsChecked = false;
                    }
                }
                else if (!_flag)
                {
                    if (!currentNode.ParentNode.IsChecked)
                    {
                        currentNode.ParentNode.IsChecked = true;
                    }
                }
            }

            foreach (var item in currentNode.Children)
            {
                item.IsChecked = currentNode.IsChecked;
            }

            if (filterDIBIn.DIBClientManager != null)
            {
                filterDIBIn._FilterDIB.dib.Dispatcher.BeginInvoke(new Action(() =>
                {
                    (filterDIBIn.DIBClientManager as DataGridViewDemo).GridVM.ExecuteDrillInCommand((filterDIBIn.DIBClientManager as DataGridViewDemo).ParentDataItemBase);
                }));
            }
        }

        private bool isLoaded;
        public bool IsLoaded
        {
            get { return this.isLoaded; }
            set
            {
                this.isLoaded = value;
                this.RaisePropertyChangedEvent(() => this.IsLoaded);
            }
        }

        private bool isExpanded;
        public bool IsExpanded
        {
            get { return this.isExpanded; }
            set
            {
                this.isExpanded = value;
                this.RaisePropertyChangedEvent(() => this.IsExpanded);
            }
        }

        private bool isSelected;
        public bool IsSelected
        {
            get { return this.isSelected; }
            set
            {
                this.isSelected = value;
                this.RaisePropertyChangedEvent(() => this.IsSelected);
            }
        }

        public Types Type { get; set; }

        private ObservableCollection<TagNode> children = new ObservableCollection<TagNode>();
        public ObservableCollection<TagNode> Children
        {
            get { return children; }
            set
            {
                children = value;
                this.RaisePropertyChangedEvent(() => this.Children);
            }
        }

        public TagNode ParentNode { get; set; }
    }

    public enum Types
    {
        None,
        CoreType,
        LibraryType,
        Category,
        Libraries,
        CatalogNumber,
        Interface,
        DataMembers,
        InterfaceSelf,
        DataMemberSelf,
        CatalogNumberSelf,
        Name,
        KEYID
    }
}
