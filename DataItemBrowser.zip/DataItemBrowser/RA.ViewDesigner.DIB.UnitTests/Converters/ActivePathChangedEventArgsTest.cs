﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for ActivePathChangedEventArgsTest and is intended
    ///to contain all ActivePathChangedEventArgsTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ActivePathChangedEventArgsTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for ActivePathChangedEventArgs Constructor
        ///</summary>
        [TestMethod()]
        public void ActivePathChangedEventArgsConstructorTest()
        {
            string propertyName = "ActivePath"; 
            bool hasActiveElements = true; 
            ActivePathChangedEventArgs target = new ActivePathChangedEventArgs(propertyName, hasActiveElements);
            Assert.AreEqual(hasActiveElements, target.HasActiveElements);
            Assert.AreEqual(propertyName, target.PropertyName);
        }

        /// <summary>
        ///A test for HasActiveElements
        ///</summary>
        [TestMethod()]
        public void ActivePathChangedEventArgs_HasActiveElementsTest()
        {
            string propertyName = "ActivePath"; 
            bool hasActiveElements = true; 
            ActivePathChangedEventArgs target = new ActivePathChangedEventArgs(propertyName, hasActiveElements); 
            bool actual;
            actual = target.HasActiveElements;
            Assert.AreEqual(hasActiveElements, actual);
        }
    }
}
