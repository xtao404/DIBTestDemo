﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.Common;
using TagFilterControl.Controls.PreFilterManager.FilterInsatnce;
using TagFilterControl.Tags;

namespace TagFilterControl.Service
{
    interface ITagService
    {
        TagTreeViewResult LoadSubItems(TagNode selectNode);
        object SaveFilterInfo(FilterProfile filterDto, OperationAction action);
        QueryListResult<FilterProfile> QueryFilterItems();
        QueryListResult<FilterProfile> LoadFilterByIdAndInitializeFilterItem(FilterProfile dto, FilterManager filterManager);
    }

    public class TagTreeViewResult : Result
    {
        public ObservableCollection<TagNode> Children { get; set; }
    }
}
