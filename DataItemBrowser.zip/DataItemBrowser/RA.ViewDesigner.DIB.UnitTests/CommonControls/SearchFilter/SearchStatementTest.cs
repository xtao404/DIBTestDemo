﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI.CommonControls;
using System.Collections.ObjectModel;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for SearchStatementTest and is intended
    ///to contain all SearchStatementTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SearchStatementTest
    {

        //These constants should match the strings in the CommonControls Resources.resx file 
        public const string ERROR_SEARCH_CANNOT_START_WITH_SPACE = "Filter value containing only spaces must be surrounded with quotes.";	
        public const string ERROR_SEARCH_BLANK_SPACE_MISSING	= "Blank space missing for:";	
        public const string ERROR_SEARCH_CLOSE_PARENTHESIS_MISSING	= "Close parenthesis missing for:";
        public const string ERROR_SEARCH_DELETE_BLANK_SPACES	= "Delete blank spaces for:";
        public const string ERROR_SEARCH_EXPECTED_OPERATOR	= "Expected an operator:";
        public const string ERROR_SEARCH_FILTER_STATEMENT_MISSING	= "Filter statement missing after operator for:";
        public const string ERROR_SEARCH_FILTER_VALUE_MISSING	= "Filter value missing for:";
        public const string ERROR_SEARCH_KEYWORD_INCORRECTLY_USED	= "Keyword AND/OR should be used between 2 statements.";
        public const string ERROR_SEARCH_OPEN_PARENTHESIS_MISSING	= "Open parenthesis missing for:";
        public const string ERROR_SEARCH_PARENTHESES_CANNOT_BE_NESTED	= "Parentheses cannot be nested.";
        public const string ERROR_SEARCH_PARENTHESES_MUST_SURROUND_FILTER_VALUES	= "Parentheses must surround only filter values.";
        public const string ERROR_SEARCH_QUOTATION_MARK_MISSING	= "Quotation mark missing for:";
        public const string ERROR_SEARCH_QUOTATION_MARKS_INCORRECT	= "Quotation marks must surround only search and filter statements.";
        public const string ERROR_SEARCH_SEARCHING_NOT_SUPPORTED	= "Searching is not supported:";
        public const string ERROR_SEARCH_UNEXPECTED_WHITESPACE = "Unexpected whitespace following:";


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        private SearchFilterParser _parser = null;
        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            _parser = new SearchFilterParser();
        }
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        // Delegate for IsMatch and ApplyFilter
        public static string ReturnFieldValue(string fieldName, object item)
        {
            return ((DataItemBase)item).GetStringMapValue(fieldName);
        }

        /// <summary>
        /// filter types used by parse method
        /// </summary>
        private ObservableCollection<FilterType> _filterTypes = null;

        /// <summary>
        /// private method to generate the a collection of Data Item Base elements
        /// </summary>
        private ObservableCollection<DataItemBase> GenerateTestCollection()
        {
            ObservableCollection<DataItemBase> myTestCollection = new ObservableCollection<DataItemBase>();

            // Add a set of Data Item Bases into the collection for testing.
            DataItemBase itemBase = new DataItemBase();
            itemBase.CommonName = "mytag";
            myTestCollection.Add(itemBase);
            
            // Add a set of Data Item Bases into the collection for testing.
            itemBase = new DataItemBase();
            itemBase.CommonName = "MYSECONDTAG";
            myTestCollection.Add(itemBase);

            // Add a set of Data Item Bases into the collection for testing.
            itemBase = new DataItemBase();
            itemBase.CommonName = "myTHIRDtag";
            myTestCollection.Add(itemBase);

            // Add a set of Data Item Bases into the collection for testing.
            itemBase = new DataItemBase();
            //create Name property and assign it to the dataItemBase
            itemBase.CommonName = "my Fourth tag";
            myTestCollection.Add(itemBase);

            // Add a set of Data Item Bases into the collection for testing.
            itemBase = new DataItemBase();
            itemBase.CommonDescription = "my Fifth Tag - no name only description";
            myTestCollection.Add(itemBase);

            return myTestCollection;
        }
        
        /// <summary>
        /// private method to generate the valid filter types
        /// </summary>
        private void GenerateFilterTypes()
        {
            _filterTypes = new ObservableCollection<FilterType>
                               {
                                   new FilterType(DIBConstants.Common.Name,true,false),
                                   new FilterType(DIBConstants.Common.DataType,false,false),
                                   new FilterType(DIBConstants.Common.Description,false,false)
                               };
        }

        /// <summary>
        ///A test for SearchValue
        ///</summary>
        [TestMethod()]
        public void SearchStatement_SearchValueTest()
        {
            SearchStatement target = new SearchStatement(); 
            ParserToken expected = new ParserToken(SearchFilterParser.ValueGroup,"my",0,false);
            
            target.SearchValue = expected;
            ParserToken actual = target.SearchValue;
            Assert.AreEqual(expected, actual);            
        }

        /// <summary>
        ///A test for OperatorToken
        ///</summary>
        [TestMethod()]
        public void SearchStatement_OperatorTokenTest()
        {
            SearchStatement target = new SearchStatement();
            ParserToken expected = new ParserToken(SearchFilterParser.BaseOperatorGroup, "AND", 11, false);
            
            target.OperatorToken = expected;
            ParserToken actual = target.OperatorToken;
            Assert.AreEqual(expected, actual);
            
        }

        /// <summary>
        ///A test for GetString
        ///</summary>
        [TestMethod()]
        public void SearchStatement_GetString_VariousCombinations()
        {
            //ARRANGE
            SearchStatement target = new SearchStatement();
            ParserToken valueToken = new ParserToken(SearchFilterParser.ValueGroup, "my", 0, false);
            target.SearchValue = valueToken;

            //ACT
            string value = target.GetSearchString();
            //ASSERT
            Assert.IsTrue(value.Contains("my"));

            //ARRANGE
            ParserToken operatorToken = new ParserToken(SearchFilterParser.BaseOperatorGroup, "AND", 11, false);
            target.OperatorToken = operatorToken;
            //ACT
            value = target.GetSearchString();
            //ASSERT
            Assert.IsTrue(value.Contains("my") && value.Contains("AND"));

            //ARRANGE
            valueToken = new ParserToken(SearchFilterParser.ValueGroup, "exactMatch", 0, true);
            target.SearchValue = valueToken;
            //ACT
            value = target.GetSearchString();
            //ASSERT
            Assert.IsTrue(value.Contains("\"exactMatch\"") && value.Contains("AND"));
        }

        /// <summary>
        ///A test for IsMatch
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_ValidSearchStatement_SuccessfulMatchTest()
        {   
            //ARRANGE
            GenerateFilterTypes();
            PrivateType privateSearchFilterDef = new PrivateType(typeof(SearchFilterDefinition));
            privateSearchFilterDef.SetStaticProperty("FilterTypes", _filterTypes);
            
            //create the searchstatement from the search text
            SearchStatement target = new SearchStatement();
            target.SearchValue = new ParserToken(SearchFilterParser.ValueGroup, "my", 0, false);
            target.OperatorToken = null;

            //create the objects to find the search text in
            DataItemBase itemBase = new DataItemBase();
            itemBase.CommonName = "mytag";

            //ACT
            bool actual = target.IsMatch(itemBase, ReturnFieldValue);

            //ASSERT
            Assert.IsTrue(actual);
        }

        /// <summary>
        ///A test for ApplyViewFilter calling IsMatch with a search strings 
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_UsingSearchString_MatchesFoundTest()
        {
            //ARRANGE
            ObservableCollection<DataItemBase> myTags = null;
            myTags = GenerateTestCollection();
            GenerateFilterTypes();

            _parser.Parse("tag", _filterTypes, true);

            int matchingCount = 0;

            //ACT
            foreach (DataItemBase myTag in myTags)
            {
                if (_parser.FilterDefinition.ApplyViewFilter(myTag, ReturnFieldValue))
                {
                    matchingCount++;
                }
            }

            //ASSERT
            Assert.AreEqual(4, matchingCount, "expected to match 4 data item base records.");

        }

        /// <summary>
        ///A test for Parse with an empty search string
        ///</summary>
        [TestMethod()]
        public void SearchStatement_Parse_EmptySearchString_HasNonEmptySearchFalseTest()
        {
            //ARRANGE
            ObservableCollection<DataItemBase> myTags = null;
            myTags = GenerateTestCollection();
            GenerateFilterTypes();

            //ACT
            if (_parser.Parse("", _filterTypes, true))
            {
                //ASSERT
                Assert.IsFalse(_parser.FilterDefinition.HasNonEmptySearchValue);
            }

            //ACT
            if (_parser.Parse("\"\"", _filterTypes, true))
            {
                //ASSERT
                Assert.IsFalse(_parser.FilterDefinition.HasNonEmptySearchValue);
            }

            //ACT
            if (_parser.Parse("n:\"\"", _filterTypes, true))
            {
                //ASSERT
                Assert.IsFalse(_parser.FilterDefinition.HasNonEmptySearchValue);
            }

            //ACT
            if (_parser.Parse("n:\"\" dt:\"\" d:\"\"", _filterTypes, true))
            {
                //ASSERT
                Assert.IsFalse(_parser.FilterDefinition.HasNonEmptySearchValue);
            }
           
        }

        /// <summary>
        ///A test for Parse with empty search string and empty filter string
        /// All inputs should yield the same error message
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_UsingEmptySearchString_QuotationMarkErrorTest()
        {
            //ARRANGE
            ObservableCollection<DataItemBase> myTags = null;
            myTags = GenerateTestCollection();
            GenerateFilterTypes();

            //ACT            
            if (!_parser.Parse("\"\"", _filterTypes, true))
            {                                
                //ASSERT                
                Assert.IsTrue(_parser.FilterDefinition.HasError);
                Assert.AreEqual(_parser.FilterDefinition.ErrorToken.SyntaxErrorMessage, ERROR_SEARCH_QUOTATION_MARKS_INCORRECT);
            }

            //ACT
            if (_parser.Parse("n:\"\"", _filterTypes, true))
            {
                //ASSERT
                Assert.IsTrue(_parser.FilterDefinition.HasError);
                Assert.AreEqual(_parser.FilterDefinition.ErrorToken.SyntaxErrorMessage, ERROR_SEARCH_QUOTATION_MARKS_INCORRECT);
            }

            //ACT
            if (_parser.Parse("n:\"\" dt:\"\" d:\"\"", _filterTypes, true))
            {
                //ASSERT
                Assert.IsTrue(_parser.FilterDefinition.HasError);
                Assert.AreEqual(_parser.FilterDefinition.ErrorToken.SyntaxErrorMessage, ERROR_SEARCH_QUOTATION_MARKS_INCORRECT);
            }

        }

         /// <summary>
        ///A test for Parse with space search string         
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_UsingSpaceSearchString_OneMatchTest()
         {
             //ARRANGE
             ObservableCollection<DataItemBase> myTags = null;
             myTags = GenerateTestCollection();

             //add another dataitem base to the collection with a name and description, the SearchStatement.IsMatch returns before checking the 
             //description if the name is null                        
             DataItemBase itemBase = new DataItemBase();
             itemBase.CommonName = "my special tag";
             itemBase.CommonDescription = "my special Tag - This description has spaces in it.";

             myTags.Add(itemBase);                        

            //filter types with name and description searchable
             _filterTypes = new ObservableCollection<FilterType>
                               {
                                   new FilterType(DIBConstants.Common.Name,true,false),
                                   new FilterType(DIBConstants.Common.DataType,false,false),
                                   new FilterType(DIBConstants.Common.Description,true,false)
                               };

             //ACT            
             if (_parser.Parse("\" \"", _filterTypes, true))
             {
                 int matchingCount = 0;

                 //ACT
                 foreach (DataItemBase myTag in myTags)
                 {
                     if (_parser.FilterDefinition.ApplyViewFilter(myTag, ReturnFieldValue))
                     {
                         matchingCount++;
                     }
                 }

                 //ASSERT                
                 Assert.AreEqual(1, matchingCount, "expected to match 1 data item base records.");
             }           

         }

        /// <summary>
        ///A test for Parse with space filter string         
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_UsingSpaceFilterString_TwoMatchesTest()
        {
            //ARRANGE
            ObservableCollection<DataItemBase> myTags = null;
            myTags = GenerateTestCollection();

            //add another dataitem base to the collection with a name and description
            DataItemBase itemBase = new DataItemBase();
            itemBase.CommonName = "my special tag";
            itemBase.CommonDescription = "my special Tag - This description has spaces in it.";

            myTags.Add(itemBase);

            //filter types with name and description searchable
            _filterTypes = new ObservableCollection<FilterType>
                               {
                                   new FilterType(DIBConstants.Common.Name,true,false),
                                   new FilterType(DIBConstants.Common.DataType,false,false),
                                   new FilterType(DIBConstants.Common.Description,true,false)
                               };

            //ACT            
            if (_parser.Parse("d:\" \"", _filterTypes, true))
            {
                int matchingCount = 0;

                //ACT
                foreach (DataItemBase myTag in myTags)
                {
                    if (_parser.FilterDefinition.ApplyViewFilter(myTag, ReturnFieldValue))
                    {
                        matchingCount++;
                    }
                }

                //ASSERT
                //The FilterStatement.IsMatch will pull the filter value to compare and not look at all searchable filters so the dataitem with 
                //no name that has a description will match the search criteria
                Assert.AreEqual(2, matchingCount, "expected to match 2 data item base records.");
            }

        }

        /// <summary>
        ///A test for ApplyViewFilter calling IsMatch with two search strings and the AND operator.
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_SearchTwoStringAnd_OneMatchTest()
        {
            //ARRANGE
            ObservableCollection<DataItemBase> myTags = null;
            myTags = GenerateTestCollection();
            GenerateFilterTypes();
            DataItemBase myMatchedTag = null;

            //ACT
            _parser.Parse("tag AND Fourth", _filterTypes, true);

            int matchingCount = 0;
            foreach (DataItemBase myTag in myTags)
            {
                if (_parser.FilterDefinition.ApplyViewFilter(myTag, ReturnFieldValue)) 
                {
                    matchingCount++;
                    myMatchedTag = myTag;
                }
            }

            //ASSERT
            Assert.AreEqual(1, matchingCount, "expected to match 1 data item base records.");
            Assert.IsNotNull(myMatchedTag);
            Assert.AreEqual("my Fourth tag", myMatchedTag.CommonName, "matched to wrong Data Item Base record.");
        }

        /// <summary>
        ///A test for ApplyViewFilter calling IsMatch with two search strings and the OR operator.
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_SearchTwoStringOr_ThreeMatchesTest()
        {
            //ARRANGE
            ObservableCollection<DataItemBase> myTags = null;
            myTags = GenerateTestCollection();
            GenerateFilterTypes();

            //ACT
            _parser.Parse("myt OR Second", _filterTypes, true);

            int matchingCount = 0;
            foreach (DataItemBase myTag in myTags)
            {
                if (_parser.FilterDefinition.ApplyViewFilter(myTag, ReturnFieldValue))
                {
                    matchingCount++;
                }
            }

            //ASSERT
            Assert.AreEqual(3, matchingCount, "expected to match 3 data item base records.");
        }

        /// <summary>
        ///A test for ApplyViewFilter calling IsMatch with two search strings, one not in a Name.
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_SearchValidOrInvalidString_OneMatchTest()
        {
            //ARRANGE
            ObservableCollection<DataItemBase> myTags = null;
            myTags = GenerateTestCollection();
            GenerateFilterTypes();
            DataItemBase myMatchedTag = null;

            //ACT
            _parser.Parse("Fifth OR Second", _filterTypes, true);

            int matchingCount = 0;
            foreach (DataItemBase myTag in myTags)
            {
                if (_parser.FilterDefinition.ApplyViewFilter(myTag, ReturnFieldValue))
                {
                    matchingCount++;
                    myMatchedTag = myTag;
                }
            }

            //ASSERT
            Assert.AreEqual(1, matchingCount, "expected to match 1 data item base records.");
            Assert.IsNotNull(myMatchedTag);
            Assert.AreEqual("MYSECONDTAG", myMatchedTag.CommonName, "matched to wrong Data Item Base record.");
        }

        /// <summary>
        ///A test for ApplyViewFilter calling IsMatch with a search string OR a Filter.
        ///</summary>
        [TestMethod()]
        public void SearchStatement_IsMatch_SearchWithFilterOR_TwoMatchesTest()
        {
            //ARRANGE
            ObservableCollection<DataItemBase> myTags = null;
            myTags = GenerateTestCollection();
            GenerateFilterTypes();
    
            //ACT
            _parser.Parse("Description:Fifth OR Second", _filterTypes, true);

            int matchingCount = 0;
            foreach (DataItemBase myTag in myTags)
            {
                if (_parser.FilterDefinition.ApplyViewFilter(myTag, ReturnFieldValue))
                {
                    matchingCount++;
                }
            }

            //ASSERT
            Assert.AreEqual(2, matchingCount, "expected to match 2 data item base records.");
        }
    }
}
