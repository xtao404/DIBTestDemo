using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System;


namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// an observable collection of PathElements, this collection should reflect the path to the currently active element
    /// </summary>
    public class PathElementObservableCollection : ObservableCollection<IPathElement>
    {
        #region Event handling

        /// <summary>
        /// Event routing triggered when a path element changes its active state
        /// </summary>
        public event PropertyChangedEventHandler ActivePathChanged;

        protected void NotifyActivePathChanged()
        {
            if (ActivePathChanged != null)
            {
                bool hasActive = false;
                if (Count > 1)
                    hasActive = true;
                else if (Count > 0)
                    hasActive = this[0].DataItem != null;
                ActivePathChanged(this, new ActivePathChangedEventArgs(String.Empty, hasActive));
            }
        }

        #endregion
        /// <summary>
        /// constructor
        /// </summary>
        public PathElementObservableCollection()
        {

        }
        /// <summary>
        /// update any listeners when the collection changed event occurs
        /// </summary>
        /// <param name="e"></param>
        protected override void OnCollectionChanged(NotifyCollectionChangedEventArgs e)
        {
            base.OnCollectionChanged(e);
            //stop listening to any deleted elements
            if (e.OldItems != null)
            {
                foreach (IPathElement pe in e.OldItems)
                {
                    pe.PropertyChanged -= new System.ComponentModel.PropertyChangedEventHandler(pe_PropertyChanged);
                }
            }
            //start listening to any added elements
            if (e.NewItems != null)
            {
                foreach (IPathElement pe in e.NewItems)
                {
                    pe.PropertyChanged += new System.ComponentModel.PropertyChangedEventHandler(pe_PropertyChanged);
                }
            }
            //notify any listeners that the active path may have changed
            NotifyActivePathChanged();
        }

        /// <summary>
        /// listener for path elements to send an active path chagned notification if the element 
        /// receives an IsActive property changed notification
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void pe_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "IsActive")
            {
                NotifyActivePathChanged();
            }

        }
        /// <summary>
        /// override the Clear method so we send out notification for the deletes
        /// this method is used during final cleanup and must remove all pathElements
        /// </summary>
        public new void Clear()
        {
            //clear out all but the home pathElement
            ClearPreserveHome();
            //clear out the home pathElement
            if (this.Count == 1)
            {
                this[0].PropertyChanged -= pe_PropertyChanged;
                Remove(this[0]);
            }
        }
        /// <summary>
        /// override the ClearPreserveHome method so we send out notification for the deletes
        /// but does not remove the home path element
        /// </summary>
        public void ClearPreserveHome()
        {
            //they must be deleted in reverse order
            for (int i = this.Count - 1; i >= 0; i--)
            {
                if (!(this[i] is HomePathElement))
                {
                    this[i].PropertyChanged -= pe_PropertyChanged;
                    Remove(this[i]);
                }
            }
        }

    }

    
        
}
