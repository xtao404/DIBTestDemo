﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Reflection;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.DIBQuery;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    class DIBClientManager_1_TreeViewSimple : DIBClientManager
    {

        public const string _DrillInLEVELINDICATOR = "DrillInLevel";
        protected int nextAutoNumber = 0;

        #region "Overrides"

        public override void DrillInFor(
            DataItemBase dataItemToDrillInto,
            DIBQueryCache queryCache)
        {
            int nextDrillInLevel = 1;
            // if dataItemToDrillInto == null then we either just launched the DIB and are displaying the initial view or we are navigating back to the intial view
            if (dataItemToDrillInto == null)
            {
                CreateViewDataItems(nextDrillInLevel, queryCache);
                return;
            }
            // We are drilling into an instance of DataItemBase we already have created.
            // We stored the drill in level on the DataItemBase instance itself. Retrieve that now and call our code to create new DataItemBase instances and add them to the cache
            nextDrillInLevel = (int.Parse(dataItemToDrillInto.GetStringMapValue(_DrillInLEVELINDICATOR))) + 1;
            CreateViewDataItems(nextDrillInLevel, queryCache);
        }

        #endregion

        #region "Custom Drill in Logic"

        protected virtual void CreateViewDataItems(int drillInLevel, DIBQueryCache queryCache)
        {
            DataItemBase parent = new DataItemBase()
            {
                CommonName = "parent level " + drillInLevel,
                GUIShowChildrenInBreadCrumbTrail = "true",
                GUITreeViewParentID = string.Empty,
                GUITreeViewID = this.GetNextAutoNumber(),
                GUIIsExpanded = "True",
            };
            parent.SetStringMapValue(_DrillInLEVELINDICATOR, drillInLevel.ToString());
            queryCache.AddDataItem(parent);

            //Add children
            queryCache.AddDataItem(this.CreateDIBFrom("1st child level ",
                parent.GUITreeViewID,
                this.GetNextAutoNumber(),
                "True",
                drillInLevel.ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("2nd child level ",
                parent.GUITreeViewID,
                this.GetNextAutoNumber(),
                "True",
                drillInLevel.ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("3rd child level ",
                parent.GUITreeViewID,
                this.GetNextAutoNumber(),
                "True",
                drillInLevel.ToString()));
        }

        protected string GetNextAutoNumber()
        {
            this.nextAutoNumber++;
            return this.nextAutoNumber.ToString();
        }

        virtual public DataItemBase CreateDIBFrom(string name, string parentID, string treeId, string supportsDrillin, string levelIndicator)
        {
            DataItemBase dib = new DataItemBase()
            {
                CommonName = name + levelIndicator,
                GUIShowChildrenInBreadCrumbTrail = "true",
                GUITreeViewParentID = parentID,
                GUITreeViewID = treeId,
                GUISupportsDrillIn = supportsDrillin,
                GUISupportsSelection = "True",
                GUIIsExpanded = "True"
            };
            dib.SetStringMapValue(_DrillInLEVELINDICATOR, levelIndicator.ToString());
           
            return dib;
        }


        #endregion
    }
}
