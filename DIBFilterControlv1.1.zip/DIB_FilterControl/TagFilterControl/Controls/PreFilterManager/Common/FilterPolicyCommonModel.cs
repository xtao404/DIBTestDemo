﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.Object;
using TagFilterControl.Utility;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public abstract class FilterPolicyCommonModel
    {
        public abstract ConditionFilterBaseModel GetNewFilterData(ObservableCollection<ConditionFilterBaseModel> filterItemSource);

        public abstract object GetValue(FilterRuleType rule);

        public abstract void ConvertConditionFilterToProfile(ObservableCollection<ConditionFilterBaseModel> returnData, ref FilterProfile dto);

        public abstract ObservableCollection<ConditionFilterBaseModel> ConvertProfileContentToFilterFoundation(FilterProfile dto);

        protected AndOr MappingFromLDAndOrToAndOr(AndOrValue andor)
        {
            switch (andor)
            {
                case AndOrValue.And: return AndOr.And;
                case AndOrValue.None: return AndOr.None;
                case AndOrValue.Or: return AndOr.Or;
            }
            return AndOr.None;
        }
    }

    public static class FilterPolicyRuleTypeId
    {
        public const string Unknown = "0";

        public const string TagName = "1";

        public const string TagType = "2";

        public const string UserDefined = "3";

        public const string Strings = "4";

        public const string AddOnDefined = "5";

        public const string ModuleDefined = "6";

        public const string PreDefined = "7";
    }

    public class FilterPolicyCommonUtil
    {
        private static XMLHelper xmlHelper = XMLHelper.GetInstance();
        public static ObservableCollection<ConditionItemForDisplay> GetConditionItemsByRule(RuleItemForDisplay item)
        {
            var rule = (FilterRuleCustomType)item.conRuleType;
            ObservableCollection<ConditionItemForDisplay> list = new ObservableCollection<ConditionItemForDisplay>();
            switch (rule)
            {
                case FilterRuleCustomType.Enum:
                    list.Add(new ConditionItemForDisplay() { DisplayValue = "IsExactly", ConConditionType = FilterConditionType.IsExactly });
                    break;
                case FilterRuleCustomType.Number:
                    list.Add(new ConditionItemForDisplay() { DisplayValue = "LargerThan", ConConditionType = FilterConditionType.LargerThan });
                    list.Add(new ConditionItemForDisplay() { DisplayValue = "LessThan", ConConditionType = FilterConditionType.LessThan });
                    list.Add(new ConditionItemForDisplay() { DisplayValue = "Equal", ConConditionType = FilterConditionType.Equal });
                    break;
                case FilterRuleCustomType.String:
                    list.Add(new ConditionItemForDisplay() { DisplayValue = "Contain", ConConditionType = FilterConditionType.Contain });
                    list.Add(new ConditionItemForDisplay() { DisplayValue = "Except", ConConditionType = FilterConditionType.Except });
                    list.Add(new ConditionItemForDisplay() { DisplayValue = "Equal", ConConditionType = FilterConditionType.Equal });
                    list.Add(new ConditionItemForDisplay() { DisplayValue = "UnEqual", ConConditionType = FilterConditionType.UnEqual });
                    break;
            }

            return list;
        }

        public static ObservableCollection<object> GetAndOrSources()
        {
            return new ObservableCollection<object>()
            {
                new conAndOrItemBase(){DisplayValue =  "And", AndOrType = AndOr.And},
                new conAndOrItemBase(){DisplayValue =  "Or", AndOrType = AndOr.Or}
            };
        }

        public static object GetValueByRule(FilterRuleType rule, object _value = null)
        {
            object value = "";

            switch (rule)
            {
                case FilterRuleType.Unknown:
                    break;
                case FilterRuleType.TagName:
                    value = new FilterPolicyStringValue();
                    break;
                case FilterRuleType.TagType:
                    ObservableCollection<object> tagTypeItemSource = new ObservableCollection<object>() 
                    { 
                        TagType.all,
                        TagType.Unused,
                        TagType.Base,
                        TagType.Alias,
                        TagType.Produced,
                        TagType.Consumed
                    };
                    value = new FilterPolicyStringValue() { TypeItemsSource = tagTypeItemSource, RangeType = (_value != null ? _value.ToString() : tagTypeItemSource.First().ToString()) };
                    break;
                case FilterRuleType.UserDefined:
                    GetItemSource(ref value, xmlHelper.UserDefined, _value);
                    break;
                case FilterRuleType.Strings:
                    GetItemSource(ref value, xmlHelper.Strings, _value);
                    break;
                case FilterRuleType.AddOnDefined:
                    GetItemSource(ref value, xmlHelper.AddOnDefined, _value);
                    break;
                case FilterRuleType.ModuleDefined:
                    GetItemSource(ref value, xmlHelper.ModuleDefined, _value);
                    break;
                case FilterRuleType.PreDefined:
                    GetItemSource(ref value, xmlHelper.PreDefined, _value);
                    break;
                default:
                    break;
            }
            return value;
        }

        private static ObservableCollection<object> GetItemSource(ref object value, List<TagDataType> dataTypes, object _value = null)
        {
            ObservableCollection<object> itemSource = new ObservableCollection<object>();
            foreach (TagDataType item in dataTypes)
            {
                itemSource.Add(item.Name);
            }
            value = new FilterPolicyStringValue() { TypeItemsSource = itemSource, RangeType = _value != null ? _value.ToString() : (itemSource.Count > 0 ? itemSource.First().ToString() : string.Empty) };
            return itemSource;
        }
    }

    public class FilterPolicyStringValue : INotifyPropertyChanged
    {
        private string displayValue;
        public string DisplayValue
        {
            get
            {
                if (string.IsNullOrEmpty(this.displayValue))
                {
                    this.displayValue = "";
                }
                return this.displayValue;
            }
            set
            {
                this.displayValue = value;
                OnPropertyChanged("DisplayValue");
            }
        }

        private string rangeType;
        public string RangeType
        {
            get
            {
                if (this.rangeType == null)
                {
                    this.rangeType = "";
                }
                return this.rangeType;
            }
            set
            {
                this.rangeType = value;
                OnPropertyChanged("RangeType");
            }
        }

        private ObservableCollection<object> typeItemsSource;
        public ObservableCollection<object> TypeItemsSource
        {
            set
            {
                this.typeItemsSource = value;
                OnPropertyChanged("TypeItemsSource");
            }
            get
            {
                return this.typeItemsSource;
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string property)
        {
            if (property != null && PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }

    public enum FilterRuleType : int
    {
        Unknown = 0,

        TagName = 1,

        TagType = 2,

        UserDefined = 3,

        Strings = 4,

        AddOnDefined = 5,

        ModuleDefined = 6,

        PreDefined = 7
    }

    public enum FilterRuleCustomType : int
    {
        Number = 0,

        String = 1,

        Enum = 2
    }

    public enum FilterConditionType
    {
        None = 0,

        Equal = 1,
        UnEqual = 2,
        Contain = 3,
        Except = 4,

        IsExactly = 5,

        LargerThan = 6,
        LessThan = 7
    }

    public enum FilterPolicyValueType : int
    {
        None = 0,

        StringValue = 1,

        NumberValue = 2,

        EnumValue = 3,
    }
}
