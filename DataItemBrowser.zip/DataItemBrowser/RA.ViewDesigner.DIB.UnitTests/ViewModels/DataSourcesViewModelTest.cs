/*************************************************************************************
                                                                     
   ViewE VieweDataSourcesTreeViewModelTest Class                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using RockwellAutomation.UI.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel;
using System.Windows;
using RockwellAutomation.UI;
using RockwellAutomation.UI.Views;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.DIBQuery;
using System;

#endregion

namespace DataItemBrowserUT
{    
    /// <summary>
    ///This is a test class for VieweDataSourcesTreeViewModelTest and is intended
    ///to contain all VieweDataSourcesTreeViewModelTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DataSourcesViewModelTest
    {

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion
        
        /// <summary>
        ///A test for Visible
        ///</summary>
        [TestMethod()]
        public void VieweDataSourcesTreeViewModelTest_VisibleTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            VieweDataSourcesTreeViewModel target = new VieweDataSourcesTreeViewModel(dibVM); 
            Visibility expected = new Visibility(); 
            Visibility actual = Visibility.Visible;
            target.Visible = expected;
            actual = target.Visible.Value;
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void DataSourcesViewConstructorTest()
        {
            // This is merely to test the constructor to get code coverage
            DIBTreeView dsv = new DIBTreeView();
            Assert.IsNotNull(dsv);
        }

        [TestMethod()]
        public void DataItemBrowserConstructorTest()
        {
            // This is merely to test the constructor to get code coverage
            DataItemBrowser dib = new DataItemBrowser();
            Assert.IsNotNull(dib);
        }

        /// <summary>
        /// This test mimicks a drill-in execute on the data type browser on 
        /// initial DIB startup.  The validation points are meant to ensure
        /// that all "initial" state information is set properly.
        /// </summary>
        [TestMethod()]
        public void VieweDataSourcesTreeViewModel_dtbStartUpDrillInCommandTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            dibVM.BrowserType = DIResource.DI_COMMON_RESOURCETYPE_DATATYPE;

            VieweDataSourcesTreeViewModel target = new VieweDataSourcesTreeViewModel(dibVM);
            DataItemBase dataItem = PathElementUtility.Instance().CreateDataItemBase("Predefined");
            DIBTreeViewItem visualControllerParent = new DIBTreeViewItem(dataItem, "Predefined", VisualType.vtPredefined, null);
            target.DrillInCommand.Execute(visualControllerParent);
            Assert.AreEqual(visualControllerParent.VisualName, dibVM.Path.ActiveElement.DisplayName);

            // validate 'Path' stuff
            Assert.AreEqual(1, dibVM.Path.Items.Count);
            Assert.AreEqual(1, dibVM.Path.SelectedPath.Count);
            Assert.IsNull(dibVM.Path.HighlightedElement);
            Assert.IsNull(dibVM.Path.SavedHighlightedElement);
            Assert.AreEqual(typeof(DataTypePathElement), dibVM.Path.SelectedPath[0].GetType());
            Assert.AreEqual("Predefined", dibVM.Path.SelectedPath[0].DisplayName);
        }

        /// <summary>
        /// This test validates a drill in when a 'Path.SavedHighlightedElement' exists.
        /// </summary>
        [TestMethod()]
        public void VieweDataSourcesTreeViewModel_dtbDrillInCommandWithSavedHighlightedElementNotSelectedTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            dibVM.BrowserType = DIResource.DI_COMMON_RESOURCETYPE_DATATYPE;

            // create a 'SavedHighlightedElement' value we can use to test with.
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataTypePathElement("Level1", DataTypePECategory.Product));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataTypePathElement("Level2", DataTypePECategory.Product));
            dibVM.Path.Add(PathElementUtility.Instance().CreateDataTypePathElement("Level3", DataTypePECategory.Product));
            dibVM.Path.NavigateBack(); //Drill out so that path.Forward containts "Level3"
            IPathElement expected = PathElementUtility.Instance().CreateDataTypePathElement("ALARM", DataTypePECategory.Product);
            dibVM.Path.SavedHighlightedElement = expected;

            VieweDataSourcesTreeViewModel target = new VieweDataSourcesTreeViewModel(dibVM);
            DataItemBase dataItem = PathElementUtility.Instance().CreateDataItemBase("Level4");
            DIBTreeViewItem visualControllerParent = new DIBTreeViewItem(dataItem, "Level4", VisualType.vtPredefined, null);            
            target.DrillInCommand.Execute(visualControllerParent); //Drill into something that is NOT Level3
            Assert.AreEqual(visualControllerParent.VisualName, dibVM.Path.ActiveElement.DisplayName);

            // Even though a SavedHighlightedElement was saved, it should not be used as NameToSelect as the paths are different.
            Assert.AreEqual(String.Empty, dibVM.NavNameToSelect);
            Assert.IsNull(dibVM.Path.SavedHighlightedElement);

            // validate 'Path' stuff
            Assert.AreEqual(3, dibVM.Path.Items.Count);
            Assert.AreEqual(3, dibVM.Path.SelectedPath.Count);
            Assert.IsNull(dibVM.Path.HighlightedElement);
            Assert.AreEqual(typeof(DataTypePathElement), dibVM.Path.SelectedPath[2].GetType());
            Assert.AreEqual("Level4", dibVM.Path.SelectedPath[2].DisplayName);
        }

       

        /// <summary>
        ///A test for DataItemBrowserViewModel_DataViewChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDataSourcesTreeViewModelTest_DataItemBrowserViewModel_DataViewChangedTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            VieweDataSourcesTreeViewModel target = new VieweDataSourcesTreeViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
            Visibility expected = new Visibility();
            expected = Visibility.Visible;
            dibVM.DataView = new DIBDataViewTypeTreeView();

            object sender = null;
            PropertyChangedEventArgs e = new PropertyChangedEventArgs(String.Empty);
            targetPrivate.Invoke("DataItemBrowserViewModel_DataViewChanged", new object[]{sender, e});
            Assert.AreEqual(expected, target.Visible);
        }

        /// <summary>
        ///A test for NotifyPropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDataSourcesTreeViewModelTest_NotifyPropertyChangedTest()
        {
            MockDataItemBrowserViewModel dibVM = new MockDataItemBrowserViewModel();
            VieweDataSourcesTreeViewModel target = new VieweDataSourcesTreeViewModel(dibVM);
            PrivateObject targetPrivate = new PrivateObject(target);
            targetPrivate.Invoke("add_PropertyChanged", new PropertyChangedEventHandler(Test_PropertyChanged));
            string propertyName = "Visible";
            _propertyName = String.Empty;
            targetPrivate.Invoke("NotifyPropertyChanged", propertyName);
            Assert.AreEqual(propertyName, _propertyName);
        }
        private string _propertyName = string.Empty;
        void Test_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            _propertyName = e.PropertyName;

        }
    }
}
