﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Common;
using TagFilterControl.Controls;
using TagFilterControl.DIBClientManagers;
using TagFilterControl.DIBClientManagers.DataGridViewSimple;
using TagFilterControl.Object;
using TagFilterControl.Service;
using TagFilterControl.Tags;
using TagFilterControl.Utility;

namespace TagFilterControl.UserControls
{
    public class FilterExppanderViewModel : BaseViewModel
    {
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private Config config = Config.GetInstance();
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();

        private ObservableCollection<TagNode> sourceItems = new ObservableCollection<TagNode>();
        public ObservableCollection<TagNode> SourceItems
        {
            get { return this.sourceItems; }
            set
            {
                this.sourceItems = value;
                this.RaisePropertyChangedEvent(() => this.SourceItems);
            }
        }

        private ObservableCollection<string> comboxItems = new ObservableCollection<string>();
        public ObservableCollection<string> ComboxItems
        {
            get { return this.comboxItems; }
            set
            {
                this.comboxItems = value;
                this.RaisePropertyChangedEvent(() => this.ComboxItems);
            }
        }


        private object currentItem;
        public object CurrentItem
        {
            get
            {
                if (!string.IsNullOrEmpty(config.Usage))
                {
                    currentItem = config.Usage;
                }
                return currentItem;
            }
            set
            {
                currentItem = value;
                config.Usage = currentItem.ToString();
                if (filterDIBIn.DIBClientManager != null)
                {
                    (filterDIBIn.DIBClientManager as DataGridViewDemo).GridVM.ExecuteDrillInCommand((filterDIBIn.DIBClientManager as DataGridViewDemo).ParentDataItemBase);
                }
                this.RaisePropertyChangedEvent(() => this.CurrentItem);
            }
        }

        private bool showControllerTags = true;
        public bool ShowControllerTags
        {
            get
            {
                return showControllerTags;
            }
            set
            {
                showControllerTags = value;
                xmlHelper.ControllerSubChildrensKeyValuePair[xmlHelper.ControllerName][0].IsCheckedControlTags = showControllerTags;
                if (filterDIBIn.DIBClientManager != null)
                {
                    (filterDIBIn.DIBClientManager as DataGridViewDemo).GridVM.ExecuteDrillInCommand(null);
                }
                this.RaisePropertyChangedEvent(() => this.ShowControllerTags);
            }
        }

        private bool showProgTags = true;
        public bool ShowProgTags
        {
            get
            {
                return showProgTags;
            }
            set
            {
                showProgTags = value;
                xmlHelper.ControllerSubChildrensKeyValuePair[xmlHelper.ControllerName][1].IsCheckedProTags = showProgTags;
                if (filterDIBIn.DIBClientManager != null)
                {
                    (filterDIBIn.DIBClientManager as DataGridViewDemo).GridVM.ExecuteDrillInCommand(null);
                }
                this.RaisePropertyChangedEvent(() => this.ShowProgTags);
            }
        }

        private bool exIsExpanded;
        public bool ExIsExpanded
        {
            get { return exIsExpanded; }
            set
            {
                exIsExpanded = value;
                this.RaisePropertyChangedEvent(() => this.ExIsExpanded);
            }
        }

        private CustomCommand<object> itemChangedCommand;
        public CustomCommand<object> ItemChangedCommand
        {
            get
            {
                return this.itemChangedCommand ?? (this.itemChangedCommand = new CustomCommand<object>(e =>
                {
                    TagNode selectNode = e as TagNode;
                    if (!selectNode.IsLoaded)
                    {
                        ServiceInvoker<ITagService>
                            .Invoke(s => s.LoadSubItems(selectNode))
                            .Callback(result =>
                            {
                                if (result != null)
                                {
                                    if (!result.HasError)
                                    {
                                        if (result.Children != null && result.Children.Count > 0)
                                        {
                                            foreach (var child in result.Children)
                                            {
                                                selectNode.Children.Add(child);
                                                child.ParentNode = selectNode;
                                            }
                                        }
                                    }
                                }
                            })
                            .Finally(() =>
                                {
                                    selectNode.IsLoaded = true;
                                    selectNode.IsSelected = true;
                                    selectNode.IsExpanded = true;
                                })
                                .Execute();
                    }
                    else
                    {
                        selectNode.IsExpanded = !selectNode.IsExpanded;
                    }
                }));
            }
        }

        public FilterExppanderViewModel()
        {
            LoadData();
        }

        private void LoadData()
        {
            this.ComboxItems.Add(TagType.all.ToString());
            this.ComboxItems.Add(TagType.Unused.ToString());
            this.ComboxItems.Add(TagType.Base.ToString());
            this.ComboxItems.Add(TagType.Produced.ToString());
            this.ComboxItems.Add(TagType.Consumed.ToString());
            this.ComboxItems.Add(TagType.Alias.ToString());
            this.CurrentItem = TagType.all.ToString();

            LoadRootNodes();
        }

        private void LoadRootNodes()
        {
            TagNode userDefined = new TagNode() { Name = "User-Defined", IsChecked = false, Type = Types.None, HasChild = true };
            TagNode strings = new TagNode() { Name = "Strings", IsChecked = false, Type = Types.None, HasChild = true };
            TagNode addOnDefined = new TagNode() { Name = "Add-On-Defined", IsChecked = false, Type = Types.None, HasChild = true };
            TagNode preDefined = new TagNode() { Name = "PreDefined", IsChecked = false, Type = Types.None, HasChild = true };
            TagNode moduleDefined = new TagNode() { Name = "Module-Defined", IsChecked = false, Type = Types.None, HasChild = true };
            TagNode usage = new TagNode() { Name = "Usage", IsChecked = false, Type = Types.None, HasChild = true };
            this.SourceItems.Add(userDefined);
            this.SourceItems.Add(strings);
            this.SourceItems.Add(addOnDefined);
            this.SourceItems.Add(preDefined);
            this.SourceItems.Add(moduleDefined);
            this.SourceItems.Add(usage);
            this.SourceItems.Add(new TagNode() { Name = "ACM", IsChecked = false, Type = Types.None, HasChild = true });
            this.filterDIBIn.Trigger += () =>
            {
                foreach (TagNode item in config.IsCheckedTags.Values)
                {
                    switch (item.ParentName)
                    {
                        case "User-Defined":
                            userDefined.Expand = true;
                            break;
                        case "Strings":
                            strings.Expand = true;
                            break;
                        case "Add-On-Defined":
                            addOnDefined.Expand = true;
                            break;
                        case "PreDefined":
                            preDefined.Expand = true;
                            break;
                        case "Module-Defined":
                            moduleDefined.Expand = true;
                            break;
                        case "Usage":
                            usage.Expand = true;
                            break;
                        default:
                            break;
                    }
                }

                if ( userDefined.Expand)
                {
                    this.ItemChangedCommand.Execute(userDefined);
                }
                if (strings.Expand)
                {
                    this.ItemChangedCommand.Execute(strings);
                }
                if (addOnDefined.Expand)
                {
                    this.ItemChangedCommand.Execute(addOnDefined);
                }
                if (preDefined.Expand)
                {
                    this.ItemChangedCommand.Execute(preDefined);
                }
                if (moduleDefined.Expand)
                {
                    this.ItemChangedCommand.Execute(moduleDefined);
                }
                if (usage.Expand)
                {
                    this.ItemChangedCommand.Execute(usage);
                }
            };
        }
    }
}
