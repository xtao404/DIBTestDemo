﻿using System.Configuration;

namespace RockwellAutomation.UI.UserConfiguration
{
    // The "WindowSection" contains the "Size" element
    public class WindowSection : ConfigurationSection
    {
        // Create a configuration section.
        public WindowSection()
        { }

        // Set or get the name of the ColumnsElement. 
        [ConfigurationProperty("Size")]
        public WindowElement Size
        {
            get
            {
                return ((WindowElement)this["Size"]);
            }
            set
            {
                this["Size"] = value;
            }
        }
    }
}
