﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.FilterObject;
using TagFilterControl.Utility;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public class FilterPolicyModel : FilterPolicyCommonModel
    {
        private XMLHelper xmlHelper = XMLHelper.GetInstance();
        private ObservableCollection<RuleItemForDisplay> ruleItemsSource
        {
            get
            {
                return AddRuleItemSource();
            }
        }

        private ObservableCollection<RuleItemForDisplay> AddRuleItemSource()
        {
            ObservableCollection<RuleItemForDisplay> ruleItemsSource = new ObservableCollection<RuleItemForDisplay>();
            ruleItemsSource.Add(new RuleItemForDisplay()
            {
                DisplayValue = "TagName",
                conRuleType = FilterRuleCustomType.String,
                ColumnName = string.Empty,
                FilterRuleType = FilterRuleType.TagName,
                ID = FilterPolicyRuleTypeId.TagName
            });

            if (flag)
            {
                ruleItemsSource.Add(new RuleItemForDisplay()
                {
                    DisplayValue = "TagType",
                    conRuleType = FilterRuleCustomType.String,
                    ColumnName = string.Empty,
                    FilterRuleType = FilterRuleType.TagType,
                    ID = FilterPolicyRuleTypeId.TagType
                });
            }

            if (xmlHelper.UserDefined.Count > 0)
            {
                ruleItemsSource.Add(new RuleItemForDisplay()
                {
                    DisplayValue = "User-Defined",
                    conRuleType = FilterRuleCustomType.String,
                    ColumnName = string.Empty,
                    FilterRuleType = FilterRuleType.UserDefined,
                    ID = FilterPolicyRuleTypeId.UserDefined
                });
            }

            if (xmlHelper.Strings.Count > 0)
            {
                ruleItemsSource.Add(new RuleItemForDisplay()
                {
                    DisplayValue = "Strings",
                    conRuleType = FilterRuleCustomType.String,
                    ColumnName = string.Empty,
                    FilterRuleType = FilterRuleType.Strings,
                    ID = FilterPolicyRuleTypeId.Strings
                });
            }

            if (xmlHelper.AddOnDefined.Count > 0)
            {
                ruleItemsSource.Add(new RuleItemForDisplay()
                {
                    DisplayValue = "Add-On-Defined",
                    conRuleType = FilterRuleCustomType.String,
                    ColumnName = string.Empty,
                    FilterRuleType = FilterRuleType.AddOnDefined,
                    ID = FilterPolicyRuleTypeId.AddOnDefined
                });
            }

            if (xmlHelper.ModuleDefined.Count > 0)
            {
                ruleItemsSource.Add(new RuleItemForDisplay()
                {
                    DisplayValue = "Module-Defined",
                    conRuleType = FilterRuleCustomType.String,
                    ColumnName = string.Empty,
                    FilterRuleType = FilterRuleType.ModuleDefined,
                    ID = FilterPolicyRuleTypeId.ModuleDefined
                });
            }

            if (xmlHelper.PreDefined.Count > 0)
            {
                ruleItemsSource.Add(new RuleItemForDisplay()
                {
                    DisplayValue = "PreDefined",
                    conRuleType = FilterRuleCustomType.String,
                    ColumnName = string.Empty,
                    FilterRuleType = FilterRuleType.PreDefined,
                    ID = FilterPolicyRuleTypeId.PreDefined
                });
            }

            return ruleItemsSource;
        }

        private bool flag = true;
        public override ConditionFilterBaseModel GetNewFilterData(ObservableCollection<ConditionFilterBaseModel> filterItemSource)
        {
            ConditionFilterBaseModel mFilterBaseModel = new ConditionFilterBaseModel();
            ConditionFilterBase mConditionFilterBase = new ConditionFilterBase();

            mConditionFilterBase.RuleItemsSource = new ObservableCollection<object>(ruleItemsSource.Cast<object>());
            ConditionFilterBaseModel tagTypeItem = filterItemSource.ToList().Find(rul => rul.ConditionFilterBase.Rule.ToString().Equals("TagType"));
            if (tagTypeItem != null)
            {
                flag = false;
                mConditionFilterBase.RuleItemsSource = new ObservableCollection<object>(ruleItemsSource.Cast<object>());
            }
            mConditionFilterBase.Rule = mConditionFilterBase.RuleItemsSource.First();

            mConditionFilterBase.ConditionItemsSource = new ObservableCollection<object>(FilterPolicyCommonUtil.GetConditionItemsByRule((mConditionFilterBase.Rule as RuleItemForDisplay)).Cast<object>());
            mConditionFilterBase.Condition = mConditionFilterBase.ConditionItemsSource.First();

            mConditionFilterBase.Value = FilterPolicyCommonUtil.GetValueByRule((mConditionFilterBase.Rule as RuleItemForDisplay).FilterRuleType);
            mConditionFilterBase.CustomisedRule = "";

            mFilterBaseModel.ConditionFilterBase = mConditionFilterBase;
            return mFilterBaseModel;
        }

        public override object GetValue(FilterRuleType rule)
        {
            return FilterPolicyCommonUtil.GetValueByRule(rule);
        }

        public override void ConvertConditionFilterToProfile(ObservableCollection<ConditionFilterBaseModel> returnData, ref FilterProfile dto)
        {
            FilterOptionsSubProfileContent content = new FilterOptionsSubProfileContent();
            List<FilterItemBase> filterItems = new List<FilterItemBase>();
            StringBuilder stringContent = new StringBuilder();

            foreach (ConditionFilterBaseModel filterItem in returnData)
            {
                if (filterItem != null &&
                    filterItem.ConditionFilterBase != null)
                {
                    FilterItemBase item = GetFilterItemBase(filterItem);
                    filterItems.Add(item);

                    string ruleType = item.RuleSelectedItem.RuleType.ToString();
                    string condition = item.ConditionSelectedItem.ConditionType.ToString();
                    string val = item.Value.Value.ToString();
                    string andOr = item.AndOrValue.ToString().Equals("None") ? "" : item.AndOrValue.ToString();

                    string _filterItem = string.Format("{0} {1} \"{2}\" {3} ", ruleType, condition, val, andOr);
                    stringContent.Append(_filterItem);

                }
            }
            content.FilterOptions = FilterCommonMethod.GetFilterReturnBase(filterItems);
            dto.Content = stringContent.ToString().Trim();
            dto.FilterContent = content;
        }

        public override ObservableCollection<ConditionFilterBaseModel> ConvertProfileContentToFilterFoundation(FilterProfile dto)
        {
            ObservableCollection<ConditionFilterBaseModel> items = new ObservableCollection<ConditionFilterBaseModel>();

            FilterOptionsSubProfileContent content = dto.FilterContent as FilterOptionsSubProfileContent;
            if (content != null && content.FilterOptions != null)
            {
                return GetConditionFilterModels(content.FilterOptions);
            }

            return items;
        }

        ObservableCollection<ConditionFilterBaseModel> GetConditionFilterModels(List<FilterReturnBase> filterOptions)
        {
            ObservableCollection<ConditionFilterBaseModel> models = new ObservableCollection<ConditionFilterBaseModel>();

            int start = 0;
            int count = 1;
            var startIndex = 0;
            var itemsCount = 0;
            filterOptions.ForEach(item =>
            {
                start = count;
                ConditionFilterBaseModel model = null;
                itemsCount = item.Conditions.Count;
                item.Conditions.ForEach(cc =>
                {
                    model = new ConditionFilterBaseModel()
                    {
                        ConditionFilterBase = GetConditionFilter(cc),
                        Order = cc.OrderSelectedItem,
                    };
                    models.Add(model);
                    count++;
                });

                ObservableCollection<int> orders = new ObservableCollection<int>();
                for (int i = start; i < count; i++)
                {
                    orders.Add(i);
                }
                for (var i = startIndex; i < itemsCount + startIndex; i++)
                {
                    models[i].OrderItemsSource = orders;
                }
                startIndex += itemsCount;
            });

            return models;
        }

        ConditionFilterBase GetConditionFilter(FilterItemBase cc)
        {
            ConditionFilterBase conditionFilter = new ConditionFilterBase();
            conditionFilter.AndOrValueItemsSource = FilterPolicyCommonUtil.GetAndOrSources();
            conditionFilter.AndOrValue = conditionFilter.AndOrValueItemsSource.FirstOrDefault(i => (i as IAndOrItemBase).AndOrType == MappingFromLDAndOrToAndOr(cc.AndOrValue));
            if (conditionFilter.AndOrValue == null)
            {
                conditionFilter.AndOrValue = new conAndOrItemBase() { AndOrType = AndOr.And };
            }
          
            conditionFilter.RuleItemsSource = new ObservableCollection<object>(GetRuleItemsSource().Cast<object>());
            conditionFilter.Rule = conditionFilter.RuleItemsSource.First(aa => cc.RuleSelectedItem.RuleType == FilterTypeSwitchUtil.GetRlueType((aa as RuleItemForDisplay).FilterRuleType));

            conditionFilter.ConditionItemsSource = new ObservableCollection<object>(FilterPolicyCommonUtil.GetConditionItemsByRule((conditionFilter.Rule as RuleItemForDisplay)).Cast<object>());
            conditionFilter.Condition = conditionFilter.ConditionItemsSource.FirstOrDefault(aa => FilterTypeSwitchUtil.GetMIGConditionType((aa as ConditionItemForDisplay).ConConditionType) == cc.ConditionSelectedItem.ConditionType);

            conditionFilter.Value = new ValueItemForDisplay(FilterTypeSwitchUtil.ConvertToValueItem(cc.Value));
            conditionFilter.CustomisedRule = cc.RuleSelectedItem.ColumnName;

            return conditionFilter;
        }

        ObservableCollection<RuleItemForDisplay> GetRuleItemsSource()
        {
            return ruleItemsSource;
        }
        
        FilterItemBase GetFilterItemBase(ConditionFilterBaseModel source)
        {
            FilterItemBase item = new FilterItemBase();

            item.AndOrValue = FilterTypeSwitchUtil.ConvertToMigrationAndOr(source.ConditionFilterBase.AndOrValue);


            item.RuleItemsSource = FilterTypeSwitchUtil.ConvertToRuleItems(ruleItemsSource);

            item.RuleSelectedItem = item.RuleItemsSource.FirstOrDefault(cc => cc.RuleType == FilterTypeSwitchUtil.GetRlueType((source.ConditionFilterBase.Rule as RuleItemForDisplay).FilterRuleType));
            item.RuleSelectedItem.ColumnName = source.ConditionFilterBase.CustomisedRule;

            item.Value = FilterTypeSwitchUtil.ConvertToValueItem(source.ConditionFilterBase);
            item.OrderSelectedItem = source.Order;

            ObservableCollection<ConditionItemForDisplay> conditions = FilterPolicyCommonUtil.GetConditionItemsByRule((source.ConditionFilterBase.Rule as RuleItemForDisplay));
            item.ConditionSelectedItem = FilterTypeSwitchUtil.ConvertToConditionItem(conditions.FirstOrDefault(cc => cc.ConConditionType == (source.ConditionFilterBase.Condition as ConditionItemForDisplay).ConConditionType));

            return item;
        }
    }
}
