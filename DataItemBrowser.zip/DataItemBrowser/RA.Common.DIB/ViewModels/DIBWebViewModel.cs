/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using System;
using System.Linq;
using System.Windows;
using System.ComponentModel;

using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.Common;


#endregion

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// View model supporting the <c>DIBWebView</c>
    /// </summary>
    public class DIBWebViewModel : DIBViewModel
    {
        #region Properties/Variables

        private DIBListViewItem _selectedItem;

        /// <summary>
        /// Selected DataItemBase item property
        /// </summary>
        public DIBListViewItem SelectedItem
        {
            get { return _selectedItem; }
            set
            {
                if (_selectedItem != value)
                {
                    _selectedItem = value;
                    NotifyPropertyChanged("SelectedItem");
                }
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">reference to the DataItemBrowser view model</param>
        public DIBWebViewModel(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
            _dibViewModel.WebViewOCChanged += new PropertyChangedEventHandler(DataItemBrowserViewModel_WebViewOCChanged);
        }



        #endregion

        #region Event Handlers

        /// <summary>
        /// Notification that the view has changed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        override protected void DataItemBrowserViewModel_DataViewChanged(object sender, EventArgs e)
        {
            if (_dibViewModel.DataView.IsWebView())
            {
                Visible = Visibility.Visible;
            }
            else
            {
                Visible = Visibility.Collapsed;
                // We want to release resources held on to by the web browser here
            }
        }

        /// <summary>
        /// handler for adding or removing the search crumb
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        override protected void DataItemBrowserViewModel_SearchBreadCrumbChanged(object sender, PropertyChangedEventArgs e)
        {
            // Do nothing. We dont want to inherit superclass execution
        }

        /// <summary>
        /// Handler for data source changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">DataGrid Property Changed Event</param>        
        void DataItemBrowserViewModel_WebViewOCChanged(object sender, PropertyChangedEventArgs e)
        {
            this._selectedItem = null;
            if (this._dibViewModel.DataItems.Count() == 0)
            {
                LogWrapper.DibGeneralLog.Error("Attempted to set source in Web View with no DataItemBase instances available. Ignoring binding request");
                return;
            }

            if (this._dibViewModel.DataItems.Count() > 1)
                LogWrapper.DibGeneralLog.Error("Attempting to set source in Web View with multiple DataItemBase instances. Using first and ignoring the rest");

            DataItemBase newDataItem = this._dibViewModel.DataItems[0];
            DIBListViewItem newViewItem = CreateDIBViewDataItemFrom(newDataItem);
            this.SelectedItem = newViewItem;        
        }

        #endregion  //event handlers
      
        #region Item Binding/Unbinding

        override public bool isActive()
        {
            return _dibViewModel.DataView.IsWebView();
        }


        protected virtual DIBListViewItem CreateDIBViewDataItemFrom(DataItemBase di)
        {
            UpdatePropertiesOnDataItemBaseIfNeeded(di);
            DIBListViewItem data = new DIBListViewItem(di);
            data.IsSelected = false;
            return data;
        }

        private static void UpdatePropertiesOnDataItemBaseIfNeeded(DataItemBase item)
        {
            //if DataItemBase does not already have a UUID on it, set it now
            //We force all instances of DataItemBase to have a UUID as its ID. The client itself can use its won ID but needs to have different property key
            if (String.IsNullOrWhiteSpace(item.CommonID)) 
                item.CommonID = ResourceBase.generateRandomUUIDString();

            if (Convert.ToBoolean(item.GUISupportsDrillIn))
                item.IsStructured = true;
            else
                item.IsStructured = false;
        }

        #endregion

        #region Drill in/Drill out

        /// <summary>
        /// Creates the path which specifies the Controller to drill into and then navigates into it.
        /// </summary>
        public override SimpleCommand CreateDrillInCommand()
        {
            return new SimpleCommand()
            {
                ExecuteDelegate = x =>
                {
                    DataItemBase item = x as DataItemBase;
                    if (item == null) return;

                    if ((_dibViewModel.Path.Forward != null) &&
                        (item.CommonName == _dibViewModel.Path.Forward.DisplayName))
                        _dibViewModel.Path.SetActive(_dibViewModel.Path.Forward);
                    else
                    {
                        IPathElement newPE = PathElementFactory.Instance().CreatePathElement(item);
                        _dibViewModel.Path.Add(newPE);

                    }
                    //handle highlighted item processing
                    this.Path.HighlightedElement = Path.ActiveElement;
                    _dibViewModel.Navigate(item);
                }
            };
        }

        /// <summary>
        /// Do we want to allow this view to have drill in functionality?
        /// If true, we still look at individual DataItemBase instances to see whether they allow drillins
        /// TO DO: Add this ability to turn off drillins in views for ListView and TreeView as well
        /// </summary>
        /// <returns>Wether we should allow drillins for this view</returns>
        public virtual bool AllowItemDrillIns
        {
            get 
            {
                // Let sublclasses override. Here we assume all grid views want to allow drill ins
                return true; 
            }

        }

        public virtual bool AllowDrillInTo(System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            return true;
        }

        public virtual void Navigated(System.Windows.Navigation.NavigationEventArgs e)
        {
            //if we are already navigated to this URI, no need to add items to path)
            if (this.SelectedItem.DataItem.CommonLocation == e.Uri.AbsoluteUri)
            {
                //handle highlighted item processing
                this.Path.HighlightedElement = Path.ActiveElement;
                return;
            }

            //Need to create a new DataItemBase instance to represent the URI we are drilling into
            DataItemBase newDIB = this.CreateDataItemBaseFromURI(e.Uri);
            IPathElement newPE = PathElementFactory.Instance().CreatePathElement(newDIB);
            this._dibViewModel.Path.Add(newPE);
            //handle highlighted item processing
            this.Path.HighlightedElement = Path.ActiveElement;

            DIBListViewItem newViewItem = CreateDIBViewDataItemFrom(newDIB);
            this._selectedItem = newViewItem; //set the selected item but do not cause property update as that will trigger a navigation by XAML code behind  

        }

        public virtual DataItemBase CreateDataItemBaseFromURI(Uri uri)
        {
            DataItemBase newDIB = new DataItemBase();
            newDIB.CommonName = this.BreadCrumbDisplayStringFor(uri);
            newDIB.CommonDataType = "URI";
            newDIB.CommonLocation = uri.AbsoluteUri;
            newDIB.CommonRefTargetId = String.Empty;
            newDIB.GUITreeViewParentID = uri.AbsoluteUri;
            newDIB.GUISupportsSelection = "True";
            newDIB.GUISupportsDrillIn = "True";
            
            UpdatePropertiesOnDataItemBaseIfNeeded(newDIB);

            return newDIB;
        }

        public virtual string BreadCrumbDisplayStringFor(Uri uri)
        {       
            // By default, use the second last path item. 
            // Ex. if the uri is 
            //          http:\\www.something.com\first\second\default.html
            //     then use "second" as the display string in the breadcrumbs 
            string[] drillInSubStrings = uri.AbsoluteUri.Split('/');
            int index = drillInSubStrings.Length - 2;
            if (index < 1) index = 0;
            return drillInSubStrings[index];
        }
        
        
        public virtual void DoubleClickSelection()
        {
            // What we shouldbe doing is creating a new dataitembase representing what was double clicked, but instead we are 'selecting' the active dataitembase
            // that represents the URL we are currently viewing
            base.DoubleClickSelection(this.SelectedItem.DataItem);
        }

        #endregion

        #region Startup - Shutdown

        /// <summary>
        /// Remove event handlers and save column configuration
        /// </summary>
        override public void Cleanup()
        {
            // Cleanup Event Subscriptions
            _dibViewModel.WebViewOCChanged -= new PropertyChangedEventHandler(DataItemBrowserViewModel_WebViewOCChanged);
            base.Cleanup();
        }

        #endregion
    }
}
