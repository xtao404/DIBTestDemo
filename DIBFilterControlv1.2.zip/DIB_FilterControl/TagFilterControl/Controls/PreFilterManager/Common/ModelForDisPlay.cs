﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Controls.PreFilterManager.Common;

namespace TagFilterControl.Controls.PreFilterManager.Common
{
    public class RuleItemForDisplay : IRuleItemBase, INotifyPropertyChanged
    {
        public object conRuleType
        {
            get;
            set;
        }

        private string _displayValue;
        public string DisplayValue
        {
            get { return _displayValue; }
            set
            {
                _displayValue = value;
                OnPropertyChanged("DisplayValue");
            }
        }

        private string _id;
        public string ID
        {
            get { return _id; }
            set
            {
                _id = value;
                OnPropertyChanged("ID");
            }
        }

        private string _columnName;
        public string ColumnName
        {
            get { return _columnName; }
            set
            {
                _columnName = value;
                OnPropertyChanged("ColumnName");
            }
        }

        private FilterRuleType _filterRuleType;
        public FilterRuleType FilterRuleType
        {
            get { return this._filterRuleType; }
            set
            {
                _filterRuleType = value;
                OnPropertyChanged("RuleType");
            }
        }

        public override string ToString()
        {
            if (string.IsNullOrEmpty(DisplayValue))
            {
                return "";
            }
            return this.DisplayValue;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string property)
        {
            if (property != null && PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }

    public class ConditionItemForDisplay : INotifyPropertyChanged
    {
        private string _displayValue;
        public string DisplayValue
        {
            get { return _displayValue; }
            set
            {
                this._displayValue = value;
                OnPropertyChanged("DisplayValue");
            }
        }

        private FilterConditionType _conConditionType;
        public FilterConditionType ConConditionType
        {
            get { return _conConditionType; }
            set
            {
                this._conConditionType = value;
                OnPropertyChanged("ConConditionType");
            }
        }

        private string _columnName;
        public string ColumnName
        {
            get { return _columnName; }
            set { _columnName = value; }
        }

        private string _id;
        public string ID
        {
            get { return _id; }
            set { _id = value; }
        }

        public override string ToString()
        {
            if (string.IsNullOrEmpty(DisplayValue))
            {
                return "";
            }
            return this.DisplayValue;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string property)
        {
            if (property != null && PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }

    public class ValueItemForDisplay : INotifyPropertyChanged
    {
        public ValueItemForDisplay(object item)
        {
            if (item is FilterPolicyStringValue)
            {
                var value = item as FilterPolicyStringValue;
                this.DisplayValue = value.DisplayValue;
                this.ValueType = FilterPolicyValueType.StringValue;
                this.TypeItemsSource = value.TypeItemsSource;
                this.RangeType = value.RangeType;
            }
            this.HasError = false;
            this.ErrorMsg = string.Empty;
        }

        public string InfoString
        {
            get
            {
                string str = string.Empty;

                if (!this.hasError)
                {
                    if (!string.IsNullOrEmpty(this.displayValue))
                    {
                        str += this.displayValue;
                        this.hasDisplayValue = true;
                    }
                    if (this.rangeType != null)
                    {
                        str += Convert.ToString(rangeType);
                    }
                    this.foregroundColor = ColorState.Normal;
                }
                else
                {
                    if (!string.IsNullOrEmpty(this.errorMsg))
                    {
                        str += this.errorMsg;
                        this.foregroundColor = ColorState.Error;
                    }
                }

                return str;
            }
        }

        private FilterPolicyValueType valueType;
        public FilterPolicyValueType ValueType
        {
            get { return this.valueType; }
            set
            {
                this.valueType = value;
                OnPropertyChanged("ValueType");
            }
        }

        private object rangeType;
        public object RangeType
        {
            get { return this.rangeType; }
            set
            {
                this.rangeType = value;
                OnPropertyChanged("RangeType");
                OnPropertyChanged("InfoString");
                OnPropertyChanged("ForegroundColor");
            }
        }

        private bool hasError;
        public bool HasError
        {
            get { return this.hasError; }
            set
            {
                this.hasError = value;
                OnPropertyChanged("HasError");
            }
        }

        private string errorMsg;
        public string ErrorMsg
        {
            get { return this.errorMsg; }
            set
            {
                this.errorMsg = value;
                OnPropertyChanged("ErrorMsg");
                OnPropertyChanged("InfoString");
                OnPropertyChanged("ForegroundColor");
            }
        }

        private bool firstTimeBindingDisplayValue = true;

        private string displayValue;
        public string DisplayValue
        {
            get
            {
                if (firstTimeBindingDisplayValue)
                {
                    if (!string.IsNullOrEmpty(this.displayValue))
                    {
                        this.hasDisplayValue = true;
                    }
                    else
                    {
                        //this.displayValue = _Input_a_Value_;
                    }
                    firstTimeBindingDisplayValue = false;
                }
                else if (!this.hasDisplayValue)
                {
                    this.displayValue = string.Empty;
                }

                return this.displayValue;
            }
            set
            {
                this.displayValue = value;
                OnPropertyChanged("DisplayValue");
                OnPropertyChanged("ForegroundColor");
                OnPropertyChanged("InfoString");
            }
        }

        private ColorState foregroundColor;
        public ColorState ForegroundColor
        {
            get
            {
                return this.foregroundColor;
            }
        }

        private bool hasDisplayValue = false;
        public bool HasDisplayValue
        {
            get { return this.hasDisplayValue; }
            set
            {
                this.hasDisplayValue = value;
                OnPropertyChanged("HasDisplayValue");
            }
        }

        private ObservableCollection<object> typeItemsSource;
        public ObservableCollection<object> TypeItemsSource
        {
            get { return this.typeItemsSource; }
            set
            {
                this.typeItemsSource = value;
                OnPropertyChanged("TypeItemsSource");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string property)
        {
            if (property != null && PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }

    public enum ColorState : int
    {
        Normal = 0,
        WaterMark = 1,
        Error = 2
    }
}
