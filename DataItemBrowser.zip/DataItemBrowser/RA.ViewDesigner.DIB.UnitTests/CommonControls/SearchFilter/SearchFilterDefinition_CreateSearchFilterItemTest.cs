using System.Linq;
using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
	/// <summary>
    ///This is a test class for how SearchFilterDefinition creates SearchFilterItems
	///</summary>
	[TestClass()]
    public class SearchFilterDefinition_CreateSearchFilterItemTest
	{
		private TestContext testContextInstance;

		/// <summary>
		///Gets or sets the test context which provides
		///information about and functionality for the current test run.
		///</summary>
		public TestContext TestContext
		{
			get
			{
				return testContextInstance;
			}
			set
			{
				testContextInstance = value;
			}
		}

		#region Additional test attributes

        private SearchFilterParser _parser = null;
		//Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            _parser = new SearchFilterParser();
        }
		
		#endregion

		/// <summary>
		/// filter types used by parse method
		/// </summary>
		private ObservableCollection<FilterType> _filterTypes = null;

		/// <summary>
		/// private method to generate the valid filter types
		/// </summary>
		private void GenerateFilterTypes()
		{
			_filterTypes = new ObservableCollection<FilterType>();
            _filterTypes.Add(new FilterType(DIBConstants.Common.Name, true, false));
            _filterTypes.Add(new FilterType(DIBConstants.Common.DataType, false, false));
            _filterTypes.Add(new FilterType(DIBConstants.Common.Description, true, false));
		}

        /// <summary>
        /// Helper test method
        ///</summary>
        public void AssertSearchFilterItem(SearchFilterItem searchFilterItem, string identifier, string value, bool isExactMatch, bool isIdentifierColumnConfigKey, SearchFilterDefinition.StatementLogic logic, int nestedItemCount)
        {
            Assert.IsTrue(searchFilterItem.GetIdentifier == identifier);
            Assert.IsTrue(searchFilterItem.GetValue == value);
            Assert.IsTrue(searchFilterItem.IsExactMatch == isExactMatch);
            Assert.IsTrue(searchFilterItem.IsIdentifierColumnConfigKey == isIdentifierColumnConfigKey);
            Assert.IsTrue(searchFilterItem.GetLogicOperator == logic);
            Assert.IsTrue(searchFilterItem.GetNestedItems.Count == nestedItemCount);
        }
		#region Item Tests


        /// <summary>
        ///A test for Parse valid exact match string filtertype-default
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ParseDetails_Valid_DefaultSearch()
        {
           	string searchFilter = "\"TestSearchItemName\""; // This is default search. Since filter types are set up with Name and Description
                                                            // being 'searchable', then both name and desciption will appear in generated SearchFilterItem's
            GenerateFilterTypes();
			bool actual = this._parser.Parse(searchFilter, _filterTypes, true);
			Assert.IsTrue(actual);
            Assert.IsTrue(this._parser.FilterDefinition.GetFilterConfig() != null);
            Assert.IsTrue(this._parser.FilterDefinition.GetFilterConfig().GetFilterItems.Count == 1);
            SearchFilterItem parentItem = this._parser.FilterDefinition.GetFilterConfig().GetFilterItems[0];
            Assert.IsTrue(parentItem.GetIdentifier == null);
            Assert.IsTrue(parentItem.GetValue == null);
            Assert.IsTrue(parentItem.GetLogicOperator == SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(parentItem.GetNestedItems.Count == 2);

            this.AssertSearchFilterItem(parentItem.GetNestedItems[0], "DisplayName", "TestSearchItemName", true, false, SearchFilterDefinition.StatementLogic.AND, 0);
            this.AssertSearchFilterItem(parentItem.GetNestedItems[1], "Description", "TestSearchItemName", false, false, SearchFilterDefinition.StatementLogic.OR, 0); //We never do isExactMatch true on description filter type. Business rule
        }

        /// <summary>
        ///A test for Parse valid string with valid filter operator as value
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ParseDetails_Valid_Use_FilterOperator_As_Value()
        {       
            GenerateFilterTypes();
            SearchFilterItem dintItem, intItem;
            SearchFilterConfig searchFilterConfig; 

            Assert.IsTrue(_parser.Parse("dt:(DINT OR INT)", _filterTypes, false));
            searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
            Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 1);
            Assert.IsTrue(searchFilterConfig.GetFilterItems[0].GetNestedItems.Count == 2);
            dintItem = searchFilterConfig.GetFilterItems[0].GetNestedItems[0];
            this.AssertSearchFilterItem(dintItem, SearchFilterDefinition.DataTypeIdentifier, "DINT", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
            intItem = searchFilterConfig.GetFilterItems[0].GetNestedItems[1];
            this.AssertSearchFilterItem(intItem, SearchFilterDefinition.DataTypeIdentifier, "INT", false, false, SearchFilterDefinition.StatementLogic.OR, 0);


            string[] searchFilters = {  
                                    "dt:DINT OR dt:INT",
                                    "dt:(DINT) OR dt:(INT)"
                                      };
            foreach (bool actual in searchFilters.Select(searchFilter => _parser.Parse(searchFilter, _filterTypes, false)))
            {
                Assert.IsTrue(actual);
                searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
                Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 2);
                dintItem = searchFilterConfig.GetFilterItems[0];
                Assert.IsTrue(!dintItem.GetNestedItems.Any());
                this.AssertSearchFilterItem(dintItem, SearchFilterDefinition.DataTypeIdentifier, "DINT", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                intItem = searchFilterConfig.GetFilterItems[1];
                Assert.IsTrue(!intItem.GetNestedItems.Any());
                this.AssertSearchFilterItem(intItem, SearchFilterDefinition.DataTypeIdentifier, "INT", false, false, SearchFilterDefinition.StatementLogic.OR, 0);
            }

            Assert.IsTrue(_parser.Parse("dt:(\"DINT\" OR \"INT\")", _filterTypes, false));
            searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
            Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 1);
            Assert.IsTrue(searchFilterConfig.GetFilterItems[0].GetNestedItems.Count == 2);
            dintItem = searchFilterConfig.GetFilterItems[0].GetNestedItems[0];
            this.AssertSearchFilterItem(dintItem, DIBConstants.Common.DataType, "DINT", true, true, SearchFilterDefinition.StatementLogic.AND, 0);
            intItem = searchFilterConfig.GetFilterItems[0].GetNestedItems[1];
            this.AssertSearchFilterItem(intItem, DIBConstants.Common.DataType, "INT", true, true, SearchFilterDefinition.StatementLogic.OR, 0);

            Assert.IsTrue(_parser.Parse("dt:\"DINT\" OR dt:\"INT\"", _filterTypes, false));
            searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
            Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 2);
            dintItem = searchFilterConfig.GetFilterItems[0];
            this.AssertSearchFilterItem(dintItem, DIBConstants.Common.DataType, "DINT", true, true, SearchFilterDefinition.StatementLogic.AND, 0);
            intItem = searchFilterConfig.GetFilterItems[1];
            this.AssertSearchFilterItem(intItem, DIBConstants.Common.DataType, "INT", true, true, SearchFilterDefinition.StatementLogic.OR, 0);

        }

        /// <summary>
        ///A test for IsIdentifierColumnConfigKey on non-exact match data type searches
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ParseDetails_IsIdentifierColumnConfigKey_nonExactMatch()
        {
            GenerateFilterTypes();
            SearchFilterItem searchFilterItem;
            SearchFilterConfig searchFilterConfig;

            Assert.IsTrue(_parser.Parse("dt:somethingWith4Number OR dt:somethingWith,Comma OR dt:somethingWith]ArrayIdent OR dt:somethingWith[ArrayIdent OR dt:somethingWithNothingSpecial", _filterTypes, false));
            searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
            Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 5);
            // Even though none of the first 4 filter items are exact match, they each have special characters that SearchFilterDefinition.cs looks for to make IsIdentifierColumnConfigKey=true
            searchFilterItem = searchFilterConfig.GetFilterItems[0];
            this.AssertSearchFilterItem(searchFilterItem, SearchFilterDefinition.ColumnDatatypeString, "somethingWith4Number", false, true /* IsIdentifierColumnConfigKey is true */, SearchFilterDefinition.StatementLogic.AND, 0);
            searchFilterItem = searchFilterConfig.GetFilterItems[1];
            this.AssertSearchFilterItem(searchFilterItem, SearchFilterDefinition.ColumnDatatypeString, "somethingWith,Comma", false, true /* IsIdentifierColumnConfigKey is true */, SearchFilterDefinition.StatementLogic.OR, 0);
            searchFilterItem = searchFilterConfig.GetFilterItems[2];
            this.AssertSearchFilterItem(searchFilterItem, SearchFilterDefinition.ColumnDatatypeString, "somethingWith]ArrayIdent", false, true /* IsIdentifierColumnConfigKey is true */, SearchFilterDefinition.StatementLogic.OR, 0);
            searchFilterItem = searchFilterConfig.GetFilterItems[3];
            this.AssertSearchFilterItem(searchFilterItem, SearchFilterDefinition.ColumnDatatypeString, "somethingWith[ArrayIdent", false, true /* IsIdentifierColumnConfigKey is true */, SearchFilterDefinition.StatementLogic.OR, 0);
            // the last search filter item does not have any special characters to make it have IsIdentifierColumnConfigKey=true
            searchFilterItem = searchFilterConfig.GetFilterItems[4];
            this.AssertSearchFilterItem(searchFilterItem, SearchFilterDefinition.DataTypeIdentifier, "somethingWithNothingSpecial", false, false /* IsIdentifierColumnConfigKey is false */, SearchFilterDefinition.StatementLogic.OR, 0);
        }


        ///A test for Parse filter operators used as values with a mixture of filter operators and values in the filter string
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ParseDetails_Valid_FilterValue_OperatorWithValues()
        {
            GenerateFilterTypes();
            SearchFilterConfig searchFilterConfig;

            string[] searchFiltersNested = { 
                                       "description:(dt: someStuff d: dt: someStuff)",
                                       "description:(dt: AND someStuff AND d: AND dt: AND someStuff)",
                                       "d:(dt: someStuff d: dt: someStuff)"
                                      };
            GenerateFilterTypes();
            foreach (bool actual in searchFiltersNested.Select(searchFilter => _parser.Parse(searchFilter, _filterTypes, false)))
            {
                Assert.IsTrue(actual);
                searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
                Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 1);
                Assert.IsTrue(searchFilterConfig.GetFilterItems[0].GetNestedItems.Count == 5);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0].GetNestedItems[0], DIBConstants.Common.Description, "dt:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0].GetNestedItems[1], DIBConstants.Common.Description, "someStuff", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0].GetNestedItems[2], DIBConstants.Common.Description, "d:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0].GetNestedItems[3], DIBConstants.Common.Description, "dt:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0].GetNestedItems[4], DIBConstants.Common.Description, "someStuff", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
            }

            string[] searchFiltersNonNested = { 
                                       "d:dt: d:someStuff d:d: d:dt: d:someStuff",
                                       "d:(dt:) d:(someStuff) d:(d:) d:(dt:) d:(someStuff)",
                                       "d:dt: AND d:someStuff AND d:d: AND d:dt: AND d:someStuff"
                                      };
            foreach (bool actual in searchFiltersNonNested.Select(searchFilter => _parser.Parse(searchFilter, _filterTypes, false)))
            {
                Assert.IsTrue(actual);
                searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
                Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 5);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0], DIBConstants.Common.Description, "dt:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[1], DIBConstants.Common.Description, "someStuff", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[2], DIBConstants.Common.Description, "d:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[3], DIBConstants.Common.Description, "dt:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[4], DIBConstants.Common.Description, "someStuff", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
            }
        }

        ///A test for Parse filter operators used as values 
        ///</summary>
        [TestMethod()]
        public void SearchFilterParser_ParseDetails_Valid_FilterValue_MultipleFiltersWithOperators()
        {
            GenerateFilterTypes();
            SearchFilterConfig searchFilterConfig;

            string[] searchFiltersNested = { 
                                       "datatype:(someStuff d:) d:(someStuff name:)",
                                       "dt:(someStuff AND d:) AND description:(someStuff AND name:)"
                                      };
            foreach (bool actual in searchFiltersNested.Select(searchFilter => _parser.Parse(searchFilter, _filterTypes, false)))
            {
                Assert.IsTrue(actual);
                searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
                Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 2);
                Assert.IsTrue(searchFilterConfig.GetFilterItems[0].GetNestedItems.Count == 2);
                Assert.IsTrue(searchFilterConfig.GetFilterItems[1].GetNestedItems.Count == 2);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0].GetNestedItems[0], SearchFilterDefinition.DataTypeIdentifier, "someStuff", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0].GetNestedItems[1], SearchFilterDefinition.DataTypeIdentifier, "d:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[1].GetNestedItems[0], SearchFilterDefinition.DescriptionIdentifier, "someStuff", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[1].GetNestedItems[1], SearchFilterDefinition.DescriptionIdentifier, "name:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
            }

            string[] searchFiltersNonNested = { 
                                       "dt:(someStuff) dt:(d:) d:(someStuff) d:(name:)",
                                       "dt:someStuff dt:d: d:someStuff d:name:",
                                       "dt:someStuff AND dt:d: AND d:someStuff AND d:name:",
                                      };
            foreach (bool actual in searchFiltersNonNested.Select(searchFilter => _parser.Parse(searchFilter, _filterTypes, false)))
            {
                Assert.IsTrue(actual);
                searchFilterConfig = this._parser.FilterDefinition.GetFilterConfig();
                Assert.IsTrue(searchFilterConfig.GetFilterItems.Count == 4);
                Assert.IsTrue(searchFilterConfig.GetFilterItems[0].GetNestedItems.Count == 0);
                Assert.IsTrue(searchFilterConfig.GetFilterItems[1].GetNestedItems.Count == 0);
                Assert.IsTrue(searchFilterConfig.GetFilterItems[2].GetNestedItems.Count == 0);
                Assert.IsTrue(searchFilterConfig.GetFilterItems[3].GetNestedItems.Count == 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[0], SearchFilterDefinition.DataTypeIdentifier, "someStuff", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[1], SearchFilterDefinition.DataTypeIdentifier, "d:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[2], SearchFilterDefinition.DescriptionIdentifier, "someStuff", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
                this.AssertSearchFilterItem(searchFilterConfig.GetFilterItems[3], SearchFilterDefinition.DescriptionIdentifier, "name:", false, false, SearchFilterDefinition.StatementLogic.AND, 0);
            }
        }
		#endregion filter strings

        /// <summary>
        ///A test to verify the tostring handles nested items
        ///</summary>
        [TestMethod()]
        public void SearchFilterConfig_ToString_NestedItems()
        {
            //ARRANGE
            string searchFilter = "\"NameAndDescriptionSearch\""; // This is default search. Since filter types are set up with Name and Description
            // being 'searchable', then both name and desciption will appear in generated SearchFilterItem's
            GenerateFilterTypes();

            //ACT
            bool actual = this._parser.Parse(searchFilter, _filterTypes, true);

            //ASSERT
            Assert.IsTrue(actual);
            Assert.IsTrue(this._parser.FilterDefinition.GetFilterConfig() != null);
            Assert.IsTrue(this._parser.FilterDefinition.GetFilterConfig().GetFilterItems.Count == 1);
            SearchFilterItem parentItem = this._parser.FilterDefinition.GetFilterConfig().GetFilterItems[0];
            Assert.IsTrue(parentItem.GetIdentifier == null);
            Assert.IsTrue(parentItem.GetValue == null);
            Assert.IsTrue(parentItem.GetLogicOperator == SearchFilterDefinition.StatementLogic.AND);
            Assert.IsTrue(parentItem.GetNestedItems.Count == 2);

            this.AssertSearchFilterItem(parentItem.GetNestedItems[0], "DisplayName", "NameAndDescriptionSearch", true, false, SearchFilterDefinition.StatementLogic.AND, 0);
            this.AssertSearchFilterItem(parentItem.GetNestedItems[1], "Description", "NameAndDescriptionSearch", false, false, SearchFilterDefinition.StatementLogic.OR, 0); //We never do isExactMatch true on description filter type. Business rule

            //verify the tostring is correct
            string output = this._parser.FilterDefinition.GetFilterConfig().ToString();

            //ASSERT
            Assert.IsTrue(output.Contains("DisplayName"));
            Assert.IsTrue(output.Contains("Description"));
            Assert.IsTrue(output.Contains("NameAndDescriptionSearch"));
            CheckStringContents(output,"Identifier");
            CheckStringContents(output,"AlternateIdentifier");
            CheckStringContents(output,"Value");
            CheckStringContents(output,"IsExactMatch");
            CheckStringContents(output,"IsIdentifierColumnConfigKey");
            CheckStringContents(output,"GetLogicOperator");
                
        }

	    private static void CheckStringContents(string output, string keyname)
	    {
            //first one doesn't have any items in it
	        int index = output.IndexOf(keyname,0);
	        Assert.IsTrue(index != -1, keyname + " not found");
            //first nested item
	        int index1 = output.IndexOf(keyname, index + keyname.Length);
	        Assert.IsTrue(index1 > index, keyname + " not found for the nested item");
            //second nested item
            int index2 = output.IndexOf(keyname, index1 + keyname.Length);
            Assert.IsTrue(index2 > index1, keyname + " not found for the nested item");
	    }
	}
}
