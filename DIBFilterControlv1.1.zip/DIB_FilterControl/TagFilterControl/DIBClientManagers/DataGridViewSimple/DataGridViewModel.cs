﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.ViewModels;

namespace TagFilterControl.DIBClientManagers.DataGridViewSimple
{
    public class DataGridViewModel : DIBGridViewModel
    {
        public Action<DataItemBase> ExecuteDrillInCommand { get; set; }

        public DataGridViewModel(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
            ExecuteDrillInCommand += (dataItemBase) =>
            {
                this.DrillInCommand.Execute(dataItemBase);
            };
        }

        public override SimpleCommand CreateDrillInCommand()
        {
            return new SimpleCommand()
            {
                ExecuteDelegate = x =>
                {
                    DIBTreeViewItem node = x as DIBTreeViewItem;
                    if (node == null)
                    {
                        if (x != null)
                        {
                            _dibViewModel.Navigate(x as DataItemBase);
                        }
                        else
                        {
                            int count = _dibViewModel.Path.Items.Count;
                            if (count > 0)
                            {
                                while (count != 1)
                                {
                                    _dibViewModel.Path.Items.RemoveAt(count - 1);
                                    count = _dibViewModel.Path.Items.Count;
                                }
                            }
                            _dibViewModel.Navigate(null);
                        }
                        return;
                    }
                    if (node.DataItem == null) return;

                    if ((_dibViewModel.Path.Forward != null) &&
                        (node.VisualName == _dibViewModel.Path.Forward.DisplayName))
                        _dibViewModel.Path.SetActive(_dibViewModel.Path.Forward);
                    else
                    {
                        IPathElement newPE = PathElementFactory.Instance().CreatePathElement(node.DataItem);
                        _dibViewModel.Path.Add(newPE);

                    }
                    //handle highlighted item processing
                    this.Path.HighlightedElement = Path.ActiveElement;
                    _dibViewModel.Navigate(node.DataItem);
                }
            };
        }
    }
}
