﻿/* ****************************************************************************
*
*  Copyright 2016 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.AbstractItem;


namespace RockwellAutomation.UI
{
    /// <summary>
    /// AOGScreenPathElement PathElement
    /// </summary>
    public class AOGScreenPathElement : PathElementBase
    {

        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public AOGScreenPathElement(DataItemBase dataItem, string displayName)
            : base(dataItem, displayName)
        {
        }

        #endregion

        #region private members

        private string _displayName = string.Empty;
        private bool _hasChildren = false;
        private bool _isActive = true;
        private bool _isContainer = true;

        #endregion

        #region PathElementBase overrides

        /// <summary>
        /// Property to get or set the path element's display name.
        /// </summary>
        public override string DisplayName
        {
            get { return _displayName; }
            set { _displayName = value; }
        }

        /// <summary>
        /// Property to get or set if the path element has children.
        /// </summary>
        public override bool HasChildren
        {
            get { return _hasChildren; }
        }

        /// <summary>
        /// Property to get or set if the path element is active.
        /// </summary>
        public override bool IsActive
        {
            get { return _isActive; }
            set
            {
                if (_isActive == value)
                    return;
                _isActive = value;
                // notify listeners
                NotifyPropertyChanged("IsActive");
            }
        }

        /// <summary>
        /// Property to get or set if the path element is a container.
        /// </summary>
        public override bool IsContainer
        {
            get { return _isContainer; }
        }

        #endregion
    }
}
