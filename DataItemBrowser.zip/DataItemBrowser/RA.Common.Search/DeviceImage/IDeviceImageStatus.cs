﻿/* ****************************************************************************
*
*  Copyright 2012 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/
using System.ComponentModel;
using RockwellAutomation.UI.CommonControls.DeviceImage.ViewModels;

namespace RockwellAutomation.UI.CommonControls.DeviceImage
{
    /// <summary>
    /// device status interface - this interface supplies the replicationstate and resource error 
    /// to the DeviceImageControl control.  If you expect the DeviceImage control to dynamically update 
    /// the state of the image, the replicationstate and resourceerror properties must fire the 
    /// PropertyChangedEvent when the property setter is called.
    /// </summary>
    public interface IDeviceStatus : INotifyPropertyChanged
    {
        DeviceImagePresenter.ReplicationStateType ReplicationState { get; }
        string ReplicationError { get; }
    }
}
