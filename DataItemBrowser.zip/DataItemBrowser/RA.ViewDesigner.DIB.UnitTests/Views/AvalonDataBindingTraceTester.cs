﻿/* ****************************************************************************
*
*  Copyright 2011 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System.Diagnostics;
using System.Windows;
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AvalonUnitTesting
{
    /// <summary>
    /// Hooks to the Trace of the WPF databinding to check for dat binding errors
    /// </summary>
    public static class AvalonDataBindingTraceTester
    {
        private static AvalonTraceListener dataBindingListener;

        /// <summary>
        /// Gets a databinding trace listener
        /// </summary>
        internal static AvalonTraceListener DataBindingListener
        {
            get
            {
                if (dataBindingListener == null)
                    dataBindingListener = new AvalonTraceListener();
                return dataBindingListener;
            }
        }

        /// <summary>
        /// hooks the window to the wpf trace
        /// </summary>
        /// <param name="windowToTest">The window to test</param>
        public static void TestDataBindingsForObject(Window windowToTest)
        {
            EnforceDataBindingTraceListener(windowToTest);
            windowToTest.ShowInTaskbar = false;
            windowToTest.Show();
            windowToTest.Hide();
            if (DataBindingListener.Messages.Count > 0)
            {
                string message = string.Join("\r\n", DataBindingListener.Messages.ToArray());
                DataBindingListener.Messages.Clear();
                Assert.Fail(message);
            }
			ForgetWindowToTest();
        }

        /// <summary>
        /// hooks the window to the wpf trace
        /// </summary>
        /// <param name="windowToTest">The window to test</param>
        public static void TestDataBindingsForObject(Func<Window> windowToTest)
        {
            Window actualWindowToTest = EnforceDataBindingTraceListener(windowToTest);
            actualWindowToTest.ShowInTaskbar = false;
            actualWindowToTest.Show();
            actualWindowToTest.Hide();
            if (DataBindingListener.Messages.Count > 0)
            {
                string message = string.Join("\r\n", DataBindingListener.Messages.ToArray());
                DataBindingListener.Messages.Clear();
                Assert.Fail(message);
            }
			ForgetWindowToTest();
        }

        //check if there is already a databinding trace listener, if not creates it
        private static void EnforceDataBindingTraceListener(Window currentWindow)
        {
            PresentationTraceSources.Refresh();
            PresentationTraceSources.DataBindingSource.Switch.Level = SourceLevels.Warning;

            //add the databinding listener
            if (!PresentationTraceSources.DataBindingSource.Listeners.Contains(DataBindingListener))
                PresentationTraceSources.DataBindingSource.Listeners.Add(DataBindingListener);

            //set the current window being tested
            DataBindingListener.CurrentWindowBeingTested = currentWindow;
        }

        //check if there is already a databinding trace listener, if not creates it
        private static Window EnforceDataBindingTraceListener(Func<Window> currentWindow)
        {
            PresentationTraceSources.Refresh();
            PresentationTraceSources.DataBindingSource.Switch.Level = SourceLevels.Warning;

            //add the databinding listener
            if (!PresentationTraceSources.DataBindingSource.Listeners.Contains(DataBindingListener))
                PresentationTraceSources.DataBindingSource.Listeners.Add(DataBindingListener);

            //set the current window being tested
            DataBindingListener.CurrentWindowBeingTested = currentWindow();
            return DataBindingListener.CurrentWindowBeingTested;
        }

		private static void ForgetWindowToTest()
		{
			// We need to do this so we don't pollute the next test.
			// Without this, binding failures can appear as a "wrong thread" issue but is really a "stale Window reference",
			// this test class is keeping an old (wrong-thread) window reference when it shouldn't
			DataBindingListener.CurrentWindowBeingTested = null;
		}
    }
}
