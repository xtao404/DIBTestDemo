/*************************************************************************************
                                                                     
   ViewE CommonControls
   Copyright � 2009-2011 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System;
using System.ComponentModel;
using RockwellAutomation.UI.CommonControls.Models;
using System.Collections.ObjectModel;
using System.Windows.Input;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.UI.CommonControls.SearchFilter.ViewModels;
using System.Collections.Generic;

namespace RockwellAutomation.UI.CommonControls.ViewModels
{
    public class SearchFilterControlViewModel : ISearchFilterControlViewModel, INotifyPropertyChanged
    {
        #region Static Variables

        /// <summary>
        /// Default Search Timer to use if not specified by clients
        /// </summary>
        public static readonly TimeSpan DefaultAutoSearchTimerDelay = new TimeSpan(0, 0, 1); //1 second by default

        private static Dictionary<string, MruListObservableCollection> mruListHistories = new Dictionary<string, MruListObservableCollection>();
        #endregion


        /// <summary>
        /// Constructor
        /// </summary>
        public SearchFilterControlViewModel(ObservableCollection<FilterType> filterTypes)
        {
            SearchModeEnabled = false;
            AutoSearchTimerDelay = DefaultAutoSearchTimerDelay; 
            _filterTypes = filterTypes;
            _searchFilterParser = new SearchFilterParser();
        }

        /// <summary>
        /// initialize with a filterdefinition 
        /// </summary>       
        /// <param name="filterDefinition"></param>
        public void Initialize(SearchFilterDefinition filterDefinition)
        {
            Initialize(filterDefinition, null);
        }

        /// <summary>
        /// initialize with a filterdefinition and mruListContextName
        /// </summary>       
        /// <param name="filterDefinition"></param>
        /// <param name="mruListContextName"></param>
        public void Initialize(SearchFilterDefinition filterDefinition, string mruListContextName)
        {
            //If we're given a name where the MRU list should be remembered, lookup that context
            // in our static data, and use the existing items, or create the context in the cache
            if (mruListContextName != null)
            {
                mruListContextName = mruListContextName.ToLower();
                if (mruListHistories.ContainsKey(mruListContextName))
                {
                    _searchMruList = mruListHistories[mruListContextName];
                }
                else
                {
                    mruListHistories[mruListContextName] = SearchMruList;
                }
            }

            SearchMruListHasItems = SearchMruList.Count > 0;

            if (filterDefinition != null)
            {
                this._searchFilterParser.FilterDefinition = filterDefinition;
                this.SearchFilterText = filterDefinition.SearchString;
                // Dont add the search Text pendingMRU item not MRU as there could be parser error 
                this._pendingSearchMruItem = this.SearchFilterText;
                SearchErrorIndicatorMessage = string.Empty;

                // Since we are being initialized with a search filter text, check for parser error now
                this.NotifyPropertyChanged("ParseSearchTextOnInitialize");
            }
        }

        /// <summary>
        /// Clear the current MRU list (note that if a named context was specified during initialize,
        /// the ClearMruListContext or ClearMruListContexts methods should be used to clear MRU lists)
        /// </summary>
        public void ClearMruList()
        {
            _searchMruList.Clear();
            _searchMruListHasItems = false;
        }

        /// <summary>
        /// Clears all items in all named MRU list contexts
        /// </summary>
        public static void ClearMruListContexts()
        {
            foreach (KeyValuePair<string, MruListObservableCollection> mruHistoryPair in mruListHistories)
                mruHistoryPair.Value.Clear();
        }

        /// <summary>
        /// Clears all items in the named MRU list context
        /// </summary>
        /// <param name="contextName">Name of the context to clear. Context names can be specified in the call to
        /// initialize to track separate MRU list "areas"</param>
        public static void ClearMruListContext(string contextName)
        {
            string contextNameLower = contextName.ToLower();
            if (mruListHistories.ContainsKey(contextNameLower))
                mruListHistories[contextNameLower].Clear();
        }
        
        /// <summary>
        /// Most Recently Used list of searches 
        /// bound to the MRU button
        /// </summary>
        private MruListObservableCollection _searchMruList = null;
        public MruListObservableCollection SearchMruList
        {
            get
            {
                if (_searchMruList == null)
                    _searchMruList = new MruListObservableCollection();
                return _searchMruList;
            }
        }
        private bool _searchMruListHasItems = false;
        public bool SearchMruListHasItems
        {
            get
            {
                return _searchMruListHasItems;
            }
            set
            {
                if (value == _searchMruListHasItems)
                    return;
                _searchMruListHasItems = value;

                NotifyPropertyChanged("SearchMruListHasItems");
            }
        }

        /// <summary>
        /// Holds onto a string we need to add to the MRU list (SearchMruOpened)
        /// holds the text of the most recent auto search since we don't want to add
        /// all intermediate auto searches to the MRU while a user is typing
        /// </summary>
        private string _pendingSearchMruItem { get; set; }

        /// <summary>
        /// Trigger from the view whenever the MRU list should make sure it has been updated
        /// with the last search text.  We need to do this because when a search occurs as a
        /// result of the automatic timer, we don't add the search text to the MRU immediately
        /// </summary>
        public void EnsureMruUpdated()
        {
            if (!string.IsNullOrWhiteSpace(_pendingSearchMruItem))
            {
                this.SearchMruList.Add(_pendingSearchMruItem);
                SearchMruListHasItems = true;
                _pendingSearchMruItem = String.Empty;
            }
        }

        /// <summary>
        /// filter types used by the parser
        /// also bound to the filter button context menu
        /// </summary>
        private ObservableCollection<FilterType> _filterTypes = null;
        public  ObservableCollection<FilterType> FilterTypes
        {
            get
            {
                if (_filterTypes == null)
                    FilterTypes = new ObservableCollection<FilterType>();

                return _filterTypes;
            }
            internal set
            {
                if (value == _filterTypes)
                    return;
                _filterTypes = value;
                NotifyPropertyChanged("FilterTypes");
            }
        }

        /// <summary>
        /// Allows client to turn on or off the ability to search on free form text
        /// </summary>
        public bool SearchModeEnabled { get; set; }

		/// <summary>
		/// Allows client to set the delay before a search is automatically performed
		/// </summary>
		public TimeSpan AutoSearchTimerDelay { get; set; }

		/// <summary>
		/// Will be true if the last search was automatically performed (as a result of a timer
		/// firing).  False if the user explicitly invoked search (enter, MRU, etc).
		/// </summary>
		public bool AutoSearched { get; set; }

        /// <summary>
        /// execute filter command
        /// </summary>
        private SimpleCommand _executeFilterCommand = null;
        public ICommand ExecuteFilterCommand
        {
            get
            {
                if (_executeFilterCommand == null)
                {
                    _executeFilterCommand = new SimpleCommand()
                    {
                        ExecuteDelegate = x =>
                        {
                            string searchText = x as string;
                            this.SearchFilterText = searchText;

                            //Even if we're an auto search, if the user is clearing the text, make sure we add any 
                            // pending MRU item to the list (this is a special case since we might not ever lose focus
                            // to hit the other invokers of the EnsureMruUpdated method).
                            if(string.IsNullOrEmpty(searchText))
                                this.EnsureMruUpdated();

							_pendingSearchMruItem = String.Empty;

                            //If we are being called with a blank search string and the
                            // SearchFilterParser is not currently searching/filtering
                            // (obtained through the IsActive property) then we can simply
                            // return here as clearing the SearchFilterText above is
                            // all that needs to be done (i.e. we don't want to refresh
                            // the grid which would change the selected item nor do we 
                            // need to update the breadcrumbs).                            
                            if (searchText.Length == 0 && !_searchFilterParser.FilterDefinition.IsActive)
                            {
                                //clear the error token 
                                _searchFilterParser.FilterDefinition.ErrorToken = null;
                                return;
                            }

                            //add search breadcrumb
                            //Parse the Search Filter string
                            if (_searchFilterParser.Parse(this.SearchFilterText, this.FilterTypes, this.SearchModeEnabled))
                            {
                                //success and text was not empty
                                if (HasNonEmptySearchValue)
                                {
									//if auto searched, we will wait to put the text in the mru list
									// in case more text is typed (i.e. we only want the "final" text
									// the user typed despite if an auto search was trigger while they
									// were typing
                                    if (this.AutoSearched)
                                        _pendingSearchMruItem = this.SearchFilterText;
                                    else
                                    {
                                        this.SearchMruList.Add(this.SearchFilterText);
                                    }
                                    SearchMruListHasItems = true;
                                    CurrentState = FilterState.Searching;
                                }
                                SearchErrorIndicatorMessage = string.Empty;
                            }
                            else
                            {
                                //fail
                                SearchErrorIndicatorMessage = _searchFilterParser.FilterDefinition.ErrorToken.SyntaxErrorMessage + " " + _searchFilterParser.FilterDefinition.ErrorToken.Value;
                            }

                        }

                    };

                }
                return _executeFilterCommand;
            }
        }
               
        /// <summary>
        /// Search/Filter text 
        /// bound to the search/filter text box
        /// </summary>
        private string _searchFilterText = String.Empty;
        public string SearchFilterText
        {
            get { return _searchFilterText; }
            set
            {
                if (value == _searchFilterText)
                    return;

                _searchFilterText = value;                
                NotifyPropertyChanged("SearchFilterText");
            }
        }

        //TODO:FILTER remove when colorize the syntax for the search/filter text
        /// <summary>
        /// Search/Filter error indicator message
        /// </summary>
        private string _searchErrorIndicatorMessage = string.Empty;
        public string SearchErrorIndicatorMessage
        {
            get { return _searchErrorIndicatorMessage; }
            set
            {
                if (value == _searchErrorIndicatorMessage)
                    return;
                _searchErrorIndicatorMessage = value;

                NotifyPropertyChanged("SearchErrorIndicatorMessage");
            }
        }
        private SearchFilterParser _searchFilterParser = null;


       
        /// <summary>
        /// Returns true if there was a parse error
        /// </summary>
        public bool HasError
        {
            get
            {
                //active means that we are not using an filter and that there is no error associated with it
                return this._searchFilterParser.FilterDefinition.HasError;
            }
            set{ }
        }

        /// <summary>
        /// Returns the starting index of the error
        /// </summary>
        public int ErrorStartIndex
        {
            get
            {
                if (this._searchFilterParser.FilterDefinition.ErrorToken != null)
                    return this._searchFilterParser.FilterDefinition.ErrorToken.StartingIndex;

                return -1;
            }
            set{}
        }

        /// <summary>
        /// Returns the length of the error
        /// </summary>
        public int ErrorLength
        {
            get
            {
                if (this._searchFilterParser.FilterDefinition.ErrorToken != null)
                    return this._searchFilterParser.FilterDefinition.ErrorToken.Length;

                return -1;
            }

            set{ //empty
            }
        }

        /// <summary>
        /// Clear search 
        /// </summary>
        public void ClearSearch()
        {
            this._searchFilterParser.FilterDefinition.ClearSearch();

            //Make sure we send out a NotifyPropertyChanged since clients who only bind to search filter text one way
            // might not have the search text cleared if they haven't yet sent the GUI value change to the VM (as is the
            // case when the filter type dropdown adds text to the search text box before any other key is pressed)
            this.SearchFilterText = string.Empty;
            NotifyPropertyChanged("SearchFilterText");
            
            SearchErrorIndicatorMessage = string.Empty;
            CurrentState = FilterState.Canceling;            
        }

        public enum FilterState
        {
            Initial = 0,
            Searching = 1,
            Canceling = 2
        }
        private FilterState _currentState = FilterState.Initial;

        public FilterState CurrentState
        {
            get { return _currentState; }
            set
            {
                PreviousState = _currentState;
                _currentState = value;
            }
        }
        private FilterState _previousState = FilterState.Initial;

        public FilterState PreviousState
        {
            get { return _previousState; }
            set
            {
                _previousState = value;
            }
        }

        public bool IsClearingSearch()
        {
            return CurrentState == SearchFilterControlViewModel.FilterState.Canceling;
        }

        /// <summary>
        ///  This function identifies cancel requests that are not actually cancelling a search request.  This includes 
        ///      cancelling when no searchfiltertext was previously entered.
        ///      cancelling when no searchfilter request was previously started
        ///      cancelling when a cancel is already being performed.
        ///  In these cases, the cancel is handled differently by the client.
        /// </summary>
        /// <returns>indicates whether the cancel request is not cancelling an active search request</returns>
        public bool IsClientOnlyCancelRequest()
        {
            // is this a preemptive (not actually cancelling a search) cancel request.
            if ((SearchFilterText.Length == 0 && PreviousState == SearchFilterControlViewModel.FilterState.Initial) ||
                (PreviousState == SearchFilterControlViewModel.FilterState.Canceling && CurrentState == SearchFilterControlViewModel.FilterState.Canceling))
                return true;

            return false;
        }

        /// <summary>
        /// Returns true if some search/filter is currently applied
        /// </summary>
        public bool IsActive
        {
            get
            {
                return this._searchFilterParser.FilterDefinition.IsActive;
            }
            set
            {/*no implementation*/}
        }

        /// <summary>
        /// Returns true if these results contain any non-empty search/filter values
        /// </summary>
        public bool HasNonEmptySearchValue
        {
            get { return this._searchFilterParser.FilterDefinition.HasNonEmptySearchValue; }
            set{/*no implementation*/}
        }

        /// <summary>
        /// get the QueryCondition used for the query request condition in the CDS
        /// </summary>
        /// <returns></returns>
        public SearchFilterConfig GetFilterConfig()
        {
            return this._searchFilterParser.FilterDefinition != null ? this._searchFilterParser.FilterDefinition.GetFilterConfig() : null;
        }

        /// <summary>
        /// Returns true if the passed filter type is present in the current search text
        /// </summary>
        /// <param name="type">Type of filter to look for</param>
        /// <returns>True if filter is present in current search</returns>
        public bool ContainsFilterType(FilterType type)
        {
            return this._searchFilterParser.FilterDefinition.Contains(type);
        }

        /// <summary>
        /// apply the view filtering on the item supplied
        /// </summary>
        /// <param name="item">item to be filtered</param>
        /// <param name="getFieldValue">delegate to get field value</param>
        /// <returns></returns>
        public bool ApplyViewFilter(Object item, GetFieldValue getFieldValue)
        {
            return this._searchFilterParser.FilterDefinition.ApplyViewFilter(item, getFieldValue);
        }
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// implements the INotifyPropertyChanged interface method NotifyPropertyChanged
        /// </summary>
        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

      

    }
}
