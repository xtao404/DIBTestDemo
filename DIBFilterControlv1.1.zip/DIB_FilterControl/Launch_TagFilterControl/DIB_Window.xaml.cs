﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TagFilterControl.Controls;

namespace Launch_TagFilterControl
{
    /// <summary>
    /// Interaction logic for DIB_Window.xaml
    /// </summary>
    public partial class DIB_Window : Window
    {
        private FilterDIBInstance filterDIBIn = FilterDIBInstance.GetInstance();
        public DIB_Window()
        {
            InitializeComponent();
            this.Closed += DIB_Window_Closed;
        }

        void DIB_Window_Closed(object sender, EventArgs e)
        {
            filterDIBIn.DIBClientManager = null;
        }
    }
}
