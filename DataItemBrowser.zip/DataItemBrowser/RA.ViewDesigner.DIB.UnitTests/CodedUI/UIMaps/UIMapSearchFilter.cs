﻿
namespace DataItemBrowserUT.CodedUI.UIMaps.UIMapSearchFilterClasses
{
    using Microsoft.VisualStudio.TestTools.UITesting.WpfControls;
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Windows.Input;
    using System.CodeDom.Compiler;
    using System.Text.RegularExpressions;
    using Microsoft.VisualStudio.TestTools.UITest.Extension;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
    using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
    using MouseButtons = System.Windows.Forms.MouseButtons;
    using RockwellAutomation.Client.Services.Query.Common;


    public partial class UIMapSearchFilter
    {

        public enum FilterTypeEnum
        {
            Name,
            DataType,
            Description
        };

        /// <summary>
        /// DIB_SearchFilterControl_FilterBuilder_SelectFilterType
        /// </summary>
        public void DIB_SearchFilterControl_FilterBuilder_SelectFilterType(FilterTypeEnum filterType)
        {
            #region Variable Declarations

            WpfButton uIFilterBuilderBtnButton = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIFilterBuilderBtnButton;
            WpfMenuItem uINameMenuItem = this.UIDataItemBrowserHostWWindow.UIFilterBuilderBtn_ConMenu.UINameMenuItem;

            #endregion

            // Click 'FilterBuilderBtn' button
            Mouse.Click(uIFilterBuilderBtnButton, new Point(16, 5));

            uINameMenuItem = GetFilterTypeMenuItem(filterType);

            // Click 'Name' menu item
            Mouse.Click(uINameMenuItem, new Point(25, 8));
        }

        private WpfMenuItem UIFilterTypeMenuItem;

        private WpfMenuItem GetFilterTypeMenuItem(FilterTypeEnum filterType)
        {
            UIFilterTypeMenuItem = new WpfMenuItem(this.UIDataItemBrowserHostWWindow.UIFilterBuilderBtn_ConMenu);

            switch (filterType)
            {
                case FilterTypeEnum.DataType:
                    UIFilterTypeMenuItem.SearchProperties[WpfMenuItem.PropertyNames.Name] = DIBConstants.Common.DataType;
                    break;
                case FilterTypeEnum.Description:
                    UIFilterTypeMenuItem.SearchProperties[WpfMenuItem.PropertyNames.Name] = DIBConstants.Common.Description;
                    break;
                default:
                    UIFilterTypeMenuItem.SearchProperties[WpfMenuItem.PropertyNames.Name] = DIBConstants.Common.Name;
                    break;
            }

            UIFilterTypeMenuItem.WindowTitles.Add("DataItemBrowser Host Window");
            return UIFilterTypeMenuItem;
        }

        /// <summary>
        /// DIB_Assert_SearchFilterText_Value - Use 'DIB_Assert_SearchFilterText_ValueExpectedValues' to pass parameters into this method.
        /// Setting 'DIB_Assert_SearchFilterText_ValueExpectedValues' inside the method to make the test class more readable.
        /// </summary>
        public void DIB_Assert_SearchFilterText_Value(string expectedValue)
        {
            this.DIB_Assert_SearchFilterText_ValueExpectedValues.UISearchFilterTextBoxEditText = expectedValue.Trim();

            #region Variable Declarations

            WpfEdit uISearchFilterTextBoxEdit = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UISearchFilterTextBoxEdit;

            #endregion

            // Verify that 'SearchFilterTextBox' text box's property 'Text' equals expectedValue
            Assert.AreEqual(this.DIB_Assert_SearchFilterText_ValueExpectedValues.UISearchFilterTextBoxEditText, uISearchFilterTextBoxEdit.Text.Trim());
        }

        public virtual DIB_Assert_SearchFilterText_ValueExpectedValues DIB_Assert_SearchFilterText_ValueExpectedValues
        {
            get
            {
                if ((this.mDIB_Assert_SearchFilterText_ValueExpectedValues == null))
                {
                    this.mDIB_Assert_SearchFilterText_ValueExpectedValues = new DIB_Assert_SearchFilterText_ValueExpectedValues();
                }
                return this.mDIB_Assert_SearchFilterText_ValueExpectedValues;
            }
        }

        private DIB_Assert_SearchFilterText_ValueExpectedValues mDIB_Assert_SearchFilterText_ValueExpectedValues;



        /// <summary>
        /// DIB_SearchFilterControl_TypeSearchFilterText - Use 'DIB_SearchFilterControl_TypeSearchFilterTextParams' to pass parameters into this method.
        /// Setting 'DIB_SearchFilterControl_TypeSearchFilterTextParams' inside this method to make the test class cleaner.
        /// </summary>
        public void DIB_SearchFilterControl_TypeSearchFilterText(string searchTextValue)
        {
            this.DIB_SearchFilterControl_TypeSearchFilterTextParams.UISearchFilterTextBoxEditText = searchTextValue;

            #region Variable Declarations
            WpfEdit uISearchFilterTextBoxEdit = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UISearchFilterTextBoxEdit;
            #endregion

            // Type a string in 'SearchFilterTextBox' text box
            uISearchFilterTextBoxEdit.Text += this.DIB_SearchFilterControl_TypeSearchFilterTextParams.UISearchFilterTextBoxEditText;
        }

        public virtual DIB_SearchFilterControl_TypeSearchFilterTextParams DIB_SearchFilterControl_TypeSearchFilterTextParams
        {
            get
            {
                if ((this.mDIB_SearchFilterControl_TypeSearchFilterTextParams == null))
                {
                    this.mDIB_SearchFilterControl_TypeSearchFilterTextParams = new DIB_SearchFilterControl_TypeSearchFilterTextParams();
                }
                return this.mDIB_SearchFilterControl_TypeSearchFilterTextParams;
            }
        }

        private DIB_SearchFilterControl_TypeSearchFilterTextParams mDIB_SearchFilterControl_TypeSearchFilterTextParams;



        /// <summary>
        /// DIB_Assert_SearchFilterControl_MRUList_ContentsValid - Use 'DIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues' to pass parameters into this method.
        /// </summary>
        public void DIB_Assert_SearchFilterControl_MRUList_ContentsValid(IList<string> validMRUListItems)
        {
            #region Variable Declarations
            WpfList uIMruListViewList = this.UIDataItemBrowserHostWWindow.UIMruListViewList;
            #endregion

            // Verify that 'MruListView' list box's property 'AutomationId' equals 'MruListView'
            Assert.AreEqual(this.DIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues.UIMruListViewListAutomationId, uIMruListViewList.AutomationId);

            for (int i = 0; i < uIMruListViewList.Items.Count; i++)
            {
                UITestControl item = uIMruListViewList.Items[i];
                Assert.AreEqual(validMRUListItems[i], item.Name);
            }

        }

        public virtual DIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues DIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues
        {
            get
            {
                if ((this.mDIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues == null))
                {
                    this.mDIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues = new DIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues();
                }
                return this.mDIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues;
            }
        }

        private DIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues mDIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues;

        /// <summary>
        /// DIB_SearchFilterControl_SelectMRUListItem - Use 'DIB_SearchFilterControl_SelectMRUListItemParams' to pass parameters into this method.
        /// </summary>
        public void DIB_SearchFilterControl_SelectMRUListItem(string itemToSelect)
        {

            #region Variable Declarations
            WpfListItem uIDtagListItem = new WpfListItem(this.UIDataItemBrowserHostWWindow.UIMruListViewList);
            uIDtagListItem.SearchProperties[WpfListItem.PropertyNames.Name] = itemToSelect;
            uIDtagListItem.WindowTitles.Add("DataItemBrowser Host Window");
            #endregion
            
            // Click list item
            Mouse.Click(uIDtagListItem, new Point(966, 10));
        }

        public virtual DIB_SearchFilterControl_SelectMRUListItemParams DIB_SearchFilterControl_SelectMRUListItemParams
        {
            get
            {
                if ((this.mDIB_SearchFilterControl_SelectMRUListItemParams == null))
                {
                    this.mDIB_SearchFilterControl_SelectMRUListItemParams = new DIB_SearchFilterControl_SelectMRUListItemParams();
                }
                return this.mDIB_SearchFilterControl_SelectMRUListItemParams;
            }
        }

        private DIB_SearchFilterControl_SelectMRUListItemParams mDIB_SearchFilterControl_SelectMRUListItemParams;
    }  //end partial class UIMapSearchFilter

    /// <summary>
    /// Parameters to be passed into 'DIB_Assert_SearchFilterText_Value'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_Assert_SearchFilterText_ValueExpectedValues
    {

        #region Fields
        /// <summary>
        /// Verify that 'SearchFilterTextBox' text box's property 'Text' equals ' name:'
        /// </summary>
        public string UISearchFilterTextBoxEditText = " name:";
        #endregion
    }


    /// <summary>
    /// Parameters to be passed into 'DIB_SearchFilterControl_TypeSearchFilterText'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_SearchFilterControl_TypeSearchFilterTextParams
    {

        #region Fields
        /// <summary>
        /// Type a string in 'SearchFilterTextBox' text box
        /// </summary>
        public string UISearchFilterTextBoxEditText = string.Empty;
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_Assert_SearchFilterControl_MRUList_ContentsValid'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_Assert_SearchFilterControl_MRUList_ContentsValidExpectedValues
    {

        #region Fields
        /// <summary>
        /// Verify that 'MruListView' list box's property 'AutomationId' equals 'MruListView'
        /// </summary>
        public string UIMruListViewListAutomationId = "MruListView";
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_SearchFilterControl_SelectMRUListItem'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_SearchFilterControl_SelectMRUListItemParams
    {

        #region Fields
        /// <summary>
        /// Set to 'Pressed' state 'SearchMruBtn' toggle button
        /// </summary>
        public bool UISearchMruBtnToggleButtonPressed = true;
        #endregion
    }

  
} //end UIMapSearchFilter class
