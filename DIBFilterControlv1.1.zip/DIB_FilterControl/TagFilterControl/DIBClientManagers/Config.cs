﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TagFilterControl.Tags;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using TagFilterControl.Controls.PreFilterManager.Common;

namespace TagFilterControl.DIBClientManagers
{
    public class Config
    {
        private static Config instance = new Config();
        private Config() { }
        public static Config GetInstance()
        {
            if (instance == null)
            {
                instance = new Config();
            }
            return instance;
        }

        public List<string> DefaultTopNodes = new List<string>() { "User-Defined", "Strings", "Add-On-Defined", 
            "PreDefined", "Module-Defined", "Usage", "ACM", "Catalog Number", "Interface", "DataMembers"};

        private bool isFirstToFilterDIBControl = false;
        public bool IsFirstToFilterDIBControl
        {
            get { return isFirstToFilterDIBControl; }
            set { isFirstToFilterDIBControl = value; }
        }

        public string Usage { get; set; }

        public Action<string> ConditionContentAction { get; set; }

        private bool isRefreshed = false;
        public bool IsRefreshed
        {
            get { return isRefreshed; }
            set { isRefreshed = value; }
        }

        public DataItemBase ControllerTags { get; set; }
        public DataItemBase ProgramTags { get; set; }
        public DataItemBase ProgramTagOne { get; set; }

        private FilterProfile selectFilterProfile;
        public FilterProfile SelectFilterProfile
        {
            get { return selectFilterProfile; }
            set { this.selectFilterProfile = value; }
        }

        private List<FilterProfile> filterItem = new List<FilterProfile>();
        public List<FilterProfile> FilterItem
        {
            get { return filterItem; }
            set { filterItem = value; }
        }

        private Dictionary<string, TagNode> isCheckedTags = new Dictionary<string, TagNode>();
        public Dictionary<string, TagNode> IsCheckedTags
        {
            get { return isCheckedTags; }
            set { isCheckedTags = value; }
        }

        private Dictionary<string, TagNode> acmCustomPropertiesFilter = new Dictionary<string, TagNode>();
        public Dictionary<string, TagNode> ACMCustomPropertiesFilter
        {
            get { return acmCustomPropertiesFilter; }
            set { acmCustomPropertiesFilter = value; }
        }

        private Dictionary<string, TagNode> memFilter = new Dictionary<string, TagNode>();
        public Dictionary<string, TagNode> MemFilter
        {
            get { return memFilter; }
            set { memFilter = value; }
        }
    }
}
