using RockwellAutomation.UI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel;
using RockwellAutomation.UI;


namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for TextCrumbTest and is intended
    ///to contain all TextCrumbTest Unit Tests
    ///</summary>
    [TestClass()]
    public class TextCrumbTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //    _propertyName = "";
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SupportsDropArrow
        ///</summary>
        [TestMethod()]
        public void TextCrumb_SupportsDropArrowTest()
        {
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("dropArrow");
            bool expected = true;

            TextCrumb target = new TextCrumb(pe); 
            bool actual = target.SupportsDropArrow;

            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for SupportsDropArrow
        ///</summary>
        [TestMethod()]
        public void TextCrumb_SupportsDropArrowTest_HMIDevice()
        {
            IPathElement pe = PathElementUtility.Instance().CreateHMIDevicePathElement("dropArrow");
            bool expected = true;

            TextCrumb target = new TextCrumb(pe);
            bool actual = target.SupportsDropArrow;

            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for PE
        ///</summary>
        [TestMethod()]
        public void TextCrumb_PETest()
        {
            string expected = "pathMe";
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement(expected);

            TextCrumb target = new TextCrumb(pe); 
            IPathElement actual = target.PathElement;

            Assert.AreEqual(expected, actual.DisplayName);
        }

        /// <summary>
        ///A test for PE
        ///</summary>
        [TestMethod()]
        public void TextCrumb_PETest_HMIDevice()
        {
            string expected = "pathMe";
            IPathElement pe = PathElementUtility.Instance().CreateHMIDevicePathElement(expected);

            TextCrumb target = new TextCrumb(pe);
            IPathElement actual = target.PathElement;

            Assert.AreEqual(expected, actual.DisplayName);
        }

        /// <summary>
        ///A test for IsActive
        ///</summary>
        [TestMethod()]
        public void TextCrumb_IsActiveTest()
        {
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("isActive");
            bool expected = true;
            pe.IsActive = expected;

            TextCrumb target = new TextCrumb(pe); 
            bool actual = target.IsActive;

            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for IsActive
        ///</summary>
        [TestMethod()]
        public void TextCrumb_IsActiveTest_HMIDevice()
        {
            IPathElement pe = PathElementUtility.Instance().CreateHMIDevicePathElement("isActive");
            bool expected = true;
            pe.IsActive = expected;

            TextCrumb target = new TextCrumb(pe);
            bool actual = target.IsActive;

            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for DisplayName
        ///</summary>
        [TestMethod()]
        public void TextCrumb_DisplayNameTest()
        {
            string expected = "myName";
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement(expected);
            pe.DisplayName = expected;

            TextCrumb target = new TextCrumb(pe);
            string actual = target.DisplayName;

            Assert.AreEqual(expected, actual);
        }


        /// <summary>
        ///A test for DisplayName
        ///</summary>
        [TestMethod()]
        public void TextCrumb_DisplayNameTest_HMIDevice()
        {
            string expected = "myName";
            IPathElement pe = PathElementUtility.Instance().CreateHMIDevicePathElement(expected);
            pe.DisplayName = expected;

            TextCrumb target = new TextCrumb(pe);
            string actual = target.DisplayName;

            Assert.AreEqual(expected, actual);
        }
       

        /// <summary>
        /// support the PathElement_NotifyPropertyChangedTest
        /// </summary>
        private string _propertyName = string.Empty;
        /// <summary>
        /// support the PathElement_NotifyPropertyChangedTest
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void local_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            _propertyName = e.PropertyName;
        }
    }
}
