﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Runtime.CompilerServices;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    public class PathElementUtility
    {
        private static PathElementUtility _pathElementUtilityInstance = null;

        /// <summary>
        /// gets the instance of the PathElementUtility
        /// </summary>
        /// <returns></returns>
        [MethodImpl(MethodImplOptions.Synchronized)]
        public static PathElementUtility Instance()
        {
            if (_pathElementUtilityInstance == null)
            {
                _pathElementUtilityInstance = new PathElementUtility();
            }
            return _pathElementUtilityInstance;
        }

        public DataItemBase CreateHomeDataItem(string name)
        {
            DataItemBase homeDataItem = new DataItemBase() {
                CommonID = PathElementUtility.getTest_CONTROLLER_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString(),
                CommonDBId = getTest_DBID_COMMON_ID().ToString()
            };
            return homeDataItem;
        }

        public IPathElement CreateHomePathElement(string name)
        {
            List<DataItemBase> dataItems = new List<DataItemBase>();
            if (name == null)
                dataItems.Add(null);
            else
            {
                DataItemBase dataItemController = CreateHomeDataItem(name);
                dataItems.Add(dataItemController);
            }
            HomePathElement homePE = new HomePathElement(null, null);
            homePE.DataItemList = dataItems;
            return homePE;
        }

        public IPathElement CreateProgramsPathElement()
        {
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(DIResource.DIB_Programs);
            return pathElement;
        }

        public IPathElement CreateDataLogsPathElement()
        {
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(DIResource.DIB_DataLogs);
            return pathElement;
        }


        public IPathElement CreateDataLogPathElement(string name)
        {
            DataItemBase dataItemDataLog = new DataItemBase() {
                CommonID = PathElementUtility.getTest_DATALOG_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.ResourceType_DataLog.ToString(),
                CommonDBId = getTest_DBID_COMMON_ID().ToString()
            };
            IPathElement programPath = PathElementFactory.Instance().CreatePathElement(dataItemDataLog);
            return programPath;
        }
      
        public IPathElement CreateControllerPathElement(string name)
        {
            DataItemBase dataItemController = new DataItemBase () {
                CommonID = PathElementUtility.getTest_CONTROLLER_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString(),
                CommonDBId = getTest_DBID_COMMON_ID().ToString(),
                IsStructured = true
            };
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(dataItemController);
            return pathElement;
        }

        public IPathElement CreateHMIDevicePathElement(string name)
        {
            DataItemBase dataItemHMIDevice = new DataItemBase () {
                CommonID = PathElementUtility.getTest_HMIDEVICE_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.ResourceType_HMIDevice.ToString(),
                CommonDBId = getTest_DBID_COMMON_ID().ToString(),
                IsStructured = true
            };
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(dataItemHMIDevice);
            return pathElement;
        }

        public IPathElement CreateTagsAndPropertiesPathElement()
        {
            DataItemBase dataItemTagsAndProperties = new DataItemBase() {
                CommonID = PathElementUtility.getTest_TAGS_AND_PROPERTIES_COMMON_ID().ToString(),
                CommonName = DIResource.DI_COMMON_RESOURCETYPE_TAGSPROPERTIES,
                CommonResourceType = TypeIdentifiers.ResourceType_TagsAndProperties.ToString(),
                IsStructured = true
            };
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(dataItemTagsAndProperties);
            return pathElement;
        }

        public IPathElement CreateTagPathElement( string name, string dataType, bool structured = false)
        {
            DataItemBase dataItemTag1 = new DataItemBase()
            {
                CommonID = PathElementUtility.getTest_TAG_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString(),
                CommonDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString(),
                IsStructured = structured
            };
            if (!string.IsNullOrEmpty(dataType))
                dataItemTag1.CommonDataType = dataType;
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(dataItemTag1);
            return pathElement;
        }

        public IPathElement CreateProgramPathElement(string name)
        {
            DataItemBase dataItemProgram = new DataItemBase()
            {
                CommonID = PathElementUtility.getTest_PROGRAM_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.ResourceType_Program.ToString(),
                CommonDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString()
            };
            IPathElement programPath = PathElementFactory.Instance().CreatePathElement(dataItemProgram);
            return programPath;
        }

        public IPathElement CreateDataItemPathElement(string name, string dataType, bool isStructured)
        {
            DataItemBase dataItemTag = new DataItemBase()
            {
                CommonID = PathElementUtility.getTest_TAG_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString(),
                CommonDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString(),
                IsStructured = isStructured
            };
            if (!string.IsNullOrEmpty(dataType))
                dataItemTag.CommonDataType = dataType;
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(dataItemTag);
            return pathElement;
        }

        public IPathElement CreateDataTypePathElement(string name, DataTypePECategory cat)
        {
            DataItemBase dataTypeTag = new DataItemBase()
            {
                CommonID = PathElementUtility.getTest_TAG_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString(),
                CommonDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString(),
            };
            IPathElement pathElement = PathElementFactory.Instance().CreateDataTypePathElement(dataTypeTag, cat);
            return pathElement;
        }

        public IPathElement CreateDataTypeMemberPathElement(string name, string dataType, bool structured = false)
        {
            DataItemBase dataItemMember = new DataItemBase()
            {
                CommonID = PathElementUtility.getTest_DATATYPE_MEMBER_COMMON_ID().ToString(),
                CommonName = name,
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString(),
                CommonDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString(),
                IsStructured = structured
            };
            if (!string.IsNullOrEmpty(dataType))
                dataItemMember.CommonDataType = dataType;
            dataItemMember.IsStructured = false;
            IPathElement pathElement = PathElementFactory.Instance().CreatePathElement(dataItemMember);
            return pathElement;
        }

        public DataItemBase CreateDataItemBase(string name)
        {
            DataItemBase dataItemTag = new DataItemBase()
            {
                CommonID = PathElementUtility.getTest_TAG_COMMON_ID().ToString(),
                CommonName = name,
                CommonDataType = "INT[1]",
                CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString(),
                CommonDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString()
            };
            return dataItemTag;
        }

        public DataItemBase CreateDataItemBase(string name, UUID resourceType)
        {
            DataItemBase dataItemTag = new DataItemBase()
            {
                CommonID = resourceType.ToString(),
                CommonName = name,
                CommonDataType = "DINT[1]",
                CommonResourceType = resourceType.ToString(),
                CommonDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString()
            };
            return dataItemTag;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Following UUIDs have an incrementing lo value, the hi values are all the same
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        #region getTest_PROGRAMS_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 12345678901234567891\n"
        private static UUID RESOURCE_PROGRAMS_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(12345678901234567891).Build();

        public static UUID getTest_PROGRAMS_COMMON_ID()
        {
            return RESOURCE_PROGRAMS_COMMON_ID_UUID;
        }
        #endregion

        #region getTest_TAGS_AND_PROPERTIES_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 12345678901234567892\n"
        private static UUID RESOURCE_TAGS_AND_PROPERTIES_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(12345678901234567892).Build();

        public static UUID getTest_TAGS_AND_PROPERTIES_COMMON_ID()
        {
            return RESOURCE_TAGS_AND_PROPERTIES_COMMON_ID_UUID;
        }
        #endregion

        #region getTest_DATALOGS_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 12345678901234567893\n"
        private static UUID RESOURCE_DATALOGS_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(12345678901234567893).Build();

        public static UUID getTest_DATALOGS_COMMON_ID()
        {
            return RESOURCE_DATALOGS_COMMON_ID_UUID;
        }
        #endregion

        #region getTest_DBID_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 12345678901234567894\n"
        private static UUID RESOURCE_DBID_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(12345678901234567894).Build();

        public static UUID getTest_DBID_COMMON_ID()
        {
            return RESOURCE_DBID_COMMON_ID_UUID;
        }
        #endregion

        #region getTest_TAG_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 13742126344913406605\n"
        private static UUID RESOURCE_TAG_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(13742126344913406605).Build();

        public static UUID getTest_TAG_COMMON_ID()
        {
            return RESOURCE_TAG_COMMON_ID_UUID;
        }
       #endregion

        #region getTest_PROGRAM_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 13742126344913406606\n"
        private static UUID RESOURCE_PROGRAM_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(13742126344913406606).Build();

        public static UUID getTest_PROGRAM_COMMON_ID()
        {
            return RESOURCE_PROGRAM_COMMON_ID_UUID;
        }
        #endregion

        #region getTest_CONTROLLER_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 13742126344913406607\n"
        private static UUID RESOURCE_CONTROLLER_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(13742126344913406607).Build();

        public static UUID getTest_CONTROLLER_COMMON_ID()
        {
            return RESOURCE_CONTROLLER_COMMON_ID_UUID;
        }
        #endregion

        #region getTest_DATATYPE_MEMBER_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 13742126344913406608\n"
        private static UUID RESOURCE_DATATYPE_MEMBER_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(13742126344913406608).Build();

        public static UUID getTest_DATATYPE_MEMBER_COMMON_ID()
        {
            return RESOURCE_DATATYPE_MEMBER_COMMON_ID_UUID;
        }
        #endregion

        #region getTest_HMIDEVICE_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 13742126344913406609\n"
        private static UUID RESOURCE_HMIDEVICE_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(13742126344913406609).Build();

        public static UUID getTest_HMIDEVICE_COMMON_ID()
        {
            return RESOURCE_HMIDEVICE_COMMON_ID_UUID;
        }
        #endregion

        #region getTest_DATATYPE_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 13742126344913406610\n"
        private static UUID RESOURCE_DATATYPE_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(13742126344913406610).Build();

        public static UUID getTest_DATATYPE_COMMON_ID()
        {
            return RESOURCE_DATATYPE_COMMON_ID_UUID;
        }
        #endregion
        
        #region getTest_DATALOG_COMMON_ID
        // Artificial COMMON_ID
        // "hi: 4292042260990610512\nlo: 13742126344913406611\n"
        private static UUID RESOURCE_DATALOG_COMMON_ID_UUID = UUID.CreateBuilder().SetHi(4292042260990610512).SetLo(13742126344913406611).Build();

        public static UUID getTest_DATALOG_COMMON_ID()
        {
            return RESOURCE_DATALOG_COMMON_ID_UUID;
        }
        #endregion
    }
}
