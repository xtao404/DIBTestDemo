﻿/*************************************************************************************     
   Copyright © 2016 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.DIBQuery
{
    class DIBQueryCommandForDevices : DIBQueryCommandForViewe
    {
        #region "Creation/Init"

        public DIBQueryCommandForDevices(QueryRequest.CreateBuilder queryRequestBuilder)
            : base( queryRequestBuilder)
        {
            CacheQueryResults = true;
        }

        #endregion

        #region "Base Overrides" 

        public override PredefinedQueryType QueryType()
        {
            return PredefinedQueryType.Devices;
        }

        public override QueryConditionConfig GenerateQueryCondition(IClientDataServices cds)
        {
            DIBClientManagerForViewe manager = cds.DibClientManager as DIBClientManagerForViewe;

            //exclude HMI devices
            if (!cds.DataContext.IsHMIDeviceTypeIncluded())
            {
                //ASSUMPTION: since we do not allow searching with type based data context we can
                //safely set the create a new query condition.  Also if we add a new device type 
                //the assumption of searching for devices of type controller would break. Right now we
                //only have two types of Devices; HMIDevice and Controller, so by adding this query 
                //condition, we implicitly exclude HMIDevice. Once more devices are added, e.g. AOG, this 
                //will break.
                QueryConditionConfig queryCondition = new QueryConditionConfig.CreateBuilder()
                    .AddConditionItem(new QueryConditionItem.CreateBuilder()
                        .SetIdentifier(DIResource.DI_COMMON_IDENTIFIER_TYPE)
                        .SetValue(TypeIdentifiers.getResourceType_Controller().ToString())
                        .SetLogicOperator(LogicOperatorType.AND)
                        .Build())
                    .Build();
                return queryCondition;

            }
            else if (manager.IsAOGPropertyBrowser())
            {
                QueryConditionConfig queryCondition = new QueryConditionConfig.CreateBuilder()
                .AddConditionItem(new QueryConditionItem.CreateBuilder()
                    .SetIdentifier(DIResource.DI_COMMON_IDENTIFIER_DISPLAY_NAME)
                    .SetValue(DIResource.DI_COMMON_LOCAL_HMIDEVICE_DISPLAY_NAME)
                    .SetIsExactMatch(true)
                    .Build())
                .Build();
                return queryCondition;
            }

            return base.GenerateQueryCondition(cds);
        }

        #endregion
    }
}
