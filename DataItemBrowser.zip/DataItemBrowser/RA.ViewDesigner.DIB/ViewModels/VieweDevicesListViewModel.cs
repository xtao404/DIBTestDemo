﻿using System;
using System.ComponentModel;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System.Windows;
using RockwellAutomation.UI.CommonControls;
using System.Collections.ObjectModel;
using RockwellAutomation.UI.Models;
using System.Windows.Input;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.ViewModels
{
    /// <summary>
    /// View model supporting the <c>DIBListView</c>
    /// </summary>
    public class VieweDevicesListViewModel : DIBListViewModel
    {

        #region Constructor

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">reference to the DataItemBrowser view model</param>
        public VieweDevicesListViewModel(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
        }

        #endregion

        #region Overrides

        override public bool isActive()
        {
            return this._dibViewModel.IsListView();
        }

        /// <summary>
        /// handler for adding or removing the search crumb
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        override protected void DataItemBrowserViewModel_SearchBreadCrumbChanged(object sender, PropertyChangedEventArgs e)
        {
            //Do nothing
        }

        override protected DIBListViewItem CreateDIBViewDataItemFrom(DataItemBase di)
        {
            DIBListViewItem data = new DIBListViewItem(di);
            data.IsSelected = false;
         
            if (di == DIResource.DIB_TagsAndProps)
            {
                data.AutomationID = DIResource.DI_COMMON_RESOURCETYPE_TAGSPROPERTIES;
                // Change the display name of this item depending on wether our view is for a controller or device
                if (this._dibViewModel.DataView.IsControllerView())
                    DIResource.DIB_TagsAndProps.CommonName = DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGSPROPERTIES;
                else
                    DIResource.DIB_TagsAndProps.CommonName = DIResource.DI_COMMON_RESOURCETYPE_HMITAGSPROPERTIES;
                // Make sure to update the name on list view item as well
                data.Name = DIResource.DIB_TagsAndProps.CommonName;
            }
            return data;
        }

        #endregion

        #region Events

        ///<summary>
        /// This is the drillIn performed from the search view
        /// If we're drilling in from a query based search view, we need to add breadcrumbs based on what's clicked
        ///<returns>return true if callback used </returns>
        ///</summary>
        /// <param name="item">The item to drill into</param>      
        private bool DrillInFromSearchViewUsingCallback(DataItemBase item)
        {
            _dibViewModel.IsQueryBasedSearchActive = false;
            //If the callback is being used, return since we'll run the actual drill in command
            // from the callback itself
            bool usedCallback = _dibViewModel.PopulatePathFromDataItemPath(item, (error) =>
            {
                if (String.IsNullOrEmpty(error))
                {
                    this.DrillInCommand.Execute(item);
                }
            });

            return usedCallback;
        }

        #endregion

        #region Commands

        /// <summary>
        /// Creates the path which specifies the Controller to drill into and then navigates into it.
        /// </summary>
        public override SimpleCommand CreateDrillInCommand()
        {
            return new SimpleCommand()
            {
                ExecuteDelegate = x =>
                {
                    DIBListViewItem itemViewData = x as DIBListViewItem;
                    if (itemViewData == null) return;
                    DataItemBase item = itemViewData.DataItem;

                    // If we're drilling in from a query based search view, we need to add breadcrumbs based on what's clicked
                    if (IsQueryBasedSearchActive)
                    {
                        //if the callback was not used then navigate to the item
                        if (DrillInFromSearchViewUsingCallback(item))
                            return;
                    }

                    //Now proceed with the "normal" drill in logic for the passed data item
                    if (item != null &&
                        ((_dibViewModel.Path.Forward != null) &&
                            (_dibViewModel.Path.Forward.DisplayName == item.CommonName)
                        ))
                        _dibViewModel.Path.SetActive(_dibViewModel.Path.Forward);
                    else
                    {
                        IPathElement newPE = PathElementFactory.Instance().CreatePathElement(item);
                        _dibViewModel.Path.Add(newPE);
                    }
                    _dibViewModel.Navigate(item);
                }
            };
        }

        #endregion



    }
}
