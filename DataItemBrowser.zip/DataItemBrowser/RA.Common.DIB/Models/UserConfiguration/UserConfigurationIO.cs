using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using RockwellAutomation.Logging;
using System.Reflection;

namespace RockwellAutomation.UI.UserConfiguration
{
    public static class UserWindowSize
    {
        public const int DefaultWindowWidth = 415;
        public const int DefaultWindowHeight = 300;
    }

    public static class UserConfigurationIO
    {
        // set a max persistable column width to avoid the possibility of a very large width was persisted and there is no way to shrink the column width.
        private static int _maxColumnPersistWidth = 2000;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Rockwell.Design", "RA0010:ExceptionsDoNotUseANakedRethrow")]
        public static Configuration ConfigurationData
        {
            get
            {
                try
                {
                    // Get the roaming configuration that applies to the current user.
                    Configuration roamingConfig = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
                
                    // Map the roaming configuration file (user.config). This
                    // enables the application to access the configuration file using the System.Configuration.Configuration class

                    // Note: Must use PerUserRoamingAndLocal and the following path assignments to prevent the <System.Web> element
                    // from being created in the user.config file.  If <system.web> exists TAF has problems.
                    ExeConfigurationFileMap configFileMap = new ExeConfigurationFileMap();
                    configFileMap.ExeConfigFilename = roamingConfig.FilePath;
                    configFileMap.LocalUserConfigFilename = roamingConfig.FilePath;
                    configFileMap.RoamingUserConfigFilename = roamingConfig.FilePath;

                    // Get the mapped configuration file
                    Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configFileMap, ConfigurationUserLevel.PerUserRoamingAndLocal);
                    return config;
                }
                catch (System.Configuration.ConfigurationErrorsException e)
                {
                    LogWrapper.LogException("UserConfigurationIO.ConfigurationData ConfigurationErrorsException Error:", e);
                    // We dont want to swallow this exception. Allow it to propogate to whoever is calling
                    throw;
                }
            }
        }

        /// <summary>
        /// Read the WindowSection which contains the size of the window
        /// </summary>
        /// <param name="height">The window height</param>
        /// <param name="width">The window width</param>
        public static void ReadWindowSize(ref int height, ref int width)
        {
            Initialize();

            // In case of exception
            height = UserWindowSize.DefaultWindowHeight;
            width = UserWindowSize.DefaultWindowWidth;

            string sectionName = "WindowSection";
            WindowSection windowSection = null;

            try
            {
                // Get the mapped configuration file
                Configuration config = ConfigurationData;

                windowSection = (WindowSection)config.GetSection(sectionName);

                if (windowSection == null)
                {
                    LogWrapper.DibGeneralLog.Error("UserConfigurationIO.ReadWindowSize: user.config must be created first");    
                    return;
                }

                if (windowSection.Size.DIBWindow_Height >= height)
                    height = windowSection.Size.DIBWindow_Height;
                if (windowSection.Size.DIBWindow_Width >= width)
                    width = windowSection.Size.DIBWindow_Width;
            }
            catch (System.Exception e)
            {
                // This maybe a ConfigurationErrorsException.
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                LogWrapper.LogException("UserConfigurationIO.ReadWindowSize Error:", e);
            }
        }

        /// <summary>
        /// Read the Column Configuration from user.config
        /// </summary>
        /// <returns>The column Configuration as a dictionary</returns>
        public static Dictionary<string, ColumnConfig> ReadColumnConfiguration()
        {
            Initialize();

            Dictionary<string, ColumnConfig> columnConfigs = new Dictionary<string, ColumnConfig>();

            string sectionName = "ColumnsSection";
            ColumnsSection columnsSection = null;

            try
            {
                // Get the mapped configuration file
                Configuration config = ConfigurationData;

                columnsSection = (ColumnsSection)config.GetSection(sectionName);

                if (columnsSection == null)
                {
                    LogWrapper.DibGeneralLog.Error("UserConfigurationIO.ReadColumnConfiguration: user.config must be created first"); 
                    return columnConfigs;
                }

                ColumnElement column = null;
                ColumnConfig columnConfig = null;
                for (int i = 0; i < columnsSection.ColumnsElement.Count; i++)
                {
                    column = columnsSection.ColumnsElement[i];
                    columnConfig = new ColumnConfig();
                    columnConfig.FieldName = column.FieldName;
                    columnConfig.Visible = (string.Compare(column.Visible, "true", true) == 0) ? true : false;
                    columnConfig.VisiblePosition = int.Parse(column.VisiblePosition);
                    columnConfig.CurrentWidth = double.Parse(column.CurrentWidth);
                    if (columnConfig.CurrentWidth > _maxColumnPersistWidth)
                        columnConfig.CurrentWidth = _maxColumnPersistWidth;
                    columnConfig.SortDirection = (Client.Services.Query.SortDirection)int.Parse(column.SortDirection);
                    columnConfig.SortIndex = int.Parse(column.SortIndex);

                    // Following are not persisted
                    columnConfig.MinWidth = 0;
                    columnConfig.Title = String.Empty;
                    columnConfig.Wrapping = false;
                    columnConfig.ShowInColumnChooser = false;

                    columnConfigs.Add(column.Key, columnConfig);
                }

            }
            catch (System.Exception e)
            {
                // This maybe a ConfigurationErrorsException
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                LogWrapper.LogException("UserConfigurationIO.ReadColumnConfiguration error:", e);
                Initialize();
            }

            return columnConfigs;
        }

        /// <summary>
        /// Save the Column Elements to the user.config file.
        /// </summary>
        /// <param name="userChanges">A dictionary containing the user changes to be applied to the user.config file.</param>
        public static void SaveColumnConfiguration(Dictionary<string, ColumnConfig> userChanges)
        {
            Initialize();

            string sectionName = "ColumnsSection";
            ColumnsSection columnsSection = null;

            try
            {
                // Get the mapped configuration file
                Configuration config = ConfigurationData;

                columnsSection = (ColumnsSection)config.GetSection(sectionName);

                if (columnsSection == null)
                {
                    LogWrapper.DibGeneralLog.Error("UserConfigurationIO.SaveColumnConfiguration: user.config must be created first");
                    return;
                }

                ColumnElement column = null;
                foreach (KeyValuePair<string, ColumnConfig> userChange in userChanges)
                {
                    ColumnConfig cfg = userChange.Value;

                    // Does the configuration information already exist?
                    column = columnsSection.ColumnsElement[userChange.Key];
                    if (column == null)
                    {
                        // create configuration information
                        column = new ColumnElement(userChange.Key, cfg.FieldName, cfg.Visible, cfg.VisiblePosition, cfg.CurrentWidth, cfg.SortDirection, cfg.SortIndex);
                        columnsSection.ColumnsElement.Add(column);
                    }
                    else
                    {
                        // update the configuration information
                        column.FieldName = cfg.FieldName;
                        column.Visible = cfg.Visible == true ? "true" : "false";
                        column.VisiblePosition = cfg.VisiblePosition.ToString();
                        if (cfg.CurrentWidth > _maxColumnPersistWidth)
                            cfg.CurrentWidth = _maxColumnPersistWidth;
                        column.CurrentWidth = cfg.CurrentWidth.ToString();
                        column.SortDirection = cfg.SortDirection.ToString();
                        column.SortIndex = cfg.SortIndex.ToString();
                    }

                }
                config.Save(ConfigurationSaveMode.Full, true);

                // Force a reload of the changed section. This makes the new values available for reading.
                ConfigurationManager.RefreshSection(sectionName);
            }
            catch (System.Exception e)
            {
                // This maybe a ConfigurationErrorsException.
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                LogWrapper.LogException("UserConfigurationIO.SaveColumnConfiguration Error:", e);
            }
        }

        /// <summary>
        /// Save the window's size in the user.config file
        /// </summary>
        /// <param name="height">The window height</param>
        /// <param name="width">The window width</param>
        public static void SaveWindowSize(int height, int width)
        {
            Initialize();

            string sectionName = "WindowSection";
            WindowSection windowSection = null;

            try
            {
                // Get the mapped configuration file
                Configuration config = ConfigurationData;

                windowSection = (WindowSection)config.GetSection(sectionName);

                if (windowSection == null)
                {
                    LogWrapper.DibGeneralLog.Error("UserConfigurationIO.SaveWindowSize: user.config must be created first");
                    return;
                }

                windowSection.Size.DIBWindow_Height = height;
                windowSection.Size.DIBWindow_Width = width;
                config.Save(ConfigurationSaveMode.Full, true);

                // Force a reload of the changed section. This makes the new values available for reading.
                ConfigurationManager.RefreshSection(sectionName);
            }
            catch (System.Exception e)
            {
                // This maybe a ConfigurationErrorsException.
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                LogWrapper.LogException("UserConfigurationIO.SaveWindowSize Error: ", e);
            }

        }

        /// <summary>
        /// Create the WindowSection element, which contains the elements describing the window.
        /// </summary>
        /// <returns>The results of the windows section creation</returns>
        private static bool CreateWindowSection()
        {
            bool results = true;

            try
            {
                Configuration config = ConfigurationData;

                // Define the custom section to add to the configuration file.
                string sectionName = "WindowSection";
                WindowSection windowSection = null;
                windowSection = (WindowSection)config.GetSection(sectionName);

                if (windowSection == null)
                {
                    windowSection = new WindowSection();

                    // Define where in the configuration file hierarchy the associated 
                    // configuration section can be declared.
                    // MachineToLocalUser indicates the ConfigurationSection can be defined in the Machine.config file, 
                    // in the Exe.config file in the client application directory, 
                    // or in the User.config file in the roaming user directory. 
                    windowSection.SectionInformation.AllowExeDefinition = ConfigurationAllowExeDefinition.MachineToLocalUser;

                    // Allow the configuration section to be overridden by other configuration files.
                    // Setting this to true minimizes the config file.
                    windowSection.SectionInformation.AllowOverride = true;

                    // Force the section to be saved.
                    windowSection.SectionInformation.ForceSave = true;

                    // Add configuration information to the configuration file.
                    config.Sections.Add(sectionName, windowSection);

                    // Their are 3 values for ConfigurationSaveMode enumeration
                    // "Full", "Modified", and "Minimal"
                    // Must use full so both sections are written out when one is changed.
                    config.Save(ConfigurationSaveMode.Full, true);

                    // Force a reload of the changed section. This makes the new values available for reading.
                    ConfigurationManager.RefreshSection(sectionName);
                }
            }
            catch (System.Exception e)
            {
                // This maybe a ConfigurationErrorsException.
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                LogWrapper.LogException("UserConfigurationIO.CreateWindowSection Error: ", e);
                results = false;
            }

            return results;
        }

        /// <summary>
        /// Create the CreateColumnsSection element, which contains all the information about columns.
        /// </summary>
        /// <returns>The results of the Columns section creation</returns>
        private static bool CreateColumnsSection()
        {
            bool results = true;

            try
            {
                Configuration config = ConfigurationData;

                // Define the custom section to add to the configuration file.
                string sectionName = "ColumnsSection";
                ColumnsSection columnsSection = null;
                columnsSection = (ColumnsSection)config.GetSection(sectionName);
                if (columnsSection == null)
                {
                    // Create a custom configuration section.
                    columnsSection = new ColumnsSection();

                    // Define where in the configuration file hierarchy the associated 
                    // configuration section can be declared.
                    // MachineToLocalUser indicates the ConfigurationSection can be defined in the Machine.config file, 
                    // in the Exe.config file in the client application directory, 
                    // or in the User.config file in the roaming user directory. 
                    columnsSection.SectionInformation.AllowExeDefinition = ConfigurationAllowExeDefinition.MachineToLocalUser;

                    // Allow the configuration section to be overridden by other configuration files.
                    // Setting this to true minimizes the config file.
                    columnsSection.SectionInformation.AllowOverride = true;

                    // Force the section to be saved.
                    columnsSection.SectionInformation.ForceSave = true;

                    // Add configuration information to the configuration file.
                    config.Sections.Add(sectionName, columnsSection);

                    // Their are 3 values for ConfigurationSaveMode enumeration
                    // "Full", "Modified", and "Minimal"
                    // Must use full so both sections are written out when one is changed.
                    config.Save(ConfigurationSaveMode.Full, true);

                    // Force a reload of the changed section. This makes the new values available for reading.
                    ConfigurationManager.RefreshSection(sectionName);
                }
            }
            catch (System.Exception e)
            {
                // This maybe a ConfigurationErrorsException.
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                LogWrapper.LogException("UserConfigurationIO.CreateColumnsSection Error: ", e);
                results = false;
            }

            return results;
        }

        /// <summary>
        /// Delete user's user.config file.  If an exception occurs whenever the user.config is being changed, method Initialize will invoke this method.  The
        /// user's configuration information will be lost but will be reinitialized through normal DIB processing.  If for some reason the user.config file can
        /// not be deleted, no user configuration will be saved between DIB invocations, but the DIB can still proceed to function.
        /// Situations where the user.config may need to be deleted:
        ///     1) File exists but is empty
        ///     2) File exists but the xml structure is invalid (beginning and ending tags don't matched)
        ///     3) Invalid version number - version number within file does not agree with version number within the path.
        ///     4) ...
        /// </summary>
        /// <param name="errMsg">Results message indicating the status of the operation "worked" indicates success, otherwise, the error message.  Only used for unit tests.</param>
        /// <returns>True if file deleted or it doesn't exist, otherwise False returned.</returns>
        public static bool DeleteUserConfigFile(ref string errMsg)
        {
            bool results = true;
            errMsg = "Worked";
            string filename = String.Empty;

            Configuration roamingConfig = null;
            // Get the roaming configuration that applies to the current user.
            try
            {
                roamingConfig = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.PerUserRoamingAndLocal);
                filename = roamingConfig.FilePath;
            }
            catch (ConfigurationErrorsException e)
            {
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                LogWrapper.LogException(MethodBase.GetCurrentMethod().ToString(), e);
                filename = e.Filename;
            }

            try
            {
                if (!File.Exists(filename))
                    return true;

                File.Delete(filename);
            }
            catch (IOException fileIO)
            {
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                // Path invalid - DirectoryNotFoundException
                // File in use
                errMsg = fileIO.Message;
                LogWrapper.LogException("UserConfigurationIO.DeleteUserConfigFile Error: ", fileIO);
                results = false;
            }
            catch (UnauthorizedAccessException fileIO)
            {
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                // UnauthorizedAccessException - path is a directory, read-only file, caller does not have the required permission
                errMsg = fileIO.Message;
                LogWrapper.LogException("UserConfigurationIO.DeleteUserConfigFile Error: ", fileIO);
                results = false;
            }
            catch (System.Exception e)
            {
                // Swallow excetion here. We dont want users of the DIB to be aware of any configurationIO errors.
                errMsg = e.Message;
                LogWrapper.LogException("UserConfiguration.DeleteUserConfigFile Error: ", e);
                results = false;
            }

            // If the file was successfully deleted record deletion.
            // The exception referred to does not refer to exceptions caught in this method.
            if (results)
            {
                IOException IOe = new IOException("User.Config file deleted because of previoulsy recorded exception.  User configuration will return to default values.");
                LogWrapper.LogException(System.Reflection.MethodBase.GetCurrentMethod().ToString() + ": UserConfigurationIO.DeleteUserConfigFile. File " + filename + " successfully deleted.", IOe);
            }

            return results;
        }


        /// <summary>
        /// Verify the user.config file exists. If it does not exist this process will create it.
        /// If it does exist make sure the version within the file is correct. If the version is incorrect delete the current
        /// user.config and let the process create a new one.
        /// </summary>
        private static void Initialize()
        {
            string errMsg = String.Empty;
            bool success = false;
            int loop = 0;

            // Validate that the user.config file exists with its default 2 sections
            // If an error occurs, delete the file and try the scenario again.
            do
            {
                loop++;

                // One of the following could fail if the version of the user.config file contained
                // in the file does not match the version of the container.
                if (CreateWindowSection())
                {
                    if (CreateColumnsSection())
                    {
                        success = true;
                    }
                }

                if ((!success) && (loop == 1))
                {
                    // The first time through the loop delete user.config if
                    // the Window or Columns section do not already exist or
                    // cannot be created.  If the deletion fails, errMsg is recorded in DeleteUserConfigFile.
                    if (!DeleteUserConfigFile(ref errMsg))
                    {
                        // If we can not delete the file then there is no sense in repeating the loop.
                        success = true;
                    }
                }
            } while ((!success) && (loop < 2));
        }

    }
}
