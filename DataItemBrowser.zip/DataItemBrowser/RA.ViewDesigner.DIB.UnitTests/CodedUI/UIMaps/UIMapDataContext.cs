﻿

namespace DataItemBrowserUT.CodedUI.UIMaps.UIMapDataContextClasses
{
    using System;
    using System.Drawing;
    using System.Text.RegularExpressions;
    using System.Windows.Input;
    using Microsoft.VisualStudio.TestTools.UITest.Extension;
    using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
    using Keyboard = Microsoft.VisualStudio.TestTools.UITesting.Keyboard;
    using Mouse = Microsoft.VisualStudio.TestTools.UITesting.Mouse;
    using MouseButtons = System.Windows.Forms.MouseButtons;
    using Microsoft.VisualStudio.TestTools.UITesting.WpfControls;
    using System.Collections.Generic;
    using System.CodeDom.Compiler;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UnitTesting;


    public partial class UIMapDataContext
    {

        /// <summary>
        /// DIB_DataContext_DT_Filter_FilterValue - Use 'DIB_DataContext_DT_Filter_FilterValueParams' to pass parameters into this method.
        /// <param name="filterValue">The value that should be filtered on.</param>
        /// </summary>
        public void DIB_DataContext_DT_Filter_FilterValue(string filterValue)
        {
            #region Variable Declarations
            WpfToggleButton uIControllerUIExpandCoToggleButton = this.UICommonTagPopupTestHoWindow.UIControllerUIExpandCoToggleButton;
            WpfEdit uITxFilterTypeEdit = this.UICommonTagPopupTestHoWindow.UIExcludeTypeTabTabList.UIPathBasedTabPage.UITxFilterTypeEdit;
            WpfEdit uITxFilterValueEdit = this.UICommonTagPopupTestHoWindow.UIExcludeTypeTabTabList.UIPathBasedTabPage.UITxFilterValueEdit;
            #endregion

            // Set to 'Pressed' state 'ControllerUI.ExpandCollapseButton' toggle button
            uIControllerUIExpandCoToggleButton.Pressed = this.DIB_DataContext_DT_Filter_FilterValueParams.UIControllerUIExpandCoToggleButtonPressed;

            // Type 'dt' in 'txFilterType' text box
            uITxFilterTypeEdit.Text = this.DIB_DataContext_DT_Filter_FilterValueParams.UITxFilterTypeEditText;

            // Type in 'txFilterValue' text box
            uITxFilterValueEdit.Text = filterValue;
        }

        /// <summary>
        /// DIB_Assert_BreadCrumb_DataLogs - Use 'DIB_Assert_BreadCrumb_DataLogsExpectedValues' to pass parameters into this method.
        /// NOTE: the UITestControlCollection will return a minimum of 3 items. There is a LineUp and LineDown item that are not 
        /// menu items in the list. 
        /// Example: A context menu with DataLogs will have 3 items come back in the collection, Count = 3
        /// Name = Data Logs
        /// FriendlyName = Data Logs
        /// ClassName = Uia.MenuItem
        /// Count = 3
        /// Name = 
        /// FriendlyName = LineUp
        /// ClassName = Uia.RepeatButton
        /// Count = 3
        /// Name = 
        /// FriendlyName = LineDown
        /// ClassName = Uia.RepeatButton
        /// </summary>
        public void DIB_Assert_BreadCrumb_DataLogs()
        {
            #region Variable Declarations
            UITestControlCollection contextMenuChildren = this.UIDataItemBrowserHostWWindow.UITextContextMenuMenu.GetChildren();
            List<UITestControl> contextChildren = new List<UITestControl>();

            //Console.WriteLine("Breadcrumb context menu contains...\n");
            for (int i = 0; i < contextMenuChildren.Count; i++)
            {
                //Console.WriteLine("\n Count = " + contextMenuChildren.Count);
                //Console.WriteLine("\n Name = " + contextMenuChildren[i].Name);
                //Console.WriteLine("\n FriendlyName = " + contextMenuChildren[i].FriendlyName);
                //Console.WriteLine("\n ClassName = " + contextMenuChildren[i].ClassName);
                if (contextMenuChildren[i].ClassName.Equals("Uia.MenuItem"))
                    contextChildren.Add(contextMenuChildren[i]);
            }
            #endregion
            Assert.IsTrue(contextChildren.Count == 1, "There should only be one item in the breadcrumb context menu. Count = " + contextMenuChildren.Count);
            Assert.IsTrue(contextChildren[0].Name.Equals("Data Logs"), "Name is not Data Logs, name = " + contextMenuChildren[0].Name);

        }

        public virtual DIB_Assert_BreadCrumb_DataLogsExpectedValues DIB_Assert_BreadCrumb_DataLogsExpectedValues
        {
            get
            {
                if ((this.mDIB_Assert_BreadCrumb_DataLogsExpectedValues == null))
                {
                    this.mDIB_Assert_BreadCrumb_DataLogsExpectedValues = new DIB_Assert_BreadCrumb_DataLogsExpectedValues();
                }
                return this.mDIB_Assert_BreadCrumb_DataLogsExpectedValues;
            }
        }

        private DIB_Assert_BreadCrumb_DataLogsExpectedValues mDIB_Assert_BreadCrumb_DataLogsExpectedValues;

        /// <summary>
        /// DIB_Assert_BreadCrumb_Program_ContextMenu - Use 'DIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues' to pass parameters into this method.
        /// </summary>
        public void DIB_Assert_BreadCrumb_Program_ContextMenu()
        {
            #region Variable Declarations
            UITestControlCollection contextMenuChildren = this.UIDataItemBrowserHostWWindow.UITextContextMenuMenu.GetChildren();
            List<UITestControl> contextChildren = new List<UITestControl>();

            //Console.WriteLine("Breadcrumb context menu contains...\n");
            for (int i = 0; i < contextMenuChildren.Count; i++)
            {
                //Console.WriteLine("\n Count = " + contextMenuChildren.Count);
                //Console.WriteLine("\n Name = " + contextMenuChildren[i].Name);
                //Console.WriteLine("\n FriendlyName = " + contextMenuChildren[i].FriendlyName);
                //Console.WriteLine("\n ClassName = " + contextMenuChildren[i].ClassName);
                if (contextMenuChildren[i].ClassName.Equals("Uia.MenuItem"))
                    contextChildren.Add(contextMenuChildren[i]);
            }
            #endregion

            Assert.IsTrue(contextChildren.Count == 1, "There should only be one item in the breadcrumb context menu. Count = " + contextMenuChildren.Count);
            Assert.IsTrue(contextChildren[0].Name.Equals("Program_3"), "Name is not Programs, name = " + contextMenuChildren[0].Name);

        }

        public virtual DIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues DIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues
        {
            get
            {
                if ((this.mDIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues == null))
                {
                    this.mDIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues = new DIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues();
                }
                return this.mDIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues;
            }
        }

        private DIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues mDIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues;



        public virtual DIB_DataContext_DT_Filter_FilterValueParams DIB_DataContext_DT_Filter_FilterValueParams
        {
            get
            {
                if ((this.mDIB_DataContext_DT_Filter_FilterValueParams == null))
                {
                    this.mDIB_DataContext_DT_Filter_FilterValueParams = new DIB_DataContext_DT_Filter_FilterValueParams();
                }
                return this.mDIB_DataContext_DT_Filter_FilterValueParams;
            }
        }

        private DIB_DataContext_DT_Filter_FilterValueParams mDIB_DataContext_DT_Filter_FilterValueParams;



        /// <summary>
        /// DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogs - Use 'DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams' to pass parameters into this method.
        /// </summary>
        public void DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogs()
        {
            #region Variable Declarations
            WpfToggleButton uIControllerUIExpandCoToggleButton = this.UICommonTagPopupTestHoWindow.UIControllerUIExpandCoToggleButton;
            //WpfText uITypeBasedText = this.UICommonTagPopupTestHoWindow.UIExcludeTypeTabTabList.UITypeBasedTabPage.UITypeBasedText;
            UITypeBasedTabPage uITypeBasedTabPage = this.UICommonTagPopupTestHoWindow.UIExcludeTypeTabTabList.UITypeBasedTabPage;

            WpfComboBox uICbExcludeAllChildrenComboBox = this.UICommonTagPopupTestHoWindow.UIExcludeTypeTabTabList.UITypeBasedTabPage.UICbExcludeAllChildrenComboBox;
            WpfComboBox uICbExcludeAllOfTypeComboBox = this.UICommonTagPopupTestHoWindow.UIExcludeTypeTabTabList.UITypeBasedTabPage.UICbExcludeAllOfTypeComboBox;
            WpfComboBox uICbIncludeAllOfTypeComboBox = this.UICommonTagPopupTestHoWindow.UIExcludeTypeTabTabList.UITypeBasedTabPage.UICbIncludeAllOfTypeComboBox;
            #endregion

            // Set to 'Pressed' state 'ControllerUI.ExpandCollapseButton' toggle button
            uIControllerUIExpandCoToggleButton.Pressed = this.DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams.UIControllerUIExpandCoToggleButtonPressed;

            // Click 'Type Based' label
            //Mouse.Click(uITypeBasedText, new Point(45, 5));
            Mouse.Click(uITypeBasedTabPage, new Point(45, 5));

            // Select 'Controller' in 'cbExcludeAllChildrenOfType' combo box
            uICbExcludeAllChildrenComboBox.SelectedItem = this.DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams.UICbExcludeAllChildrenComboBoxSelectedItem;

            // Select 'HMIDevice' in 'cbExcludeAllOfType' combo box
            uICbExcludeAllOfTypeComboBox.SelectedItem = this.DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams.UICbExcludeAllOfTypeComboBoxSelectedItem;

            // Select 'DataLogs' in 'cbIncludeAllOfType' combo box
            uICbIncludeAllOfTypeComboBox.SelectedItem = this.DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams.UICbIncludeAllOfTypeComboBoxSelectedItem;
        }

        public virtual DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams
        {
            get
            {
                if ((this.mDIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams == null))
                {
                    this.mDIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams = new DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams();
                }
                return this.mDIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams;
            }
        }

        private DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams mDIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams;

        /// <summary>
        /// DIB_ESC_From_DeviceView - Use 'DIB_ESC_From_DeviceViewParams' to pass parameters into this method.
        /// </summary>
        public void DIB_ESC_From_DeviceView()
        {
            #region Variable Declarations
            WpfTree uIDataSourcesViewTree = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataSourcesViewTree;
            //WpfTreeItem uIControllersTreeItem = this.UIDataItemBrowserHostWWindow.UIDataItemBrowserContrCustom.UIDataSourcesViewTree.UIControllersTreeItem;
            #endregion

            // Click 'DataSourcesView' tree
            Mouse.Click(uIDataSourcesViewTree, new Point(290, 175));

            // Type '{Escape}' in 'Controllers' tree item
            Keyboard.SendKeys(this.DIB_ESC_From_DeviceViewParams.UIControllersTreeItemSendKeys, ModifierKeys.None);
        }

        public virtual DIB_ESC_From_DeviceViewParams DIB_ESC_From_DeviceViewParams
        {
            get
            {
                if ((this.mDIB_ESC_From_DeviceViewParams == null))
                {
                    this.mDIB_ESC_From_DeviceViewParams = new DIB_ESC_From_DeviceViewParams();
                }
                return this.mDIB_ESC_From_DeviceViewParams;
            }
        }

        private DIB_ESC_From_DeviceViewParams mDIB_ESC_From_DeviceViewParams;
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_Assert_BreadCrumb_DataLogs'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_Assert_BreadCrumb_DataLogsExpectedValues
    {

        #region Fields
        /// <summary>
        /// Verify that 'Data Logs' menu item's property 'HasFocus' equals 'True'
        /// </summary>
        public bool UIDataLogsMenuItemHasFocus = true;
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_Assert_BreadCrumb_Program_ContextMenu'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_Assert_BreadCrumb_Program_ContextMenuExpectedValues
    {

        #region Fields
        /// <summary>
        /// Verify that 'TextContextMenu' popup menu's property 'Enabled' equals 'True'
        /// </summary>
        public bool UITextContextMenuMenuEnabled = true;
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_DataContext_DT_Filter_FilterValue'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.1")]
    public class DIB_DataContext_DT_Filter_FilterValueParams
    {

        #region Fields
        /// <summary>
        /// Set to 'Pressed' state 'ControllerUI.ExpandCollapseButton' toggle button
        /// </summary>
        public bool UIControllerUIExpandCoToggleButtonPressed = true;

        /// <summary>
        /// Type 'dt' in 'txFilterType' text box
        /// </summary>
        public string UITxFilterTypeEditText = "dt";

        /// <summary>
        /// Type 'BOOL[32]' in 'txFilterValue' text box
        /// </summary>
        public string UITxFilterValueEditText = "BOOL[32]";
        #endregion
    }

    /// <summary>
    /// Parameters to be passed into 'DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogs'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.415")]
    public class DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogsParams
    {

        #region Fields
        /// <summary>
        /// Set to 'Pressed' state 'ControllerUI.ExpandCollapseButton' toggle button
        /// </summary>
        public bool UIControllerUIExpandCoToggleButtonPressed = true;

        /// <summary>
        /// Select 'Controller' in 'cbExcludeAllChildrenOfType' combo box
        /// </summary>
        public string UICbExcludeAllChildrenComboBoxSelectedItem = "Controller";

        /// <summary>
        /// Select 'HMIDevice' in 'cbExcludeAllOfType' combo box
        /// </summary>
        public string UICbExcludeAllOfTypeComboBoxSelectedItem = "HMIDevice";

        /// <summary>
        /// Select 'DataLogs' in 'cbIncludeAllOfType' combo box
        /// </summary>
        public string UICbIncludeAllOfTypeComboBoxSelectedItem = "DataLogs";
        #endregion
    }
    /// <summary>
    /// Parameters to be passed into 'DIB_ESC_From_DeviceView'
    /// </summary>
    [GeneratedCode("Coded UITest Builder", "10.0.40219.415")]
    public class DIB_ESC_From_DeviceViewParams
    {

        #region Fields
        /// <summary>
        /// Type '{Escape}' in 'Controllers' tree item
        /// </summary>
        public string UIControllersTreeItemSendKeys = "{Escape}";
        #endregion
}
}
