/*************************************************************************************
                                                                     
   ViewE VieweTagGridViewModelTest Class
   Copyright � 2009-2010 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using RockwellAutomation.UI.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel;
using System.Collections.Generic;
using Xceed.Wpf.DataGrid;
using RockwellAutomation.UI.Models;
using System.Windows;
using RockwellAutomation.UI;
using System.Collections.ObjectModel;
using System.Threading;
using RockwellAutomation.UI.UserConfiguration;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using System;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.WindowsControl.DIBClient;

#endregion

namespace DataItemBrowserUT
{    
    /// <summary>
    ///This is a test class for VieweTagGridViewModelTest and is intended
    ///to contain all VieweTagGridViewModelTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DataGridViewModelTest
    {
        #region static members

        private static DataItemBrowserViewModel target;

        #endregion

        #region Additional test attributes

        [ClassInitialize()]
        public static void VieweTagGridViewModelTestClassInit(TestContext testContext)
        {
            // because these unit tests have the potential to call on the Xceed 
            // data grid, we need to make sure we set the license key so the 
            // unit tests don't get stuck with a license key exception.
            XceedDeploymentLicense.SetLicense();
        }

        [TestInitialize()]
        public void VieweTagGridViewModelTestInit()
        {

            // only go on if the view model is null, or we are changing data providers
            if ((target == null))
            {
                BackgroundWorkerSyncContextHelper.DoTests(() =>
                {
                    string project = "00000000000011110000000000002222";
                    UUID packageContext = UUID.CreateBuilder().SetHi(0UL).SetLo(0UL).Build();
                    UUID projectContext = UUID.CreateBuilder().SetHi(HiWord(project)).SetLo(LoWord(project)).Build();
                    DIBClientManagerForViewe.Instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, projectContext, packageContext);

                    target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG);
                    DIBQueryConnection.SetResourceServiceType(true);
                    target.Initialize(null, string.Empty);
                });
            }
        }

        /// <summary>
        /// Use TestCleanup to run code after each test has run
        /// </summary>
        [TestCleanup()]
        public void MyTestCleanup()
        {
            DIBClientManagerForViewe.Instance.Shutdown();
        }
        

        //Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            target = null;        
        }
        
        public ulong HiWord( string project )
        {
            return Convert.ToUInt64(project.Substring(0, 16), 16);
        }

        public ulong LoWord( string project)
        {
            return Convert.ToUInt64(project.Substring(16, 16), 16);
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
       
        #endregion
        
        /// <summary>
        /// A test for Visible
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_VisibleTest_Visible()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            Visibility expected = new Visibility();
            expected = Visibility.Visible;
            Visibility actual;
            target.Visible = expected;
            actual = target.Visible.Value;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// A test for Visible
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_VisibleTest_Collapsed()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            Visibility expected = new Visibility();
            expected = Visibility.Collapsed;
            Visibility actual;
            target.Visible = expected;
            actual = target.Visible.Value;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// A test for SelectedItem
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_SelectedItemTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            DataItemBase expected = new DataItemBase();
            //create Name property and assign it to the dataItemBase
            expected.CommonName = "selectedDataItemBase";
            DataItemBase actual;
            target.SelectedItem = expected;
            actual = target.SelectedItem;
            Assert.AreEqual(expected.CommonName, actual.CommonName);
        }

        /// <summary>
        /// A test for LastUserHighlightedItem
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_LastUserHighlightedItemTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            target.LastUserHighlightedItem = "::L63.TagA";
            string expected = "::L63.TagA";
            Assert.AreEqual(expected, target.LastUserHighlightedItem);
        }

        /// <summary>
        /// A test for Path
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_PathTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            String controllerName = "activeController";
            mock.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(controllerName));
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock); 
            Path actual = target.Path;
            Assert.AreEqual(controllerName, actual.ActiveElement.DisplayName);
            Assert.AreEqual(mock.Path.SelectedPath[0], actual.SelectedPath[0]);
        }

        /// <summary>
        /// A test for Path
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_PathTest_HMIDevice()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            String controllerName = "activeController";
            mock.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controllerName));
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            Path actual = target.Path;
            Assert.AreEqual(controllerName, actual.ActiveElement.DisplayName);
            Assert.AreEqual(mock.Path.SelectedPath[0], actual.SelectedPath[0]);
        }

        /// <summary>
        /// A test for ItemsSource
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_ItemsSourceTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            ObservableCollection<DataItemBase> dibs = new ObservableCollection<DataItemBase>();
            DataItemBase dib1 = new DataItemBase() { CommonName = "tag1" };
            dibs.Add(dib1);
            DataItemBase dib2 = new DataItemBase() { CommonName = "tag2" };
            dibs.Add(dib2);
            DataItemBase dib3 = new DataItemBase() { CommonName = "tag3" };
            dibs.Add(dib3); 
            
            DataGridCollectionView expected = new DataGridCollectionView(dibs);
            DataGridCollectionView actual;
            PrivateObject privateTarget = new PrivateObject(target);
            privateTarget.SetProperty("ItemsSource", expected);
            actual = target.ItemsSource;
            Assert.AreEqual(dibs[0].CommonName, (actual.GetItemAt(0) as DataItemBase).CommonName);
            Assert.AreEqual(dibs[1].CommonName, (actual.GetItemAt(1) as DataItemBase).CommonName);
            Assert.AreEqual(dibs[2].CommonName, (actual.GetItemAt(2) as DataItemBase).CommonName);
        }

        /// <summary>
        /// A test for DrillOutCommand
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_DrillOutCommandTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            String controllerName = "drilloutController";
            mock.Path.Add(PathElementUtility.Instance().CreateProgramPathElement(controllerName));

            DataItemBase program = new DataItemBase() { CommonName = "drilloutProgram" };
            mock.Path.Add(PathElementUtility.Instance().CreateProgramPathElement(program.CommonName));

            DataItemBase dib = new DataItemBase() { CommonName = "drillout", CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString() };
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(dib.CommonName, String.Empty, true));

            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            target.DrillOutCommand.Execute(dib);

            Assert.AreEqual(dib.CommonName, mock.NavNameToSelect);
            Assert.AreEqual(program.CommonName, mock.NavPathList[1].DisplayName);
        }

        /// <summary>
        /// A test for DrillInCommand
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_DrillInCommandTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            DataItemBase homeDataItem = new DataItemBase(){ 
                CommonID =  "hi: 16643070363065207339\nlo: 13601259066303758964\n", 
                CommonName = "home", 
                CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403191811\n"
            };
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            mock.Path.Items.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));


            DataItemBase dib = new DataItemBase()
            {
                CommonName = "drillinTag",
                CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString()
            };

            target.DrillInCommand.Execute(dib);
            Assert.AreEqual(dib.CommonName, mock.NavPathList[1].DisplayName);
        }


        /// <summary>
        /// A test for DrillInCommand
        /// This is to test that anomaly 119850 remains fixed
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_DrillOutAndInToSameTag_AndReselectLastHighlightedElement()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);

            //Add some items to the path and then navigate backwards so that there is an existing path.Forward item
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Controller1", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Level2", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Level3", "", true));
            IPathElement lastSelectedPathItem = PathElementUtility.Instance().CreateDataItemPathElement("SomeTerminalNode", "", true);
            mock.Path.SavedHighlightedElement = lastSelectedPathItem;
            Assert.IsTrue(mock.Path.Forward == null);
            Assert.IsTrue(mock.Path.ActiveElement.DisplayName == "Level3");
            Assert.IsTrue(mock.Path.SavedHighlightedElement.DisplayName == "SomeTerminalNode");
            mock.Path.NavigateBack(); //Drill out
            Assert.IsTrue(mock.Path.Forward.DisplayName == "Level3");
            Assert.IsTrue(mock.Path.ActiveElement.DisplayName == "Level2");
            Assert.IsTrue(mock.Path.SavedHighlightedElement.DisplayName == "SomeTerminalNode");

            DataItemBase dib = new DataItemBase() { CommonName = "Level3" };
            target.DrillInCommand.Execute(dib); //Drill back into same tag called "drillinTag"

            Assert.IsTrue(mock.NavPathList.Count == 3);
            Assert.AreEqual(dib.CommonName, mock.NavPathList[2].DisplayName);
            Assert.IsTrue(mock.NavPathList[2].DisplayName == "Level3");
            //Are we attempting to select the last highlighted item?
            Assert.IsTrue(mock.NavNameToSelect == "SomeTerminalNode");
        }       
        
        /// <summary>
        /// A test for DrillInCommand
        /// This is to test that anomaly 119850 remains fixed
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_DrillOutAndInToDifferentTag_AndDontReselectAnything()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);

            //Add some items to the path and then navigate backwards so that there is a forward item
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Controller1", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("SomeAutoValue1", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("SomeDetailTag", "", true));
            IPathElement lastSelectedPathItem = PathElementUtility.Instance().CreateDataItemPathElement("SomeTerminalNode", "", true);
            mock.Path.SavedHighlightedElement = lastSelectedPathItem;
            Assert.IsTrue(mock.Path.Forward == null);
            Assert.IsTrue(mock.Path.ActiveElement.DisplayName == "SomeDetailTag");
            Assert.IsTrue(mock.Path.SavedHighlightedElement.DisplayName == "SomeTerminalNode");
            mock.Path.NavigateBack(); //Drill out
            Assert.IsTrue(mock.Path.Forward.DisplayName == "SomeDetailTag");
            Assert.IsTrue(mock.Path.ActiveElement.DisplayName == "SomeAutoValue1");
            Assert.IsTrue(mock.Path.SavedHighlightedElement.DisplayName == "SomeTerminalNode");

            DataItemBase dib = new DataItemBase() { CommonName = "drillinTag" };
            target.DrillInCommand.Execute(dib); //Drill back into same tag called "drillinTag"

            Assert.IsTrue(mock.NavPathList.Count == 3);
            Assert.AreEqual(dib.CommonName, mock.NavPathList[2].DisplayName);
            Assert.IsTrue(mock.NavPathList[2].DisplayName == "drillinTag");
            //Are we attempting to select the last highlighted item? Since we drilled into a different tag, this should be nothing
            Assert.IsTrue(mock.NavNameToSelect == "");
        }


        /// <summary>
        /// A test for DrillInCommand with no Forward path and two nodes in history list with same name
        /// This is to test that anomaly 119835 remains fixed
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_DrillIn_TagAndParentWithSameName()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);

            //Add some items to the path and then navigate backwards so that there is an existing path.Forward item
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Controller1", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Level2", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Level3SameName", "", true));
            IPathElement lastSelectedPathItem = PathElementUtility.Instance().CreateDataItemPathElement("Level3SameName", "", true);
            mock.Path.SavedHighlightedElement = lastSelectedPathItem;
            Assert.IsTrue(mock.Path.Forward == null);
            Assert.IsTrue(mock.Path.ActiveElement.DisplayName == "Level3SameName");
            Assert.IsTrue(mock.Path.SavedHighlightedElement.DisplayName == "Level3SameName");

            DataItemBase dib = new DataItemBase() { CommonName = "Level3SameName" };
            target.DrillInCommand.Execute(dib); //Drill down from Tag called "Level3SameName" to another tag called "Level3SameName"

            Assert.IsTrue(mock.NavPathList.Count == 4);
            Assert.IsTrue(mock.NavPathList[3].DisplayName == "Level3SameName");
            //We should NOT have attempted to select a Tag called Level3SameName
            Assert.IsTrue(mock.NavNameToSelect != "Level3SameName");
            Assert.IsTrue(mock.NavNameToSelect == "");
        }


        /// <summary>
        /// A test for DataItemBrowserViewModel_DataViewChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_DataItemBrowserViewModel_DataViewChangedTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            PrivateObject targetPrivate = new PrivateObject(target);
            object sender = null;
            Visibility expected = Visibility.Collapsed;
            ActivePathChangedEventArgs e = new ActivePathChangedEventArgs("", false);
            targetPrivate.Invoke("DataItemBrowserViewModel_DataViewChanged", new object[]{sender, e});
            Assert.AreEqual(target.Visible, expected);
        }

        /// <summary>
        /// A test for NotifyPropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_NotifyPropertyChangedTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            PrivateObject targetPrivate = new PrivateObject(target);
            targetPrivate.Invoke("add_PropertyChanged", new PropertyChangedEventHandler(myPropertyHandler));
            _myPropertyName = "";
            _mySender = null;
            string propertyName = "myProperty";
            targetPrivate.Invoke("NotifyPropertyChanged", propertyName);
            Assert.AreEqual(propertyName, _myPropertyName);
            Assert.AreEqual(target, _mySender);
        }
        private string _myPropertyName = "";
        private object _mySender = null;
        public void myPropertyHandler(object sender, PropertyChangedEventArgs e)
        {
            _myPropertyName = e.PropertyName;
            _mySender = sender;
        }

        /// <summary>
        /// A test for NotifyColumnConfigurationChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_NotifyColumnConfigurationChangedTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            PrivateObject targetPrivate = new PrivateObject(target);
            targetPrivate.Invoke("add_ColumnConfigurationChanged", new PropertyChangedEventHandler(myPropertyHandler));
            _myPropertyName = "";
            _mySender = null;
            //property name is not passed along so it is empty string
            string propertyName = "";
            targetPrivate.Invoke("NotifyColumnConfigurationChanged");
            Assert.AreEqual(propertyName, _myPropertyName);
            Assert.AreEqual(target, _mySender);
        }

        /// <summary>
        /// A test for DoubleClickSelection
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_DoubleClickSelectionTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);


            mock.Path.Add(PathElementUtility.Instance().CreateHomePathElement("Controller1"));
            DataItemBase selectedDataItem = (PathElementUtility.Instance().CreateDataItemBase("doubleClickTag"));
            string selectedName = "::Controller1.doubleClickTag";

            target.DoubleClickSelection(selectedDataItem);
            Assert.AreEqual(selectedName, mock.SelectedItemCommandName);
        }

        /// <summary>
        /// A test for UserChangedHighlightedItem
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_UserChangedHighlightedItemTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);
            
            List<IPathElement> pathList = new List<IPathElement>();
            pathList.Add(PathElementUtility.Instance().CreateHomePathElement(""));
            pathList.Add(PathElementUtility.Instance().CreateControllerPathElement("L63"));
            pathList.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
            PrivateObject privatePath = new PrivateObject(target.Path);
            privatePath.SetProperty("UserSetHighlightedPath", pathList);
                        
            DataItemBase dataItem = (PathElementUtility.Instance().CreateDataItemBase("TagA"));

            string highlightedItem = "::L63.TagA";

            target.UserChangedHighlightedItem(dataItem);            
            Assert.AreEqual(highlightedItem, mock.UserSetHighlightedItemCommandName);
        }

        /// <summary>
        /// A test for UserChangedHighlightedItem
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweTagGridViewModel_UserChangedHighlightedItemTest_HMIDevice()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweTagGridViewModel target = new VieweTagGridViewModel(mock);

            List<IPathElement> pathList = new List<IPathElement>();
            pathList.Add(PathElementUtility.Instance().CreateHomePathElement(""));
            pathList.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("L63"));
            pathList.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
            PrivateObject privatePath = new PrivateObject(target.Path);
            privatePath.SetProperty("UserSetHighlightedPath", pathList);            
            DataItemBase dataItem = (PathElementUtility.Instance().CreateDataItemBase("TagA"));

            string highlightedItem = "::L63.TagA";

            target.UserChangedHighlightedItem(dataItem);
            Assert.AreEqual(highlightedItem, mock.UserSetHighlightedItemCommandName);
        }

    }
}
