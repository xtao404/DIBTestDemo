﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using TagFilterControl.Common;

namespace TagFilterControl.Controls.PreFilter
{
    public class FilterDIBManagerViewModel : BaseViewModel
    {
        private bool isCheckedAll;
        public bool IsCheckedAll
        {
            get { return this.isCheckedAll; }
            set
            {
                this.isCheckedAll = value;
                foreach (var item in this.FilterItems)
                {
                    item.IsChecked = value;
                }
                this.RaisePropertyChangedEvent(() => this.IsCheckedAll);
            }
        }

        protected void RaiseIsCheckedAll(bool uncheck)
        {
            if (uncheck)
            {
                this.isCheckedAll = false;
            }
            else
            {
                this.isCheckedAll = this.FilterItems.All(i => i.IsChecked);
            }
            this.RaisePropertyChangedEvent(() => IsCheckedAll);
        }
        protected void RegisterItemCheckEvent()
        {
            foreach (var item in this.FilterItems)
            {
                item.IsCheckedChanged += (@checked) =>
                {
                    this.EditCommand.RaiseCanExecuteChanged();
                    this.DeleteCommand.RaiseCanExecuteChanged();
                    this.RaiseIsCheckedAll(!@checked);
                };
            }
        }

        private ObservableCollection<PreFilterDIBItem> filterItems;
        public ObservableCollection<PreFilterDIBItem> FilterItems
        {
            get { return this.filterItems ?? (this.filterItems = new ObservableCollection<PreFilterDIBItem>()); }
            set
            {
                this.filterItems = value;
                this.RaisePropertyChangedEvent(() => this.FilterItems);
            }
        }

        public IEnumerable<PreFilterDIBItem> SelectedItems
        {
            get
            {
                return this.FilterItems.Where(i => i.IsChecked);
            }
        }

        private bool canEditExecute;
        public bool CanEditExecute
        {
            get { return canEditExecute; }
            set
            {
                this.canEditExecute = value;
                this.RaisePropertyChangedEvent(() => this.CanEditExecute);
            }
        }

        private bool canDeleteExecute;
        public bool CanDeleteExecute
        {
            get { return canDeleteExecute; }
            set
            {
                this.canDeleteExecute = value;
                this.RaisePropertyChangedEvent(() => this.CanDeleteExecute);
            }
        }

        public ICommand CreateCommand
        {
            get
            {
                return new CustomCommand(
                    () =>
                    {

                    });
            }
        }

        private CustomCommand editCommand;
        public CustomCommand EditCommand
        {
            get
            {
                return this.editCommand ?? (this.editCommand = new CustomCommand(
                    () =>
                    {

                    }));
            }
        }

        private CustomCommand deleteCommand;
        public CustomCommand DeleteCommand
        {
            get
            {
                return this.deleteCommand ?? (this.deleteCommand = new CustomCommand(() =>
                {

                }));
            }
        }

        public CustomCommand CloseCommand
        {
            get
            {
                return new CustomCommand(() =>
                {

                });
            }
        }
    }

    public class FilterDIBItem : BaseViewModel
    {
        private string name;
        public string Name
        {
            get { return this.name; }
            set
            {
                name = value;
                this.RaisePropertyChangedEvent(() => this.Name);
            }
        }

        private string lastModifyTime;
        public string LastModifyTime
        {
            get { return lastModifyTime; }
            set
            {
                lastModifyTime = value;
                this.RaisePropertyChangedEvent(() => this.LastModifyTime);
            }
        }

        private bool isChecked;
        public bool IsChecked
        {
            get
            {
                return this.isChecked;
            }
            set
            {
                this.isChecked = value;
                this.IsCheckedChanged.Execute(value);
                this.RaisePropertyChangedEvent(() => this.IsChecked);
            }
        }

        public event Action<bool> IsCheckedChanged;
    }
}
