﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Object
{
    public class TagObjects : BaseAttribute
    {
        public TagObjects()
        {
            DataValueMembers = new List<DataValueMember>();
        }

        public TagType TagType { get; set; }

        public string DataType { get; set; }

        public string Constant { get; set; }

        public string Radix { get; set; }

        public string ExternalAccess { get; set; }

        public TagUsage Usage { get; set; }

        public List<DataValueMember> DataValueMembers { get; set; }
    }

    public class TagDataType : BaseAttribute
    {
        public TagFamily Family { get; set; }

        public TagClass Class { get; set; }

        public string UId { get; set; }

        public string ParentUId { get; set; }

        public string Size { get; set; }
    }

    public enum TagClass
    {
        ProductDefined,
        IO,
        User,
        AOI
    }

    public enum TagFamily
    {
        StringFamily,
        NoFamily
    }

    public class DataValueMember
    {
        public string Name { get; set; }

        public TagType TagType { get; set; }

        public string DataType { get; set; }

        public string Radix { get; set; }

        public string Value { get; set; }
    }

    public enum TagType
    {
        all,
        Unused,
        Base,
        Alias,
        Produced,
        Consumed
    }

    public enum TagUsage
    {
        None,
        Local,
        Input,
        Public,
        Output,
        InOut
    }
}
