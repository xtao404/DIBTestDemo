﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Reflection;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.DIBQuery;

namespace RockwellAutomation.UI.WindowsControl.DIBClient
{
    class DIBClientManager_2_TreeViewMultiSubChildren : DIBClientManager_1_TreeViewSimple
    {

        private string baseAssemblyLocation;
        protected string baseAssemblyLocationURIString;

        override public void InitializeDIBControlOnStartup(RockwellAutomation.UI.Views.DataItemBrowser dataItemBrowserControl, System.Text.StringBuilder logger)
        {
            baseAssemblyLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            baseAssemblyLocationURIString = "file:\\\\" + baseAssemblyLocation;
        }

        #region Navigation overrides

        override public string GetResourceTypeString(DataItemBase dataItem)
        {
            return DIResource.DI_COMMON_RESOURCETYPE_GENERIC_DIB_ITEMVIEW;
        }

        #endregion

        #region "Custom Drill in Logic"

        protected override void CreateViewDataItems(int drillInLevel, DIBQueryCache queryCache)
        {
            DataItemBase parent = new DataItemBase()
            {
                CommonName = "parent level " + drillInLevel,
                GUIShowChildrenInBreadCrumbTrail = "true",
                CommonDescription = "Root Level Tree Node for Level: " + drillInLevel,
                CommonDataType = "Root Node",
                GUITreeViewParentID = string.Empty,
                GUITreeViewID = this.GetNextAutoNumber(),
                GUIIsExpanded = "True",
                GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\16by16\\detail.png"
            };
            parent.SetStringMapValue(_DrillInLEVELINDICATOR, drillInLevel.ToString());
            queryCache.AddDataItem(parent);

            string firstChildID, secondChildID, thirdChildID;
            //Add first level children
            queryCache.AddDataItem(this.CreateDIBFrom("1st child level ",
                parent.GUITreeViewID,
                firstChildID = this.GetNextAutoNumber(),
                "False",
                drillInLevel.ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("2nd child level ",
                parent.GUITreeViewID,
                secondChildID = this.GetNextAutoNumber(),
                "False",
                drillInLevel.ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("3rd child level ",
                parent.GUITreeViewID,
                thirdChildID = this.GetNextAutoNumber(),
                "False",
                drillInLevel.ToString()));

            // Add second level children
            queryCache.AddDataItem(this.CreateDIBFrom("1st child level ",
                firstChildID,
                firstChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 1).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("2nd child level ",
                secondChildID,
                secondChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 1).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("3rd child level ",
                thirdChildID,
                thirdChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 1).ToString()));


            // Add third level children
            queryCache.AddDataItem(this.CreateDIBFrom("1st child level ",
                firstChildID,
                firstChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 2).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("2nd child level ",
                secondChildID,
                secondChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 2).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("3rd child level ",
                thirdChildID,
                thirdChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 2).ToString()));

            // Add fourth level children
            queryCache.AddDataItem(this.CreateDIBFrom("1st child level ",
                firstChildID,
                firstChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 3).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("2nd child level ",
                secondChildID,
                secondChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 3).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("3rd child level ",
                thirdChildID,
                thirdChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 3).ToString()));

            // Add fifth level children
            queryCache.AddDataItem(this.CreateDIBFrom("1st child level ",
                firstChildID,
                firstChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 4).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("2nd child level ",
                secondChildID,
                secondChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 4).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("3rd child level ",
                thirdChildID,
                thirdChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 4).ToString()));

            // Add sixth level children
            queryCache.AddDataItem(this.CreateDIBFrom("1st child level ",
                firstChildID,
                firstChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 5).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("2nd child level ",
                secondChildID,
                secondChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 5).ToString()));
            queryCache.AddDataItem(this.CreateDIBFrom("3rd child level ",
                thirdChildID,
                thirdChildID = this.GetNextAutoNumber(),
                "True",
                (drillInLevel + 5).ToString()));
        }


        override public DataItemBase CreateDIBFrom(string name, string parentID, string treeId, string supportsDrillin, string levelIndicator)
        {
            DataItemBase dib = base.CreateDIBFrom(name, parentID, treeId, supportsDrillin, levelIndicator);
            // Set the icon for this DataItembase
            dib.GUISmallImagePath = this.baseAssemblyLocationURIString + "\\Images\\16by16\\check1_16.png";
            // Set the description and data type for this DataItemBase so that we can search on it
            dib.CommonDescription = (bool.Parse(supportsDrillin)? "Drillable" : "Non-Drillable") + " Tree Item: " + name;
            dib.CommonDataType = (string.IsNullOrWhiteSpace(parentID)? "Root Node" : "Child Node");
            return dib;
        }

        #endregion
    }
}
