﻿/*************************************************************************************
                                                                     
   ViewE Keyboard Navigation
   Copyright © 2009-2011 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using System.Windows.Input;

namespace RockwellAutomation.UI
{
    /// <summary>
    /// Helper class for KeyboardNavigation
    /// </summary>
    static class KeyboardNavigation
    {
        /// <summary>
        /// Return the string value of the keystroke paramater
        /// </summary>
        public static string stringValueOfKey(KeyEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Shift && e.Key == Key.OemMinus) return "_";
            if (e.Key == Key.Space) return " ";
            if (e.Key == Key.OemOpenBrackets) return "[";
            if (e.Key == Key.OemCloseBrackets) return "]";
            if (e.Key == Key.OemComma) return ",";
            if (Keyboard.Modifiers == ModifierKeys.Shift && e.Key == Key.Oem1) return ":";
            if (Keyboard.Modifiers == ModifierKeys.Shift && (e.Key == Key.D2 || e.Key == Key.NumPad2)) return "@"; //Allow selection of metadata first character
            return (new KeyConverter().ConvertToString(e.Key).ToLower());
        }

        /// <summary>
        /// Identify keystrokes that we are interested in for the purpose of grid auto selection
        /// </summary>
        public static bool IsValidGridAutoSelectionKey(KeyEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Alt || Keyboard.Modifiers == ModifierKeys.Control || Keyboard.Modifiers == ModifierKeys.Windows) return false;
            if (e.IsRepeat) return false;
            if (e.Key == Key.System) return false;

            bool isAlpha = (e.Key >= Key.A && e.Key <= Key.Z);
            bool isNumPadNumeric = (e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9);
            bool isNumeric = (e.Key >= Key.D0 && e.Key <= Key.D9);
            //Allow '_', ' ', '[', ']', ':', ','
            bool isOtherAllowedKey = ((Keyboard.Modifiers == ModifierKeys.Shift && e.Key == Key.OemMinus) || e.Key == Key.Space || e.Key == Key.OemOpenBrackets || e.Key == Key.OemCloseBrackets || e.Key == Key.Oem1 || e.Key == Key.OemComma);

            return (isAlpha || isNumPadNumeric || isNumeric || isOtherAllowedKey);
        }
    }
}
