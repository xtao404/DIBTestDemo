﻿

using System;
using System.Threading;

namespace DataItemBrowserUT.CodedUI
{
    using DataItemBrowserUT.CodedUI.UIMaps.UIMapClasses;
    using Microsoft.VisualStudio.TestTools.UITesting;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using DataItemBrowserUT.CodedUI.UIMaps.UIMapDataContextClasses;
    using RockwellAutomation.Client.Services.Query.Common;

    /// <summary>
    /// Summary description for 
    /// </summary>
    [CodedUITest]
    public class DataContextTest : CodedUITestBase
    {
		/// <summary>
		/// Constructor
		/// </summary>
        public DataContextTest()
        {
            //USE ONE OF THE CALLS TO SetProjectFile

            //Use this to call the Mock to avoid requiring the ROA stack to be running for the tests to run. This must be used to 
            //run the tests as part of the build process
            //SetProjectFile(new Tuple<string, string, string>("Controller1", "StructuresArraysBits_filter_V21", "Controller"));

            //Use this if you just want to have the tests run by development but do not want to have it run as part of the 
            //build process. All the methods must have [TestCategory("ExcludeOnAutoBuild")] so they are not run as part of the build.
            SetProjectFile("DataItemBrowserUT.CodedUI.Projects.Project12.VPD");
        }

        /// <summary>
        /// Set up a datacontext with 
        /// root
        /// exclude root children
        /// include
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void DataContext_Root_ExcludeChildren_IncludeProgram()
        {
            //ARRANGE           
            this.UIMapDataContext.DIB_DataContext_Root_ExcludeRootChildren_Include();
            OpenDIB();

            //ASSERT
            this.UIMapDataContext.DIB_Assert_DeviceListView_Enabled();
            //navigate and verify that the program is the only item in the grid
            this.UIMapDataContext.DIB_DataContext_Navigate_Programs_Alt_Right();
            this.UIMapDataContext.DIB_DataContext_Program_Shft_Tab();
            this.UIMapDataContext.DIB_Assert_BreadCrumb_Program_ContextMenu();

            //Close DIB from the Devices View
            this.UIMap.ClickHomeCrumbButton();
            DIB_WaitForSpinnerStop();
            this.UIMapDataContext.DIB_ESC_From_ControllerView();
        }
       
        /// <summary>
        /// Set up a datacontext with 
        /// Filter Type = DT
        /// filter value = BOOL[32] 
        /// 
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void DataContext_with_Filter()
        {
            //ARRANGE         
            this.UIMapDataContext.DIB_DataContext_DT_Filter_FilterValue("BOOL[32]");
            OpenDIB();

            //ASSERT              
            //verify the grid contains only rows with datatype = BOOL[32]
            DIB_WaitForSpinnerStop();
            //this should hook up the Automation to the grid so the grid serialization enables
            this.UIMap.Assert_DataViewsAutomationIds();
            Thread.Sleep(2000);
            DIB_Assert_DataGridView_Contents(9, DIBConstants.Common.DataType, "BOOL[32]", false);
            
            CloseDIB();
        }

        /// <summary>
        /// Set up a datacontext with type based
        /// Exclude All children of: Controller
        /// Exclude All of Type: HMIDevice
        /// Include All of Type: DataLogs
        /// 
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]  //This can be removed if the mock is used
        public void DataContext_IncludeOnlyDataLogs()
        {
            //ARRANGE, ACT          
            this.UIMapDataContext.DIB_DataContext_TypeBased_ExcludeAllChildren_ExcludeTypeHMI_IncludeTypeDataLogs();

            OpenDIB();
            
            //ASSERT
            //verify only Datalogs are available in the breadcrumbs
            this.UIMapDataContext.DIB_DataContext_Navigate_Controller1_Alt_Right();
            this.UIMapDataContext.DIB_ShiftTab_DataLogsDeviceTree();            
            this.UIMapDataContext.DIB_Assert_BreadCrumb_DataLogs();

            //CloseDIB from DeviceView of Controllers
            this.UIMap.ClickHomeCrumbButton();
            DIB_WaitForSpinnerStop();
            this.UIMapDataContext.DIB_ESC_From_DeviceView();

        }

        private void CloseDIB()
        {
            this.UIMap.ClickHomeCrumbButton();
            DIB_WaitForSpinnerStop();
            this.UIMap.DIB_PressESC();
        }

        private void OpenDIB()
        {
            this.UIMap.PTH_ClickTagBrowserButton();
            //kludge to ensure that DIB opens to the datasources view and not the last hightlighted item
            UIMap.PTH_EnterDotInReadTagTextBox();
            this.UIMap.PTH_ClickReadTagElipsisButton();
        }
        #region Additional test attributes

        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            CodedUITestBase.BaseClassInitialize(testContext);
        }

        [ClassCleanup]
        public static void MyClassCleanup()
        {
            CodedUITestBase.BaseClassCleanup();
        }

        //Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void MyTestInitialize()
        {
            SetupGridSerialization();          
        }

        //Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {
            CleanUpGridSerialization();

            //must close the popup after each test to clear out the datacontext and have
            //the popup in a reproducible starting state
            ClosePopup();
        }

        #endregion     

		///<summary>
		/// This is the UIMap of the CodedUITestBase
		/// Any recorded functionality that is generic enough to be used by any 
		/// coded UI test should be put in this class, to customize any of these recordings
		/// read the information at the top of this file
		///</summary>
        public UIMap UIMap
        {
            get
            {
                if ((this.map == null))
                {
                    this.map = new UIMap();
                }

                return this.map;
            }
        }

		///<summary>
		/// This is the UIMap of YOUR CLASS
		/// Any recorded functionality that is specific for your 
		/// class should be put in this map file, to customize any of these recordings
		/// read the information at the top of this file
		///</summary>
        public UIMapDataContext UIMapDataContext
        {
            get
            {
                if ((this.dataContextMap == null))
                {
                    this.dataContextMap = new UIMapDataContext();
                }
                return this.dataContextMap;
            }
        }
        private UIMap map;
        private UIMapDataContext dataContextMap;
    }


}
