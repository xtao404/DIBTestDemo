﻿/* ****************************************************************************
*
*  Copyright 2016 Rockwell Automation Technologies Inc.  Confidential.  All Rights Reserved.
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.UI.DIBQuery
{
    class DIBQueryCommandForHMIDevice : DIBQueryCommandForViewe
    {
        
        #region "Creation/Init"

        public DIBQueryCommandForHMIDevice(QueryRequest.CreateBuilder queryRequestBuilder)
            : base( queryRequestBuilder)
        {
            CacheQueryResults = true;
        }
        
        #endregion

        #region "Base Overrides"

        public override PredefinedQueryType QueryType()
        {
            return PredefinedQueryType.Undefined;
        }

        public override void Execute(IClientDataServices cds, IDIBQueryConnection queryConnection)
        {
            // User drilled into the HMIDevice view
            DIBClientManagerForViewe manager = cds.DibClientManager as DIBClientManagerForViewe;
            if (manager.IsAOGPropertyBrowser())
            {
                DataItemBase pathNode = new DataItemBase()
                {
                    CommonName = manager.AOGScreenName,
                    CommonResourceType = TypeIdentifiers.ResourceType_AOG.ToString(),
                    GUISupportsDrillIn = "true",
                    GUISupportsSelection = "true",
                    GUIShowChildrenInBreadCrumbTrail = "true",
                    IsStructured = true
                };
                cds.QueryCache.AddDataItem(pathNode);
            }
            else
            {
                cds.QueryCache.AddDataItem(DIResource.DIB_TagsAndProps);
            }
            
            ExecuteNonDBQueryResponse(queryConnection, cds.QueryCache);
            return;
        }
        
        #endregion
    }
}
