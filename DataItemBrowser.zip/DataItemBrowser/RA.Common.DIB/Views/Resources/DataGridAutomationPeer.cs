﻿/**************************************************************************************
                                                                     
   ViewE DataGridAutomationPeer
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
#region references

using Xceed.Wpf.DataGrid.Views;
using System.Collections.Generic;
using System.Windows.Automation.Peers;
using System;



#endregion

namespace RockwellAutomation.UI.Views
{
    /// <summary>
    /// Class to expose the DataGrids inner/child Pane class to UI automation clients (for scrollbar
    /// and keyboard focus checking when the grid is empty)
    /// </summary>
    public class DataGridAutomationPeer : Xceed.Wpf.DataGrid.Automation.DataGridControlAutomationPeer
    {
        private DIBGridView _grid = null;

        public DataGridAutomationPeer(DIBGridView grid)
            : base(grid)
        {
            _grid = grid;
        }

        protected override string GetClassNameCore()
        {
            return base.GetClassNameCore();
        }

        protected override List<AutomationPeer> GetChildrenCore()
        {
            List<AutomationPeer> automationPeers = base.GetChildrenCore();
            if (_grid != null)
            {
                TableViewScrollViewer gridTableViewSv = _grid.Template.FindName("PART_ScrollViewer", _grid) as TableViewScrollViewer;
                if (gridTableViewSv != null)
                {
                    AutomationPeer peer = ScrollViewerAutomationPeer.CreatePeerForElement(gridTableViewSv);
                    if (peer != null)
                    {
                        automationPeers.Add(peer);
                    }
                }
            }

            return automationPeers;
        }
    }
}