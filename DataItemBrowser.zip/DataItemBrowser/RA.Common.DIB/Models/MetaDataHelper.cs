﻿using System;
using System.Diagnostics;
using System.Linq;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.UI.DIBQuery;

namespace RockwellAutomation.UI
{    
    /// <summary>
    /// Creates instances of DataItemBase that represent Metadata
    /// </summary>
    public static class MetaDataHelper 
    {

        #region Public

        /// <summary>Add MetaData related items to the current Item Collection based on a QueryResponse details and ClientDataServices state
        /// </summary>
        /// <param name="queryResponse">QueryResponse representing the query type.</param>
        /// <param name="cds">ClientDataServices representing query details</param>
        public static void CreateMetaDataFor(QueryResponse queryResponse, IClientDataServices cds)
        {
            if (queryResponse == null) return;
            // If the DIB user has indicated to not display metadata (specified as a DIB startup paramater), dont create any meta rows in the result
            if (!cds.ShouldDisplayMetaData()) return;
            // Only show metadata if we are in the data grid view
            if (!cds.DataView.IsGridView()) return;
            // Only show metadata if we are in the tag browser
            if (cds.IsTagBrowser() != true) return;
            // Only show metadata if we are showing data type members
            if (!queryResponse.GetQueryRequest.GetPredefinedQuery.Equals(PredefinedQueryType.DataTypeMembers)) return;
            // Only show metadata if we are browsing outside of HMI devices
            if (cds.IsBrowsingHMIDevice()) return;

            // If we drilled into a numeric type, display numeric metadata 
            if (MetaDataHelper.IsNumericBaseType(cds.CurrentParentDataItem()))
            {
                CreateNumericMetaDataFor(cds.QueryCache, cds.CurrentParentDataItem());
                return;
            }

            // We drilled into a non-numeric data type member. Display default non-numeric metadata
            MetaDataHelper.CreateMetaDataFor(cds.QueryCache);
        }

        /// <summary>Add MetaData related items to the current Item Collection.
        /// </summary>
        /// <param name="dataItems">The observableCollection that will contain the DataItemBases</param>
        public static void CreateMetaDataFor(DIBQueryCache queryCache)
        {
            queryCache.AddDataItem(MetaDataHelper.MetaDataDescription());
            queryCache.AddDataItem(MetaDataHelper.MetaDataEU());
            queryCache.AddDataItem(MetaDataHelper.MetaDataName());
        }

        /// <summary>Add numeric MetaData related items to the current Item Collection.
        /// </summary>        
        /// <param name="queryCache">The observableCollection that will contain the DataItemBases </param>
        /// <param name="parentDIB">The DataItemBase to use in creating the meta data tags.</param>
        public static void CreateNumericMetaDataFor(DIBQueryCache queryCache, DataItemBase parentDIB)
        {
            if (parentDIB == null) return;
            queryCache.AddDataItem(MetaDataHelper.MetaDataDescription());
            queryCache.AddDataItem(MetaDataHelper.MetaDataEU());

            if (parentDIB.CommonDataType == DIResource.DI_COMMON_RESOURCETYPE_BOOL)
            {
                queryCache.AddDataItem(MetaDataHelper.MetaDataName());
                queryCache.AddDataItem(MetaDataHelper.MetaDataState0());
                queryCache.AddDataItem(MetaDataHelper.MetaDataState1());
            }
            else
            {
                queryCache.AddDataItem(MetaDataHelper.MetaDataMax(parentDIB));
                queryCache.AddDataItem(MetaDataHelper.MetaDataMin(parentDIB));
                queryCache.AddDataItem(MetaDataHelper.MetaDataName());
            }
        }

        public static DataItemBase MetaDataName()
        {
            DataItemBase dib = new DataItemBase() { 
                CommonName = "@Name", 
                CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_STRING,
                CommonDescription = "Specifies the name of the tag",
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString()
            };
            return dib;
        }

        public static DataItemBase MetaDataEU()
        {
            DataItemBase dib = new DataItemBase() {
                CommonName = "@EngineeringUnit",
                CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_STRING,
                CommonDescription = "Specifies the unit of measure for the value (i.e. inches, psi, etc)",
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString()
            };
            return dib;
        }

        public static DataItemBase MetaDataDescription()
        {
            DataItemBase dib = new DataItemBase() {
                CommonName = "@Description",
                CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_STRING,
                CommonDescription = "Specifies the description of the tag",
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString()
            };
            return dib;
        }

        public static DataItemBase MetaDataState0()
        {
            DataItemBase dib = new DataItemBase() {
                CommonName = "@State0",
                CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_STRING,
                CommonDescription = "Describes the state when the value is zero (i.e. Off)",
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString()
            };
            return dib;
        }

        public static DataItemBase MetaDataState1()
        {
            DataItemBase dib = new DataItemBase()
            {
                CommonName = "@State1",
                CommonDataType = DIResource.DI_COMMON_RESOURCETYPE_STRING,
                CommonDescription = "Describes the state when the value is one (i.e. On)",
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString()
            };
            return dib;
        }

        public static DataItemBase MetaDataMax(DataItemBase parentDIB)
        {
            DataItemBase dib = new DataItemBase(){
                CommonName = "@Max",
                CommonDescription = "Specifies the maximum value",
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString()
            };
            if (parentDIB != null) dib.CommonDataType = parentDIB.CommonDataType;
            return dib;
        }

        public static DataItemBase MetaDataMin(DataItemBase parentDIB)
        {
            DataItemBase dib = new DataItemBase() {
                CommonName = "@Min",
                CommonDataType = parentDIB.CommonDataType,
                CommonDescription = "Specifies the minimum value",
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString()
            };
            return dib;
        }

        /// <summary>
        /// Determine if a given DataItemBase represents a MetaData item
        /// </summary>
        /// <param name="dib"></param>
        /// <returns>indictor on if the given DataItemBase represents a MetaData item</returns>
        public static bool isMetaData(DataItemBase dib)
        {
            if (dib == null) return false;
            return isMetaDataName(dib.CommonName);
        }

        /// <summary>Return back whether the passed string representing a DataItemBase name is MetaData
        /// NOTE: This method is called by other classes that have performance considerations. Its called by a GUI class: NameWithDimsComparer that sorts items 
        /// in our main tag grid. Changes to this method should not impact performance</summary>
        /// <param name="name">The name</param>
        /// <returns>indictor on if the given name represents a MetaData item</returns>
        public static bool isMetaDataName(String name) 
        {
            if (String.IsNullOrEmpty(name)) return false;
            return (name.StartsWith("@"));
        }

        #endregion

        #region "Numeric/Array  Testing"

        /// <summary>
        /// Method to determine if a given DataItemBase represents a numeric type. Numeric types include integers, bools, and reals
        /// </summary>
        /// <param name="parentDIB">The DataItemBase to check if it represents a numeric type</param>
        /// <returns>indictor on whether the parentDIB represents a Numeric Type</returns>
        static public bool IsNumericBaseType(DataItemBase parentDIB)
        {
            if (parentDIB == null) return false;
            string dataTypeString = parentDIB.CommonDataType;
            if (dataTypeString == null) return false;
            return IsDataTypeNumeric(dataTypeString);
        }

        /// <summary>
        /// Method to determine if a given datatype string represents a numeric type. Numeric types include integers, bools, and reals 
        /// </summary>
        /// <param name="dataTypeString">The string to check if it represents an numeric type</param>
        /// <returns>indictor on whether the string represents an numeric type</returns>
        static public bool IsDataTypeNumeric(string dataTypeString)
        {
            if (dataTypeString == null)
                return false;

            if ((dataTypeString == DIResource.DI_COMMON_RESOURCETYPE_BOOL) ||
                (dataTypeString == DIResource.DI_COMMON_RESOURCETYPE_SINT) ||
                (dataTypeString == DIResource.DI_COMMON_RESOURCETYPE_INT) ||
                (dataTypeString == DIResource.DI_COMMON_RESOURCETYPE_DINT) ||
                (dataTypeString == DIResource.DI_COMMON_RESOURCETYPE_LINT) ||
                (dataTypeString == DIResource.DI_COMMON_RESOURCETYPE_REAL))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// Method to determine if a given DataItemBase represents an array.  
        /// </summary>
        /// <param name="parentDIB">The DataItemBase to check if it represents an Array</param>
        /// <returns>indictor on whether the parentDIB represents an Array</returns>
        static public bool IsArrayBaseType(DataItemBase parentDIB)
        {
            if (parentDIB == null) return false;
            string dimString = parentDIB.CommonDataType;
            if (String.IsNullOrEmpty(dimString)) return false;

            //If there is no array start character, then this in not an aray type
            if (!dimString.Contains(DIResource.DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER)) return false;

            // Remove leading characters
            dimString = dimString.Remove(0, dimString.IndexOf(DIResource.DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER, 0));
            // Remove array start and end characters
            dimString = dimString.Trim(DIResource.DI_COMMON_RESOURCETYPE_ARRAY_START_DELIMITER);
            dimString = dimString.Trim(DIResource.DI_COMMON_RESOURCETYPE_ARRAY_END_DELIMITER);
            if (String.IsNullOrEmpty(dimString)) return false;

            String[] dims = dimString.Split(new string[] { DIResource.DI_COMMON_RESOURCETYPE_ARRAY_DIMENSIONS_SEPERATOR.ToString() }, 3, StringSplitOptions.None);
            return dims.Any(current => uint.Parse(current) > 0);
        }
        #endregion


    } 
}
