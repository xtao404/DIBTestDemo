﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.DesignTimeClient.DataItemBrowser.Provider.Resources;
using RockwellAutomation.UI.Models;
using RockwellAutomation.DesignTimeClient.DataItemBrowser.Provider.Utils;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for PathElementFactoryTest and is intended
    ///to contain all PathElementFactoryTest Unit Tests
    ///</summary>
    [TestClass()]
    public class PathElementFactoryTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for CreateForProgramInternal
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.DTC.DataItemBrowser.dll")]
        public void PathElementFactory_CreateForProgramInternalTest()
        {
            string programName = "firstProgram"; 
            PathElement expected = new PathElement(); // only done for testing
            expected.DisplayName = programName;
            expected.HasChildren = false;
            expected.IsActive = true;
            expected.IsContainer = true;
            PathElement actual;
            actual = PathElementFactory_Accessor.CreateForProgramInternal(programName);
            Assert.AreEqual(expected.DisplayName, actual.DisplayName);
            Assert.AreEqual(expected.HasChildren, actual.HasChildren);
            Assert.AreEqual(expected.IsActive, actual.IsActive);
            Assert.AreEqual(expected.IsContainer, actual.IsContainer);
        }

        /// <summary>
        ///A test for CreateForProgram
        ///</summary>
        [TestMethod()]
        public void PathElementFactory_CreateForProgramTest()
        {
            ProgramContainer program = new ProgramContainer();
            program.Name = "SecondProgram";
            PathElement expected = new PathElement(); // only done for testing
            expected.DisplayName = program.Name;
            expected.HasChildren = false;
            expected.IsActive = true;
            expected.IsContainer = true;
            PathElement actual;
            actual = PathElementFactory.CreateForProgram(program);
            Assert.AreEqual(expected.DisplayName, actual.DisplayName);
            Assert.AreEqual(expected.HasChildren, actual.HasChildren);
            Assert.AreEqual(expected.IsActive, actual.IsActive);
            Assert.AreEqual(expected.IsContainer, actual.IsContainer);
        }

        /// <summary>
        ///A test for CreateForDataItemBaseInternal
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.DTC.DataItemBrowser.dll")]
        public void PathElementFactory_CreateForDataItemBaseInternalTest()
        {
            string dataItemBaseName = "firstDataItemBase";
            PathElement expected = new PathElement();
            expected.DisplayName = dataItemBaseName;
            expected.HasChildren = false;
            expected.IsActive = true;
            expected.IsContainer = false;

            PathElement actual = PathElementFactory_Accessor.CreateForDataItemBaseInternal(dataItemBaseName);
            Assert.AreEqual(expected.DisplayName, actual.DisplayName);
            Assert.AreEqual(expected.HasChildren, actual.HasChildren);
            Assert.AreEqual(expected.IsActive, actual.IsActive);
            Assert.AreEqual(expected.IsContainer, actual.IsContainer);
        }

        /// <summary>
        ///A test for CreateForDataItemBase
        ///</summary>
        [TestMethod()]
        public void PathElementFactory_CreateForDataItemBaseTest()
        {
            DataItemBase dataItemBase = new DataItemBase();
            //create Name property and assign it to the dataItemBase
            Property nameProp = new Property();
            nameProp.FieldName = DIResource.DI_COMMON_NAME;
            nameProp.FieldValue = "secondDataItemBase";
            dataItemBase.Add(nameProp);

            PathElement expected = new PathElement();
            expected.DisplayName = nameProp.FieldValue;
            expected.HasChildren = false;
            expected.IsActive = true;
            expected.IsContainer = false;

            PathElement actual = PathElementFactory.CreateForDataItemBase(dataItemBase);
            Assert.AreEqual(expected.DisplayName, actual.DisplayName);
            Assert.AreEqual(expected.HasChildren, actual.HasChildren);
            Assert.AreEqual(expected.IsActive, actual.IsActive);
            Assert.AreEqual(expected.IsContainer, actual.IsContainer);
        }

        /// <summary>
        ///A test for CreateForControllerInternal
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.DTC.DataItemBrowser.dll")]
        public void PathElementFactory_CreateForControllerInternalTest()
        {
            string controllerName = "firstController";
            PathElement expected = new PathElement(); // only done for testing
            expected.DisplayName = controllerName;
            expected.HasChildren = true;
            expected.IsActive = true;
            expected.IsContainer = true;
            PathElement actual;
            actual = PathElementFactory_Accessor.CreateForControllerInternal(controllerName);
            Assert.AreEqual(expected.DisplayName, actual.DisplayName);
            Assert.AreEqual(expected.HasChildren, actual.HasChildren);
            Assert.AreEqual(expected.IsActive, actual.IsActive);
            Assert.AreEqual(expected.IsContainer, actual.IsContainer);
        }

        /// <summary>
        ///A test for CreateForController
        ///</summary>
        [TestMethod()]
        public void PathElementFactory_CreateForControllerTest()
        {
            Controller controller = new Controller();
            controller.Name = "secondController";
            PathElement expected = new PathElement(); // only done for testing
            expected.DisplayName = controller.Name;
            expected.HasChildren = true;
            expected.IsActive = true;
            expected.IsContainer = true;
            PathElement actual = PathElementFactory.CreateForController(controller);
            Assert.AreEqual(expected.DisplayName, actual.DisplayName);
            Assert.AreEqual(expected.HasChildren, actual.HasChildren);
            Assert.AreEqual(expected.IsActive, actual.IsActive);
            Assert.AreEqual(expected.IsContainer, actual.IsContainer);
        }

     
    }
}
