﻿using System;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapClasses;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapKeyBoardNavClasses;
using DataItemBrowserUT.CodedUI.UIMaps.UIMapSearchFilterClasses;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace DataItemBrowserUT.CodedUI
{
    /// <summary>
    /// Summary description for CodedUITest1
    /// </summary>
    [CodedUITest]
    public class KeyBoardNavTest : CodedUITestBase
    {
        public KeyBoardNavTest()
        {
            //USE ONE OF THE CALLS TO SetProjectFile

            //Use this to call the Mock to avoid requiring the ROA stack to be running for the tests to run. This must be used to 
            //run the tests as part of the build process
            //SetProjectFile(new Tuple<string, string, string>("Controller1", "StructuresArraysBits_filter_V21", "Controller"));

            //Use this if you just want to have the tests run by development but do not want to have it run as part of the 
            //build process. All the methods must have [TestCategory("ExcludeOnAutoBuild")] so they are not run as part of the build.
            SetProjectFile("DataItemBrowserUT.CodedUI.Projects.Project12.VPD");
        }

        /// <summary>
        /// verify the DIB window is maximized when the correct keyboard shortcut keys 
        /// are selected
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void Keyboard_MaximizeWindow_Test()
        {
            //ACT
            this.UIMapKeyBoardNav.DIB_Keyboard_Maximize_Window();
            //ASSERT
            this.UIMapKeyBoardNav.DIB_Assert_DIBWindow_Maximized();
            //Clean-up
            this.UIMapKeyBoardNav.DIB_Keyboard_Minimize_Window();
            this.UIMapKeyBoardNav.UIDataItemBrowserHostWWindow.SetFocus();
        }

        /// <summary>
        /// Verify the DIB window is minimized when the correct keyboard
        /// shortcuts are slected
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void Keyboard_MinimizeWindow_Test()
        {
            //ACT
            this.UIMapKeyBoardNav.DIB_Keyboard_Minimize_Window();
            //ASSERT
            this.UIMapKeyBoardNav.DIB_Assert_DIBWindow_Minimized();
            this.UIMapKeyBoardNav.UIDataItemBrowserHostWWindow.SetFocus();
        }

        /// <summary>
        /// Verify using TAB in the DIB window navigates correctly
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void Keyboard_Tab_Test()
        {
           //ACT tab
           this.UIMapKeyBoardNav.DIB_Keyboard_Tab_1_In_Opened_DIB();
            //ASSERT
            this.UIMapKeyBoardNav.DIB_Assert_FilterContextMenu_Focus();
            //ACT shift-tab
           this.UIMapKeyBoardNav.DIB_Keyboard_Tab_1_From_FilterContext();
                        
           this.UIMapKeyBoardNav.DIB_Keyboard_ShiftTab_From_SearchText();
            //ASSERT
           this.UIMapKeyBoardNav.DIB_Assert_FilterContextMenu_Focus();
            
            this.UIMapKeyBoardNav.DIB_Keyboard_ShiftTab_From_FilterContext();
        }

        /// <summary>
        /// Verify using the ALT-Left, ALT-Right, ALT-Down, ALT-Up
        /// navigates correctly
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void Keyboard_ALT_Arrow_Test()
        {
            //ACT ALT_RightArrow
            this.UIMap.DIB_DataSources_ClickController1();
            this.UIMapKeyBoardNav.DIB_Keyboard_ALT_RightArrow_Controller1_TagsProps();
            DIB_WaitForSpinnerStop();
            //ASSERT
            this.UIMapKeyBoardNav.DIB_Assert_DataGrid_Alarm_PreDefArray1_Enabled();
            
            //ACT ALT_LeftArrow back to the datasources view 
            this.UIMapKeyBoardNav.DIB_Keyboard_ALT_LeftArrow_TagsProps_to_Controller();
            DIB_WaitForSpinnerStop();
            this.UIMapKeyBoardNav.DIB_Keyboard_ALT_LeftArrow_Controller_to_DataSources();
            DIB_WaitForSpinnerStop();
            //ASSERT
            this.UIMapKeyBoardNav.DIB_Assert_DataSources_Controller1_Selected();
            
            //ARRANGE Go back to DataSources and use ALT_RightArrow,ALT_DownArrow,ALT_UpArrow
            UIMap.ClickHomeCrumbButton();
            this.UIMap.DIB_DataSources_ClickController1();
            this.UIMapKeyBoardNav.DIB_Keyboard_ALT_RightArrow_Controller1_TagsProps();
            DIB_WaitForSpinnerStop();
            this.UIMapKeyBoardNav.DIB_Keyboard_ALT_DownArrow_4_Times_ALT_UpArrow_1_Times_ALT_Right_1Time();          
            //ASSERT
            this.UIMapKeyBoardNav.DIB_Assert_BreadCrumb_Button_Enabled("AOI_UDT_NoArrayMembers1");
            DIB_WaitForSpinnerStop();
            DIB_Assert_DataGridView_Contents(13);

        }

        /// <summary>
        /// Verify F1 opens the Help window
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void Keyboard_Open_Help_Test()
        {
            //ACT
            this.UIMapKeyBoardNav.DIB_Keyboard_F1_in_SearchText();
            //ASSERT
            this.UIMapKeyBoardNav.DIB_AssertMethod_HelpOpen();
            //CLEAN-UP          
            Keyboard.SendKeys("{F4}", System.Windows.Input.ModifierKeys.Alt);

            DIB_WaitForSpinnerStop();
        }

        /// <summary>
        /// Verify that CTRL+F puts focus in the SearchText         
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void Keyboard_Focus_SearchText_Test()
        {
            //ACT
            this.UIMapKeyBoardNav.DIB_Keyboard_CTRL_F_in_DataSources();
            //ASSERT
            this.UIMapSearchFilter.DIB_Assert_SearchFilterControl_SearchText_HasFocus();
        }

        /// <summary>
        /// Verify navigating around and back to the grid using ALT+L works 
        /// </summary>
        [TestMethod]
        [TestCategory("CodedUITest")]
        [TestCategory("ExcludeOnAutoBuild")]
        public void Keyboard_Focus_Grid_Test()
        {
            //ARRANGE ACT
            this.UIMap.DIB_DataSources_ClickController1();
            this.UIMapKeyBoardNav.DIB_Keyboard_ALT_RightArrow_Controller1_TagsProps();
            DIB_WaitForSpinnerStop();
            this.UIMapKeyBoardNav.DIB_KeyBoardNav_Various_Shortcuts_Focus_to_Grid();
            //ASSERT
            this.UIMapKeyBoardNav.DIB_Assert_BreadCrumb_Button_Enabled("AOI_UDT_NoArrayMembers1");
            DIB_WaitForSpinnerStop();
            DIB_Assert_DataGridView_Contents(13);
        }

        #region Additional test attributes

        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            CodedUITestBase.BaseClassInitialize(testContext);
        }

        [ClassCleanup]
        public static void MyClassCleanup()
        {
            CodedUITestBase.BaseClassCleanup();
        }

        //Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void MyTestInitialize()
        {
            SetupGridSerialization();

            //Open DIB
            this.UIMap.PTH_ClickTagBrowserButton();
            //kludge to ensure that DIB opens to the datasources view and not the last hightlighted item
            UIMap.PTH_EnterDotInReadTagTextBox();
            this.UIMap.PTH_ClickReadTagElipsisButton();

        }

        //Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void MyTestCleanup()
        {
            CleanUpGridSerialization();

            //close DIB
            UIMap.ClickHomeCrumbButton();
            DIB_WaitForSpinnerStop();
            UIMap.DIB_PressESC();
        }

        #endregion

       
        public UIMap UIMap
        {
            get
            {
                if ((this.map == null))
                {
                    this.map = new UIMap();
                }

                return this.map;
            }
        }

        public UIMapKeyBoardNav UIMapKeyBoardNav
        {
            get
            {
                if ((this.keyboardNavMap == null))
                {
                    this.keyboardNavMap = new UIMapKeyBoardNav();
                }
                return this.keyboardNavMap;
            }
        }

        public UIMapSearchFilter UIMapSearchFilter
        {
            get
            {
                if ((this.searchFilterMap == null))
                {
                    this.searchFilterMap = new UIMapSearchFilter();
                }
                return this.searchFilterMap;
            }
        }
        
        private UIMapSearchFilter searchFilterMap;
        private UIMap map;
        private UIMapKeyBoardNav keyboardNavMap;
    }
}
