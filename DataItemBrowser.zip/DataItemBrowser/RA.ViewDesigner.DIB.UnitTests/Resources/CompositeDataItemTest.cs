﻿using RockwellAutomation.UI.Resources;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RockwellAutomation.UI;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.ServiceFramework.DataTypes;
using System.Collections.ObjectModel;
using System.Collections;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace DataItemBrowserUT
{


    /// <summary>
    ///This is a test class for CompositeDataItemTest and is intended
    ///to contain all CompositeDataItemTest Unit Tests
    ///</summary>
    [TestClass()]
    public class CompositeDataItemTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            DIBQueryConnection.ProjectContext = null;
            DIBQueryConnection.PackageContext = null;
            DIBClientManagerForViewe.InitializeVieweSpecificClasses();
        }

        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for CompositeDataItem Constructor
        ///also tests CreateDataItemResourceIDList called from the constructor
        ///also tests toString
        ///</summary>
        [TestMethod()]
        public void CompositeDataItemConstructorTagBrowserTest()
        {
            List<IPathElement> list;

            //test controller tag
            CreateElementList(out list, 1);
            CompositeDataItem target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
            string guid = target.ToString();
            string expected = "<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>::3b9065b2-374f-4c50-beb5-d71a0f19ca8f.<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca8d";
            target = null;

            //test program tag
            CreateElementList(out list, 2);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
            guid = target.ToString();
            expected = "<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>::3b9065b2-374f-4c50-beb5-d71a0f19ca8f\\<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca8e.<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca8d.<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca90";
            Assert.AreEqual(expected, guid);
            target = null;

            //test array bit
            CreateElementList(out list, 3);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
            guid = target.ToString();
            expected = "<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>::3b9065b2-374f-4c50-beb5-d71a0f19ca8f.<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca8d[0].8";
            Assert.AreEqual(expected, guid);
            target = null;

            //test array bit that is created differently DFCTS00294103
            CreateElementList(out list, 4);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
            guid = target.ToString();
            expected = "<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>::3b9065b2-374f-4c50-beb5-d71a0f19ca8f.<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca8d[0].22";
            Assert.AreEqual(expected, guid);
            target = null;

            // HMIDevice ::MyVieweProject01.Hardware.Temperature.3
            CreateElementList(out list, 5);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
            guid = target.ToString();
            expected = "<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>::3b9065b2-374f-4c50-beb5-d71a0f19ca91.<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca8d.<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca90.3";
            Assert.AreEqual(expected, guid);
            target = null;

            //test array tag member metaData
            CreateElementList(out list, 6);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
            guid = target.ToString();
            expected = "<9e5a3574-9c88-4902-a681-793eb4599133>::91f4fd46-12f3-4d05-891c-d8e2b3a47744.<9e5a3574-9c88-4902-a681-793eb4599133>3829105f-4734-4205-beb5-d71a0f19ca9a[0].@EngineeringUnit";
            Assert.AreEqual(expected, guid);
            target = null;

            //test tag member metadata
            CreateElementList(out list, 7);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
            guid = target.ToString();
            expected = "<9e5a3574-9c88-4902-a681-793eb4599133>::e6f81051-0255-4a2b-bcc1-610ee918c274\\<9e5a3574-9c88-4902-a681-793eb4599133>3b9065b2-374f-4c50-8ce3-5f1006ac5812.<9e5a3574-9c88-4902-a681-793eb4599133>18f6c927-2ed3-4dad-b070-f87727437980.<9e5a3574-9c88-4902-a681-793eb4599133>92063495-0bae-4d80-b1c6-920fa7c980c7.@Name";
            Assert.AreEqual(expected, guid);
            target = null;

            //test tag member bit metadata
            CreateElementList(out list, 8);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);
            guid = target.ToString();
            expected = "<9e5a3574-9c88-4902-a681-793eb4599133>::91f4fd46-12f3-4d05-891c-d8e2b3a47744.<9e5a3574-9c88-4902-a681-793eb4599133>3829105f-4734-4205-beb5-d71a0f19ca9a[0].8.@State1";
            Assert.AreEqual(expected, guid);
            target = null;

        }
        /// <summary>
        ///A test for CompositeDataItem Constructor
        ///also tests CreateDataItemResourceIDList called from the constructor
        ///also tests toString
        ///</summary>
        [TestMethod()]
        public void CompositeDataItemConstructorDataTypeBrowserTest()
        {
            List<IPathElement> list;

            //test user-defined datatype
            CreateDataTypeList(out list, 1);
            CompositeDataItem target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser);
            string guid = target.ToString();
            string expected = "<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca92";
            Assert.AreEqual(expected, guid);
            target = null;

            //test pre-defined (product defined) datatype
            CreateDataTypeList(out list, 2);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser);
            guid = target.ToString();
            expected = "<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca92";
            Assert.AreEqual(expected, guid);
            target = null;

            //test module-defined datatype
            CreateDataTypeList(out list, 3);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.DataTypeBrowser);
            guid = target.ToString();
            expected = "<3b9065b2-374f-4c50-ab54-a98ceb1f0ad6>3b9065b2-374f-4c50-beb5-d71a0f19ca92";
            Assert.AreEqual(expected, guid);
            target = null;
        }

        private void CreateDataTypeList(out List<IPathElement> list, int listType)
        {
            list = new List<IPathElement>();
            switch (listType)
            {
                case 1: //user-defined
                    DataItemBase dataType1 = new DataItemBase()
                    {
                        CommonID = PathElementUtility.getTest_DATATYPE_COMMON_ID().ToString(),
                        CommonName = "user-defined Datatype",
                        CommonResourceType = TypeIdentifiers.ResourceType_DataType.ToString(),
                        CommonRefTargetDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString()
                    };
                    IPathElement dataTypePath1 = PathElementFactory.Instance().CreateDataTypePathElement(dataType1, DataTypePECategory.User);
                    list.Add(dataTypePath1);
                    break;
                case 2: //pre-defined
                    DataItemBase dataType2 = new DataItemBase()
                    {
                        CommonID = PathElementUtility.getTest_DATATYPE_COMMON_ID().ToString(),
                        CommonName = "user-defined Datatype",
                        CommonResourceType = TypeIdentifiers.ResourceType_DataType.ToString(),
                        CommonRefTargetDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString()
                    };
                    IPathElement dataTypePath2 = PathElementFactory.Instance().CreateDataTypePathElement(dataType2, DataTypePECategory.Product);
                    list.Add(dataTypePath2);
                    break;
                case 3: //module-defined
                    DataItemBase dataType3 = new DataItemBase()
                    {
                        CommonID = PathElementUtility.getTest_DATATYPE_COMMON_ID().ToString(),
                        CommonName = "user-defined Datatype",
                        CommonResourceType = TypeIdentifiers.ResourceType_DataType.ToString(),
                        CommonRefTargetDBId = PathElementUtility.getTest_DBID_COMMON_ID().ToString()
                    };
                    IPathElement dataTypePath3 = PathElementFactory.Instance().CreateDataTypePathElement(dataType3, DataTypePECategory.Module);
                    list.Add(dataTypePath3);
                    break;
                default:
                    Assert.Fail("Need to create the IPathElement List, the listType passed in is not implemented");
                    break;
            }

        }

        /// <summary>
        /// creates a IPathElement List given an integer representing a type of list to create
        /// </summary>
        /// <param name="list"></param> The list that is created
        /// <param name="listType"></param> A number that identifies a different list to be made for validating that the CompositeDataItem is created correctly
        /// for different paths containing different types of elements
        private void CreateElementList(out List<IPathElement> list, int listType)
        {
            list = new List<IPathElement>();
            switch (listType)
            {
                case 1: //controller tag
                    list.Add(PathElementUtility.Instance().CreateControllerPathElement("Controller1"));
                    list.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
                    list.Add(PathElementUtility.Instance().CreateTagPathElement("BOOL_UDT_Array1", "[1]", true));
                    break;

                case 2: //program tag
                    list.Add(PathElementUtility.Instance().CreateControllerPathElement("Controller1"));
                    list.Add(PathElementUtility.Instance().CreateProgramsPathElement());
                    list.Add(PathElementUtility.Instance().CreateProgramPathElement("Program1"));
                    list.Add(PathElementUtility.Instance().CreateTagPathElement("Tag1", "", true));
                    list.Add(PathElementUtility.Instance().CreateDataTypeMemberPathElement("member1", ""));
                    break;

                case 3: //array bit ::Controller1.BOOL_UDT_Array1[0].8                    
                    list.Add(PathElementUtility.Instance().CreateControllerPathElement("Controller1"));
                    list.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
                    list.Add(PathElementUtility.Instance().CreateTagPathElement("BOOL_UDT_Array1", "[1]", true));
                    list.Add(PathElementUtility.Instance().CreateTagPathElement("BOOL_UDT_Array1[0]", "", true));

                    DataItemBase dataItemBit3 = new DataItemBase() { CommonName = "  8", IsStructured = false };
                    IPathElement bitPath3 = PathElementFactory.Instance().CreatePathElement(dataItemBit3);
                    list.Add(bitPath3);
                    break;

                case 4: //array bit ::Controller1.BOOL_UDT_Array1[0].22 TESTS DFCTS00294103 
                    list.Add(PathElementUtility.Instance().CreateControllerPathElement("Controller1"));
                    list.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
                    list.Add(PathElementUtility.Instance().CreateTagPathElement("BOOL_UDT_Array1", "[1]", true));
                    list.Add(PathElementUtility.Instance().CreateTagPathElement("BOOL_UDT_Array1[0]", ""));

                    //this will test the or path for the check for if it is a bit or not DFCTS00294103
                    DataItemBase dataItemBit4 = new DataItemBase() { CommonID = PathElementUtility.getTest_TAG_COMMON_ID().ToString(), CommonName = "  22", IsStructured = false};
                    IPathElement bitPath4 = PathElementFactory.Instance().CreatePathElement(dataItemBit4);
                    list.Add(bitPath4);
                    break;

                case 5: // HMIDevice ::MyVieweProject01.Hardware.Temperature.3
                    list.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("MyVieweProject01"));
                    list.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
                    list.Add(PathElementUtility.Instance().CreateTagPathElement("Hardware", "", true));
                    list.Add(PathElementUtility.Instance().CreateDataTypeMemberPathElement("Temperature", ""));

                    DataItemBase dataItemBit5 = new DataItemBase() { CommonID = PathElementUtility.getTest_DATATYPE_MEMBER_COMMON_ID().ToString(), CommonName = "  3", IsStructured = false };
                    IPathElement bitPath5 = PathElementFactory.Instance().CreatePathElement(dataItemBit5);
                    list.Add(bitPath5);
                    break;

                case 6: //tag Member with MetaData ::Controller1.BOOL_UDT_Array1[0].@Name                    
                    DataItemBase dataItemController6 = new DataItemBase() {
                        CommonID = "hi: 10517309507224423685\nlo: 9880010150732134212\n",
                        CommonName = "Controller1",
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403191811\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n"
                    };
                    IPathElement controllerPath6 = PathElementFactory.Instance().CreatePathElement(dataItemController6);
                    list.Add(controllerPath6);

                    DataItemBase dataItemTagsAndProp6 = new DataItemBase() {
                        CommonID = "hi: 10517309507224423685\nlo: 9880010150732134212\n",
                        CommonName = "Tags and Properties",
                        CommonResourceType = "hi: 17334120166104580409\nlo: 10307459619794856573\n"
                    };
                    IPathElement tagsAndPropsPath6 = PathElementFactory.Instance().CreatePathElement(dataItemTagsAndProp6);
                    list.Add(tagsAndPropsPath6);

                    DataItemBase dataItemTag6 = new DataItemBase() {
                        CommonID = "hi: 4046783741571645957\nlo: 13742126344913406618\n",
                        CommonName = "BOOL_UDT_Array1",
                        CommonDataType = "[1]",
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403257376\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                        IsStructured = true
                    };
                    IPathElement tagPath6 = PathElementFactory.Instance().CreatePathElement(dataItemTag6);
                    list.Add(tagPath6);


                    DataItemBase dataItemMember6 = new DataItemBase() {
                        CommonID = "hi: 15200224795241303326\nlo: 9607636616225992912\n",
                        CommonName = "BOOL_UDT_Array1[0]",
                        CommonDataType = String.Empty,
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403257376\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                        IsStructured = true
                    };
                    IPathElement memberPath6 = PathElementFactory.Instance().CreatePathElement(dataItemMember6);
                    list.Add(memberPath6);

                    DataItemBase dibItemMeta6 = MetaDataHelper.MetaDataEU();
                    IPathElement bitPath6 = PathElementFactory.Instance().CreatePathElement(dibItemMeta6);
                    list.Add(bitPath6);
                    break;
                    
                case 7: //program tag member metadata

                    DataItemBase dataItemController7 = new DataItemBase() {
                        CommonID = "hi: 16643070363065207339\nlo: 13601259066303758964\n",
                        CommonName = "Controller1",
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403191811\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                    };
                    IPathElement controllerPath7 = PathElementFactory.Instance().CreatePathElement(dataItemController7);
                    list.Add(controllerPath7);


                    DataItemBase dataItemProgram7 = new DataItemBase() {
                        CommonID = "hi: 4292042260990610512\nlo: 10152062507459303442\n",
                        CommonName = "Program1",
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403257348\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                    };
                    IPathElement programPath7 = PathElementFactory.Instance().CreatePathElement(dataItemProgram7);
                    list.Add(programPath7);

                    DataItemBase dataItemTag7 = new DataItemBase()
                    {
                        CommonID = "hi: 1798846271307599277\nlo: 12713934938710440320\n",
                        CommonName = "Tag1",
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403257376\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                    };
                    IPathElement tagPath7 = PathElementFactory.Instance().CreatePathElement(dataItemTag7);
                    list.Add(tagPath7);

                    DataItemBase dataItemMember7 = new DataItemBase()
                    {
                        CommonID = "hi: 10522155394148486528\nlo: 12810086786039120071\n",
                        CommonName = "member1",
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403257361\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                    };
                    dataItemMember7.IsStructured = false;
                    IPathElement memberPath7 = PathElementFactory.Instance().CreatePathElement(dataItemMember7);
                    list.Add(memberPath7);
                 
                    DataItemBase dibItemMeta7 = MetaDataHelper.MetaDataName();
                    IPathElement bitPath7 = PathElementFactory.Instance().CreatePathElement(dibItemMeta7);
                    list.Add(bitPath7);
                    break;


                case 8: //program tag member bit metadata

                    DataItemBase dataItemController8 = new DataItemBase()
                    {
                        CommonID = "hi: 10517309507224423685\nlo: 9880010150732134212\n",
                        CommonName = "Controller1",
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403191811\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                    };
                    IPathElement controllerPath8 = PathElementFactory.Instance().CreatePathElement(dataItemController8);
                    list.Add(controllerPath8);
                    
                    DataItemBase dataItemTagsAndProp8 = new DataItemBase(){
                        CommonID = "hi: 10517309507224423685\nlo: 9880010150732134212\n",
                        CommonName = "ags and Properties",
                        CommonResourceType = "hi: 17334120166104580409\nlo: 10307459619794856573\n",
                    };
                    IPathElement tagsAndPropsPath8 = PathElementFactory.Instance().CreatePathElement(dataItemTagsAndProp8);
                    list.Add(tagsAndPropsPath8);
                    
                    DataItemBase dataItemTag8 = new DataItemBase()
                    {
                        CommonID = "hi: 4046783741571645957\nlo: 13742126344913406618\n",
                        CommonName = "BOOL_UDT_Array1",
                        CommonDataType = "[1]",
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403257376\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                        IsStructured = true
                    };
                    IPathElement tagPath8 = PathElementFactory.Instance().CreatePathElement(dataItemTag8);
                    list.Add(tagPath8);
                 
                    DataItemBase dataItemMember8 = new DataItemBase()
                    {
                        CommonID = "hi: 15200224795241303326\nlo: 9607636616225992912\n",
                        CommonName = "BOOL_UDT_Array1[0]",
                        CommonDataType = String.Empty,
                        CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403257376\n",
                        CommonDBId = "hi: 11410491380855228674\nlo: 11998004192512414003\n",
                        IsStructured = true
                    };
                    IPathElement memberPath8 = PathElementFactory.Instance().CreatePathElement(dataItemMember8);
                    list.Add(memberPath8);

                    DataItemBase dataItemBit8 = new DataItemBase()
                    {
                        CommonName = "  8",
                        IsStructured = false
                    };
                    IPathElement bitPath8 = PathElementFactory.Instance().CreatePathElement(dataItemBit8);
                    list.Add(bitPath8);

                    DataItemBase dibItemMeta8 = MetaDataHelper.MetaDataState1();
                    IPathElement bitPathMeta8 = PathElementFactory.Instance().CreatePathElement(dibItemMeta8);
                    list.Add(bitPathMeta8);
                    break;

                default:
                    Assert.Fail("Need to create the IPathElement List, the listType passed in is not implemented");
                    break;
            }

        }

        /// <summary>
        ///A test for CollectionOfData
        ///</summary>
        [TestMethod()]
        public void collectionOfDataTest()
        {
            List<IPathElement> list;

            //test controller tag
            CreateElementList(out list, 1);
            CompositeDataItem target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);

            Assert.AreEqual(2, target.CollectionOfData.Count);
            int i = 0;
            foreach (RockwellAutomation.UI.Resources.CompositeDataItem.DataItemResourceID dataitem in target.CollectionOfData)
            {
                switch (i)
                {
                    case 0:
                        Assert.AreEqual(PathElementUtility.getTest_CONTROLLER_COMMON_ID(), dataitem.ResourceID);
                        Assert.AreEqual(TypeIdentifiers.getResourceType_Controller(), dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    case 1:
                        Assert.AreEqual(PathElementUtility.getTest_TAG_COMMON_ID(), dataitem.ResourceID);
                        Assert.AreEqual(TypeIdentifiers.ResourceType_Tag, dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    default:
                        Assert.Fail("more dataitems in list than expected");
                        break;
                }
                i++;
            }
            target = null;

            //test program tag
            CreateElementList(out list, 2);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);

            Assert.AreEqual(4, target.CollectionOfData.Count);
            i = 0;
            foreach (RockwellAutomation.UI.Resources.CompositeDataItem.DataItemResourceID dataitem in target.CollectionOfData)
            {
                switch (i)
                {
                    case 0:
                        Assert.AreEqual(PathElementUtility.getTest_CONTROLLER_COMMON_ID(), dataitem.ResourceID);
                        Assert.AreEqual(TypeIdentifiers.getResourceType_Controller(), dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    case 1:
                        Assert.AreEqual(PathElementUtility.getTest_PROGRAM_COMMON_ID(), dataitem.ResourceID);
                        Assert.AreEqual(TypeIdentifiers.ResourceType_Program, dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    case 2:
                        Assert.AreEqual(dataitem.ResourceID, PathElementUtility.getTest_TAG_COMMON_ID());
                        Assert.AreEqual(dataitem.ResourceTypeID, TypeIdentifiers.ResourceType_Tag);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    case 3:
                        Assert.AreEqual(dataitem.ResourceID, PathElementUtility.getTest_DATATYPE_MEMBER_COMMON_ID());
                        Assert.AreEqual(dataitem.ResourceTypeID, TypeIdentifiers.ResourceType_DataTypeMember);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    default:
                        Assert.Fail("more dataitems in list than expected");
                        break;
                }
                i++;
            }
            target = null;

            //test array bit
            CreateElementList(out list, 3);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);

            Assert.AreEqual(2, target.CollectionOfData.Count);
            i = 0;
            foreach (RockwellAutomation.UI.Resources.CompositeDataItem.DataItemResourceID dataitem in target.CollectionOfData)
            {
                switch (i)
                {
                    case 0:
                        Assert.AreEqual(PathElementUtility.getTest_CONTROLLER_COMMON_ID(), dataitem.ResourceID);
                        Assert.AreEqual(TypeIdentifiers.getResourceType_Controller(), dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    case 1:
                        Assert.AreEqual(PathElementUtility.getTest_TAG_COMMON_ID(), dataitem.ResourceID);
                        Assert.IsNull(dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual("8", dataitem.Bit.Trim());
                        Assert.AreEqual("[0]", dataitem.Dimensions);
                        break;
                    default:
                        Assert.Fail("more dataitems in list than expected");
                        break;
                }
                i++;
            }
            target = null;

            //test another array bit
            CreateElementList(out list, 4);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);

            Assert.AreEqual(2, target.CollectionOfData.Count);
            i = 0;
            foreach (RockwellAutomation.UI.Resources.CompositeDataItem.DataItemResourceID dataitem in target.CollectionOfData)
            {
                switch (i)
                {
                    case 0:
                        Assert.AreEqual(PathElementUtility.getTest_CONTROLLER_COMMON_ID(), dataitem.ResourceID);
                        Assert.AreEqual(TypeIdentifiers.getResourceType_Controller(), dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    case 1:
                        Assert.AreEqual(PathElementUtility.getTest_TAG_COMMON_ID(), dataitem.ResourceID);
                        Assert.IsNull(dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual("22", dataitem.Bit.Trim());
                        Assert.AreEqual("[0]", dataitem.Dimensions);
                        break;
                    default:
                        Assert.Fail("more dataitems in list than expected");
                        break;
                }
                i++;
            }
            target = null;

            //test HMI device
            CreateElementList(out list, 5);
            target = new CompositeDataItem(list, DIBViewItemBase.VisualPerspectiveEnum.TagBrowser);

            Assert.AreEqual(3, target.CollectionOfData.Count);
            i = 0;
            foreach (RockwellAutomation.UI.Resources.CompositeDataItem.DataItemResourceID dataitem in target.CollectionOfData)
            {
                switch (i)
                {
                    case 0:
                        Assert.AreEqual(PathElementUtility.getTest_HMIDEVICE_COMMON_ID(), dataitem.ResourceID);
                        Assert.AreEqual(TypeIdentifiers.ResourceType_HMIDevice, dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    case 1:
                        Assert.AreEqual(PathElementUtility.getTest_TAG_COMMON_ID(), dataitem.ResourceID);
                        Assert.AreEqual(TypeIdentifiers.ResourceType_Tag, dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual(string.Empty, dataitem.Bit);
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    case 2:
                        Assert.AreEqual(PathElementUtility.getTest_DATATYPE_MEMBER_COMMON_ID(), dataitem.ResourceID);
                        Assert.IsNull(dataitem.ResourceTypeID);
                        Assert.AreEqual(PathElementUtility.getTest_DBID_COMMON_ID(), dataitem.DbID);
                        Assert.AreEqual("3", dataitem.Bit.Trim());
                        Assert.AreEqual(string.Empty, dataitem.Dimensions);
                        break;
                    default:
                        Assert.Fail("more dataitems in list than expected");
                        break;
                }
                i++;
            }
            target = null;
        }


    }
}
