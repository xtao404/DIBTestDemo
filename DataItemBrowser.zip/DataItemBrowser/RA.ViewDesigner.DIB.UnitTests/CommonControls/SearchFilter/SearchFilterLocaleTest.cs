﻿using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using RockwellAutomation.UI;
using RockwellAutomation.UI.CommonControls;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using AvalonUnitTesting;
using RockwellAutomation.UI.CommonControls.ViewModels;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.CommonControls.Properties;

namespace DataItemBrowserUT
{
    /// <summary>
    ///This is a test class for SearchFilterControlTest and is intended
    ///to contain all SearchFilterControlTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SearchFilterLocaleTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        static Dictionary<string, string> _base = new Dictionary<string, string>();

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            // Get all of the "base" strings.
            // Text & Tooltips
            _base["SEARCH_PLACEHOLDER"] = Resources.SEARCH_PLACEHOLDER;
            _base["CLEAR_SEARCH"] = Resources.CLEAR_SEARCH;
            _base["SEARCH_CTX_MENU_TOOLTIP"] = Resources.SEARCH_CTX_MENU_TOOLTIP;
            _base["SEARCH_RECENT_TOOLTIP"] = Resources.SEARCH_RECENT_TOOLTIP;
            // Syntax Error Strings
            _base["ERROR_SEARCH_BLANK_SPACE_MISSING"] = Resources.ERROR_SEARCH_BLANK_SPACE_MISSING;
            _base["ERROR_SEARCH_CANNOT_START_WITH_SPACE"] = Resources.ERROR_SEARCH_CANNOT_START_WITH_SPACE;
            _base["ERROR_SEARCH_CLOSE_PARENTHESIS_MISSING"] = Resources.ERROR_SEARCH_CLOSE_PARENTHESIS_MISSING;
            _base["ERROR_SEARCH_DELETE_BLANK_SPACES"] = Resources.ERROR_SEARCH_DELETE_BLANK_SPACES;
            _base["ERROR_SEARCH_EXPECTED_OPERATOR"] = Resources.ERROR_SEARCH_EXPECTED_OPERATOR;
            _base["ERROR_SEARCH_FILTER_STATEMENT_MISSING"] = Resources.ERROR_SEARCH_FILTER_STATEMENT_MISSING;
            _base["ERROR_SEARCH_FILTER_VALUE_MISSING"] = Resources.ERROR_SEARCH_FILTER_VALUE_MISSING;
            _base["ERROR_SEARCH_KEYWORD_INCORRECTLY_USED"] = Resources.ERROR_SEARCH_KEYWORD_INCORRECTLY_USED;
            _base["ERROR_SEARCH_OPEN_PARENTHESIS_MISSING"] = Resources.ERROR_SEARCH_OPEN_PARENTHESIS_MISSING;
            _base["ERROR_SEARCH_PARENTHESES_CANNOT_BE_NESTED"] = Resources.ERROR_SEARCH_PARENTHESES_CANNOT_BE_NESTED;
            _base["ERROR_SEARCH_PARENTHESES_MUST_SURROUND_FILTER_VALUES"] = Resources.ERROR_SEARCH_PARENTHESES_MUST_SURROUND_FILTER_VALUES;
            _base["ERROR_SEARCH_QUOTATION_MARKS_INCORRECT"] = Resources.ERROR_SEARCH_QUOTATION_MARKS_INCORRECT;
            _base["ERROR_SEARCH_QUOTATION_MARK_MISSING"] = Resources.ERROR_SEARCH_QUOTATION_MARK_MISSING;
            _base["ERROR_SEARCH_SEARCHING_NOT_SUPPORTED"] = Resources.ERROR_SEARCH_SEARCHING_NOT_SUPPORTED;
            _base["ERROR_SEARCH_UNEXPECTED_WHITESPACE"] = Resources.ERROR_SEARCH_UNEXPECTED_WHITESPACE;
        }
        //
        //Use ClassCleanup to run code after all tests in a class have run
        [ClassCleanup()]
        public static void MyClassCleanup()
        {
            _base.Clear();
            _base = null;
        }

        /// <summary>
        /// Use TestInitialize to run code before running each test
        /// </summary>
        [TestInitialize()]
        public void MyTestInitialize()
        {
            ClearLocale();
        }
        
        /// <summary>
        /// Use TestCleanup to run code after each test has run
        /// </summary>
        [TestCleanup()]
        public void MyTestCleanup()
        {
            ClearLocale();
        }
        
        #endregion

        static void SetLocale(string lcl)
        {
            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = new System.Globalization.CultureInfo(lcl);
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = new System.Globalization.CultureInfo(lcl);
        }

        static void ClearLocale()
        {
            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = null;
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = null;
        }

        /// <summary>
        /// Helper to compare the current locale strings vs. an expected set of strings.
        /// </summary>
        internal Dictionary<string, string> CompareAllLocalStrings(Dictionary<string, string> compareTo, bool expectMatch = true)
        {
            Dictionary<string, string> ret = new Dictionary<string, string>();

            SearchFilterControl target = new SearchFilterControl();
            PrivateType pt = new PrivateType(typeof(Resources));

            foreach (string key in compareTo.Keys)
            {
                string actual = (string)pt.GetStaticFieldOrProperty(key);
                ret[key] = actual;
                Assert.IsTrue(actual.Length > 0);
                Assert.IsFalse(String.IsNullOrEmpty(actual));
                string expected = compareTo[key];
                if (expectMatch)
                    Assert.AreEqual<string>(actual, expected);
                else
                    Assert.AreNotEqual<string>(actual, expected);
            }

            return ret;
        }

        /// <summary>
        /// Test variations of English, these should all match.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_en()
        {
            SetLocale("en");
            CompareAllLocalStrings(_base);
            SetLocale("en-US");
            CompareAllLocalStrings(_base);
            SetLocale("en-CA");
            CompareAllLocalStrings(_base);
            SetLocale("en-BZ");
            CompareAllLocalStrings(_base);
            SetLocale("en-IN");
            CompareAllLocalStrings(_base);
            SetLocale("en-IE");
            CompareAllLocalStrings(_base);
            SetLocale("en-NZ");
            CompareAllLocalStrings(_base);
            SetLocale("en-PH");
            CompareAllLocalStrings(_base);
            SetLocale("en-AU");
            CompareAllLocalStrings(_base);
            SetLocale("en-SG");
            CompareAllLocalStrings(_base);
            SetLocale("en-GB");
            CompareAllLocalStrings(_base);
        }

        /// <summary>
        /// Test variations of Portugese, these should all match each other,
        /// but be different from the English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_pt()
        {
            SetLocale("pt");
            Dictionary<string, string> curLocale = CompareAllLocalStrings(_base, false);
            SetLocale("pt-BR");
            CompareAllLocalStrings(curLocale);
            SetLocale("pt-PT");
            CompareAllLocalStrings(curLocale);

            string searchTerm = "pesquisa";
            Assert.IsTrue(curLocale["SEARCH_PLACEHOLDER"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["CLEAR_SEARCH"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_RECENT_TOOLTIP"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_CTX_MENU_TOOLTIP"].ToLower().Contains(searchTerm));
        }

        /// <summary>
        /// Test variations of French, these should all match each other,
        /// but be different from the English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_fr()
        {
            SetLocale("fr");
            Dictionary<string, string> curLocale = CompareAllLocalStrings(_base, false);
            SetLocale("fr-FR");
            CompareAllLocalStrings(curLocale);
            SetLocale("fr-CA");
            CompareAllLocalStrings(curLocale);
            SetLocale("fr-BE");
            CompareAllLocalStrings(curLocale);
            SetLocale("fr-CH");
            CompareAllLocalStrings(curLocale);

            string searchTerm = "recherche";
            Assert.IsTrue(curLocale["SEARCH_PLACEHOLDER"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["CLEAR_SEARCH"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_RECENT_TOOLTIP"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_CTX_MENU_TOOLTIP"].ToLower().Contains(searchTerm));
        }

        /// <summary>
        /// Test variations of Italian, these should all match each other,
        /// but be different from the English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_it()
        {
            SetLocale("it");
            Dictionary<string, string> curLocale = CompareAllLocalStrings(_base, false);
            SetLocale("it-IT");
            CompareAllLocalStrings(curLocale);
            SetLocale("it-CH");
            CompareAllLocalStrings(curLocale);

            string searchTerm = "ricerc";
            Assert.IsTrue(curLocale["SEARCH_PLACEHOLDER"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["CLEAR_SEARCH"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_RECENT_TOOLTIP"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_CTX_MENU_TOOLTIP"].ToLower().Contains(searchTerm));
        }

        /// <summary>
        /// Test variations of German, these should all match each other,
        /// but be different from the English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_de()
        {
            SetLocale("de");
            Dictionary<string, string> curLocale = CompareAllLocalStrings(_base, false);
            SetLocale("de-DE");
            CompareAllLocalStrings(curLocale);
            SetLocale("de-AT");
            CompareAllLocalStrings(curLocale);
            SetLocale("de-LI");
            CompareAllLocalStrings(curLocale);
            SetLocale("de-LU");
            CompareAllLocalStrings(curLocale);
            SetLocale("de-CH");
            CompareAllLocalStrings(curLocale);

            string searchTerm = "such";
            Assert.IsTrue(curLocale["SEARCH_PLACEHOLDER"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["CLEAR_SEARCH"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_RECENT_TOOLTIP"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_CTX_MENU_TOOLTIP"].ToLower().Contains(searchTerm));
        }

        /// <summary>
        /// Test variations of Spanish, these should all match each other,
        /// but be different from the English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_es()
        {
            SetLocale("es");
            Dictionary<string, string> curLocale = CompareAllLocalStrings(_base, false);
            SetLocale("es-ES");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-MX");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-AR");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-BO");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-CL");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-CO");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-CR");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-DO");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-EC");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-SV");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-GT");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-HN");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-NI");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-PA");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-PY");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-PE");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-PR");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-US");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-UY");
            CompareAllLocalStrings(curLocale);
            SetLocale("es-VE");
            CompareAllLocalStrings(curLocale);

            string searchTerm = "búsqueda";
            Assert.IsTrue(curLocale["SEARCH_PLACEHOLDER"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["CLEAR_SEARCH"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_RECENT_TOOLTIP"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_CTX_MENU_TOOLTIP"].ToLower().Contains(searchTerm));
        }

        /// <summary>
        /// Test variations of Chinese, these should all match each other,
        /// but be different from the English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_zh()
        {
            SetLocale("zh");
            Dictionary<string, string> curLocale = CompareAllLocalStrings(_base, false);
            SetLocale("zh-CN");
            CompareAllLocalStrings(curLocale);
            SetLocale("zh-HK");
            CompareAllLocalStrings(curLocale);
            SetLocale("zh-Hans");
            CompareAllLocalStrings(curLocale);
            SetLocale("zh-Hant");
            CompareAllLocalStrings(curLocale);
            SetLocale("zh-SG");
            CompareAllLocalStrings(curLocale);
            SetLocale("zh-TW");
            CompareAllLocalStrings(curLocale);

            string searchTerm = "搜";
            Assert.IsTrue(curLocale["SEARCH_PLACEHOLDER"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["CLEAR_SEARCH"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_RECENT_TOOLTIP"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_CTX_MENU_TOOLTIP"].ToLower().Contains(searchTerm));
        }

        /// <summary>
        /// Test variations of Japanese, these should all match each other,
        /// but be different from the English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_ja()
        {
            SetLocale("ja");
            Dictionary<string, string> curLocale = CompareAllLocalStrings(_base, false);
            SetLocale("ja-JP");
            CompareAllLocalStrings(curLocale);

            string searchTerm = "検";
            Assert.IsTrue(curLocale["SEARCH_PLACEHOLDER"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["CLEAR_SEARCH"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_RECENT_TOOLTIP"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_CTX_MENU_TOOLTIP"].ToLower().Contains(searchTerm));
        }

        /// <summary>
        /// Test variations of Korean, these should all match each other,
        /// but be different from the English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_ko()
        {
            SetLocale("ko");
            Dictionary<string, string> curLocale = CompareAllLocalStrings(_base, false);
            SetLocale("ko-KR");
            CompareAllLocalStrings(curLocale);

            string searchTerm = "색";
            Assert.IsTrue(curLocale["SEARCH_PLACEHOLDER"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["CLEAR_SEARCH"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_RECENT_TOOLTIP"].ToLower().Contains(searchTerm));
            Assert.IsTrue(curLocale["SEARCH_CTX_MENU_TOOLTIP"].ToLower().Contains(searchTerm));
        }

        /// <summary>
        /// Test unsuported locales, these should default to English.
        /// </summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.Search.dll")]
        public void SearchFilterLocalization_unsupported()
        {
            SetLocale("af"); // African - not supported
            CompareAllLocalStrings(_base);
            SetLocale("ar"); // Arabic - not supported
            CompareAllLocalStrings(_base);
            SetLocale("ar-EG"); // Arabic - not supported
            CompareAllLocalStrings(_base);
            SetLocale("ar-QA"); // Arabic - not supported
            CompareAllLocalStrings(_base);
            SetLocale("ar-SA"); // Arabic - not supported
            CompareAllLocalStrings(_base);
            SetLocale("ar-DZ"); // Arabic - not supported
            CompareAllLocalStrings(_base);
            SetLocale("nl"); // Dutch - not supported
            CompareAllLocalStrings(_base);
            SetLocale("el"); // Greek - not supported
            CompareAllLocalStrings(_base);
            SetLocale("el-GR"); // Greek - not supported
            CompareAllLocalStrings(_base);
            SetLocale("sa"); // Sanskrit - not supported
            CompareAllLocalStrings(_base);
            SetLocale("sa-IN"); // Sanskrit - not supported
            CompareAllLocalStrings(_base);
            SetLocale("sv"); // Swedish - not supported
            CompareAllLocalStrings(_base);
            SetLocale("sv-FI"); // Swedish - not supported
            CompareAllLocalStrings(_base);
            SetLocale("sv-SE"); // Swedish - not supported
            CompareAllLocalStrings(_base);
        }
    }
}
