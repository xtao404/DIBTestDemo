﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TagFilterControl.Controls.PreFilter
{
    /// <summary>
    /// Interaction logic for FilterDIBManager.xaml
    /// </summary>
    public partial class FilterDIBManager : UserControl
    {
        public FilterDIBManager()
        {
            InitializeComponent();
            this.PreFilterDIBVM = new FilterDIBManagerViewModel();
            this.DataContext = this.PreFilterDIBVM;
        }

        public FilterDIBManagerViewModel PreFilterDIBVM { get; set; }
    }
}
