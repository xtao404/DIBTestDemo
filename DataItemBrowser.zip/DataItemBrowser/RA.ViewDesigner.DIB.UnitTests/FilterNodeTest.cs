﻿using RockwellAutomation.UI;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.ObjectModel;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for FilterNodeTest and is intended
    ///to contain all FilterNodeTest Unit Tests
    ///</summary>
    [TestClass()]
    public class FilterNodeTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        ///// <summary>
        /////A test for Children
        /////</summary>
        //[TestMethod()]
        //public void FilterNode_ChildrenTest()
        //{
        //    FilterNode target = new FilterNode(); 
        //    Collection<FilterToken> expected = new Collection<FilterToken>();
        //    expected.Add(new FilterToken("token",3,true)); 
        //    target.Children = expected;
        //    Collection<FilterToken> actual = target.Children;
        //    Assert.AreEqual(expected[0], actual[0]);
        //}

  

     
    }
}
