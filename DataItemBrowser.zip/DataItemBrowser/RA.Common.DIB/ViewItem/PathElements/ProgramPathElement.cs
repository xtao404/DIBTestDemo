﻿/*************************************************************************************
                                                                     
   ViewE DataItemBrowser                                                                     
   Copyright © 2014 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/
using RockwellAutomation.Client.Services.Query.AbstractItem;

namespace RockwellAutomation.UI
{

    /// <summary>
    /// Single Program PathElement
    /// </summary>
    public class ProgramPathElement : ActiveContrainerWithChildrenPathElement
    {
       
        #region Constructor/Initialize

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="dataItem"></param>
        public ProgramPathElement(DataItemBase dataItem, string displayName)
                :base(dataItem, displayName)
        {
            _hasChildren = false;
        }

        #endregion

        #region PathElementBase overrides

        /// <summary>
        /// Property to get or set the path element's display name.
        /// </summary>
        public override string DisplayName
        {
            get { return _displayName; }
            set { _displayName = value; }
        }

        #endregion
    }
}
