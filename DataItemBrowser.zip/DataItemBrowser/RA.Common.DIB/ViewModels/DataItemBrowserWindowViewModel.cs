﻿using System;
using System.Windows;
using RockwellAutomation.UI.UserConfiguration;
using RockwellAutomation.Logging;

using System.Runtime.InteropServices;

namespace RockwellAutomation.UI.Windows
{
    /// <summary>
    /// DataItemBrowser window view mdoel 
    /// The class derives from Freezable to work around a limitation in WPF when data-binding from XAML -
    /// allows the the DependencyProperties to work.
    /// </summary>
    public class DataItemBrowserWindowViewModel : Freezable 
    {
        #region Properties

        ///<summary>
        /// DIBWindow_Width dependency property
        ///</summary>
        public static DependencyProperty DIBWindow_WidthProperty = DependencyProperty.Register("DIBWindow_Width",
                                typeof(int), typeof(DataItemBrowserWindowViewModel), new PropertyMetadata(UserWindowSize.DefaultWindowWidth));

        public int DIBWindow_Width 
        {
            get { return (int)GetValue(DataItemBrowserWindowViewModel.DIBWindow_WidthProperty); }
            set { SetValue(DataItemBrowserWindowViewModel.DIBWindow_WidthProperty, value); } 
        }

        ///<summary>
        /// DIBWindow_Height dependency property
        ///</summary>
        public static DependencyProperty DIBWindow_HeightProperty = DependencyProperty.Register("DIBWindow_Height",
                                typeof(int), typeof(DataItemBrowserWindowViewModel), new PropertyMetadata(UserWindowSize.DefaultWindowHeight));

        public int DIBWindow_Height
        {
            get { return (int)GetValue(DataItemBrowserWindowViewModel.DIBWindow_HeightProperty); }
            set { SetValue(DataItemBrowserWindowViewModel.DIBWindow_HeightProperty, value); }
        }
        #endregion Properties

        #region DPI computations

        /// <summary>
        /// Set the system's DPI (dots per inch)
        /// </summary>
        /// <param name="fwe">Framework item (must be visible) from which to acquire the system's DPI</param>
        public static int DPI = 0;
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        public static void SetDPI(FrameworkElement fwe)
        {
            PresentationSource source = PresentationSource.FromVisual(fwe);
            if (source != null)
            {
                DPI = (int)(96.0 * source.CompositionTarget.TransformToDevice.M11);
                source = null;
            }
        }

        /// <summary>
        /// Convert a screen measurement in pixels into WPFs Device Independent Pixels
        /// </summary>
        /// <param name="pixels">screen pixels</param>
        /// <returns></returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2233:OperationsShouldNotOverflow", MessageId = "pixels*96")]
        public static int ConvertPixelsToDIPs(int pixels)
        {
            if (DPI == 0)
                return pixels;
            return pixels * 96 / DPI;
        }

        /// <summary>
        /// Convert a measurement in WPF Device Independent Pixels to screen pixels
        /// </summary>
        /// <param name="dips">WPF device independent pixels</param>
        /// <returns></returns>
        public static int ConvertDIPsToPixels(int dips)
        {
            return dips * DPI / 96;
        }
        #endregion DPI computations

        #region Constructor and initialization
        /// <summary>
        /// TagBrowser data presenter constructor
        /// </summary>
        public DataItemBrowserWindowViewModel(int minHeight, int minWidth)
        {
            // Open user.config and read the user's configuration information.
            UserConfigurationIO.ReadWindowSize(ref minHeight, ref minWidth);
            DIBWindow_Height = minHeight;
            DIBWindow_Width  = minWidth;
        }

        #endregion Constructor and initialization

        #region calculate window location and size

        /// <summary>
        /// Calculates the top/left corner of the browser based on the starting location, 
        /// the launching element's offset, the browser's size, and which screen the DIB is on (in a multiple screen configuration)
        ///
        /// NOTE: This method is used by the DTC unit tests; any changes to the method
        /// signature and/or functionality must be tested with the DTC. This method
        /// must remain STATIC so that the DTC can access it directly.
        ///
        /// </summary>
        /// <param name="targetPoint">starting topleft point in device-independent units</param>
        /// <param name="editorOffset">size of editing element that launched the browser</param>
        /// <param name="browserSize">initial size of the browser</param>
        /// <returns>Point - the upper left point location of the browser window</returns>
        public static Point CalculateBrowserLocation(Point targetPoint, Size editorOffset, Size browserSize)
        {
            return CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
        }

       
        /// <summary>
        /// Calculates the top/left corner of the browser based on the starting location, 
        /// the launching element's offset, the browser's size, and which screen the DIB is on (in a multiple screen configuration)
        ///
        /// </summary>
        /// <param name="targetPoint">starting topleft point in device-independent units on the virtual screen (the union of all the screens)</param>
        /// <param name="editorOffset">size of editing element that launched the browser</param>
        /// <param name="browserSize">initial size of the browser</param>
        /// <returns>Point -  the upper left point location of the browser window</returns>
        /// <returns>browserSize - final size of the browser</returns>
        public static Point CalculateBrowserLocationAndSize(Point targetPoint, Size editorOffset, ref Size browserSize)
        {
            // Set the top and left point of the DIB based on the target point and the editing element's height
            // This is within the virtual screen (the union of screens)
            int x = (int)targetPoint.X;
            int y = (int)(targetPoint.Y + editorOffset.Height);
            Point dibTopLeft = new Point(x, y);

            // The working area is the desktop area in Device-Independent pixels of the screen hosting dibTopLeft, excluding taskbars, docked windows, and docked tool bars.
            Rect WorkingArea = WPFWorkingArea(x, y);

            // Make sure the DIB's width does not span screen boundaries.  Maximum width of the DIB is the width of the current screen.
            if (browserSize.Width > WorkingArea.Width)
            {
                browserSize.Width = WorkingArea.Width;
            }

            // If the tag browser's right edge is off the screen adjust it back to the left
            if (dibTopLeft.X + browserSize.Width > WorkingArea.Right)
                dibTopLeft.X = (int)(WorkingArea.Right - browserSize.Width);

            // Is the bottom of the browser going to be off the screen?
            if (dibTopLeft.Y + browserSize.Height > WorkingArea.Bottom)
            {
                // Maximize the height of the DIB.
                // Would it be better to display the browser above or below the element that launched the DIB?
                // Which direction has the most room?
                int heightBelow = (int)(WorkingArea.Bottom - dibTopLeft.Y);
                int heightAbove = (int)(dibTopLeft.Y - WorkingArea.Top - editorOffset.Height);
                if (heightBelow > heightAbove)
                {
                    // There is more space below the editing element than above and
                    // the space below the launching element is insufficient to display the dib - shorten the DIB
                    browserSize.Height = heightBelow;
                }
                else
                {
                    // There is more space above the editing element than below
                    // Is this space sufficient to display the dib or does it need to be shortened?
                    if (heightAbove > browserSize.Height)
                    {
                        // The space above the launching element is sufficient to display the DIB
                        dibTopLeft.Y = (int)(dibTopLeft.Y - browserSize.Height - editorOffset.Height);
                    }
                    else
                    {
                        // The space above the launching element is insufficient to display the DIB - shorten the DIB
                        browserSize.Height = heightAbove;
                        dibTopLeft.Y = WorkingArea.Top;
                    }
                }
            }

            return dibTopLeft;
        }

        /// <summary>
        /// What is the WPF WorkingArea for the device-independent cooordinate (x,y)
        /// The working area is the desktop area (in DIPs) of the display, excluding taskbars, docked windows, and docked tool bars.
        /// 
        /// NOTE: This method can not be united tested as it is dependent upon a physical monitor and multi-monitor configuration.
        /// 
        /// </summary>
        /// <param name="x">x coordinate in device-independent pixels</param>
        /// <param name="y">y coordinate in device-independent pixels</param>
        /// <returns>the WPF rectangle for this screen</returns>
        public static Rect WPFWorkingArea(int x, int y)
        {
            // What are the screen's pixel coordinates for the coordinate?
            System.Drawing.Point point = new System.Drawing.Point(ConvertDIPsToPixels(x), ConvertDIPsToPixels(y));

            // Determine which screen contains the point. Handles multi-screen configuration.
            // If the (x,y) coordinate does not map to a screen, the Primary Screen will be used.
            int monId = 1;
            System.Windows.Forms.Screen screenContainingPoint = System.Windows.Forms.Screen.PrimaryScreen;
            foreach (System.Windows.Forms.Screen screen in System.Windows.Forms.Screen.AllScreens)
            {
                if (screen.Bounds.Contains(point.X, point.Y))
                {
                    screenContainingPoint = screen;
                    break;
                }

                monId++;
            }

            // The working area is the desktop area (in DIPs) of the display, excluding taskbars, docked windows, and docked tool bars.
            Rect WorkingArea = ConvertScreenToDIPs(screenContainingPoint);
            return WorkingArea;
        }

        /// <summary>
        /// Convert the Screen's Working Area to a device independent rectangle
        /// </summary>
        /// <param name="screen"></param>
        /// <returns></returns>
        private static Rect ConvertScreenToDIPs(System.Windows.Forms.Screen screen)
        {
            Rect results = new Rect( ConvertPixelsToDIPs(screen.WorkingArea.X),
                                     ConvertPixelsToDIPs(screen.WorkingArea.Y),
                                     ConvertPixelsToDIPs(screen.WorkingArea.Width),
                                     ConvertPixelsToDIPs(screen.WorkingArea.Height)
                                   );
            return results;
;
        }
        /// <summary>
        /// calculates the top/left corner of the browser based on the starting location, 
        /// editor offset and browser size
        /// </summary>
        /// <param name="targetPoint">starting topleft point</param>
        /// <param name="editorOffset">size of editing element that launched the browser</param>
        /// <returns>Point - the starting location of the browser window</returns>
        public Point CalculateBrowserLocation(Point targetPoint, Size editorOffset)
        {

            Size browserSize = new Size(DIBWindow_Width, DIBWindow_Height);
            
            Point results = CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            DIBWindow_Width = (int)browserSize.Width;
            DIBWindow_Height = (int)browserSize.Height;

            LogWrapper.DibStartUpLog.Info(
                "TargetPoint: x = " + targetPoint.X +
                "  y = " + targetPoint.Y +
                "  DPI = " + DPI);
            LogWrapper.DibStartUpLog.Info(
                "Browser location: x = " + results.X + 
                "  y = " + results.Y +
                "  DIBWindow_Width = " + DIBWindow_Width +
                "  DIBWindow_Height = " + DIBWindow_Height);

            return results;
        }

        #endregion calcualte window location and size

        /// <summary>
        /// Read the window's size from the user.config file
        /// </summary>
        private void ReadWindowSize(int minHeight, int minWidth)
        {
            int height = 0;
            int width = 0;
            UserConfigurationIO.ReadWindowSize(ref height, ref width);

            // If an error occurred while reading the window's size, or
            // the stored value is not greater then the minimum size, use the defaults
            if (height < minHeight)
                DIBWindow_Height = UserWindowSize.DefaultWindowHeight;
            else
                DIBWindow_Height = height;

            if (width < minWidth)
                DIBWindow_Width = UserWindowSize.DefaultWindowWidth;
            else
                DIBWindow_Width = width;

        }

        /// <summary>
        /// Save the window's size to the user.config file
        /// </summary>
        public void SaveWindowSize()
        {
            UserConfigurationIO.SaveWindowSize(DIBWindow_Height, DIBWindow_Width);
        }

        #region Freezable

        /// <summary>
        /// This class derives from Freezable to work around a limitation in WPF when data-binding from XAML -
        /// allows the the DependencyProperties to work.
        /// </summary>
        /// <returns></returns>
        protected override Freezable CreateInstanceCore()
        {
            throw new NotImplementedException();
        }

        #endregion

    }
}
