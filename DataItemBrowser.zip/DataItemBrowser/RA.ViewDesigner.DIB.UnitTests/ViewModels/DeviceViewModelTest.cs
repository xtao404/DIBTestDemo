﻿using RockwellAutomation.UI.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.ComponentModel;
using System.Windows;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI;
using System.Collections.Generic;
using RockwellAutomation.Client.Services.Query.Common;
using AvalonUnitTesting;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query;

namespace DataItemBrowserUT
{
    /// <summary>
    ///This is a test class for VieweDevicesListViewModelTest and is intended
    ///to contain all VieweDevicesListViewModelTest Unit Tests
    ///</summary>
    [TestClass()]
    public class VieweDevicesListViewModelTest
    {

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        /// <summary>
        /// DeviceImageControl UI data binding check.
        /// </summary>
        [TestMethod()]
        public void DeviceImageControl_DataBindingIsCorrectTest()
        {
            AvalonTestRunner.RunInSTA(delegate()
            {
                // Create the control using a delegate to ensure binding errors generated during
                // control creation are caught.
                Func<object> controlCreator = delegate()
                {
                    // what ever your control is called
                    DeviceImageControl control = new DeviceImageControl();
                    return control;
                };

                AvalonTestRunner.RunDataBindingTests(controlCreator);
            });
        }

        /// <summary>
        /// A test for Visible
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDevicesListViewModel_VisibleTest_Visible()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);
            Visibility expected = new Visibility();
            expected = Visibility.Visible;
            Visibility actual;
            target.Visible = expected;
            actual = target.Visible.Value;
            Assert.AreEqual(expected, actual, "Visible Property is not Visible");
        }

        /// <summary>
        /// A test for Visible
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDevicesListViewModel_VisibleTest_Collapsed()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);
            Visibility expected = new Visibility();
            expected = Visibility.Collapsed;
            Visibility actual;
            target.Visible = expected;
            actual = target.Visible.Value;
            Assert.AreEqual(expected, actual, "Visible Property is not Collapsed");
        }


        /// <summary>
        /// A test for SelectedItem
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDevicesListViewModel_SelectedItemTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);
            DataItemBase expected = new DataItemBase() { CommonName = "selectedDataItemBase" };

            DataItemBase dib = new DataItemBase() { CommonName = "selectedDataItemBase" };
            DIBListViewItem data = new DIBListViewItem(dib);

            target.SelectedItem = data;
            DIBListViewItem actual;
            actual = target.SelectedItem;
            Assert.AreEqual(expected.CommonName, actual.DataItem.CommonName);
        }

        /// <summary>
        /// A test for DataItemBrowserViewModel_DataViewChanged
        /// Also tests IsDeviceView - default value for target.Visible is Visibility.Collapsed
        /// Mock's IsDeviceView returns true, which changes target.Visible to Visibility.Visible
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_DataViewChangedTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            mock.IsListViewValue = true;
            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);
            PrivateObject targetPrivate = new PrivateObject(target);
            object sender = null; 
            EventArgs e = null; 
            targetPrivate.Invoke("DataItemBrowserViewModel_DataViewChanged", new object[]{sender, e});
            Assert.AreEqual(target.Visible.Value, Visibility.Visible, "Visible should be Visibility.Visible");
        }

        /// <summary>
        /// A test for NotifyPropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDevicesListViewModel_NotifyPropertyChangedTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);
            PrivateObject targetPrivate = new PrivateObject(target);
            targetPrivate.Invoke("add_PropertyChanged", new PropertyChangedEventHandler(myPropertyHandler));
            _myPropertyName = "";
            _mySender = null;
            string propertyName = "myProperty";
            targetPrivate.Invoke("NotifyPropertyChanged", propertyName);
            Assert.AreEqual(propertyName, _myPropertyName);
            Assert.AreEqual(target, _mySender);
        }
        private string _myPropertyName = "";
        private object _mySender = null;
        public void myPropertyHandler(object sender, PropertyChangedEventArgs e)
        {
            _myPropertyName = e.PropertyName;
            _mySender = sender;
        }


        /// <summary>
        /// A test for DrillOutCommand - used by keyboard navigation
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DeviceViewViewModel_DrillOutCommandTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            String controllerName = "drilloutController";
            mock.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(controllerName));
            DataItemBase controllerDIB = mock.Path.Last.DataItem;
            mock.Path.Add(PathElementUtility.Instance().CreateDataLogsPathElement());
            DataItemBase datalogsDIB = mock.Path.Last.DataItem;

            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);
            target.DrillOutCommand.Execute(null);  // We are drilling out to the DataSources View

            Assert.AreEqual(controllerDIB.CommonName, mock.Path.ActiveElement.DataItem.CommonName, "Active Element should be drilloutController");
            Assert.AreEqual(mock.Path.Forward.DataItem.CommonName, mock.NavPathList[1].DisplayName, "Forward path should be DataLogs");
        }

        /// <summary>
        /// A test for DrillInCommand
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDevicesListViewModel_DrillInCommandTest()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);
            DataItemBase homeDataItem = new DataItemBase()
            {
                CommonID = "hi: 16643070363065207339\nlo: 13601259066303758964\n",
                CommonName = "home",
                CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403191811\n"
            };
            List<DataItemBase> dataItems = new List<DataItemBase>();

            dataItems.Add(homeDataItem);
            mock.Path.Items.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));

            DataItemBase dib = new DataItemBase()
            {
                CommonName = "drillinTag",
                CommonResourceType = TypeIdentifiers.ResourceType_Tag.ToString()
            };
            DIBListViewItem data = new DIBListViewItem(dib);

            target.DrillInCommand.Execute(data);
            Assert.AreEqual(dib.CommonName, mock.NavPathList[1].DisplayName);
        }

        /// <summary>
        /// A test for DrillInCommand with no Forward path and two nodes in history list with same name
        /// This is to test that anomaly 119835 remains fixed
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDevicesListViewModel_DrillIn_TagAndParentWithSameName()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);

            //Add some items to the path and then navigate backwards so that there is an existing path.Forward item
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Controller1", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Level2", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Level3SameName", "", true));
            IPathElement lastSelectedPathItem = PathElementUtility.Instance().CreateDataItemPathElement("Level3SameName", "", true);
            mock.Path.SavedHighlightedElement = lastSelectedPathItem;
            Assert.IsTrue(mock.Path.Forward == null);
            Assert.IsTrue(mock.Path.ActiveElement.DisplayName == "Level3SameName");
            Assert.IsTrue(mock.Path.SavedHighlightedElement.DisplayName == "Level3SameName");

            DataItemBase dib = new DataItemBase() {CommonName = "Level3SameName"};
            DIBListViewItem data = new DIBListViewItem(dib);

            target.DrillInCommand.Execute(data); //Drill down from Tag called "Level3SameName" to another tag called "Level3SameName"

            Assert.IsTrue(mock.NavPathList.Count == 4);
            Assert.IsTrue(mock.NavPathList[3].DisplayName == "Level3SameName");
            //We should NOT have attempted to select a Tag called Level3SameName
            Assert.IsTrue(mock.NavNameToSelect != "Level3SameName");
            Assert.IsTrue(mock.NavNameToSelect == "");
        }

        /// <summary>
        /// A test for DrillInCommand
        /// This is to test that anomaly 119850 remains fixed
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void VieweDevicesListViewModel_DrillOutAndInToDifferentTag_AndDontReselectAnything()
        {
            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);

            //Add some items to the path and then navigate backwards so that there is a forward item
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("Controller1", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("SomeAutoValue1", "", true));
            mock.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("SomeDetailTag", "", true));
            IPathElement lastSelectedPathItem = PathElementUtility.Instance().CreateDataItemPathElement("SomeTerminalNode", "", true);
            mock.Path.SavedHighlightedElement = lastSelectedPathItem;
            Assert.IsTrue(mock.Path.Forward == null);
            Assert.IsTrue(mock.Path.ActiveElement.DisplayName == "SomeDetailTag");
            Assert.IsTrue(mock.Path.SavedHighlightedElement.DisplayName == "SomeTerminalNode");
            mock.Path.NavigateBack(); //Drill out
            Assert.IsTrue(mock.Path.Forward.DisplayName == "SomeDetailTag");
            Assert.IsTrue(mock.Path.ActiveElement.DisplayName == "SomeAutoValue1");
            Assert.IsTrue(mock.Path.SavedHighlightedElement.DisplayName == "SomeTerminalNode");

            DataItemBase dib = new DataItemBase() {CommonName = "drillinTag"};
            DIBListViewItem data = new DIBListViewItem(dib);
            target.DrillInCommand.Execute(data); //Drill back into same tag called "drillinTag"

            Assert.IsTrue(mock.NavPathList.Count == 3);
            Assert.AreEqual(dib.CommonName, mock.NavPathList[2].DisplayName);
            Assert.IsTrue(mock.NavPathList[2].DisplayName == "drillinTag");
            //Are we attempting to select the last highlighted item? Since we drilled into a different tag, this should be nothing
            Assert.IsTrue(mock.NavNameToSelect == "");
        }


        /// <summary>
        ///A test for Items and DataItemBrowserViewModel_ListViewOCChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ItemsAndDataItemBrowserViewModel_ListViewOCChangedTest()
        {
            IObservableCollection<DataItemBase> expected = new TSObservableCollection<DataItemBase>();
            expected.Add(DIResource.DIB_TagsAndProps);
            expected.Add(DIResource.DIB_Programs);
            expected.Add(DIResource.DIB_DataLogs);

            MockDataItemBrowserViewModel mock = new MockDataItemBrowserViewModel();
            mock.DataItems = expected;

            VieweDevicesListViewModel target = new VieweDevicesListViewModel(mock);
            PrivateObject targetPrivate = new PrivateObject(target);

            object sender = null;
            SelectedItemPropertyChangedEventArgs DSOCArgs = new SelectedItemPropertyChangedEventArgs(DIResource.DI_COMMON_RESOURCETYPE_DATALOGS_UI, DIResource.DI_COMMON_RESOURCETYPE_DATALOGS_UI);

            targetPrivate.Invoke("DataItemBrowserViewModel_ListViewOCChanged", new object[]{sender, (PropertyChangedEventArgs)DSOCArgs});

            foreach (DIBListViewItem data in target.Items)
            {
                // Associate an image with the data            
                if (data.DataItem.Equals(DIResource.DIB_TagsAndProps))
                {
                    Assert.IsTrue(data.AutomationName == "TagsAndProps", "Data Item name should be TagsAndProps");
                    Assert.IsFalse(data.IsSelected, "Tags and Properties should not be selected");
                }
                else if (data.DataItem.Equals(DIResource.DIB_Programs))
                {
                    Assert.IsTrue(data.Name == "Programs", "Data Item name should be Programs");
                    Assert.IsFalse(data.IsSelected, "Programs should not be selected");
                }
                else if (data.DataItem.Equals(DIResource.DIB_DataLogs))
                {
                    Assert.IsTrue(data.Name == "Data Logs", "Data Item name should be DataLogs");
                    Assert.IsTrue(data.IsSelected, "DataLogs should be selected");
                }
                else
                    Assert.Fail("Invalid DataItemBae");

            }
        }
    }
}
