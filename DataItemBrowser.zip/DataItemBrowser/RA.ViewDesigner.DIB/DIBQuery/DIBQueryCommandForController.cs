﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;
using RockwellAutomation.UI.Models;

namespace RockwellAutomation.UI.DIBQuery
{
    class DIBQueryCommandForController : DIBQueryCommandForPrograms
    {

        #region "Creation/Init"

        public DIBQueryCommandForController(QueryRequest.CreateBuilder queryRequestBuilder)
            : base(queryRequestBuilder)
        {
            CacheQueryResults = true;
        }

        #endregion

        #region "Base Overides"

        public override PredefinedQueryType QueryType()
        {
            return PredefinedQueryType.Undefined;
        }


        public override void Execute(IClientDataServices cds, IDIBQueryConnection queryConnection)
        {
            // User drilled into the Controller view
            DataContext dataContext = cds.DataContext;
            DIBQueryCache queryCache = cds.QueryCache;

            this.CacheQueryResults = true;
            if (dataContext.IsTagsAndPropertiesTypeIncluded()) queryCache.AddDataItem(DIResource.DIB_TagsAndProps);
            if (dataContext.IsProgramTypeIncluded()) queryCache.AddDataItem(DIResource.DIB_Programs);
            if (dataContext.IsDataLogTypeIncluded()) queryCache.AddDataItem(DIResource.DIB_DataLogs);

            ExecuteNonDBQueryResponse(queryConnection, queryCache);
            return;

        }
        #endregion
    }
}
