﻿/* ****************************************************************************
*
*  Copyright 2011 Rockwell Automation Inc.  Confidential.  All Rights Reserved.  
*
*  This program is the proprietary property of Rockwell Automation Inc.
*  and it shall not be reproduced, distributed or used in any way without the 
*  approval of an authorized company official.  This program is an unpublished
*  work subject to Trade Secret and Copyright protection.  All rights to this
*  program are reserved to Rockwell Automation Inc.
*
*
** ***************************************************************************/

using System.Diagnostics;
using System.Windows;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace AvalonUnitTesting
{
    /// <summary>
    /// Trace listener that asserts when a data binding error is encontered in a specific page
    /// </summary>
    public class AvalonTraceListener : TraceListener
    {
        private Window currentWindowBeingTested;

        public List<string> Messages = new List<string>();

        /// <summary>
        /// The current window that is being tests
        /// </summary>
        internal Window CurrentWindowBeingTested
        {
            get { return currentWindowBeingTested; }
            set { currentWindowBeingTested = value; }
        }
        /// <summary>
        /// Fails the unit test if this method is called
        /// </summary>
        /// <param name="message">The message to push in the fail</param>
        public override void Write(string message)
        { }

        /// <summary>
        /// Fails the unit test if this method is called
        /// </summary>
        /// <param name="message">The message to push in the fail</param>
        public override void WriteLine(string message)
        {
            //close the window before failing the tests
			if (currentWindowBeingTested != null)
			{
				try
				{
					currentWindowBeingTested.Close();
				}
				catch (System.InvalidOperationException ex)
				{
					// We sometimes get this if we're currently on the wrong thread:
					//	System.InvalidOperationException: The calling thread cannot access this object because a different thread owns it.
					// Since this exception obscures the actual test failure (the 'message' arg), we'll trace the cross-thread exception
					// and let the test fail for the "real" reason
					System.Diagnostics.Trace.WriteLine("Exception: " + ex.ToString());
				}
			}

            Messages.Add(message);
        }
    }
}
