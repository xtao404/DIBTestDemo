﻿#undef CAN_VIEW_H2DB

using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml.Linq;

#if CAN_VIEW_H2DB
using java.sql;
#endif

namespace RockwellAutomation.DesignTimeClient.PopUpTestHost
{
	/// <summary>
	/// Class used to represent a ViewE project file conforming to a GUID (Hi/Low) name
	/// to provide turning this name into an actual GUID datatype value
	/// </summary>
	class ProjectFileName
	{
		string _FullPath = "";
		string _DirName = "";
		string _FileName = "";
		string _ExtName = "";
		string _Content = "";
		string _CreationInfo = "";

		const string CONTROLLER_TYPE_UUID = "718c2595-952c-405a-9f9f-af4e5b650003";
		const string DEVICE_TYPE_UUID     = "718c2595-952c-405a-9f9f-af4e5b650011";
		const string PROGRAM_TYPE_UUID    = "718c2595-952c-405a-9f9f-af4e5b660004";
        const string DATALOG_TYPE_UUID    = "aa32f1d7-3c02-4318-a919-ea62864b492b";
        const string DATALOGS_TYPE_UUID   = "debc82df-5ca9-472f-b388-3889983850e4";

        public Dictionary<string, List<string>> Devices { get; internal set; }

		/// <summary>
		/// Load/unload an H2 DB driver so we load the content (devices) contained within an H2 database
		/// </summary>
		/// <param name="Load"></param>
		public static void H2DataBaseDriver(bool Load)
		{
#if CAN_VIEW_H2DB
			if(Load)
				org.h2.Driver.load();
			else
				org.h2.Driver.unload();
#endif
		}

		public ProjectFileName(string FullFilePath, bool ReadFileContent = false, bool ReadDeviceContent = false)
		{
			_FullPath = FullFilePath;
			if (String.IsNullOrWhiteSpace(_FullPath) || !File.Exists(_FullPath))
			{
				_Content = "File not found";
			}
			else
			{
				_DirName = Path.GetDirectoryName(FullFilePath);
				_FileName = Path.GetFileNameWithoutExtension(FullFilePath);
				_ExtName = Path.GetExtension(FullFilePath);

				_CreationInfo = "Created " + File.GetCreationTime(FullFilePath).ToString();
				//This returns BUILTIN\Administrators so comment until it can be uncovered how to get a user name (apparently hard with .NET API)
				//_CreationInfo += " by " + File.GetAccessControl(FullFilePath).GetOwner(typeof(System.Security.Principal.NTAccount)).ToString();

				Devices = new Dictionary<string,List<string>>();

				if(ReadFileContent)
				{
				    if (_ExtName == ".xml")
				    {
					    string FileContent = File.ReadAllText(FullFilePath);
					    if (FileContent.StartsWith("<?xml"))
					    {
						    var xElem = XElement.Load(FullFilePath);
						    var Controllers = from controller in xElem.Elements("Controller") select controller;

						    string NewLine = "";
						    foreach (var Controller in Controllers)
						    {
							    _Content += NewLine + Controller.ToString();
							    NewLine = "\n";
						    }
					    }
					    else
					    {
						    _Content = FileContent;
					    }
				    }
				    else if (_ExtName == ".db")
				    {
#if CAN_VIEW_H2DB
					    //Copy file just in case the db is locked
					    string dbCopy = _FullPath.Replace(".h2.db", "_copy.h2.db");
					    File.Copy(_FullPath, dbCopy, true);

					    Connection dbConnection = null;

					    try
					    {
						    //Connect to the file copy					        
					        string dbUrl = "jdbc:h2:file:" + Path.Combine(_DirName, _FileName.Replace(".h2", "_copy"));
						    dbConnection = DriverManager.getConnection(dbUrl, "sa", "");

						    //Check to see if the resource table exists
						    Statement stmt = dbConnection.createStatement();
						    ResultSet InfoSchemaQueryRes = stmt.executeQuery("SELECT COUNT(*) as NUM FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME = 'RESOURCE'");
						    InfoSchemaQueryRes.next();
						    bool HasResourceTable = InfoSchemaQueryRes.getInt("NUM") == 1;

						    //Get a list of all devices from the db and fill in the content member of this project file name
						    if (HasResourceTable)
						    {
							    string NewLine = "";
							    ResultSet DeviceResultSet = stmt.executeQuery("SELECT DISPLAY_NAME, TYPE_UUID, UUID FROM RESOURCE WHERE TYPE_UUID = '" + CONTROLLER_TYPE_UUID + "' OR TYPE_UUID = '" + DEVICE_TYPE_UUID + "'");

							    Dictionary<string, string> DeviceNameToUuid = new Dictionary<string, string>();
							    Dictionary<string, string> DeviceNameToType = new Dictionary<string, string>();
							    while (DeviceResultSet.next())
							    {
								    string DeviceName = DeviceResultSet.getString("DISPLAY_NAME");
								    string DeviceUuid = DeviceResultSet.getString("UUID");
								    string DeviceType = DeviceResultSet.getString("TYPE_UUID");

								    DeviceNameToUuid.Add(DeviceName, DeviceUuid);
								    DeviceNameToType.Add(DeviceName, DeviceType);
							    }

							    foreach (KeyValuePair<string, string> DeviceKeyAndVal in DeviceNameToUuid)
							    {
								    //Lookup device children if we have been told to do so
								    string DeviceContentString = "";
                                    string Name = "";
                                    List<string> DeviceChildList = new List<string>();
                                    if (ReadDeviceContent)
								    {
                                        // Is this device a Controller?
                                        if (DeviceNameToType[DeviceKeyAndVal.Key] == CONTROLLER_TYPE_UUID)
                                        {
                                            int Programs = 0;
                                            int DataLogs = 0;

                                            // Programs
                                            ResultSet ProgramResultSet = stmt.executeQuery("SELECT DISPLAY_NAME FROM RESOURCE WHERE TYPE_UUID = '" + PROGRAM_TYPE_UUID + "' AND PARENT_UUID = '" + DeviceKeyAndVal.Value + "'");
                                            while (ProgramResultSet.next())
                                            {
                                                Programs++;
                                                Name = "\\" + ProgramResultSet.getString("DISPLAY_NAME");
                                                DeviceChildList.Add(Name);
                                            }

                                            // DataLogs
                                            // First find the DataLogs "folder"
                                            ResultSet DataLogsResultSet = stmt.executeQuery("SELECT DISPLAY_NAME, UUID FROM RESOURCE WHERE TYPE_UUID = '" + DATALOGS_TYPE_UUID + "' AND PARENT_UUID = '" + DeviceKeyAndVal.Value + "'");
                                            if (DataLogsResultSet.next())
                                            {
                                                // DataLogs "folder" exists now find each datalog
                                                ResultSet DataLogResultSet = stmt.executeQuery("SELECT DISPLAY_NAME, UUID FROM RESOURCE WHERE TYPE_UUID = '" + DATALOG_TYPE_UUID + "' AND PARENT_UUID = '" + DataLogsResultSet.getString("UUID") + "'");
                                                while (DataLogResultSet.next())
                                                {
                                                    DataLogs++;
                                                    Name = "\\@" + DataLogResultSet.getString("DISPLAY_NAME");
                                                    DeviceChildList.Add(Name);
                                                }
                                            }

                                            DeviceContentString = string.Format("{0,2} {1,-10}{2,2} {3,-8}", Programs, "Programs", DataLogs, "DataLogs");
                                        }

                                        Devices.Add(DeviceKeyAndVal.Key, DeviceChildList);
                                    }

								    //Set the actual content string
								    string DeviceName = DeviceKeyAndVal.Key;
								    _Content += NewLine + DeviceName.PadRight(35) + (DeviceNameToType[DeviceName] == CONTROLLER_TYPE_UUID ? "(Controller)" : "(HMI Device)").PadRight(20);
								    if(DeviceContentString!="")
									    _Content += " " + DeviceContentString;
								
								    NewLine = "\n";
							    }
							

						    }
					    }
					    catch (Exception e)
					    {
						    Console.WriteLine("ProjectFileName {0} content exeception: {1} ", _FileName, e.Message);
					    }

					    //Close db and delete our file copy
					    if (dbConnection != null && !dbConnection.isClosed())
						    dbConnection.close();
					    File.Delete(dbCopy);
#endif
				    }
				}
			}
		}


		public XElement Controllers { get; set; }

		public bool HasContent
		{
			get
			{
				return Content != "";
			}
		}
		public string FullPath
		{
			get
			{
				return _FullPath;
			}
		}

		public string Content
		{
			get
			{
				return _Content.Trim();
			}
		}

		public string CreationInfo
		{
			get
			{
				return _CreationInfo;
			}
		}

		private string LoAndHi
		{
			get
			{
				return _FileName.Replace("-", "");
			}
		}

		public override string ToString()
		{
			return _FileName;
		}

		public ulong HiWord
		{
			get
			{
				return HasValidName ? Convert.ToUInt64(LoAndHi.Substring(0, 16), 16) : 0;
			}
		}

		public ulong LoWord
		{
			get
			{
				return HasValidName ? Convert.ToUInt64(LoAndHi.Substring(16, 16), 16) : 0;
			}
		}

		public bool HasValidName
		{
			get
            {
                return LoAndHi.Length >= 32;
			}
		}
	}
}
