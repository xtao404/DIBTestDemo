
namespace RockwellAutomation.UI.Models
{
    /// <summary>
    /// SearchCrumb class
    /// Used solely to represent the breadcrumb's search image
    /// </summary>
    public class SearchCrumb : ACrumb
    {
        /// <summary>
        /// constructor
        /// </summary>
        public SearchCrumb() { }

        /// <summary>
        /// Does this crumb support drop arrow navigation property.
        /// </summary>
        public override bool SupportsDropArrow
        {
            //search crumb has no drop arrow, it is always the last crumb
            get { return false; }
        }


    }
}
