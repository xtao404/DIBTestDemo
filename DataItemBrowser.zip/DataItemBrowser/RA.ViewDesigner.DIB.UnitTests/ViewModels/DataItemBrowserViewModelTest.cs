/**************************************************************************************   
   ViewE DataItemBrowser                                                                     
   Copyright � 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using System.Collections.ObjectModel;
using System.Threading;
using System.ComponentModel;
using System.Collections.Generic;
using FakeItEasy;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RockwellAutomation.UI;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.UI.CommonControls.SearchFilter;
using RockwellAutomation.UI.CommonControls.SearchFilter.ViewModels;
using RockwellAutomation.UI.CommonControls.ViewModels;
using RockwellAutomation.UI.DIBQuery;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.Resources;
using System.Windows.Input;
using RockwellAutomation.UI.WindowsControl.DIBClient;
using RockwellAutomation.Client.Services.Query.Common;
using System;


namespace DataItemBrowserUT
{  
    /// <summary>
    /// This is a test class for DataItemBrowserViewModelTest and is intended
    /// to contain all DataItemBrowserViewModelTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DataItemBrowserViewModelTest
    {
        
        #region public interface

        /// <summary>
        /// get/set the state of the async operation
        /// </summary>
        static public bool AsynOperationComplete { get; set; }

        /// <summary>
        /// handler for PropertyChange notifications
        /// </summary>
        public void DSVMLoadComplete(object o, System.ComponentModel.PropertyChangedEventArgs e)
        {
            AsynOperationComplete = true;
        }

        /// <summary>
        /// used to pause an asynchronous unit tests until the async operation
        /// has completed and raised the appropriate PropertyChangeNotification.
        /// </summary>
        /// <param name="millisecond_interval">milliseconds to have the thread sleep before next polling</param>
        public void WaitForAsyncCompleteEvent(int millisecond_interval)
        {
            // set max wait time before a time out
            // Note: currently set to 300000ms (5 mins) to compensate for the 
            //       ResourceServiceProvider current performance issues.  once
            //       that has been addressed we could lower the max time to 
            //       something more reasonable
            int max_wait = 300000;
            int wait_time = 0;

            if (millisecond_interval < 3000)
                millisecond_interval = 3000;

            while (!AsynOperationComplete && (wait_time < max_wait))
            {
                wait_time += millisecond_interval;
                Thread.Sleep(millisecond_interval);
            }
            if (!AsynOperationComplete)
                Assert.Fail("Maximum wait time exceeded, unit test failed");
        }

        #endregion public interface

        #region private members

        private static DataItemBrowserViewModel target;
        ISearchFilterControlViewModel fakeSearchFilterControlViewModel = null;
        IClientDataServices fakeClientDataServices = null;
        readonly UUID packageContext = UUID.CreateBuilder().SetHi(1UL).SetLo(0UL).Build();
        readonly UUID projectContext = UUID.CreateBuilder().SetHi(1UL).SetLo(0UL).Build();


        #endregion private members
        
        #region Additional test attributes

        /// <summary>
        ///  initialize DataItemBrowserViewModel
        ///  Explicitely called, removed from TestInitialize(), since not all tests need this
        /// </summary>
        /// <param name="browserType"></param>
        public void DataItemBrowserViewModelTestInit(string browserType)
        {
            DataItemBrowserViewModelTestInit(packageContext, projectContext, browserType);
        }

        /// <summary>
        ///  initialize DataItemBrowserViewModel
        ///  Explicitely called, removed from TestInitialize(), since not all tests need this
        ///  Created this override method so that tests could pass in their own unique project and package Context 
        ///  values. When the unit tests run with the same context values the DIB will populate the connect string 
        /// with the last highlighted value. This allows the unit test to control if the connect string is populated.
        /// </summary>
        /// <param name="pkgContext"> packagecontext </param>
        /// <param name="projContext"> project context</param>
        /// <param name="browserType"> "Tag" or "Data Type"</param>        
        public void DataItemBrowserViewModelTestInit(UUID pkgContext, UUID projContext, string browserType)
        {
            // only go on if the view model is null, or we are changing data providers
            if ((target == null))
            {
                BackgroundWorkerSyncContextHelper.DoTests(() =>
                {
                    //set up SearchFilterControlViewModel parameters/methods
                    fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();
                    //set up ClientDataServices                  
                    fakeClientDataServices = A.Fake<IClientDataServices>();

                    //set it up so that whatever callback is passed in will be called
                    A.CallTo(() => fakeClientDataServices.Initialize(A<DataItemBrowserContext>.Ignored, A<InitializationComplete>.Ignored)).Invokes(call =>
                    {
                        var callback = ((InitializationComplete)call.Arguments[1]);
                        callback(new DataContext(), string.Empty);
                    });
                    target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, browserType, fakeSearchFilterControlViewModel, fakeClientDataServices);
                    target.Initialize(null, string.Empty);
                });
                target.NavigateStateChanged += new PropertyChangedEventHandler(target_NavigateStateChanged);

            }
            else
            {
                // clear/reset the path so it is clean for each subsequent test run.
                target.Path.Clear();

                // clear search for the tests that may have previously run and utilized search
                if (target.IsSearchActive)
                {
                    target.SearchFilterControlVM.SearchFilterText = "";
                    target.SearchFilterControlVM.ExecuteFilterCommand.Execute("");
                    target.ProcessFilter();
                }
            }

            AsynOperationComplete = false;
        }

        // Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void DataItemBrowserViewModelTestInitialize()
        {
            DIBClientManagerForViewe.Instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, projectContext, packageContext);
            DIBClientManagerForViewe.InitializeVieweSpecificClasses();
        }

        [TestCleanup()]
        public void DataItemBrowserViewModelTestCleanup()
        {
            DIBClientManagerForViewe.Instance.Shutdown();

            if (target != null) this.UnregisterForEvents();            
            target = null;
            fakeSearchFilterControlViewModel = null;
            fakeClientDataServices = null;
        }
		
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        private TestContext testContextInstance;
        public TestContext TestContext
        {
            get { return testContextInstance; }
            set { testContextInstance = value; }
        }    

        #endregion

        #region AssemblyInitializer

        /// <summary>
        /// used to initalize and clean-up the <c>BackgroundWorkerSyncContextHelper</c>
        /// for test of asynchronous unit tests.
        /// </summary>
        [TestClass]
        public static class AssemblyInitializer
        {
            [AssemblyInitialize()]
            public static void AssemblyInitialize(TestContext testContext)
            {
                BackgroundWorkerSyncContextHelper.Init();
            }

            [AssemblyCleanup]
            public static void AssemblyCleanup()
            {
                BackgroundWorkerSyncContextHelper.Cleanup();
            }
        }

        #endregion

        #region PropertyEventHandlers
        bool _navigateStateChangedCalled = false;
        void target_NavigateStateChanged(object sender, PropertyChangedEventArgs e)
        {
            _navigateStateChangedCalled = true;
            if ((e as NavigateStateChangedEventArgs).Begin == false)
                AsynOperationComplete = true;
        }


        bool _notifiedOfDataGridColsChanged = false;
        void target_DataGridColsChanged(object sender, PropertyChangedEventArgs e)
        {
            _notifiedOfDataGridColsChanged = true;
        }

        bool _notifiedOfListViewOCChanged = false;
        string _listViewOCChangedValue = string.Empty;
        void target_ListViewOCChanged(object sender, PropertyChangedEventArgs e)
        {
            _listViewOCChangedValue = (e as SelectedItemPropertyChangedEventArgs).SelectedItem;
            _notifiedOfListViewOCChanged = true;
        }

        string gridOCChangedItem = string.Empty;
        bool _notifiedOfDataGridOCChanged = false;
        void target_DataGridOCChanged(object sender, PropertyChangedEventArgs e)
        {
            _notifiedOfDataGridOCChanged = true;
            gridOCChangedItem = (e as DGOCPropertyChangedEventArgs).ItemToSelect.CommonName;            
        }

      
        private bool _addSearchCrumb = false;
        /// <summary>
        /// private helper to list for search breadcrumb changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void target_SearchBreadCrumbChanged(object sender, PropertyChangedEventArgs e)
        {
            SearchBreadCrumbPropertyChangedEventArgs bcArg = e as SearchBreadCrumbPropertyChangedEventArgs;
            _addSearchCrumb = bcArg.Add;
        }

        /// <summary>
        /// internal TreeeView observable collection changed event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        private string _selectedDataSource = string.Empty;
        private void TreeViewOCChanged(object sender, PropertyChangedEventArgs e)
        {
            SelectedItemPropertyChangedEventArgs DSOCArgs = e as SelectedItemPropertyChangedEventArgs;
            _selectedDataSource = DSOCArgs.SelectedItem;

        }

        private string _selectedItem;
        /// <summary>
        /// internal selected item path has changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SelectedItemPathChanged(object sender, PropertyChangedEventArgs e)
        {
            DataItemBrowserViewModel dibVM = sender as DataItemBrowserViewModel;
            _selectedItem = dibVM.SelectedItemPath;
        }

        private string _userSetHighlightedItem;
        /// <summary>
        /// internal selected item path has changed event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void UserSetHighlightedItemPathChanged(object sender, PropertyChangedEventArgs e)
        {
            DataItemBrowserViewModel dibVM = sender as DataItemBrowserViewModel;
            _userSetHighlightedItem = dibVM.UserSetHighlightedItemPath;
        }

        /// <summary>
        /// internal double click select event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private bool _doubleClickSelect = false;
        private void doubleClickSelect(object sender, PropertyChangedEventArgs e)
        {
            _doubleClickSelect = true;
        }

        /// <summary>
        /// internal DataGrid observable collection changed event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        private DataItemBase _itemToSelect = null;
        private void DataGridOCChanged(object sender, PropertyChangedEventArgs e)
        {
            DGOCPropertyChangedEventArgs DSOCArgs = e as DGOCPropertyChangedEventArgs;
            _itemToSelect = DSOCArgs.ItemToSelect;

        }

        private string _selectedItemPath = string.Empty;
        private void target_SelectItemAfterLaunchWithSearch(object sender, PropertyChangedEventArgs e)
        {
            _selectedItemPath = (e as SelectItemAfterLaunchWithSearchEventArgs).SelectedItemPath;
        }
        
        private List<IPathElement> _pathList = null;
        private string _nameToSelect = "bogus name";
        private void target_NavigateComplete(object sender, PropertyChangedEventArgs e)
        {
            _pathList = (e as NavigatePropertyChangedEventArgs).FullPath;
            _nameToSelect = (e as NavigatePropertyChangedEventArgs).NameToSelect;
        }
        #endregion PropertyEventHandlers

        /// <summary>
        ///A test for SelectedItemPath
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_SelectedItemPathTest()
        {            
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            string expected = "this is a jumble of text";

            PrivateObject dibVmPO = new PrivateObject(target);
            dibVmPO.SetFieldOrProperty("SelectedItemPath", expected);

            string actual = target.SelectedItemPath;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for SelectedDataItemBase
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_SelectedDataItemBaseTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            DataItemBase expected = new DataItemBase() { CommonName = "this is a jumble of text" };

            PrivateObject dibVmPO = new PrivateObject(target);
            dibVmPO.SetFieldOrProperty("SelectedDataItemBase", expected);

            DataItemBase actual = target.SelectedDataItemBase;
            Assert.AreEqual(expected, actual);
        }


        /// <summary>
        ///A test for _selectedItemPath
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_SelectedItemPathInitValueTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);

            PrivateObject dibVmPO = new PrivateObject(target);
            string initialSelectedItemValue = (string)dibVmPO.GetFieldOrProperty("_selectedItemPath");

            //This may seem like an odd verification, but we had at one point changed the initial value of _selectedItemPath
            // to work around an issue where invalid connect strings wouldn't clear the last highlighted item path - so
            // verify this doesn't creep back in by ensuring the initial value is empty
            Assert.AreEqual(string.Empty, initialSelectedItemValue, "Initial value of selected item should be an empty string");
        }

        /// <summary>
        ///A test for UserSetHighlightedItemPath
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_UserSetHighlightedItemPathTest()
        {           
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            string expected = "this is a jumble of text";

            PrivateObject dibVmPO = new PrivateObject(target);
            dibVmPO.SetFieldOrProperty("UserSetHighlightedItemPath", expected);
            
            string actual = target.UserSetHighlightedItemPath;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for SelectedItemCommand
        ///</summary>
        //[TestMethod()]
        public void DataItemBrowserViewModel_SelectedItemCommandTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            target.Path.Clear();
            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateProgramPathElement("p1"));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("t1", "", true));
            string expected = "::c1\\p1.t1.m1";

            DataItemBase m1DataItem = PathElementUtility.Instance().CreateDataItemBase("m1");
            target.SelectedItemCommand.Execute(m1DataItem);

            string actual = target.SelectedItemPath;
            Assert.AreEqual(expected, actual);

            DataItemBase actualDataItemBase = target.SelectedDataItemBase;
            Assert.AreEqual(m1DataItem, actualDataItemBase);

            CompositeDataItem cdi = target.SelectedCompositeDataItem;
            Assert.AreEqual(4, cdi.CollectionOfData.Count);
       
        }

        /// <summary>
        ///A test for SelectedItemCommand
        ///</summary>
        //[TestMethod()]
        public void DataItemBrowserViewModel_SelectedItemCommandTest_HMIDevice()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            target.Path.Clear();
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("t1", "", true));
            string expected = "::c1.t1.m1";

            DataItemBase m1DataItem = PathElementUtility.Instance().CreateDataItemBase("m1");
            target.SelectedItemCommand.Execute(m1DataItem);

            string actual = target.SelectedItemPath;
            Assert.AreEqual(expected, actual);

            DataItemBase actualDataItemBase = target.SelectedDataItemBase;
            Assert.AreEqual(m1DataItem, actualDataItemBase);

            CompositeDataItem cdi = target.SelectedCompositeDataItem;
            Assert.AreEqual(3, cdi.CollectionOfData.Count);

        }

        /// <summary>
        /// A test for SelectedItemCommand CanExecute
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_SelectedItemCommandTest_CanExecuteTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            bool expected = true;
            ICommand targetCommand = target.SelectedItemCommand;
            bool actual = targetCommand.CanExecute("junk");
            Assert.AreEqual(expected, actual);
            target.Path.Clear();
        }

        /// <summary>
        /// A test for SelectedItemCommand Execute
        ///</summary>
        [TestMethod()]
        public void CommandReference_ExecuteTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            target.Path.Add(PathElementUtility.Instance().CreateHomePathElement(""));
            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement("Controller1"));
            target.Path.Add(PathElementUtility.Instance().CreateProgramsPathElement());
            target.Path.Add(PathElementUtility.Instance().CreateProgramPathElement("Program1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagPathElement("Tag1", "", true));

            DataItemBase dataItem = new DataItemBase() { 
                CommonID = PathElementUtility.getTest_DATATYPE_MEMBER_COMMON_ID().ToString(), 
                CommonName = "member1", 
                CommonResourceType = TypeIdentifiers.ResourceType_DataTypeMember.ToString(),
                IsStructured = false};

            ICommand command = target.SelectedItemCommand;
            string expected = "::Controller1\\Program1.Tag1.member1";
            command.Execute(dataItem);
            Assert.AreEqual(expected, target.SelectedItemPath);

            //validate resource id contents of this item      
            int i = 0;
            CompositeDataItem cdi = target.SelectedCompositeDataItem;
            Assert.AreEqual(5, cdi.CollectionOfData.Count);
            foreach (RockwellAutomation.UI.Resources.CompositeDataItem.DataItemResourceID dataItemResource in cdi.CollectionOfData)
            {
                switch (i)
                {
                    case 1: //controller1
                        Assert.AreEqual(dataItemResource.ResourceID, PathElementUtility.getTest_CONTROLLER_COMMON_ID());
                        Assert.AreEqual(dataItemResource.ResourceTypeID, TypeIdentifiers.getResourceType_Controller());
                        Assert.AreEqual(dataItemResource.Dimensions, string.Empty);
                        Assert.AreEqual(dataItemResource.Bit, string.Empty);
                        break;
                    case 2: //program1
                        Assert.AreEqual(dataItemResource.ResourceID, PathElementUtility.getTest_PROGRAM_COMMON_ID());
                        Assert.AreEqual(dataItemResource.ResourceTypeID, TypeIdentifiers.ResourceType_Program);
                        Assert.AreEqual(dataItemResource.Dimensions, string.Empty);
                        Assert.AreEqual(dataItemResource.Bit, string.Empty);
                        break;
                    case 3: //tag1
                        Assert.AreEqual(dataItemResource.ResourceID, PathElementUtility.getTest_TAG_COMMON_ID());
                        Assert.AreEqual(dataItemResource.ResourceTypeID, TypeIdentifiers.ResourceType_Tag);
                        Assert.AreEqual(dataItemResource.Dimensions, string.Empty);
                        Assert.AreEqual(dataItemResource.Bit, string.Empty);
                        break;
                    case 4: //member1
                        Assert.AreEqual(dataItemResource.ResourceID, PathElementUtility.getTest_DATATYPE_MEMBER_COMMON_ID());
                        Assert.AreEqual(dataItemResource.ResourceTypeID, TypeIdentifiers.ResourceType_DataTypeMember);
                        Assert.AreEqual(dataItemResource.Dimensions, string.Empty);
                        Assert.AreEqual(dataItemResource.Bit, string.Empty);
                        break;
                }
                i++;

            }

            target.Path.Clear();
        }

        /// <summary>
        ///A test for UserSetHighlightedItemCommand
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_UserSetHighlightedItemCommandTest()
        {
            DataItemBrowserViewModelTestInit (DIResource.DI_COMMON_RESOURCETYPE_TAG);
            List<IPathElement> myPath = new List<IPathElement>();
            myPath.Add(PathElementUtility.Instance().CreateHomePathElement(""));
            myPath.Add(PathElementUtility.Instance().CreateControllerPathElement("c1"));
            myPath.Add(PathElementUtility.Instance().CreateProgramsPathElement());
            myPath.Add(PathElementUtility.Instance().CreateProgramPathElement("p1"));
            myPath.Add(PathElementUtility.Instance().CreateDataItemPathElement("t1", "", true));
            myPath.Add(PathElementUtility.Instance().CreateDataItemPathElement("m1", "", true));

            PrivateObject privatePath = new PrivateObject(target.Path);
            privatePath.SetProperty("UserSetHighlightedPath", myPath);

            string expected = "::c1\\p1.t1.m1";

            DataItemBase m1DataItem = PathElementUtility.Instance().CreateDataItemBase("m1");
            target.UserSetHighlightedItemCommand.Execute(m1DataItem);

            string actual = target.UserSetHighlightedItemPath;
            Assert.AreEqual(expected, actual);

            CompositeDataItem cdi = target.UserSetHighlightedItemResourceID;
            Assert.AreEqual(5, cdi.CollectionOfData.Count);
        }

        /// <summary>
        ///A test for UserSetHighlightedItemCommand
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_UserSetHighlightedItemCommandTest_HMIDevice()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            List<IPathElement> myPath = new List<IPathElement>();
            myPath.Add(PathElementUtility.Instance().CreateHomePathElement(""));
            myPath.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            myPath.Add(PathElementUtility.Instance().CreateDataItemPathElement("t1", "", true));
            myPath.Add(PathElementUtility.Instance().CreateDataItemPathElement("m1", "", true));
            PrivateObject privatePath = new PrivateObject(target.Path);
            privatePath.SetProperty("UserSetHighlightedPath", myPath);
            
            string expected = "::c1.t1.m1";

            DataItemBase m1DataItem = PathElementUtility.Instance().CreateDataItemBase("m1");
            target.UserSetHighlightedItemCommand.Execute(m1DataItem);

            string actual = target.UserSetHighlightedItemPath;
            Assert.AreEqual(expected, actual);

            CompositeDataItem cdi = target.UserSetHighlightedItemResourceID;
            Assert.AreEqual(4, cdi.CollectionOfData.Count);
        }


        /// <summary>
        ///A test for Path
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_PathTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            Path expected = new Path();
            //inconsistent behavior with the unit tests not cleaning up properly, so added the clear here
            target.Path.Clear();  
            string controllerName = "pathController";
            string tagName = "pathTag";
            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(controllerName));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            
            List<IPathElement> actual = target.Path.SelectedPath;
            Assert.AreEqual(controllerName, actual[0].DisplayName);
            Assert.AreEqual(tagName, actual[1].DisplayName);
        }

        /// <summary>
        ///A test for Path
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_PathTest_HMIDevice()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);     
            Path expected = new Path();
            //inconsistent behavior with the unit tests not cleaning up properly, so added the clear here
            target.Path.Clear();
            string controllerName = "pathController";
            string tagName = "pathTag";
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controllerName));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));

            List<IPathElement> actual = target.Path.SelectedPath;
            Assert.AreEqual(controllerName, actual[0].DisplayName);
            Assert.AreEqual(tagName, actual[1].DisplayName);
        }

        /// <summary>
        ///A test for ItemSelectionChangedCommand
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ItemSelectionChangedCommand_SuccessTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            string controllerName = "controller1";
            string tagName = "testPath";

            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(controllerName));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            string expected = "::"+controllerName + "." + tagName;
            target.ItemSelectionChangedCommand.Execute(target.Path.SelectedPath);
            Assert.AreEqual(expected,target.SelectedItemPath);
        }

        /// <summary>
        ///A test for ItemSelectionChangedCommand
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ItemSelectionChangedCommand_SuccessTest_HMIDevice()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            string controllerName = "controller1";
            string tagName = "testPath";

            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controllerName));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            string expected = "::" + controllerName + "." + tagName;
            target.ItemSelectionChangedCommand.Execute(target.Path.SelectedPath);
            Assert.AreEqual(expected, target.SelectedItemPath);
        }

       
        /// <summary>
        ///A test for ItemSelectionChangedCommand
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ItemSelectionChangedCommand_Success2Test()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            string controllerName = "controller1";
            string tagName = "testPath";
            string highlightedTag = "highLightTag";

            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(controllerName));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            target.Path.HighlightedElement = PathElementUtility.Instance().CreateDataItemPathElement(highlightedTag, "", true);
            string expected = "::" + controllerName + "." + tagName + "." + highlightedTag;
            target.ItemSelectionChangedCommand.Execute(target.Path.HighlightedElement);
            Assert.AreEqual(expected, target.SelectedItemPath);
        }

        /// <summary>
        ///A test for ItemSelectionChangedCommand
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ItemSelectionChangedCommand_Success2Test_HMIDevice()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            string controllerName = "Controller1";
            string tagName = "testPath";
            string highlightedTag = "highLightTag";

            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controllerName));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            target.Path.HighlightedElement = PathElementUtility.Instance().CreateDataItemPathElement(highlightedTag, "", true);
            string expected = "::" + controllerName + "." + tagName + "." + highlightedTag;
            target.ItemSelectionChangedCommand.Execute(target.Path.HighlightedElement);
            Assert.AreEqual(expected, target.SelectedItemPath);
        }


        /// <summary>
        ///A test for ItemSelectionChangedCommand
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ItemSelectionChangedCommand_FromHomeTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            string controllerName = "controller1";
            string tagName = "testPath";
            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement(controllerName));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            target.Path.SetActive(null);
            string expected = "";
            target.ItemSelectionChangedCommand.Execute(target.Path.SelectedPath);
            Assert.AreEqual(expected, target.SelectedItemPath);
        }

        /// <summary>
        ///A test for ItemSelectionChangedCommand
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ItemSelectionChangedCommand_FromHomeTest_HMIDevice()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            string controllerName = "controller1";
            string tagName = "testPath";
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement(controllerName));
            target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement(tagName, "", true));
            target.Path.SetActive(null);
            string expected = "";
            target.ItemSelectionChangedCommand.Execute(target.Path.SelectedPath);
            Assert.AreEqual(expected, target.SelectedItemPath);
        }

        /// <summary>
        ///A test for IsSearchEnabled
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_SearchEnabledTest_HmiDevice()
        {            
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);

            IPathElement Home = PathElementUtility.Instance().CreateHomePathElement("");
            target.Path.Add(Home);

            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("HMIName"));

            //navigate updates the IsSearchEnabled property
            target.Navigate(target.Path.Last.DataItem);
            Assert.IsTrue(target.IsSearchEnabled);
        }

        /// <summary>
        ///A test for IsSearchEnabled
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_SearchEnabledTest_Controller()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);

            IPathElement Home = PathElementUtility.Instance().CreateHomePathElement("");
            target.Path.Add(Home);

            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement("ControllerName"));
            
            //navigate updates the IsSearchEnabled property           
            target.Navigate(target.Path.Last.DataItem);
            Assert.IsTrue(target.IsSearchEnabled);
        }
       
        /// <summary>
		///A test for IsSearchEnabled for the data sources view
		///</summary>
		[TestMethod()]
		public void DataItemBrowserViewModel_SearchEnabledTest_Devices()
		{
            // Using a different UUID for Package and Project UUID resets variables in the static DIBPersistedVariables class
            UUID tPackageContext = UUID.CreateBuilder().SetHi(2UL).SetLo(3UL).Build();
            UUID tProjectContext = UUID.CreateBuilder().SetHi(2UL).SetLo(3UL).Build();

            //Reinitialize DIBClientManager with diferent UUIDs than last time
            DIBClientManagerForViewe.Instance = new DIBClientManagerForViewe(DIBViewItemBase.VisualPerspectiveEnum.TagBrowser, tProjectContext, tPackageContext);
            DIBClientManagerForViewe.InitializeVieweSpecificClasses();

            //Initialize sets the IsSearchEnabled for the type of browser
            DataItemBrowserViewModelTestInit(tPackageContext, tProjectContext, DIResource.DI_COMMON_RESOURCETYPE_TAG);
           
           if (String.IsNullOrWhiteSpace(target.ProblemText))
                Assert.IsTrue(target.IsSearchEnabled);
            else
                Assert.IsFalse(target.IsSearchEnabled);
		}

		/// <summary>
		///A test for IsSearchEnabled for the data types view
		///</summary>
		[TestMethod()]
		public void DataItemBrowserViewModel_SearchEnabledTest_DataTypes()
		{
            //Initialize sets the IsSearchEnabled for the type of browser
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_DATATYPE);
           
            Assert.IsFalse(target.IsSearchEnabled);
		}

		/// <summary>
		///A test for IsSearchEnabled
		///</summary>
		[TestMethod()]
		public void DataItemBrowserViewModel_SearchEnabledTest_DataType_User()
		{            
			//Since we don't differentiate the breadcrumbs for each type of data type, this one test suits system and module as well			
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_DATATYPE);

			IPathElement Home = PathElementUtility.Instance().CreateHomePathElement("");
			target.Path.Add(Home);
			target.Path.Add(PathElementUtility.Instance().CreateDataItemPathElement("UserDefined", "", true));

            //the navigate is what triggers the update to IsSearchEnabled
            target.Navigate(target.Path.Last.DataItem);

            if (target.ProblemText != "")
                Assert.IsFalse(target.IsSearchEnabled);
            else
                Assert.IsTrue(target.IsSearchEnabled);
		}
    
        /// <summary>
        ///A test for ExecuteFilterCommand via PerformFilter
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ExecuteFilterCommand_SuccessTest()
        {
            //ARRANGE
            // SearchBreadCrumChanged event is thrown in PerformFilter
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            _addSearchCrumb = false;
            target.SearchBreadCrumbChanged += new PropertyChangedEventHandler(target_SearchBreadCrumbChanged);

			Assert.IsFalse(target.IsSearchActive);
           
            A.CallTo(() => fakeSearchFilterControlViewModel.SearchFilterText).Returns("DataType:DINT");
            A.CallTo(() => fakeSearchFilterControlViewModel.HasNonEmptySearchValue).Returns(true);
            //return true that the call to search was successful
            A.CallTo(() => fakeClientDataServices.Search(A<DataItemBase>.Ignored, A<SearchFilterConfig>.Ignored)).Returns(true);

           //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsTrue(_addSearchCrumb);

            //ARRANGE
            _addSearchCrumb = false;
            A.CallTo(() => fakeSearchFilterControlViewModel.SearchFilterText).Returns("dt:DINT");
            
            //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsTrue(_addSearchCrumb);
			Assert.IsTrue(target.IsSearchActive);
        }

        /// <summary>
        /// A test for ExecuteFilterCommand via PerformFilter
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ExecuteFilterCommandFailTest()
        {
            //ARRANGE
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            // SearchBreadCrumbChanged event is thrown in PerformFilter
            _addSearchCrumb = true;
            target.SearchBreadCrumbChanged += new PropertyChangedEventHandler(target_SearchBreadCrumbChanged);

			Assert.IsFalse(target.IsSearchActive);

            A.CallTo(() => fakeSearchFilterControlViewModel.SearchFilterText).Returns("datatype:");
            A.CallTo(() => fakeSearchFilterControlViewModel.HasNonEmptySearchValue).Returns(true);
            A.CallTo(() => fakeSearchFilterControlViewModel.HasError).Returns(true);

            //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsFalse(_addSearchCrumb);
            
            //should call NotifyNavigateStateChanged(false);
            Assert.IsTrue(AsynOperationComplete);
            Assert.IsFalse(target.IsSearchActive);
            Assert.AreEqual(null, _itemToSelect);

            //ARRANGE            
            A.CallTo(() => fakeSearchFilterControlViewModel.SearchFilterText).Returns("dt:");
            A.CallTo(() => fakeSearchFilterControlViewModel.HasNonEmptySearchValue).Returns(true);
            A.CallTo(() => fakeSearchFilterControlViewModel.HasError).Returns(true);
            _addSearchCrumb = true;

            //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsFalse(_addSearchCrumb);            
            Assert.IsTrue(AsynOperationComplete);
            Assert.IsFalse(target.IsSearchActive);
            Assert.AreEqual(null, _itemToSelect);
        }



        /// <summary>
        ///A test for Path_PropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_Path_PropertyChangedTest()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
           
            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement("c1"));
            const string highlightedName = "PropChangedTag";
            target.Path.HighlightedElement = PathElementUtility.Instance().CreateTagPathElement(highlightedName,string.Empty,true);
            
            PropertyChangedEventArgs e = new PropertyChangedEventArgs("HighlightedElement");
            object[] args = new object[2];
            args[0] = null;
            args[1] = e;
            PrivateObject private_target = new PrivateObject(target);
            private_target.Invoke("Path_PropertyChanged",args);
            
            int index = target.SelectedItemPath.LastIndexOf(".");
            string name = target.SelectedItemPath.Substring(index + 1, target.SelectedItemPath.Length - (index + 1));
            Assert.AreEqual(highlightedName, name);
        }

        /// <summary>
        ///A test for NotifySelectedItemPathChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_NotifySelectedItemPathChangedTest()
        {
            BackgroundWorkerSyncContextHelper.DoTests(() =>
            {
                DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG);
                PrivateObject dibVmPO = new PrivateObject(target);
                target.Initialize(null, string.Empty);
                dibVmPO.SetFieldOrProperty("SelectedItemPath", "::Controller1\\");
                dibVmPO.Invoke("add_SelectedItemPathChanged", new PropertyChangedEventHandler(SelectedItemPathChanged));
                dibVmPO.Invoke("NotifySelectedItemPathChanged");
                Assert.AreEqual(_selectedItem, target.SelectedItemPath);
            });
        }
       
        /// <summary>
        ///A test for NotifyUserSetHighlightedItemPathChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_NotifyUserSetHighlightedItemPathChangedTest()
        {
            BackgroundWorkerSyncContextHelper.DoTests(() =>
            {
                DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG);
                PrivateObject dibVmPO = new PrivateObject(target);

                target.Initialize(null, string.Empty);
                dibVmPO.SetFieldOrProperty("UserSetHighlightedItemPath", "::Controller1\\");
                dibVmPO.Invoke("add_UserSetHighlightedItemPathChanged", new PropertyChangedEventHandler(UserSetHighlightedItemPathChanged));
                dibVmPO.Invoke("NotifyUserSetHighlightedItemPathChanged");
                Assert.AreEqual(_userSetHighlightedItem, target.UserSetHighlightedItemPath);
            });
        }

       
        /// <summary>
        ///A test for NotifyDoubleClickSelect
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_NotifyDoubleClickSelectTest()
        {
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG);
            PrivateObject dibVmPO = new PrivateObject(target);

            dibVmPO.Invoke("add_DoubleClickSelect", new PropertyChangedEventHandler(doubleClickSelect));
            bool expected = true;
            _doubleClickSelect = false;
            dibVmPO.Invoke("NotifyDoubleClickSelect");
            Assert.AreEqual(expected, _doubleClickSelect);
        }       

		/// <summary>
		///A test for NotifyTreeViewOCChanged
		///</summary>
		[TestMethod()]
		[DeploymentItem("RA.Common.DIB.dll")]
		public void DataItemBrowserViewModel_NotifyDataSourceOCChangedTest()
		{
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG); 
            PrivateObject dibVmPO = new PrivateObject(target);

		    dibVmPO.Invoke("add_TreeViewOCChanged", new PropertyChangedEventHandler(TreeViewOCChanged));

		    string selectedName = "anotherName";
            dibVmPO.Invoke("NotifyTreeViewOCChanged", selectedName);
		    Assert.AreEqual(selectedName, _selectedDataSource);
		}
      
        /// <summary>
        ///A test for NotifyDataGridOCChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DataItemBrowserViewModel_NotifyDataGridOCChangedTest()
        {
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG); 
            PrivateObject dibVmPO = new PrivateObject(target);

            dibVmPO.Invoke("add_DataGridOCChanged", new PropertyChangedEventHandler(DataGridOCChanged));
            DataItemBase ItemToSelect = new DataItemBase() { CommonName = "selectedDataItemBase" };

            dibVmPO.Invoke("NotifyDataGridOCChanged", ItemToSelect);
            Assert.AreEqual(ItemToSelect.CommonName, _itemToSelect.CommonName);
        }

       
      

        ///<summary>
        /// A test for Close
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_CloseTest()
        {
            BackgroundWorkerSyncContextHelper.DoTests(() =>
            {
                DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG);
                target.Initialize(null, string.Empty);
                target.Close();
				//ROAQ
				//Assert.IsNull(target._viewModel);
            });
        }      

        ///<summary>
        /// A test for IsClientSideSearch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_IsClientSideSearch_NotActive_InitialState_True()
        {
             //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Initial;
            var fakeIClientDataServices = A.Fake<IClientDataServices>();
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeIClientDataServices);
            target.IsQueryBasedSearchActive = false;

            //ACT
            bool result = target.IsClientSideSearch();

            //ASSERT
            Assert.IsTrue(result);                                                                    
        }

        ///<summary>
        /// A test for IsClientSideSearch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_IsClientSideSearch_NotActive_SearchingState_True()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Searching;
            var fakeIClientDataServices = A.Fake<IClientDataServices>();
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeIClientDataServices);
            target.IsQueryBasedSearchActive = false;

            //ACT
            bool result = target.IsClientSideSearch();

            //ASSERT
            Assert.IsTrue(result);
        }

        ///<summary>
        /// A test for IsClientSideSearch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_IsClientSideSearch_NotActive_CancellingState_False()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Canceling;
            var fakeIClientDataServices = A.Fake<IClientDataServices>();
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeIClientDataServices);
            target.IsQueryBasedSearchActive = false;

            //ACT
            bool result = target.IsClientSideSearch();

            //ASSERT
            Assert.IsTrue(result);
        }

        ///<summary>
        /// A test for IsClientSideSearch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_IsClientSideSearch_Active_CancellingState_False()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Canceling;
            var fakeIClientDataServices = A.Fake<IClientDataServices>();
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeIClientDataServices);
            target.IsQueryBasedSearchActive = true;

            //ACT
            bool result = target.IsClientSideSearch();

            //ASSERT
            Assert.IsFalse(result);
        }

        ///<summary>
        /// A test for IsClientSideSearch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_IsClientSideSearch_Active_SearchingState_False()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Searching;
            var fakeIClientDataServices = A.Fake<IClientDataServices>();
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeIClientDataServices);
            target.IsQueryBasedSearchActive = true;

            //ACT
            bool result = target.IsClientSideSearch();

            //ASSERT
            Assert.IsFalse(result);
        }

        ///<summary>
        /// A test for IsClientSideSearch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_IsClientSideSearch_Active_InitialState_False()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Initial;
            var fakeIClientDataServices = A.Fake<IClientDataServices>();
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeIClientDataServices);
            target.IsQueryBasedSearchActive = true;

            //ACT
            bool result = target.IsClientSideSearch();

            //ASSERT
            Assert.IsFalse(result);
        }


        ///<summary>
        /// A test for PopulatePathFromDataItemPath
        /// called when a tag is selected from the search view
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_PopulatePathFromDataItemPath_SelectHMITag_verifyHMITagsAndPropertiesCreated()
        {
            //ARRANGE
            var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Initial;
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            //create dataitembase to be returned from the CDS call internal to the method under test
            PathElementUtility peUtility = PathElementUtility.Instance();
            DataItemBase controller1 = peUtility.CreateDataItemBase("c1");
            controller1.SetVieweReplicationState("SYNCHED");
            controller1.SetVieweReplicationErrorMessage(String.Empty);
            controller1.CommonID = "hi: 2053511652086794620\nlo: 13169019947325935803\n";
            controller1.CommonResourceType = TypeIdentifiers.ResourceType_Device.ToString(); 
            controller1.CommonDBId = "hi: 2663100995484601513\nlo: 10837620680844918234\n";
            A.CallTo(() => fakeClientDataServices.GetDeviceItemByName(A<string>.Ignored)).Returns(controller1);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeClientDataServices);
            target.Path.Clear();

            //create dataitembase for the selected item
            DataItemBase selectedItem = peUtility.CreateDataItemBase("Bool_UDT_ScalarArray1");
            selectedItem.CommonLocation = "::c1";
            selectedItem.CommonDataType = "ALARM";
            selectedItem.SetStringMapValue("Dimensions", String.Empty);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));

            //ACT
            bool callbackCalled = target.PopulatePathFromDataItemPath(selectedItem, null);

            //ASSERT            
            Assert.IsFalse(callbackCalled);
            IPathElement actualLastPathElement = target.Path.Last;
            Assert.AreEqual(DIResource.DI_COMMON_RESOURCETYPE_HMITAGSPROPERTIES, actualLastPathElement.DisplayName);
        }

         ///<summary>
        /// A test for PopulatePathFromDataItemPath
        /// called when a tag is selected from the search view
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_PopulatePathFromDataItemPath_SelectControllerTag_verifyTagsAndPropertiesCreated()
         {
            //ARRANGE
             var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
             fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Initial;
             var fakeClientDataServices = A.Fake<IClientDataServices>();
             //create dataitembase to be returned from the CDS call internal to the method under test
             PathElementUtility peUtility = PathElementUtility.Instance();
             DataItemBase controller1 = peUtility.CreateDataItemBase("c1");
             controller1.SetVieweReplicationState("SYNCHED");
             controller1.SetVieweReplicationErrorMessage(String.Empty);
             controller1.CommonID = "hi: 2053511652086794620\n lo: 13169019947325935803\n";
             controller1.CommonResourceType = "hi: 8181955947408408666\n lo: 11502104724403191811\n";
             controller1.CommonDBId = "hi: 2663100995484601513\n lo: 10837620680844918234\n";
             A.CallTo(() => fakeClientDataServices.GetDeviceItemByName(A<string>.Ignored)).Returns(controller1);

            //create the class under test 
             DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeClientDataServices);
             target.Path.Clear();

            //create dataitembase for the selected item
            DataItemBase selectedItem = peUtility.CreateDataItemBase("Bool_UDT_ScalarArray1");
            selectedItem.CommonLocation = "::c1";
            selectedItem.CommonDataType = "ALARM";
            selectedItem.SetStringMapValue("Dimensions", String.Empty);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateControllerPathElement("c1"));

            //ACT
            bool callbackCalled = target.PopulatePathFromDataItemPath(selectedItem, null);

            //ASSERT            
            Assert.IsFalse(callbackCalled);
            IPathElement actualLastPathElement = target.Path.Last;
            Assert.AreEqual(DIResource.DI_COMMON_RESOURCETYPE_CONTROLLERTAGSPROPERTIES, actualLastPathElement.DisplayName);
         }

         ///<summary>
        /// A test for PopulatePathFromDataItemPath
        /// called when a tag is selected from the search view
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_PopulatePathFromDataItemPath_SelectProgramTag_verifyProgramsCreated()
         {
             //ARRANGE
             var fakeViewModel = A.Fake<ISearchFilterControlViewModel>();
             fakeViewModel.CurrentState = SearchFilterControlViewModel.FilterState.Initial;
             var fakeClientDataServices = A.Fake<IClientDataServices>();
             //create dataitembase to be returned from the CDS call internal to the method under test
             PathElementUtility peUtility = PathElementUtility.Instance();
             DataItemBase controller1 = peUtility.CreateDataItemBase("c1");
             controller1.SetVieweReplicationState("SYNCHED");
             controller1.SetVieweReplicationErrorMessage(String.Empty);
             controller1.CommonID = "hi: 2053511652086794620\n lo: 13169019947325935803\n";
             controller1.CommonResourceType = "hi: 8181955947408408666\n lo: 11502104724403191811\n";
             controller1.CommonDBId = "hi: 2663100995484601513\n lo: 10837620680844918234\n";
             A.CallTo(() => fakeClientDataServices.GetDeviceItemByName(A<string>.Ignored)).Returns(controller1);

            //set up DrillIn return
            A.CallTo(()=>fakeClientDataServices.DrillIn(A<DataItemBase>.Ignored,A<DataLoadComplete>.Ignored)).Returns(true);

            //create dataitembase to be returned from the CDS call internal to the method under test
            DataItemBase program1 = peUtility.CreateDataItemBase("Program_1");
            program1.CommonDescription = "Program for Task1. Testing to support US0528.";
            program1.CommonID = "hi: 2053511652086794620\nlo: 13169019947325935803\n";
            program1.CommonResourceType = "hi: 8181955947408408666\nlo: 11502104724403191811\n";
            program1.CommonDBId = "hi: 2663100995484601513\nlo: 10837620680844918234\n";
            A.CallTo(() => fakeClientDataServices.GetDataItemByName(A<string>.Ignored,A<string>.Ignored)).Returns(program1);

             //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeViewModel, fakeClientDataServices);

             //create dataitembase for the selected item
            DataItemBase selectedItem = peUtility.CreateDataItemBase("Pgm_SingleDINT");
            selectedItem.CommonLocation = "::c1\\Program_1";
            selectedItem.CommonDataType = "DINT";
            selectedItem.SetStringMapValue("Dimensions", String.Empty);

             //set up the Path parameter in the DIBVM used in the method under test
             List<DataItemBase> dataItems = new List<DataItemBase>();
             dataItems.Add(null);
             target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
             target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));

             //ACT
             bool callbackCalled = target.PopulatePathFromDataItemPath(selectedItem, null);

             //ASSERT            
             Assert.IsFalse(callbackCalled);
             IPathElement actualLastPathElement = target.Path.Last;
             Assert.AreEqual(actualLastPathElement.DisplayName, DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS);  
         }

        ///<summary>
        /// A test for ProcessFilter
        /// called the search text has been updated or during the initialization of the DIB if a filter was passed in
        /// through the datacontext
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ProcessFilter_ValidSearchText_SearchViaQuery_VerifyProperties()
        {
            //ARRANGE
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeSearchFilterControlViewModel.SearchFilterText = "array";
            fakeSearchFilterControlViewModel.HasNonEmptySearchValue = true;
            fakeSearchFilterControlViewModel.HasError = false;
            //TODO set this up
            SearchFilterConfig searchFilterConfig = null;
            A.CallTo(() => fakeSearchFilterControlViewModel.GetFilterConfig()).Returns(searchFilterConfig);

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.Search(A<DataItemBase>.Ignored, A<SearchFilterConfig>.Ignored)).Returns(true);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);

            //setup properties/methods for class under test
            target.IsSearchActive = false;
            target.IsQueryBasedSearchActive = false;
            target.ProblemText = string.Empty;
            
            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));

            //register for PropertyChangedEvents            
            target.DataGridOCChanged +=new PropertyChangedEventHandler(DataGridOCChanged);
            target.SearchBreadCrumbChanged += new PropertyChangedEventHandler(target_SearchBreadCrumbChanged);
            target.DataGridColsChanged +=new PropertyChangedEventHandler(target_DataGridColsChanged);
            target.NavigateStateChanged +=new PropertyChangedEventHandler(target_NavigateStateChanged);

            //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsTrue(_notifiedOfDataGridColsChanged);
            Assert.IsTrue(target.IsQueryBasedSearchActive);
            Assert.IsTrue(_addSearchCrumb);

        }

        private void UnregisterForEvents()
        {
            if (target == null) return;
            target.DataGridOCChanged -= new PropertyChangedEventHandler(DataGridOCChanged);
            target.SearchBreadCrumbChanged -= new PropertyChangedEventHandler(target_SearchBreadCrumbChanged);
            target.DataGridColsChanged -= new PropertyChangedEventHandler(target_DataGridColsChanged);
            target.NavigateStateChanged -= new PropertyChangedEventHandler(target_NavigateStateChanged);
        }
        
        ///<summary>
        /// A test for ProcessFilter
        /// called the search text has been updated or during the initialization of the DIB if a filter was passed in
        /// through the datacontext
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ProcessFilter_EmptySearchText_QueryBasedSearchActive_VerifyProperties()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);

            //ARRANGE
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeSearchFilterControlViewModel.SearchFilterText = string.Empty;
            fakeSearchFilterControlViewModel.HasNonEmptySearchValue = false;
            fakeSearchFilterControlViewModel.HasError = false;

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.Search(A<DataItemBase>.Ignored, A<SearchFilterConfig>.Ignored)).Returns(true);
            //set up DrillIn return
            A.CallTo(() => fakeClientDataServices.DrillIn(A<DataItemBase>.Ignored, A<DataLoadComplete>.Ignored)).Returns(true);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);

            //setup properties/methods for class under test
            target.IsSearchActive = false;
            target.IsQueryBasedSearchActive = true;
            target.ProblemText = string.Empty;

            //register for PropertyChangedEvents            
            target.DataGridOCChanged += new PropertyChangedEventHandler(DataGridOCChanged);
            target.SearchBreadCrumbChanged += new PropertyChangedEventHandler(target_SearchBreadCrumbChanged);
            target.DataGridColsChanged += new PropertyChangedEventHandler(target_DataGridColsChanged);
            target.NavigateStateChanged += new PropertyChangedEventHandler(target_NavigateStateChanged);

            //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsFalse(_notifiedOfDataGridColsChanged, "DataGridColsChanged = " + _notifiedOfDataGridColsChanged);
            Assert.IsFalse(target.IsQueryBasedSearchActive, "IsQueryBasedSearchActive = " + target.IsQueryBasedSearchActive);
            Assert.IsFalse(_addSearchCrumb);
            Assert.IsFalse(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //begin == true
            Assert.IsTrue(target.IsSearchEnabled);
           
        }

        ///<summary>
        /// A test for ProcessFilter
        /// called the search text has been updated or during the initialization of the DIB if a filter was passed in
        /// through the datacontext
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ProcessFilter_SearchTextValid_SearchViaQuery_VerifyProperties()
        {
            //ARRANGE
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeSearchFilterControlViewModel.SearchFilterText = "array";
            fakeSearchFilterControlViewModel.HasNonEmptySearchValue = true;
            fakeSearchFilterControlViewModel.HasError = false;
            //TODO set this up
            SearchFilterConfig searchFilterConfig = null;
            A.CallTo(() => fakeSearchFilterControlViewModel.GetFilterConfig()).Returns(searchFilterConfig);

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.Search(A<DataItemBase>.Ignored, A<SearchFilterConfig>.Ignored)).Returns(false);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);

            //setup properties/methods for class under test
            target.IsSearchActive = false;
            target.IsQueryBasedSearchActive = false;
            target.ProblemText = string.Empty;

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));

            //register for PropertyChangedEvents            
            target.DataGridOCChanged += new PropertyChangedEventHandler(DataGridOCChanged);
            target.SearchBreadCrumbChanged += new PropertyChangedEventHandler(target_SearchBreadCrumbChanged);
            target.DataGridColsChanged += new PropertyChangedEventHandler(target_DataGridColsChanged);
            target.NavigateStateChanged += new PropertyChangedEventHandler(target_NavigateStateChanged);

            //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsTrue(_notifiedOfDataGridColsChanged, "_notifiedOfDataGridColsChanged = " + _notifiedOfDataGridColsChanged);
            Assert.IsNull(_itemToSelect, "_itemToSelect = " + _itemToSelect);
            Assert.IsFalse(target.IsQueryBasedSearchActive, "IsQueryBasedSearchActive = " + target.IsQueryBasedSearchActive);
            Assert.IsTrue(_addSearchCrumb, "_addSearchCrumb = " + _addSearchCrumb);


        }

        ///<summary>
        /// A test for ProcessFilter
        /// called the search text has been updated or during the initialization of the DIB if a filter was passed in
        /// through the datacontext
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ProcessFilter_SearchTextValid_NotSearchViaQuery_VerifyProperties()
        {
            //ARRANGE
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeSearchFilterControlViewModel.SearchFilterText = "array";
            fakeSearchFilterControlViewModel.HasNonEmptySearchValue = true;
            fakeSearchFilterControlViewModel.HasError = false;
            //TODO set this up
            SearchFilterConfig searchFilterConfig = null;
            A.CallTo(() => fakeSearchFilterControlViewModel.GetFilterConfig()).Returns(searchFilterConfig);

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.Search(A<DataItemBase>.Ignored, A<SearchFilterConfig>.Ignored)).Returns(false);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);

            //setup properties/methods for class under test
            target.IsSearchActive = false;
            target.IsQueryBasedSearchActive = false;
            target.ProblemText = string.Empty;

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagPathElement("tag1",string.Empty));

            //register for PropertyChangedEvents            
            target.DataGridOCChanged += new PropertyChangedEventHandler(DataGridOCChanged);
            target.SearchBreadCrumbChanged += new PropertyChangedEventHandler(target_SearchBreadCrumbChanged);
            target.DataGridColsChanged += new PropertyChangedEventHandler(target_DataGridColsChanged);
            target.NavigateStateChanged += new PropertyChangedEventHandler(target_NavigateStateChanged);

            //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsTrue(_notifiedOfDataGridColsChanged, "_notifiedOfDataGridColsChanged = " + _notifiedOfDataGridColsChanged);
            Assert.IsNull(_itemToSelect, "_itemToSelect = " + _itemToSelect);
            Assert.IsFalse(target.IsQueryBasedSearchActive, "IsQueryBasedSearchActive = " + target.IsQueryBasedSearchActive);
            Assert.IsTrue(_addSearchCrumb, "_addSearchCrumb = " + _addSearchCrumb);
            Assert.IsTrue(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //begin == false
        }

        ///<summary>
        /// A test for ProcessFilter
        /// called the search text has been updated or during the initialization of the DIB if a filter was passed in
        /// through the datacontext
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ProcessFilter_SearchTextValid_NotSearchViaQuery_ProblemText_VerifyProperties()
        {
            DataItemBrowserViewModelTestInit(DIResource.DI_COMMON_RESOURCETYPE_TAG);
            //ARRANGE
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();
            fakeSearchFilterControlViewModel.SearchFilterText = "array";
            fakeSearchFilterControlViewModel.HasNonEmptySearchValue = true;
            fakeSearchFilterControlViewModel.HasError = false;
            //TODO set this up
            SearchFilterConfig searchFilterConfig = null;
            A.CallTo(() => fakeSearchFilterControlViewModel.GetFilterConfig()).Returns(searchFilterConfig);

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            A.CallTo(() => fakeClientDataServices.Search(A<DataItemBase>.Ignored, A<SearchFilterConfig>.Ignored)).Returns(false);
            A.CallTo(() => fakeClientDataServices.DrillIn(A<DataItemBase>.Ignored)).Returns(false);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);

            //setup properties/methods for class under test
            target.IsSearchActive = false;
            target.IsQueryBasedSearchActive = false;
            target.ProblemText = "Something has gone terribly wrong";

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagPathElement("tag1", string.Empty));

            //register for PropertyChangedEvents            
            target.DataGridOCChanged += new PropertyChangedEventHandler(DataGridOCChanged);
            target.SearchBreadCrumbChanged += new PropertyChangedEventHandler(target_SearchBreadCrumbChanged);
            target.DataGridColsChanged += new PropertyChangedEventHandler(target_DataGridColsChanged);
            target.NavigateStateChanged += new PropertyChangedEventHandler(target_NavigateStateChanged);

            //ACT
            target.ProcessFilter();

            //ASSERT
            Assert.IsFalse(_notifiedOfDataGridColsChanged, "_notifiedOfDataGridColsChanged = " + _notifiedOfDataGridColsChanged);
            Assert.IsNull(_itemToSelect, "_itemToSelect = " + _itemToSelect);
            Assert.IsFalse(target.IsQueryBasedSearchActive, "IsQueryBasedSearchActive = " + target.IsQueryBasedSearchActive);
            Assert.IsTrue(_addSearchCrumb, "_addSearchCrumb = " + _addSearchCrumb);
            Assert.IsFalse(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //never triggered
            Assert.IsTrue(target.IsSearchActive);
        }


        ///<summary>
        /// A test for DataServicesLoadComplete
        /// callback called when the clientdataservices callback has been called from QSP
        /// simulate initial DIB launch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_DataServicesLoadComplete_HomePath_NoError_VerifyProperties()
        {
            //ARRANGE            
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //set up DataViewType
            var fakeDataView = A.Fake<IDIBDataViewType>();
            A.CallTo(() => fakeDataView.IsTreeView()).Returns(true);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            
            //register for events
            dibVmPO.Invoke("add_TreeViewOCChanged", new PropertyChangedEventHandler(TreeViewOCChanged));
            dibVmPO.Invoke("add_NavigateStateChanged", new PropertyChangedEventHandler(target_NavigateStateChanged));

            //ACT
            string error = string.Empty;
            dibVmPO.Invoke("DataServicesLoadComplete", error);

            //ASSERT
            Assert.AreEqual(_selectedDataSource,string.Empty, "_selectedDataSource = " + _selectedDataSource);
            Assert.IsTrue(target.IsSearchEnabled, "IsSearchEnabled = " + target.IsSearchEnabled);
            Assert.IsTrue(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //begin = false

        }

        ///<summary>
        /// A test for DataServicesLoadComplete
        /// callback called when the clientdataservices callback has been called from QSP
        /// simulate drilling into a controller
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_DataServicesLoadComplete_ControllerPath_NoError_VerifyProperties()
        {
            //ARRANGE            
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();           

            //set up DataViewType
            var fakeDataView = A.Fake<IDIBDataViewType>();
           // A.CallTo(() => fakeDataView.IsDataSourcesView()).Returns(false);
            A.CallTo(() => fakeDataView.IsListView()).Returns(true);
            fakeClientDataServices.DataView = fakeDataView;
            
            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));

            //register for events
            dibVmPO.Invoke("add_ListViewOCChanged", new PropertyChangedEventHandler(target_ListViewOCChanged));
            dibVmPO.Invoke("add_NavigateStateChanged", new PropertyChangedEventHandler(target_NavigateStateChanged));

            //ACT
            string error = string.Empty;
            dibVmPO.Invoke("DataServicesLoadComplete", error);
            
            //ASSERT
            A.CallTo(() => fakeClientDataServices.DataView.IsListView()).MustHaveHappened();
            Assert.IsTrue(_notifiedOfListViewOCChanged, "_notifiedOfListViewOCChanged = " + _notifiedOfListViewOCChanged);  
            Assert.IsTrue(target.IsSearchEnabled, "IsSearchEnabled = " + target.IsSearchEnabled);
            Assert.IsTrue(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //begin = false

        }

         ///<summary>
        /// A test for DataServicesLoadComplete
        /// callback called when the clientdataservices callback has been called from QSP
        /// Simulate drilling into a tag
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_DataServicesLoadComplete_TagPath_NoError_VerifyProperties()
         {
             //ARRANGE 
             //set up SearchFilterControlViewModel parameters/methods
             var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

             //set up ClientDataServices
             var fakeClientDataServices = A.Fake<IClientDataServices>();

             //set up DataViewType
             var fakeDataView = A.Fake<IDIBDataViewType>();
             A.CallTo(() => fakeDataView.IsListView()).Returns(false);

             //create the class under test 
             DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
             PrivateObject dibVmPO = new PrivateObject(target);

             //set up the Path parameter in the DIBVM used in the method under test
             List<DataItemBase> dataItems = new List<DataItemBase>();
             dataItems.Add(null);
             target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
             target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
             target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
             target.Path.Add(PathElementUtility.Instance().CreateTagPathElement("tag1", string.Empty));

             //register for events
            // target.add_DataGridOCChanged(new PropertyChangedEventHandler(target_DataGridOCChanged));
             dibVmPO.Invoke("add_NavigateStateChanged", new PropertyChangedEventHandler(target_NavigateStateChanged));

             //ACT
             string error = string.Empty;
             dibVmPO.Invoke("DataServicesLoadComplete", error);

             //ASSERT

             A.CallTo(() => fakeClientDataServices.DataView.IsListView()).MustHaveHappened();
            // Assert.IsTrue(_notifiedOfDataGridOCChanged, "_notifiedOfDataGridOCChanged = " + _notifiedOfDataGridOCChanged);
             Assert.IsTrue(target.IsSearchEnabled, "IsSearchEnabled = " + target.IsSearchEnabled);
             Assert.IsTrue(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //begin = false
         }

        ///<summary>
        /// A test for DataServicesLoadComplete
        /// callback called when the clientdataservices callback has been called from QSP
        /// Simulate launching with the selected item string set
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_DataServicesLoadComplete_SelectedItem_NoError_VerifyProperties()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
           
            //set up DataViewType
            var fakeDataView = A.Fake<IDIBDataViewType>();
            A.CallTo(() => fakeDataView.IsTreeView()).Returns(false);
            A.CallTo(() => fakeDataView.IsListView()).Returns(false);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
            target.Path.SavedHighlightedElement = PathElementUtility.Instance().CreateTagPathElement("AOI_UDT_NoArrayMembers3", "[30,20,10]");
            target.Path.SavedHighlightedElement.DataItem = PathElementUtility.Instance().CreateDataItemBase("AOI_UDT_NoArrayMembers3");

            //register for events
            dibVmPO.Invoke("add_DataGridOCChanged", new PropertyChangedEventHandler(target_DataGridOCChanged));
            dibVmPO.Invoke("add_NavigateStateChanged", new PropertyChangedEventHandler(target_NavigateStateChanged));

            ////ACT
            string error = string.Empty;
            dibVmPO.Invoke("DataServicesLoadComplete", error);
            

            ////ASSERT
            Assert.IsTrue(_notifiedOfDataGridOCChanged, "_notifiedOfDataGridOCChanged = " + _notifiedOfDataGridOCChanged);
            Assert.IsTrue(target.IsSearchEnabled, "IsSearchEnabled = " + target.IsSearchEnabled);
            Assert.IsTrue(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //begin = false
        }

        ///<summary>
        /// A test for DataServicesLoadComplete
        /// callback called when the clientdataservices callback has been called from QSP
        /// Simulate a forward path
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_DataServicesLoadComplete_ForwardPath_NoError_VerifyProperties()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //set up DataViewType
            var fakeDataView = A.Fake<IDIBDataViewType>();
            A.CallTo(() => fakeDataView.IsTreeView()).Returns(false);
            A.CallTo(() => fakeDataView.IsListView()).Returns(false);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());            
            target.Path.Forward = PathElementUtility.Instance().CreateTagPathElement("Tank1_Full", string.Empty);
            target.Path.Forward.DataItem = PathElementUtility.Instance().CreateDataItemBase("Tank1_Full");

            //register for events
            dibVmPO.Invoke("add_DataGridOCChanged", new PropertyChangedEventHandler(target_DataGridOCChanged));
            dibVmPO.Invoke("add_NavigateStateChanged", new PropertyChangedEventHandler(target_NavigateStateChanged));

            //ACT
            string error = string.Empty;
            dibVmPO.Invoke("DataServicesLoadComplete", error);

            //ASSERT
            Assert.IsTrue(_notifiedOfDataGridOCChanged, "_notifiedOfDataGridOCChanged = " + _notifiedOfDataGridOCChanged);
            Assert.AreEqual(gridOCChangedItem, "Tank1_Full");
            Assert.IsTrue(target.IsSearchEnabled, "IsSearchEnabled = " + target.IsSearchEnabled);
            Assert.IsTrue(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //begin = false

        }

        
        ///<summary>
        /// A test for DataServicesLoadComplete
        /// callback called when the clientdataservices callback has been called from QSP
        /// Simulate launching the DIB with _launchWithSearchSelectedItemPath set to the connectstring
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_DataServicesLoadComplete_launchWithSearchSelectedItemPath_NoError_VerifyProperties()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            DataItemBase selectedItem = PathElementUtility.Instance().CreateDataItemBase("BOOL_UDT_Array1");
            A.CallTo(() => fakeClientDataServices.GetDataItemByName(A<string>.Ignored, A<string>.Ignored)).Returns(selectedItem);

            //set up DataViewType
            var fakeDataView = A.Fake<IDIBDataViewType>();
            A.CallTo(() => fakeDataView.IsTreeView()).Returns(false);
            A.CallTo(() => fakeDataView.IsListView()).Returns(false);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
            dibVmPO.SetFieldOrProperty("_launchWithSearchSelectedItemPath", "::c1.BOOL_UDT_Array1");

            //register for events
            dibVmPO.Invoke("add_DataGridOCChanged", new PropertyChangedEventHandler(target_DataGridOCChanged));
            dibVmPO.Invoke("add_NavigateStateChanged", new PropertyChangedEventHandler(target_NavigateStateChanged));

            //ACT
            string error = string.Empty;
            dibVmPO.Invoke("DataServicesLoadComplete", error);

            //ASSERT
            Assert.IsTrue(_notifiedOfDataGridOCChanged, "_notifiedOfDataGridOCChanged = " + _notifiedOfDataGridOCChanged);
            Assert.AreEqual(gridOCChangedItem, "BOOL_UDT_Array1");
            Assert.IsTrue(target.IsSearchEnabled, "IsSearchEnabled = " + target.IsSearchEnabled);
            Assert.IsTrue(AsynOperationComplete, "AsynOperationComplete = " + AsynOperationComplete); //begin = false
        }

        
        ///<summary>
        /// A test for NotifySelectItemAfterLaunchWithSearch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_NotifySelectItemAfterLaunchWithSearch_VerifyEventCalled()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            dibVmPO.Invoke("add_SelectItemAfterLaunchWithSearch", new PropertyChangedEventHandler(target_SelectItemAfterLaunchWithSearch));

            //ACT
            dibVmPO.Invoke("NotifySelectItemAfterLaunchWithSearch", "::c1.BOOL_UDT_Array1");

            //ASSERT
            Assert.AreEqual(_selectedItemPath, "::c1.BOOL_UDT_Array1");

        }

        
        ///<summary>
        /// A test for getChildren
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_getChildren_Verify()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            List<DropArrowItem> fakeList = new List<DropArrowItem>();
            DropArrowItem x = new DropArrowItem
            {
                DisplayName = "myDropItem",
                IsContainer = false,
                HostCrumb = new TextCrumb(PathElementUtility.Instance().CreateDataItemPathElement("mytest", string.Empty, false)),
                IsBold = false
            };

            fakeList.Add(x);
            A.CallTo(() => fakeClientDataServices.GetChildrenOfCrumb(A<ACrumb>.Ignored, A<string>.Ignored)).Returns(fakeList);

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
             
            //set up the Path
            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
            target.Path.Add(PathElementUtility.Instance().CreateTagPathElement("BOOL_UDT_Array3", string.Empty));
            target.Path.Add(PathElementUtility.Instance().CreateTagPathElement("BOOL_UDT_Array3[0,0,1]", string.Empty));

            //create the homeCrumb to pass into the call
            ACrumb hostCrumb = new TextCrumb(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());           

            //ACT
            List<DropArrowItem> returnedList = target.getChildren("c1", hostCrumb);

            //ASSERT
            A.CallTo(()=>fakeClientDataServices.GetChildrenOfCrumb(A<ACrumb>.Ignored,A<string>.Ignored)).MustHaveHappened();
            Assert.AreEqual(returnedList, fakeList);

        }

        
        ///<summary>
        /// A test for UpdateFolderDataItems
        /// Create a scenario where Path.back == null  
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_UpdateFolderDataItems_NoCommonID_NoParent_VerifyNewCommonIDCreatedAndEmpty()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();                       

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            //Create a scenario where Path.back == null           
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());
           
            //create the dataItem to pass into the call                     
            DataItemBase dataItem = DIResource.DIB_TagsAndProps;

            //ACT            
            dibVmPO.Invoke("UpdateFolderDataItems", dataItem);

            //ASSERT
            Assert.AreEqual(string.Empty, dataItem.CommonID);

        }

        ///<summary>
        /// A test for UpdateFolderDataItems
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_UpdateFolderDataItems_PathBackExists_CommonIDExists_VerifyCommonIDSetToPathBackID()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());

            //create the dataItem to pass into the call                     
            DataItemBase dataItem = DIResource.DIB_TagsAndProps;
            dataItem.CommonID = PathElementUtility.getTest_TAGS_AND_PROPERTIES_COMMON_ID().ToString();
            //ACT            
            dibVmPO.Invoke("UpdateFolderDataItems", dataItem);

            //ASSERT
            string newValue = target.Path.Back.DataItem.CommonID;
            Assert.AreEqual(newValue, dataItem.CommonID);

        }
        
        ///<summary>
        /// A test for IsNavigateOnCurrentPath
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_IsNavigateOnCurrentPath_MatchingPaths_True()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());

            //ACT
            bool result = target.IsNavigateOnCurrentPath(target.Path);

            //ASSERT
            Assert.IsTrue(result,"Should be equal paths and are not.");
        }

        ///<summary>
        /// A test for IsNavigateOnCurrentPath
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_IsNavigateOnCurrentPath_NotMatchingPaths_False()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());

            //path to compare
            Path comparePath = new Path();
            comparePath.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateProgramPathElement("Program1"));

            //ACT
            bool result = target.IsNavigateOnCurrentPath(comparePath);

            //ASSERT
            Assert.IsFalse(result, "Should be different paths and are not.");
        }

        ///<summary>
        /// A test for ShouldSearchViaQuery
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ShouldSearchViaQuery_ControllerHomePath_True()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            //add controller as a homepathelement 
            DataItemBase controller = PathElementUtility.Instance().CreateDataItemBase("C1");
            controller.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();            
            dataItems.Add(controller);                         
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));                        

            //ACT
            bool result = (bool)dibVmPO.Invoke("ShouldSearchViaQuery");

            //ASSERT
            Assert.IsTrue(result, "ShouldSearchViaQuery = " + result);
        }

        ///<summary>
        /// A test for ShouldSearchViaQuery
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ShouldSearchViaQuery_HMIDeviceHomePath_True()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            //add hmiDevice as a homepathelement 
            DataItemBase hmiDevice = PathElementUtility.Instance().CreateDataItemBase("HMIDevice");
            hmiDevice.CommonResourceType = TypeIdentifiers.ResourceType_HMIDevice.ToString();  
            dataItems.Add(hmiDevice);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));

            //ACT
            bool result = (bool)dibVmPO.Invoke("ShouldSearchViaQuery");

            //ASSERT
            Assert.IsTrue(result, "ShouldSearchViaQuery = " + result);
        }

        ///<summary>
        /// A test for ShouldSearchViaQuery
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_ShouldSearchViaQuery_TagsAndProperties_False()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();
            //add controller as a homepathelement 
            DataItemBase controller = PathElementUtility.Instance().CreateDataItemBase("C1");
            controller.CommonResourceType = TypeIdentifiers.getResourceType_Controller().ToString();  
            dataItems.Add(controller);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            //active element is Tags and Props
            target.Path.Add(PathElementUtility.Instance().CreateTagsAndPropertiesPathElement());

            //ACT
            bool result = (bool)dibVmPO.Invoke("ShouldSearchViaQuery");

            //ASSERT
            Assert.IsFalse(result, "ShouldSearchViaQuery = " + result);
        }        

        ///<summary>
        /// A test for CleanupFailedSearch
        ///</summary>
        [TestMethod()]
        public void DataItemBrowserViewModel_CleanupFailedSearch()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up the Path parameter in the DIBVM used in the method under test
            List<DataItemBase> dataItems = new List<DataItemBase>();           
            dataItems.Add(null);
            target.Path.Add(PathElementFactory.Instance().CreateHomePathElement(dataItems));
            target.Path.Add(PathElementUtility.Instance().CreateHMIDevicePathElement("c1"));
            target.Path.Add(PathElementUtility.Instance().CreateProgramPathElement("Program1"));
            
            //set up properties
            target.IsQueryBasedSearchActive = true;

            //set up event handlers
            dibVmPO.Invoke("add_NavigateComplete", new PropertyChangedEventHandler(target_NavigateComplete));

            //ACT
            dibVmPO.Invoke("CleanupFailedSearch", true, false);

            //ASSERT
            Assert.AreEqual(string.Empty,_nameToSelect);
            PathElementObservableCollection collection = target.Path.Items;
            Assert.AreEqual(3, collection.Count);

            CheckInReturnedList(collection);
           
            //Cleanup
            dibVmPO.Invoke("remove_NavigateComplete", new PropertyChangedEventHandler(target_NavigateComplete));
        }

        /// <summary>
        /// Test Initialize as a DataType browser with a partial connectstring
        ///         
        /// For the Datatype Browser, if the datatype specified in the connect string is a UDT, but the user did not prepend the controller
        /// then use the last highlighted item as the connectstring
        /// 
        /// </summary>   
        [TestMethod]    
        public void DataItemBrowserViewModel_Initialize_DataTypeBrowser_ConnectString()
        {
            //ARRANGE 
            //set up SearchFilterControlViewModel parameters/methods
            var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

            //set up ClientDataServices
            var fakeClientDataServices = A.Fake<IClientDataServices>();
            //set it up so that whatever callback is passed in will be called
            A.CallTo(() => fakeClientDataServices.Initialize(A<DataItemBrowserContext>.Ignored, A<InitializationComplete>.Ignored)).Invokes(call =>
                                                                                                                                                {
                                                                                                                                                    var callback = ((InitializationComplete)call.Arguments[1]);
                                                                                                                                                    callback(new DataContext(), string.Empty);
                                                                                                                                                });

            //create the class under test 
            DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_DATATYPE, fakeSearchFilterControlViewModel, fakeClientDataServices);
            PrivateObject dibVmPO = new PrivateObject(target);

            //set up event handlers           
            dibVmPO.Invoke("add_NavigateStateChanged", new PropertyChangedEventHandler(target_NavigateStateChanged));            

            //initialize parameters and variables needed for test
            string connectstring = "DINT_ScalarArray";
            DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem = "::controller1.DINT_ScalarArray";
            DIBPersistedVariables.LastPackageContext = packageContext;
            DIBPersistedVariables.LastProjectContext = projectContext;
            DataItemBrowserContext context = DataItemBrowserContextUtility.SampleEmptyDataItemBrowserContext();

            //ACT
            target.Initialize(context, connectstring);

            //ASSERT
            Assert.IsFalse(target.IsSearchEnabled);
            Assert.IsFalse(target.IsTagBrowser());          
            Assert.IsTrue(_navigateStateChangedCalled);
            //check that the connect string was set to lasthighlighteditem
            ConnectStringProcessor _connectStringProcessor = dibVmPO.GetField("_connectStringProcessor") as ConnectStringProcessor;
            PrivateObject connectPO = new PrivateObject(_connectStringProcessor);
            Assert.AreEqual(DIBPersistedVariables.DataTypeBrowser_LastHighLightedItem, connectPO.GetFieldOrProperty("ConnectString"));
            
        }

          /// <summary>
        /// Test Initialize as a Tag browser with a DataContext FilterDefinition
        ///         
        /// Verify the SearchFilterControlViewModel.Initialize gets called
        /// </summary>   
        [TestMethod]
        public void DataItemBrowserViewModel_Initialize_TagBrowser_DataContextFilterDefinition()
          {
              //ARRANGE 
              //set up SearchFilterControlViewModel parameters/methods
              var fakeSearchFilterControlViewModel = A.Fake<ISearchFilterControlViewModel>();

              //set up the parameters for the initialize call
              DIBPersistedVariables.LastPackageContext = packageContext;
              DIBPersistedVariables.LastProjectContext = projectContext;
              DataItemBrowserContext context = DataItemBrowserContextUtility.SampleFilterDataItemBrowserContext();
              DataContext dataContext = new DataContext();
              ObservableCollection<FilterType> _filterTypes = new ObservableCollection<FilterType>();
              _filterTypes.Add(new FilterType(DIBConstants.Common.Name, true, false));
              _filterTypes.Add(new FilterType(DIBConstants.Common.DataType, false, true));  //launch filter must be set
              _filterTypes.Add(new FilterType(DIBConstants.Common.Description, true, false));
              SearchFilterDefinition filterDefinition = new SearchFilterDefinition(_filterTypes);
              dataContext.FilterDefinition = filterDefinition;
              if (!dataContext.FilterDefinition.AddFilter("dt:", "DINT", true, SearchFilterDefinition.StatementLogic.AND))
                  Assert.Fail("Filter could not be added... possibly NO Launch Filter Set!");
              dataContext.FilterDefinition.HasNonEmptySearchValue = true;

              //set up ClientDataServices with the exact DataItemBrowserContext
              var fakeClientDataServices = A.Fake<IClientDataServices>();
              //set it up so that whatever callback is passed in will be called with the DataContext data we specify
              A.CallTo(() => fakeClientDataServices.Initialize(A<DataItemBrowserContext>.That.Matches(s => s.Equals(context)), A<InitializationComplete>.Ignored)).Invokes(call =>
                                                                                                                                                  {
                                                                                                                                                      var callback = ((InitializationComplete)call.Arguments[1]);
                                                                                                                                                      callback(dataContext, string.Empty);
                                                                                                                                                  });

              A.CallTo(() => fakeClientDataServices.DrillIn(A<DataItemBase>.Ignored, A<DataLoadComplete>.Ignored)).Invokes(call =>
                                                                                                                              {
                                                                                                                                  var callback = ((DataLoadComplete)call.Arguments[1]);
                                                                                                                                  callback(string.Empty);
                                                                                                                              });

              //create the class under test 
              DataItemBrowserViewModel target = new DataItemBrowserViewModel(DIBClientManagerForViewe.Instance, DIResource.DI_COMMON_RESOURCETYPE_TAG, fakeSearchFilterControlViewModel, fakeClientDataServices);
              PrivateObject dibVmPO = new PrivateObject(target);
             

              //ACT
              target.Initialize(context, null);


              //ASSERT
               A.CallTo(()=>fakeSearchFilterControlViewModel.Initialize(A<SearchFilterDefinition>.That.Matches(s=>s.Equals(dataContext.FilterDefinition)))).MustHaveHappened();

          }

        #region private methods

        private void CheckInReturnedList(PathElementObservableCollection targetList)
        {
            bool found = false;
            //verify that the returned element is in the list
            foreach (var pathElementReturned in _pathList)
            {
                foreach (var targetElement in targetList)
                {
                    if (pathElementReturned.DisplayName == targetElement.DisplayName)
                    {
                        found = true;
                        break;
                    }
                }
            }

            Assert.IsTrue(found,"CleanupFailedSearch pathElement returned was not found in the list");
        }

        #endregion private methods
    }
}
