﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using TagFilterControl.Service;

namespace TagFilterControl.Common
{
    public interface IInvoker<T>
    {
        ICallback Callback(Action<T> callback);
    }

    public interface IFinally
    {
        void Execute();
    }

    public interface ICallback
    {
        IFinally Finally(Action finallyAction);
        void Execute();
    }

    public sealed class ServiceInvoker<T> where T : class
    {
        public static IInvoker<TResult> Invoke<TResult>(Func<T, TResult> func)
        {
            return new AsyncInvoker<T, TResult>(func);
        }

        public static T GetInterface()
        {
            return ServiceContainer<T>.ServiceContainerInstance[typeof(T)];
        }

        class AsyncInvoker<TInterface, TResult> : IInvoker<TResult>, IFinally, ICallback where TInterface : class
        {
            private Func<TInterface, TResult> func;
            private Action finallyAction;
            private Action<TResult> callback;

            public AsyncInvoker(Func<TInterface, TResult> func)
            {
                this.func = func;
            }

            public void Execute()
            {
                Action<IAsyncResult> resultHandler = (result) =>
                {
                    this.callback(this.func.EndInvoke(result));
                    this.finallyAction.Execute();
                };
                AsyncCallback asyncCallback = (result) =>
                {
                    UIDispatcher._Dispatcher.BeginInvoke(DispatcherPriority.ApplicationIdle, resultHandler, result);
                };
                func.BeginInvoke(GetInstance(), asyncCallback, null);
            }

            static Dictionary<Type, TInterface> serviceContainer = ServiceContainer<TInterface>.ServiceContainerInstance;

            private static TInterface GetInstance()
            {
                Type type = typeof(TInterface);
                if (serviceContainer.ContainsKey(type))
                {
                    return serviceContainer[type];
                }
                if (type == typeof(ITagService))
                {
                    serviceContainer.Add(typeof(ITagService), (TInterface)Activator.CreateInstance(typeof(TagService)));
                }
                if (serviceContainer.ContainsKey(type))
                {
                    return serviceContainer[type];
                }
                throw new Exception(string.Format("Not found {0}", type));
            }

            public IFinally Finally(Action finallyAction)
            {
                this.finallyAction = finallyAction;
                return this;
            }

            public ICallback Callback(Action<TResult> callback)
            {
                this.callback = callback;
                return this;
            }
        }

        static class ServiceContainer<TInterface>
        {
            static ServiceContainer()
            {
            }

            public static Dictionary<Type, TInterface> ServiceContainerInstance = new Dictionary<Type, TInterface> { };
        }
    }
}
