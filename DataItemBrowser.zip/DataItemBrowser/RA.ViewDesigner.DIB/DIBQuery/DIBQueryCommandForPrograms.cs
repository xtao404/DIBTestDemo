﻿/*************************************************************************************     
   Copyright © 2012 Rockwell Automation Technologies, Inc. All Rights Reserved.                                                                      
 *************************************************************************************                                                                  
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of RockwellAutomation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT                                                                 
 *************************************************************************************/

using RockwellAutomation.Client.Services.Query;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.Client.Services.Query.Common;

namespace RockwellAutomation.UI.DIBQuery
{
    class DIBQueryCommandForPrograms : DIBQueryCommandForViewe
    {

        #region "Creation/Init"

        public DIBQueryCommandForPrograms(QueryRequest.CreateBuilder queryRequestBuilder)
            : base(queryRequestBuilder)
        {
            CacheQueryResults = true;
        }

        #endregion

        #region "Base Overides"

        public override PredefinedQueryType QueryType()
        {
            return PredefinedQueryType.Programs;
        }

        public override QueryConditionConfig GenerateQueryCondition(IClientDataServices cds)
        {
            // check to see if we are processing includes, currently this only applies to Programs
            if (cds.DataContext.HasInclude() && cds.DataContext.IncludePath.DeviceDataItem != null)
            {
                //Get the UUID of the device from the include path - warning you cannot use the parent item, because 
                //the parent item is the Programs folder dataitem and the UUID of it is changed everytime you drill 
                //into a program folder.  So the include parent and the parent /would always be equal 
                UUID includeDeviceId = ResourceBase.GuidStringToId(cds.DataContext.IncludePath.DeviceDataItem.CommonID);

                //is the device from the include path and the parent equal
                if (ResourceBase.IsEqual(includeDeviceId, this.ParentResourceTypeId()))
                {
                    //create an include condition to filter all but this included program
                    string includeName = cds.DataContext.IncludePath.DataItem.CommonName;
                    //during initialization when we are building the include path, the _dataContext.IncludePath.DataItem will
                    //be the "Programs" item, since we have not found the program item yet, so do not apply the filter until we 
                    //have processed the full include path.
                    if (string.Compare(includeName, DIResource.DI_COMMON_RESOURCETYPE_PROGRAMS) != 0)
                    {
                        QueryConditionConfig queryCondition = new QueryConditionConfig.CreateBuilder().AddConditionItem(
                                                new QueryConditionItem.CreateBuilder().SetIdentifier(DIResource.DI_COMMON_IDENTIFIER_DISPLAY_NAME)
                                                                                 .SetIsExactMatch(true)
                                                                                 .SetValue(includeName)
                                                                                 .Build())
                                                                        .Build();
                        return queryCondition;
                    }
                }

            }
            return base.GenerateQueryCondition(cds);
        }

        #endregion
    }
}
