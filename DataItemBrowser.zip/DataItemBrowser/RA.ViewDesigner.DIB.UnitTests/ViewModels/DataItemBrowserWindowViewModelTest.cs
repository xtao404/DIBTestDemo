﻿/*************************************************************************************
                                                                     
   DataItemBrowserWindowViewModelTest Class
   Copyright © 2009-2015 Rockwell Automation Technologies, Inc. All Rights Reserved.    
                                                                     
 *************************************************************************************
                                                                     
   IMPORTANT NOTICE:                                                                     
   This source code contains valuable and proprietary trade secrets of Rockwell
   Automation Technologies Inc. and its use is strictly subject to the terms and 
   conditions of the ROCKWELL AUTOMATION TECHNOLOGIES SOFTWARE LICENSE AGREEMENT
                                                                      
 *************************************************************************************/

using RockwellAutomation.UI.Windows;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Windows.Forms;
using System.Windows;
using AvalonUnitTesting;

namespace DataItemBrowserUT
{

    /// <summary>
    ///This is a test class for DataItemBrowserWindowViewModelTest and is intended
    ///to contain all DataItemBrowserWindowViewModelTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DataItemBrowserWindowViewModelTest
    {

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            // Unit Tests run in a MTA, but Windows run in an STA, so run the delegate in an STA
            AvalonTestRunner.RunInSTA(
                delegate
                {
                    // Create a FrameworkElement so SetDPI can get the system's DPI
                    // The window must be visible.
                    Window w = new Window();
                    w.Show();
                    DataItemBrowserWindowViewModel.SetDPI(w);
                    w.Close();
                });
        }

        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        
        //Use TestInitialize to run code before running each test
        [TestInitialize()]
        public void MyTestInitialize()
        {
            if (DataItemBrowserWindowViewModel.DPI != 96)
            {
                Assert.Inconclusive("This test only works for DPI == 96. Other DPIs will not be tested as changing the system's DPI requires a manual change (Control Panel>Display) and then logging off and logging back on.");
            }
        }
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        /// <summary>
        ///A test for ConvertScreenToDIPs
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ConvertScreenToDIPsTest()
        {
            // Get Primary Screen
            Screen primaryScreen = Screen.PrimaryScreen;

            Rect expected = new Rect(primaryScreen.WorkingArea.X, primaryScreen.WorkingArea.Y, primaryScreen.WorkingArea.Width, primaryScreen.WorkingArea.Height);
            Rect actual;
            actual = (Rect)new PrivateType(typeof(DataItemBrowserWindowViewModel)).InvokeStatic("ConvertScreenToDIPs", primaryScreen);
            Assert.AreEqual(expected, actual, "Expected rectangle is not equivalent to actual rectangle");
        }

        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in upper left corner of window when browser is full screen.
        /// Browser will shrink to fit the area below the launching element, and will be flush to the left.
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_UpperLeft_FullScreen()
        {
            const int n = 100;
            Point targetPoint = new Point(0,0);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(n, n);

            // browserSize = the entire screen
            Size browserSize = new Size(WorkingArea.Width, WorkingArea.Height);
            Size browserSizeExpected = new Size(WorkingArea.Width, WorkingArea.Height - n);
            Point topLeftExpected = new Point(0, n);
            Point topLeftActual;
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");

            // browserSize width > entire screen's width: Browser's width will = screen's width
            browserSize = new Size(2 * WorkingArea.Width, WorkingArea.Height);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }

        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in upper left corner of window when browser is half screen.
        /// Browser fits the area below the launching element, no size change, flush with left hand-side of screen
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_UpperLeft_HalfScreen()
        {
            const int n = 100;
            Point targetPoint = new Point(0, 0);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(n, n);

            // browserSize - 1/2 actual window height
            Point topLeftExpected = new Point(0, n);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width, WorkingArea.Height / 2);
            Size browserSizeExpected = new Size(WorkingArea.Width, WorkingArea.Height / 2);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }

        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in upper left corner of window when browser is less than half screen wide and height.
        /// Browser fits the area below the launching element, no size change
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_UpperLeft_LessThanHalfScreenInWidthAndHeight()
        {
            const int n = 100;
            Point targetPoint = new Point(0, 0);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(n, n);

            // browserSize - Less than half screen in width and height
            Point topLeftExpected = new Point(0, n);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width / 2 - n, WorkingArea.Height / 2 - n);
            Size browserSizeExpected = new Size(WorkingArea.Width / 2 - n, WorkingArea.Height / 2 - n);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }


        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in upper right corner of window when browser is full screen.
        /// Browser will shrink to fit the area below the launching element
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_UpperRight_FullScreen()
        {
            const int n = 100;
            Screen primaryScreen = Screen.PrimaryScreen;
            int x = primaryScreen.WorkingArea.Right - n;
            int y = primaryScreen.WorkingArea.Top;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize = the entire screen
            Size browserSize = new Size(WorkingArea.Width, WorkingArea.Height);
            Size browserSizeExpected = new Size(WorkingArea.Width, WorkingArea.Height - n);
            Point topLeftExpected = new Point(WorkingArea.Left, WorkingArea.Top + n);
            Point topLeftActual;
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }

        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in upper left corner of window when browser is half screen.
        /// Browser fits the area below the launching element, no size change, flush with left hand-side of screen
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_UpperRight_HalfScreen()
        {
            const int n = 100;
            Screen primaryScreen = Screen.PrimaryScreen;
            int x = primaryScreen.WorkingArea.Right - n;
            int y = primaryScreen.WorkingArea.Top;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize - 1/2 actual window height
            Point topLeftExpected = new Point(WorkingArea.Left, WorkingArea.Top + n);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width, WorkingArea.Height / 2);
            Size browserSizeExpected = new Size(WorkingArea.Width, WorkingArea.Height / 2);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }

        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in upper left corner of window when browser is less than half screen wide.
        /// Browser fits the area below the launching element, no size change
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_UpperRight_LessThanHalfScreenInWidthAndHeight()
        {
            const int n = 100;
            Screen primaryScreen = Screen.PrimaryScreen;
            int x = primaryScreen.WorkingArea.Right - n;
            int y = primaryScreen.WorkingArea.Top;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize - Less than half screen in width and height
            Point topLeftExpected = new Point(WorkingArea.Right - WorkingArea.Width / 2 + n, WorkingArea.Top + n);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width / 2 - n, WorkingArea.Height / 2 - n);
            Size browserSizeExpected = new Size(WorkingArea.Width / 2 - n, WorkingArea.Height / 2 - n);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }


        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in lower left corner of window when browser is full screen.
        /// Browser will shrink to fit the area below the launching element
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_LowerLeft_FullScreen()
        {
            // Get Primary Screen
            Screen primaryScreen = Screen.PrimaryScreen;

            const int n = 100;
            int x = primaryScreen.WorkingArea.Left;
            int y = primaryScreen.WorkingArea.Bottom - n;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize - full screen
            Point topLeftExpected = new Point(primaryScreen.WorkingArea.Left, primaryScreen.WorkingArea.Top);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width, WorkingArea.Height);
            Size browserSizeExpected = new Size(WorkingArea.Width, WorkingArea.Height - n);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }


        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in lower left corner of window when browser is half screen.
        /// Browser fits the area above the launching element, no size change
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_LowerLeft_HalfScreen()
        {
            // Get Primary Screen
            Screen primaryScreen = Screen.PrimaryScreen;

            const int n = 100;
            int x = primaryScreen.WorkingArea.Left;
            int y = primaryScreen.WorkingArea.Bottom - n;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize - 1/2 actual window height
            Point topLeftExpected = new Point(x, WorkingArea.Height / 2 - n);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width, WorkingArea.Height / 2);
            Size browserSizeExpected = new Size(WorkingArea.Width, WorkingArea.Height / 2);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }

        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in upper left corner of window when browser is less than half screen wide.
        /// Browser fits the area below the launching element, no size change
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_LowerLeft_LessThanHalfScreenInWidthAndHeight()
        {
            const int n = 100;
            Screen primaryScreen = Screen.PrimaryScreen;
            int x = primaryScreen.WorkingArea.Left;
            int y = primaryScreen.WorkingArea.Bottom - n;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize - Less than half screen in width and height
            Point topLeftExpected = new Point(x, y - WorkingArea.Height / 2 + n);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width / 2 - n, WorkingArea.Height / 2 - n);
            Size browserSizeExpected = new Size(WorkingArea.Width / 2 - n, WorkingArea.Height / 2 - n);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }

        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in lower right corner of window when browser is full screen.
        /// Browser will shrink to fit the area above the launching element
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_LowerRight_FullScreen()
        {
            // Get Primary Screen
            Screen primaryScreen = Screen.PrimaryScreen;

            const int n = 100;
            int x = primaryScreen.WorkingArea.Right - n;
            int y = primaryScreen.WorkingArea.Bottom - n;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize - full screen
            Point topLeftExpected = new Point(primaryScreen.WorkingArea.Left, primaryScreen.WorkingArea.Top);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width, WorkingArea.Height);
            Size browserSizeExpected = new Size(WorkingArea.Width, WorkingArea.Height - n);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }


        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in lower left corner of window when browser is half screen.
        /// Browser fits the area above the launching element, no size change
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_LowerRight_HalfScreen()
        {
            // Get Primary Screen
            Screen primaryScreen = Screen.PrimaryScreen;

            const int n = 100;
            int x = primaryScreen.WorkingArea.Right - n;
            int y = primaryScreen.WorkingArea.Bottom - n;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize - 1/2 actual window height
            Point topLeftExpected = new Point(WorkingArea.Left, WorkingArea.Height / 2 - n);
            Point topLeftActual;
            Size browserSize = new Size(WorkingArea.Width, WorkingArea.Height / 2);
            Size browserSizeExpected = new Size(WorkingArea.Width, WorkingArea.Height / 2);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }

        /// <summary>
        /// A test for CalculateBrowserLocationAndSize
        /// Launching element in upper left corner of window when browser is less than half screen wide.
        /// Browser fits the area above the launching element, no size change
        ///</summary>
        [TestMethod()]
        public void CalculateBrowserLocationAndSizeTest_LowerRight_LessThanHalfScreenInWidthAndHeight()
        {
            const int n = 100;
            Screen primaryScreen = Screen.PrimaryScreen;
            int x = primaryScreen.WorkingArea.Right - n;
            int y = primaryScreen.WorkingArea.Bottom - n;
            Point targetPoint = new Point(x, y);
            Size editorOffset = new Size(n, n);
            Rect WorkingArea = DataItemBrowserWindowViewModel.WPFWorkingArea(x, y);

            // browserSize - Less than half screen in width and height
            double width = WorkingArea.Width / 2 - n;
            double height = WorkingArea.Height / 2 - n;
            Point topLeftExpected = new Point(WorkingArea.Right - width, y - height);
            Point topLeftActual;
            Size browserSize = new Size(width, height);
            Size browserSizeExpected = new Size(width, height);
            topLeftActual = DataItemBrowserWindowViewModel.CalculateBrowserLocationAndSize(targetPoint, editorOffset, ref browserSize);
            Assert.AreEqual(browserSizeExpected, browserSize, "Browser is not the correct size");
            Assert.AreEqual(topLeftExpected, topLeftActual, "Browser's Top Left point is invalid: (" + topLeftActual.X + ", " + topLeftActual.Y + ")");
        }

        /// <summary>
        /// A test for ConvertDIPsToPixels
        /// If DPI == 96, a DIP is equal to a screen pixel
        ///</summary>
        [TestMethod()]
        public void ConvertDIPsToPixelsTest()
        {
            int expected = 960;
            int actual = 0;
            actual = DataItemBrowserWindowViewModel.ConvertDIPsToPixels(expected);
            Assert.IsTrue(expected == actual, "ConvertDIPsToPixels conversion failed: actual = " + actual + " expected = " + expected);
       }


        /// <summary>
        /// A test for ConvertPixelsToDIPs
        /// If DPI == 96, a DIP is equal to a screen pixel
        ///</summary>
        [TestMethod()]
        public void ConvertPixelsToDIPsTest()
        {
            int expected = 960;
            int actual = 0;
            actual = DataItemBrowserWindowViewModel.ConvertPixelsToDIPs(expected);
            Assert.IsTrue(expected == actual, "ConvertPixelsToDIPs conversion failed: actual = " + actual + " expected = " + expected);
        }
    }
}
