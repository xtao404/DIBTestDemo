﻿using RockwellAutomation.UI.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel;
using RockwellAutomation.UI;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for ACrumbTest and is intended
    ///to contain all ACrumbTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ACrumbTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //

        /// <summary>
        /// Use TestInitialize to run code before running each test
        /// </summary>
        [TestInitialize()]
        public void MyTestInitialize()
        {
            DIBClientManagerForViewe.InitializeVieweSpecificClasses();
        }

        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for SupportsDropArrow
        ///</summary>
        [TestMethod()]
        public void ACrumb_SupportsDropArrowTest()
        {
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("dropArrow");
            bool expected = true;

            ACrumb target = new TextCrumb(pe);
           
            bool actual = target.SupportsDropArrow;
            Assert.AreEqual(expected, actual);
        }

           /// <summary>
        ///A test for IsLast
        ///</summary>
        [TestMethod()]
        public void ACrumb_IsLastTest_True()
        {
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("lastTest");

            ACrumb target = new TextCrumb(pe); 
            bool expected = true; 

            target.IsLast = expected;
            bool actual = target.IsLast;
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        ///A test for IsLast
        ///</summary>
        [TestMethod()]
        public void ACrumb_IsLastTest_False()
        {
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("isLast");

            ACrumb target = new TextCrumb(pe);
            bool expected = false;

            target.IsLast = expected;
            bool actual = target.IsLast;
            Assert.AreEqual(expected, actual);
        }

  

        /// <summary>
        ///A test for NotifyPropertyChanged
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void ACrumb_NotifyPropertyChangedTest()
        {
            IPathElement pe = PathElementUtility.Instance().CreateControllerPathElement("notifyProp");

            ACrumb target = new TextCrumb(pe);
            target.PropertyChanged += myLocalPropertyChanged;
            target.IsLast = true;

            string propertyName = "IsLast";
            Assert.AreEqual(propertyName, _propertyChangedName);
        }

        private string _propertyChangedName = "";
        public void myLocalPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            _propertyChangedName = e.PropertyName;
        }
    }
}
