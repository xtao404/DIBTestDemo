
#region references

using System.Windows.Input;
using System.ComponentModel;
using System;
using RockwellAutomation.UI.CommonControls;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI.Models;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Windows;


#endregion

namespace RockwellAutomation.UI.ViewModels
{
    public class DIBWebViewModelForVieweWebBrowsing : DIBWebViewModel
    {
        #region "Constructor"

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="dibVM">DataItemBrowser View Model</param>
        public DIBWebViewModelForVieweWebBrowsing(IDataItemBrowserViewModel dibVM)
            : base(dibVM)
        {
        }

        #endregion

        #region Event Handlers

        override public bool AllowDrillInTo(System.Windows.Navigation.NavigatingCancelEventArgs e)
        {
            if (e.Uri.AbsolutePath.ToString().EndsWith("Wiki/Home.aspx"))
            {
                MessageBox.Show("This demo does not allow drilling into WIKI.....just because", "Not allowed to drill into CT WIKI");
                return false;
            }
            return true;
        }

        #endregion Event Handlers

        #region Breadcrumb related

        override public string BreadCrumbDisplayStringFor(Uri uri)
        {
            //Parse the query part of the uri.
            NameValueCollection query = HttpUtility.ParseQueryString(uri.Query);

            return this.BreadCrumbDisplayStringForCalorieKing(uri);
        }

        private string BreadCrumbDisplayStringForCalorieKing(Uri uri)
        {
            // By default, use the last path item. 
            // Ex. if the uri is 
            //          http:\\www.something.com\first\second\default.html
            //     then use "default" as the display string in the breadcrumbs 
            string[] drillInSubStrings = uri.AbsoluteUri.Split('/');
            int index = drillInSubStrings.Length - 1;
            if (index < 1) index = 0;
            if (index != 0 && drillInSubStrings[index] == String.Empty) index = index - 1;

            string response = drillInSubStrings[index].Replace("_Y2lkPTEwJnNpZD0xMyZyaWQ9MTAyOQ.html", String.Empty);
            return response;
        }


        #endregion

    }
}
