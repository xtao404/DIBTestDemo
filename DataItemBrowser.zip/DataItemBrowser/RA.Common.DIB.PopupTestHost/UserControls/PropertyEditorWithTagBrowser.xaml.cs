using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using RockwellAutomation.UI.Windows;
using System.Globalization;
using RockwellAutomation.UI.Models;
using RockwellAutomation.UI;
using RockwellAutomation.Logging;
using RockwellAutomation.UI.ViewModels;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.DesignTimeClient.PopUpGenericTestHost
{
    /// <summary>
    /// Interaction logic for PropertyEditorWithTagBrowser.xaml
    /// </summary>
    public partial class PropertyEditorWithTagBrowser : UserControl
    {

        #region properties/variables

        /// <summary>
        /// property for tag browser window 
        /// </summary>
        private DIBWindow _browser;

        public static readonly DependencyProperty DIBClientManagerNameProperty =
            DependencyProperty.Register("DIBClientManagerName", typeof(string), typeof(PropertyEditorWithTagBrowser), new UIPropertyMetadata(String.Empty));
        public string DIBClientManagerName
        {
            get { return (string)GetValue(DIBClientManagerNameProperty); }
            set { SetValue(DIBClientManagerNameProperty, value); }
        }

        /// <summary>
        /// TagName dependency property - path to tag name
        /// </summary>
        public readonly static DependencyProperty TagNameProperty = 
            DependencyProperty.Register("TagName", typeof(string), typeof(PropertyEditorWithTagBrowser), new PropertyMetadata(""));
        /// <summary>
        /// Tag Name property
        /// </summary>
        public string TagName
        {
            get {return ((string)(base.GetValue(PropertyEditorWithTagBrowser.TagNameProperty))); }
            set {base.SetValue(PropertyEditorWithTagBrowser.TagNameProperty, value);}
        }


        /// <summary>
        /// HighlightedItem dependency property
        /// </summary>
        public readonly static DependencyProperty HighlightedItemProperty = 
            DependencyProperty.Register("HighlightedItem", typeof(string), typeof(PropertyEditorWithTagBrowser), new PropertyMetadata(""));
        /// <summary>
        /// HighlightedItem property
        /// </summary>
        public string HighlightedItem
        {
            get { return ((string)(base.GetValue(PropertyEditorWithTagBrowser.HighlightedItemProperty)));}
            set { base.SetValue(PropertyEditorWithTagBrowser.HighlightedItemProperty, value);}
        }

        /// <summary>
        /// PresistWindow dependency property - specifies either which type of data item browser should be launched
        /// </summary>
        public readonly static DependencyProperty PersistWindowProperty = 
            DependencyProperty.Register("PersistWindow", typeof(bool), typeof(PropertyEditorWithTagBrowser),new PropertyMetadata(false));
        /// <summary>
        /// PersistWindow property 
        /// </summary>
        public bool PersistWindow
        {
            get {return ((bool)(base.GetValue(PropertyEditorWithTagBrowser.PersistWindowProperty)));}
            set { base.SetValue(PropertyEditorWithTagBrowser.PersistWindowProperty, value);}
        }


        // Using a DependencyProperty as the backing store for DesiredFontSize.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DesiredFontSizeProperty =
            DependencyProperty.Register("DesiredFontSize", typeof(double), typeof(PropertyEditorWithTagBrowser), new UIPropertyMetadata(0.0));
        public double DesiredFontSize
        {
            get { return (double)GetValue(DesiredFontSizeProperty); }
            set { SetValue(DesiredFontSizeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DesiredFontFamily.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DesiredFontFamilyProperty =
            DependencyProperty.Register("DesiredFontFamily", typeof(FontFamily), typeof(PropertyEditorWithTagBrowser), new UIPropertyMetadata(null));
        public FontFamily DesiredFontFamily
        {
            get { return (FontFamily)GetValue(DesiredFontFamilyProperty); }
            set { SetValue(DesiredFontFamilyProperty, value); }
        }
   

        #endregion Properties

        #region Constructor
        /// <summary>
        /// constructor
        /// </summary>
        public PropertyEditorWithTagBrowser()
        {
            InitializeComponent();
            this.DataContext = this;
        }

        #endregion Constructor

        #region Events
   
        /// <summary>
        /// Event routing triggered when the user single-clicks (selects) an item
        /// </summary>
        public static readonly RoutedEvent HighlightedItemChangedEvent =
            EventManager.RegisterRoutedEvent("HighlightedItemChanged", RoutingStrategy.Bubble,
            typeof(RoutedEventHandler), typeof(PropertyEditorWithTagBrowser));
        /// <summary>
        /// Provide CLR accessors for the UserSetHighlightedItemChanged event
        /// </summary>
        public event RoutedEventHandler HighlightedItemChanged
        {
            add { AddHandler(HighlightedItemChangedEvent, value); }
            remove { RemoveHandler(HighlightedItemChangedEvent, value); }
        }
        /// <summary>
        /// Raises the UserHighlightedItemChanged event
        /// </summary>
        private void RaiseHighlightedItemChangedEvent()
        {
            RaiseEvent(new RoutedEventArgs(HighlightedItemChangedEvent));
        }
        /// <summary>
        /// Event Handler which responds to the browser's change in a HighLightedIem
        /// </summary>
        /// <param name="sender">Browser</param>
        /// <param name="e">Not used</param>
        void _browser_HighlightedItemChangedEventHandler(object sender, RoutedEventArgs e)
        {
            DIBWindow browser = (DIBWindow)sender;
            this.HighlightedItem = string.Format(CultureInfo.InvariantCulture, "{0}", browser.HighlightedItem);
            RaiseHighlightedItemChangedEvent();
        }

        /// <summary>
        /// Occurs when the show tag browser button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnClickShowTagBrowser(object sender, RoutedEventArgs e)
        {
            Binding fontSizeBinding = new Binding("DesiredFontSize");
            Binding fontFamilyBinding = new Binding("DesiredFontFamily");

            fontSizeBinding.Source = this;
            fontFamilyBinding.Source = this;

            // Set the DIB Client Manager
            RockwellAutomation.UI.WindowsControl.DIBClient.DIBClientManager viewManager;
            viewManager = RockwellAutomation.DesignTimeClient.PopUpGenericTestHost.Window1.GetDIBClientManagerFor(this.DIBClientManagerName);
            viewManager.InitialLaunchString = this.TagName;

            _browser = new DIBWindow(PropertyText, viewManager) { PersistWindow = this.PersistWindow };

            // set the binding for the Font size and family
            _browser.SetBinding(DIBWindow.FontSizeProperty, fontSizeBinding);
            _browser.SetBinding(DIBWindow.FontFamilyProperty, fontFamilyBinding);

            _browser.ItemSelectedEventHandler += new RoutedEventHandler(BrowserItemSelected);
            _browser.HighlightedItemChangedEventHandler += new RoutedEventHandler(_browser_HighlightedItemChangedEventHandler);
            _browser.HighlightedItem = this.HighlightedItem;        
           
            _browser.Initialize(this.TagName);
            if (this.PersistWindow)
                _browser.ShowDialog();
            else
                _browser.Show();
        }
        
        /// <summary>
        ///Item is selected in the data item browser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BrowserItemSelected(object sender, RoutedEventArgs e)
        {
            DIBWindow browser = (DIBWindow)sender;
            this.TagName = string.Format(CultureInfo.InvariantCulture, "{0}", browser.SelectedItem);
        }       
        #endregion Events

        //Clears last highlighted info
        public void ClearLastHighlightedItemInfo()
        {
            if (_browser != null)
            {
                _browser.ClearLastHighlightedItemInfo();
                this.HighlightedItem = "";
            }
        }

    }
}
