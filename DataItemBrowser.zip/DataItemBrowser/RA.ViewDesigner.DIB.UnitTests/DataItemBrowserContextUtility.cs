﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.UI;
using RockwellAutomation.UI.Models;

namespace DataItemBrowserUT
{
    class DataItemBrowserContextUtility
    {
        #region DataItemBrowserContext
        
        public static DataItemBrowserContext SampleEmptyDataItemBrowserContext()
        {
            DataItemBrowserContext context = new DataItemBrowserContext.CreateBuilder().Root(string.Empty, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                     .ExcludeAllChildrenFromRoot()
                                                                                     .Include(string.Empty)
                                                                                     .Build();

            return context;
        }

        public static DataItemBrowserContext SampleIncludePathDataItemBrowserContext()
        {
            DataItemBrowserContext context = new DataItemBrowserContext.CreateBuilder().Root("::c1", DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                     .ExcludeAllChildrenFromRoot()
                                                                                     .Include("::c1\\Program_1")
                                                                                     .Build();

            return context;
        }

        public static DataItemBrowserContext SampleFilterDataItemBrowserContext()
        {
            DataItemBrowserContext dataContext = new DataItemBrowserContext.CreateBuilder().Root("::c1", DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                            .AddFilter("dt:", "DINT", true)
                                                                                            .Build();
            return dataContext;

        }

        public static DataItemBrowserContext SampleExcludeHMIDeviceDataItemBrowserContext()
        {
            DataItemBrowserContext dataContext = new DataItemBrowserContext.CreateBuilder().Root(string.Empty, DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                                                                                            .ExcludeAllOfType(DataItemBrowserContext.ExcludeAllOfTypeEnum.HMIDevice)
                                                                                            .Build();
            return dataContext;

        }

        #endregion DataItemBrowserContext

        #region DataContext

        public static DataContext SampleIncludePathDataContext()
        {
            DataContext dataContext = new DataContext();
            List<DataItemBase> dataItems = new List<DataItemBase>();
            DataItemBase controller = PathElementUtility.Instance().CreateDataItemBase("c1", TypeIdentifiers.getResourceType_Controller());            
            dataItems.Add(controller);
            DataItemBase programs = PathElementUtility.Instance().CreateDataItemBase("Programs", TypeIdentifiers.ResourceType_Programs);
            dataItems.Add(programs);
            DataItemBase program = PathElementUtility.Instance().CreateDataItemBase("Program_1", TypeIdentifiers.ResourceType_Program);            
            dataItems.Add(program);
            
            dataContext.IncludePath = new ContextPath(dataItems);

            dataContext.ExcludeAllChildrenFromRoot = true;

            return dataContext;
        }

        #endregion DataContext

    }
}
