using System;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using RockwellAutomation.UI;
using PopupTestHost;
using RockwellAutomation.UI.Models;
using System.Windows.Media.Imaging;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using RockwellAutomation.Message.PackageManager;
using RockwellAutomation.ServiceFramework.DataTypes;
using RockwellAutomation.UI.DIBQuery;
using System.Text;
using RockwellAutomation.UI.WindowsControl.DIBClient;

namespace RockwellAutomation.DesignTimeClient.PopUpTestHost
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window, INotifyPropertyChanged
    {
        const string _NOT_AVAILABLE_LITERAL = "<Not available>";
        const string _WELL_KNOWN_DEFAULT_CONTROLLERS_FILE = @"MyDefaultDevices.txt";
        const string _WELL_KNOWN_DEFAULT_PACKAGEPATH_FILE = @"MyDefaultPackageDirs.txt";
        const string _SKIP_PACKAGER_ERROR_COMMANDLINE_PARAM = "/hidepackagererror";
        const string _ROCWKELL_DATA_DIRECTORY_LITERAL = "ROCKWELL_DATA_DIRECTORY";
        const string _DIB_TEST_PROJECTS = @"dibtestprojects";
		const string _NEW_DB_TEXT = "New..."; //Keep this in sync with the data trigger in XAML
        const string _INVALID_DB_TEXT = "Invalid";
        public string _dirExecutable;

        public Window1()
        {
            InitializeComponent();
            this.DataContext = this;
            _dirExecutable = Directory.GetCurrentDirectory();
            Assembly assem = Assembly.GetEntryAssembly();
            AssemblyName assemName = assem.GetName();
            TestHostVersionLabel.Text += " " + assemName.Version.ToString();

            #if DEBUG
            PersistWindow.IsChecked = true;
            #endif

			txRoot.PreviewKeyDown    += new KeyEventHandler((object sender, KeyEventArgs e) => { HandleAutoCompleteTextBox(sender as TextBox, e); });
			txExclude.PreviewKeyDown += new KeyEventHandler((object sender, KeyEventArgs e) => { HandleAutoCompleteTextBox(sender as TextBox, e); });
			txInclude.PreviewKeyDown += new KeyEventHandler((object sender, KeyEventArgs e) => { HandleAutoCompleteTextBox(sender as TextBox, e); });

            //Make sure @DataLogs is always the correct case (this assists test given that we want to stay case sensitive from an API perspective
            // given this is a predefined folder name
            txRoot.LostFocus += new RoutedEventHandler((object sender, RoutedEventArgs e) =>
            {
                TextBox rootTextBox = sender as TextBox;
                string ProperDataLogsCase = "@DataLogs";
                int dlIndex = rootTextBox.Text.IndexOf(ProperDataLogsCase, StringComparison.CurrentCultureIgnoreCase);
                if (dlIndex >= 0)
                {
                    string correctCaseText = rootTextBox.Text.ToLower().Replace(ProperDataLogsCase.ToLower(), "").Insert(dlIndex, ProperDataLogsCase);
                    if (rootTextBox.Text != correctCaseText)
                        rootTextBox.Text = correctCaseText;
                }
            });
        }

        private string _userSetHighLightedItemResourceID = null;
        public string UserSetHighLightedItemResourceID
        {
            get { return _userSetHighLightedItemResourceID; }
            set
            {
                if (_userSetHighLightedItemResourceID == value)
                    return;

                _userSetHighLightedItemResourceID = value;
                NotifyPropertyChanged("UserSetHighLightedItemResourceID");
            }
        }

        private string _userSetHighLighted = string.Empty;
        public string UserSetHighlightedItem
        {
            get { return _userSetHighLighted; }
            set
            {
                if (_userSetHighLighted == value)
                    return;

                _userSetHighLighted = value;
                NotifyPropertyChanged("UserSetHighLightedItem");
            }
        }

        private string _highLightedItem = string.Empty;
        public string HighlightedItem
        {
            get { return _highLightedItem; }
            set
            {
                if (_highLightedItem == value)
                    return;

                _highLightedItem = value;
                NotifyPropertyChanged("HighLightedItem");
            }
        }

        /// <summary>
        /// What personality should the DIB take on? - Tag or Data Type
        /// </summary>
        private string _browserType = "";
        public string BrowserType
        {
            get { return _browserType; }
            set
            {
                if (_browserType == value)
                    return;

                _browserType = value;
                NotifyPropertyChanged("BrowserType");
            }
        }
        private bool _validationError = false;

        /// <summary>
        /// window loaded 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            this.dataProvider.Text = _NOT_AVAILABLE_LITERAL;

            // The following order is important as each assignment causes the BrowserTypeAndHighlightedConverter to be called
            BrowserTypeAndHighlightedConverter.Clear();
            this.BrowserType = "";
            this.txLastHighLightedItem.Text = _NOT_AVAILABLE_LITERAL;
            this.txUserSetHighlightedItem.Text = _NOT_AVAILABLE_LITERAL;            
            this.txUserSetHighlightedItemResourceID.Text = _NOT_AVAILABLE_LITERAL;
            this.txReadTagID.Text = _NOT_AVAILABLE_LITERAL;
            this.txWriteTagID.Text = _NOT_AVAILABLE_LITERAL;
            this.txDataType1ID.Text = _NOT_AVAILABLE_LITERAL;
            this.txDataType2ID.Text = _NOT_AVAILABLE_LITERAL;

            // Establish event Handlers
            PropertyEditWithDataType_1.HighlightedItemChanged += new RoutedEventHandler(HighlightedItemChanged);
            PropertyEditWithDataType_2.HighlightedItemChanged += new RoutedEventHandler(HighlightedItemChanged);
            PropertyEditWithTB1.HighlightedItemChanged += new RoutedEventHandler(HighlightedItemChanged);
            PropertyEditWithTB2.HighlightedItemChanged += new RoutedEventHandler(HighlightedItemChanged);
            PropertyEditWithDataType_1.UserSetHighlightedItemChanged += new RoutedEventHandler(UserSetHighlightedItemChanged);
            PropertyEditWithDataType_2.UserSetHighlightedItemChanged += new RoutedEventHandler(UserSetHighlightedItemChanged);
            PropertyEditWithTB1.UserSetHighlightedItemChanged += new RoutedEventHandler(UserSetHighlightedItemChanged);
            PropertyEditWithTB2.UserSetHighlightedItemChanged += new RoutedEventHandler(UserSetHighlightedItemChanged);

			//Load H2 DB driver so we can see info on controllers and devices the project list box
			ProjectFileName.H2DataBaseDriver(true);

			//Extract any files embedded as resources
			ExtractEmbeddedResources();

            //Init the package manager helper
            InitializeAndConnectToPackageManager();

            PopulatePackageListBox();

			//Load defaults for the selection of devices if well-known file exists
			// a user browsing for a file will change the current directory so we must ensure we are looking in the correct directory.
			//Directory.SetCurrentDirectory(_dirExecutable);
			if (File.Exists(_WELL_KNOWN_DEFAULT_CONTROLLERS_FILE))
				LoadMyDefaults();
        }

        /// <summary>
        /// Atempt to connect to package manager. If we are not able, then attempt to start OSGI and retry connecting to package manager
        /// </summary>
        private void InitializeAndConnectToPackageManager()
        {
            bool isPacManConnectionValid = PackageManagerHelper.Instance().Initialize();
            // if we can connect then we dont need to do any more work here since it means OSGI is already running
            if (isPacManConnectionValid) return;

            // Allow the unit tests to hide the package manager error given they use the mock services
            bool HidePackagerError = !string.IsNullOrEmpty(Environment.GetCommandLineArgs().FirstOrDefault(x => { return x.StartsWith(_SKIP_PACKAGER_ERROR_COMMANDLINE_PARAM); }));
            // If we are hiding package manager errors, not need to do any more work here since we are using mock services
            if (HidePackagerError) return;

            // Check if OSGI is running and if it needs starting, wait a little for it to spin up
            MessageBox.Show("The package manager service connection could not be established:\n\n\t" + PackageManagerHelper.Instance().LastInitializeError +
                    "\n\nMake sure that your RA OSGI service is running. Continuing with PopUpTestHost startup...", "Package Manager Connection Failed");
        }

        public Visibility TestHostMainContentVisibility
        {
            get
            {
                return HasOpenPackage && !DeviceCreationEditGrid.IsVisible ? Visibility.Visible : Visibility.Hidden;
            }
        }

        public bool HasOpenPackage
        {
            get
            {
                bool ret = true;
                if (PackageList.SelectedItem != null && PackageList.SelectedItem is PackageFileName)
                {
                    PackageFileName curPackage = PackageList.SelectedItem as PackageFileName;
                    ret = curPackage.IsOpen || curPackage.FullPath==_INVALID_DB_TEXT;
                }
                return ret;
            }
        }

        public bool NoBrowserOpen
        {
            get { return (bool)GetValue(NoBrowserOpenProperty); }
            set { SetValue(NoBrowserOpenProperty, value); }
        }

        // Using a DependencyProperty as the backing store for HasOpenTagBrowser.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NoBrowserOpenProperty =
            DependencyProperty.Register("NoBrowserOpen", typeof(bool), typeof(Window1), new UIPropertyMetadata(true));

        
		/// <summary>
		/// Extracts various files embedded as resources for use during runtime
		/// </summary>
		private void ExtractEmbeddedResources()
		{
			try
			{
				string[] TafSubdirs = {"Assets", "UIObjects", "Workflow"};
				string GenDbDir = System.IO.Path.Combine(_dirExecutable, "GenerateDatabase");

				//Create root directory
				if (!Directory.Exists(GenDbDir))
					Directory.CreateDirectory(GenDbDir);

				//Create sub directories
				foreach(string subDir in TafSubdirs)
				{
					string FullSubDir = System.IO.Path.Combine(GenDbDir, subDir);
					if(!Directory.Exists(FullSubDir))
						Directory.CreateDirectory(FullSubDir);
				}

				//Extract the GenerateDatabase TAF solution
				Stream GenDb_TafSln = Assembly.GetExecutingAssembly().GetManifestResourceStream("PopupTestHost.tafsolution.taf");
                var TafSlnFileStream = File.Create(System.IO.Path.Combine(GenDbDir, "tafsolution.taf"));
                GenDb_TafSln.CopyTo(TafSlnFileStream);
                TafSlnFileStream.Close();
                var KernelCfgFileStream = File.Create(System.IO.Path.Combine(GenDbDir, "kernelconf.xml"));
                GenDb_TafSln.CopyTo(KernelCfgFileStream);
                KernelCfgFileStream.Close();
                GenDb_TafSln.Close();

				//Extract the GenerateDatabase TAF workflow
				var TafWrkFileStream = File.Create(System.IO.Path.Combine(GenDbDir, "Workflow", "GenDbFromTxt.wfxml"));
				Stream GenDb_TafWrk = Assembly.GetExecutingAssembly().GetManifestResourceStream("PopupTestHost.GenDbFromTxt.wfxml");
				GenDb_TafWrk.CopyTo(TafWrkFileStream);
				TafWrkFileStream.Close();
				GenDb_TafWrk.Close();
			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}

        /// <summary>
        /// Retrieve the ROCWKELL_DATA_DIRECTORY environment variable.
        /// If the environment variable is already set on the process level, we want to use that. This is what will be used when we run unit tests from autobuild as that will set the process variable before launching the unit tests
        /// If the environment variable is not set at the process level, use the normal env variable set on the machine. This is what will be used when launching the PopUpTestHost from development
        /// </summary>
        private String GetEnvironmentVariableRockwellDataDirectory()
        {
            String processEnvVariable = Environment.GetEnvironmentVariable(_ROCWKELL_DATA_DIRECTORY_LITERAL, EnvironmentVariableTarget.Process);
            if (processEnvVariable != null) return processEnvVariable;

            return Environment.GetEnvironmentVariable(_ROCWKELL_DATA_DIRECTORY_LITERAL, EnvironmentVariableTarget.Machine);

            //bool isUsingCustomValeForRockwellDataDirectory = !string.IsNullOrEmpty(Environment.GetCommandLineArgs().FirstOrDefault(x => { return x.StartsWith("/ROCKWELL_DATA_DIRECTORY="); }));
            //if (!isUsingCustomValeForRockwellDataDirectory) return Environment.GetEnvironmentVariable("ROCKWELL_DATA_DIRECTORY", EnvironmentVariableTarget.Machine);

        }        

		/// <summary>
		/// Window closing
		/// </summary>
		/// <param name="e"></param>
		protected override void OnClosing(CancelEventArgs e)
		{
			base.OnClosing(e);

            Window DibWindow = GetOpenDibWindow();
            if (DibWindow != null)
                DibWindow.Close();

			//close the H2 database driver we opened in the window load
			ProjectFileName.H2DataBaseDriver(false);

            //close any package manager connections
            PackageManagerHelper.Instance().Shutdown();
            // Make sure to close any query or edit sessions left open by DibQuery
            DIBClientManagerForViewe.Instance.Shutdown();
		}

		/// <summary>
		/// Check to see if there is an open DIB window whenever the whenever the popup test host window activates
		/// so we can set various variables that control the state of gui elements (for instance the property
        /// editor buttons should be disabled if a DIB window is currently open).  We also show an extra context
        /// menu item to show the open DIB window which might have gotten hidden behind other windows which can 
        /// happen and is a common annoyance when using the persist window and switching between windows/debugging)
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void Window_Activated(object sender, EventArgs e)
		{
            bool hasOpenBrowser = (GetOpenDibWindow() != null);

            ProcessBrowserWindowIsOpenChange(hasOpenBrowser);

            Focus();
		}

        /// <summary>
        /// Helper to control the booleans tracking if browser window is open
        /// </summary>
        /// <param name="isOpen"></param>
        private void ProcessBrowserWindowIsOpenChange(bool isOpen)
        {
            //This will take care of enabling/disabling the buttons that open the tag browser
            NoBrowserOpen = !isOpen;

            //Code behind to save a converter
            ShowBrowserMenuItem.Visibility = isOpen ? Visibility.Visible : Visibility.Collapsed;
        }

        /// <summary>
        /// Attempts to locate an open DIB window and returns that window if found
        /// </summary>
        /// <returns>Window to the open DIB window</returns>
        private Window GetOpenDibWindow()
        {
            Window openDib = null;

            foreach (Window win in Application.Current.Windows)
            {
                if (win != this && win is RockwellAutomation.UI.Windows.DIBWindow)
                {
                    if ((win as RockwellAutomation.UI.Windows.DIBWindow).PersistWindow)
                        openDib = win.IsVisible ? win : null;
                    break; //since we know there's only one
                }
            }

            return openDib;
        }

        /// <summary>
        /// Handle the HighlightedItemChanged event from the PropertyEditorWithTagBrowser controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void HighlightedItemChanged(object sender, RoutedEventArgs e)
        {
            PropertyEditorWithTagBrowser propertyEditor = sender as PropertyEditorWithTagBrowser;
            if (propertyEditor != null)
            {
                HighlightedItem = propertyEditor.HighlightedItem;
            }
        }

        /// <summary>
        /// Handle the UserSetHighlightedItemChanged event from the PropertyEditorWithTagBrowser controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void UserSetHighlightedItemChanged(object sender, RoutedEventArgs e)
        {
            PropertyEditorWithTagBrowser propertyEditor = sender as PropertyEditorWithTagBrowser;
            if (propertyEditor != null)
            {
                UserSetHighLightedItemResourceID = propertyEditor.UserSetHighlightedItemResourceID;
                if (UserSetHighlightedItem != propertyEditor.UserSetHighlightedItem)
                {
                    UserSetHighlightedItem = propertyEditor.UserSetHighlightedItem;
                }
            }
        }

        /// <summary>
        /// Add all package files (or project files if using the mock) to the PackageListBox
        /// </summary>
        private void PopulatePackageListBox(bool readContent = false)
        {
            this.PackageList.Items.Clear();

            {
                //Obtain a list of open packages so we can keep track of what may have been previously opened
                IList<OpenPackageInfo> OpenPackages = PackageManagerHelper.Instance().Initialized ? PackageManagerHelper.Instance().GetOpenPackages() : null;

                //Create a list of directories to search for packages in (can be overridden via a file)
                string[] packageDirs = { PackageDir, PackageDirDesigner };
                string pathFile = System.IO.Path.Combine(_dirExecutable, _WELL_KNOWN_DEFAULT_PACKAGEPATH_FILE);
                if (File.Exists(pathFile))
                {
                    string[] allFileLines = File.ReadAllLines(pathFile);
                    if (allFileLines.Count() > 0)
                        packageDirs = allFileLines;
                }

                //Obtain a list of all package files
                List<string> files = new List<string>();
                string mockExt = ".xml";
                string realExt = ".vpd";
                foreach (string fileLine in packageDirs)
                {
                    if (string.IsNullOrWhiteSpace(fileLine))
                        continue;

                    //An env variable may or may not end in a backslash so replace with a comma to allow for a Path.Combine call below.
                    // This is somewhat for backward compatability as well since we originally persisted a slash in the defaults file.
                    string fileLineMod = fileLine.Replace(@"%\", @"%,");

                    string dir = Environment.ExpandEnvironmentVariables(fileLineMod);
                    if (dir.Contains(','))
                        dir = System.IO.Path.Combine(dir.Split(','));

                    if (Directory.Exists(dir))
                    {
                        IEnumerable<string> foundFiles = Directory.GetFiles(dir, "*" + realExt).Union(Directory.GetFiles(dir, "*" + mockExt));
                        foreach (string filePath in foundFiles)
                            files.Add(filePath);
                    }
                }

                //Sort and add each file to the package list
                IEnumerable<String> filesSorted = files.OrderByDescending(filePath => File.GetLastWriteTime(filePath));
                foreach (string file in filesSorted)
                {
                    bool ReadFileContent = readContent && !Keyboard.IsKeyDown(Key.LeftShift) && !Keyboard.IsKeyDown(Key.RightShift);
                    //Real ROA package files
                    if (file.ToLower().EndsWith(".vpd"))
                    {
                        OpenPackageInfo openPackage = OpenPackages == null ? null : OpenPackages.SingleOrDefault(opi =>
                            {
                                string openPackagePath = opi.Uri.TrimStart(new char[]{'/'}).Replace('/', '\\'); //just incase we get a "unix" style path
                                return openPackagePath.Equals(file, StringComparison.CurrentCultureIgnoreCase);
                            });
                        UUID PackageId = openPackage != null ? openPackage.PackageUUID : null;
                        UUID ProjectId = PackageId != null ? PackageManagerHelper.Instance().GetProjectDatabaseIdFromPackage(PackageId) : null;
                        this.PackageList.Items.Add(new PackageFileName(file, PackageId, ProjectId));
                    }
                    //Mock ROA project files
                    else if (file.ToLower().EndsWith(".xml"))
                    {
                        this.PackageList.Items.Add(new ProjectFileName(file, ReadFileContent, true));
                    }
                }
            }

            //If we don't have items, add a blank
            if (!this.PackageList.HasItems)
                this.PackageList.Items.Add(new PackageFileName("", null, null));//XAML will take care of the text in this case
            this.PackageList.SelectedIndex = 0;

            //If we are able, add item to create new package files
            if (CanGenerateDatabases() && PackageManagerHelper.Instance().Initialized)
                this.PackageList.Items.Add(new PackageFileName(_NEW_DB_TEXT, null, null));
        }

		 /// <summary>
		 /// browse for acd files using the OpenFileDialog and set the textbox text 
		 /// </summary>
		 /// <param name="tb">textbox to update</param>
		 private void BrowserForAcd(TextBox tb)
		 {
			 string originalACD = tb.Text;

			 Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
			 // Set filter for file extension and default file extension 
			 dlg.DefaultExt = ".acd";
			 dlg.Filter = "Acd files(.acd)|*.acd";
			 if (tb.Text == "")
				 dlg.InitialDirectory = "C:\\RSLogix 5000\\Projects\\";
			 else
			 {
				 if(tb.Text.EndsWith("\\"))
				 {
					 dlg.InitialDirectory = tb.Text;
				 }
				 else
					 dlg.FileName = tb.Text;
			 }


			 // Display OpenFileDialog by calling ShowDialog method 
			 try
			 {
				 Nullable<bool> result = dlg.ShowDialog();
				 // Get the selected file name and display in a TextBox 
				 if (result == true)
				 {
					 // Open document
					 string filename = dlg.FileName;
					 // DFCTS00119687: Popup TestHost: Browsing to the same acd file name in controller path does not force reconnection
					 //    Set to empty before setting the filename because if the name is the same it will not refresh.
					 tb.Text = "";
					 tb.Text = filename;
				 }
			 }
			 catch (Exception exception)
			 {
				 string msg;
				 msg = "The OpenFileDialog has thrown an Exception with the Message:\n\t";
				 msg += exception.Message;
				 msg += "\n\nThe text entered must end with a '\\' to indicate at path or end with a '.' extension to indicate a filename.";
				 msg += "\nNote that UNC paths expect share names and may behave differently than mapped letter drive paths.";
				 msg += "\nAlso be aware that invalid paths may not throw an exception so always verify the location when the dialog appears if you are unsure.";
				 MessageBox.Show(msg, this.testHostMainWnd.Title);
			 }
			 // If the ACD's name has changed then force user to choose the desired browser type
			 if (System.String.Compare(tb.Text, originalACD, true) != 0)
			 {
				 this.TagBrowserButton.IsChecked = false;
				 this.TagBrowser.Visibility = Visibility.Collapsed;

				 this.DataTypeBrowserButton.IsChecked = false;
				 this.DataTypeBrowser.Visibility = Visibility.Collapsed;
				 ClearTagNames();
			 }         
		 }

		/// <summary>
		/// browse for controller files, based on the button clicked
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void controllerbrowsebtn_Click(object sender, RoutedEventArgs e)
		{
			Button btn = sender as Button;

			if (btn.Name == controller1browsebtn.Name)
				BrowserForAcd(controller1tx);
			else if (btn.Name == controller2browsebtn.Name)
				BrowserForAcd(controller2tx);
			else if (btn.Name == controller3browsebtn.Name)
				BrowserForAcd(controller3tx);
			else if (btn.Name == controller4browsebtn.Name)
				BrowserForAcd(controller4tx);
		}

		/// <summary>
		/// The name of a controller has changed.  Validate it is unique.
		/// If it is unique uncheck toggle buttons for Tag Browser and Data Type Browser as
		/// well as hide associated data ports.
		/// </summary>
		private void controller_TextChanged(object sender, TextChangedEventArgs e)
		{
			if ((this.controller1Nametx != null) && (this.controller2Nametx != null) && (this.controller3Nametx != null) && (this.controller4Nametx != null))
			{
				if ((this.controller1Nametx.Text == this.controller2Nametx.Text) ||
					(this.controller1Nametx.Text == this.controller3Nametx.Text) ||
					(this.controller1Nametx.Text == this.controller4Nametx.Text) ||
					(this.controller2Nametx.Text == this.controller3Nametx.Text) ||
					(this.controller2Nametx.Text == this.controller4Nametx.Text) ||
					(this.controller3Nametx.Text == this.controller4Nametx.Text))
				{
					if (this.controller1Nametx.IsFocused)
						{this.controller1Nametx.Text = "";}
					else if (this.controller2Nametx.IsFocused)
						{this.controller2Nametx.Text = "";}
					else if (this.controller3Nametx.IsFocused)
						{this.controller3Nametx.Text = "";}
					else if (this.controller4Nametx.IsFocused)
						{this.controller4Nametx.Text = "";}

					MessageBox.Show("Controller names must be unique. Please enter a valid name.", "Popup TestHost");
					return;
				}
			}
 
			if (this.TagBrowserButton != null)
			{
			   this.TagBrowserButton.IsChecked = false;
			   this.TagBrowser.Visibility = Visibility.Collapsed;
			}
			if(this.DataTypeBrowserButton != null)
			{
			   this.DataTypeBrowserButton.IsChecked = false;
			   this.DataTypeBrowser.Visibility = Visibility.Collapsed;
			}

			if(this.dataProvider!=null)
                this.dataProvider.Text = _NOT_AVAILABLE_LITERAL;

			// The following order is important as each assignment causes the BrowserTypeAndHighlightedConverter to be called
			BrowserTypeAndHighlightedConverter.Clear();
			this.BrowserType = "";
			//this.txHighlightedItem.Text = _NOT_AVAILABLE_LITERAL;

			ClearTagNames();
		}

		/* ROAQ
		private void process_controller_ValidationError()
		{
			// set flag to to force a relodaing of the ACD file.
			_validationError = true;
			_resetACDFiles = true;
			if (this.TagBrowserButton != null)
			{
				this.TagBrowserButton.IsChecked = false;
				this.TagBrowser.Visibility = Visibility.Collapsed;
			}
			if (this.DataTypeBrowserButton != null)
			{
				this.DataTypeBrowserButton.IsChecked = false;
				this.DataTypeBrowser.Visibility = Visibility.Collapsed;
			}
			this.dataProvider.Text = _NOT_AVAILABLE_LITERAL;

			// The following order is important as each assignment causes the BrowserTypeAndHighlightedConverter to be called
			BrowserTypeAndHighlightedConverter.Clear();
			this.BrowserType = "";
			this.txHighlightedItem.Text = _NOT_AVAILABLE_LITERAL;

			ClearTagNames();
		}
		*/

		/// <summary>
		/// Empty our the TextBoxes associated with the Tag Browser and the Data Type Browser.
		/// </summary>
		private void ClearTagNames()
		{
			if (null != this.PropertyEditWithTB1)
				this.PropertyEditWithTB1.TagName = "";

			if (null != this.PropertyEditWithTB2)
				this.PropertyEditWithTB2.TagName = "";

			if (null != this.PropertyEditWithDataType_1)
				this.PropertyEditWithDataType_1.TagName = "";

			if (null != this.PropertyEditWithDataType_2)
				this.PropertyEditWithDataType_2.TagName = "";
		}

		/* ROAQ
		private IList<RockwellAutomation.UI.Container> GetControllers()
		{
			IList<RockwellAutomation.UI.Container> controllers = new List<RockwellAutomation.UI.Container>();
			Controller newController = null;
			_validationError = false;
			if (controller1tx.Text != "")
			{
				newController = CreateController(controller1Nametx.Text, controller1tx.Text);
				if (null != newController)
					controllers.Add(newController);
				else
					process_controller_ValidationError();
			}
			if (controller2tx.Text != "" && !_validationError)
			{
				newController = CreateController(controller2Nametx.Text, controller2tx.Text);
				if (null != newController)
					controllers.Add(newController);
				else
					process_controller_ValidationError();
			}
			if (controller3tx.Text != "" && !_validationError)
			{
				newController = CreateController(controller3Nametx.Text, controller3tx.Text);
				if (null != newController)
					controllers.Add(newController);
				else
					process_controller_ValidationError();
			}
			if (controller4tx.Text != "" && !_validationError)
			{
				newController = CreateController(controller4Nametx.Text, controller4tx.Text);
				if (null != newController)
					controllers.Add(newController);
				else
					process_controller_ValidationError();
			}

 
			return controllers;
		}
		 */

        /// <summary>
        /// Specify if the Tag or the Data Type Browser should be displayed
        /// When a radio button is checked, this method determines which browser controls to display.
        /// </summary>
        private void HandleBrowserChange(object sender, RoutedEventArgs e) 
        {
            RadioButton rb = sender as RadioButton;
            
            if ((this.TagBrowser == null) || (this.DataTypeBrowser == null)) {
                   // This method is called during InitializeComponent and not all elements are created yet
                   return;
            }
            if (rb == null) return;
            if (_validationError) return;
            if (rb.Equals(TagBrowserButton))
            {
                if (rb.IsChecked == true)
                {
                    this.BrowserType = DIResource.DI_COMMON_RESOURCETYPE_TAG;
                    this.TagBrowser.Visibility = Visibility.Visible;
                    this.DataTypeBrowser.Visibility = Visibility.Collapsed;
                }
            }
            else
            {
                // Data Type Browser
                if (rb.IsChecked == true)
                {
                    this.BrowserType = DIResource.DI_COMMON_RESOURCETYPE_DATATYPE;
                    this.TagBrowser.Visibility = Visibility.Collapsed;
                    this.DataTypeBrowser.Visibility = Visibility.Visible;
                }
            }
        }

           #region INotifyPropertyChanged Members
           /// <summary>
           /// implements that INotifyPropertyChanged inteface method NotifyPropertyChanged
           /// </summary>
           public event PropertyChangedEventHandler PropertyChanged;

           protected void NotifyPropertyChanged(string propertyName)
           {
               if (PropertyChanged != null)
                   PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
           }

           #endregion

		   private void PackageList_SelectionChanged(object sender, SelectionChangedEventArgs e)
		   {
               UpdateControlsFromPackageListSelection(true, false);

               ClearSearchMRUListHistory();

               //Set which service type to use
               if(PackageList.SelectedItem is ProjectFileName)
                   DIBQueryConnection.SetResourceServiceType(true); //use mock
               else if(PackageList.SelectedItem is PackageFileName)
                   DIBQueryConnection.SetResourceServiceType(false); //use real
           }

            //Helper to look at the selection of the package list and set the gui controls accordingly
            private void UpdateControlsFromPackageListSelection(bool frameworkInvoked, bool fromFailedCreate)
            {
                //Don't do anything while a database is being generated
                if (frameworkInvoked && DeviceCreationEditGrid.IsVisible && !DeviceCreationEditGrid.IsEnabled)
                    return;

               bool isSelectionOnBlank   = false;
               bool isSelectionOnAddNew  = false;
               bool isSelectionOnInvalid = false;
               UUID PackageId = null;
               UUID ProjectId = null;
               bool isPackageOpen = false;
               bool isSelectionUnknown = false;
               bool isUsingMock = false;

               //Package file names used for real ROA
               if (PackageList.SelectedItem is PackageFileName)
               {
                   PackageFileName curPackage = PackageList.SelectedItem as PackageFileName;
                   isSelectionOnBlank   = curPackage.FullPath == "";
                   isSelectionOnAddNew  = curPackage.FullPath == _NEW_DB_TEXT;
                   isSelectionOnInvalid = curPackage.FullPath == _INVALID_DB_TEXT;
                   PackageId = curPackage.PackageId;
                   ProjectId = curPackage.ProjectId;
                   isPackageOpen = curPackage.IsOpen || isSelectionOnInvalid;
               }
               //Project file names used for mock ROA
               else if (PackageList.SelectedItem is ProjectFileName)
               {
                   ProjectFileName curProject = PackageList.SelectedItem as ProjectFileName;
                   isSelectionOnAddNew = curProject.FullPath == _NEW_DB_TEXT;
                   PackageId = ServiceFramework.DataTypes.UUID.CreateBuilder().SetHi(curProject.HiWord).SetLo(curProject.LoWord).Build();
                   ProjectId = ServiceFramework.DataTypes.UUID.CreateBuilder().SetHi(curProject.HiWord).SetLo(curProject.LoWord).Build();
                   isUsingMock = true;
               }
               //Handle an unexpected object gracefully
               else
                   isSelectionUnknown = true;

               //As long as we know what type of object we're dealing with, set properties accordingly
               if(!isSelectionUnknown)
               {
                   if (isSelectionOnAddNew)
				   {
                       PackageNameValue.Text = GetTimeStampPackageName();
                       ProjectNameValue.Text = GetTimeStampPackageName();
                       
					   ProcessGenerateDbResults(null, false); //clear color/toolips set from any previous db gen
					   DeviceCreationEditGrid.Visibility = Visibility.Visible;

                       SelectAndFocusActiveFileNameTextbox();

                       //hide the package open / close buttons
                       PackageOpenButton.Visibility = Visibility.Hidden;
                       PackageCloseButton.Visibility = Visibility.Hidden;
				   }
				   else
				   {
                       //Hide the device creation grid as long as we weren't called from a failed package creation
                       if(!fromFailedCreate)
					        DeviceCreationEditGrid.Visibility = Visibility.Collapsed;

                       //Set the open/closed button visibility based on if the package is open (and if using mock/if current selection is the blank item)
                       PackageOpenButton.Visibility = !isSelectionOnBlank && !isPackageOpen && !isUsingMock && !isSelectionOnInvalid ? Visibility.Visible : Visibility.Hidden;
                       PackageCloseButton.Visibility = !isSelectionOnBlank && isPackageOpen && !isUsingMock && !isSelectionOnInvalid ? Visibility.Visible : Visibility.Hidden;

                       UpdatePropEditsContextIds(PackageId, ProjectId);
				   }

                   //Update the display of content in the popup test host
                   NotifyPropertyChanged("TestHostMainContentVisibility");

                   //It would get confusing if we keep an open DIB up when the package selection changes,
                   // so close an open window if we get here
                   Window DibWindow = GetOpenDibWindow();
                   if (DibWindow != null)
                   {
                       DibWindow.Close();
                       ProcessBrowserWindowIsOpenChange(false);
                   }

                   // Set the controls back to their original values.
                   // TagBrowser and Data Type Selector radio buttons remain the same
                   this.txLastHighLightedItem.Text = _NOT_AVAILABLE_LITERAL;
                   this.txUserSetHighlightedItem.Text = _NOT_AVAILABLE_LITERAL;
                   this.txUserSetHighlightedItemResourceID.Text = _NOT_AVAILABLE_LITERAL;
                   this._userSetHighLightedItemResourceID = null;
                   this.txReadTag.Text = string.Empty;
                   this.txReadTagID.Text = _NOT_AVAILABLE_LITERAL;
                   this.txWriteTag.Text = string.Empty;
                   this.txWriteTagID.Text = _NOT_AVAILABLE_LITERAL;
                   this.txDataType1.Text = string.Empty;
                   this.txDataType1ID.Text = _NOT_AVAILABLE_LITERAL;
                   this.txDataType2.Text = string.Empty;
                   this.txDataType2ID.Text = _NOT_AVAILABLE_LITERAL;
                   this.txRoot.Text = "";
                   this.txInclude.Text = "";
                   this.txExclude.Text = "";
                   this.excludeRoot.IsChecked = false;
                   this.navIntoFolderRoot.SelectedIndex = 0;
                   this.txFilterType.Text = "";
                   this.txFilterValue.Text = "";
                   this.exactMatch.IsChecked = false;
			   }
		   }

            private void SelectAndFocusActiveFileNameTextbox()
            {
                //focus and select the package/project name text
                if (PackageNameTab.IsSelected)
                {
                    PackageNameValue.Focus();
                    PackageNameValue.SelectAll();
                }
                else if(ProjectNameTab.IsSelected)
                {
                    ProjectNameValue.Focus();
                    ProjectNameValue.SelectAll();
                }
            }

           private void PackageOpenButton_Click(object sender, RoutedEventArgs e)
           {
               //Per requirements, whenever a project is opened, the MRU should clear,
               // so perform that action here.
               ClearSearchMRUListHistory();

               PackageFileName curPackage = PackageList.SelectedItem as PackageFileName;
               if (curPackage != null)
               {
                   PackageOpenButton.IsEnabled = false;
                   
                   bool bShiftKeyDown = Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift);

                   UUID PackageId = PackageManagerHelper.Instance().OpenPackage(curPackage.FullPath);
                   if (PackageId != null)
                   {
                       //We got the package id okay so now attempt to get the project database
                       curPackage.PackageId = PackageId;

                       UUID ProjectId = PackageManagerHelper.Instance().GetProjectDatabaseIdFromPackage(PackageId);
                       curPackage.ProjectId = ProjectId;

                       //If we couldn't obtain the project id, show an error message
                       if (ProjectId == null)
                           MessageBox.Show("The package specified is invalid.\n\nThe project database named '" + PackageManagerHelper.ProjectDatabaseName + "' could not be located in package.", "Package Open Failed");

                       UpdatePropEditsContextIds(PackageId, ProjectId);

                       //If we got the project id, or if the shift key is down (which we allow to keep an empty package open)
                       if (ProjectId != null || bShiftKeyDown)
                       {
                           //Success so hide the open button and show the close button
                           PackageOpenButton.Visibility = Visibility.Hidden;
                           PackageCloseButton.Visibility = Visibility.Visible;

                           //Ensure the package list is disabled (while a package is open)
                           PackageList.IsEnabled = false;

                           //Update the display of content in the popup test host
                           NotifyPropertyChanged("TestHostMainContentVisibility");
                       }
                       //Otherwise we need to close the package
                       else
                       {
                           //Close the package since we couldn't obtain a project file from it
                           PackageManagerHelper.Instance().ClosePackage(PackageId);

                           //Null the package id to reflect the above close package (thus gui will not show as open)
                           curPackage.PackageId = null;
                       }
                   }
                   //If we couldn't open the package, show an error message
                   else
                   {
                       MessageBox.Show("The package specified could not be opened.\n\n" + PackageManagerHelper.Instance().LastPackageOpenResponseError, "Package Open Failed");
                   }

                   PackageOpenButton.IsEnabled = true;
               }
           }

           private void PackageCloseButton_Click(object sender, RoutedEventArgs e)
           {
               PackageFileName curPackage = PackageList.SelectedItem as PackageFileName;
               if (curPackage != null)
               {
                   PackageCloseButton.IsEnabled = false;
                   if (PackageManagerHelper.Instance().ClosePackage(curPackage.PackageId))
                   {
                       //Success so hide the close button and show the open button
                       PackageCloseButton.Visibility = Visibility.Hidden;
                       PackageOpenButton.Visibility = Visibility.Visible;

                       //Ensure the package list is enabled
                       PackageList.IsEnabled = true;

                       //Null the guids of the package file name so we know it's closed
                       curPackage.PackageId = null;
                       curPackage.ProjectId = null;

                       //Hide device creation which could be shown if a previous create failed
                       DeviceCreationEditGrid.Visibility = Visibility.Collapsed;

                       //Update the display of content in the popup test host
                       NotifyPropertyChanged("TestHostMainContentVisibility");
                   }

                   PackageCloseButton.IsEnabled = true;
               }
           }

            /// <summary>
            /// Helper to open a file and call a callback once it is closed
            /// </summary>
            /// <param name="path"></param>
            /// <param name="callback"></param>
           private void OpenTxtFileWithCallback(string path, Action callback)
           {
               Process openTxtProc = new Process();
           
                openTxtProc.StartInfo.FileName = path;
                openTxtProc.EnableRaisingEvents = true;
                openTxtProc.Exited += new EventHandler((object pSender, EventArgs pArgs) =>
                {
                    testHostMainWnd.Dispatcher.BeginInvoke(new System.Threading.ThreadStart(() =>
                    {
                        callback();
                    }));
                });
                openTxtProc.Start();
           }

		   private void PackageList_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
		   {
			   if (_LastTafCmdProc != null && !_LastTafCmdProc.HasExited)
			   {
				   if (MessageBox.Show("Package creation in progress.  Do you want to stop it now?", "Stop package creation?", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
				   {
					   e.Handled = true;
					   try
					   {
						   if (_LastTafCmdProc != null && !_LastTafCmdProc.HasExited) //check again since time might have gone by since the message box
						   {
							   _LastTafCmdProc.Kill();
							   ProcessGenerateDbResults(new string[] { "STOP" }, false);
						   }
					   }
					   catch (Exception ex)
					   {
						   Console.WriteLine(ex.Message);
					   }
				   }
			   }
			   else if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
			   {
                    //Ctrl+Shift click should open notepad with the default file
                    if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
                    {
                        //Create file if it doesn't exist with our default package subdir
                        string pathFile = System.IO.Path.Combine(_dirExecutable, _WELL_KNOWN_DEFAULT_PACKAGEPATH_FILE);
                        if (!File.Exists(pathFile))
                            File.WriteAllLines(pathFile, new string[] { "%" + _ROCWKELL_DATA_DIRECTORY_LITERAL + "%," + _DIB_TEST_PROJECTS + "\r\n" + @"%USERPROFILE%\Documents\Studio 5000\Projects" });
                        
                        //Open the file
                        if (File.Exists(pathFile))
                        {
                            OpenTxtFileWithCallback(pathFile, () => {
                                //Update listbox when file closes
                                PopulatePackageListBox();
                            });
                            e.Handled = true;
                            return;
                        }
                    }

                    Popup thePop = new Popup { Placement = PlacementMode.Relative, PlacementTarget = PackageList, StaysOpen = false };
                    TextBox pathEdit = new TextBox { Text = this.GetEnvironmentVariableRockwellDataDirectory(), Width = PackageList.ActualWidth - 50 };
                    PackageLabel.Tag = PackageLabel.Text;
                    PackageLabel.Text = "ROCKWELL_DATA_DIRECTORY:";
                    PackageStateGrid.Visibility = Visibility.Hidden;
                    thePop.Closed += new EventHandler((object snr, EventArgs arg)=>
                    {
                        PackageLabel.Text = (string)PackageLabel.Tag;
                        PackageStateGrid.Visibility = Visibility.Visible;
                    });
					pathEdit.KeyDown += new KeyEventHandler((snr, arg) =>
					{
						if(arg.Key==Key.Enter)
						{
							Button ob = ((arg.OriginalSource as TextBox).Tag as Button);
							ob.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, ob));
                            arg.Handled = true;
						}
					});
                    pathEdit.PreviewMouseDown += new MouseButtonEventHandler((object snr, MouseButtonEventArgs arg) =>
                    {
                        //Ctrl+Shift click should open ROCKWELL_DATA_DIRECTORY
                        bool bShiftKeyDown = Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift);
                        bool bCtrlKeyDown = Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl);
                        if (bCtrlKeyDown && bShiftKeyDown)
                        {
                            string pathEditText = (snr as TextBox).Text;
                            string folderToShow = Directory.Exists(pathEditText) ? pathEditText : this.GetEnvironmentVariableRockwellDataDirectory();

                            OpenFolderViaWinExplorer(folderToShow);
                            
                            arg.Handled = true;
                        }
                    });
					Button okayButt = new Button { Content = "SET", Width = 50 };
					pathEdit.Tag = okayButt;
					okayButt.Tag = pathEdit;
					okayButt.Click += new RoutedEventHandler((snr, arg)=>
					{
						String pathEditText = ((arg.OriginalSource as Button).Tag as TextBox).Text;
						if(String.IsNullOrWhiteSpace(pathEditText))
						{
							thePop.IsOpen = false;
						}
						else if (Directory.Exists(pathEditText))
						{
                            Environment.SetEnvironmentVariable(_ROCWKELL_DATA_DIRECTORY_LITERAL, pathEditText, EnvironmentVariableTarget.Machine);
							bool readContent = Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl);
                            PopulatePackageListBox(readContent);
							thePop.IsOpen = false;
						}
						else
						{
							thePop.IsOpen = false;
							MessageBox.Show("Invalid path: " + pathEditText);
							thePop.IsOpen = true;
						}
					});
                    StackPanel stack = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = System.Windows.HorizontalAlignment.Stretch, Height = PackageList.ActualHeight };
					stack.Children.Add(pathEdit);
					stack.Children.Add(okayButt);
					
					thePop.Child = stack;
					thePop.IsOpen = true;
                    pathEdit.Focus();
                    pathEdit.SelectAll();
					e.Handled = true;
			   }
		   }

           //Helper to show a folder in windows explorer
           private void OpenFolderViaWinExplorer(string folderToShow)
           {
               Process openExplorerProc = new Process();
               openExplorerProc.StartInfo.FileName = folderToShow;
               openExplorerProc.StartInfo.UseShellExecute = true;
               openExplorerProc.StartInfo.Verb = "Open";
               openExplorerProc.Start();
           }

           /// <summary>
           /// Helper to set the package / project id on the property editor controls
           /// </summary>
           /// <param name="PackageId">UUID representing the package to use for the DIB</param>
           /// <param name="ProjectId">UUID representing the project to use for the DIB</param>
           private void UpdatePropEditsContextIds(UUID PackageId, UUID ProjectId)
           {
               this.PropertyEditWithTB1.PackageContext = PackageId;
               this.PropertyEditWithTB1.ProjectContext = ProjectId;

               this.PropertyEditWithTB2.PackageContext = PackageId;
               this.PropertyEditWithTB2.ProjectContext = ProjectId;

               this.PropertyEditWithDataType_1.PackageContext = PackageId;
               this.PropertyEditWithDataType_1.ProjectContext = ProjectId;

               this.PropertyEditWithDataType_2.PackageContext = PackageId;
               this.PropertyEditWithDataType_2.ProjectContext = ProjectId;
           }

		   /// <summary>
		   /// Helper to ask if the user wants to start a process (and start it if yes)
		   /// </summary>
		   /// <param name="promptName">name to display in the prompt for the user</param>
		   /// <param name="path">directory where the file to run exists</param>
		   /// <param name="file">file to run ('bat', 'exe', etc.)</param>
		   /// <param name="args">arguments to pass to the file</param>
		   /// <returns></returns>
		   private Process PromptToStart(string promptName, string path, string file, string args="")
		   {
			   Process proc = null;
			   if (MessageBox.Show(promptName + " does not appear to be started.  Would you like to start it now?", "Start "+promptName+"?", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
			   {
				   try
				   {
					   proc = new Process();
					   proc.StartInfo.WorkingDirectory = path;

					   string PathAndName = System.IO.Path.Combine(path, file);
					   if (PathAndName.EndsWith(".bat"))
					   {
						   proc.StartInfo.FileName = "cmd";
						   proc.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
						   proc.StartInfo.Arguments = "/C \"" + file + " " + args + "\"";
					   }
					   else
					   {
						   proc.StartInfo.FileName = PathAndName;
						   proc.StartInfo.Arguments = args;
					   }

					   proc.Start();
				   }
				   catch (Exception ex)
				   {
					   Console.WriteLine(ex.Message);
				   }
			   }

			   return proc;
		   }

            private void GetAllSelectedComboboxItemsExcept(ComboBox cb,ref string navIntoFoldertxt,ref string excludeAllChildrenOfTypetxt,ref string excludeAllOfTypetxt,ref string includeAllOfTypetxt)
            {
                if (cb != this.navIntoFolderRoot )
                {
                    if (this.navIntoFolderRoot == null)
                        navIntoFoldertxt = DataItemBrowserContext.NavToFolderEnum.Nav_NoAction.ToString();
                    else
                    {
                        navIntoFoldertxt = this.navIntoFolderRoot.SelectionBoxItem as string;
                        if (string.IsNullOrEmpty(navIntoFoldertxt))
                            navIntoFoldertxt = DataItemBrowserContext.NavToFolderEnum.Nav_NoAction.ToString();
                    }
                }
                if (cb != this.cbExcludeAllChildrenOfType )
                {
                    if (this.cbExcludeAllChildrenOfType == null)
                        excludeAllChildrenOfTypetxt = DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.None.ToString();
                    else
                    {
                        excludeAllChildrenOfTypetxt = this.cbExcludeAllChildrenOfType.SelectionBoxItem as string;
                        if (string.IsNullOrEmpty(excludeAllChildrenOfTypetxt))
                            excludeAllChildrenOfTypetxt = DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.None.ToString();
                    }
                }
                if (cb != this.cbExcludeAllOfType )
                {
                    if (this.cbExcludeAllOfType == null)
                        excludeAllOfTypetxt = DataItemBrowserContext.ExcludeAllOfTypeEnum.None.ToString();
                    else
                    {
                        excludeAllOfTypetxt = this.cbExcludeAllOfType.SelectionBoxItem as string;
                        if (string.IsNullOrEmpty(excludeAllOfTypetxt))
                            excludeAllOfTypetxt = DataItemBrowserContext.ExcludeAllOfTypeEnum.None.ToString();
                    }
                }
                if (cb != this.cbIncludeAllOfType )
                {
                    if (this.cbIncludeAllOfType == null)
                        includeAllOfTypetxt = DataItemBrowserContext.IncludeAllOfTypeEnum.None.ToString();
                    else
                    {
                        includeAllOfTypetxt = this.cbIncludeAllOfType.SelectionBoxItem as string;
                        if (string.IsNullOrEmpty(includeAllOfTypetxt))
                            includeAllOfTypetxt = DataItemBrowserContext.IncludeAllOfTypeEnum.None.ToString();
                    }
                }
            }
            private void ValidateDataContext(string navIntoFoldertxt, string excludeAllChildrenOfTypetxt, string excludeAllOfTypetxt,string includeAllOfTypetxt)
            {
                
             if (this.txInclude == null)
                 return;
             if (navIntoFoldertxt.Equals("Nav_IntoTags")) navIntoFoldertxt = "Nav_IntoTagsProps";
             DataItemBrowserContext.NavToFolderEnum navIntoFolder = (DataItemBrowserContext.NavToFolderEnum)Enum.Parse(typeof(DataItemBrowserContext.NavToFolderEnum), navIntoFoldertxt);
            
             
             DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum excludeAllChildrenOfType = (DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum)Enum.Parse(typeof(DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum), excludeAllChildrenOfTypetxt);
             DataItemBrowserContext.ExcludeAllOfTypeEnum excludeAllOfType = (DataItemBrowserContext.ExcludeAllOfTypeEnum)Enum.Parse(typeof(DataItemBrowserContext.ExcludeAllOfTypeEnum), excludeAllOfTypetxt);
             DataItemBrowserContext.IncludeAllOfTypeEnum includeAllOfType = (DataItemBrowserContext.IncludeAllOfTypeEnum)Enum.Parse(typeof(DataItemBrowserContext.IncludeAllOfTypeEnum), includeAllOfTypetxt);

      
             DataItemBrowserContext.CreateBuilder contextBuilder = new DataItemBrowserContext.CreateBuilder(null);
             contextBuilder.Root(this.txRoot.Text, navIntoFolder)
                              .ExcludeAllChildrenFrom(this.txExclude.Text)
                              .Include(this.txInclude.Text)
                              .ExcludeAllChildrenOfType(excludeAllChildrenOfType)
                              .ExcludeAllOfType(excludeAllOfType)
                              .IncludeAllOfType(includeAllOfType);

            
             if (this.excludeRoot.IsChecked == true)
             {
                 contextBuilder.ExcludeAllChildrenFromRoot();
             }

             contextBuilder.DisplayMetaData(this.chckDisplayMeta.IsChecked == true);

             if (!string.IsNullOrEmpty(this.txFilterType.Text))
             {
                 bool isExactMatch = false;
                 if (this.exactMatch.IsChecked == true)
                     isExactMatch = true;
                     contextBuilder.AddFilter(this.txFilterType.Text, this.txFilterValue.Text, isExactMatch);
             }
             
             this.contextResult.Visibility = Visibility.Visible;
             string imageName = "check1_16.png";
             string tooltip = string.Empty;
               DataItemBrowserContext context = contextBuilder.Build();
             if (context.SyntaxWarnings.Count > 0)
             {
                 imageName = "warning16.png";
                 foreach (string warning in context.SyntaxWarnings)
                 {
                     tooltip += warning + "\n";
                 }
                 
             }
             if (string.IsNullOrEmpty(tooltip))
                 tooltip = "Verified";
             this.contextResult.ToolTip = tooltip;
             BitmapImage image = new BitmapImage(new Uri(@"pack://application:,,,/RA.DTC.DataItemBrowser.PopupTestHost;component/" + imageName, UriKind.RelativeOrAbsolute));
             this.contextResult.Source = image;
             //display status string
             string status = string.Empty;
             if (!string.IsNullOrEmpty(this.txRoot.Text))
                 status += "Root=" + this.txRoot.Text + ", ";
             if (navIntoFolder != DataItemBrowserContext.NavToFolderEnum.Nav_NoAction)
                 status +=  navIntoFolder.ToString()+ ", ";

                if (this.excludeRoot.IsChecked == true)
                 status += "ExcludeRootChildren, ";
                //path based processing 
             if (!string.IsNullOrEmpty(this.txExclude.Text))
                 status += "ExcludeChildrenFrom=" + this.txExclude.Text + ", ";
             if (!string.IsNullOrEmpty(this.txInclude.Text))
                 status += "IncludePath=" + this.txInclude.Text + ", ";
            //filtering
             if (!string.IsNullOrEmpty(this.txFilterType.Text) || !string.IsNullOrEmpty(this.txFilterValue.Text))
             {
                 if (this.exactMatch.IsChecked == true)
                     status += "Filter=" + this.txFilterType.Text + ":\"" + this.txFilterValue.Text + "\", ";
                 else
                     status += "Filter=" + this.txFilterType.Text + ":" + this.txFilterValue.Text + ", ";
             }
            //type based processing
             if (excludeAllChildrenOfType != DataItemBrowserContext.ExcludeAllChildrenOfTypeEnum.None)
                 status += "ExcludeAllChildrenOfType:" + excludeAllChildrenOfType.ToString() + ", ";
             if (excludeAllOfType != DataItemBrowserContext.ExcludeAllOfTypeEnum.None)
                 status += "ExcludeAllOfType:" + excludeAllOfType.ToString() + ", ";
             if (includeAllOfType != DataItemBrowserContext.IncludeAllOfTypeEnum.None)
                 status += "IncludeAllOfType:" + includeAllOfType.ToString() + ", ";

             this.txStatus.Tag = status;
             this.txStatus.Text = expandButton.IsChecked==true ? status : "(OFF)";
          }
          

           private void context_TextChanged(object sender, TextChangedEventArgs e)
           {
               string navIntoFoldertxt = string.Empty;
               string excludeAllChildrenOfTypetxt = string.Empty;
               string excludeAllOfTypetxt = string.Empty;
               string includeAllOfTypetxt = string.Empty;
               GetAllSelectedComboboxItemsExcept(null, ref navIntoFoldertxt, ref excludeAllChildrenOfTypetxt, ref  excludeAllOfTypetxt, ref  includeAllOfTypetxt);
               ValidateDataContext(navIntoFoldertxt, excludeAllChildrenOfTypetxt, excludeAllOfTypetxt, includeAllOfTypetxt);
           }

           private void excludeRoot_Click(object sender, RoutedEventArgs e)
           {
               string navIntoFoldertxt = string.Empty;
               string excludeAllChildrenOfTypetxt = string.Empty;
               string excludeAllOfTypetxt = string.Empty;
               string includeAllOfTypetxt = string.Empty;
               GetAllSelectedComboboxItemsExcept(null, ref navIntoFoldertxt, ref excludeAllChildrenOfTypetxt, ref  excludeAllOfTypetxt, ref  includeAllOfTypetxt);
               ValidateDataContext(navIntoFoldertxt, excludeAllChildrenOfTypetxt, excludeAllOfTypetxt, includeAllOfTypetxt);

           }

           private void navIntoFolderRoot_SelectionChanged(object sender, SelectionChangedEventArgs e)
           {
               string navIntoFoldertxt = string.Empty;
               string excludeAllChildrenOfTypetxt = string.Empty;
               string excludeAllOfTypetxt = string.Empty;
               string includeAllOfTypetxt = string.Empty;              
               //the selectedItem must be passed in,  if you ask for SelectedItem at this point you
               //will get the last selected item.
               if (e.AddedItems.Count >0)
               {
                    ComboBoxItem selectedCB = e.AddedItems[0] as ComboBoxItem;
                    navIntoFoldertxt = selectedCB.Content as string;
               }

               GetAllSelectedComboboxItemsExcept((ComboBox)sender, ref navIntoFoldertxt, ref excludeAllChildrenOfTypetxt, ref  excludeAllOfTypetxt, ref  includeAllOfTypetxt);
               ValidateDataContext(navIntoFoldertxt, excludeAllChildrenOfTypetxt, excludeAllOfTypetxt, includeAllOfTypetxt);

 
           }

           private void excludeAllChildrenOfType_SelectionChanged(object sender, SelectionChangedEventArgs e)
           {
               string navIntoFoldertxt = string.Empty;
               string excludeAllChildrenOfTypetxt = string.Empty;
               string excludeAllOfTypetxt = string.Empty;
               string includeAllOfTypetxt = string.Empty;
               //the selectedItem must be passed in,  if you ask for SelectedItem at this point you
               //will get the last selected item.
               if (e.AddedItems.Count > 0)
               {
                   ComboBoxItem selectedCB = e.AddedItems[0] as ComboBoxItem;
                   excludeAllChildrenOfTypetxt = selectedCB.Content as string;
               }

               GetAllSelectedComboboxItemsExcept((ComboBox)sender, ref navIntoFoldertxt, ref excludeAllChildrenOfTypetxt, ref  excludeAllOfTypetxt, ref  includeAllOfTypetxt);
               ValidateDataContext(navIntoFoldertxt, excludeAllChildrenOfTypetxt, excludeAllOfTypetxt, includeAllOfTypetxt);

           }

           private void excludeAllOfType_SelectionChanged(object sender, SelectionChangedEventArgs e)
           {
               string navIntoFoldertxt = string.Empty;
               string excludeAllChildrenOfTypetxt = string.Empty;
               string excludeAllOfTypetxt = string.Empty;
               string includeAllOfTypetxt = string.Empty;
               //the selectedItem must be passed in,  if you ask for SelectedItem at this point you
               //will get the last selected item.
               if (e.AddedItems.Count > 0)
               {
                   ComboBoxItem selectedCB = e.AddedItems[0] as ComboBoxItem;
                   excludeAllOfTypetxt = selectedCB.Content as string;
               }

               GetAllSelectedComboboxItemsExcept((ComboBox)sender, ref navIntoFoldertxt, ref excludeAllChildrenOfTypetxt, ref  excludeAllOfTypetxt, ref  includeAllOfTypetxt);
               ValidateDataContext(navIntoFoldertxt, excludeAllChildrenOfTypetxt, excludeAllOfTypetxt, includeAllOfTypetxt);

           }
           private void includeAllOfType_SelectionChanged(object sender, SelectionChangedEventArgs e)
           {
               string navIntoFoldertxt = string.Empty;
               string excludeAllChildrenOfTypetxt = string.Empty;
               string excludeAllOfTypetxt = string.Empty;
               string includeAllOfTypetxt = string.Empty;
               //the selectedItem must be passed in,  if you ask for SelectedItem at this point you
               //will get the last selected item.
               if (e.AddedItems.Count > 0)
               {
                   ComboBoxItem selectedCB = e.AddedItems[0] as ComboBoxItem;
                   includeAllOfTypetxt = selectedCB.Content as string;
               }

               GetAllSelectedComboboxItemsExcept((ComboBox)sender, ref navIntoFoldertxt, ref excludeAllChildrenOfTypetxt, ref  excludeAllOfTypetxt, ref  includeAllOfTypetxt);
               ValidateDataContext(navIntoFoldertxt, excludeAllChildrenOfTypetxt, excludeAllOfTypetxt, includeAllOfTypetxt);

           }

           private void exactMatch_Click(object sender, RoutedEventArgs e)
           {
               string navIntoFoldertxt = string.Empty;
               string excludeAllChildrenOfTypetxt = string.Empty;
               string excludeAllOfTypetxt = string.Empty;
               string includeAllOfTypetxt = string.Empty;
               GetAllSelectedComboboxItemsExcept(null, ref navIntoFoldertxt, ref excludeAllChildrenOfTypetxt, ref  excludeAllOfTypetxt, ref  includeAllOfTypetxt);

               ValidateDataContext(navIntoFoldertxt, excludeAllChildrenOfTypetxt, excludeAllOfTypetxt, includeAllOfTypetxt);
           }

		   /// <summary>
		   /// Helper to processes key event args from a text box to see if some "auto complete" should be used
           /// Up arrow  and down arrow cycle through devices
           /// LeftCtrl and RightCtrl along with Up and Down arrow cycle through the current devices children: programs, datalogs
		   /// </summary>
		   /// <param name="tb">text box event came from</param>
		   /// <param name="e">key event coming from the text box</param>
		   private void HandleAutoCompleteTextBox(TextBox tb, KeyEventArgs e)
		   {
			   if (tb != null)
			   {
				   //Up and down will help user out
				   if (e.Key == Key.Up || e.Key == Key.Down)
				   {
					   //Check to see if the current project has any devices
                       ProjectFileName CurrentProj = PackageList.SelectedItem as ProjectFileName;
					   if (CurrentProj != null && CurrentProj.Devices.Count > 0)
					   {
						   //If control key is pressed, we will try to look for children of a device
						   string NextText = "";
						   if (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
						   {
							   // nextChild could be a Program, a DataLog, or eventually a Screen, or AOG
                               string nextChild = "";
							   string[] currentRoot = tb.Text.TrimStart(':').Split('\\');
							   //If the text box at least has a device name
							   if (currentRoot.Length > 0)
							   {
								   //See if the device has any children
                                   string currentChild = currentRoot.Length > 1 ? "\\" + currentRoot[1] : "";  // Add "\" back
								   if (CurrentProj.Devices.Keys.Contains(currentRoot[0]))
								   {
									   List<string> DeviceChildList = CurrentProj.Devices[currentRoot[0]];
									   bool useNext = false;
									   foreach (string child in DeviceChildList)
									   {
										   //Save the first child into next in case we are at the end of the list
										   if (nextChild == "")
											   nextChild = child;

										   //If previous loop, set useNext, then use this one and break (also do if
										   // there was no child typed yet)
										   if (useNext || currentChild == "")
										   {
											   nextChild = child;
											   break;
										   }

										   //Check to see if the current child is what is currently in the text box
										   // and if so, mark the bool that will instruct the next iteration of this
										   // loop to take that value
										   if (currentChild == child)
											   useNext = true;
									   }

									   //Set the next text
									   NextText = "::" + currentRoot[0];
									   if (nextChild != "")
										   NextText = NextText + nextChild;
								   }
								   //If the current text is not in the list of devices, control up/down should not
								   // do anything since we can't find children for the device
								   else
									   NextText = tb.Text;
							   }
						   }

						   //If no control key was used, or we couldn't find a child of the currently typed device,
						   // we'll find the next device and use it for the text box text
						   if (NextText == "")
						   {
							   int index = (tb.Tag != null) ? (int)tb.Tag + 1 : 0;
							   if (index > CurrentProj.Devices.Count - 1)
								   index = 0;
							   tb.Tag = index;
							   if (CurrentProj.Devices.Count > 0)
								   NextText = "::" + CurrentProj.Devices.Keys.ElementAt(index);
						   }

						   //Actually change the text
						   if(tb.Text != NextText)
							tb.Text = NextText;
					   }
				   }
			   }
		   }

			/// <summary>
			/// Click handler for reset to default controllers (i.e. devices) button
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void resetControllers_Click(object sender, RoutedEventArgs e)
			{
				if (File.Exists(_WELL_KNOWN_DEFAULT_CONTROLLERS_FILE) && (Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl)))
				{
					//Ctrl+Shift click should open notepad with the default file
					if (Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift))
					{
						Process openTxtProc = new Process();
						openTxtProc.StartInfo.FileName = _WELL_KNOWN_DEFAULT_CONTROLLERS_FILE;
						openTxtProc.EnableRaisingEvents = true;
						openTxtProc.Exited += new EventHandler((object pSender, EventArgs pArgs) =>
						{
							testHostMainWnd.Dispatcher.BeginInvoke(new System.Threading.ThreadStart(() =>
							{
								LoadMyDefaults();
							}));
						});
						openTxtProc.Start();
					}
					//Control click should load the defaults (since there is no longer a specific button for this)
					else
						LoadMyDefaults();
				}
				else
				{
					this.controller1Nametx.Text = "Controller1";
					this.controller1tx.Text = @"";
					this.controller2Nametx.Text = "Controller2";
					this.controller2tx.Text = @"";
					this.controller3Nametx.Text = "Controller3";
					this.controller3tx.Text = @"";
					this.controller4Nametx.Text = "Controller4";
					this.controller4tx.Text = @"";
					this.hmidevice1Nametx.Text = "HmiDevice1";
					this.hmidevice1tx.Text = @"";
				}
           }

			/// <summary>
			/// Expected path on System to TafCommand.exe
			/// </summary>
			public string TafCommandPath
			{
				get
				{
					string TafCommandDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Rockwell Automation", @"Test Automation Framework");
					return System.IO.Path.Combine(TafCommandDir, @"TAFCommand.exe");
				}
			}

			/// <summary>
			/// Expected directory on System to the generate workflow DB
			/// </summary>
			public string GenDbTafSlnDir
			{
				get
				{
					return System.IO.Path.Combine(_dirExecutable, @"GenerateDatabase");
				}
			}

			/// <summary>
			/// Helper to return whether the tools are installed on the current client which enable us to generate databases
			/// </summary>
			private bool CanGenerateDatabases()
			{
				return File.Exists(TafCommandPath) && Directory.Exists(GenDbTafSlnDir);

				//MessageBox.Show("TAF workflow does not appear to be available in the folder: \n\t" + GenDbTafSlnDir);
			}

			Process _LastTafCmdProc = null;
            string _LastGeneratedPackagePath = "";

            public string PackageDir
            {
                get
                {
                    return System.IO.Path.Combine(this.GetEnvironmentVariableRockwellDataDirectory(), _DIB_TEST_PROJECTS);
                }
            }

            public string PackageDirDesigner
            {
                get
                {
                    return System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Studio 5000", "Projects");
                }
            }

            //Helper to return a string that can be used for a package name (contains a timestamp so will be unique)
            private string GetTimeStampPackageName()
            {
                return "Project_" + DateTime.Now.ToString("s").Replace(':', '_').Replace('.', '_').Replace('-', '_');
            }

            //Removes the first empty item from the package list box if it exists (called by the package creation logic
            //after a new package is generated)
            private void RemoveFirstBlankPackageIfNeeded()
            {
                //If the first item in the list was a blank item (because the list was empty before a previous
                // db generation, remove the blank item)
                if (this.PackageList.Items.GetItemAt(0) is PackageFileName)
                {
                    if (string.IsNullOrWhiteSpace((this.PackageList.Items.GetItemAt(0) as PackageFileName).FullPath))
                        this.PackageList.Items.RemoveAt(0);
                }
                else if (this.PackageList.Items.GetItemAt(0) is ProjectFileName)
                {
                    if (string.IsNullOrWhiteSpace((this.PackageList.Items.GetItemAt(0) as ProjectFileName).FullPath))
                        this.PackageList.Items.RemoveAt(0);
                }
            }

			/// <summary>
			/// Handler for the generate database button to run a TAF workflow to generate a database
			/// </summary>
			/// <param name="sender"></param>
			/// <param name="e"></param>
			private void generateDatabase_Click(object sender, RoutedEventArgs e)
			{
				try
				{
                    //It is possible after we hide the grid that the enter key press could still call this so
                    // prevent execution if the creation grid is not visible.  Alternatively we could disable
                    // the device creation grid whenever it is collapsed, or we could ensure when the grid is
                    // collapsed focus never remains on a textbox, but this is more isolated and streamlined.
                    if (!DeviceCreationEditGrid.IsVisible)
                        return;

                    //Ensure the package directory exists (do here as opposed to initialize since we allow changing of ROCKWELL_DATA_DIRECTORY from the popup test host)
                    if (!Directory.Exists(PackageDir))
                        Directory.CreateDirectory(PackageDir);

                    TextBox activeTextBox = PackageNameTab.IsSelected ? PackageNameValue : ProjectNameValue;
                    bool createMock = ProjectNameTab.IsSelected;

                    //Provide a timestamped file name if none was typed 
                    if (String.IsNullOrWhiteSpace(activeTextBox.Text))
                        activeTextBox.Text = GetTimeStampPackageName();

                    string NewPackageExt = createMock ? ".xml" : ".VPD";
                    string NewPackageFileName = activeTextBox.Text + NewPackageExt;
                    string NewPackageDir = activeTextBox.Tag!=null ? (string)activeTextBox.Tag : PackageDir;
                    string NewPackagePathAndName = System.IO.Path.Combine(NewPackageDir, NewPackageFileName);

                    //Check if the package file already exists
                    if (File.Exists(NewPackagePathAndName))
                    {
                        //Shift should suppress the confirm package overwrite
                        if(!Keyboard.IsKeyDown(Key.LeftShift) && !Keyboard.IsKeyDown(Key.RightShift))
                        {
                            if (createMock)
                            {
                                //if we're creating a mock xml file, prompt to continue
                                if (MessageBox.Show("Project already exists.\n\nDo you want to overwrite it?", "Project already exists", MessageBoxButton.YesNo) == MessageBoxResult.No)
                                    return;
                            }
                            else
                            {
                                //return if file already exists (if we wanted to extend this to allow overwrite, we would need to check to see if the package
                                // is open because deleting an open package will fail during the package manager create package
                                MessageBox.Show("Package already exists.  Choose a different name or delete the existing file.\n\nNote: Ensure the package is closed before you delete it.", "Package already exists", MessageBoxButton.OK);
                                return;
                            }
                        }

                        File.Delete(NewPackagePathAndName);
                    }

                    //All we have to do if we're creating a mock file is write an XML file out.  So just create it and set it to the selected item
                    if (createMock)
                    {
                        CreateMockDataSourcesXmlFile(NewPackagePathAndName, new Tuple<TextBox, TextBox, string>(controller1Nametx, controller1tx, "controller"),
                                                                            new Tuple<TextBox, TextBox, string>(controller2Nametx, controller2tx, "controller"),
                                                                            new Tuple<TextBox, TextBox, string>(controller3Nametx, controller3tx, "controller"),
                                                                            new Tuple<TextBox, TextBox, string>(controller4Nametx, controller4tx, "controller"),
                                                                            new Tuple<TextBox, TextBox, string>(hmidevice1Nametx, hmidevice1tx, "hmi"));

                        RemoveFirstBlankPackageIfNeeded();

                        //Check / remove any duplicates (since we allow overwriting of project (mock) files
                        foreach (object curItem in this.PackageList.Items)
                        {
                            if (string.Equals(NewPackagePathAndName, GetProjectListItemFullPath(curItem), StringComparison.CurrentCultureIgnoreCase))
                            {
                                this.PackageList.Items.Remove(curItem);
                                break;
                            }
                        }

                        //Add and select the newly created package
                        this.PackageList.Items.Insert(0, new ProjectFileName(NewPackagePathAndName));
                        this.PackageList.SelectedIndex = 0;
                        return;
                    }

                    //Prevent re-entry
                    DeviceCreationEditGrid.IsEnabled = false;

                    //Make calls to create the package (which will implicitly open it)
                    UUID NewPackageId = PackageManagerHelper.Instance().CreatePackage(NewPackagePathAndName);
                    if (NewPackageId != null)
                    {
                        UUID NewProjectId = PackageManagerHelper.Instance().CreateProjectDbInPackage(NewPackageId);
                        if (NewProjectId != null)
                        {
                            PackageManagerHelper.Instance().SavePackage(NewPackageId);

                            PackageFileName NewPackageFile = new PackageFileName(NewPackagePathAndName, NewPackageId, NewProjectId);

                            RemoveFirstBlankPackageIfNeeded();

                            //Insert at top since newest files are shown at top
                            this.PackageList.Items.Insert(0, NewPackageFile);
                            this.PackageList.SelectedItem = NewPackageFile;

                            if (CanGenerateDatabases())
                            {
                                string BinDir = System.IO.Path.Combine(this.GetEnvironmentVariableRockwellDataDirectory(), @"bin");

                                //Allow shift-click to bypass project service check
                                if (!Keyboard.IsKeyDown(Key.LeftShift) && !Keyboard.IsKeyDown(Key.RightShift))
                                {
                                    //Check for project services running (this will work regardless if it was run as an exe or installed as a service)
                                    Process[] RSPSprocs = Process.GetProcessesByName("RSL5KProjectServices");
                                    if (RSPSprocs.Length == 0)
                                    {
                                        //If we wanted to check if RSPS is installed as a service, we could use the code below.  For now, we'll
                                        // simply run as an EXE
                                        //var RSPSservice = ServiceController.GetServices().FirstOrDefault(s => s.ServiceName == "RSL5KProjectService");
                                        //if (RSPSservice != null && !RSPSservice.Status.Equals(ServiceControllerStatus.Running))
                                        //	RSPSservice.Start();

                                        Process NewProc = PromptToStart("RSL5KProjectServices", BinDir, "RSL5KProjectServices.exe", "--exe");
                                        if (NewProc == null)
                                            return;
                                        Thread.Sleep(1000); //give some time for the new project services exe to register
                                    }
                                }

                                //Establish our file names
                                string devicesFileName = "DevicesToGenerate.txt";
                                string devicesFileResultName = "DevicesToGenerate.result.txt";
                                string devicesFileOutputName = "DevicesToGenerate.output.log";
                                string devicesFilePath = System.IO.Path.Combine(PackageDir, devicesFileName);
                                string devicesFlesResultPath = System.IO.Path.Combine(PackageDir, devicesFileResultName);
                                string devicesFlesOutputPath = System.IO.Path.Combine(PackageDir, devicesFileOutputName);

                                //Delete any previous results / output file (or creates the file for the first time)
                                File.Delete(devicesFlesResultPath);
                                File.Delete(devicesFlesOutputPath);

                                //Generate the devices file based on the popup test host input fields
                                StreamWriter DeviceGenFileStream = new StreamWriter(devicesFilePath, false);
                                DeviceGenFileStream.WriteLine("type,path,name"); //this would only change if the workflow changes
                                if (!string.IsNullOrWhiteSpace(controller1Nametx.Text) && !string.IsNullOrWhiteSpace(controller1tx.Text))
                                    DeviceGenFileStream.WriteLine("controller," + controller1tx.Text + "," + controller1Nametx.Text);
                                if (!string.IsNullOrWhiteSpace(controller2Nametx.Text) && !string.IsNullOrWhiteSpace(controller2tx.Text))
                                    DeviceGenFileStream.WriteLine("controller," + controller2tx.Text + "," + controller2Nametx.Text);
                                if (!string.IsNullOrWhiteSpace(controller3Nametx.Text) && !string.IsNullOrWhiteSpace(controller3tx.Text))
                                    DeviceGenFileStream.WriteLine("controller," + controller3tx.Text + "," + controller3Nametx.Text);
                                if (!string.IsNullOrWhiteSpace(controller4Nametx.Text) && !string.IsNullOrWhiteSpace(controller4tx.Text))
                                    DeviceGenFileStream.WriteLine("controller," + controller4tx.Text + "," + controller4Nametx.Text);
                                if (!string.IsNullOrWhiteSpace(hmidevice1Nametx.Text) && !string.IsNullOrWhiteSpace(hmidevice1tx.Text))
                                    DeviceGenFileStream.WriteLine("terminal," + hmidevice1tx.Text + "," + hmidevice1Nametx.Text);
                                DeviceGenFileStream.Close();

                                //Set the initial controls before db gen starts
                                ProcessGenerateDbResults();

                                //Start the TAF workflow
                                Process tafCmd = new Process();
                                _LastTafCmdProc = tafCmd;
                                tafCmd.StartInfo.FileName = TafCommandPath;
                                tafCmd.StartInfo.WindowStyle = ProcessWindowStyle.Hidden;
                                tafCmd.StartInfo.WorkingDirectory = Environment.CurrentDirectory;
                                tafCmd.StartInfo.Arguments = "/r \"" + GenDbTafSlnDir + "\\tafsolution.taf\" /LM 4 /CL \"" + PackageDir + "\\log.xml\" /VAR:packageFile \"" + NewPackagePathAndName + "\" /VAR:deviceFile \"" + devicesFilePath + "\"";

                                tafCmd.StartInfo.UseShellExecute = false;
                                tafCmd.StartInfo.CreateNoWindow = true;
                                tafCmd.StartInfo.RedirectStandardOutput = true;
                                tafCmd.Start();
                                tafCmd.BeginOutputReadLine();

                                //Save the output of the TAF workflow to a file just in case we want to see the activity log
                                tafCmd.OutputDataReceived += new DataReceivedEventHandler((object drSender, DataReceivedEventArgs drArgs) =>
                                {
                                    File.AppendAllText(devicesFlesOutputPath, drArgs.Data + "\r\n");
                                });

                                //Setup file system watcher for the results file result
                                FileSystemWatcher ResultsWatcher = new FileSystemWatcher(PackageDir, devicesFileResultName);
                                ResultsWatcher.Changed += new FileSystemEventHandler((object rwSender, FileSystemEventArgs rwArgs) =>
                                {
                                    controller1Nametx.Dispatcher.BeginInvoke(new System.Threading.ThreadStart(() =>
                                    {
                                        string[] ResultsFileLines = File.ReadAllLines(rwArgs.FullPath);
                                        ProcessGenerateDbResults(ResultsFileLines);
                                    }));
                                });
                                ResultsWatcher.EnableRaisingEvents = true;
                            }
                            else
                            {
                                MessageBox.Show("Devices could not be added to package.\n\nTAF does not appear to be installed.  Looking for:\n\t" + TafCommandPath, "TAF not found");

                                //Ensure the package list is disabled (while a package is open)
                                PackageList.IsEnabled = false;
                            }
                        }
                        else
                        {
                            //Re-enable grid on error
                            DeviceCreationEditGrid.IsEnabled = true;
                        }
                    }
                    else
                    {
                        //Re-enable grid on error
                        DeviceCreationEditGrid.IsEnabled = true;

                        MessageBox.Show("There was an error creating a new package.", "Package Create Failed");
                    }					
			   }
			   catch (Exception ex)
			   {
				   Console.WriteLine(ex.Message);
			   }
		   }

            //Helper to create the mock data sources file - returns the name of the created XML file
            private void CreateMockDataSourcesXmlFile(string fileName, params Tuple<TextBox, TextBox, string>[] mockDataSources)
            {
                StringBuilder MockXmlContentBuilder = new StringBuilder();
                MockXmlContentBuilder.AppendLine("<?xml version=\"1.0\" ?>");
                MockXmlContentBuilder.AppendLine("<!--");
                MockXmlContentBuilder.AppendLine("    Copyright 2013 Rockwell Automation Technologies, Inc.");
                MockXmlContentBuilder.AppendLine("");
                MockXmlContentBuilder.AppendLine("    Device Resource instance file for the Mock Query Session service.");
                MockXmlContentBuilder.AppendLine("    This file specifies the Devices contained within the project (database).");
                MockXmlContentBuilder.AppendLine("--> ");
                MockXmlContentBuilder.AppendLine("<Resources>");
                foreach (Tuple<TextBox, TextBox, string> curDataSource in mockDataSources)
                {
                    TextBox curNameTextBox  = curDataSource.Item1;
                    TextBox curValueTextBox = curDataSource.Item2;

                    if (!string.IsNullOrWhiteSpace(curNameTextBox.Text) && !string.IsNullOrWhiteSpace(curValueTextBox.Text))
                    {
                        bool isHMI = curDataSource.Item3 == "hmi";
                        string NodeName = isHMI ? "HMI" : "Controller";

                        MockXmlContentBuilder.Append("   <");
                        MockXmlContentBuilder.Append(NodeName);
                        MockXmlContentBuilder.Append(" name=\"");
                        MockXmlContentBuilder.Append(curNameTextBox.Text);
                        MockXmlContentBuilder.Append("\" ");
                        MockXmlContentBuilder.Append("path=\"");
                        if(isHMI)
                            MockXmlContentBuilder.Append(curValueTextBox.Text); //ip address needs no manipulation
                        else
                            MockXmlContentBuilder.Append(System.IO.Path.Combine(System.IO.Path.GetDirectoryName(curValueTextBox.Text), System.IO.Path.GetFileNameWithoutExtension(curValueTextBox.Text)));
                        MockXmlContentBuilder.AppendLine("\" />");
                    }
                }

                MockXmlContentBuilder.AppendLine("</Resources>");

                File.WriteAllText(fileName, MockXmlContentBuilder.ToString());
            }

            //Enter in the project/package name value textbox should "click" the create button
            private void FileNameValue_KeyDown(object sender, KeyEventArgs e)
            {
                if (e.Key == Key.Enter)
                {
                    generateDatabase.RaiseEvent(new RoutedEventArgs(Button.ClickEvent, generateDatabase));
                    e.Handled = true;   
                }
                else if (sender == ProjectNameValue)
                {
                    if(e.Key == Key.Up || e.Key == Key.Down)
                    {
                        _lastAutoCompleteIndex += (e.Key == Key.Up) ? -1 : 1;
                        if(_lastAutoCompleteIndex<0)
                            _lastAutoCompleteIndex = 0;

                        var a = from object c in this.PackageList.Items where GetProjectListItemFullPath(c).ToLower().EndsWith(".xml") select c;
                        int index = _lastAutoCompleteIndex % a.Count();
                        string fullPath = GetProjectListItemFullPath(a.ElementAt(index));
                        ProjectNameValue.Text = System.IO.Path.GetFileNameWithoutExtension(fullPath);
                        ProjectNameValue.Tag = System.IO.Path.GetDirectoryName(fullPath);
                        e.Handled = true;
                    }
                    else
                    {
                        ProjectNameValue.Tag = null;
                    }
                }
            }
            private int _lastAutoCompleteIndex = 0;

			/// <summary>
			/// Update UI based on a results file having been updated from the generate database TAF workflow running
			/// </summary>
			/// <param name="resultLines">The lines as parsed from the TAF workflow result file</param>
			private void ProcessGenerateDbResults(string[] resultLines=null, bool workflowActive = true)
			{
				TextBox[] DeviceTexts = { controller1Nametx, controller2Nametx, controller3Nametx, controller4Nametx, hmidevice1Nametx };

				this.Cursor = workflowActive ? Cursors.AppStarting : null;

				if (resultLines == null)
				{
					foreach (TextBox deviceTb in DeviceTexts)
					{
						deviceTb.FontWeight = FontWeights.Normal;
						deviceTb.Foreground = workflowActive ? System.Windows.Media.Brushes.Gray : System.Windows.Media.Brushes.Black;
						deviceTb.ToolTip = null;
					}
				}
				else
				{
					string PackagePath = resultLines[0];
					//In a cancel case, we need to use the previously cached value for project ID
                    if (PackagePath == "STOP")
                        PackagePath = _LastGeneratedPackagePath;
					else
                        _LastGeneratedPackagePath = PackagePath;

					foreach (string line in resultLines)
					{
						string stateResult = line.Substring(line.LastIndexOf(',') + 1);
						foreach (TextBox deviceTb in DeviceTexts)
						{
							if (line.StartsWith(deviceTb.Text))
							{
								deviceTb.FontWeight = FontWeights.Bold;
								if (stateResult != "")
								{
									deviceTb.Foreground = stateResult == "SYNCHED" ? System.Windows.Media.Brushes.Green : System.Windows.Media.Brushes.Red;
									deviceTb.ToolTip = stateResult;
								}
							}
						}
					   
						if (line=="OK" || line=="ERROR" || line=="STOP")
						{
							foreach (TextBox deviceTb in DeviceTexts)
								if (deviceTb.Foreground == System.Windows.Media.Brushes.Gray)
									deviceTb.Foreground = System.Windows.Media.Brushes.Black;

                            bool createOK = line == "OK";
                            //If all is okay, disable the package list since the package is open
                            if (createOK)
                            {
                                PackageList.IsEnabled = false;
                                PackageOpenButton_Click(null, null);
                            }
                            //Update controls (since initially the package list selection change was ignored
                            // because the package was being created)
                            bool fromFailedCreate = !createOK;
                            UpdateControlsFromPackageListSelection(false, fromFailedCreate);

                            //Null out the last taf cmd member var
                            _LastTafCmdProc = null;

							//Re-enable edits
							DeviceCreationEditGrid.IsEnabled = true;
						   
							//Restore a normal cursor
							this.Cursor = null;
						}
					}
				}
			}
        
			/// <summary>
			/// LoadMyDefaults
			/// 
			/// Reads a specific file (MyDefaultControllers.txt) to populate the controller entries
			/// The file must be a .txt up to four lines containing comma delimited values for controller name, and location
			/// 
			/// Example:
			///      test_30_tags,C:\RSLogix 5000\Projects\test_30_tags.ACD
			///      StructuresArraysBits,C:\RSLogix 5000\Projects\StructuresArraysBits.ACD
			///      test_structured_tags_1,C:\RSLogix 5000\Projects\test_structured_tags_1.ACD
			///      test_lots_of_tags,C:\RSLogix 5000\Projects\test_lots_of_tags.ACD
			///      
			/// </summary>
            private void LoadMyDefaults()
            {
				StreamReader srMyDefaultsFile = new StreamReader(_WELL_KNOWN_DEFAULT_CONTROLLERS_FILE);
				if (null != srMyDefaultsFile)
				{
					int nLineNbr = 0;
					string currentLine;
					while (!srMyDefaultsFile.EndOfStream)
					{
						currentLine = srMyDefaultsFile.ReadLine();
						string[] tokens = currentLine.Split(',');

						if (tokens[0].Equals("@BrowserType"))
						{
							this.BrowserType = tokens[1];

							if (this.BrowserType.Equals("Tag"))
								TagBrowserButton.IsChecked = true;
							else if (this.BrowserType.Equals("DataType"))
								DataTypeBrowserButton.IsChecked = true;
						}
                        else if (tokens[0].Equals("@SelectedItem") || tokens[0].Equals("@ElementValue"))
						{
                            string elementName = tokens[1];
                            string elementValue = String.Join(",", tokens.Skip(2).ToArray());
							
                            //Handle text boxes
                            TextBox txt = this.FindName(elementName) as TextBox;
							if(txt!=null)
                                txt.Text = elementValue;
                            else
                            {
                                //Handle combo boxes
                                ComboBox box = this.FindName(elementName) as ComboBox;
                                if (box != null)
                                {
                                    if (string.IsNullOrWhiteSpace(elementValue))
                                        box.SelectedIndex = 0;
                                    else
                                    {
                                        foreach (ComboBoxItem item in box.Items)
                                        {
                                            if ((item.Content as string) == elementValue)
                                            {
                                                box.SelectedItem = item;
                                                break;
                                            }
                                        }
                                    }
                                }
                                //Handle check boxes
                                else
                                {
                                    CheckBox check = this.FindName(elementName) as CheckBox;
                                    if (check != null)
                                    {
                                        check.IsChecked = elementValue == "1" || elementValue.ToLower() == "true";
                                    }
                                }
                            }
						}
                        else if (tokens[0].Equals("@ShowDataContext"))
                        {
                            if (tokens[1] == "1")
                                expandButton.IsChecked = true;
                        }
                        else if(tokens[0].Equals("@ViewProject"))
                        {
                            string packagePath = tokens[1];
                            if (!string.IsNullOrWhiteSpace(packagePath))
                            {
                                bool validPackage = false;
                                PackageFileName firstPackage = null;
                                
                                foreach (object curObj in this.PackageList.Items)
                                {
                                    if (firstPackage == null && curObj is PackageFileName)
                                        firstPackage = curObj as PackageFileName;

                                    if (packagePath == "invalid")
                                        break;

                                    string curFullPath = GetProjectListItemFullPath(curObj);

                                    if (curFullPath == _NEW_DB_TEXT)
                                        break;

                                    if (curFullPath.ToLower().Contains(packagePath.ToLower()))
                                    {
                                        this.PackageList.SelectedItem = curObj;
                                        validPackage = true;
                                        break;
                                    }
                                }

                                //Add invalid package file if we hadn't already
                                if (validPackage == false)
                                {
                                    UUID ZeroUUID = UUID.CreateBuilder().SetHi(0).SetLo(0).Build();
                                    UUID PackageID = null;
                                    UUID ProjectID = null;
                                    if(tokens.Count() > 2 && tokens[2] == "1")
                                        PackageID = ZeroUUID;
                                    if (tokens.Count() > 3 && tokens[3] == "1")
                                        ProjectID = ZeroUUID;

                                    if (firstPackage == null || firstPackage.FullPath != _INVALID_DB_TEXT)
                                    {
                                        this.PackageList.Items.Insert(0, new PackageFileName(_INVALID_DB_TEXT, PackageID, ProjectID));
                                        this.PackageList.SelectedIndex = 0;
                                    }
                                    else if (((firstPackage.PackageId == null && PackageID !=null) || (firstPackage.PackageId != null && PackageID==null)) ||
                                             ((firstPackage.ProjectId == null && ProjectID !=null) || (firstPackage.ProjectId != null && ProjectID==null)))
                                    {
                                        this.PackageList.Items.Insert(0, new PackageFileName(_INVALID_DB_TEXT, PackageID, ProjectID));
                                        this.PackageList.Items.RemoveAt(1);
                                        this.PackageList.SelectedIndex = 0;
                                    }
                                }
                            }
                        }

                        if (tokens[0].StartsWith("@"))
                            continue;
                        
                        nLineNbr++;
						if (nLineNbr == 1)
						{
							this.controller1Nametx.Text = tokens[0];
							this.controller1tx.Text = tokens[1];
						}
						else if (nLineNbr == 2)
						{
							this.controller2Nametx.Text = tokens[0];
							this.controller2tx.Text = tokens[1];
						}
						else if (nLineNbr == 3)
						{
							this.controller3Nametx.Text = tokens[0];
							this.controller3tx.Text = tokens[1];
						}
						else if (nLineNbr == 4)
						{
							this.controller4Nametx.Text = tokens[0];
							this.controller4tx.Text = tokens[1];
						}
						else if (nLineNbr == 5)
						{
							this.hmidevice1Nametx.Text = tokens[0];
							this.hmidevice1tx.Text = tokens[1];
						}
					}
					srMyDefaultsFile.Close();
				}
			}

            //Helper to return the full path of the passed item as found in the project list combo box
            // since it can be multiple object types
            private string GetProjectListItemFullPath(object projectListItem)
            {
                string fullPath = "";

                if (projectListItem is PackageFileName)
                    fullPath = (projectListItem as PackageFileName).FullPath;
                else if (projectListItem is ProjectFileName)
                    fullPath = (projectListItem as ProjectFileName).FullPath;

                return fullPath;
            }

            private void expandButton_Checked(object sender, RoutedEventArgs e)
            {
                ToggleButton tb = sender as ToggleButton;
                if (tb.IsChecked == true)
                {
                    DataContextGrid.Visibility = Visibility.Visible;
                    this.txStatus.Text = this.txStatus.Tag!=null ? (string)this.txStatus.Tag : "";
                }
                else
                {
                    DataContextGrid.Visibility = Visibility.Collapsed;
                    this.txStatus.Tag = this.txStatus.Text;
                    this.txStatus.Text = "(OFF)";
                }
            }

            //Handler for keydown to provide some keyboard shortcut functionality
            private void testHostMainWnd_KeyDown(object sender, KeyEventArgs e)
            {
                if(Keyboard.IsKeyDown(Key.LeftCtrl) || Keyboard.IsKeyDown(Key.RightCtrl))
                {
                    //Ctrl+N should display the new data base creation pane (if possible)
                    // do so by changing the package list selected item
                    if (e.Key == Key.N && PackageList.IsEnabled)
                    {
                        object lastObj = PackageList.Items[PackageList.Items.Count - 1];
                        if (lastObj is PackageFileName)
                        {
                            PackageFileName lastPackageName = lastObj as PackageFileName;
                            if (lastPackageName.FullPath == _NEW_DB_TEXT)
                            {
                                if (PackageList.SelectedItem != lastPackageName)
                                    PackageList.SelectedItem = lastPackageName;
                            }
                        }
                    }
                    //Ctrl+S should save all data to the my default controllers file
                    else if (e.Key == Key.S)
                    {
                        SaveTestHostData();
                        e.Handled = true;
                    }
                    //Ctrl+L should load all data from the my defaults controllers file
                    else if (e.Key == Key.L)
                    {
                        if (File.Exists(_WELL_KNOWN_DEFAULT_CONTROLLERS_FILE))
                        {
                            LoadMyDefaults();
                            e.Handled = true;
                        }
                    }
                    //Ctrl+E should show an explorer window to the current project directory
                    else if (e.Key == Key.E)
                    {
                        ShowProjectFolder();
                        e.Handled = true;
                    }
                    //Ctrl+R should refresh the package list box
                    else if (e.Key == Key.R)
                    {
                        PopulatePackageListBox();
                        LoadMyDefaults();
                        e.Handled = true;
                    }
                    //Ctrl+D should activate an open DIB window
                    else if (e.Key == Key.D)
                    {
                        Window DibWindow = GetOpenDibWindow();
                        if (DibWindow != null)
                        {
                            DibWindow.Activate();
                            e.Handled = true;
                        }
                    }
                    //Ctrl+D should clear all data context values
                    else if (e.Key == Key.K)
                    {
                        ClearDataContextValues();
                        e.Handled = true;
                    }
                    //Ctrl+H should clear the last highlighted item
                    else if (e.Key == Key.H)
                    {
                        ClearLastHighlightedItem();
                        e.Handled = true;
                    }
                    //Ctrl+M should clear the search MRU list history
                    else if (e.Key == Key.M)
                    {
                        ClearSearchMRUListHistory();
                        e.Handled = true;
                    }
                }
            }

        /// <summary>
        /// Writes a settings file based on the current values/selections of the popup test host window
        /// </summary>
        /// <returns>true if the file was saved</returns>
        private bool SaveTestHostData()
        {
            bool saved = false;

            string pathFile = System.IO.Path.Combine(_dirExecutable, _WELL_KNOWN_DEFAULT_CONTROLLERS_FILE);
            bool shiftKeyDown = Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift);

            if (!File.Exists(pathFile) || MessageBox.Show("Save popup test host settings?", "Save Settings", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                List<string> DefaultLines = new List<string>();
                if (!string.IsNullOrWhiteSpace(this.controller1Nametx.Text))
                    DefaultLines.Add(this.controller1Nametx.Text + "," + this.controller1tx.Text);
                if (!string.IsNullOrWhiteSpace(this.controller2Nametx.Text))
                    DefaultLines.Add(this.controller2Nametx.Text + "," + this.controller2tx.Text);
                if (!string.IsNullOrWhiteSpace(this.controller3Nametx.Text))
                    DefaultLines.Add(this.controller3Nametx.Text + "," + this.controller3tx.Text);
                if (!string.IsNullOrWhiteSpace(this.controller4Nametx.Text))
                    DefaultLines.Add(this.controller4Nametx.Text + "," + this.controller4tx.Text);
                if (!string.IsNullOrWhiteSpace(this.hmidevice1Nametx.Text))
                    DefaultLines.Add(this.hmidevice1Nametx.Text + "," + this.hmidevice1tx.Text);

                PackageFileName CurProject = this.PackageList.SelectedItem as PackageFileName;
                string ProjectPath = CurProject != null ? CurProject.FullPath.ToLower() : "";
                string invalidSuffix = "";
                if (CurProject.FullPath == _INVALID_DB_TEXT)
                    invalidSuffix = string.Format(",{0},{1}", (CurProject.PackageId == null ? "0" : "1"), (CurProject.ProjectId == null ? "0" : "1"));
                DefaultLines.Add("@ViewProject," + ProjectPath + invalidSuffix);

                DefaultLines.Add("@ShowDataContext," + (expandButton.IsChecked.GetValueOrDefault(false) ? "1" : "0"));

                bool PackageOpen = HasOpenPackage;

                DefaultLines.Add("@BrowserType," + (PackageOpen ? this.BrowserType : ""));
                DefaultLines.Add("@SelectedItem,txReadTag," + (PackageOpen ? txReadTag.Text : ""));
                DefaultLines.Add("@SelectedItem,txWriteTag," + (PackageOpen ? txWriteTag.Text : ""));
                DefaultLines.Add("@SelectedItem,txDataType1," + (PackageOpen ? txDataType1.Text : ""));
                DefaultLines.Add("@SelectedItem,txDataType2," + (PackageOpen ? txDataType2.Text : ""));

                List<Tuple<string, string>> DataContextInfo = new List<Tuple<string, string>>();
                GetDataContextElementInfo(DataContextInfo);
                foreach (Tuple<string, string> fieldInfo in DataContextInfo)
                {
                    string fieldName = fieldInfo.Item1;
                    string fieldValue = fieldInfo.Item2;
                    DefaultLines.Add(string.Format("@ElementValue,{0},{1}", fieldName, fieldValue));
                }

                File.WriteAllLines(pathFile, DefaultLines);

                saved = true;
            }
            
            //Shift should open the defaults file
            if (shiftKeyDown)
            {
                OpenTxtFileWithCallback(pathFile, () =>
                {
                    LoadMyDefaults();
                });
            }

            return saved;
        }

        /// <summary>
        /// Code to handle commands for the context menu items
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            MenuItem item = sender as MenuItem;
            if(item!=null)
            {
                string menuId = item.Tag as string;
                if(menuId=="save")
                {
                    SaveTestHostData();
                    e.Handled = true;
                }
                else if(menuId=="load")
                {
                    if (File.Exists(_WELL_KNOWN_DEFAULT_CONTROLLERS_FILE))
                    {
                        LoadMyDefaults();
                        e.Handled = true;
                    }
                }
                else if (menuId == "open_project_folder")
                {
                    ShowProjectFolder();
                }
                else if (menuId == "refresh_package_list")
                {
                    PopulatePackageListBox();
                    LoadMyDefaults();
                }
                else if (menuId.StartsWith("error"))
                {
                    if (menuId == "errorTimeout")
                    {
                        ClientDataServices.ForceProblemType(item.IsChecked ? ProblemInfoType.ResourceServiceTimeout : ProblemInfoType.NoProblem);
                    }
                    else if (menuId == "errorResponse")
                    {
                        ClientDataServices.ForceProblemType(item.IsChecked ? ProblemInfoType.ResourceServiceError : ProblemInfoType.NoProblem);
                    }

                    //Uncheck the other items
                    foreach (MenuItem curMenuItem in (item.Parent as MenuItem).Items)
                        if (curMenuItem != item)
                            curMenuItem.IsChecked = false;

                    e.Handled = true;
                }
                else if (menuId == "showDIB")
                {
                    Window DibWindow = GetOpenDibWindow();
                    if (DibWindow != null)
                    {
                        DibWindow.Activate();
                        e.Handled = true;
                    }
                }
                else if (menuId == "clear_data_context")
                {
                    ClearDataContextValues();
                }
                else if (menuId == "clear_last_highlighted_item")
                {
                    ClearLastHighlightedItem();
                }
                else if (menuId == "clear_search_mru_list_history")
                {
                    ClearSearchMRUListHistory();
                }
            }
        }

        /// <summary>
        /// Helper to get the names (i.e. XAML keys) and values of all the elements that comprise the data context fields
        /// </summary>
        /// <param name="DataContextFieldInfo">Array containing tuple of name/value for each data context field</param>
        /// <param name="parent">Used internally for recursion, should be null when called initially</param>
        private void GetDataContextElementInfo(List<Tuple<string, string>> DataContextFieldInfo, Panel parent = null)
        {
            UIElementCollection childElements = parent != null ? parent.Children : DataContextGrid.Children;
            foreach (FrameworkElement dcChild in childElements)
            {
                //Skip things that are hidden in the UI
                if (dcChild.Visibility != System.Windows.Visibility.Visible)
                    continue;

                if (dcChild is TextBox)
                {
                    DataContextFieldInfo.Add(new Tuple<string, string>(dcChild.Name, (dcChild as TextBox).Text));
                }
                else if (dcChild is ComboBox)
                {
                    DataContextFieldInfo.Add(new Tuple<string, string>(dcChild.Name, ((dcChild as ComboBox).SelectedValue as ComboBoxItem).Content as string));
                }
                else if (dcChild is CheckBox)
                {
                    DataContextFieldInfo.Add(new Tuple<string, string>(dcChild.Name, (dcChild as CheckBox).IsChecked.ToString()));
                }
                else if (dcChild is TabControl)
                {
                    foreach (TabItem ti in (dcChild as TabControl).Items)
                    {
                        GetDataContextElementInfo(DataContextFieldInfo, ti.Content as Grid);
                    }
                }
            }
        }

        /// <summary>
        /// Helper to clear all fields nested in the data context grid
        /// </summary>
        private void ClearDataContextValues(Panel parent = null)
        {
            List<Tuple<string, string>> DataContextInfo = new List<Tuple<string, string>>();
            GetDataContextElementInfo(DataContextInfo);

            foreach (Tuple<string, string> fieldInfo in DataContextInfo)
            {
                string fieldName = fieldInfo.Item1;
                UIElement dcChild = FindName(fieldName) as UIElement;
                if (dcChild is TextBox)
                {
                    (dcChild as TextBox).Text = string.Empty;
                }
                else if (dcChild is ComboBox)
                {
                    (dcChild as ComboBox).SelectedIndex = 0;
                }
                else if (dcChild is CheckBox)
                {
                    (dcChild as CheckBox).IsChecked = false;
                }
            }
        }

        private void LocaleSelection_Selected(object sender, RoutedEventArgs e)
        {
            ComboBox box = (ComboBox)sender;
            ComboBoxItem item = (ComboBoxItem)box.SelectedValue;
            string localeId = item.Name;
            localeId = localeId.Replace("_", "-");
            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = new System.Globalization.CultureInfo(localeId);
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = new System.Globalization.CultureInfo(localeId);
        }

        //Helper to clear out the last highlighted item of all browsers
        private void ClearLastHighlightedItem()
        {
            PropertyEditorWithTagBrowser[] browsers = { PropertyEditWithTB1, PropertyEditWithTB2, PropertyEditWithDataType_1, PropertyEditWithDataType_2 };
            foreach (PropertyEditorWithTagBrowser browser in browsers)
            {
                browser.ClearLastHighlightedItemInfo();
            }
        }

        //Helper to clear the search MRU list history of all browsers
        private void ClearSearchMRUListHistory()
        {
            PropertyEditorWithTagBrowser[] browsers = { PropertyEditWithTB1, PropertyEditWithTB2, PropertyEditWithDataType_1, PropertyEditWithDataType_2 };
            foreach (PropertyEditorWithTagBrowser browser in browsers)
            {
                browser.ClearSearchMRUListHistory();
            }
        }
        

        //Handler for Ctrl+E / context menu to show the current project directory in explorer
        private void ShowProjectFolder()
        {
            string FullPath = GetProjectListItemFullPath(this.PackageList.SelectedItem);
            string Dir = string.IsNullOrWhiteSpace(FullPath) ? ((Keyboard.IsKeyDown(Key.LeftShift) || Keyboard.IsKeyDown(Key.RightShift)) ? PackageDirDesigner : PackageDir) : System.IO.Path.GetDirectoryName(FullPath);
            OpenFolderViaWinExplorer(Dir);
        }

        //Clicking on a tab in the project/package creation grid (real tab or mock tab)
        private void FileNameTab_MouseUp(object sender, MouseButtonEventArgs e)
        {
            SelectAndFocusActiveFileNameTextbox();
        }

        //Handler for the clear last highlighted item button
        private void ClearLastHighLightedItemButton_Click(object sender, RoutedEventArgs e)
        {
            ClearLastHighlightedItem();
        }

        //Handler for the clear search MRU list button
        private void ClearSearchMruList_Click(object sender, RoutedEventArgs e)
        {
            ClearSearchMRUListHistory();
        }
    }


    /// <summary>
    /// This converter maintains the last two Highlighted items, one for the DIB and one for the DTB.
    /// The BrowserType determines which value to store and return.  The highlighted items are stored in local strings.
    /// When the BrowserType changes, the result of the converter is the remembered path.
    /// NOTE: This is only for debug purposes.
    /// </summary>
    public class BrowserTypeAndHighlightedConverter : IMultiValueConverter
    {
        private static string _last_DTB_HighlightedItem = string.Empty;
        private static string _last_DIB_HighlightedItem = string.Empty;
        private static string _last_BrowserType = string.Empty;

        /// <summary>
        /// When the project changes clear out the remembered highlighted items
        /// </summary>
        public static void Clear()
        {
            _last_DTB_HighlightedItem = string.Empty;
            _last_DIB_HighlightedItem = string.Empty;
            _last_BrowserType = string.Empty;
        }

       
        #region IMultiValueConverter Members

        /// <summary>
        /// If the BrowserType has changed then return the last Highlighted item for that browser's personality.
        /// If the BrowserType has not changed, then the converter was invoked by a change in the highlighted item. Store this value.
        /// </summary>
        /// <param name="values">Browser Type and HighlightedItem path</param>
        /// <param name="targetType"></param>
        /// <param name="parameter">not used</param>
        /// <param name="culture"></param>
        /// <returns>The Highlighted Item string</returns>
        public object Convert(object[] values, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            // Having these first two clauses help us avoid designer load errors
            if (values == null || values.Length < 2)
                return "<Converter: value array is null or has too few elements>";
            if (!(values[0] is string) || !(values[1] is string))
                return "<Converter: one of the array values is not the right type>";

            string browserType = (string)values[0];
            string highlightedItem = (string)values[1];
            string results = highlightedItem;
            
            // Has the browser type changed?  If so then
            // restore the last HighlightedItem's path.
            if (_last_BrowserType != browserType)
            {
                switch (browserType)
                {
                    case "Tag": // DIResource.DI_COMMON_RESOURCETYPE_TAG
                        results = _last_DIB_HighlightedItem;
                        break;
                    case "DataType": // DIResource.DI_COMMON_RESOURCETYPE_DATATYPE
                        results = _last_DTB_HighlightedItem;
                        break;
                }
                _last_BrowserType = browserType;
            }
            else
            {
                // Browser type has not changed - store the new highlightedItem value
                switch (browserType)
                {
                    case "Tag": // DIResource.DI_COMMON_RESOURCETYPE_TAG
                        _last_DIB_HighlightedItem = highlightedItem;
                        results = _last_DIB_HighlightedItem;
                        break;
                    case "DataType": // DIResource.DI_COMMON_RESOURCETYPE_DATATYPE
                        _last_DTB_HighlightedItem = highlightedItem;
                        results = _last_DTB_HighlightedItem;
                        break;
                }
            }

            return results;
        }

        /// <summary>
        /// If the user types into the data port (even though this is a ReadOnly field and there is OneWay binding) this method is called.
        /// Just return the known values for BrowserType and Highlighted item.
        /// </summary>
        /// <param name="value"></param>
        /// <param name="targetTypes"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, System.Globalization.CultureInfo culture)
        {            
            string[] highLightedItems = new string[2];
            highLightedItems[0] = _last_BrowserType;
            highLightedItems[1] = (string)value;

            return highLightedItems;
        }
     
        #endregion
    }
    
}
