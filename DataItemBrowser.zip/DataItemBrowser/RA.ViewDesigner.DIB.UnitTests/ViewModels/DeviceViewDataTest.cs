﻿using RockwellAutomation.UI.ViewModels;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using RockwellAutomation.UI;
using RockwellAutomation.Client.Services.Query.AbstractItem;
using RockwellAutomation.Client.Services.Query.Common;

namespace DataItemBrowserUT
{
    
    
    /// <summary>
    ///This is a test class for DeviceViewDataTest and is intended
    ///to contain all DeviceViewDataTest Unit Tests
    ///</summary>
    [TestClass()]
    public class DeviceViewDataTest
    {

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        /// <summary>
        ///A test for Description
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DescriptionTest()
        {
            string actual = "DataLogs";
            DataItemBase dib = new DataItemBase() { CommonDescription = actual };

            DIBListViewItem target = new DIBListViewItem(dib);
            Assert.IsTrue(actual == target.Description, "Target description must be " + actual);
        }

        /// <summary>
        ///A test for IsSelected
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void IsSelectedTest()
        {
            DIBListViewItem target = new DIBListViewItem(null);
            target.IsSelected = false;
            Assert.IsFalse(target.IsSelected, "IsSelected is not false");
            target.IsSelected = true;
            Assert.IsTrue(target.IsSelected, "IsSelected is not true");
        }

        /// <summary>
        ///A test for Item
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void DV_ItemTest()
        {
            DataItemBase dib = new DataItemBase() { CommonName = "DataLogs" };

            DIBListViewItem target = new DIBListViewItem(dib);
            Assert.IsTrue(dib.Equals(target.DataItem), "DeviceViewData's item is not correct");
        }

        /// <summary>
        ///A test for Name property
        ///</summary>
        [TestMethod()]
        [DeploymentItem("RA.Common.DIB.dll")]
        public void NameTest()
        {
            string actual = "DataLogs";

            DataItemBase dib = new DataItemBase() { CommonName = actual };

            DIBListViewItem target = new DIBListViewItem(dib);
            Assert.IsTrue(actual == target.Name, "Target name must be DatLogs");
        }
    }
}
