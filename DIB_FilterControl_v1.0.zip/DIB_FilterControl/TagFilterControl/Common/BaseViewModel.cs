﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TagFilterControl.Common
{
    public abstract class BaseViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void RaisePropertyChangedEvent(string propertyName)
        {
            this.VerifyPropertyName(propertyName);
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        public void RaisePropertyChangedEvent<T>(Expression<Func<T>> propertyExpression)
        {
            try
            {
                string propertyName = PropertySupport.ExtractPropertyName(propertyExpression);
                this.RaisePropertyChangedEvent(propertyName);
            }
            catch (Exception ex)
            {
            }
        }
        public void VerifyPropertyName(string propertyName)
        {
            var myType = this.GetType();
            if (myType.GetProperty(propertyName) == null)
            {
                throw new ArgumentException("Property not found", propertyName);
            }
        }
    }

    public static class PropertySupport
    {
        public static string ExtractPropertyName<T>(Expression<Func<T>> propertyExpression)
        {
            if (propertyExpression == null)
            {
                throw new ArgumentNullException("propertyExpression");
            }
            MemberExpression memberExpression = propertyExpression.Body as MemberExpression;
            if (memberExpression == null)
            {
                throw new ArgumentException("Param is not a MemberExpression", "propertyExpression");
            }
            PropertyInfo property = memberExpression.Member as PropertyInfo;
            if (property == null)
            {
                throw new ArgumentException("Param is not a property", "propertyExpression");
            }
            if (property.GetGetMethod(true).IsStatic)
            {
                throw new ArgumentException("Param is not a static property", "propertyExpression");
            }
            return memberExpression.Member.Name;
        }
    }
}
